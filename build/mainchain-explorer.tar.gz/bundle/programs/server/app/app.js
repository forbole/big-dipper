var require = meteorInstall({"imports":{"api":{"accounts":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/accounts/server/methods.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Validators;
module.link("/imports/api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);

const fetchFromUrl = url => {
  try {
    let res = HTTP.get(LCD + url);

    if (res.statusCode == 200) {
      return res;
    }

    ;
  } catch (e) {
    console.log(e);
  }
};

Meteor.methods({
  'accounts.getAccountDetail': function (address) {
    this.unblock();
    let url = LCD + '/auth/accounts/' + address;

    try {
      let available = HTTP.get(url);

      if (available.statusCode == 200) {
        let response = JSON.parse(available.content).result;
        let account;
        if (response.type === 'cosmos-sdk/Account') account = response.value;else if (response.type === 'cosmos-sdk/DelayedVestingAccount' || response.type === 'cosmos-sdk/ContinuousVestingAccount') account = response.value.BaseVestingAccount.BaseAccount;
        if (account && account.account_number != null) return account;
        return null;
      }
    } catch (e) {
      console.log(e);
    }
  },
  'accounts.getBalance': function (address) {
    this.unblock();
    let balance = {}; // get available atoms

    let url = LCD + '/bank/balances/' + address;

    try {
      let available = HTTP.get(url);

      if (available.statusCode == 200) {
        // console.log(JSON.parse(available.content))
        balance.available = JSON.parse(available.content).result;
        if (balance.available && balance.available.length > 0) balance.available = balance.available[0];
      }
    } catch (e) {
      console.log(e);
    } // get delegated amnounts


    url = LCD + '/staking/delegators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        balance.delegations = JSON.parse(delegations.content).result;
      }
    } catch (e) {
      console.log(e);
    } // get unbonding


    url = LCD + '/staking/delegators/' + address + '/unbonding_delegations';

    try {
      let unbonding = HTTP.get(url);

      if (unbonding.statusCode == 200) {
        balance.unbonding = JSON.parse(unbonding.content).result;
      }
    } catch (e) {
      console.log(e);
    } // get rewards


    url = LCD + '/distribution/delegators/' + address + '/rewards';

    try {
      let rewards = HTTP.get(url);

      if (rewards.statusCode == 200) {
        balance.rewards = JSON.parse(rewards.content).result.total;
      }
    } catch (e) {
      console.log(e);
    } // get commission


    let validator = Validators.findOne({
      $or: [{
        operator_address: address
      }, {
        delegator_address: address
      }, {
        address: address
      }]
    });

    if (validator) {
      let url = LCD + '/distribution/validators/' + validator.operator_address;
      balance.operator_address = validator.operator_address;

      try {
        let rewards = HTTP.get(url);

        if (rewards.statusCode == 200) {
          let content = JSON.parse(rewards.content).result;
          if (content.val_commission && content.val_commission.length > 0) balance.commission = content.val_commission[0];
        }
      } catch (e) {
        console.log(e);
      }
    }

    return balance;
  },

  'accounts.getDelegation'(address, validator) {
    let url = "/staking/delegators/".concat(address, "/delegations/").concat(validator);
    let delegations = fetchFromUrl(url);
    delegations = delegations && delegations.data.result;
    if (delegations && delegations.shares) delegations.shares = parseFloat(delegations.shares);
    url = "/staking/redelegations?delegator=".concat(address, "&validator_to=").concat(validator);
    let relegations = fetchFromUrl(url);
    relegations = relegations && relegations.data.result;
    let completionTime;

    if (relegations) {
      relegations.forEach(relegation => {
        let entries = relegation.entries;
        let time = new Date(entries[entries.length - 1].completion_time);
        if (!completionTime || time > completionTime) completionTime = time;
      });
      delegations.redelegationCompletionTime = completionTime;
    }

    url = "/staking/delegators/".concat(address, "/unbonding_delegations/").concat(validator);
    let undelegations = fetchFromUrl(url);
    undelegations = undelegations && undelegations.data.result;

    if (undelegations) {
      delegations.unbonding = undelegations.entries.length;
      delegations.unbondingCompletionTime = undelegations.entries[0].completion_time;
    }

    return delegations;
  },

  'accounts.getAllDelegations'(address) {
    let url = LCD + '/staking/delegators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        delegations = JSON.parse(delegations.content).result;

        if (delegations && delegations.length > 0) {
          delegations.forEach((delegation, i) => {
            if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
          });
        }

        return delegations;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  },

  'accounts.getAllUnbondings'(address) {
    let url = LCD + '/staking/delegators/' + address + '/unbonding_delegations';

    try {
      let unbondings = HTTP.get(url);

      if (unbondings.statusCode == 200) {
        unbondings = JSON.parse(unbondings.content).result;
        return unbondings;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  },

  'accounts.getAllRedelegations'(address, validator) {
    let url = "/staking/redelegations?delegator=".concat(address, "&validator_from=").concat(validator);
    let result = fetchFromUrl(url);

    if (result && result.data) {
      let redelegations = {};
      result.data.forEach(redelegation => {
        let entries = redelegation.entries;
        redelegations[redelegation.validator_dst_address] = {
          count: entries.length,
          completionTime: entries[0].completion_time
        };
      });
      return redelegations;
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"blocks":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/server/methods.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Promise;
module.link("meteor/promise", {
  Promise(v) {
    Promise = v;
  }

}, 2);
let Blockscon;
module.link("/imports/api/blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 3);
let Chain;
module.link("/imports/api/chain/chain.js", {
  Chain(v) {
    Chain = v;
  }

}, 4);
let ValidatorSets;
module.link("/imports/api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 5);
let Validators;
module.link("/imports/api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 6);
let ValidatorRecords, Analytics, VPDistributions;
module.link("/imports/api/records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  VPDistributions(v) {
    VPDistributions = v;
  }

}, 7);
let VotingPowerHistory;
module.link("/imports/api/voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 8);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 9);
let Evidences;
module.link("../../evidences/evidences.js", {
  Evidences(v) {
    Evidences = v;
  }

}, 10);
let sha256;
module.link("js-sha256", {
  sha256(v) {
    sha256 = v;
  }

}, 11);
let getAddress;
module.link("tendermint/lib/pubkey", {
  getAddress(v) {
    getAddress = v;
  }

}, 12);
let cheerio;
module.link("cheerio", {
  "*"(v) {
    cheerio = v;
  }

}, 13);

// import Block from '../../../ui/components/Block';
// getValidatorVotingPower = (validators, address) => {
//     for (v in validators){
//         if (validators[v].address == address){
//             return parseInt(validators[v].voting_power);
//         }
//     }
// }
getRemovedValidators = (prevValidators, validators) => {
  // let removeValidators = [];
  for (p in prevValidators) {
    for (v in validators) {
      if (prevValidators[p].address == validators[v].address) {
        prevValidators.splice(p, 1);
      }
    }
  }

  return prevValidators;
};

getValidatorProfileUrl = identity => {
  if (identity.length == 16) {
    let response = HTTP.get("https://keybase.io/_/api/1.0/user/lookup.json?key_suffix=".concat(identity, "&fields=pictures"));

    if (response.statusCode == 200) {
      let them = response.data.them;
      return them && them.length && them[0].pictures && them[0].pictures.primary && them[0].pictures.primary.url;
    } else {
      console.log(JSON.stringify(response));
    }
  } else if (identity.indexOf("keybase.io/team/") > 0) {
    let teamPage = HTTP.get(identity);

    if (teamPage.statusCode == 200) {
      let page = cheerio.load(teamPage.content);
      return page(".kb-main-card img").attr('src');
    } else {
      console.log(JSON.stringify(teamPage));
    }
  }
}; // var filtered = [1, 2, 3, 4, 5].filter(notContainedIn([1, 2, 3, 5]));
// console.log(filtered); // [4]


Meteor.methods({
  'blocks.averageBlockTime'(address) {
    let blocks = Blockscon.find({
      proposerAddress: address
    }).fetch();
    let heights = blocks.map((block, i) => {
      return block.height;
    });
    let blocksStats = Analytics.find({
      height: {
        $in: heights
      }
    }).fetch(); // console.log(blocksStats);

    let totalBlockDiff = 0;

    for (b in blocksStats) {
      totalBlockDiff += blocksStats[b].timeDiff;
    }

    return totalBlockDiff / heights.length;
  },

  'blocks.findUpTime'(address) {
    let collection = ValidatorRecords.rawCollection(); // let aggregateQuery = Meteor.wrapAsync(collection.aggregate, collection);

    var pipeline = [{
      $match: {
        "address": address
      }
    }, // {$project:{address:1,height:1,exists:1}},
    {
      $sort: {
        "height": -1
      }
    }, {
      $limit: Meteor.settings.public.uptimeWindow - 1
    }, {
      $unwind: "$_id"
    }, {
      $group: {
        "_id": "$address",
        "uptime": {
          "$sum": {
            $cond: [{
              $eq: ['$exists', true]
            }, 1, 0]
          }
        }
      }
    }]; // let result = aggregateQuery(pipeline, { cursor: {} });

    return Promise.await(collection.aggregate(pipeline).toArray()); // return .aggregate()
  },

  'blocks.getLatestHeight': function () {
    this.unblock();
    let url = RPC + '/status';

    try {
      let response = HTTP.get(url);
      let status = JSON.parse(response.content);
      return status.result.sync_info.latest_block_height;
    } catch (e) {
      return 0;
    }
  },
  'blocks.getCurrentHeight': function () {
    this.unblock();
    let currHeight = Blockscon.find({}, {
      sort: {
        height: -1
      },
      limit: 1
    }).fetch(); // console.log("currentHeight:"+currHeight);

    let startHeight = Meteor.settings.params.startHeight;

    if (currHeight && currHeight.length == 1) {
      let height = currHeight[0].height;
      if (height > startHeight) return height;
    }

    return startHeight;
  },
  'blocks.blocksUpdate': function () {
    if (SYNCING) return "Syncing...";else console.log("start to sync"); // Meteor.clearInterval(Meteor.timerHandle);
    // get the latest height

    let until = Meteor.call('blocks.getLatestHeight'); // console.log(until);
    // get the current height in db

    let curr = Meteor.call('blocks.getCurrentHeight');
    console.log(curr); // loop if there's update in db

    if (until > curr) {
      SYNCING = true;
      let validatorSet = {}; // get latest validator candidate information

      url = LCD + '/staking/validators';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      url = LCD + '/staking/validators?status=unbonding';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      url = LCD + '/staking/validators?status=unbonded';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      let totalValidators = Object.keys(validatorSet).length;
      console.log("all validators: " + totalValidators);

      for (let height = curr + 1; height <= until; height++) {
        let startBlockTime = new Date(); // add timeout here? and outside this loop (for catched up and keep fetching)?

        this.unblock();
        let url = RPC + '/block?height=' + height;
        let analyticsData = {};
        console.log(url);

        try {
          const bulkValidators = Validators.rawCollection().initializeUnorderedBulkOp();
          const bulkValidatorRecords = ValidatorRecords.rawCollection().initializeUnorderedBulkOp();
          const bulkVPHistory = VotingPowerHistory.rawCollection().initializeUnorderedBulkOp();
          const bulkTransations = Transactions.rawCollection().initializeUnorderedBulkOp();
          let startGetHeightTime = new Date();
          let response = HTTP.get(url);

          if (response.statusCode == 200) {
            let block = JSON.parse(response.content);
            block = block.result; // store height, hash, numtransaction and time in db

            let blockData = {};
            blockData.height = height;
            blockData.hash = block.block_meta.block_id.hash;
            blockData.transNum = block.block_meta.header.num_txs;
            blockData.time = new Date(block.block.header.time);
            blockData.lastBlockHash = block.block.header.last_block_id.hash;
            blockData.proposerAddress = block.block.header.proposer_address;
            blockData.validators = [];
            let precommits = block.block.last_commit.precommits;

            if (precommits != null) {
              // console.log(precommits.length);
              for (let i = 0; i < precommits.length; i++) {
                if (precommits[i] != null) {
                  blockData.validators.push(precommits[i].validator_address);
                }
              }

              analyticsData.precommits = precommits.length; // record for analytics
              // PrecommitRecords.insert({height:height, precommits:precommits.length});
            } // save txs in database


            if (block.block.data.txs && block.block.data.txs.length > 0) {
              for (t in block.block.data.txs) {
                Meteor.call('Transactions.index', sha256(Buffer.from(block.block.data.txs[t], 'base64')), blockData.time, (err, result) => {
                  if (err) {
                    console.log(err);
                  }
                });
              }
            } // save double sign evidences


            if (block.block.evidence.evidence) {
              Evidences.insert({
                height: height,
                evidence: block.block.evidence.evidence
              });
            }

            blockData.precommitsCount = blockData.validators.length;
            analyticsData.height = height;
            let endGetHeightTime = new Date();
            console.log("Get height time: " + (endGetHeightTime - startGetHeightTime) / 1000 + "seconds.");
            let startGetValidatorsTime = new Date(); // update chain status

            url = RPC + '/validators?height=' + height;
            response = HTTP.get(url);
            console.log(url);
            let validators = JSON.parse(response.content);
            validators.result.block_height = parseInt(validators.result.block_height);
            ValidatorSets.insert(validators.result);
            blockData.validatorsCount = validators.result.validators.length;
            let startBlockInsertTime = new Date();
            Blockscon.insert(blockData);
            let endBlockInsertTime = new Date();
            console.log("Block insert time: " + (endBlockInsertTime - startBlockInsertTime) / 1000 + "seconds."); // store valdiators exist records

            let existingValidators = Validators.find({
              address: {
                $exists: true
              }
            }).fetch();

            if (height > 1) {
              // record precommits and calculate uptime
              // only record from block 2
              for (i in validators.result.validators) {
                let address = validators.result.validators[i].address;
                let record = {
                  height: height,
                  address: address,
                  exists: false,
                  voting_power: parseInt(validators.result.validators[i].voting_power) //getValidatorVotingPower(existingValidators, address)

                };

                for (j in precommits) {
                  if (precommits[j] != null) {
                    if (address == precommits[j].validator_address) {
                      record.exists = true;
                      precommits.splice(j, 1);
                      break;
                    }
                  }
                } // calculate the uptime based on the records stored in previous blocks
                // only do this every 15 blocks ~


                if (height % 15 == 0) {
                  // let startAggTime = new Date();
                  let numBlocks = Meteor.call('blocks.findUpTime', address);
                  let uptime = 0; // let endAggTime = new Date();
                  // console.log("Get aggregated uptime for "+existingValidators[i].address+": "+((endAggTime-startAggTime)/1000)+"seconds.");

                  if (numBlocks[0] != null && numBlocks[0].uptime != null) {
                    uptime = numBlocks[0].uptime;
                  }

                  let base = Meteor.settings.public.uptimeWindow;

                  if (height < base) {
                    base = height;
                  }

                  if (record.exists) {
                    if (uptime < base) {
                      uptime++;
                    }

                    uptime = uptime / base * 100;
                    bulkValidators.find({
                      address: address
                    }).upsert().updateOne({
                      $set: {
                        uptime: uptime,
                        lastSeen: blockData.time
                      }
                    });
                  } else {
                    uptime = uptime / base * 100;
                    bulkValidators.find({
                      address: address
                    }).upsert().updateOne({
                      $set: {
                        uptime: uptime
                      }
                    });
                  }
                }

                bulkValidatorRecords.insert(record); // ValidatorRecords.update({height:height,address:record.address},record);
              }
            }

            let chainStatus = Chain.findOne({
              chainId: block.block_meta.header.chain_id
            });
            let lastSyncedTime = chainStatus ? chainStatus.lastSyncedTime : 0;
            let timeDiff;
            let blockTime = Meteor.settings.params.defaultBlockTime;

            if (lastSyncedTime) {
              let dateLatest = blockData.time;
              let dateLast = new Date(lastSyncedTime);
              timeDiff = Math.abs(dateLatest.getTime() - dateLast.getTime());
              blockTime = (chainStatus.blockTime * (blockData.height - 1) + timeDiff) / blockData.height;
            }

            let endGetValidatorsTime = new Date();
            console.log("Get height validators time: " + (endGetValidatorsTime - startGetValidatorsTime) / 1000 + "seconds.");
            Chain.update({
              chainId: block.block_meta.header.chain_id
            }, {
              $set: {
                lastSyncedTime: blockData.time,
                blockTime: blockTime
              }
            });
            analyticsData.averageBlockTime = blockTime;
            analyticsData.timeDiff = timeDiff;
            analyticsData.time = blockData.time; // initialize validator data at first block
            // if (height == 1){
            //     Validators.remove({});
            // }

            analyticsData.voting_power = 0;
            let startFindValidatorsNameTime = new Date();

            if (validators.result) {
              // validators are all the validators in the current height
              console.log("validatorSet size: " + validators.result.validators.length);

              for (v in validators.result.validators) {
                // Validators.insert(validators.result.validators[v]);
                let validator = validators.result.validators[v];
                validator.voting_power = parseInt(validator.voting_power);
                validator.proposer_priority = parseInt(validator.proposer_priority);
                let valExist = Validators.findOne({
                  "pub_key.value": validator.pub_key.value
                });

                if (!valExist) {
                  console.log("validator pub_key ".concat(validator.address, " ").concat(validator.pub_key.value, " not in db")); // let command = Meteor.settings.bin.gaiadebug+" pubkey "+validator.pub_key.value;
                  // console.log(command);
                  // let tempVal = validator;

                  validator.address = getAddress(validator.pub_key);
                  validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
                  validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
                  validator.consensus_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixConsPub);
                  let validatorData = validatorSet[validator.consensus_pubkey];

                  if (validatorData) {
                    if (validatorData.description.identity) validator.profile_url = getValidatorProfileUrl(validatorData.description.identity);
                    validator.operator_address = validatorData.operator_address;
                    validator.delegator_address = Meteor.call('getDelegator', validatorData.operator_address);
                    validator.jailed = validatorData.jailed;
                    validator.status = validatorData.status;
                    validator.min_self_delegation = validatorData.min_self_delegation;
                    validator.tokens = validatorData.tokens;
                    validator.delegator_shares = validatorData.delegator_shares;
                    validator.description = validatorData.description;
                    validator.bond_height = validatorData.bond_height;
                    validator.bond_intra_tx_counter = validatorData.bond_intra_tx_counter;
                    validator.unbonding_height = validatorData.unbonding_height;
                    validator.unbonding_time = validatorData.unbonding_time;
                    validator.commission = validatorData.commission;
                    validator.self_delegation = validator.delegator_shares; // validator.removed = false,
                    // validator.removedAt = 0
                    // validatorSet.splice(val, 1);
                  } else {
                    console.log('no con pub key?');
                  } // bulkValidators.insert(validator);


                  bulkValidators.find({
                    consensus_pubkey: validator.consensus_pubkey
                  }).upsert().updateOne({
                    $set: validator
                  }); // console.log("validator first appears: "+bulkValidators.length);

                  bulkVPHistory.insert({
                    address: validator.address,
                    prev_voting_power: 0,
                    voting_power: validator.voting_power,
                    type: 'add',
                    height: blockData.height,
                    block_time: blockData.time
                  }); // Meteor.call('runCode', command, function(error, result){
                  // validator.address = result.match(/\s[0-9A-F]{40}$/igm);
                  // validator.address = validator.address[0].trim();
                  // validator.hex = result.match(/\s[0-9A-F]{64}$/igm);
                  // validator.hex = validator.hex[0].trim();
                  // validator.cosmosaccpub = result.match(/cosmospub.*$/igm);
                  // validator.cosmosaccpub = validator.cosmosaccpub[0].trim();
                  // validator.operator_pubkey = result.match(/cosmosvaloperpub.*$/igm);
                  // validator.operator_pubkey = validator.operator_pubkey[0].trim();
                  // validator.consensus_pubkey = result.match(/cosmosvalconspub.*$/igm);
                  // validator.consensus_pubkey = validator.consensus_pubkey[0].trim();
                  // });
                } else {
                  let validatorData = validatorSet[valExist.consensus_pubkey];

                  if (validatorData) {
                    if (validatorData.description && (!valExist.description || validatorData.description.identity !== valExist.description.identity)) validator.profile_url = getValidatorProfileUrl(validatorData.description.identity);
                    validator.jailed = validatorData.jailed;
                    validator.status = validatorData.status;
                    validator.tokens = validatorData.tokens;
                    validator.delegator_shares = validatorData.delegator_shares;
                    validator.description = validatorData.description;
                    validator.bond_height = validatorData.bond_height;
                    validator.bond_intra_tx_counter = validatorData.bond_intra_tx_counter;
                    validator.unbonding_height = validatorData.unbonding_height;
                    validator.unbonding_time = validatorData.unbonding_time;
                    validator.commission = validatorData.commission; // calculate self delegation percentage every 30 blocks

                    if (height % 30 == 1) {
                      try {
                        let response = HTTP.get(LCD + '/staking/delegators/' + valExist.delegator_address + '/delegations/' + valExist.operator_address);

                        if (response.statusCode == 200) {
                          let selfDelegation = JSON.parse(response.content).result;

                          if (selfDelegation.shares) {
                            validator.self_delegation = parseFloat(selfDelegation.shares) / parseFloat(validator.delegator_shares);
                          }
                        }
                      } catch (e) {// console.log(e);
                      }
                    }

                    bulkValidators.find({
                      consensus_pubkey: valExist.consensus_pubkey
                    }).updateOne({
                      $set: validator
                    }); // console.log("validator exisits: "+bulkValidators.length);
                    // validatorSet.splice(val, 1);
                  } else {
                    console.log('no con pub key?');
                  }

                  let prevVotingPower = VotingPowerHistory.findOne({
                    address: validator.address
                  }, {
                    height: -1,
                    limit: 1
                  });

                  if (prevVotingPower) {
                    if (prevVotingPower.voting_power != validator.voting_power) {
                      let changeType = prevVotingPower.voting_power > validator.voting_power ? 'down' : 'up';
                      let changeData = {
                        address: validator.address,
                        prev_voting_power: prevVotingPower.voting_power,
                        voting_power: validator.voting_power,
                        type: changeType,
                        height: blockData.height,
                        block_time: blockData.time
                      }; // console.log('voting power changed.');
                      // console.log(changeData);

                      bulkVPHistory.insert(changeData);
                    }
                  }
                } // console.log(validator);


                analyticsData.voting_power += validator.voting_power;
              } // if there is validator removed


              let prevValidators = ValidatorSets.findOne({
                block_height: height - 1
              });

              if (prevValidators) {
                let removedValidators = getRemovedValidators(prevValidators.validators, validators.result.validators);

                for (r in removedValidators) {
                  bulkVPHistory.insert({
                    address: removedValidators[r].address,
                    prev_voting_power: removedValidators[r].voting_power,
                    voting_power: 0,
                    type: 'remove',
                    height: blockData.height,
                    block_time: blockData.time
                  });
                }
              }
            } // check if there's any validator not in db 14400 blocks(~1 day)


            if (height % 14400 == 0) {
              try {
                console.log('Checking all validators against db...');
                let dbValidators = {};
                Validators.find({}, {
                  fields: {
                    consensus_pubkey: 1,
                    status: 1
                  }
                }).forEach(v => dbValidators[v.consensus_pubkey] = v.status);
                Object.keys(validatorSet).forEach(conPubKey => {
                  let validatorData = validatorSet[conPubKey]; // Active validators should have been updated in previous steps

                  if (validatorData.status === 2) return;

                  if (dbValidators[conPubKey] == undefined) {
                    console.log("validator with consensus_pubkey ".concat(conPubKey, " not in db"));
                    validatorData.pub_key = {
                      "type": "tendermint/PubKeyEd25519",
                      "value": Meteor.call('bech32ToPubkey', conPubKey)
                    };
                    validatorData.address = getAddress(validatorData.pub_key);
                    validatorData.delegator_address = Meteor.call('getDelegator', validatorData.operator_address);
                    validatorData.accpub = Meteor.call('pubkeyToBech32', validatorData.pub_key, Meteor.settings.public.bech32PrefixAccPub);
                    validatorData.operator_pubkey = Meteor.call('pubkeyToBech32', validatorData.pub_key, Meteor.settings.public.bech32PrefixValPub);
                    console.log(JSON.stringify(validatorData));
                    bulkValidators.find({
                      consensus_pubkey: conPubKey
                    }).upsert().updateOne({
                      $set: validatorData
                    });
                  } else if (dbValidators[conPubKey] == 2) {
                    bulkValidators.find({
                      consensus_pubkey: conPubKey
                    }).upsert().updateOne({
                      $set: validatorData
                    });
                  }
                });
              } catch (e) {
                console.log(e);
              }
            } // fetching keybase every 14400 blocks(~1 day)


            if (height % 14400 == 1) {
              console.log('Fetching keybase...');
              Validators.find({}).forEach(validator => {
                try {
                  let profileUrl = getValidatorProfileUrl(validator.description.identity);

                  if (profileUrl) {
                    bulkValidators.find({
                      address: validator.address
                    }).upsert().updateOne({
                      $set: {
                        'profile_url': profileUrl
                      }
                    });
                  }
                } catch (e) {
                  console.log(e);
                }
              });
            }

            let endFindValidatorsNameTime = new Date();
            console.log("Get validators name time: " + (endFindValidatorsNameTime - startFindValidatorsNameTime) / 1000 + "seconds."); // record for analytics

            let startAnayticsInsertTime = new Date();
            Analytics.insert(analyticsData);
            let endAnalyticsInsertTime = new Date();
            console.log("Analytics insert time: " + (endAnalyticsInsertTime - startAnayticsInsertTime) / 1000 + "seconds.");
            let startVUpTime = new Date();

            if (bulkValidators.length > 0) {
              // console.log(bulkValidators.length);
              bulkValidators.execute((err, result) => {
                if (err) {
                  console.log(err);
                }

                if (result) {// console.log(result);
                }
              });
            }

            let endVUpTime = new Date();
            console.log("Validator update time: " + (endVUpTime - startVUpTime) / 1000 + "seconds.");
            let startVRTime = new Date();

            if (bulkValidatorRecords.length > 0) {
              bulkValidatorRecords.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            }

            let endVRTime = new Date();
            console.log("Validator records update time: " + (endVRTime - startVRTime) / 1000 + "seconds.");

            if (bulkVPHistory.length > 0) {
              bulkVPHistory.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            }

            if (bulkTransations.length > 0) {
              bulkTransations.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            } // calculate voting power distribution every 60 blocks ~ 5mins


            if (height % 60 == 1) {
              console.log("===== calculate voting power distribution =====");
              let activeValidators = Validators.find({
                status: 2,
                jailed: false
              }, {
                sort: {
                  voting_power: -1
                }
              }).fetch();
              let numTopTwenty = Math.ceil(activeValidators.length * 0.2);
              let numBottomEighty = activeValidators.length - numTopTwenty;
              let topTwentyPower = 0;
              let bottomEightyPower = 0;
              let numTopThirtyFour = 0;
              let numBottomSixtySix = 0;
              let topThirtyFourPercent = 0;
              let bottomSixtySixPercent = 0;

              for (v in activeValidators) {
                if (v < numTopTwenty) {
                  topTwentyPower += activeValidators[v].voting_power;
                } else {
                  bottomEightyPower += activeValidators[v].voting_power;
                }

                if (topThirtyFourPercent < 0.34) {
                  topThirtyFourPercent += activeValidators[v].voting_power / analyticsData.voting_power;
                  numTopThirtyFour++;
                }
              }

              bottomSixtySixPercent = 1 - topThirtyFourPercent;
              numBottomSixtySix = activeValidators.length - numTopThirtyFour;
              let vpDist = {
                height: height,
                numTopTwenty: numTopTwenty,
                topTwentyPower: topTwentyPower,
                numBottomEighty: numBottomEighty,
                bottomEightyPower: bottomEightyPower,
                numTopThirtyFour: numTopThirtyFour,
                topThirtyFourPercent: topThirtyFourPercent,
                numBottomSixtySix: numBottomSixtySix,
                bottomSixtySixPercent: bottomSixtySixPercent,
                numValidators: activeValidators.length,
                totalVotingPower: analyticsData.voting_power,
                blockTime: blockData.time,
                createAt: new Date()
              };
              console.log(vpDist);
              VPDistributions.insert(vpDist);
            }
          }
        } catch (e) {
          console.log(e);
          SYNCING = false;
          return "Stopped";
        }

        let endBlockTime = new Date();
        console.log("This block used: " + (endBlockTime - startBlockTime) / 1000 + "seconds.");
      }

      SYNCING = false;
      Chain.update({
        chainId: Meteor.settings.public.chainId
      }, {
        $set: {
          lastBlocksSyncedTime: new Date(),
          totalValidators: totalValidators
        }
      });
    }

    return until;
  },
  'addLimit': function (limit) {
    // console.log(limit+10)
    return limit + 10;
  },
  'hasMore': function (limit) {
    if (limit > Meteor.call('getCurrentHeight')) {
      return false;
    } else {
      return true;
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/server/publications.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Blockscon;
module.link("../blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 3);
publishComposite('blocks.height', function (limit) {
  return {
    find() {
      return Blockscon.find({}, {
        limit: limit,
        sort: {
          height: -1
        }
      });
    },

    children: [{
      find(block) {
        return Validators.find({
          address: block.proposerAddress
        }, {
          limit: 1
        });
      }

    }]
  };
});
publishComposite('blocks.findOne', function (height) {
  return {
    find() {
      return Blockscon.find({
        height: height
      });
    },

    children: [{
      find(block) {
        return Transactions.find({
          height: block.height
        });
      }

    }, {
      find(block) {
        return Validators.find({
          address: block.proposerAddress
        }, {
          limit: 1
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"blocks.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/blocks.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Blockscon: () => Blockscon
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const Blockscon = new Mongo.Collection('blocks');
Blockscon.helpers({
  proposer() {
    return Validators.findOne({
      address: this.proposerAddress
    });
  }

}); // Blockscon.helpers({
//     sorted(limit) {
//         return Blockscon.find({}, {sort: {height:-1}, limit: limit});
//     }
// });
// Meteor.setInterval(function() {
//     Meteor.call('blocksUpdate', (error, result) => {
//         console.log(result);
//     })
// }, 30000000);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chain":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/server/methods.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let getAddress;
module.link("tendermint/lib/pubkey.js", {
  getAddress(v) {
    getAddress = v;
  }

}, 2);
let Chain, ChainStates;
module.link("../chain.js", {
  Chain(v) {
    Chain = v;
  },

  ChainStates(v) {
    ChainStates = v;
  }

}, 3);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 4);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 5);

findVotingPower = (validator, genValidators) => {
  for (let v in genValidators) {
    if (validator.pub_key.value == genValidators[v].pub_key.value) {
      return parseInt(genValidators[v].power);
    }
  }
};

Meteor.methods({
  'chain.getConsensusState': function () {
    this.unblock();
    let url = RPC + '/dump_consensus_state';

    try {
      let response = HTTP.get(url);
      let consensus = JSON.parse(response.content);
      consensus = consensus.result;
      let height = consensus.round_state.height;
      let round = consensus.round_state.round;
      let step = consensus.round_state.step;
      let votedPower = Math.round(parseFloat(consensus.round_state.votes[round].prevotes_bit_array.split(" ")[3]) * 100);
      Chain.update({
        chainId: Meteor.settings.public.chainId
      }, {
        $set: {
          votingHeight: height,
          votingRound: round,
          votingStep: step,
          votedPower: votedPower,
          proposerAddress: consensus.round_state.validators.proposer.address,
          prevotes: consensus.round_state.votes[round].prevotes,
          precommits: consensus.round_state.votes[round].precommits
        }
      });
    } catch (e) {
      console.log(e);
    }
  },
  'chain.updateStatus': function () {
    this.unblock();
    let url = RPC + '/status';

    try {
      let response = HTTP.get(url);
      let status = JSON.parse(response.content);
      status = status.result;
      let chain = {};
      chain.chainId = status.node_info.network;
      chain.latestBlockHeight = status.sync_info.latest_block_height;
      chain.latestBlockTime = status.sync_info.latest_block_time;
      let latestState = ChainStates.findOne({}, {
        sort: {
          height: -1
        }
      });

      if (latestState && latestState.height >= chain.latestBlockHeight) {
        return "no updates (getting block ".concat(chain.latestBlockHeight, " at block ").concat(latestState.height, ")");
      }

      url = RPC + '/validators';
      response = HTTP.get(url);
      let validators = JSON.parse(response.content);
      validators = validators.result.validators;
      chain.validators = validators.length;
      let activeVP = 0;

      for (v in validators) {
        activeVP += parseInt(validators[v].voting_power);
      }

      chain.activeVotingPower = activeVP;
      Chain.update({
        chainId: chain.chainId
      }, {
        $set: chain
      }, {
        upsert: true
      }); // Get chain states

      if (parseInt(chain.latestBlockHeight) > 0) {
        let chainStates = {};
        chainStates.height = parseInt(status.sync_info.latest_block_height);
        chainStates.time = new Date(status.sync_info.latest_block_time);
        url = LCD + '/staking/pool';

        try {
          response = HTTP.get(url);
          let bonding = JSON.parse(response.content).result; // chain.bondedTokens = bonding.bonded_tokens;
          // chain.notBondedTokens = bonding.not_bonded_tokens;

          chainStates.bondedTokens = parseInt(bonding.bonded_tokens);
          chainStates.notBondedTokens = parseInt(bonding.not_bonded_tokens);
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/supply/total/' + Meteor.settings.public.mintingDenom;

        try {
          response = HTTP.get(url);
          let supply = JSON.parse(response.content).result;
          chainStates.totalSupply = parseInt(supply);
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/distribution/community_pool';

        try {
          response = HTTP.get(url);
          let pool = JSON.parse(response.content).result;

          if (pool && pool.length > 0) {
            chainStates.communityPool = [];
            pool.forEach((amount, i) => {
              chainStates.communityPool.push({
                denom: amount.denom,
                amount: parseFloat(amount.amount)
              });
            });
          }
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/minting/inflation';

        try {
          response = HTTP.get(url);
          let inflation = JSON.parse(response.content).result;

          if (inflation) {
            chainStates.inflation = parseFloat(inflation);
          }
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/minting/annual-provisions';

        try {
          response = HTTP.get(url);
          let provisions = JSON.parse(response.content);

          if (provisions) {
            chainStates.annualProvisions = parseFloat(provisions.result);
          }
        } catch (e) {
          console.log(e);
        }

        ChainStates.insert(chainStates);
      } // chain.totalVotingPower = totalVP;
      // validators = Validators.find({}).fetch();
      // console.log(validators);


      return chain.latestBlockHeight;
    } catch (e) {
      console.log(e);
      return "Error getting chain status.";
    }
  },
  'chain.getLatestStatus': function () {
    Chain.find().sort({
      created: -1
    }).limit(1);
  },
  'chain.genesis': function () {
    let chain = Chain.findOne({
      chainId: Meteor.settings.public.chainId
    });

    if (chain && chain.readGenesis) {
      console.log('Genesis file has been processed');
    } else if (Meteor.settings.debug.readGenesis) {
      console.log('=== Start processing genesis file ===');
      let response = HTTP.get(Meteor.settings.genesisFile);
      let genesis = JSON.parse(response.content);
      let distr = genesis.app_state.distr || genesis.app_state.distribution;
      let chainParams = {
        chainId: genesis.chain_id,
        genesisTime: genesis.genesis_time,
        consensusParams: genesis.consensus_params,
        auth: genesis.app_state.auth,
        bank: genesis.app_state.bank,
        staking: {
          pool: genesis.app_state.staking.pool,
          params: genesis.app_state.staking.params
        },
        mint: genesis.app_state.mint,
        distr: {
          communityTax: distr.community_tax,
          baseProposerReward: distr.base_proposer_reward,
          bonusProposerReward: distr.bonus_proposer_reward,
          withdrawAddrEnabled: distr.withdraw_addr_enabled
        },
        gov: null,
        slashing: {
          params: genesis.app_state.slashing.params
        },
        supply: genesis.app_state.supply,
        crisis: genesis.app_state.crisis
      };
      let totalVotingPower = 0; // read gentx

      if (genesis.app_state.genutil && genesis.app_state.genutil.gentxs && genesis.app_state.genutil.gentxs.length > 0) {
        for (i in genesis.app_state.genutil.gentxs) {
          let msg = genesis.app_state.genutil.gentxs[i].value.msg; // console.log(msg.type);

          for (m in msg) {
            if (msg[m].type == "cosmos-sdk/MsgCreateValidator") {
              console.log(msg[m].value); // let command = Meteor.settings.bin.gaiadebug+" pubkey "+msg[m].value.pubkey;

              let validator = {
                consensus_pubkey: msg[m].value.pubkey,
                description: msg[m].value.description,
                commission: msg[m].value.commission,
                min_self_delegation: msg[m].value.min_self_delegation,
                operator_address: msg[m].value.validator_address,
                delegator_address: msg[m].value.delegator_address,
                voting_power: Math.floor(parseInt(msg[m].value.value.amount) / Meteor.settings.public.stakingFraction),
                jailed: false,
                status: 2
              };
              totalVotingPower += validator.voting_power;
              let pubkeyValue = Meteor.call('bech32ToPubkey', msg[m].value.pubkey); // Validators.upsert({consensus_pubkey:msg[m].value.pubkey},validator);

              validator.pub_key = {
                "type": "tendermint/PubKeyEd25519",
                "value": pubkeyValue
              };
              validator.address = getAddress(validator.pub_key);
              validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
              validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
              VotingPowerHistory.insert({
                address: validator.address,
                prev_voting_power: 0,
                voting_power: validator.voting_power,
                type: 'add',
                height: 0,
                block_time: genesis.genesis_time
              });
              Validators.insert(validator);
            }
          }
        }
      } // read validators from previous chain


      console.log('read validators from previous chain');

      if (genesis.app_state.staking.validators && genesis.app_state.staking.validators.length > 0) {
        console.log(genesis.app_state.staking.validators.length);
        let genValidatorsSet = genesis.app_state.staking.validators;
        let genValidators = genesis.validators;

        for (let v in genValidatorsSet) {
          // console.log(genValidators[v]);
          let validator = genValidatorsSet[v];
          validator.delegator_address = Meteor.call('getDelegator', genValidatorsSet[v].operator_address);
          let pubkeyValue = Meteor.call('bech32ToPubkey', validator.consensus_pubkey);
          validator.pub_key = {
            "type": "tendermint/PubKeyEd25519",
            "value": pubkeyValue
          };
          validator.address = getAddress(validator.pub_key);
          validator.pub_key = validator.pub_key;
          validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
          validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
          validator.voting_power = findVotingPower(validator, genValidators);
          totalVotingPower += validator.voting_power;
          Validators.upsert({
            consensus_pubkey: validator.consensus_pubkey
          }, validator);
          VotingPowerHistory.insert({
            address: validator.address,
            prev_voting_power: 0,
            voting_power: validator.voting_power,
            type: 'add',
            height: 0,
            block_time: genesis.genesis_time
          });
        }
      }

      chainParams.readGenesis = true;
      chainParams.activeVotingPower = totalVotingPower;
      let result = Chain.upsert({
        chainId: chainParams.chainId
      }, {
        $set: chainParams
      });
      console.log('=== Finished processing genesis file ===');
    }

    return true;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/server/publications.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Chain, ChainStates;
module.link("../chain.js", {
  Chain(v) {
    Chain = v;
  },

  ChainStates(v) {
    ChainStates = v;
  }

}, 1);
let CoinStats;
module.link("../../coin-stats/coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
Meteor.publish('chainStates.latest', function () {
  return [ChainStates.find({}, {
    sort: {
      height: -1
    },
    limit: 1
  }), CoinStats.find({}, {
    sort: {
      last_updated_at: -1
    },
    limit: 1
  })];
});
publishComposite('chain.status', function () {
  return {
    find() {
      return Chain.find({
        chainId: Meteor.settings.public.chainId
      });
    },

    children: [{
      find(chain) {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            operator_address: 1,
            status: -1,
            jailed: 1,
            profile_url: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chain.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/chain.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Chain: () => Chain,
  ChainStates: () => ChainStates
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const Chain = new Mongo.Collection('chain');
const ChainStates = new Mongo.Collection('chain_states');
Chain.helpers({
  proposer() {
    return Validators.findOne({
      address: this.proposerAddress
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"coin-stats":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/coin-stats/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let CoinStats;
module.link("../coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 1);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 2);
Meteor.methods({
  'coinStats.getCoinStats': function () {
    this.unblock();
    let coinId = Meteor.settings.public.coingeckoId;

    if (coinId) {
      try {
        let now = new Date();
        now.setMinutes(0);
        let url = "https://api.coingecko.com/api/v3/simple/price?ids=" + coinId + "&vs_currencies=usd&include_market_cap=true&include_24hr_vol=true&include_24hr_change=true&include_last_updated_at=true";
        let response = HTTP.get(url);

        if (response.statusCode == 200) {
          // console.log(JSON.parse(response.content));
          let data = JSON.parse(response.content);
          data = data[coinId]; // console.log(coinStats);

          return CoinStats.upsert({
            last_updated_at: data.last_updated_at
          }, {
            $set: data
          });
        }
      } catch (e) {
        console.log(e);
      }
    } else {
      return "No coingecko Id provided.";
    }
  },
  'coinStats.getStats': function () {
    this.unblock();
    let coinId = Meteor.settings.public.coingeckoId;

    if (coinId) {
      return CoinStats.findOne({}, {
        sort: {
          last_updated_at: -1
        }
      });
    } else {
      return "No coingecko Id provided.";
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"coin-stats.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/coin-stats/coin-stats.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  CoinStats: () => CoinStats
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const CoinStats = new Mongo.Collection('coin_stats');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"delegations":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/server/methods.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Delegations;
module.link("../delegations.js", {
  Delegations(v) {
    Delegations = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
Meteor.methods({
  'delegations.getDelegations': function () {
    this.unblock();
    let validators = Validators.find({}).fetch();
    let delegations = [];
    console.log("=== Getting delegations ===");

    for (v in validators) {
      if (validators[v].operator_address) {
        let url = LCD + '/staking/validators/' + validators[v].operator_address + "/delegations";

        try {
          let response = HTTP.get(url);

          if (response.statusCode == 200) {
            let delegation = JSON.parse(response.content).result; // console.log(delegation);

            delegations = delegations.concat(delegation);
          } else {
            console.log(response.statusCode);
          }
        } catch (e) {
          console.log(e);
        }
      }
    }

    for (i in delegations) {
      if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
    } // console.log(delegations);


    let data = {
      delegations: delegations,
      createdAt: new Date()
    };
    return Delegations.insert(data);
  } // 'blocks.averageBlockTime'(address){
  //     let blocks = Blockscon.find({proposerAddress:address}).fetch();
  //     let heights = blocks.map((block, i) => {
  //         return block.height;
  //     });
  //     let blocksStats = Analytics.find({height:{$in:heights}}).fetch();
  //     // console.log(blocksStats);
  //     let totalBlockDiff = 0;
  //     for (b in blocksStats){
  //         totalBlockDiff += blocksStats[b].timeDiff;
  //     }
  //     return totalBlockDiff/heights.length;
  // }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/server/publications.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"delegations.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/delegations.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Delegations: () => Delegations
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Delegations = new Mongo.Collection('delegations');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"enterprise":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/enterprise/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Enterprise;
module.link("../enterprise.js", {
  Enterprise(v) {
    Enterprise = v;
  }

}, 2);
Meteor.methods({
  'enterprise.getPurchaseOrders': function () {
    this.unblock();

    try {
      let url = LCD + '/enterprise/pos';
      let response = HTTP.get(url);
      let purchaseOrders = JSON.parse(response.content).result;
      let finishedPurchaseOrders = new Set(Enterprise.find({
        "status": {
          $in: ["reject", "complete"]
        }
      }).fetch().map(p => p.poId));
      let poIds = [];

      if (purchaseOrders.length > 0) {
        const bulkPos = Enterprise.rawCollection().initializeUnorderedBulkOp();

        for (let i in purchaseOrders) {
          let po = purchaseOrders[i];
          po.poId = parseInt(po.id);

          if (po.poId > 0 && !finishedPurchaseOrders.has(po.poId)) {
            try {
              bulkPos.find({
                poId: po.poId
              }).upsert().updateOne({
                $set: po
              });
              poIds.push(po.poId);
            } catch (e) {
              bulkPos.find({
                poId: po.poId
              }).upsert().updateOne({
                $set: po
              });
              poIds.push(po.poId);
              console.log(e.response.content);
            }
          }
        }

        if (poIds.length > 0) {
          bulkPos.execute();
        }
      }

      return true;
    } catch (e) {
      console.log(e);
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/enterprise/server/publications.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Enterprise;
module.link("../enterprise.js", {
  Enterprise(v) {
    Enterprise = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
Meteor.publish('enterprise.list_pos', function () {
  return Enterprise.find({}, {
    sort: {
      poId: -1
    }
  });
});
Meteor.publish('enterprise.one_po', function (id) {
  check(id, Number);
  return Enterprise.find({
    poId: id
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"enterprise.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/enterprise/enterprise.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Enterprise: () => Enterprise
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Enterprise = new Mongo.Collection('enterprise');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"ledger":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/ledger/server/methods.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 0);
Meteor.methods({
  'transaction.submit': function (txInfo) {
    const url = "".concat(LCD, "/txs");
    data = {
      "tx": txInfo.value,
      "mode": "sync"
    };
    const timestamp = new Date().getTime();
    console.log("submitting transaction".concat(timestamp, " ").concat(url, " with data ").concat(JSON.stringify(data)));
    let response = HTTP.post(url, {
      data
    });
    console.log("response for transaction".concat(timestamp, " ").concat(url, ": ").concat(JSON.stringify(response)));

    if (response.statusCode == 200) {
      let data = response.data;
      if (data.code) throw new Meteor.Error(data.code, JSON.parse(data.raw_log).message);
      return response.data.txhash;
    }
  },
  'transaction.execute': function (body, path) {
    const url = "".concat(LCD, "/").concat(path);
    data = {
      "base_req": _objectSpread({}, body, {
        "chain_id": Meteor.settings.public.chainId,
        "simulate": false
      })
    };
    let response = HTTP.post(url, {
      data
    });

    if (response.statusCode == 200) {
      return JSON.parse(response.content);
    }
  },
  'transaction.simulate': function (txMsg, from, path) {
    let adjustment = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '1.2';
    const url = "".concat(LCD, "/").concat(path);
    data = _objectSpread({}, txMsg, {
      "base_req": {
        "from": from,
        "chain_id": Meteor.settings.public.chainId,
        "gas_adjustment": adjustment,
        "simulate": true
      }
    });
    let response = HTTP.post(url, {
      data
    });

    if (response.statusCode == 200) {
      return JSON.parse(response.content).gas_estimate;
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"records":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/server/methods.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let ValidatorRecords, Analytics, AverageData, AverageValidatorData;
module.link("../records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  AverageData(v) {
    AverageData = v;
  },

  AverageValidatorData(v) {
    AverageValidatorData = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
let ValidatorSets;
module.link("/imports/api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 4);
let Status;
module.link("../../status/status.js", {
  Status(v) {
    Status = v;
  }

}, 5);
let MissedBlocksStats;
module.link("../records.js", {
  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  }

}, 6);
let MissedBlocks;
module.link("../records.js", {
  MissedBlocks(v) {
    MissedBlocks = v;
  }

}, 7);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 8);
let Chain;
module.link("../../chain/chain.js", {
  Chain(v) {
    Chain = v;
  }

}, 9);

let _;

module.link("lodash", {
  default(v) {
    _ = v;
  }

}, 10);
const BULKUPDATEMAXSIZE = 1000;

const getBlockStats = (startHeight, latestHeight) => {
  let blockStats = {};
  const cond = {
    $and: [{
      height: {
        $gt: startHeight
      }
    }, {
      height: {
        $lte: latestHeight
      }
    }]
  };
  const options = {
    sort: {
      height: 1
    }
  };
  Blockscon.find(cond, options).forEach(block => {
    blockStats[block.height] = {
      height: block.height,
      proposerAddress: block.proposerAddress,
      precommitsCount: block.precommitsCount,
      validatorsCount: block.validatorsCount,
      validators: block.validators,
      time: block.time
    };
  });
  Analytics.find(cond, options).forEach(block => {
    if (!blockStats[block.height]) {
      blockStats[block.height] = {
        height: block.height
      };
      console.log("block ".concat(block.height, " does not have an entry"));
    }

    _.assign(blockStats[block.height], {
      precommits: block.precommits,
      averageBlockTime: block.averageBlockTime,
      timeDiff: block.timeDiff,
      voting_power: block.voting_power
    });
  });
  return blockStats;
};

const getPreviousRecord = (voterAddress, proposerAddress) => {
  let previousRecord = MissedBlocks.findOne({
    voter: voterAddress,
    proposer: proposerAddress,
    blockHeight: -1
  });
  let lastUpdatedHeight = Meteor.settings.params.startHeight;
  let prevStats = {};

  if (previousRecord) {
    prevStats = _.pick(previousRecord, ['missCount', 'totalCount']);
  } else {
    prevStats = {
      missCount: 0,
      totalCount: 0
    };
  }

  return prevStats;
};

Meteor.methods({
  'ValidatorRecords.calculateMissedBlocks': function () {
    if (!COUNTMISSEDBLOCKS) {
      try {
        let startTime = Date.now();
        COUNTMISSEDBLOCKS = true;
        console.log('calulate missed blocks count');
        this.unblock();
        let validators = Validators.find({}).fetch();
        let latestHeight = Meteor.call('blocks.getCurrentHeight');
        let explorerStatus = Status.findOne({
          chainId: Meteor.settings.public.chainId
        });
        let startHeight = explorerStatus && explorerStatus.lastProcessedMissedBlockHeight ? explorerStatus.lastProcessedMissedBlockHeight : Meteor.settings.params.startHeight;
        latestHeight = Math.min(startHeight + BULKUPDATEMAXSIZE, latestHeight);
        const bulkMissedStats = MissedBlocks.rawCollection().initializeOrderedBulkOp();
        let validatorsMap = {};
        validators.forEach(validator => validatorsMap[validator.address] = validator); // a map of block height to block stats

        let blockStats = getBlockStats(startHeight, latestHeight); // proposerVoterStats is a proposer-voter map counting numbers of proposed blocks of which voter is an active validator

        let proposerVoterStats = {};

        _.forEach(blockStats, (block, blockHeight) => {
          let proposerAddress = block.proposerAddress;
          let votedValidators = new Set(block.validators);
          let validatorSets = ValidatorSets.findOne({
            block_height: block.height
          });
          let votedVotingPower = 0;
          validatorSets.validators.forEach(activeValidator => {
            if (votedValidators.has(activeValidator.address)) votedVotingPower += parseFloat(activeValidator.voting_power);
          });
          validatorSets.validators.forEach(activeValidator => {
            let currentValidator = activeValidator.address;

            if (!_.has(proposerVoterStats, [proposerAddress, currentValidator])) {
              let prevStats = getPreviousRecord(currentValidator, proposerAddress);

              _.set(proposerVoterStats, [proposerAddress, currentValidator], prevStats);
            }

            _.update(proposerVoterStats, [proposerAddress, currentValidator, 'totalCount'], n => n + 1);

            if (!votedValidators.has(currentValidator)) {
              _.update(proposerVoterStats, [proposerAddress, currentValidator, 'missCount'], n => n + 1);

              bulkMissedStats.insert({
                voter: currentValidator,
                blockHeight: block.height,
                proposer: proposerAddress,
                precommitsCount: block.precommitsCount,
                validatorsCount: block.validatorsCount,
                time: block.time,
                precommits: block.precommits,
                averageBlockTime: block.averageBlockTime,
                timeDiff: block.timeDiff,
                votingPower: block.voting_power,
                votedVotingPower,
                updatedAt: latestHeight,
                missCount: _.get(proposerVoterStats, [proposerAddress, currentValidator, 'missCount']),
                totalCount: _.get(proposerVoterStats, [proposerAddress, currentValidator, 'totalCount'])
              });
            }
          });
        });

        _.forEach(proposerVoterStats, (voters, proposerAddress) => {
          _.forEach(voters, (stats, voterAddress) => {
            bulkMissedStats.find({
              voter: voterAddress,
              proposer: proposerAddress,
              blockHeight: -1
            }).upsert().updateOne({
              $set: {
                voter: voterAddress,
                proposer: proposerAddress,
                blockHeight: -1,
                updatedAt: latestHeight,
                missCount: _.get(stats, 'missCount'),
                totalCount: _.get(stats, 'totalCount')
              }
            });
          });
        });

        let message = '';

        if (bulkMissedStats.length > 0) {
          const client = MissedBlocks._driver.mongo.client; // TODO: add transaction back after replica set(#146) is set up
          // let session = client.startSession();
          // session.startTransaction();

          let bulkPromise = bulkMissedStats.execute(null
          /*, {session}*/
          ).then(Meteor.bindEnvironment((result, err) => {
            if (err) {
              COUNTMISSEDBLOCKS = false; // Promise.await(session.abortTransaction());

              throw err;
            }

            if (result) {
              // Promise.await(session.commitTransaction());
              message = "(".concat(result.result.nInserted, " inserted, ") + "".concat(result.result.nUpserted, " upserted, ") + "".concat(result.result.nModified, " modified)");
            }
          }));
          Promise.await(bulkPromise);
        }

        COUNTMISSEDBLOCKS = false;
        Status.upsert({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastProcessedMissedBlockHeight: latestHeight,
            lastProcessedMissedBlockTime: new Date()
          }
        });
        return "done in ".concat(Date.now() - startTime, "ms ").concat(message);
      } catch (e) {
        COUNTMISSEDBLOCKS = false;
        throw e;
      }
    } else {
      return "updating...";
    }
  },
  'ValidatorRecords.calculateMissedBlocksStats': function () {
    // TODO: deprecate this method and MissedBlocksStats collection
    // console.log("ValidatorRecords.calculateMissedBlocks: "+COUNTMISSEDBLOCKS);
    if (!COUNTMISSEDBLOCKSSTATS) {
      COUNTMISSEDBLOCKSSTATS = true;
      console.log('calulate missed blocks stats');
      this.unblock();
      let validators = Validators.find({}).fetch();
      let latestHeight = Meteor.call('blocks.getCurrentHeight');
      let explorerStatus = Status.findOne({
        chainId: Meteor.settings.public.chainId
      });
      let startHeight = explorerStatus && explorerStatus.lastMissedBlockHeight ? explorerStatus.lastMissedBlockHeight : Meteor.settings.params.startHeight; // console.log(latestHeight);
      // console.log(startHeight);

      const bulkMissedStats = MissedBlocksStats.rawCollection().initializeUnorderedBulkOp();

      for (i in validators) {
        // if ((validators[i].address == "B8552EAC0D123A6BF609123047A5181D45EE90B5") || (validators[i].address == "69D99B2C66043ACBEAA8447525C356AFC6408E0C") || (validators[i].address == "35AD7A2CD2FC71711A675830EC1158082273D457")){
        let voterAddress = validators[i].address;
        let missedRecords = ValidatorRecords.find({
          address: voterAddress,
          exists: false,
          $and: [{
            height: {
              $gt: startHeight
            }
          }, {
            height: {
              $lte: latestHeight
            }
          }]
        }).fetch();
        let counts = {}; // console.log("missedRecords to process: "+missedRecords.length);

        for (b in missedRecords) {
          let block = Blockscon.findOne({
            height: missedRecords[b].height
          });
          let existingRecord = MissedBlocksStats.findOne({
            voter: voterAddress,
            proposer: block.proposerAddress
          });

          if (typeof counts[block.proposerAddress] === 'undefined') {
            if (existingRecord) {
              counts[block.proposerAddress] = existingRecord.count + 1;
            } else {
              counts[block.proposerAddress] = 1;
            }
          } else {
            counts[block.proposerAddress]++;
          }
        }

        for (address in counts) {
          let data = {
            voter: voterAddress,
            proposer: address,
            count: counts[address]
          };
          bulkMissedStats.find({
            voter: voterAddress,
            proposer: address
          }).upsert().updateOne({
            $set: data
          });
        } // }

      }

      if (bulkMissedStats.length > 0) {
        bulkMissedStats.execute(Meteor.bindEnvironment((err, result) => {
          if (err) {
            COUNTMISSEDBLOCKSSTATS = false;
            console.log(err);
          }

          if (result) {
            Status.upsert({
              chainId: Meteor.settings.public.chainId
            }, {
              $set: {
                lastMissedBlockHeight: latestHeight,
                lastMissedBlockTime: new Date()
              }
            });
            COUNTMISSEDBLOCKSSTATS = false;
            console.log("done");
          }
        }));
      } else {
        COUNTMISSEDBLOCKSSTATS = false;
      }

      return true;
    } else {
      return "updating...";
    }
  },
  'Analytics.aggregateBlockTimeAndVotingPower': function (time) {
    this.unblock();
    let now = new Date();

    if (time == 'm') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastMinuteVotingPower: averageVotingPower,
            lastMinuteBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    }

    if (time == 'h') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 60 * 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastHourVotingPower: averageVotingPower,
            lastHourBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    }

    if (time == 'd') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastDayVotingPower: averageVotingPower,
            lastDayBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    } // return analytics.length;

  },
  'Analytics.aggregateValidatorDailyBlockTime': function () {
    this.unblock();
    let validators = Validators.find({}).fetch();
    let now = new Date();

    for (i in validators) {
      let averageBlockTime = 0;
      let blocks = Blockscon.find({
        proposerAddress: validators[i].address,
        "time": {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }, {
        fields: {
          height: 1
        }
      }).fetch();

      if (blocks.length > 0) {
        let blockHeights = [];

        for (b in blocks) {
          blockHeights.push(blocks[b].height);
        }

        let analytics = Analytics.find({
          height: {
            $in: blockHeights
          }
        }, {
          fields: {
            height: 1,
            timeDiff: 1
          }
        }).fetch();

        for (a in analytics) {
          averageBlockTime += analytics[a].timeDiff;
        }

        averageBlockTime = averageBlockTime / analytics.length;
      }

      AverageValidatorData.insert({
        proposerAddress: validators[i].address,
        averageBlockTime: averageBlockTime,
        type: 'ValidatorDailyAverageBlockTime',
        createdAt: now
      });
    }

    return true;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/server/publications.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatorRecords, Analytics, MissedBlocks, MissedBlocksStats, VPDistributions;
module.link("../records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  MissedBlocks(v) {
    MissedBlocks = v;
  },

  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  },

  VPDistributions(v) {
    VPDistributions = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
Meteor.publish('validator_records.all', function () {
  return ValidatorRecords.find();
});
Meteor.publish('validator_records.uptime', function (address, num) {
  return ValidatorRecords.find({
    address: address
  }, {
    limit: num,
    sort: {
      height: -1
    }
  });
});
Meteor.publish('analytics.history', function () {
  return Analytics.find({}, {
    sort: {
      height: -1
    },
    limit: 50
  });
});
Meteor.publish('vpDistribution.latest', function () {
  return VPDistributions.find({}, {
    sort: {
      height: -1
    },
    limit: 1
  });
});
publishComposite('missedblocks.validator', function (address, type) {
  let conditions = {};

  if (type == 'voter') {
    conditions = {
      voter: address
    };
  } else {
    conditions = {
      proposer: address
    };
  }

  return {
    find() {
      return MissedBlocksStats.find(conditions);
    },

    children: [{
      find(stats) {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            profile_url: 1
          }
        });
      }

    }]
  };
});
publishComposite('missedrecords.validator', function (address, type) {
  return {
    find() {
      return MissedBlocks.find({
        [type]: address
      }, {
        sort: {
          updatedAt: -1
        }
      });
    },

    children: [{
      find() {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            operator_address: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"records.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/records.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  ValidatorRecords: () => ValidatorRecords,
  Analytics: () => Analytics,
  MissedBlocksStats: () => MissedBlocksStats,
  MissedBlocks: () => MissedBlocks,
  VPDistributions: () => VPDistributions,
  AverageData: () => AverageData,
  AverageValidatorData: () => AverageValidatorData
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const ValidatorRecords = new Mongo.Collection('validator_records');
const Analytics = new Mongo.Collection('analytics');
const MissedBlocksStats = new Mongo.Collection('missed_blocks_stats');
const MissedBlocks = new Mongo.Collection('missed_blocks');
const VPDistributions = new Mongo.Collection('voting_power_distributions');
const AverageData = new Mongo.Collection('average_data');
const AverageValidatorData = new Mongo.Collection('average_validator_data');
MissedBlocksStats.helpers({
  proposerMoniker() {
    let validator = Validators.findOne({
      address: this.proposer
    });
    return validator.description ? validator.description.moniker : this.proposer;
  },

  voterMoniker() {
    let validator = Validators.findOne({
      address: this.voter
    });
    return validator.description ? validator.description.moniker : this.voter;
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"status":{"server":{"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/status/server/publications.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Status;
module.link("../status.js", {
  Status(v) {
    Status = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
Meteor.publish('status.status', function () {
  return Status.find({
    chainId: Meteor.settings.public.chainId
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"status.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/status/status.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Status: () => Status
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Status = new Mongo.Collection('status');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactions":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/server/methods.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 4);
const AddressLength = 40;
Meteor.methods({
  'Transactions.index': function (hash, blockTime) {
    this.unblock();
    hash = hash.toUpperCase();
    let url = LCD + '/txs/' + hash;
    let response = HTTP.get(url);
    let tx = JSON.parse(response.content);
    console.log(hash);
    tx.height = parseInt(tx.height); // if (!tx.code){
    //     let msg = tx.tx.value.msg;
    //     for (let m in msg){
    //         if (msg[m].type == "cosmos-sdk/MsgCreateValidator"){
    //             console.log(msg[m].value);
    //             let command = Meteor.settings.bin.gaiadebug+" pubkey "+msg[m].value.pubkey;
    //             let validator = {
    //                 consensus_pubkey: msg[m].value.pubkey,
    //                 description: msg[m].value.description,
    //                 commission: msg[m].value.commission,
    //                 min_self_delegation: msg[m].value.min_self_delegation,
    //                 operator_address: msg[m].value.validator_address,
    //                 delegator_address: msg[m].value.delegator_address,
    //                 voting_power: Math.floor(parseInt(msg[m].value.value.amount) / 1000000)
    //             }
    //             Meteor.call('runCode', command, function(error, result){
    //                 validator.address = result.match(/\s[0-9A-F]{40}$/igm);
    //                 validator.address = validator.address[0].trim();
    //                 validator.hex = result.match(/\s[0-9A-F]{64}$/igm);
    //                 validator.hex = validator.hex[0].trim();
    //                 validator.pub_key = result.match(/{".*"}/igm);
    //                 validator.pub_key = JSON.parse(validator.pub_key[0].trim());
    //                 let re = new RegExp(Meteor.settings.public.bech32PrefixAccPub+".*$","igm");
    //                 validator.cosmosaccpub = result.match(re);
    //                 validator.cosmosaccpub = validator.cosmosaccpub[0].trim();
    //                 re = new RegExp(Meteor.settings.public.bech32PrefixValPub+".*$","igm");
    //                 validator.operator_pubkey = result.match(re);
    //                 validator.operator_pubkey = validator.operator_pubkey[0].trim();
    //                 Validators.upsert({consensus_pubkey:msg[m].value.pubkey},validator);
    //                 VotingPowerHistory.insert({
    //                     address: validator.address,
    //                     prev_voting_power: 0,
    //                     voting_power: validator.voting_power,
    //                     type: 'add',
    //                     height: tx.height+2,
    //                     block_time: blockTime
    //                 });
    //             })
    //         }
    //     }
    // }

    let txId = Transactions.insert(tx);

    if (txId) {
      return txId;
    } else return false;
  },
  'Transactions.findDelegation': function (address, height) {
    // following cosmos-sdk/x/slashing/spec/06_events.md and cosmos-sdk/x/staking/spec/06_events.md
    return Transactions.find({
      $or: [{
        $and: [{
          "events.type": "delegate"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.attributes.key": "action"
        }, {
          "events.attributes.value": "unjail"
        }, {
          "events.attributes.key": "sender"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "create_validator"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "unbond"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "redelegate"
        }, {
          "events.attributes.key": "destination_validator"
        }, {
          "events.attributes.value": address
        }]
      }],
      "code": {
        $exists: false
      },
      height: {
        $lt: height
      }
    }, {
      sort: {
        height: -1
      },
      limit: 1
    }).fetch();
  },
  'Transactions.findUser': function (address) {
    let fields = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    // address is either delegator address or validator operator address
    let validator;
    if (!fields) fields = {
      address: 1,
      description: 1,
      operator_address: 1,
      delegator_address: 1
    };

    if (address.includes(Meteor.settings.public.bech32PrefixValAddr)) {
      // validator operator address
      validator = Validators.findOne({
        operator_address: address
      }, {
        fields
      });
    } else if (address.includes(Meteor.settings.public.bech32PrefixAccAddr)) {
      // delegator address
      validator = Validators.findOne({
        delegator_address: address
      }, {
        fields
      });
    } else if (address.length === AddressLength) {
      validator = Validators.findOne({
        address: address
      }, {
        fields
      });
    }

    if (validator) {
      return validator;
    }

    return false;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/server/publications.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Transactions;
module.link("../transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 1);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 2);
publishComposite('transactions.list', function () {
  let limit = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 30;
  return {
    find() {
      return Transactions.find({}, {
        sort: {
          height: -1
        },
        limit: limit
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.validator', function (validatorAddress, delegatorAddress) {
  let limit = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 100;
  let query = {};

  if (validatorAddress && delegatorAddress) {
    query = {
      $or: [{
        "events.attributes.value": validatorAddress
      }, {
        "events.attributes.value": delegatorAddress
      }]
    };
  }

  if (!validatorAddress && delegatorAddress) {
    query = {
      "events.attributes.value": delegatorAddress
    };
  }

  return {
    find() {
      return Transactions.find(query, {
        sort: {
          height: -1
        },
        limit: limit
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.findOne', function (hash) {
  return {
    find() {
      return Transactions.find({
        txhash: hash
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.height', function (height) {
  return {
    find() {
      return Transactions.find({
        height: height
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactions.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/transactions.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Transactions: () => Transactions
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Blockscon;
module.link("../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 1);
let TxIcon;
module.link("../../ui/components/Icons.jsx", {
  TxIcon(v) {
    TxIcon = v;
  }

}, 2);
const Transactions = new Mongo.Collection('transactions');
Transactions.helpers({
  block() {
    return Blockscon.findOne({
      height: this.height
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validators":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 1);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 2);
let Delegations;
module.link("../../delegations/delegations.js", {
  Delegations(v) {
    Delegations = v;
  }

}, 3);
Meteor.methods({
  'Validators.findCreateValidatorTime': function (address) {
    // look up the create validator time to consider if the validator has never updated the commission
    let tx = Transactions.findOne({
      $and: [{
        "tx.value.msg.value.delegator_address": address
      }, {
        "tx.value.msg.type": "cosmos-sdk/MsgCreateValidator"
      }, {
        code: {
          $exists: false
        }
      }]
    });

    if (tx) {
      let block = Blockscon.findOne({
        height: tx.height
      });

      if (block) {
        return block.time;
      }
    } else {
      // no such create validator tx
      return false;
    }
  },

  // async 'Validators.getAllDelegations'(address){
  'Validators.getAllDelegations'(address) {
    let url = LCD + '/staking/validators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        delegations = JSON.parse(delegations.content).result;
        delegations.forEach((delegation, i) => {
          if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
        });
        return delegations;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/server/publications.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Validators;
module.link("../validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
let ValidatorRecords;
module.link("../../records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  }

}, 2);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 3);
Meteor.publish('validators.all', function () {
  let sort = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "description.moniker";
  let direction = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : -1;
  let fields = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return Validators.find({}, {
    sort: {
      [sort]: direction
    },
    fields: fields
  });
});
publishComposite('validators.firstSeen', {
  find() {
    return Validators.find({});
  },

  children: [{
    find(val) {
      return ValidatorRecords.find({
        address: val.address
      }, {
        sort: {
          height: 1
        },
        limit: 1
      });
    }

  }]
});
Meteor.publish('validators.voting_power', function () {
  return Validators.find({
    status: 2,
    jailed: false
  }, {
    sort: {
      voting_power: -1
    },
    fields: {
      address: 1,
      description: 1,
      voting_power: 1,
      profile_url: 1
    }
  });
});
publishComposite('validator.details', function (address) {
  let options = {
    address: address
  };

  if (address.indexOf(Meteor.settings.public.bech32PrefixValAddr) != -1) {
    options = {
      operator_address: address
    };
  }

  return {
    find() {
      return Validators.find(options);
    },

    children: [{
      find(val) {
        return VotingPowerHistory.find({
          address: val.address
        }, {
          sort: {
            height: -1
          },
          limit: 50
        });
      }

    }, {
      find(val) {
        return ValidatorRecords.find({
          address: val.address
        }, {
          sort: {
            height: -1
          },
          limit: Meteor.settings.public.uptimeWindow
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validators.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/validators.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Validators: () => Validators
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let ValidatorRecords;
module.link("../records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  }

}, 1);
let VotingPowerHistory;
module.link("../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 2);
const Validators = new Mongo.Collection('validators');
Validators.helpers({
  firstSeen() {
    return ValidatorRecords.findOne({
      address: this.address
    });
  },

  history() {
    return VotingPowerHistory.find({
      address: this.address
    }, {
      sort: {
        height: -1
      },
      limit: 50
    }).fetch();
  }

}); // Validators.helpers({
//     uptime(){
//         // console.log(this.address);
//         let lastHundred = ValidatorRecords.find({address:this.address}, {sort:{height:-1}, limit:100}).fetch();
//         console.log(lastHundred);
//         let uptime = 0;
//         for (i in lastHundred){
//             if (lastHundred[i].exists){
//                 uptime+=1;
//             }
//         }
//         return uptime;
//     }
// })
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"voting-power":{"server":{"publications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/voting-power/server/publications.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"history.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/voting-power/history.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  VotingPowerHistory: () => VotingPowerHistory
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const VotingPowerHistory = new Mongo.Collection('voting_power_history');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"evidences":{"evidences.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/evidences/evidences.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Evidences: () => Evidences
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Evidences = new Mongo.Collection('evidences');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validator-sets":{"validator-sets.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validator-sets/validator-sets.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  ValidatorSets: () => ValidatorSets
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const ValidatorSets = new Mongo.Collection('validator_sets');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"startup":{"both":{"index.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/both/index.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Import modules used by both client and server through a single index entry point
// e.g. useraccounts configuration file.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"create-indexes.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/create-indexes.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Blockscon;
module.link("../../api/blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 0);
let ValidatorRecords, Analytics, MissedBlocksStats, MissedBlocks, AverageData, AverageValidatorData;
module.link("../../api/records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  },

  MissedBlocks(v) {
    MissedBlocks = v;
  },

  AverageData(v) {
    AverageData = v;
  },

  AverageValidatorData(v) {
    AverageValidatorData = v;
  }

}, 1);
let Transactions;
module.link("../../api/transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 2);
let ValidatorSets;
module.link("../../api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 3);
let Validators;
module.link("../../api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 4);
let VotingPowerHistory;
module.link("../../api/voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 5);
let Evidences;
module.link("../../api/evidences/evidences.js", {
  Evidences(v) {
    Evidences = v;
  }

}, 6);
let CoinStats;
module.link("../../api/coin-stats/coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 7);
let ChainStates;
module.link("../../api/chain/chain.js", {
  ChainStates(v) {
    ChainStates = v;
  }

}, 8);
ChainStates.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
Blockscon.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
Blockscon.rawCollection().createIndex({
  proposerAddress: 1
});
Evidences.rawCollection().createIndex({
  height: -1
}); //Proposals.rawCollection().createIndex({proposalId: 1}, {unique:true});

ValidatorRecords.rawCollection().createIndex({
  address: 1,
  height: -1
}, {
  unique: 1
});
ValidatorRecords.rawCollection().createIndex({
  address: 1,
  exists: 1,
  height: -1
});
Analytics.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
MissedBlocks.rawCollection().createIndex({
  proposer: 1,
  voter: 1,
  updatedAt: -1
});
MissedBlocks.rawCollection().createIndex({
  proposer: 1,
  blockHeight: -1
});
MissedBlocks.rawCollection().createIndex({
  voter: 1,
  blockHeight: -1
});
MissedBlocks.rawCollection().createIndex({
  voter: 1,
  proposer: 1,
  blockHeight: -1
}, {
  unique: true
});
MissedBlocksStats.rawCollection().createIndex({
  proposer: 1
});
MissedBlocksStats.rawCollection().createIndex({
  voter: 1
});
MissedBlocksStats.rawCollection().createIndex({
  proposer: 1,
  voter: 1
}, {
  unique: true
});
AverageData.rawCollection().createIndex({
  type: 1,
  createdAt: -1
}, {
  unique: true
});
AverageValidatorData.rawCollection().createIndex({
  proposerAddress: 1,
  createdAt: -1
}, {
  unique: true
}); // Status.rawCollection.createIndex({})

Transactions.rawCollection().createIndex({
  txhash: 1
}, {
  unique: true
});
Transactions.rawCollection().createIndex({
  height: -1
}); // Transactions.rawCollection().createIndex({action:1});

Transactions.rawCollection().createIndex({
  "events.attributes.key": 1
});
Transactions.rawCollection().createIndex({
  "events.attributes.value": 1
});
ValidatorSets.rawCollection().createIndex({
  block_height: -1
});
Validators.rawCollection().createIndex({
  address: 1
}, {
  unique: true,
  partialFilterExpression: {
    address: {
      $exists: true
    }
  }
});
Validators.rawCollection().createIndex({
  consensus_pubkey: 1
}, {
  unique: true
});
Validators.rawCollection().createIndex({
  "pub_key.value": 1
}, {
  unique: true,
  partialFilterExpression: {
    "pub_key.value": {
      $exists: true
    }
  }
});
VotingPowerHistory.rawCollection().createIndex({
  address: 1,
  height: -1
});
VotingPowerHistory.rawCollection().createIndex({
  type: 1
});
CoinStats.rawCollection().createIndex({
  last_updated_at: -1
}, {
  unique: true
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/index.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("./util.js");
module.link("./register-api.js");
module.link("./create-indexes.js");
let onPageLoad;
module.link("meteor/server-render", {
  onPageLoad(v) {
    onPageLoad = v;
  }

}, 0);
let Helmet;
module.link("react-helmet", {
  Helmet(v) {
    Helmet = v;
  }

}, 1);
// import App from '../../ui/App.jsx';
onPageLoad(sink => {
  // const context = {};
  // const sheet = new ServerStyleSheet()
  // const html = renderToString(sheet.collectStyles(
  //     <StaticRouter location={sink.request.url} context={context}>
  //         <App />
  //     </StaticRouter>
  //   ));
  // sink.renderIntoElementById('app', html);
  const helmet = Helmet.renderStatic();
  sink.appendToHead(helmet.meta.toString());
  sink.appendToHead(helmet.title.toString()); // sink.appendToHead(sheet.getStyleTags());
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"register-api.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/register-api.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("../../api/ledger/server/methods.js");
module.link("../../api/chain/server/methods.js");
module.link("../../api/chain/server/publications.js");
module.link("../../api/blocks/server/methods.js");
module.link("../../api/blocks/server/publications.js");
module.link("../../api/validators/server/methods.js");
module.link("../../api/validators/server/publications.js");
module.link("../../api/records/server/methods.js");
module.link("../../api/records/server/publications.js");
module.link("../../api/enterprise/server/methods.js");
module.link("../../api/enterprise/server/publications.js");
module.link("../../api/voting-power/server/publications.js");
module.link("../../api/transactions/server/methods.js");
module.link("../../api/transactions/server/publications.js");
module.link("../../api/delegations/server/methods.js");
module.link("../../api/delegations/server/publications.js");
module.link("../../api/status/server/publications.js");
module.link("../../api/accounts/server/methods.js");
module.link("../../api/coin-stats/server/methods.js");
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"util.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/util.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let bech32;
module.link("bech32", {
  default(v) {
    bech32 = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let cheerio;
module.link("cheerio", {
  "*"(v) {
    cheerio = v;
  }

}, 2);

// Load future from fibers
var Future = Npm.require("fibers/future"); // Load exec


var exec = Npm.require("child_process").exec;

function toHexString(byteArray) {
  return byteArray.map(function (byte) {
    return ('0' + (byte & 0xFF).toString(16)).slice(-2);
  }).join('');
}

Meteor.methods({
  pubkeyToBech32: function (pubkey, prefix) {
    // '1624DE6420' is ed25519 pubkey prefix
    let pubkeyAminoPrefix = Buffer.from('1624DE6420', 'hex');
    let buffer = Buffer.alloc(37);
    pubkeyAminoPrefix.copy(buffer, 0);
    Buffer.from(pubkey.value, 'base64').copy(buffer, pubkeyAminoPrefix.length);
    return bech32.encode(prefix, bech32.toWords(buffer));
  },
  bech32ToPubkey: function (pubkey) {
    // '1624DE6420' is ed25519 pubkey prefix
    let pubkeyAminoPrefix = Buffer.from('1624DE6420', 'hex');
    let buffer = Buffer.from(bech32.fromWords(bech32.decode(pubkey).words));
    return buffer.slice(pubkeyAminoPrefix.length).toString('base64');
  },
  getDelegator: function (operatorAddr) {
    let address = bech32.decode(operatorAddr);
    return bech32.encode(Meteor.settings.public.bech32PrefixAccAddr, address.words);
  },
  getKeybaseTeamPic: function (keybaseUrl) {
    let teamPage = HTTP.get(keybaseUrl);

    if (teamPage.statusCode == 200) {
      let page = cheerio.load(teamPage.content);
      return page(".kb-main-card img").attr('src');
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"ui":{"components":{"Icons.jsx":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/ui/components/Icons.jsx                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  DenomSymbol: () => DenomSymbol,
  ProposalStatusIcon: () => ProposalStatusIcon,
  VoteIcon: () => VoteIcon,
  TxIcon: () => TxIcon,
  InfoIcon: () => InfoIcon
});
let React;
module.link("react", {
  default(v) {
    React = v;
  }

}, 0);
let UncontrolledTooltip;
module.link("reactstrap", {
  UncontrolledTooltip(v) {
    UncontrolledTooltip = v;
  }

}, 1);

const DenomSymbol = props => {
  switch (props.denom) {
    case "steak":
      return '🥩';

    default:
      return '🍅';
  }
};

const ProposalStatusIcon = props => {
  switch (props.status) {
    case 'Passed':
      return React.createElement("i", {
        className: "fas fa-check-circle text-success"
      });

    case 'Rejected':
      return React.createElement("i", {
        className: "fas fa-times-circle text-danger"
      });

    case 'Removed':
      return React.createElement("i", {
        className: "fas fa-trash-alt text-dark"
      });

    case 'DepositPeriod':
      return React.createElement("i", {
        className: "fas fa-battery-half text-warning"
      });

    case 'VotingPeriod':
      return React.createElement("i", {
        className: "fas fa-hand-paper text-info"
      });

    default:
      return React.createElement("i", null);
  }
};

const VoteIcon = props => {
  switch (props.vote) {
    case 'yes':
      return React.createElement("i", {
        className: "fas fa-check text-success"
      });

    case 'no':
      return React.createElement("i", {
        className: "fas fa-times text-danger"
      });

    case 'abstain':
      return React.createElement("i", {
        className: "fas fa-user-slash text-warning"
      });

    case 'no_with_veto':
      return React.createElement("i", {
        className: "fas fa-exclamation-triangle text-info"
      });

    default:
      return React.createElement("i", null);
  }
};

const TxIcon = props => {
  if (props.valid) {
    return React.createElement("span", {
      className: "text-success text-nowrap"
    }, React.createElement("i", {
      className: "fas fa-check-circle"
    }));
  } else {
    return React.createElement("span", {
      className: "text-danger text-nowrap"
    }, React.createElement("i", {
      className: "fas fa-times-circle"
    }));
  }
};

class InfoIcon extends React.Component {
  constructor(props) {
    super(props);
    this.ref = React.createRef();
  }

  render() {
    return [React.createElement("i", {
      key: "icon",
      className: "material-icons info-icon",
      ref: this.ref
    }, "info"), React.createElement(UncontrolledTooltip, {
      key: "tooltip",
      placement: "right",
      target: this.ref
    }, this.props.children ? this.props.children : this.props.tooltipText)];
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"both":{"i18n":{"en-us.i18n.yml.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/en-us.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('en-US','',{"common":{"height":"Height","voter":"Voter","votingPower":"Voting Power","addresses":"Addresses","amounts":"Amounts","delegators":"delegators","block":"block","blocks":"blocks","precommit":"precommit","precommits":"precommits","last":"last","backToList":"Back to List","information":"Information","time":"Time","hash":"Hash","more":"More","fullStop":".","searchPlaceholder":"Search with tx hash / block height / address","cancel":"Cancel","retry":"Retry"},"navbar":{"siteName":"Unification Mainchain","version":"beta","validators":"Validators","blocks":"Blocks","transactions":"Transactions","proposals":"Proposals","votingPower":"Voting Power","lang":"ENG","english":"English","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"Fork me!"},"consensus":{"consensusState":"Consensus State","round":"Round","step":"Step"},"chainStates":{"price":"Price","marketCap":"Market Cap","inflation":"Inflation","communityPool":"Community Pool"},"chainStatus":{"startMessage":"The chain is going to start in","stopWarning":"The chain appears to be stopped for <em>{$time}</em>! Feed me with new blocks 😭!","latestHeight":"Latest Block Height","averageBlockTime":"Average Block Time","all":"All","now":"Now","allTime":"All Time","lastMinute":"Last Minute","lastHour":"Last Hour","lastDay":"Last Day","seconds":"seconds","activeValidators":"Active Validators","outOfValidators":"out of {$totalValidators} validators","onlineVotingPower":"Online Voting Power","fromTotalStakes":"{$percent} from {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"Block Time History","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"Random Validators","moniker":"Moniker","uptime":"Uptime","selfPercentage":"Self%","commission":"Commission","lastSeen":"Last Seen","status":"Status","jailed":"Jailed","navActive":"Active","navInactive":"Inactive","active":"Active Validators","inactive":"Inactive Validators","listOfActive":"Here is a list of active validators.","listOfInactive":"Here is a list of inactive validators.","validatorDetails":"Validator Details","lastNumBlocks":"Last {$numBlocks} blocks","validatorInfo":"Validator Info","operatorAddress":"Operator Address","selfDelegationAddress":"Self-Delegate Address","commissionRate":"Commission Rate","maxRate":"Max Rate","maxChangeRate":"Max Change Rate","selfDelegationRatio":"Self Delegation Ratio","proposerPriority":"Proposer Priority","delegatorShares":"Delegator Shares","userDelegateShares":"Shares Delegated by you","tokens":"Tokens","unbondingHeight":"Unbonding Height","unbondingTime":"Unbonding Time","powerChange":"Power Change","delegations":"Delegations","transactions":"Transactions","validatorNotExists":"Validator does not exist.","backToValidator":"Back to Validator","missedBlocks":"Missed Blocks","missedPrecommits":"Missed Precommits","missedBlocksTitle":"Missed blocks of {$moniker}","totalMissed":"Total missed","block":"Block","missedCount":"Miss Count","iDontMiss":"I do not miss ","lastSyncTime":"Last sync time","delegator":"Delegator","amount":"Amount"},"blocks":{"block":"Block","proposer":"Proposer","latestBlocks":"Latest blocks","noBlock":"No block.","numOfTxs":"No. of Txs","numOfTransactions":"No. of Transactions","notFound":"No such block found."},"transactions":{"transaction":"Transaction","transactions":"Transactions","notFound":"No transaction found.","activities":"Activities","txHash":"Tx Hash","valid":"Valid","fee":"Fee","gasUsedWanted":"Gas (used / wanted)","noTxFound":"No such transaction found.","noValidatorTxsFound":"No transaction related to this validator was found.","memo":"Memo","transfer":"Transfer","staking":"Staking","distribution":"Distribution","governance":"Governance","slashing":"Slashing","enterprise":"Enterprise","wrkchain":"WRKChain","beacon":"BEACON"},"proposals":{"notFound":"No proposal found.","listOfProposals":"Here is a list of governance proposals.","proposer":"Proposer","proposal":"proposal","proposals":"Proposals","proposalID":"Proposal ID","title":"Title","status":"Status","submitTime":"Submit Time","depositEndTime":"Deposit End Time","votingStartTime":"Voting Start Time","votingEndTime":"End Voting Time","totalDeposit":"Total Deposit","description":"Description","proposalType":"Proposal Type","proposalStatus":"Proposal Status","notStarted":"not started","final":"final","deposit":"Deposit","tallyResult":"Tally Result","yes":"Yes","abstain":"Abstain","no":"No","noWithVeto":"No with Veto","percentageVoted":"<span class=\"text-info\">{$percent}</span> of online voting power has been voted.","validMessage":"This proposal is {$tentative}<strong>valid</strong>.","invalidMessage":"Less than {$quorum} of voting power is voted. This proposal is <strong>invalid</strong>.","moreVoteMessage":"It will be a valid proposal once <span class=\"text-info\">{$moreVotes}</span> more votes are casted."},"votingPower":{"distribution":"Voting Power Distribution","pareto":"Pareto Principle (20/80 rule)","minValidators34":"Min no. of validators hold 34%+ power"},"accounts":{"accountDetails":"Account Details","available":"Available","delegated":"Delegated","unbonding":"Unbonding","rewards":"Rewards","total":"Total","notFound":"This account does not exist. Are you looking for a wrong address?","validators":"Validators","shares":"Shares","mature":"Mature","no":"No ","delegation":"Delegation","plural":"s","signOut":"Sign out","signInText":"You are signed in as ","toLoginAs":"To log in as","signInWithLedger":"Sign In With Ledger","signInWarning":"Please make sure your Ledger device is connected and <strong class=\"text-primary\">Cosmos App 1.5.0 or above</strong> is opened.","pleaseAccept":"please accept in your Ledger device."},"activities":{"single":"A","happened":"happened.","senders":"The following sender(s)","sent":"sent","receivers":"to the following receipient(s)","received":"received","failedTo":"failed to ","to":"to","from":"from","operatingAt":"operating at","withMoniker":"with moniker","withTitle":"with title","withA":"with a","purchased":"purchased","decision":"decision"},"messageTypes":{"send":"Send","multiSend":"Multi Send","createValidator":"Create Validator","editValidator":"Edit Validator","delegate":"Delegate","undelegate":"Undelegate","redelegate":"Redelegate","submitProposal":"Submit Proposal","deposit":"Deposit","vote":"Vote","withdrawComission":"Withdraw Commission","withdrawReward":"Withdraw Reward","modifyWithdrawAddress":"Modify Withdraw Address","unjail":"Unjail","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive","enterprisePurchase":"Purchase Enterprise UND","enterpriseProcess":"Process Enterprise Purchase Order","wrkchainRegister":"Register WRKChain","wrkchainRecord":"Record WRKChain Hashes","beaconRegister":"Register BEACON","beaconRecord":"Record BEACON Timestamp"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"zh-hans.i18n.yml.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/zh-hans.i18n.yml.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('zh-Hans','',{"common":{"height":"高度","voter":"投票人","votingPower":"投票权","addresses":"地址","amounts":"数量","delegators":"委托人","block":"区块","blocks":"区块","precommit":"建块前保证","precommits":"建块前保证","last":"最后","backToList":"回到列表","information":"资讯","time":"时间","hash":"哈希","more":"更多","fullStop":"。","searchPlaceholder":"搜寻交易哈希 / 区块高度 / 地址","cancel":"取消","retry":"重试"},"navbar":{"siteName":"北斗","version":"beta","validators":"验证人","blocks":"区块","transactions":"交易","proposals":"治理提案","votingPower":"投票权分布","lang":"中文（简）","english":"English","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"Fork me!"},"consensus":{"consensusState":"共识状态","round":"轮数","step":"阶数"},"chainStates":{"price":"价格","marketCap":"市值","inflation":"通胀率","communityPool":"社区储备"},"chainStatus":{"startMessage":"这链将还有以下时间便会开始","stopWarning":"这链似乎已经停了 <em>{$time}</em>！ 请继续喂我吃新的区块 😭!","latestHeight":"最新区块高度","averageBlockTime":"平均区块时间","all":"全部","now":"现在","allTime":"全部","lastMinute":"前一分钟","lastHour":"前一小时","lastDay":"前一天","seconds":"秒","activeValidators":"有效验证人","outOfValidators":"来自总共 {$totalValidators} 个验证人","onlineVotingPower":"在线投票权","fromTotalStakes":"为 {$totalStakes} 颗 {$denom} 的 {$percent}"},"analytics":{"blockTimeHistory":"在线投票权","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"随机验证人","moniker":"验证人代号","uptime":"上线时间比重","selfPercentage":"自我委托%","commission":"佣金","lastSeen":"最后投票时间","status":"状态","jailed":"被禁制","navActive":"有效","navInactive":"无效","active":"有效验证人","inactive":"无效验证人","listOfActive":"这名单显示所有有效验证人","listOfInactive":"这名单显示所有无效验证人","validatorDetails":"验证人详情","lastNumBlocks":"最后 {$numBlocks} 个区块","validatorInfo":"验证人资讯","operatorAddress":"操作地址","selfDelegationAddress":"自我委托地址","commissionRate":"佣金","maxRate":"最大佣金限制","maxChangeRate":"每天最大佣金变化限制","selfDelegationRatio":"自我委托比例","proposerPriority":"建块优先权","delegatorShares":"委托股数","userDelegateShares":"你委托的股数","tokens":"代币数量","unbondingHeight":"解绑高度","unbondingTime":"解绑时间","powerChange":"投票权变更","delegations":"委托","transactions":"交易","validatorNotExists":"验证人不存在。","backToValidator":"回到验证人页面","missedBlocks":"错过了的区块","missedPrecommits":"遗留了的建块前保证","missedBlocksTitle":"错过了 {$moniker} 的区块","totalMissed":"一共错过了","block":"区块","missedCount":"错过数量","iDontMiss":"我不会错过任何一个","lastSyncTime":"上一次同步时间","delegator":"委托人","amount":"数量"},"blocks":{"proposer":"建块人","block":"区块","latestBlocks":"最近区块","noBlock":"没有区块。","numOfTxs":"交易数量","numOfTransactions":"交易数量","notFound":"没有这个区块。"},"transactions":{"transaction":"交易","transactions":"交易","notFound":"沒有交易。","activities":"活动","txHash":"交易哈希","valid":"有效","fee":"费用","gasUsedWanted":"瓦斯 (已用 / 要求)","noTxFound":"没有这笔交易。","noValidatorTxsFound":"没有跟这个验证人有关的交易","memo":"备忘录","transfer":"代币转移","staking":"委托","distribution":"收益分配","governance":"链上治理","slashing":"削减","enterprise":"企业","wrkchain":"WRKChain","beacon":"BEACON"},"proposals":{"notFound":"没有治理提案","listOfProposals":"这名单显示所有治理提案","proposer":"提案人","proposal":"治理提案","proposals":"治理提案","proposalID":"提案编号","title":"主题","status":"状态","submitTime":"提案时间","depositEndTime":"存入押金","votingStartTime":"投票开始时间","votingEndTime":"投票结束时间","totalDeposit":"押金总额","description":"详细内容","proposalType":"提案类型","proposalStatus":"提案状态","notStarted":"未开始","final":"最后结果","deposit":"押金","tallyResult":"投票结果","yes":"赞成","abstain":"弃权","no":"反对","noWithVeto":"强烈反对","percentageVoted":"现时在线投票权的投票率是 <span class=\"text-info\">{$percent}</span>。","validMessage":"这个提案 {$tentative} <strong>有效</strong>.","invalidMessage":"已投票的在线投票权少于 {$quorum}。这个提案 <strong>無效</strong>。","moreVoteMessage":"当再有多 <span class=\"text-info\">{$moreVotes}</span> 投票权投了票的话，这个提案将会有效。"},"votingPower":{"distribution":"投票权分布","pareto":"帕累托原则 (20/80 定率)","minValidators34":"最少合共有超过 34% 投票权的验证人"},"accounts":{"accountDetails":"帐户详情","available":"可用的","delegated":"委托中","unbonding":"解绑中","rewards":"未取回收益","total":"总共","notFound":"这个帐户不存在。你是否在查看一个错误的地址？","validators":"验证人","shares":"股数","mature":"成熟日期","no":"没有","delegation":"委托","plural":"","signOut":"登出","signInText":"你已登录以下帐户","toLoginAs":"登录以下帐户","signInWithLedger":"透过 Ledger 登录","signInWarning":"请确定你已经连接 Ledger 设备，并已开启 <strong class=\"text-primary\">Cosmos App 版本 1.5.0 或以上</strong>。","pleaseAccept":"请从你的 Ledger 设备确认。"},"activities":{"single":"一个","happened":"发生了","senders":"以下的帐户","sent":"发了","receivers":"到以下的帐户","received":"收到","failedTo":"未能","to":"到","from":"从","operatingAt":"操作地址为","withMoniker":"而验证人代号为","withTitle":"治理提案主题为","withA":"投了","purchased":"已购买","decision":"决定"},"messageTypes":{"send":"发送","multiSend":"多重发送","createValidator":"建立验证人","editValidator":"编辑验证人资料","delegate":"委托","undelegate":"解委托","redelegate":"转委托","submitProposal":"提交议案","deposit":"存入","vote":"投票","withdrawComission":"提取手续费","withdrawReward":"提取收益","modifyWithdrawAddress":"更改收益取回地址","unjail":"赦免","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive","enterprisePurchase":"Purchase Enterprise UND","enterpriseProcess":"Process Enterprise Purchase Order","wrkchainRegister":"Register WRKChain","wrkchainRecord":"Record WRKChain Hashes","beaconRegister":"Register BEACON","beaconRecord":"Record BEACON Timestamp"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"zh-hant.i18n.yml.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/zh-hant.i18n.yml.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('zh-Hant','',{"common":{"height":"高度","voter":"投票人","votingPower":"投票權","addresses":"地址","amounts":"數量","delegators":"委托人","block":"區塊","blocks":"區塊","precommit":"建塊前保證","precommits":"建塊前保證","last":"最後","backToList":"回到列表","information":"資訊","time":"時間","hash":"哈希","more":"更多","fullStop":"。","searchPlaceholder":"搜尋交易哈希 / 區塊高度 / 地址","cancel":"取消","retry":"重試"},"navbar":{"siteName":"北斗","version":"beta","validators":"驗證人","blocks":"區塊","transactions":"交易","proposals":"治理提案","votingPower":"投票權分佈","lang":"中文（繁）","english":"English","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"Fork me!"},"consensus":{"consensusState":"共識狀態","round":"輪數","step":"階數"},"chainStates":{"price":"價格","marketCap":"市值","inflation":"通漲率","communityPool":"社區儲備"},"chainStatus":{"startMessage":"這鏈將還有以下時間便會開始","stopWarning":"這鏈似乎已經停了 <em>{$time}</em>！ 請繼續餵我吃新的區塊 😭!","latestHeight":"最新區塊高度","averageBlockTime":"平均區塊時間","all":"全部","now":"現在","allTime":"全部","lastMinute":"前一分鐘","lastHour":"前一小時","lastDay":"前一天","seconds":"秒","activeValidators":"有效驗證人","outOfValidators":"來自總共 {$totalValidators} 個驗證人","onlineVotingPower":"在線投票權","fromTotalStakes":"為 {$totalStakes} 顆 {$denom} 的 {$percent}"},"analytics":{"blockTimeHistory":"在線投票權","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"隨機驗證人","moniker":"驗證人代號","uptime":"上線時間比重","selfPercentage":"自我委托%","commission":"佣金","lastSeen":"最後投票時間","status":"狀態","jailed":"被禁制","navActive":"有效","navInactive":"無效","active":"有效驗證人","inactive":"無效驗證人","listOfActive":"這名單顯示所有有效驗證人","listOfInactive":"這名單顯示所有無效驗證人","validatorDetails":"驗證人詳情","lastNumBlocks":"最後 {$numBlocks} 個區塊","validatorInfo":"驗證人資訊","operatorAddress":"操作地址","selfDelegationAddress":"自我委托地址","commissionRate":"佣金","maxRate":"最大佣金限制","maxChangeRate":"每天最大佣金變化限制","selfDelegationRatio":"自我委托比列","proposerPriority":"建塊優先權","delegatorShares":"委托股數","userDelegateShares":"你委托的股數","tokens":"代幣數量","unbondingHeight":"解綁高度","unbondingTime":"解綁時間","powerChange":"投票權變更","delegations":"委托","transactions":"交易","validatorNotExists":"驗證人不存在。","backToValidator":"回到驗證人頁面","missedBlocks":"錯過了的區塊","missedPrecommits":"遺留了的建塊前保證","missedBlocksTitle":"錯過了 {$moniker} 的區塊","totalMissed":"一共錯過了","block":"區塊","missedCount":"錯過數量","iDontMiss":"我不會錯過任何一個","lastSyncTime":"上一次同步時間","delegator":"委托人","amount":"數量"},"blocks":{"proposer":"建塊人","block":"區塊","latestBlocks":"最近區塊","noBlock":"沒有區塊。","numOfTxs":"交易數量","numOfTransactions":"交易數量","notFound":"沒有這個區塊。"},"transactions":{"transaction":"交易","transactions":"交易","notFound":"沒有交易。","activities":"活動","txHash":"交易哈希","valid":"有效","fee":"費用","gasUsedWanted":"瓦斯 (已用 / 要求)","noTxFound":"沒有這筆交易。","noValidatorTxsFound":"沒有跟這個驗證人有關的交易","memo":"備忘錄","transfer":"代幣轉移","staking":"委托","distribution":"收益分配","governance":"鏈上治理","slashing":"削減","enterprise":"企業","wrkchain":"WRKChain","beacon":"BEACON"},"proposals":{"notFound":"沒有治理提案","listOfProposals":"這名單顯示所有治理提案","proposer":"提案人","proposal":"治理提案","proposals":"治理提案","proposalID":"提案編號","title":"主題","status":"狀態","submitTime":"提案時間","depositEndTime":"存入押金","votingStartTime":"投票開始時間","votingEndTime":"投票結束時間","totalDeposit":"押金總額","description":"詳細內容","proposalType":"提案類型","proposalStatus":"提案狀態","notStarted":"未開始","final":"最後結果","deposit":"押金","tallyResult":"投票結果","yes":"贊成","abstain":"棄權","no":"反對","noWithVeto":"強烈反對","percentageVoted":"現時在線投票權的投票率是 <span class=\"text-info\">{$percent}</span>。","validMessage":"這個提案 {$tentative} <strong>有效</strong>.","invalidMessage":"已投票的在線投票權少於 {$quorum}。這個 <strong>無效</strong>。","moreVoteMessage":"當再有多 <span class=\"text-info\">{$moreVotes}</span> 投票權投了票的話，這個提案將會有效。"},"votingPower":{"distribution":"投票權分佈","pareto":"帕累托原則 (20/80 定率)","minValidators34":"最少合共有超過 34% 投票權的驗證人"},"accounts":{"accountDetails":"帳戶詳情","available":"可用的","delegated":"委托中","unbonding":"解綁中","rewards":"未取回收益","total":"總共","notFound":"這個帳戶不存在。你是否在查看一個錯誤的地址？","validators":"驗證人","shares":"股數","mature":"成熟日期","no":"沒有","delegation":"委托","plural":"","signOut":"登出","signInText":"你已登入以下帳戶","toLoginAs":"登入以下帳戶","signInWithLedger":"透過 Ledger 登入","signInWarning":"請確定你已經連接 Ledger 設備，並已開啓 <strong class=\"text-primary\">Cosmos App 版本 1.5.0 或以上</strong>。","pleaseAccept":"請從你的 Ledger 設備確認。"},"activities":{"single":"一個","happened":"發生了","senders":"以下的帳戶","sent":"發了","receivers":"到以下的帳戶","received":"收到","failedTo":"未能","to":"到","from":"從","operatingAt":"操作地止為","withMoniker":"而驗證人代號為","withTitle":"治理提案主題為","withA":"投了","purchased":"已購買","decision":"決定"},"messageTypes":{"send":"發送","multiSend":"多重發送","createValidator":"建立驗證人","editValidator":"編輯驗證人資料","delegate":"委托","undelegate":"解委托","redelegate":"轉委托","submitProposal":"提交議案","deposit":"存入","vote":"投票","withdrawComission":"提取手續費","withdrawReward":"提取收益","modifyWithdrawAddress":"更改收益取回地址","unjail":"赦免","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive","enterprisePurchase":"Purchase Enterprise UND","enterpriseProcess":"Process Enterprise Purchase Order","wrkchainRegister":"Register WRKChain","wrkchainRecord":"Record WRKChain Hashes","beaconRegister":"Register BEACON","beaconRecord":"Record BEACON Timestamp"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"utils":{"coins.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/utils/coins.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => Coin
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let numbro;
module.link("numbro", {
  default(v) {
    numbro = v;
  }

}, 1);

autoformat = value => {
  let formatter = '0,0.0000';
  value = Math.round(value * 1000) / 1000;
  if (Math.round(value) === value) formatter = '0,0';else if (Math.round(value * 10) === value * 10) formatter = '0,0.0';else if (Math.round(value * 100) === value * 100) formatter = '0,0.00';else if (Math.round(value * 1000) === value * 1000) formatter = '0,0.000';
  return numbro(value).format(formatter);
};

class Coin {
  constructor(amount) {
    let denom = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    if (typeof amount === 'object') ({
      amount,
      denom
    } = amount);

    if (!denom || denom.toLowerCase() === Coin.MintingDenom.toLowerCase()) {
      this._amount = Number(amount);
    } else if (denom.toLowerCase() === Coin.StakingDenom.toLowerCase()) {
      this._amount = Number(amount) * Coin.StakingFraction;
    } else {
      throw Error("unsupported denom ".concat(denom));
    }
  }

  get amount() {
    return this._amount;
  }

  get stakingAmount() {
    return this._amount / Coin.StakingFraction;
  }

  toString(precision) {
    // default to display in mint denom if it has more than 4 decimal places
    let minStake = Coin.StakingFraction / (precision ? Math.pow(10, precision) : 10000);

    if (this.amount < minStake) {
      return "".concat(numbro(this.amount).format('0,0'), " ").concat(Coin.MintingDenom);
    } else {
      return "".concat(precision ? numbro(this.stakingAmount).format('0,0.' + '0'.repeat(precision)) : autoformat(this.stakingAmount), " ").concat(Coin.StakingDenom);
    }
  }

  mintString(formatter) {
    let amount = this.amount;

    if (formatter) {
      amount = numbro(amount).format(formatter);
    }

    return "".concat(amount, " ").concat(Coin.MintingDenom);
  }

  stakeString(formatter) {
    let amount = this.stakingAmount;

    if (formatter) {
      amount = numbro(amount).format(formatter);
    }

    return "".concat(amount, " ").concat(Coin.StakingDenom);
  }

}

Coin.StakingDenom = Meteor.settings.public.stakingDenom;
Coin.StakingDenomPlural = Meteor.settings.public.stakingDenomPlural || Coin.StakingDenom + 's';
Coin.MintingDenom = Meteor.settings.public.mintingDenom;
Coin.StakingFraction = Number(Meteor.settings.public.stakingFraction);
Coin.MinStake = 1 / Number(Meteor.settings.public.stakingFraction);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("/imports/startup/server");
module.link("/imports/startup/both");
// import moment from 'moment';
// import '/imports/api/blocks/blocks.js';
SYNCING = false;
COUNTMISSEDBLOCKS = false;
COUNTMISSEDBLOCKSSTATS = false;
RPC = Meteor.settings.remote.rpc;
LCD = Meteor.settings.remote.lcd;
timerBlocks = 0;
timerChain = 0;
timerConsensus = 0;
timerProposal = 0;
timerProposalsResults = 0;
timerMissedBlock = 0;
timerDelegation = 0;
timerAggregate = 0;
const DEFAULTSETTINGS = '/default_settings.json';

updateChainStatus = () => {
  Meteor.call('chain.updateStatus', (error, result) => {
    if (error) {
      console.log("updateStatus: " + error);
    } else {
      console.log("updateStatus: " + result);
    }
  });
};

updateBlock = () => {
  Meteor.call('blocks.blocksUpdate', (error, result) => {
    if (error) {
      console.log("updateBlocks: " + error);
    } else {
      console.log("updateBlocks: " + result);
    }
  });
};

getConsensusState = () => {
  Meteor.call('chain.getConsensusState', (error, result) => {
    if (error) {
      console.log("get consensus: " + error);
    }
  });
};

getPurchaseOrders = () => {
  Meteor.call('enterprise.getPurchaseOrders', (error, result) => {
    if (error) {
      console.log("get po: " + error);
    }

    if (result) {
      console.log("get po: " + result);
    }
  });
}; //getProposals = () => {
//    Meteor.call('proposals.getProposals', (error, result) => {
//        if (error){
//            console.log("get proposal: "+ error);
//        }
//        if (result){
//            console.log("get proposal: "+result);
//        }
//    });
//}
//
//getProposalsResults = () => {
//    Meteor.call('proposals.getProposalResults', (error, result) => {
//        if (error){
//            console.log("get proposals result: "+error);
//        }
//        if (result){
//            console.log("get proposals result: "+result);
//        }
//    });
//}


updateMissedBlocks = () => {
  Meteor.call('ValidatorRecords.calculateMissedBlocks', (error, result) => {
    if (error) {
      console.log("missed blocks error: " + error);
    }

    if (result) {
      console.log("missed blocks ok:" + result);
    }
  });
  /*
      Meteor.call('ValidatorRecords.calculateMissedBlocksStats', (error, result) =>{
          if (error){
              console.log("missed blocks stats error: "+ error)
          }
          if (result){
              console.log("missed blocks stats ok:" + result);
          }
      });
  */
};

getDelegations = () => {
  Meteor.call('delegations.getDelegations', (error, result) => {
    if (error) {
      console.log("get delegations error: " + error);
    } else {
      console.log("get delegations ok: " + result);
    }
  });
};

aggregateMinutely = () => {
  // doing something every min
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "m", (error, result) => {
    if (error) {
      console.log("aggregate minutely block time error: " + error);
    } else {
      console.log("aggregate minutely block time ok: " + result);
    }
  });
  Meteor.call('coinStats.getCoinStats', (error, result) => {
    if (error) {
      console.log("get coin stats error: " + error);
    } else {
      console.log("get coin stats ok: " + result);
    }
  });
};

aggregateHourly = () => {
  // doing something every hour
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "h", (error, result) => {
    if (error) {
      console.log("aggregate hourly block time error: " + error);
    } else {
      console.log("aggregate hourly block time ok: " + result);
    }
  });
};

aggregateDaily = () => {
  // doing somthing every day
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "d", (error, result) => {
    if (error) {
      console.log("aggregate daily block time error: " + error);
    } else {
      console.log("aggregate daily block time ok: " + result);
    }
  });
  Meteor.call('Analytics.aggregateValidatorDailyBlockTime', (error, result) => {
    if (error) {
      console.log("aggregate validators block time error:" + error);
    } else {
      console.log("aggregate validators block time ok:" + result);
    }
  });
};

Meteor.startup(function () {
  if (Meteor.isDevelopment) {
    let DEFAULTSETTINGSJSON;
    module.link("../default_settings.json", {
      default(v) {
        DEFAULTSETTINGSJSON = v;
      }

    }, 0);
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;
    Object.keys(DEFAULTSETTINGSJSON).forEach(key => {
      if (Meteor.settings[key] == undefined) {
        console.warn("CHECK SETTINGS JSON: ".concat(key, " is missing from settings"));
        Meteor.settings[key] = {};
      }

      Object.keys(DEFAULTSETTINGSJSON[key]).forEach(param => {
        if (Meteor.settings[key][param] == undefined) {
          console.warn("CHECK SETTINGS JSON: ".concat(key, ".").concat(param, " is missing from settings"));
          Meteor.settings[key][param] = DEFAULTSETTINGSJSON[key][param];
        }
      });
    });
  }

  Meteor.call('chain.genesis', (err, result) => {
    if (err) {
      console.log(err);
    }

    if (result) {
      if (Meteor.settings.debug.startTimer) {
        timerConsensus = Meteor.setInterval(function () {
          getConsensusState();
        }, Meteor.settings.params.consensusInterval);
        timerBlocks = Meteor.setInterval(function () {
          updateBlock();
        }, Meteor.settings.params.blockInterval);
        timerChain = Meteor.setInterval(function () {
          updateChainStatus();
        }, Meteor.settings.params.statusInterval);
        timerPurchaseOrder = Meteor.setInterval(function () {
          getPurchaseOrders();
        }, Meteor.settings.params.proposalInterval); //                timerProposal = Meteor.setInterval(function(){
        //                    getProposals();
        //                }, Meteor.settings.params.proposalInterval);
        //
        //                timerProposalsResults = Meteor.setInterval(function(){
        //                    getProposalsResults();
        //                }, Meteor.settings.params.proposalInterval);

        timerMissedBlock = Meteor.setInterval(function () {
          updateMissedBlocks();
        }, Meteor.settings.params.missedBlocksInterval);
        timerDelegation = Meteor.setInterval(function () {
          getDelegations();
        }, Meteor.settings.params.delegationInterval);
        timerAggregate = Meteor.setInterval(function () {
          let now = new Date();

          if (now.getUTCSeconds() == 0) {
            aggregateMinutely();
          }

          if (now.getUTCMinutes() == 0 && now.getUTCSeconds() == 0) {
            aggregateHourly();
          }

          if (now.getUTCHours() == 0 && now.getUTCMinutes() == 0 && now.getUTCSeconds() == 0) {
            aggregateDaily();
          }
        }, 1000);
      }
    }
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"default_settings.json":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// default_settings.json                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "public": {
    "chainName": "Cosmos Testnet",
    "chainId": "{Chain ID}",
    "gtm": "{Add your Google Tag Manager ID here}",
    "slashingWindow": 10000,
    "uptimeWindow": 250,
    "initialPageSize": 30,
    "bech32PrefixAccAddr": "cosmos",
    "bech32PrefixAccPub": "cosmospub",
    "bech32PrefixValAddr": "cosmosvaloper",
    "bech32PrefixValPub": "cosmosvaloperpub",
    "bech32PrefixConsAddr": "cosmosvalcons",
    "bech32PrefixConsPub": "cosmosvalconspub",
    "stakingDenom": "ATOM",
    "stakingDenomPlural": null,
    "mintingDenom": "uatom",
    "stakingFraction": 1000000,
    "powerReduction": null,
    "gasPrice": 0.02,
    "coingeckoId": "cosmos"
  },
  "genesisFile": "{Replace the address of the genesis file of the chain}",
  "remote": {
    "rpc": "https://gaia-seeds.interblock.io",
    "lcd": "https://gaia-seeds.interblock.io:1317"
  },
  "debug": {
    "startTimer": true,
    "readGenesis": true
  },
  "params": {
    "startHeight": 0,
    "defaultBlockTime": 5000,
    "blockInterval": 15000,
    "consensusInterval": 1000,
    "statusInterval": 7500,
    "signingInfoInterval": 1800000,
    "proposalInterval": 5000,
    "missedBlocksInterval": 60000,
    "delegationInterval": 900000
  }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx",
    ".mjs",
    ".i18n.yml"
  ]
});

require("/both/i18n/en-us.i18n.yml.js");
require("/both/i18n/zh-hans.i18n.yml.js");
require("/both/i18n/zh-hant.i18n.yml.js");
require("/both/utils/coins.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWNjb3VudHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jsb2Nrcy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYmxvY2tzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jsb2Nrcy9ibG9ja3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2NoYWluL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jaGFpbi9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jaGFpbi9jaGFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29pbi1zdGF0cy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29pbi1zdGF0cy9jb2luLXN0YXRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9kZWxlZ2F0aW9ucy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZGVsZWdhdGlvbnMvZGVsZWdhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2VudGVycHJpc2Uvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2VudGVycHJpc2Uvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZW50ZXJwcmlzZS9lbnRlcnByaXNlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9sZWRnZXIvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3JlY29yZHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3JlY29yZHMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcmVjb3Jkcy9yZWNvcmRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zdGF0dXMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc3RhdHVzL3N0YXR1cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdHJhbnNhY3Rpb25zL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90cmFuc2FjdGlvbnMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdHJhbnNhY3Rpb25zL3RyYW5zYWN0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdmFsaWRhdG9ycy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdmFsaWRhdG9ycy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3ZvdGluZy1wb3dlci9oaXN0b3J5LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9ldmlkZW5jZXMvZXZpZGVuY2VzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS92YWxpZGF0b3Itc2V0cy92YWxpZGF0b3Itc2V0cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL2JvdGgvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvY3JlYXRlLWluZGV4ZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvcmVnaXN0ZXItYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL3V0aWwuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdWkvY29tcG9uZW50cy9JY29ucy5qc3giLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvdXRpbHMvY29pbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIk1ldGVvciIsIm1vZHVsZSIsImxpbmsiLCJ2IiwiSFRUUCIsIlZhbGlkYXRvcnMiLCJmZXRjaEZyb21VcmwiLCJ1cmwiLCJyZXMiLCJnZXQiLCJMQ0QiLCJzdGF0dXNDb2RlIiwiZSIsImNvbnNvbGUiLCJsb2ciLCJtZXRob2RzIiwiYWRkcmVzcyIsInVuYmxvY2siLCJhdmFpbGFibGUiLCJyZXNwb25zZSIsIkpTT04iLCJwYXJzZSIsImNvbnRlbnQiLCJyZXN1bHQiLCJhY2NvdW50IiwidHlwZSIsInZhbHVlIiwiQmFzZVZlc3RpbmdBY2NvdW50IiwiQmFzZUFjY291bnQiLCJhY2NvdW50X251bWJlciIsImJhbGFuY2UiLCJsZW5ndGgiLCJkZWxlZ2F0aW9ucyIsInVuYm9uZGluZyIsInJld2FyZHMiLCJ0b3RhbCIsInZhbGlkYXRvciIsImZpbmRPbmUiLCIkb3IiLCJvcGVyYXRvcl9hZGRyZXNzIiwiZGVsZWdhdG9yX2FkZHJlc3MiLCJ2YWxfY29tbWlzc2lvbiIsImNvbW1pc3Npb24iLCJkYXRhIiwic2hhcmVzIiwicGFyc2VGbG9hdCIsInJlbGVnYXRpb25zIiwiY29tcGxldGlvblRpbWUiLCJmb3JFYWNoIiwicmVsZWdhdGlvbiIsImVudHJpZXMiLCJ0aW1lIiwiRGF0ZSIsImNvbXBsZXRpb25fdGltZSIsInJlZGVsZWdhdGlvbkNvbXBsZXRpb25UaW1lIiwidW5kZWxlZ2F0aW9ucyIsInVuYm9uZGluZ0NvbXBsZXRpb25UaW1lIiwiZGVsZWdhdGlvbiIsImkiLCJ1bmJvbmRpbmdzIiwicmVkZWxlZ2F0aW9ucyIsInJlZGVsZWdhdGlvbiIsInZhbGlkYXRvcl9kc3RfYWRkcmVzcyIsImNvdW50IiwiUHJvbWlzZSIsIkJsb2Nrc2NvbiIsIkNoYWluIiwiVmFsaWRhdG9yU2V0cyIsIlZhbGlkYXRvclJlY29yZHMiLCJBbmFseXRpY3MiLCJWUERpc3RyaWJ1dGlvbnMiLCJWb3RpbmdQb3dlckhpc3RvcnkiLCJUcmFuc2FjdGlvbnMiLCJFdmlkZW5jZXMiLCJzaGEyNTYiLCJnZXRBZGRyZXNzIiwiY2hlZXJpbyIsImdldFJlbW92ZWRWYWxpZGF0b3JzIiwicHJldlZhbGlkYXRvcnMiLCJ2YWxpZGF0b3JzIiwicCIsInNwbGljZSIsImdldFZhbGlkYXRvclByb2ZpbGVVcmwiLCJpZGVudGl0eSIsInRoZW0iLCJwaWN0dXJlcyIsInByaW1hcnkiLCJzdHJpbmdpZnkiLCJpbmRleE9mIiwidGVhbVBhZ2UiLCJwYWdlIiwibG9hZCIsImF0dHIiLCJibG9ja3MiLCJmaW5kIiwicHJvcG9zZXJBZGRyZXNzIiwiZmV0Y2giLCJoZWlnaHRzIiwibWFwIiwiYmxvY2siLCJoZWlnaHQiLCJibG9ja3NTdGF0cyIsIiRpbiIsInRvdGFsQmxvY2tEaWZmIiwiYiIsInRpbWVEaWZmIiwiY29sbGVjdGlvbiIsInJhd0NvbGxlY3Rpb24iLCJwaXBlbGluZSIsIiRtYXRjaCIsIiRzb3J0IiwiJGxpbWl0Iiwic2V0dGluZ3MiLCJwdWJsaWMiLCJ1cHRpbWVXaW5kb3ciLCIkdW53aW5kIiwiJGdyb3VwIiwiJGNvbmQiLCIkZXEiLCJhd2FpdCIsImFnZ3JlZ2F0ZSIsInRvQXJyYXkiLCJSUEMiLCJzdGF0dXMiLCJzeW5jX2luZm8iLCJsYXRlc3RfYmxvY2tfaGVpZ2h0IiwiY3VyckhlaWdodCIsInNvcnQiLCJsaW1pdCIsInN0YXJ0SGVpZ2h0IiwicGFyYW1zIiwiU1lOQ0lORyIsInVudGlsIiwiY2FsbCIsImN1cnIiLCJ2YWxpZGF0b3JTZXQiLCJjb25zZW5zdXNfcHVia2V5IiwidG90YWxWYWxpZGF0b3JzIiwiT2JqZWN0Iiwia2V5cyIsInN0YXJ0QmxvY2tUaW1lIiwiYW5hbHl0aWNzRGF0YSIsImJ1bGtWYWxpZGF0b3JzIiwiaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCIsImJ1bGtWYWxpZGF0b3JSZWNvcmRzIiwiYnVsa1ZQSGlzdG9yeSIsImJ1bGtUcmFuc2F0aW9ucyIsInN0YXJ0R2V0SGVpZ2h0VGltZSIsImJsb2NrRGF0YSIsImhhc2giLCJibG9ja19tZXRhIiwiYmxvY2tfaWQiLCJ0cmFuc051bSIsImhlYWRlciIsIm51bV90eHMiLCJsYXN0QmxvY2tIYXNoIiwibGFzdF9ibG9ja19pZCIsInByb3Bvc2VyX2FkZHJlc3MiLCJwcmVjb21taXRzIiwibGFzdF9jb21taXQiLCJwdXNoIiwidmFsaWRhdG9yX2FkZHJlc3MiLCJ0eHMiLCJ0IiwiQnVmZmVyIiwiZnJvbSIsImVyciIsImV2aWRlbmNlIiwiaW5zZXJ0IiwicHJlY29tbWl0c0NvdW50IiwiZW5kR2V0SGVpZ2h0VGltZSIsInN0YXJ0R2V0VmFsaWRhdG9yc1RpbWUiLCJibG9ja19oZWlnaHQiLCJwYXJzZUludCIsInZhbGlkYXRvcnNDb3VudCIsInN0YXJ0QmxvY2tJbnNlcnRUaW1lIiwiZW5kQmxvY2tJbnNlcnRUaW1lIiwiZXhpc3RpbmdWYWxpZGF0b3JzIiwiJGV4aXN0cyIsInJlY29yZCIsImV4aXN0cyIsInZvdGluZ19wb3dlciIsImoiLCJudW1CbG9ja3MiLCJ1cHRpbWUiLCJiYXNlIiwidXBzZXJ0IiwidXBkYXRlT25lIiwiJHNldCIsImxhc3RTZWVuIiwiY2hhaW5TdGF0dXMiLCJjaGFpbklkIiwiY2hhaW5faWQiLCJsYXN0U3luY2VkVGltZSIsImJsb2NrVGltZSIsImRlZmF1bHRCbG9ja1RpbWUiLCJkYXRlTGF0ZXN0IiwiZGF0ZUxhc3QiLCJNYXRoIiwiYWJzIiwiZ2V0VGltZSIsImVuZEdldFZhbGlkYXRvcnNUaW1lIiwidXBkYXRlIiwiYXZlcmFnZUJsb2NrVGltZSIsInN0YXJ0RmluZFZhbGlkYXRvcnNOYW1lVGltZSIsInByb3Bvc2VyX3ByaW9yaXR5IiwidmFsRXhpc3QiLCJwdWJfa2V5IiwiYWNjcHViIiwiYmVjaDMyUHJlZml4QWNjUHViIiwib3BlcmF0b3JfcHVia2V5IiwiYmVjaDMyUHJlZml4VmFsUHViIiwiYmVjaDMyUHJlZml4Q29uc1B1YiIsInZhbGlkYXRvckRhdGEiLCJkZXNjcmlwdGlvbiIsInByb2ZpbGVfdXJsIiwiamFpbGVkIiwibWluX3NlbGZfZGVsZWdhdGlvbiIsInRva2VucyIsImRlbGVnYXRvcl9zaGFyZXMiLCJib25kX2hlaWdodCIsImJvbmRfaW50cmFfdHhfY291bnRlciIsInVuYm9uZGluZ19oZWlnaHQiLCJ1bmJvbmRpbmdfdGltZSIsInNlbGZfZGVsZWdhdGlvbiIsInByZXZfdm90aW5nX3Bvd2VyIiwiYmxvY2tfdGltZSIsInNlbGZEZWxlZ2F0aW9uIiwicHJldlZvdGluZ1Bvd2VyIiwiY2hhbmdlVHlwZSIsImNoYW5nZURhdGEiLCJyZW1vdmVkVmFsaWRhdG9ycyIsInIiLCJkYlZhbGlkYXRvcnMiLCJmaWVsZHMiLCJjb25QdWJLZXkiLCJ1bmRlZmluZWQiLCJwcm9maWxlVXJsIiwiZW5kRmluZFZhbGlkYXRvcnNOYW1lVGltZSIsInN0YXJ0QW5heXRpY3NJbnNlcnRUaW1lIiwiZW5kQW5hbHl0aWNzSW5zZXJ0VGltZSIsInN0YXJ0VlVwVGltZSIsImV4ZWN1dGUiLCJlbmRWVXBUaW1lIiwic3RhcnRWUlRpbWUiLCJlbmRWUlRpbWUiLCJhY3RpdmVWYWxpZGF0b3JzIiwibnVtVG9wVHdlbnR5IiwiY2VpbCIsIm51bUJvdHRvbUVpZ2h0eSIsInRvcFR3ZW50eVBvd2VyIiwiYm90dG9tRWlnaHR5UG93ZXIiLCJudW1Ub3BUaGlydHlGb3VyIiwibnVtQm90dG9tU2l4dHlTaXgiLCJ0b3BUaGlydHlGb3VyUGVyY2VudCIsImJvdHRvbVNpeHR5U2l4UGVyY2VudCIsInZwRGlzdCIsIm51bVZhbGlkYXRvcnMiLCJ0b3RhbFZvdGluZ1Bvd2VyIiwiY3JlYXRlQXQiLCJlbmRCbG9ja1RpbWUiLCJsYXN0QmxvY2tzU3luY2VkVGltZSIsInB1Ymxpc2hDb21wb3NpdGUiLCJjaGlsZHJlbiIsImV4cG9ydCIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsImhlbHBlcnMiLCJwcm9wb3NlciIsIkNoYWluU3RhdGVzIiwiZmluZFZvdGluZ1Bvd2VyIiwiZ2VuVmFsaWRhdG9ycyIsInBvd2VyIiwiY29uc2Vuc3VzIiwicm91bmRfc3RhdGUiLCJyb3VuZCIsInN0ZXAiLCJ2b3RlZFBvd2VyIiwidm90ZXMiLCJwcmV2b3Rlc19iaXRfYXJyYXkiLCJzcGxpdCIsInZvdGluZ0hlaWdodCIsInZvdGluZ1JvdW5kIiwidm90aW5nU3RlcCIsInByZXZvdGVzIiwiY2hhaW4iLCJub2RlX2luZm8iLCJuZXR3b3JrIiwibGF0ZXN0QmxvY2tIZWlnaHQiLCJsYXRlc3RCbG9ja1RpbWUiLCJsYXRlc3RfYmxvY2tfdGltZSIsImxhdGVzdFN0YXRlIiwiYWN0aXZlVlAiLCJhY3RpdmVWb3RpbmdQb3dlciIsImNoYWluU3RhdGVzIiwiYm9uZGluZyIsImJvbmRlZFRva2VucyIsImJvbmRlZF90b2tlbnMiLCJub3RCb25kZWRUb2tlbnMiLCJub3RfYm9uZGVkX3Rva2VucyIsIm1pbnRpbmdEZW5vbSIsInN1cHBseSIsInRvdGFsU3VwcGx5IiwicG9vbCIsImNvbW11bml0eVBvb2wiLCJhbW91bnQiLCJkZW5vbSIsImluZmxhdGlvbiIsInByb3Zpc2lvbnMiLCJhbm51YWxQcm92aXNpb25zIiwiY3JlYXRlZCIsInJlYWRHZW5lc2lzIiwiZGVidWciLCJnZW5lc2lzRmlsZSIsImdlbmVzaXMiLCJkaXN0ciIsImFwcF9zdGF0ZSIsImRpc3RyaWJ1dGlvbiIsImNoYWluUGFyYW1zIiwiZ2VuZXNpc1RpbWUiLCJnZW5lc2lzX3RpbWUiLCJjb25zZW5zdXNQYXJhbXMiLCJjb25zZW5zdXNfcGFyYW1zIiwiYXV0aCIsImJhbmsiLCJzdGFraW5nIiwibWludCIsImNvbW11bml0eVRheCIsImNvbW11bml0eV90YXgiLCJiYXNlUHJvcG9zZXJSZXdhcmQiLCJiYXNlX3Byb3Bvc2VyX3Jld2FyZCIsImJvbnVzUHJvcG9zZXJSZXdhcmQiLCJib251c19wcm9wb3Nlcl9yZXdhcmQiLCJ3aXRoZHJhd0FkZHJFbmFibGVkIiwid2l0aGRyYXdfYWRkcl9lbmFibGVkIiwiZ292Iiwic2xhc2hpbmciLCJjcmlzaXMiLCJnZW51dGlsIiwiZ2VudHhzIiwibXNnIiwibSIsInB1YmtleSIsImZsb29yIiwic3Rha2luZ0ZyYWN0aW9uIiwicHVia2V5VmFsdWUiLCJnZW5WYWxpZGF0b3JzU2V0IiwiQ29pblN0YXRzIiwicHVibGlzaCIsImxhc3RfdXBkYXRlZF9hdCIsImNvaW5JZCIsImNvaW5nZWNrb0lkIiwibm93Iiwic2V0TWludXRlcyIsIkRlbGVnYXRpb25zIiwiY29uY2F0IiwiY3JlYXRlZEF0IiwiRW50ZXJwcmlzZSIsInB1cmNoYXNlT3JkZXJzIiwiZmluaXNoZWRQdXJjaGFzZU9yZGVycyIsIlNldCIsInBvSWQiLCJwb0lkcyIsImJ1bGtQb3MiLCJwbyIsImlkIiwiaGFzIiwiY2hlY2siLCJOdW1iZXIiLCJfb2JqZWN0U3ByZWFkIiwiZGVmYXVsdCIsInR4SW5mbyIsInRpbWVzdGFtcCIsInBvc3QiLCJjb2RlIiwiRXJyb3IiLCJyYXdfbG9nIiwibWVzc2FnZSIsInR4aGFzaCIsImJvZHkiLCJwYXRoIiwidHhNc2ciLCJhZGp1c3RtZW50IiwiZ2FzX2VzdGltYXRlIiwiQXZlcmFnZURhdGEiLCJBdmVyYWdlVmFsaWRhdG9yRGF0YSIsIlN0YXR1cyIsIk1pc3NlZEJsb2Nrc1N0YXRzIiwiTWlzc2VkQmxvY2tzIiwiXyIsIkJVTEtVUERBVEVNQVhTSVpFIiwiZ2V0QmxvY2tTdGF0cyIsImxhdGVzdEhlaWdodCIsImJsb2NrU3RhdHMiLCJjb25kIiwiJGFuZCIsIiRndCIsIiRsdGUiLCJvcHRpb25zIiwiYXNzaWduIiwiZ2V0UHJldmlvdXNSZWNvcmQiLCJ2b3RlckFkZHJlc3MiLCJwcmV2aW91c1JlY29yZCIsInZvdGVyIiwiYmxvY2tIZWlnaHQiLCJsYXN0VXBkYXRlZEhlaWdodCIsInByZXZTdGF0cyIsInBpY2siLCJtaXNzQ291bnQiLCJ0b3RhbENvdW50IiwiQ09VTlRNSVNTRURCTE9DS1MiLCJzdGFydFRpbWUiLCJleHBsb3JlclN0YXR1cyIsImxhc3RQcm9jZXNzZWRNaXNzZWRCbG9ja0hlaWdodCIsIm1pbiIsImJ1bGtNaXNzZWRTdGF0cyIsImluaXRpYWxpemVPcmRlcmVkQnVsa09wIiwidmFsaWRhdG9yc01hcCIsInByb3Bvc2VyVm90ZXJTdGF0cyIsInZvdGVkVmFsaWRhdG9ycyIsInZhbGlkYXRvclNldHMiLCJ2b3RlZFZvdGluZ1Bvd2VyIiwiYWN0aXZlVmFsaWRhdG9yIiwiY3VycmVudFZhbGlkYXRvciIsInNldCIsIm4iLCJ2b3RpbmdQb3dlciIsInVwZGF0ZWRBdCIsInZvdGVycyIsInN0YXRzIiwiY2xpZW50IiwiX2RyaXZlciIsIm1vbmdvIiwiYnVsa1Byb21pc2UiLCJ0aGVuIiwiYmluZEVudmlyb25tZW50Iiwibkluc2VydGVkIiwiblVwc2VydGVkIiwibk1vZGlmaWVkIiwibGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrVGltZSIsIkNPVU5UTUlTU0VEQkxPQ0tTU1RBVFMiLCJsYXN0TWlzc2VkQmxvY2tIZWlnaHQiLCJtaXNzZWRSZWNvcmRzIiwiY291bnRzIiwiZXhpc3RpbmdSZWNvcmQiLCJsYXN0TWlzc2VkQmxvY2tUaW1lIiwiYXZlcmFnZVZvdGluZ1Bvd2VyIiwiYW5hbHl0aWNzIiwibGFzdE1pbnV0ZVZvdGluZ1Bvd2VyIiwibGFzdE1pbnV0ZUJsb2NrVGltZSIsImxhc3RIb3VyVm90aW5nUG93ZXIiLCJsYXN0SG91ckJsb2NrVGltZSIsImxhc3REYXlWb3RpbmdQb3dlciIsImxhc3REYXlCbG9ja1RpbWUiLCJibG9ja0hlaWdodHMiLCJhIiwibnVtIiwiY29uZGl0aW9ucyIsInByb3Bvc2VyTW9uaWtlciIsIm1vbmlrZXIiLCJ2b3Rlck1vbmlrZXIiLCJBZGRyZXNzTGVuZ3RoIiwidG9VcHBlckNhc2UiLCJ0eCIsInR4SWQiLCIkbHQiLCJpbmNsdWRlcyIsImJlY2gzMlByZWZpeFZhbEFkZHIiLCJiZWNoMzJQcmVmaXhBY2NBZGRyIiwidmFsaWRhdG9yQWRkcmVzcyIsImRlbGVnYXRvckFkZHJlc3MiLCJxdWVyeSIsIlR4SWNvbiIsImRpcmVjdGlvbiIsInZhbCIsImZpcnN0U2VlbiIsImhpc3RvcnkiLCJjcmVhdGVJbmRleCIsInVuaXF1ZSIsInBhcnRpYWxGaWx0ZXJFeHByZXNzaW9uIiwib25QYWdlTG9hZCIsIkhlbG1ldCIsInNpbmsiLCJoZWxtZXQiLCJyZW5kZXJTdGF0aWMiLCJhcHBlbmRUb0hlYWQiLCJtZXRhIiwidG9TdHJpbmciLCJ0aXRsZSIsImJlY2gzMiIsIkZ1dHVyZSIsIk5wbSIsInJlcXVpcmUiLCJleGVjIiwidG9IZXhTdHJpbmciLCJieXRlQXJyYXkiLCJieXRlIiwic2xpY2UiLCJqb2luIiwicHVia2V5VG9CZWNoMzIiLCJwcmVmaXgiLCJwdWJrZXlBbWlub1ByZWZpeCIsImJ1ZmZlciIsImFsbG9jIiwiY29weSIsImVuY29kZSIsInRvV29yZHMiLCJiZWNoMzJUb1B1YmtleSIsImZyb21Xb3JkcyIsImRlY29kZSIsIndvcmRzIiwiZ2V0RGVsZWdhdG9yIiwib3BlcmF0b3JBZGRyIiwiZ2V0S2V5YmFzZVRlYW1QaWMiLCJrZXliYXNlVXJsIiwiRGVub21TeW1ib2wiLCJQcm9wb3NhbFN0YXR1c0ljb24iLCJWb3RlSWNvbiIsIkluZm9JY29uIiwiUmVhY3QiLCJVbmNvbnRyb2xsZWRUb29sdGlwIiwicHJvcHMiLCJ2b3RlIiwidmFsaWQiLCJDb21wb25lbnQiLCJjb25zdHJ1Y3RvciIsInJlZiIsImNyZWF0ZVJlZiIsInJlbmRlciIsInRvb2x0aXBUZXh0IiwiQ29pbiIsIm51bWJybyIsImF1dG9mb3JtYXQiLCJmb3JtYXR0ZXIiLCJmb3JtYXQiLCJ0b0xvd2VyQ2FzZSIsIk1pbnRpbmdEZW5vbSIsIl9hbW91bnQiLCJTdGFraW5nRGVub20iLCJTdGFraW5nRnJhY3Rpb24iLCJzdGFraW5nQW1vdW50IiwicHJlY2lzaW9uIiwibWluU3Rha2UiLCJwb3ciLCJyZXBlYXQiLCJtaW50U3RyaW5nIiwic3Rha2VTdHJpbmciLCJzdGFraW5nRGVub20iLCJTdGFraW5nRGVub21QbHVyYWwiLCJzdGFraW5nRGVub21QbHVyYWwiLCJNaW5TdGFrZSIsInJlbW90ZSIsInJwYyIsImxjZCIsInRpbWVyQmxvY2tzIiwidGltZXJDaGFpbiIsInRpbWVyQ29uc2Vuc3VzIiwidGltZXJQcm9wb3NhbCIsInRpbWVyUHJvcG9zYWxzUmVzdWx0cyIsInRpbWVyTWlzc2VkQmxvY2siLCJ0aW1lckRlbGVnYXRpb24iLCJ0aW1lckFnZ3JlZ2F0ZSIsIkRFRkFVTFRTRVRUSU5HUyIsInVwZGF0ZUNoYWluU3RhdHVzIiwiZXJyb3IiLCJ1cGRhdGVCbG9jayIsImdldENvbnNlbnN1c1N0YXRlIiwiZ2V0UHVyY2hhc2VPcmRlcnMiLCJ1cGRhdGVNaXNzZWRCbG9ja3MiLCJnZXREZWxlZ2F0aW9ucyIsImFnZ3JlZ2F0ZU1pbnV0ZWx5IiwiYWdncmVnYXRlSG91cmx5IiwiYWdncmVnYXRlRGFpbHkiLCJzdGFydHVwIiwiaXNEZXZlbG9wbWVudCIsIkRFRkFVTFRTRVRUSU5HU0pTT04iLCJwcm9jZXNzIiwiZW52IiwiTk9ERV9UTFNfUkVKRUNUX1VOQVVUSE9SSVpFRCIsImtleSIsIndhcm4iLCJwYXJhbSIsInN0YXJ0VGltZXIiLCJzZXRJbnRlcnZhbCIsImNvbnNlbnN1c0ludGVydmFsIiwiYmxvY2tJbnRlcnZhbCIsInN0YXR1c0ludGVydmFsIiwidGltZXJQdXJjaGFzZU9yZGVyIiwicHJvcG9zYWxJbnRlcnZhbCIsIm1pc3NlZEJsb2Nrc0ludGVydmFsIiwiZGVsZWdhdGlvbkludGVydmFsIiwiZ2V0VVRDU2Vjb25kcyIsImdldFVUQ01pbnV0ZXMiLCJnZXRVVENIb3VycyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSx1Q0FBWixFQUFvRDtBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBcEQsRUFBa0YsQ0FBbEY7O0FBR3ZJLE1BQU1HLFlBQVksR0FBSUMsR0FBRCxJQUFTO0FBQzFCLE1BQUc7QUFDQyxRQUFJQyxHQUFHLEdBQUdKLElBQUksQ0FBQ0ssR0FBTCxDQUFTQyxHQUFHLEdBQUdILEdBQWYsQ0FBVjs7QUFDQSxRQUFJQyxHQUFHLENBQUNHLFVBQUosSUFBa0IsR0FBdEIsRUFBMEI7QUFDdEIsYUFBT0gsR0FBUDtBQUNIOztBQUFBO0FBQ0osR0FMRCxDQU1BLE9BQU9JLENBQVAsRUFBUztBQUNMQyxXQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osQ0FWRDs7QUFZQVosTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCwrQkFBNkIsVUFBU0MsT0FBVCxFQUFpQjtBQUMxQyxTQUFLQyxPQUFMO0FBQ0EsUUFBSVYsR0FBRyxHQUFHRyxHQUFHLEdBQUcsaUJBQU4sR0FBeUJNLE9BQW5DOztBQUNBLFFBQUc7QUFDQyxVQUFJRSxTQUFTLEdBQUdkLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWhCOztBQUNBLFVBQUlXLFNBQVMsQ0FBQ1AsVUFBVixJQUF3QixHQUE1QixFQUFnQztBQUM1QixZQUFJUSxRQUFRLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXSCxTQUFTLENBQUNJLE9BQXJCLEVBQThCQyxNQUE3QztBQUNBLFlBQUlDLE9BQUo7QUFDQSxZQUFJTCxRQUFRLENBQUNNLElBQVQsS0FBa0Isb0JBQXRCLEVBQ0lELE9BQU8sR0FBR0wsUUFBUSxDQUFDTyxLQUFuQixDQURKLEtBRUssSUFBSVAsUUFBUSxDQUFDTSxJQUFULEtBQWtCLGtDQUFsQixJQUF3RE4sUUFBUSxDQUFDTSxJQUFULEtBQWtCLHFDQUE5RSxFQUNERCxPQUFPLEdBQUdMLFFBQVEsQ0FBQ08sS0FBVCxDQUFlQyxrQkFBZixDQUFrQ0MsV0FBNUM7QUFDSixZQUFJSixPQUFPLElBQUlBLE9BQU8sQ0FBQ0ssY0FBUixJQUEwQixJQUF6QyxFQUNJLE9BQU9MLE9BQVA7QUFDSixlQUFPLElBQVA7QUFDSDtBQUNKLEtBYkQsQ0FjQSxPQUFPWixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLEdBckJVO0FBc0JYLHlCQUF1QixVQUFTSSxPQUFULEVBQWlCO0FBQ3BDLFNBQUtDLE9BQUw7QUFDQSxRQUFJYSxPQUFPLEdBQUcsRUFBZCxDQUZvQyxDQUlwQzs7QUFDQSxRQUFJdkIsR0FBRyxHQUFHRyxHQUFHLEdBQUcsaUJBQU4sR0FBeUJNLE9BQW5DOztBQUNBLFFBQUc7QUFDQyxVQUFJRSxTQUFTLEdBQUdkLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWhCOztBQUNBLFVBQUlXLFNBQVMsQ0FBQ1AsVUFBVixJQUF3QixHQUE1QixFQUFnQztBQUM1QjtBQUNBbUIsZUFBTyxDQUFDWixTQUFSLEdBQW9CRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0gsU0FBUyxDQUFDSSxPQUFyQixFQUE4QkMsTUFBbEQ7QUFDQSxZQUFJTyxPQUFPLENBQUNaLFNBQVIsSUFBcUJZLE9BQU8sQ0FBQ1osU0FBUixDQUFrQmEsTUFBbEIsR0FBMkIsQ0FBcEQsRUFDSUQsT0FBTyxDQUFDWixTQUFSLEdBQW9CWSxPQUFPLENBQUNaLFNBQVIsQ0FBa0IsQ0FBbEIsQ0FBcEI7QUFDUDtBQUNKLEtBUkQsQ0FTQSxPQUFPTixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxLQWpCbUMsQ0FtQnBDOzs7QUFDQUwsT0FBRyxHQUFHRyxHQUFHLEdBQUcsc0JBQU4sR0FBNkJNLE9BQTdCLEdBQXFDLGNBQTNDOztBQUNBLFFBQUc7QUFDQyxVQUFJZ0IsV0FBVyxHQUFHNUIsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBbEI7O0FBQ0EsVUFBSXlCLFdBQVcsQ0FBQ3JCLFVBQVosSUFBMEIsR0FBOUIsRUFBa0M7QUFDOUJtQixlQUFPLENBQUNFLFdBQVIsR0FBc0JaLElBQUksQ0FBQ0MsS0FBTCxDQUFXVyxXQUFXLENBQUNWLE9BQXZCLEVBQWdDQyxNQUF0RDtBQUNIO0FBQ0osS0FMRCxDQU1BLE9BQU9YLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNILEtBN0JtQyxDQThCcEM7OztBQUNBTCxPQUFHLEdBQUdHLEdBQUcsR0FBRyxzQkFBTixHQUE2Qk0sT0FBN0IsR0FBcUMsd0JBQTNDOztBQUNBLFFBQUc7QUFDQyxVQUFJaUIsU0FBUyxHQUFHN0IsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBaEI7O0FBQ0EsVUFBSTBCLFNBQVMsQ0FBQ3RCLFVBQVYsSUFBd0IsR0FBNUIsRUFBZ0M7QUFDNUJtQixlQUFPLENBQUNHLFNBQVIsR0FBb0JiLElBQUksQ0FBQ0MsS0FBTCxDQUFXWSxTQUFTLENBQUNYLE9BQXJCLEVBQThCQyxNQUFsRDtBQUNIO0FBQ0osS0FMRCxDQU1BLE9BQU9YLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNILEtBeENtQyxDQTBDcEM7OztBQUNBTCxPQUFHLEdBQUdHLEdBQUcsR0FBRywyQkFBTixHQUFrQ00sT0FBbEMsR0FBMEMsVUFBaEQ7O0FBQ0EsUUFBRztBQUNDLFVBQUlrQixPQUFPLEdBQUc5QixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFkOztBQUNBLFVBQUkyQixPQUFPLENBQUN2QixVQUFSLElBQXNCLEdBQTFCLEVBQThCO0FBQzFCbUIsZUFBTyxDQUFDSSxPQUFSLEdBQWtCZCxJQUFJLENBQUNDLEtBQUwsQ0FBV2EsT0FBTyxDQUFDWixPQUFuQixFQUE0QkMsTUFBNUIsQ0FBbUNZLEtBQXJEO0FBQ0g7QUFDSixLQUxELENBTUEsT0FBT3ZCLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNILEtBcERtQyxDQXNEcEM7OztBQUNBLFFBQUl3QixTQUFTLEdBQUcvQixVQUFVLENBQUNnQyxPQUFYLENBQ1o7QUFBQ0MsU0FBRyxFQUFFLENBQUM7QUFBQ0Msd0JBQWdCLEVBQUN2QjtBQUFsQixPQUFELEVBQTZCO0FBQUN3Qix5QkFBaUIsRUFBQ3hCO0FBQW5CLE9BQTdCLEVBQTBEO0FBQUNBLGVBQU8sRUFBQ0E7QUFBVCxPQUExRDtBQUFOLEtBRFksQ0FBaEI7O0FBRUEsUUFBSW9CLFNBQUosRUFBZTtBQUNYLFVBQUk3QixHQUFHLEdBQUdHLEdBQUcsR0FBRywyQkFBTixHQUFvQzBCLFNBQVMsQ0FBQ0csZ0JBQXhEO0FBQ0FULGFBQU8sQ0FBQ1MsZ0JBQVIsR0FBMkJILFNBQVMsQ0FBQ0csZ0JBQXJDOztBQUNBLFVBQUk7QUFDQSxZQUFJTCxPQUFPLEdBQUc5QixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFkOztBQUNBLFlBQUkyQixPQUFPLENBQUN2QixVQUFSLElBQXNCLEdBQTFCLEVBQThCO0FBQzFCLGNBQUlXLE9BQU8sR0FBR0YsSUFBSSxDQUFDQyxLQUFMLENBQVdhLE9BQU8sQ0FBQ1osT0FBbkIsRUFBNEJDLE1BQTFDO0FBQ0EsY0FBSUQsT0FBTyxDQUFDbUIsY0FBUixJQUEwQm5CLE9BQU8sQ0FBQ21CLGNBQVIsQ0FBdUJWLE1BQXZCLEdBQWdDLENBQTlELEVBQ0lELE9BQU8sQ0FBQ1ksVUFBUixHQUFxQnBCLE9BQU8sQ0FBQ21CLGNBQVIsQ0FBdUIsQ0FBdkIsQ0FBckI7QUFDUDtBQUVKLE9BUkQsQ0FTQSxPQUFPN0IsQ0FBUCxFQUFTO0FBQ0xDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSjs7QUFFRCxXQUFPa0IsT0FBUDtBQUNILEdBakdVOztBQWtHWCwyQkFBeUJkLE9BQXpCLEVBQWtDb0IsU0FBbEMsRUFBNEM7QUFDeEMsUUFBSTdCLEdBQUcsaUNBQTBCUyxPQUExQiwwQkFBaURvQixTQUFqRCxDQUFQO0FBQ0EsUUFBSUosV0FBVyxHQUFHMUIsWUFBWSxDQUFDQyxHQUFELENBQTlCO0FBQ0F5QixlQUFXLEdBQUdBLFdBQVcsSUFBSUEsV0FBVyxDQUFDVyxJQUFaLENBQWlCcEIsTUFBOUM7QUFDQSxRQUFJUyxXQUFXLElBQUlBLFdBQVcsQ0FBQ1ksTUFBL0IsRUFDSVosV0FBVyxDQUFDWSxNQUFaLEdBQXFCQyxVQUFVLENBQUNiLFdBQVcsQ0FBQ1ksTUFBYixDQUEvQjtBQUVKckMsT0FBRyw4Q0FBdUNTLE9BQXZDLDJCQUErRG9CLFNBQS9ELENBQUg7QUFDQSxRQUFJVSxXQUFXLEdBQUd4QyxZQUFZLENBQUNDLEdBQUQsQ0FBOUI7QUFDQXVDLGVBQVcsR0FBR0EsV0FBVyxJQUFJQSxXQUFXLENBQUNILElBQVosQ0FBaUJwQixNQUE5QztBQUNBLFFBQUl3QixjQUFKOztBQUNBLFFBQUlELFdBQUosRUFBaUI7QUFDYkEsaUJBQVcsQ0FBQ0UsT0FBWixDQUFxQkMsVUFBRCxJQUFnQjtBQUNoQyxZQUFJQyxPQUFPLEdBQUdELFVBQVUsQ0FBQ0MsT0FBekI7QUFDQSxZQUFJQyxJQUFJLEdBQUcsSUFBSUMsSUFBSixDQUFTRixPQUFPLENBQUNBLE9BQU8sQ0FBQ25CLE1BQVIsR0FBZSxDQUFoQixDQUFQLENBQTBCc0IsZUFBbkMsQ0FBWDtBQUNBLFlBQUksQ0FBQ04sY0FBRCxJQUFtQkksSUFBSSxHQUFHSixjQUE5QixFQUNJQSxjQUFjLEdBQUdJLElBQWpCO0FBQ1AsT0FMRDtBQU1BbkIsaUJBQVcsQ0FBQ3NCLDBCQUFaLEdBQXlDUCxjQUF6QztBQUNIOztBQUVEeEMsT0FBRyxpQ0FBMEJTLE9BQTFCLG9DQUEyRG9CLFNBQTNELENBQUg7QUFDQSxRQUFJbUIsYUFBYSxHQUFHakQsWUFBWSxDQUFDQyxHQUFELENBQWhDO0FBQ0FnRCxpQkFBYSxHQUFHQSxhQUFhLElBQUlBLGFBQWEsQ0FBQ1osSUFBZCxDQUFtQnBCLE1BQXBEOztBQUNBLFFBQUlnQyxhQUFKLEVBQW1CO0FBQ2Z2QixpQkFBVyxDQUFDQyxTQUFaLEdBQXdCc0IsYUFBYSxDQUFDTCxPQUFkLENBQXNCbkIsTUFBOUM7QUFDQUMsaUJBQVcsQ0FBQ3dCLHVCQUFaLEdBQXNDRCxhQUFhLENBQUNMLE9BQWQsQ0FBc0IsQ0FBdEIsRUFBeUJHLGVBQS9EO0FBQ0g7O0FBQ0QsV0FBT3JCLFdBQVA7QUFDSCxHQS9IVTs7QUFnSVgsK0JBQTZCaEIsT0FBN0IsRUFBcUM7QUFDakMsUUFBSVQsR0FBRyxHQUFHRyxHQUFHLEdBQUcsc0JBQU4sR0FBNkJNLE9BQTdCLEdBQXFDLGNBQS9DOztBQUVBLFFBQUc7QUFDQyxVQUFJZ0IsV0FBVyxHQUFHNUIsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBbEI7O0FBQ0EsVUFBSXlCLFdBQVcsQ0FBQ3JCLFVBQVosSUFBMEIsR0FBOUIsRUFBa0M7QUFDOUJxQixtQkFBVyxHQUFHWixJQUFJLENBQUNDLEtBQUwsQ0FBV1csV0FBVyxDQUFDVixPQUF2QixFQUFnQ0MsTUFBOUM7O0FBQ0EsWUFBSVMsV0FBVyxJQUFJQSxXQUFXLENBQUNELE1BQVosR0FBcUIsQ0FBeEMsRUFBMEM7QUFDdENDLHFCQUFXLENBQUNnQixPQUFaLENBQW9CLENBQUNTLFVBQUQsRUFBYUMsQ0FBYixLQUFtQjtBQUNuQyxnQkFBSTFCLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxJQUFrQjFCLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxDQUFlZCxNQUFyQyxFQUNJWixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBZixHQUF3QkMsVUFBVSxDQUFDYixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBaEIsQ0FBbEM7QUFDUCxXQUhEO0FBSUg7O0FBRUQsZUFBT1osV0FBUDtBQUNIOztBQUFBO0FBQ0osS0FiRCxDQWNBLE9BQU9wQixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLEdBcEpVOztBQXFKWCw4QkFBNEJJLE9BQTVCLEVBQW9DO0FBQ2hDLFFBQUlULEdBQUcsR0FBR0csR0FBRyxHQUFHLHNCQUFOLEdBQTZCTSxPQUE3QixHQUFxQyx3QkFBL0M7O0FBRUEsUUFBRztBQUNDLFVBQUkyQyxVQUFVLEdBQUd2RCxJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFqQjs7QUFDQSxVQUFJb0QsVUFBVSxDQUFDaEQsVUFBWCxJQUF5QixHQUE3QixFQUFpQztBQUM3QmdELGtCQUFVLEdBQUd2QyxJQUFJLENBQUNDLEtBQUwsQ0FBV3NDLFVBQVUsQ0FBQ3JDLE9BQXRCLEVBQStCQyxNQUE1QztBQUNBLGVBQU9vQyxVQUFQO0FBQ0g7O0FBQUE7QUFDSixLQU5ELENBT0EsT0FBTy9DLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osR0FsS1U7O0FBbUtYLGlDQUErQkksT0FBL0IsRUFBd0NvQixTQUF4QyxFQUFrRDtBQUM5QyxRQUFJN0IsR0FBRyw4Q0FBdUNTLE9BQXZDLDZCQUFpRW9CLFNBQWpFLENBQVA7QUFDQSxRQUFJYixNQUFNLEdBQUdqQixZQUFZLENBQUNDLEdBQUQsQ0FBekI7O0FBQ0EsUUFBSWdCLE1BQU0sSUFBSUEsTUFBTSxDQUFDb0IsSUFBckIsRUFBMkI7QUFDdkIsVUFBSWlCLGFBQWEsR0FBRyxFQUFwQjtBQUNBckMsWUFBTSxDQUFDb0IsSUFBUCxDQUFZSyxPQUFaLENBQXFCYSxZQUFELElBQWtCO0FBQ2xDLFlBQUlYLE9BQU8sR0FBR1csWUFBWSxDQUFDWCxPQUEzQjtBQUNBVSxxQkFBYSxDQUFDQyxZQUFZLENBQUNDLHFCQUFkLENBQWIsR0FBb0Q7QUFDaERDLGVBQUssRUFBRWIsT0FBTyxDQUFDbkIsTUFEaUM7QUFFaERnQix3QkFBYyxFQUFFRyxPQUFPLENBQUMsQ0FBRCxDQUFQLENBQVdHO0FBRnFCLFNBQXBEO0FBSUgsT0FORDtBQU9BLGFBQU9PLGFBQVA7QUFDSDtBQUNKOztBQWpMVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDZkEsSUFBSTVELE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUErQyxJQUFJNkQsT0FBSjtBQUFZL0QsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0JBQVosRUFBNkI7QUFBQzhELFNBQU8sQ0FBQzdELENBQUQsRUFBRztBQUFDNkQsV0FBTyxHQUFDN0QsQ0FBUjtBQUFVOztBQUF0QixDQUE3QixFQUFxRCxDQUFyRDtBQUF3RCxJQUFJOEQsU0FBSjtBQUFjaEUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0JBQVosRUFBNEM7QUFBQytELFdBQVMsQ0FBQzlELENBQUQsRUFBRztBQUFDOEQsYUFBUyxHQUFDOUQsQ0FBVjtBQUFZOztBQUExQixDQUE1QyxFQUF3RSxDQUF4RTtBQUEyRSxJQUFJK0QsS0FBSjtBQUFVakUsTUFBTSxDQUFDQyxJQUFQLENBQVksNkJBQVosRUFBMEM7QUFBQ2dFLE9BQUssQ0FBQy9ELENBQUQsRUFBRztBQUFDK0QsU0FBSyxHQUFDL0QsQ0FBTjtBQUFROztBQUFsQixDQUExQyxFQUE4RCxDQUE5RDtBQUFpRSxJQUFJZ0UsYUFBSjtBQUFrQmxFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtDQUFaLEVBQTREO0FBQUNpRSxlQUFhLENBQUNoRSxDQUFELEVBQUc7QUFBQ2dFLGlCQUFhLEdBQUNoRSxDQUFkO0FBQWdCOztBQUFsQyxDQUE1RCxFQUFnRyxDQUFoRztBQUFtRyxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVDQUFaLEVBQW9EO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUFwRCxFQUFrRixDQUFsRjtBQUFxRixJQUFJaUUsZ0JBQUosRUFBcUJDLFNBQXJCLEVBQStCQyxlQUEvQjtBQUErQ3JFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGlDQUFaLEVBQThDO0FBQUNrRSxrQkFBZ0IsQ0FBQ2pFLENBQUQsRUFBRztBQUFDaUUsb0JBQWdCLEdBQUNqRSxDQUFqQjtBQUFtQixHQUF4Qzs7QUFBeUNrRSxXQUFTLENBQUNsRSxDQUFELEVBQUc7QUFBQ2tFLGFBQVMsR0FBQ2xFLENBQVY7QUFBWSxHQUFsRTs7QUFBbUVtRSxpQkFBZSxDQUFDbkUsQ0FBRCxFQUFHO0FBQUNtRSxtQkFBZSxHQUFDbkUsQ0FBaEI7QUFBa0I7O0FBQXhHLENBQTlDLEVBQXdKLENBQXhKO0FBQTJKLElBQUlvRSxrQkFBSjtBQUF1QnRFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNDQUFaLEVBQW1EO0FBQUNxRSxvQkFBa0IsQ0FBQ3BFLENBQUQsRUFBRztBQUFDb0Usc0JBQWtCLEdBQUNwRSxDQUFuQjtBQUFxQjs7QUFBNUMsQ0FBbkQsRUFBaUcsQ0FBakc7QUFBb0csSUFBSXFFLFlBQUo7QUFBaUJ2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDc0UsY0FBWSxDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxnQkFBWSxHQUFDckUsQ0FBYjtBQUFlOztBQUFoQyxDQUFqRCxFQUFtRixDQUFuRjtBQUFzRixJQUFJc0UsU0FBSjtBQUFjeEUsTUFBTSxDQUFDQyxJQUFQLENBQVksOEJBQVosRUFBMkM7QUFBQ3VFLFdBQVMsQ0FBQ3RFLENBQUQsRUFBRztBQUFDc0UsYUFBUyxHQUFDdEUsQ0FBVjtBQUFZOztBQUExQixDQUEzQyxFQUF1RSxFQUF2RTtBQUEyRSxJQUFJdUUsTUFBSjtBQUFXekUsTUFBTSxDQUFDQyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDd0UsUUFBTSxDQUFDdkUsQ0FBRCxFQUFHO0FBQUN1RSxVQUFNLEdBQUN2RSxDQUFQO0FBQVM7O0FBQXBCLENBQXhCLEVBQThDLEVBQTlDO0FBQWtELElBQUl3RSxVQUFKO0FBQWUxRSxNQUFNLENBQUNDLElBQVAsQ0FBWSx1QkFBWixFQUFvQztBQUFDeUUsWUFBVSxDQUFDeEUsQ0FBRCxFQUFHO0FBQUN3RSxjQUFVLEdBQUN4RSxDQUFYO0FBQWE7O0FBQTVCLENBQXBDLEVBQWtFLEVBQWxFO0FBQXNFLElBQUl5RSxPQUFKO0FBQVkzRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxTQUFaLEVBQXNCO0FBQUMsTUFBSUMsQ0FBSixFQUFNO0FBQUN5RSxXQUFPLEdBQUN6RSxDQUFSO0FBQVU7O0FBQWxCLENBQXRCLEVBQTBDLEVBQTFDOztBQWU1dEM7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBMEUsb0JBQW9CLEdBQUcsQ0FBQ0MsY0FBRCxFQUFpQkMsVUFBakIsS0FBZ0M7QUFDbkQ7QUFDQSxPQUFLQyxDQUFMLElBQVVGLGNBQVYsRUFBeUI7QUFDckIsU0FBSzNFLENBQUwsSUFBVTRFLFVBQVYsRUFBcUI7QUFDakIsVUFBSUQsY0FBYyxDQUFDRSxDQUFELENBQWQsQ0FBa0JoRSxPQUFsQixJQUE2QitELFVBQVUsQ0FBQzVFLENBQUQsQ0FBVixDQUFjYSxPQUEvQyxFQUF1RDtBQUNuRDhELHNCQUFjLENBQUNHLE1BQWYsQ0FBc0JELENBQXRCLEVBQXdCLENBQXhCO0FBQ0g7QUFDSjtBQUNKOztBQUVELFNBQU9GLGNBQVA7QUFDSCxDQVhEOztBQWFBSSxzQkFBc0IsR0FBSUMsUUFBRCxJQUFjO0FBQ25DLE1BQUlBLFFBQVEsQ0FBQ3BELE1BQVQsSUFBbUIsRUFBdkIsRUFBMEI7QUFDdEIsUUFBSVosUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsb0VBQXFFMEUsUUFBckUsc0JBQWY7O0FBQ0EsUUFBSWhFLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUFnQztBQUM1QixVQUFJeUUsSUFBSSxHQUFHakUsUUFBUSxDQUFDd0IsSUFBVCxDQUFjeUMsSUFBekI7QUFDQSxhQUFPQSxJQUFJLElBQUlBLElBQUksQ0FBQ3JELE1BQWIsSUFBdUJxRCxJQUFJLENBQUMsQ0FBRCxDQUFKLENBQVFDLFFBQS9CLElBQTJDRCxJQUFJLENBQUMsQ0FBRCxDQUFKLENBQVFDLFFBQVIsQ0FBaUJDLE9BQTVELElBQXVFRixJQUFJLENBQUMsQ0FBRCxDQUFKLENBQVFDLFFBQVIsQ0FBaUJDLE9BQWpCLENBQXlCL0UsR0FBdkc7QUFDSCxLQUhELE1BR087QUFDSE0sYUFBTyxDQUFDQyxHQUFSLENBQVlNLElBQUksQ0FBQ21FLFNBQUwsQ0FBZXBFLFFBQWYsQ0FBWjtBQUNIO0FBQ0osR0FSRCxNQVFPLElBQUlnRSxRQUFRLENBQUNLLE9BQVQsQ0FBaUIsa0JBQWpCLElBQXFDLENBQXpDLEVBQTJDO0FBQzlDLFFBQUlDLFFBQVEsR0FBR3JGLElBQUksQ0FBQ0ssR0FBTCxDQUFTMEUsUUFBVCxDQUFmOztBQUNBLFFBQUlNLFFBQVEsQ0FBQzlFLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0IsVUFBSStFLElBQUksR0FBR2QsT0FBTyxDQUFDZSxJQUFSLENBQWFGLFFBQVEsQ0FBQ25FLE9BQXRCLENBQVg7QUFDQSxhQUFPb0UsSUFBSSxDQUFDLG1CQUFELENBQUosQ0FBMEJFLElBQTFCLENBQStCLEtBQS9CLENBQVA7QUFDSCxLQUhELE1BR087QUFDSC9FLGFBQU8sQ0FBQ0MsR0FBUixDQUFZTSxJQUFJLENBQUNtRSxTQUFMLENBQWVFLFFBQWYsQ0FBWjtBQUNIO0FBQ0o7QUFDSixDQWxCRCxDLENBb0JBO0FBQ0E7OztBQUVBekYsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCw0QkFBMEJDLE9BQTFCLEVBQWtDO0FBQzlCLFFBQUk2RSxNQUFNLEdBQUc1QixTQUFTLENBQUM2QixJQUFWLENBQWU7QUFBQ0MscUJBQWUsRUFBQy9FO0FBQWpCLEtBQWYsRUFBMENnRixLQUExQyxFQUFiO0FBQ0EsUUFBSUMsT0FBTyxHQUFHSixNQUFNLENBQUNLLEdBQVAsQ0FBVyxDQUFDQyxLQUFELEVBQVF6QyxDQUFSLEtBQWM7QUFDbkMsYUFBT3lDLEtBQUssQ0FBQ0MsTUFBYjtBQUNILEtBRmEsQ0FBZDtBQUdBLFFBQUlDLFdBQVcsR0FBR2hDLFNBQVMsQ0FBQ3lCLElBQVYsQ0FBZTtBQUFDTSxZQUFNLEVBQUM7QUFBQ0UsV0FBRyxFQUFDTDtBQUFMO0FBQVIsS0FBZixFQUF1Q0QsS0FBdkMsRUFBbEIsQ0FMOEIsQ0FNOUI7O0FBRUEsUUFBSU8sY0FBYyxHQUFHLENBQXJCOztBQUNBLFNBQUtDLENBQUwsSUFBVUgsV0FBVixFQUFzQjtBQUNsQkUsb0JBQWMsSUFBSUYsV0FBVyxDQUFDRyxDQUFELENBQVgsQ0FBZUMsUUFBakM7QUFDSDs7QUFDRCxXQUFPRixjQUFjLEdBQUNOLE9BQU8sQ0FBQ2xFLE1BQTlCO0FBQ0gsR0FkVTs7QUFlWCxzQkFBb0JmLE9BQXBCLEVBQTRCO0FBQ3hCLFFBQUkwRixVQUFVLEdBQUd0QyxnQkFBZ0IsQ0FBQ3VDLGFBQWpCLEVBQWpCLENBRHdCLENBRXhCOztBQUNBLFFBQUlDLFFBQVEsR0FBRyxDQUNYO0FBQUNDLFlBQU0sRUFBQztBQUFDLG1CQUFVN0Y7QUFBWDtBQUFSLEtBRFcsRUFFWDtBQUNBO0FBQUM4RixXQUFLLEVBQUM7QUFBQyxrQkFBUyxDQUFDO0FBQVg7QUFBUCxLQUhXLEVBSVg7QUFBQ0MsWUFBTSxFQUFFL0csTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJDLFlBQXZCLEdBQW9DO0FBQTdDLEtBSlcsRUFLWDtBQUFDQyxhQUFPLEVBQUU7QUFBVixLQUxXLEVBTVg7QUFBQ0MsWUFBTSxFQUFDO0FBQ0osZUFBTyxVQURIO0FBRUosa0JBQVU7QUFDTixrQkFBTztBQUNIQyxpQkFBSyxFQUFFLENBQUM7QUFBQ0MsaUJBQUcsRUFBRSxDQUFDLFNBQUQsRUFBWSxJQUFaO0FBQU4sYUFBRCxFQUEyQixDQUEzQixFQUE4QixDQUE5QjtBQURKO0FBREQ7QUFGTjtBQUFSLEtBTlcsQ0FBZixDQUh3QixDQWtCeEI7O0FBRUEsV0FBT3RELE9BQU8sQ0FBQ3VELEtBQVIsQ0FBY2IsVUFBVSxDQUFDYyxTQUFYLENBQXFCWixRQUFyQixFQUErQmEsT0FBL0IsRUFBZCxDQUFQLENBcEJ3QixDQXFCeEI7QUFDSCxHQXJDVTs7QUFzQ1gsNEJBQTBCLFlBQVc7QUFDakMsU0FBS3hHLE9BQUw7QUFDQSxRQUFJVixHQUFHLEdBQUdtSCxHQUFHLEdBQUMsU0FBZDs7QUFDQSxRQUFHO0FBQ0MsVUFBSXZHLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjtBQUNBLFVBQUlvSCxNQUFNLEdBQUd2RyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFiO0FBQ0EsYUFBUXFHLE1BQU0sQ0FBQ3BHLE1BQVAsQ0FBY3FHLFNBQWQsQ0FBd0JDLG1CQUFoQztBQUNILEtBSkQsQ0FLQSxPQUFPakgsQ0FBUCxFQUFTO0FBQ0wsYUFBTyxDQUFQO0FBQ0g7QUFDSixHQWpEVTtBQWtEWCw2QkFBMkIsWUFBVztBQUNsQyxTQUFLSyxPQUFMO0FBQ0EsUUFBSTZHLFVBQVUsR0FBRzdELFNBQVMsQ0FBQzZCLElBQVYsQ0FBZSxFQUFmLEVBQWtCO0FBQUNpQyxVQUFJLEVBQUM7QUFBQzNCLGNBQU0sRUFBQyxDQUFDO0FBQVQsT0FBTjtBQUFrQjRCLFdBQUssRUFBQztBQUF4QixLQUFsQixFQUE4Q2hDLEtBQTlDLEVBQWpCLENBRmtDLENBR2xDOztBQUNBLFFBQUlpQyxXQUFXLEdBQUdqSSxNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUJELFdBQXpDOztBQUNBLFFBQUlILFVBQVUsSUFBSUEsVUFBVSxDQUFDL0YsTUFBWCxJQUFxQixDQUF2QyxFQUEwQztBQUN0QyxVQUFJcUUsTUFBTSxHQUFHMEIsVUFBVSxDQUFDLENBQUQsQ0FBVixDQUFjMUIsTUFBM0I7QUFDQSxVQUFJQSxNQUFNLEdBQUc2QixXQUFiLEVBQ0ksT0FBTzdCLE1BQVA7QUFDUDs7QUFDRCxXQUFPNkIsV0FBUDtBQUNILEdBN0RVO0FBOERYLHlCQUF1QixZQUFXO0FBQzlCLFFBQUlFLE9BQUosRUFDSSxPQUFPLFlBQVAsQ0FESixLQUVLdEgsT0FBTyxDQUFDQyxHQUFSLENBQVksZUFBWixFQUh5QixDQUk5QjtBQUNBOztBQUNBLFFBQUlzSCxLQUFLLEdBQUdwSSxNQUFNLENBQUNxSSxJQUFQLENBQVksd0JBQVosQ0FBWixDQU44QixDQU85QjtBQUNBOztBQUNBLFFBQUlDLElBQUksR0FBR3RJLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSx5QkFBWixDQUFYO0FBQ0F4SCxXQUFPLENBQUNDLEdBQVIsQ0FBWXdILElBQVosRUFWOEIsQ0FXOUI7O0FBQ0EsUUFBSUYsS0FBSyxHQUFHRSxJQUFaLEVBQWtCO0FBQ2RILGFBQU8sR0FBRyxJQUFWO0FBRUEsVUFBSUksWUFBWSxHQUFHLEVBQW5CLENBSGMsQ0FJZDs7QUFDQWhJLFNBQUcsR0FBR0csR0FBRyxHQUFDLHFCQUFWOztBQUVBLFVBQUc7QUFDQ1MsZ0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBYSxZQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBN0IsQ0FBb0N5QixPQUFwQyxDQUE2Q1osU0FBRCxJQUFlbUcsWUFBWSxDQUFDbkcsU0FBUyxDQUFDb0csZ0JBQVgsQ0FBWixHQUEyQ3BHLFNBQXRHO0FBQ0gsT0FIRCxDQUlBLE9BQU14QixDQUFOLEVBQVE7QUFDSkMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFFREwsU0FBRyxHQUFHRyxHQUFHLEdBQUMsc0NBQVY7O0FBRUEsVUFBRztBQUNDUyxnQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0FhLFlBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE3QixDQUFvQ3lCLE9BQXBDLENBQTZDWixTQUFELElBQWVtRyxZQUFZLENBQUNuRyxTQUFTLENBQUNvRyxnQkFBWCxDQUFaLEdBQTJDcEcsU0FBdEc7QUFDSCxPQUhELENBSUEsT0FBTXhCLENBQU4sRUFBUTtBQUNKQyxlQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUVETCxTQUFHLEdBQUdHLEdBQUcsR0FBQyxxQ0FBVjs7QUFFQSxVQUFHO0FBQ0NTLGdCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQWEsWUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTdCLENBQW9DeUIsT0FBcEMsQ0FBNkNaLFNBQUQsSUFBZW1HLFlBQVksQ0FBQ25HLFNBQVMsQ0FBQ29HLGdCQUFYLENBQVosR0FBMkNwRyxTQUF0RztBQUNILE9BSEQsQ0FJQSxPQUFNeEIsQ0FBTixFQUFRO0FBQ0pDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBQ0QsVUFBSTZILGVBQWUsR0FBR0MsTUFBTSxDQUFDQyxJQUFQLENBQVlKLFlBQVosRUFBMEJ4RyxNQUFoRDtBQUNBbEIsYUFBTyxDQUFDQyxHQUFSLENBQVkscUJBQW9CMkgsZUFBaEM7O0FBQ0EsV0FBSyxJQUFJckMsTUFBTSxHQUFHa0MsSUFBSSxHQUFDLENBQXZCLEVBQTJCbEMsTUFBTSxJQUFJZ0MsS0FBckMsRUFBNkNoQyxNQUFNLEVBQW5ELEVBQXVEO0FBQ25ELFlBQUl3QyxjQUFjLEdBQUcsSUFBSXhGLElBQUosRUFBckIsQ0FEbUQsQ0FFbkQ7O0FBQ0EsYUFBS25DLE9BQUw7QUFDQSxZQUFJVixHQUFHLEdBQUdtSCxHQUFHLEdBQUMsZ0JBQUosR0FBdUJ0QixNQUFqQztBQUNBLFlBQUl5QyxhQUFhLEdBQUcsRUFBcEI7QUFFQWhJLGVBQU8sQ0FBQ0MsR0FBUixDQUFZUCxHQUFaOztBQUNBLFlBQUc7QUFDQyxnQkFBTXVJLGNBQWMsR0FBR3pJLFVBQVUsQ0FBQ3NHLGFBQVgsR0FBMkJvQyx5QkFBM0IsRUFBdkI7QUFDQSxnQkFBTUMsb0JBQW9CLEdBQUc1RSxnQkFBZ0IsQ0FBQ3VDLGFBQWpCLEdBQWlDb0MseUJBQWpDLEVBQTdCO0FBQ0EsZ0JBQU1FLGFBQWEsR0FBRzFFLGtCQUFrQixDQUFDb0MsYUFBbkIsR0FBbUNvQyx5QkFBbkMsRUFBdEI7QUFDQSxnQkFBTUcsZUFBZSxHQUFHMUUsWUFBWSxDQUFDbUMsYUFBYixHQUE2Qm9DLHlCQUE3QixFQUF4QjtBQUVBLGNBQUlJLGtCQUFrQixHQUFHLElBQUkvRixJQUFKLEVBQXpCO0FBQ0EsY0FBSWpDLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjs7QUFDQSxjQUFJWSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0IsZ0JBQUl3RixLQUFLLEdBQUcvRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFaO0FBQ0E2RSxpQkFBSyxHQUFHQSxLQUFLLENBQUM1RSxNQUFkLENBRjJCLENBRzNCOztBQUNBLGdCQUFJNkgsU0FBUyxHQUFHLEVBQWhCO0FBQ0FBLHFCQUFTLENBQUNoRCxNQUFWLEdBQW1CQSxNQUFuQjtBQUNBZ0QscUJBQVMsQ0FBQ0MsSUFBVixHQUFpQmxELEtBQUssQ0FBQ21ELFVBQU4sQ0FBaUJDLFFBQWpCLENBQTBCRixJQUEzQztBQUNBRCxxQkFBUyxDQUFDSSxRQUFWLEdBQXFCckQsS0FBSyxDQUFDbUQsVUFBTixDQUFpQkcsTUFBakIsQ0FBd0JDLE9BQTdDO0FBQ0FOLHFCQUFTLENBQUNqRyxJQUFWLEdBQWlCLElBQUlDLElBQUosQ0FBUytDLEtBQUssQ0FBQ0EsS0FBTixDQUFZc0QsTUFBWixDQUFtQnRHLElBQTVCLENBQWpCO0FBQ0FpRyxxQkFBUyxDQUFDTyxhQUFWLEdBQTBCeEQsS0FBSyxDQUFDQSxLQUFOLENBQVlzRCxNQUFaLENBQW1CRyxhQUFuQixDQUFpQ1AsSUFBM0Q7QUFDQUQscUJBQVMsQ0FBQ3JELGVBQVYsR0FBNEJJLEtBQUssQ0FBQ0EsS0FBTixDQUFZc0QsTUFBWixDQUFtQkksZ0JBQS9DO0FBQ0FULHFCQUFTLENBQUNyRSxVQUFWLEdBQXVCLEVBQXZCO0FBQ0EsZ0JBQUkrRSxVQUFVLEdBQUczRCxLQUFLLENBQUNBLEtBQU4sQ0FBWTRELFdBQVosQ0FBd0JELFVBQXpDOztBQUNBLGdCQUFJQSxVQUFVLElBQUksSUFBbEIsRUFBdUI7QUFDbkI7QUFDQSxtQkFBSyxJQUFJcEcsQ0FBQyxHQUFDLENBQVgsRUFBY0EsQ0FBQyxHQUFDb0csVUFBVSxDQUFDL0gsTUFBM0IsRUFBbUMyQixDQUFDLEVBQXBDLEVBQXVDO0FBQ25DLG9CQUFJb0csVUFBVSxDQUFDcEcsQ0FBRCxDQUFWLElBQWlCLElBQXJCLEVBQTBCO0FBQ3RCMEYsMkJBQVMsQ0FBQ3JFLFVBQVYsQ0FBcUJpRixJQUFyQixDQUEwQkYsVUFBVSxDQUFDcEcsQ0FBRCxDQUFWLENBQWN1RyxpQkFBeEM7QUFDSDtBQUNKOztBQUVEcEIsMkJBQWEsQ0FBQ2lCLFVBQWQsR0FBMkJBLFVBQVUsQ0FBQy9ILE1BQXRDLENBUm1CLENBU25CO0FBQ0E7QUFDSCxhQXhCMEIsQ0EwQjNCOzs7QUFDQSxnQkFBSW9FLEtBQUssQ0FBQ0EsS0FBTixDQUFZeEQsSUFBWixDQUFpQnVILEdBQWpCLElBQXdCL0QsS0FBSyxDQUFDQSxLQUFOLENBQVl4RCxJQUFaLENBQWlCdUgsR0FBakIsQ0FBcUJuSSxNQUFyQixHQUE4QixDQUExRCxFQUE0RDtBQUN4RCxtQkFBS29JLENBQUwsSUFBVWhFLEtBQUssQ0FBQ0EsS0FBTixDQUFZeEQsSUFBWixDQUFpQnVILEdBQTNCLEVBQStCO0FBQzNCbEssc0JBQU0sQ0FBQ3FJLElBQVAsQ0FBWSxvQkFBWixFQUFrQzNELE1BQU0sQ0FBQzBGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZbEUsS0FBSyxDQUFDQSxLQUFOLENBQVl4RCxJQUFaLENBQWlCdUgsR0FBakIsQ0FBcUJDLENBQXJCLENBQVosRUFBcUMsUUFBckMsQ0FBRCxDQUF4QyxFQUEwRmYsU0FBUyxDQUFDakcsSUFBcEcsRUFBMEcsQ0FBQ21ILEdBQUQsRUFBTS9JLE1BQU4sS0FBaUI7QUFDdkgsc0JBQUkrSSxHQUFKLEVBQVE7QUFDSnpKLDJCQUFPLENBQUNDLEdBQVIsQ0FBWXdKLEdBQVo7QUFDSDtBQUNKLGlCQUpEO0FBS0g7QUFDSixhQW5DMEIsQ0FxQzNCOzs7QUFDQSxnQkFBSW5FLEtBQUssQ0FBQ0EsS0FBTixDQUFZb0UsUUFBWixDQUFxQkEsUUFBekIsRUFBa0M7QUFDOUI5Rix1QkFBUyxDQUFDK0YsTUFBVixDQUFpQjtBQUNicEUsc0JBQU0sRUFBRUEsTUFESztBQUVibUUsd0JBQVEsRUFBRXBFLEtBQUssQ0FBQ0EsS0FBTixDQUFZb0UsUUFBWixDQUFxQkE7QUFGbEIsZUFBakI7QUFJSDs7QUFFRG5CLHFCQUFTLENBQUNxQixlQUFWLEdBQTRCckIsU0FBUyxDQUFDckUsVUFBVixDQUFxQmhELE1BQWpEO0FBRUE4Ryx5QkFBYSxDQUFDekMsTUFBZCxHQUF1QkEsTUFBdkI7QUFFQSxnQkFBSXNFLGdCQUFnQixHQUFHLElBQUl0SCxJQUFKLEVBQXZCO0FBQ0F2QyxtQkFBTyxDQUFDQyxHQUFSLENBQVksc0JBQXFCLENBQUM0SixnQkFBZ0IsR0FBQ3ZCLGtCQUFsQixJQUFzQyxJQUEzRCxHQUFpRSxVQUE3RTtBQUdBLGdCQUFJd0Isc0JBQXNCLEdBQUcsSUFBSXZILElBQUosRUFBN0IsQ0FyRDJCLENBc0QzQjs7QUFDQTdDLGVBQUcsR0FBR21ILEdBQUcsR0FBQyxxQkFBSixHQUEwQnRCLE1BQWhDO0FBQ0FqRixvQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0FNLG1CQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjtBQUNBLGdCQUFJd0UsVUFBVSxHQUFHM0QsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBakI7QUFDQXlELHNCQUFVLENBQUN4RCxNQUFYLENBQWtCcUosWUFBbEIsR0FBaUNDLFFBQVEsQ0FBQzlGLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0JxSixZQUFuQixDQUF6QztBQUNBekcseUJBQWEsQ0FBQ3FHLE1BQWQsQ0FBcUJ6RixVQUFVLENBQUN4RCxNQUFoQztBQUVBNkgscUJBQVMsQ0FBQzBCLGVBQVYsR0FBNEIvRixVQUFVLENBQUN4RCxNQUFYLENBQWtCd0QsVUFBbEIsQ0FBNkJoRCxNQUF6RDtBQUNBLGdCQUFJZ0osb0JBQW9CLEdBQUcsSUFBSTNILElBQUosRUFBM0I7QUFDQWEscUJBQVMsQ0FBQ3VHLE1BQVYsQ0FBaUJwQixTQUFqQjtBQUNBLGdCQUFJNEIsa0JBQWtCLEdBQUcsSUFBSTVILElBQUosRUFBekI7QUFDQXZDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBdUIsQ0FBQ2tLLGtCQUFrQixHQUFDRCxvQkFBcEIsSUFBMEMsSUFBakUsR0FBdUUsVUFBbkYsRUFsRTJCLENBb0UzQjs7QUFDQSxnQkFBSUUsa0JBQWtCLEdBQUc1SyxVQUFVLENBQUN5RixJQUFYLENBQWdCO0FBQUM5RSxxQkFBTyxFQUFDO0FBQUNrSyx1QkFBTyxFQUFDO0FBQVQ7QUFBVCxhQUFoQixFQUEwQ2xGLEtBQTFDLEVBQXpCOztBQUVBLGdCQUFJSSxNQUFNLEdBQUcsQ0FBYixFQUFlO0FBQ1g7QUFDQTtBQUNBLG1CQUFLMUMsQ0FBTCxJQUFVcUIsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQTVCLEVBQXVDO0FBQ25DLG9CQUFJL0QsT0FBTyxHQUFHK0QsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQWxCLENBQTZCckIsQ0FBN0IsRUFBZ0MxQyxPQUE5QztBQUNBLG9CQUFJbUssTUFBTSxHQUFHO0FBQ1QvRSx3QkFBTSxFQUFFQSxNQURDO0FBRVRwRix5QkFBTyxFQUFFQSxPQUZBO0FBR1RvSyx3QkFBTSxFQUFFLEtBSEM7QUFJVEMsOEJBQVksRUFBRVIsUUFBUSxDQUFDOUYsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQWxCLENBQTZCckIsQ0FBN0IsRUFBZ0MySCxZQUFqQyxDQUpiLENBSTJEOztBQUozRCxpQkFBYjs7QUFPQSxxQkFBS0MsQ0FBTCxJQUFVeEIsVUFBVixFQUFxQjtBQUNqQixzQkFBSUEsVUFBVSxDQUFDd0IsQ0FBRCxDQUFWLElBQWlCLElBQXJCLEVBQTBCO0FBQ3RCLHdCQUFJdEssT0FBTyxJQUFJOEksVUFBVSxDQUFDd0IsQ0FBRCxDQUFWLENBQWNyQixpQkFBN0IsRUFBK0M7QUFDM0NrQiw0QkFBTSxDQUFDQyxNQUFQLEdBQWdCLElBQWhCO0FBQ0F0QixnQ0FBVSxDQUFDN0UsTUFBWCxDQUFrQnFHLENBQWxCLEVBQW9CLENBQXBCO0FBQ0E7QUFDSDtBQUNKO0FBQ0osaUJBakJrQyxDQW1CbkM7QUFDQTs7O0FBRUEsb0JBQUtsRixNQUFNLEdBQUcsRUFBVixJQUFpQixDQUFyQixFQUF1QjtBQUNuQjtBQUNBLHNCQUFJbUYsU0FBUyxHQUFHdkwsTUFBTSxDQUFDcUksSUFBUCxDQUFZLG1CQUFaLEVBQWlDckgsT0FBakMsQ0FBaEI7QUFDQSxzQkFBSXdLLE1BQU0sR0FBRyxDQUFiLENBSG1CLENBSW5CO0FBQ0E7O0FBQ0Esc0JBQUtELFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsSUFBakIsSUFBMkJBLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYUMsTUFBYixJQUF1QixJQUF0RCxFQUE0RDtBQUN4REEsMEJBQU0sR0FBR0QsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhQyxNQUF0QjtBQUNIOztBQUVELHNCQUFJQyxJQUFJLEdBQUd6TCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QkMsWUFBbEM7O0FBQ0Esc0JBQUlkLE1BQU0sR0FBR3FGLElBQWIsRUFBa0I7QUFDZEEsd0JBQUksR0FBR3JGLE1BQVA7QUFDSDs7QUFFRCxzQkFBSStFLE1BQU0sQ0FBQ0MsTUFBWCxFQUFrQjtBQUNkLHdCQUFJSSxNQUFNLEdBQUdDLElBQWIsRUFBa0I7QUFDZEQsNEJBQU07QUFDVDs7QUFDREEsMEJBQU0sR0FBSUEsTUFBTSxHQUFHQyxJQUFWLEdBQWdCLEdBQXpCO0FBQ0EzQyxrQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDOUUsNkJBQU8sRUFBQ0E7QUFBVCxxQkFBcEIsRUFBdUMwSyxNQUF2QyxHQUFnREMsU0FBaEQsQ0FBMEQ7QUFBQ0MsMEJBQUksRUFBQztBQUFDSiw4QkFBTSxFQUFDQSxNQUFSO0FBQWdCSyxnQ0FBUSxFQUFDekMsU0FBUyxDQUFDakc7QUFBbkM7QUFBTixxQkFBMUQ7QUFDSCxtQkFORCxNQU9JO0FBQ0FxSSwwQkFBTSxHQUFJQSxNQUFNLEdBQUdDLElBQVYsR0FBZ0IsR0FBekI7QUFDQTNDLGtDQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUM5RSw2QkFBTyxFQUFDQTtBQUFULHFCQUFwQixFQUF1QzBLLE1BQXZDLEdBQWdEQyxTQUFoRCxDQUEwRDtBQUFDQywwQkFBSSxFQUFDO0FBQUNKLDhCQUFNLEVBQUNBO0FBQVI7QUFBTixxQkFBMUQ7QUFDSDtBQUNKOztBQUVEeEMsb0NBQW9CLENBQUN3QixNQUFyQixDQUE0QlcsTUFBNUIsRUFsRG1DLENBbURuQztBQUNIO0FBQ0o7O0FBRUQsZ0JBQUlXLFdBQVcsR0FBRzVILEtBQUssQ0FBQzdCLE9BQU4sQ0FBYztBQUFDMEoscUJBQU8sRUFBQzVGLEtBQUssQ0FBQ21ELFVBQU4sQ0FBaUJHLE1BQWpCLENBQXdCdUM7QUFBakMsYUFBZCxDQUFsQjtBQUNBLGdCQUFJQyxjQUFjLEdBQUdILFdBQVcsR0FBQ0EsV0FBVyxDQUFDRyxjQUFiLEdBQTRCLENBQTVEO0FBQ0EsZ0JBQUl4RixRQUFKO0FBQ0EsZ0JBQUl5RixTQUFTLEdBQUdsTSxNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUJpRSxnQkFBdkM7O0FBQ0EsZ0JBQUlGLGNBQUosRUFBbUI7QUFDZixrQkFBSUcsVUFBVSxHQUFHaEQsU0FBUyxDQUFDakcsSUFBM0I7QUFDQSxrQkFBSWtKLFFBQVEsR0FBRyxJQUFJakosSUFBSixDQUFTNkksY0FBVCxDQUFmO0FBQ0F4RixzQkFBUSxHQUFHNkYsSUFBSSxDQUFDQyxHQUFMLENBQVNILFVBQVUsQ0FBQ0ksT0FBWCxLQUF1QkgsUUFBUSxDQUFDRyxPQUFULEVBQWhDLENBQVg7QUFDQU4sdUJBQVMsR0FBRyxDQUFDSixXQUFXLENBQUNJLFNBQVosSUFBeUI5QyxTQUFTLENBQUNoRCxNQUFWLEdBQW1CLENBQTVDLElBQWlESyxRQUFsRCxJQUE4RDJDLFNBQVMsQ0FBQ2hELE1BQXBGO0FBQ0g7O0FBRUQsZ0JBQUlxRyxvQkFBb0IsR0FBRyxJQUFJckosSUFBSixFQUEzQjtBQUNBdkMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLGlDQUFnQyxDQUFDMkwsb0JBQW9CLEdBQUM5QixzQkFBdEIsSUFBOEMsSUFBOUUsR0FBb0YsVUFBaEc7QUFFQXpHLGlCQUFLLENBQUN3SSxNQUFOLENBQWE7QUFBQ1gscUJBQU8sRUFBQzVGLEtBQUssQ0FBQ21ELFVBQU4sQ0FBaUJHLE1BQWpCLENBQXdCdUM7QUFBakMsYUFBYixFQUF5RDtBQUFDSixrQkFBSSxFQUFDO0FBQUNLLDhCQUFjLEVBQUM3QyxTQUFTLENBQUNqRyxJQUExQjtBQUFnQytJLHlCQUFTLEVBQUNBO0FBQTFDO0FBQU4sYUFBekQ7QUFFQXJELHlCQUFhLENBQUM4RCxnQkFBZCxHQUFpQ1QsU0FBakM7QUFDQXJELHlCQUFhLENBQUNwQyxRQUFkLEdBQXlCQSxRQUF6QjtBQUVBb0MseUJBQWEsQ0FBQzFGLElBQWQsR0FBcUJpRyxTQUFTLENBQUNqRyxJQUEvQixDQXBKMkIsQ0FzSjNCO0FBQ0E7QUFDQTtBQUNBOztBQUVBMEYseUJBQWEsQ0FBQ3dDLFlBQWQsR0FBNkIsQ0FBN0I7QUFFQSxnQkFBSXVCLDJCQUEyQixHQUFHLElBQUl4SixJQUFKLEVBQWxDOztBQUNBLGdCQUFJMkIsVUFBVSxDQUFDeEQsTUFBZixFQUFzQjtBQUNsQjtBQUNBVixxQkFBTyxDQUFDQyxHQUFSLENBQVksd0JBQXNCaUUsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQWxCLENBQTZCaEQsTUFBL0Q7O0FBQ0EsbUJBQUs1QixDQUFMLElBQVU0RSxVQUFVLENBQUN4RCxNQUFYLENBQWtCd0QsVUFBNUIsRUFBdUM7QUFDbkM7QUFDQSxvQkFBSTNDLFNBQVMsR0FBRzJDLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0J3RCxVQUFsQixDQUE2QjVFLENBQTdCLENBQWhCO0FBQ0FpQyx5QkFBUyxDQUFDaUosWUFBVixHQUF5QlIsUUFBUSxDQUFDekksU0FBUyxDQUFDaUosWUFBWCxDQUFqQztBQUNBakoseUJBQVMsQ0FBQ3lLLGlCQUFWLEdBQThCaEMsUUFBUSxDQUFDekksU0FBUyxDQUFDeUssaUJBQVgsQ0FBdEM7QUFFQSxvQkFBSUMsUUFBUSxHQUFHek0sVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDLG1DQUFnQkQsU0FBUyxDQUFDMkssT0FBVixDQUFrQnJMO0FBQW5DLGlCQUFuQixDQUFmOztBQUNBLG9CQUFJLENBQUNvTCxRQUFMLEVBQWM7QUFDVmpNLHlCQUFPLENBQUNDLEdBQVIsNkJBQWlDc0IsU0FBUyxDQUFDcEIsT0FBM0MsY0FBc0RvQixTQUFTLENBQUMySyxPQUFWLENBQWtCckwsS0FBeEUsaUJBRFUsQ0FFVjtBQUNBO0FBQ0E7O0FBRUFVLDJCQUFTLENBQUNwQixPQUFWLEdBQW9CMkQsVUFBVSxDQUFDdkMsU0FBUyxDQUFDMkssT0FBWCxDQUE5QjtBQUNBM0ssMkJBQVMsQ0FBQzRLLE1BQVYsR0FBbUJoTixNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJqRyxTQUFTLENBQUMySyxPQUF4QyxFQUFpRC9NLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCZ0csa0JBQXhFLENBQW5CO0FBQ0E3SywyQkFBUyxDQUFDOEssZUFBVixHQUE0QmxOLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmpHLFNBQVMsQ0FBQzJLLE9BQXhDLEVBQWlEL00sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJrRyxrQkFBeEUsQ0FBNUI7QUFDQS9LLDJCQUFTLENBQUNvRyxnQkFBVixHQUE2QnhJLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmpHLFNBQVMsQ0FBQzJLLE9BQXhDLEVBQWlEL00sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJtRyxtQkFBeEUsQ0FBN0I7QUFFQSxzQkFBSUMsYUFBYSxHQUFHOUUsWUFBWSxDQUFDbkcsU0FBUyxDQUFDb0csZ0JBQVgsQ0FBaEM7O0FBQ0Esc0JBQUk2RSxhQUFKLEVBQWtCO0FBQ2Qsd0JBQUlBLGFBQWEsQ0FBQ0MsV0FBZCxDQUEwQm5JLFFBQTlCLEVBQ0kvQyxTQUFTLENBQUNtTCxXQUFWLEdBQXlCckksc0JBQXNCLENBQUNtSSxhQUFhLENBQUNDLFdBQWQsQ0FBMEJuSSxRQUEzQixDQUEvQztBQUNKL0MsNkJBQVMsQ0FBQ0csZ0JBQVYsR0FBNkI4SyxhQUFhLENBQUM5SyxnQkFBM0M7QUFDQUgsNkJBQVMsQ0FBQ0ksaUJBQVYsR0FBOEJ4QyxNQUFNLENBQUNxSSxJQUFQLENBQVksY0FBWixFQUE0QmdGLGFBQWEsQ0FBQzlLLGdCQUExQyxDQUE5QjtBQUNBSCw2QkFBUyxDQUFDb0wsTUFBVixHQUFtQkgsYUFBYSxDQUFDRyxNQUFqQztBQUNBcEwsNkJBQVMsQ0FBQ3VGLE1BQVYsR0FBbUIwRixhQUFhLENBQUMxRixNQUFqQztBQUNBdkYsNkJBQVMsQ0FBQ3FMLG1CQUFWLEdBQWdDSixhQUFhLENBQUNJLG1CQUE5QztBQUNBckwsNkJBQVMsQ0FBQ3NMLE1BQVYsR0FBbUJMLGFBQWEsQ0FBQ0ssTUFBakM7QUFDQXRMLDZCQUFTLENBQUN1TCxnQkFBVixHQUE2Qk4sYUFBYSxDQUFDTSxnQkFBM0M7QUFDQXZMLDZCQUFTLENBQUNrTCxXQUFWLEdBQXdCRCxhQUFhLENBQUNDLFdBQXRDO0FBQ0FsTCw2QkFBUyxDQUFDd0wsV0FBVixHQUF3QlAsYUFBYSxDQUFDTyxXQUF0QztBQUNBeEwsNkJBQVMsQ0FBQ3lMLHFCQUFWLEdBQWtDUixhQUFhLENBQUNRLHFCQUFoRDtBQUNBekwsNkJBQVMsQ0FBQzBMLGdCQUFWLEdBQTZCVCxhQUFhLENBQUNTLGdCQUEzQztBQUNBMUwsNkJBQVMsQ0FBQzJMLGNBQVYsR0FBMkJWLGFBQWEsQ0FBQ1UsY0FBekM7QUFDQTNMLDZCQUFTLENBQUNNLFVBQVYsR0FBdUIySyxhQUFhLENBQUMzSyxVQUFyQztBQUNBTiw2QkFBUyxDQUFDNEwsZUFBVixHQUE0QjVMLFNBQVMsQ0FBQ3VMLGdCQUF0QyxDQWhCYyxDQWlCZDtBQUNBO0FBQ0E7QUFDSCxtQkFwQkQsTUFvQk87QUFDSDlNLDJCQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWjtBQUNILG1CQWxDUyxDQW9DVjs7O0FBQ0FnSSxnQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDMEMsb0NBQWdCLEVBQUVwRyxTQUFTLENBQUNvRztBQUE3QixtQkFBcEIsRUFBb0VrRCxNQUFwRSxHQUE2RUMsU0FBN0UsQ0FBdUY7QUFBQ0Msd0JBQUksRUFBQ3hKO0FBQU4sbUJBQXZGLEVBckNVLENBc0NWOztBQUNBNkcsK0JBQWEsQ0FBQ3VCLE1BQWQsQ0FBcUI7QUFDakJ4SiwyQkFBTyxFQUFFb0IsU0FBUyxDQUFDcEIsT0FERjtBQUVqQmlOLHFDQUFpQixFQUFFLENBRkY7QUFHakI1QyxnQ0FBWSxFQUFFakosU0FBUyxDQUFDaUosWUFIUDtBQUlqQjVKLHdCQUFJLEVBQUUsS0FKVztBQUtqQjJFLDBCQUFNLEVBQUVnRCxTQUFTLENBQUNoRCxNQUxEO0FBTWpCOEgsOEJBQVUsRUFBRTlFLFNBQVMsQ0FBQ2pHO0FBTkwsbUJBQXJCLEVBdkNVLENBZ0RWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFJQTtBQUNILGlCQS9ERCxNQWdFSTtBQUNBLHNCQUFJa0ssYUFBYSxHQUFHOUUsWUFBWSxDQUFDdUUsUUFBUSxDQUFDdEUsZ0JBQVYsQ0FBaEM7O0FBQ0Esc0JBQUk2RSxhQUFKLEVBQWtCO0FBQ2Qsd0JBQUlBLGFBQWEsQ0FBQ0MsV0FBZCxLQUE4QixDQUFDUixRQUFRLENBQUNRLFdBQVYsSUFBeUJELGFBQWEsQ0FBQ0MsV0FBZCxDQUEwQm5JLFFBQTFCLEtBQXVDMkgsUUFBUSxDQUFDUSxXQUFULENBQXFCbkksUUFBbkgsQ0FBSixFQUNJL0MsU0FBUyxDQUFDbUwsV0FBVixHQUF5QnJJLHNCQUFzQixDQUFDbUksYUFBYSxDQUFDQyxXQUFkLENBQTBCbkksUUFBM0IsQ0FBL0M7QUFDSi9DLDZCQUFTLENBQUNvTCxNQUFWLEdBQW1CSCxhQUFhLENBQUNHLE1BQWpDO0FBQ0FwTCw2QkFBUyxDQUFDdUYsTUFBVixHQUFtQjBGLGFBQWEsQ0FBQzFGLE1BQWpDO0FBQ0F2Riw2QkFBUyxDQUFDc0wsTUFBVixHQUFtQkwsYUFBYSxDQUFDSyxNQUFqQztBQUNBdEwsNkJBQVMsQ0FBQ3VMLGdCQUFWLEdBQTZCTixhQUFhLENBQUNNLGdCQUEzQztBQUNBdkwsNkJBQVMsQ0FBQ2tMLFdBQVYsR0FBd0JELGFBQWEsQ0FBQ0MsV0FBdEM7QUFDQWxMLDZCQUFTLENBQUN3TCxXQUFWLEdBQXdCUCxhQUFhLENBQUNPLFdBQXRDO0FBQ0F4TCw2QkFBUyxDQUFDeUwscUJBQVYsR0FBa0NSLGFBQWEsQ0FBQ1EscUJBQWhEO0FBQ0F6TCw2QkFBUyxDQUFDMEwsZ0JBQVYsR0FBNkJULGFBQWEsQ0FBQ1MsZ0JBQTNDO0FBQ0ExTCw2QkFBUyxDQUFDMkwsY0FBVixHQUEyQlYsYUFBYSxDQUFDVSxjQUF6QztBQUNBM0wsNkJBQVMsQ0FBQ00sVUFBVixHQUF1QjJLLGFBQWEsQ0FBQzNLLFVBQXJDLENBWmMsQ0FjZDs7QUFFQSx3QkFBSTBELE1BQU0sR0FBRyxFQUFULElBQWUsQ0FBbkIsRUFBcUI7QUFDakIsMEJBQUc7QUFDQyw0QkFBSWpGLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNDLEdBQUcsR0FBRyxzQkFBTixHQUE2Qm9NLFFBQVEsQ0FBQ3RLLGlCQUF0QyxHQUF3RCxlQUF4RCxHQUF3RXNLLFFBQVEsQ0FBQ3ZLLGdCQUExRixDQUFmOztBQUVBLDRCQUFJcEIsUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCLDhCQUFJd04sY0FBYyxHQUFHL00sSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQWxEOztBQUNBLDhCQUFJNE0sY0FBYyxDQUFDdkwsTUFBbkIsRUFBMEI7QUFDdEJSLHFDQUFTLENBQUM0TCxlQUFWLEdBQTRCbkwsVUFBVSxDQUFDc0wsY0FBYyxDQUFDdkwsTUFBaEIsQ0FBVixHQUFrQ0MsVUFBVSxDQUFDVCxTQUFTLENBQUN1TCxnQkFBWCxDQUF4RTtBQUNIO0FBQ0o7QUFDSix1QkFURCxDQVVBLE9BQU0vTSxDQUFOLEVBQVEsQ0FDSjtBQUNIO0FBQ0o7O0FBRURrSSxrQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDMEMsc0NBQWdCLEVBQUVzRSxRQUFRLENBQUN0RTtBQUE1QixxQkFBcEIsRUFBbUVtRCxTQUFuRSxDQUE2RTtBQUFDQywwQkFBSSxFQUFDeEo7QUFBTixxQkFBN0UsRUFoQ2MsQ0FpQ2Q7QUFDQTtBQUNILG1CQW5DRCxNQW1DUTtBQUNKdkIsMkJBQU8sQ0FBQ0MsR0FBUixDQUFZLGlCQUFaO0FBQ0g7O0FBQ0Qsc0JBQUlzTixlQUFlLEdBQUc3SixrQkFBa0IsQ0FBQ2xDLE9BQW5CLENBQTJCO0FBQUNyQiwyQkFBTyxFQUFDb0IsU0FBUyxDQUFDcEI7QUFBbkIsbUJBQTNCLEVBQXdEO0FBQUNvRiwwQkFBTSxFQUFDLENBQUMsQ0FBVDtBQUFZNEIseUJBQUssRUFBQztBQUFsQixtQkFBeEQsQ0FBdEI7O0FBRUEsc0JBQUlvRyxlQUFKLEVBQW9CO0FBQ2hCLHdCQUFJQSxlQUFlLENBQUMvQyxZQUFoQixJQUFnQ2pKLFNBQVMsQ0FBQ2lKLFlBQTlDLEVBQTJEO0FBQ3ZELDBCQUFJZ0QsVUFBVSxHQUFJRCxlQUFlLENBQUMvQyxZQUFoQixHQUErQmpKLFNBQVMsQ0FBQ2lKLFlBQTFDLEdBQXdELE1BQXhELEdBQStELElBQWhGO0FBQ0EsMEJBQUlpRCxVQUFVLEdBQUc7QUFDYnROLCtCQUFPLEVBQUVvQixTQUFTLENBQUNwQixPQUROO0FBRWJpTix5Q0FBaUIsRUFBRUcsZUFBZSxDQUFDL0MsWUFGdEI7QUFHYkEsb0NBQVksRUFBRWpKLFNBQVMsQ0FBQ2lKLFlBSFg7QUFJYjVKLDRCQUFJLEVBQUU0TSxVQUpPO0FBS2JqSSw4QkFBTSxFQUFFZ0QsU0FBUyxDQUFDaEQsTUFMTDtBQU1iOEgsa0NBQVUsRUFBRTlFLFNBQVMsQ0FBQ2pHO0FBTlQsdUJBQWpCLENBRnVELENBVXZEO0FBQ0E7O0FBQ0E4RixtQ0FBYSxDQUFDdUIsTUFBZCxDQUFxQjhELFVBQXJCO0FBQ0g7QUFDSjtBQUVKLGlCQWxJa0MsQ0FxSW5DOzs7QUFFQXpGLDZCQUFhLENBQUN3QyxZQUFkLElBQThCakosU0FBUyxDQUFDaUosWUFBeEM7QUFDSCxlQTNJaUIsQ0E2SWxCOzs7QUFFQSxrQkFBSXZHLGNBQWMsR0FBR1gsYUFBYSxDQUFDOUIsT0FBZCxDQUFzQjtBQUFDdUksNEJBQVksRUFBQ3hFLE1BQU0sR0FBQztBQUFyQixlQUF0QixDQUFyQjs7QUFFQSxrQkFBSXRCLGNBQUosRUFBbUI7QUFDZixvQkFBSXlKLGlCQUFpQixHQUFHMUosb0JBQW9CLENBQUNDLGNBQWMsQ0FBQ0MsVUFBaEIsRUFBNEJBLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0J3RCxVQUE5QyxDQUE1Qzs7QUFFQSxxQkFBS3lKLENBQUwsSUFBVUQsaUJBQVYsRUFBNEI7QUFDeEJ0RiwrQkFBYSxDQUFDdUIsTUFBZCxDQUFxQjtBQUNqQnhKLDJCQUFPLEVBQUV1TixpQkFBaUIsQ0FBQ0MsQ0FBRCxDQUFqQixDQUFxQnhOLE9BRGI7QUFFakJpTixxQ0FBaUIsRUFBRU0saUJBQWlCLENBQUNDLENBQUQsQ0FBakIsQ0FBcUJuRCxZQUZ2QjtBQUdqQkEsZ0NBQVksRUFBRSxDQUhHO0FBSWpCNUosd0JBQUksRUFBRSxRQUpXO0FBS2pCMkUsMEJBQU0sRUFBRWdELFNBQVMsQ0FBQ2hELE1BTEQ7QUFNakI4SCw4QkFBVSxFQUFFOUUsU0FBUyxDQUFDakc7QUFOTCxtQkFBckI7QUFRSDtBQUNKO0FBRUosYUE5VDBCLENBaVUzQjs7O0FBQ0EsZ0JBQUlpRCxNQUFNLEdBQUcsS0FBVCxJQUFrQixDQUF0QixFQUF3QjtBQUNwQixrQkFBSTtBQUNBdkYsdUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHVDQUFaO0FBQ0Esb0JBQUkyTixZQUFZLEdBQUcsRUFBbkI7QUFDQXBPLDBCQUFVLENBQUN5RixJQUFYLENBQWdCLEVBQWhCLEVBQW9CO0FBQUM0SSx3QkFBTSxFQUFFO0FBQUNsRyxvQ0FBZ0IsRUFBRSxDQUFuQjtBQUFzQmIsMEJBQU0sRUFBRTtBQUE5QjtBQUFULGlCQUFwQixFQUNNM0UsT0FETixDQUNlN0MsQ0FBRCxJQUFPc08sWUFBWSxDQUFDdE8sQ0FBQyxDQUFDcUksZ0JBQUgsQ0FBWixHQUFtQ3JJLENBQUMsQ0FBQ3dILE1BRDFEO0FBRUFlLHNCQUFNLENBQUNDLElBQVAsQ0FBWUosWUFBWixFQUEwQnZGLE9BQTFCLENBQW1DMkwsU0FBRCxJQUFlO0FBQzdDLHNCQUFJdEIsYUFBYSxHQUFHOUUsWUFBWSxDQUFDb0csU0FBRCxDQUFoQyxDQUQ2QyxDQUU3Qzs7QUFDQSxzQkFBSXRCLGFBQWEsQ0FBQzFGLE1BQWQsS0FBeUIsQ0FBN0IsRUFDSTs7QUFFSixzQkFBSThHLFlBQVksQ0FBQ0UsU0FBRCxDQUFaLElBQTJCQyxTQUEvQixFQUEwQztBQUN0Qy9OLDJCQUFPLENBQUNDLEdBQVIsMkNBQStDNk4sU0FBL0M7QUFFQXRCLGlDQUFhLENBQUNOLE9BQWQsR0FBd0I7QUFDcEIsOEJBQVMsMEJBRFc7QUFFcEIsK0JBQVMvTSxNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJzRyxTQUE5QjtBQUZXLHFCQUF4QjtBQUlBdEIsaUNBQWEsQ0FBQ3JNLE9BQWQsR0FBd0IyRCxVQUFVLENBQUMwSSxhQUFhLENBQUNOLE9BQWYsQ0FBbEM7QUFDQU0saUNBQWEsQ0FBQzdLLGlCQUFkLEdBQWtDeEMsTUFBTSxDQUFDcUksSUFBUCxDQUFZLGNBQVosRUFBNEJnRixhQUFhLENBQUM5SyxnQkFBMUMsQ0FBbEM7QUFFQThLLGlDQUFhLENBQUNMLE1BQWQsR0FBdUJoTixNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJnRixhQUFhLENBQUNOLE9BQTVDLEVBQXFEL00sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJnRyxrQkFBNUUsQ0FBdkI7QUFDQUksaUNBQWEsQ0FBQ0gsZUFBZCxHQUFnQ2xOLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmdGLGFBQWEsQ0FBQ04sT0FBNUMsRUFBcUQvTSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmtHLGtCQUE1RSxDQUFoQztBQUNBdE0sMkJBQU8sQ0FBQ0MsR0FBUixDQUFZTSxJQUFJLENBQUNtRSxTQUFMLENBQWU4SCxhQUFmLENBQVo7QUFDQXZFLGtDQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUMwQyxzQ0FBZ0IsRUFBRW1HO0FBQW5CLHFCQUFwQixFQUFtRGpELE1BQW5ELEdBQTREQyxTQUE1RCxDQUFzRTtBQUFDQywwQkFBSSxFQUFDeUI7QUFBTixxQkFBdEU7QUFDSCxtQkFkRCxNQWNPLElBQUlvQixZQUFZLENBQUNFLFNBQUQsQ0FBWixJQUEyQixDQUEvQixFQUFrQztBQUNyQzdGLGtDQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUMwQyxzQ0FBZ0IsRUFBRW1HO0FBQW5CLHFCQUFwQixFQUFtRGpELE1BQW5ELEdBQTREQyxTQUE1RCxDQUFzRTtBQUFDQywwQkFBSSxFQUFDeUI7QUFBTixxQkFBdEU7QUFDSDtBQUNKLGlCQXZCRDtBQXdCSCxlQTdCRCxDQTZCRSxPQUFPek0sQ0FBUCxFQUFTO0FBQ1BDLHVCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osYUFuVzBCLENBcVczQjs7O0FBQ0EsZ0JBQUl3RixNQUFNLEdBQUcsS0FBVCxJQUFrQixDQUF0QixFQUF3QjtBQUNwQnZGLHFCQUFPLENBQUNDLEdBQVIsQ0FBWSxxQkFBWjtBQUNBVCx3QkFBVSxDQUFDeUYsSUFBWCxDQUFnQixFQUFoQixFQUFvQjlDLE9BQXBCLENBQTZCWixTQUFELElBQWU7QUFDdkMsb0JBQUk7QUFDQSxzQkFBSXlNLFVBQVUsR0FBSTNKLHNCQUFzQixDQUFDOUMsU0FBUyxDQUFDa0wsV0FBVixDQUFzQm5JLFFBQXZCLENBQXhDOztBQUNBLHNCQUFJMEosVUFBSixFQUFnQjtBQUNaL0Ysa0NBQWMsQ0FBQ2hELElBQWYsQ0FBb0I7QUFBQzlFLDZCQUFPLEVBQUVvQixTQUFTLENBQUNwQjtBQUFwQixxQkFBcEIsRUFDTTBLLE1BRE4sR0FDZUMsU0FEZixDQUN5QjtBQUFDQywwQkFBSSxFQUFDO0FBQUMsdUNBQWNpRDtBQUFmO0FBQU4scUJBRHpCO0FBRUg7QUFDSixpQkFORCxDQU1FLE9BQU9qTyxDQUFQLEVBQVU7QUFDUkMseUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixlQVZEO0FBV0g7O0FBRUQsZ0JBQUlrTyx5QkFBeUIsR0FBRyxJQUFJMUwsSUFBSixFQUFoQztBQUNBdkMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLCtCQUE4QixDQUFDZ08seUJBQXlCLEdBQUNsQywyQkFBM0IsSUFBd0QsSUFBdEYsR0FBNEYsVUFBeEcsRUF0WDJCLENBd1gzQjs7QUFDQSxnQkFBSW1DLHVCQUF1QixHQUFHLElBQUkzTCxJQUFKLEVBQTlCO0FBQ0FpQixxQkFBUyxDQUFDbUcsTUFBVixDQUFpQjNCLGFBQWpCO0FBQ0EsZ0JBQUltRyxzQkFBc0IsR0FBRyxJQUFJNUwsSUFBSixFQUE3QjtBQUNBdkMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUEyQixDQUFDa08sc0JBQXNCLEdBQUNELHVCQUF4QixJQUFpRCxJQUE1RSxHQUFrRixVQUE5RjtBQUVBLGdCQUFJRSxZQUFZLEdBQUcsSUFBSTdMLElBQUosRUFBbkI7O0FBQ0EsZ0JBQUkwRixjQUFjLENBQUMvRyxNQUFmLEdBQXdCLENBQTVCLEVBQThCO0FBQzFCO0FBQ0ErRyw0QkFBYyxDQUFDb0csT0FBZixDQUF1QixDQUFDNUUsR0FBRCxFQUFNL0ksTUFBTixLQUFpQjtBQUNwQyxvQkFBSStJLEdBQUosRUFBUTtBQUNKekoseUJBQU8sQ0FBQ0MsR0FBUixDQUFZd0osR0FBWjtBQUNIOztBQUNELG9CQUFJL0ksTUFBSixFQUFXLENBQ1A7QUFDSDtBQUNKLGVBUEQ7QUFRSDs7QUFFRCxnQkFBSTROLFVBQVUsR0FBRyxJQUFJL0wsSUFBSixFQUFqQjtBQUNBdkMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUEyQixDQUFDcU8sVUFBVSxHQUFDRixZQUFaLElBQTBCLElBQXJELEdBQTJELFVBQXZFO0FBRUEsZ0JBQUlHLFdBQVcsR0FBRyxJQUFJaE0sSUFBSixFQUFsQjs7QUFDQSxnQkFBSTRGLG9CQUFvQixDQUFDakgsTUFBckIsR0FBOEIsQ0FBbEMsRUFBb0M7QUFDaENpSCxrQ0FBb0IsQ0FBQ2tHLE9BQXJCLENBQTZCLENBQUM1RSxHQUFELEVBQU0vSSxNQUFOLEtBQWlCO0FBQzFDLG9CQUFJK0ksR0FBSixFQUFRO0FBQ0p6Six5QkFBTyxDQUFDQyxHQUFSLENBQVl3SixHQUFaO0FBQ0g7QUFDSixlQUpEO0FBS0g7O0FBRUQsZ0JBQUkrRSxTQUFTLEdBQUcsSUFBSWpNLElBQUosRUFBaEI7QUFDQXZDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSxvQ0FBbUMsQ0FBQ3VPLFNBQVMsR0FBQ0QsV0FBWCxJQUF3QixJQUEzRCxHQUFpRSxVQUE3RTs7QUFFQSxnQkFBSW5HLGFBQWEsQ0FBQ2xILE1BQWQsR0FBdUIsQ0FBM0IsRUFBNkI7QUFDekJrSCwyQkFBYSxDQUFDaUcsT0FBZCxDQUFzQixDQUFDNUUsR0FBRCxFQUFNL0ksTUFBTixLQUFpQjtBQUNuQyxvQkFBSStJLEdBQUosRUFBUTtBQUNKekoseUJBQU8sQ0FBQ0MsR0FBUixDQUFZd0osR0FBWjtBQUNIO0FBQ0osZUFKRDtBQUtIOztBQUVELGdCQUFJcEIsZUFBZSxDQUFDbkgsTUFBaEIsR0FBeUIsQ0FBN0IsRUFBK0I7QUFDM0JtSCw2QkFBZSxDQUFDZ0csT0FBaEIsQ0FBd0IsQ0FBQzVFLEdBQUQsRUFBTS9JLE1BQU4sS0FBaUI7QUFDckMsb0JBQUkrSSxHQUFKLEVBQVE7QUFDSnpKLHlCQUFPLENBQUNDLEdBQVIsQ0FBWXdKLEdBQVo7QUFDSDtBQUNKLGVBSkQ7QUFLSCxhQXhhMEIsQ0EwYTNCOzs7QUFFQSxnQkFBSWxFLE1BQU0sR0FBRyxFQUFULElBQWUsQ0FBbkIsRUFBcUI7QUFDakJ2RixxQkFBTyxDQUFDQyxHQUFSLENBQVksaURBQVo7QUFDQSxrQkFBSXdPLGdCQUFnQixHQUFHalAsVUFBVSxDQUFDeUYsSUFBWCxDQUFnQjtBQUFDNkIsc0JBQU0sRUFBQyxDQUFSO0FBQVU2RixzQkFBTSxFQUFDO0FBQWpCLGVBQWhCLEVBQXdDO0FBQUN6RixvQkFBSSxFQUFDO0FBQUNzRCw4QkFBWSxFQUFDLENBQUM7QUFBZjtBQUFOLGVBQXhDLEVBQWtFckYsS0FBbEUsRUFBdkI7QUFDQSxrQkFBSXVKLFlBQVksR0FBR2pELElBQUksQ0FBQ2tELElBQUwsQ0FBVUYsZ0JBQWdCLENBQUN2TixNQUFqQixHQUF3QixHQUFsQyxDQUFuQjtBQUNBLGtCQUFJME4sZUFBZSxHQUFHSCxnQkFBZ0IsQ0FBQ3ZOLE1BQWpCLEdBQTBCd04sWUFBaEQ7QUFFQSxrQkFBSUcsY0FBYyxHQUFHLENBQXJCO0FBQ0Esa0JBQUlDLGlCQUFpQixHQUFHLENBQXhCO0FBRUEsa0JBQUlDLGdCQUFnQixHQUFHLENBQXZCO0FBQ0Esa0JBQUlDLGlCQUFpQixHQUFHLENBQXhCO0FBQ0Esa0JBQUlDLG9CQUFvQixHQUFHLENBQTNCO0FBQ0Esa0JBQUlDLHFCQUFxQixHQUFHLENBQTVCOztBQUlBLG1CQUFLNVAsQ0FBTCxJQUFVbVAsZ0JBQVYsRUFBMkI7QUFDdkIsb0JBQUluUCxDQUFDLEdBQUdvUCxZQUFSLEVBQXFCO0FBQ2pCRyxnQ0FBYyxJQUFJSixnQkFBZ0IsQ0FBQ25QLENBQUQsQ0FBaEIsQ0FBb0JrTCxZQUF0QztBQUNILGlCQUZELE1BR0k7QUFDQXNFLG1DQUFpQixJQUFJTCxnQkFBZ0IsQ0FBQ25QLENBQUQsQ0FBaEIsQ0FBb0JrTCxZQUF6QztBQUNIOztBQUdELG9CQUFJeUUsb0JBQW9CLEdBQUcsSUFBM0IsRUFBZ0M7QUFDNUJBLHNDQUFvQixJQUFJUixnQkFBZ0IsQ0FBQ25QLENBQUQsQ0FBaEIsQ0FBb0JrTCxZQUFwQixHQUFtQ3hDLGFBQWEsQ0FBQ3dDLFlBQXpFO0FBQ0F1RSxrQ0FBZ0I7QUFDbkI7QUFDSjs7QUFFREcsbUNBQXFCLEdBQUcsSUFBSUQsb0JBQTVCO0FBQ0FELCtCQUFpQixHQUFHUCxnQkFBZ0IsQ0FBQ3ZOLE1BQWpCLEdBQTBCNk4sZ0JBQTlDO0FBRUEsa0JBQUlJLE1BQU0sR0FBRztBQUNUNUosc0JBQU0sRUFBRUEsTUFEQztBQUVUbUosNEJBQVksRUFBRUEsWUFGTDtBQUdURyw4QkFBYyxFQUFFQSxjQUhQO0FBSVRELCtCQUFlLEVBQUVBLGVBSlI7QUFLVEUsaUNBQWlCLEVBQUVBLGlCQUxWO0FBTVRDLGdDQUFnQixFQUFFQSxnQkFOVDtBQU9URSxvQ0FBb0IsRUFBRUEsb0JBUGI7QUFRVEQsaUNBQWlCLEVBQUVBLGlCQVJWO0FBU1RFLHFDQUFxQixFQUFFQSxxQkFUZDtBQVVURSw2QkFBYSxFQUFFWCxnQkFBZ0IsQ0FBQ3ZOLE1BVnZCO0FBV1RtTyxnQ0FBZ0IsRUFBRXJILGFBQWEsQ0FBQ3dDLFlBWHZCO0FBWVRhLHlCQUFTLEVBQUU5QyxTQUFTLENBQUNqRyxJQVpaO0FBYVRnTix3QkFBUSxFQUFFLElBQUkvTSxJQUFKO0FBYkQsZUFBYjtBQWdCQXZDLHFCQUFPLENBQUNDLEdBQVIsQ0FBWWtQLE1BQVo7QUFFQTFMLDZCQUFlLENBQUNrRyxNQUFoQixDQUF1QndGLE1BQXZCO0FBQ0g7QUFDSjtBQUNKLFNBM2VELENBNGVBLE9BQU9wUCxDQUFQLEVBQVM7QUFDTEMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0F1SCxpQkFBTyxHQUFHLEtBQVY7QUFDQSxpQkFBTyxTQUFQO0FBQ0g7O0FBQ0QsWUFBSWlJLFlBQVksR0FBRyxJQUFJaE4sSUFBSixFQUFuQjtBQUNBdkMsZUFBTyxDQUFDQyxHQUFSLENBQVksc0JBQXFCLENBQUNzUCxZQUFZLEdBQUN4SCxjQUFkLElBQThCLElBQW5ELEdBQXlELFVBQXJFO0FBQ0g7O0FBQ0RULGFBQU8sR0FBRyxLQUFWO0FBQ0FqRSxXQUFLLENBQUN3SSxNQUFOLENBQWE7QUFBQ1gsZUFBTyxFQUFDL0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFoQyxPQUFiLEVBQXVEO0FBQUNILFlBQUksRUFBQztBQUFDeUUsOEJBQW9CLEVBQUMsSUFBSWpOLElBQUosRUFBdEI7QUFBa0NxRix5QkFBZSxFQUFDQTtBQUFsRDtBQUFOLE9BQXZEO0FBQ0g7O0FBRUQsV0FBT0wsS0FBUDtBQUNILEdBL21CVTtBQWduQlgsY0FBWSxVQUFTSixLQUFULEVBQWdCO0FBQ3hCO0FBQ0EsV0FBUUEsS0FBSyxHQUFDLEVBQWQ7QUFDSCxHQW5uQlU7QUFvbkJYLGFBQVcsVUFBU0EsS0FBVCxFQUFnQjtBQUN2QixRQUFJQSxLQUFLLEdBQUdoSSxNQUFNLENBQUNxSSxJQUFQLENBQVksa0JBQVosQ0FBWixFQUE2QztBQUN6QyxhQUFRLEtBQVI7QUFDSCxLQUZELE1BRU87QUFDSCxhQUFRLElBQVI7QUFDSDtBQUNKO0FBMW5CVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDN0RBLElBQUlySSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUk4RCxTQUFKO0FBQWNoRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMrRCxXQUFTLENBQUM5RCxDQUFELEVBQUc7QUFBQzhELGFBQVMsR0FBQzlELENBQVY7QUFBWTs7QUFBMUIsQ0FBM0IsRUFBdUQsQ0FBdkQ7QUFBMEQsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBN0MsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSXFFLFlBQUo7QUFBaUJ2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDc0UsY0FBWSxDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxnQkFBWSxHQUFDckUsQ0FBYjtBQUFlOztBQUFoQyxDQUFqRCxFQUFtRixDQUFuRjtBQUt0UG1RLGdCQUFnQixDQUFDLGVBQUQsRUFBa0IsVUFBU3RJLEtBQVQsRUFBZTtBQUM3QyxTQUFPO0FBQ0hsQyxRQUFJLEdBQUU7QUFDRixhQUFPN0IsU0FBUyxDQUFDNkIsSUFBVixDQUFlLEVBQWYsRUFBbUI7QUFBQ2tDLGFBQUssRUFBRUEsS0FBUjtBQUFlRCxZQUFJLEVBQUU7QUFBQzNCLGdCQUFNLEVBQUUsQ0FBQztBQUFWO0FBQXJCLE9BQW5CLENBQVA7QUFDSCxLQUhFOztBQUlIbUssWUFBUSxFQUFFLENBQ047QUFDSXpLLFVBQUksQ0FBQ0ssS0FBRCxFQUFPO0FBQ1AsZUFBTzlGLFVBQVUsQ0FBQ3lGLElBQVgsQ0FDSDtBQUFDOUUsaUJBQU8sRUFBQ21GLEtBQUssQ0FBQ0o7QUFBZixTQURHLEVBRUg7QUFBQ2lDLGVBQUssRUFBQztBQUFQLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE07QUFKUCxHQUFQO0FBZUgsQ0FoQmUsQ0FBaEI7QUFrQkFzSSxnQkFBZ0IsQ0FBQyxnQkFBRCxFQUFtQixVQUFTbEssTUFBVCxFQUFnQjtBQUMvQyxTQUFPO0FBQ0hOLFFBQUksR0FBRTtBQUNGLGFBQU83QixTQUFTLENBQUM2QixJQUFWLENBQWU7QUFBQ00sY0FBTSxFQUFDQTtBQUFSLE9BQWYsQ0FBUDtBQUNILEtBSEU7O0FBSUhtSyxZQUFRLEVBQUUsQ0FDTjtBQUNJekssVUFBSSxDQUFDSyxLQUFELEVBQU87QUFDUCxlQUFPM0IsWUFBWSxDQUFDc0IsSUFBYixDQUNIO0FBQUNNLGdCQUFNLEVBQUNELEtBQUssQ0FBQ0M7QUFBZCxTQURHLENBQVA7QUFHSDs7QUFMTCxLQURNLEVBUU47QUFDSU4sVUFBSSxDQUFDSyxLQUFELEVBQU87QUFDUCxlQUFPOUYsVUFBVSxDQUFDeUYsSUFBWCxDQUNIO0FBQUM5RSxpQkFBTyxFQUFDbUYsS0FBSyxDQUFDSjtBQUFmLFNBREcsRUFFSDtBQUFDaUMsZUFBSyxFQUFDO0FBQVAsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FSTTtBQUpQLEdBQVA7QUFzQkgsQ0F2QmUsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUN2QkEvSCxNQUFNLENBQUN1USxNQUFQLENBQWM7QUFBQ3ZNLFdBQVMsRUFBQyxNQUFJQTtBQUFmLENBQWQ7QUFBeUMsSUFBSXdNLEtBQUo7QUFBVXhRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3VRLE9BQUssQ0FBQ3RRLENBQUQsRUFBRztBQUFDc1EsU0FBSyxHQUFDdFEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUExQyxFQUF3RSxDQUF4RTtBQUc3RyxNQUFNOEQsU0FBUyxHQUFHLElBQUl3TSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsUUFBckIsQ0FBbEI7QUFFUHpNLFNBQVMsQ0FBQzBNLE9BQVYsQ0FBa0I7QUFDZEMsVUFBUSxHQUFFO0FBQ04sV0FBT3ZRLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQ3JCLGFBQU8sRUFBQyxLQUFLK0U7QUFBZCxLQUFuQixDQUFQO0FBQ0g7O0FBSGEsQ0FBbEIsRSxDQU1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCOzs7Ozs7Ozs7OztBQ3RCQSxJQUFJL0YsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUl3RSxVQUFKO0FBQWUxRSxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDeUUsWUFBVSxDQUFDeEUsQ0FBRCxFQUFHO0FBQUN3RSxjQUFVLEdBQUN4RSxDQUFYO0FBQWE7O0FBQTVCLENBQXZDLEVBQXFFLENBQXJFO0FBQXdFLElBQUkrRCxLQUFKLEVBQVUyTSxXQUFWO0FBQXNCNVEsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDZ0UsT0FBSyxDQUFDL0QsQ0FBRCxFQUFHO0FBQUMrRCxTQUFLLEdBQUMvRCxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CMFEsYUFBVyxDQUFDMVEsQ0FBRCxFQUFHO0FBQUMwUSxlQUFXLEdBQUMxUSxDQUFaO0FBQWM7O0FBQWhELENBQTFCLEVBQTRFLENBQTVFO0FBQStFLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBQThFLElBQUlvRSxrQkFBSjtBQUF1QnRFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtCQUFaLEVBQTRDO0FBQUNxRSxvQkFBa0IsQ0FBQ3BFLENBQUQsRUFBRztBQUFDb0Usc0JBQWtCLEdBQUNwRSxDQUFuQjtBQUFxQjs7QUFBNUMsQ0FBNUMsRUFBMEYsQ0FBMUY7O0FBT3hhMlEsZUFBZSxHQUFHLENBQUMxTyxTQUFELEVBQVkyTyxhQUFaLEtBQThCO0FBQzVDLE9BQUssSUFBSTVRLENBQVQsSUFBYzRRLGFBQWQsRUFBNEI7QUFDeEIsUUFBSTNPLFNBQVMsQ0FBQzJLLE9BQVYsQ0FBa0JyTCxLQUFsQixJQUEyQnFQLGFBQWEsQ0FBQzVRLENBQUQsQ0FBYixDQUFpQjRNLE9BQWpCLENBQXlCckwsS0FBeEQsRUFBOEQ7QUFDMUQsYUFBT21KLFFBQVEsQ0FBQ2tHLGFBQWEsQ0FBQzVRLENBQUQsQ0FBYixDQUFpQjZRLEtBQWxCLENBQWY7QUFDSDtBQUNKO0FBQ0osQ0FORDs7QUFRQWhSLE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsNkJBQTJCLFlBQVU7QUFDakMsU0FBS0UsT0FBTDtBQUNBLFFBQUlWLEdBQUcsR0FBR21ILEdBQUcsR0FBQyx1QkFBZDs7QUFDQSxRQUFHO0FBQ0MsVUFBSXZHLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjtBQUNBLFVBQUkwUSxTQUFTLEdBQUc3UCxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFoQjtBQUNBMlAsZUFBUyxHQUFHQSxTQUFTLENBQUMxUCxNQUF0QjtBQUNBLFVBQUk2RSxNQUFNLEdBQUc2SyxTQUFTLENBQUNDLFdBQVYsQ0FBc0I5SyxNQUFuQztBQUNBLFVBQUkrSyxLQUFLLEdBQUdGLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQkMsS0FBbEM7QUFDQSxVQUFJQyxJQUFJLEdBQUdILFNBQVMsQ0FBQ0MsV0FBVixDQUFzQkUsSUFBakM7QUFDQSxVQUFJQyxVQUFVLEdBQUcvRSxJQUFJLENBQUM2RSxLQUFMLENBQVd0TyxVQUFVLENBQUNvTyxTQUFTLENBQUNDLFdBQVYsQ0FBc0JJLEtBQXRCLENBQTRCSCxLQUE1QixFQUFtQ0ksa0JBQW5DLENBQXNEQyxLQUF0RCxDQUE0RCxHQUE1RCxFQUFpRSxDQUFqRSxDQUFELENBQVYsR0FBZ0YsR0FBM0YsQ0FBakI7QUFFQXROLFdBQUssQ0FBQ3dJLE1BQU4sQ0FBYTtBQUFDWCxlQUFPLEVBQUMvTCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjhFO0FBQWhDLE9BQWIsRUFBdUQ7QUFBQ0gsWUFBSSxFQUFDO0FBQ3pENkYsc0JBQVksRUFBRXJMLE1BRDJDO0FBRXpEc0wscUJBQVcsRUFBRVAsS0FGNEM7QUFHekRRLG9CQUFVLEVBQUVQLElBSDZDO0FBSXpEQyxvQkFBVSxFQUFFQSxVQUo2QztBQUt6RHRMLHlCQUFlLEVBQUVrTCxTQUFTLENBQUNDLFdBQVYsQ0FBc0JuTSxVQUF0QixDQUFpQzZMLFFBQWpDLENBQTBDNVAsT0FMRjtBQU16RDRRLGtCQUFRLEVBQUVYLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQkksS0FBdEIsQ0FBNEJILEtBQTVCLEVBQW1DUyxRQU5ZO0FBT3pEOUgsb0JBQVUsRUFBRW1ILFNBQVMsQ0FBQ0MsV0FBVixDQUFzQkksS0FBdEIsQ0FBNEJILEtBQTVCLEVBQW1Dckg7QUFQVTtBQUFOLE9BQXZEO0FBU0gsS0FsQkQsQ0FtQkEsT0FBTWxKLENBQU4sRUFBUTtBQUNKQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osR0ExQlU7QUEyQlgsd0JBQXNCLFlBQVU7QUFDNUIsU0FBS0ssT0FBTDtBQUNBLFFBQUlWLEdBQUcsR0FBR21ILEdBQUcsR0FBQyxTQUFkOztBQUNBLFFBQUc7QUFDQyxVQUFJdkcsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsVUFBSW9ILE1BQU0sR0FBR3ZHLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWI7QUFDQXFHLFlBQU0sR0FBR0EsTUFBTSxDQUFDcEcsTUFBaEI7QUFDQSxVQUFJc1EsS0FBSyxHQUFHLEVBQVo7QUFDQUEsV0FBSyxDQUFDOUYsT0FBTixHQUFnQnBFLE1BQU0sQ0FBQ21LLFNBQVAsQ0FBaUJDLE9BQWpDO0FBQ0FGLFdBQUssQ0FBQ0csaUJBQU4sR0FBMEJySyxNQUFNLENBQUNDLFNBQVAsQ0FBaUJDLG1CQUEzQztBQUNBZ0ssV0FBSyxDQUFDSSxlQUFOLEdBQXdCdEssTUFBTSxDQUFDQyxTQUFQLENBQWlCc0ssaUJBQXpDO0FBRUEsVUFBSUMsV0FBVyxHQUFHdEIsV0FBVyxDQUFDeE8sT0FBWixDQUFvQixFQUFwQixFQUF3QjtBQUFDMEYsWUFBSSxFQUFFO0FBQUMzQixnQkFBTSxFQUFFLENBQUM7QUFBVjtBQUFQLE9BQXhCLENBQWxCOztBQUNBLFVBQUkrTCxXQUFXLElBQUlBLFdBQVcsQ0FBQy9MLE1BQVosSUFBc0J5TCxLQUFLLENBQUNHLGlCQUEvQyxFQUFrRTtBQUM5RCxtREFBb0NILEtBQUssQ0FBQ0csaUJBQTFDLHVCQUF3RUcsV0FBVyxDQUFDL0wsTUFBcEY7QUFDSDs7QUFFRDdGLFNBQUcsR0FBR21ILEdBQUcsR0FBQyxhQUFWO0FBQ0F2RyxjQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQSxVQUFJd0UsVUFBVSxHQUFHM0QsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBakI7QUFDQXlELGdCQUFVLEdBQUdBLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0J3RCxVQUEvQjtBQUNBOE0sV0FBSyxDQUFDOU0sVUFBTixHQUFtQkEsVUFBVSxDQUFDaEQsTUFBOUI7QUFDQSxVQUFJcVEsUUFBUSxHQUFHLENBQWY7O0FBQ0EsV0FBS2pTLENBQUwsSUFBVTRFLFVBQVYsRUFBcUI7QUFDakJxTixnQkFBUSxJQUFJdkgsUUFBUSxDQUFDOUYsVUFBVSxDQUFDNUUsQ0FBRCxDQUFWLENBQWNrTCxZQUFmLENBQXBCO0FBQ0g7O0FBQ0R3RyxXQUFLLENBQUNRLGlCQUFOLEdBQTBCRCxRQUExQjtBQUdBbE8sV0FBSyxDQUFDd0ksTUFBTixDQUFhO0FBQUNYLGVBQU8sRUFBQzhGLEtBQUssQ0FBQzlGO0FBQWYsT0FBYixFQUFzQztBQUFDSCxZQUFJLEVBQUNpRztBQUFOLE9BQXRDLEVBQW9EO0FBQUNuRyxjQUFNLEVBQUU7QUFBVCxPQUFwRCxFQTFCRCxDQTJCQzs7QUFDQSxVQUFJYixRQUFRLENBQUNnSCxLQUFLLENBQUNHLGlCQUFQLENBQVIsR0FBb0MsQ0FBeEMsRUFBMEM7QUFDdEMsWUFBSU0sV0FBVyxHQUFHLEVBQWxCO0FBQ0FBLG1CQUFXLENBQUNsTSxNQUFaLEdBQXFCeUUsUUFBUSxDQUFDbEQsTUFBTSxDQUFDQyxTQUFQLENBQWlCQyxtQkFBbEIsQ0FBN0I7QUFDQXlLLG1CQUFXLENBQUNuUCxJQUFaLEdBQW1CLElBQUlDLElBQUosQ0FBU3VFLE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQnNLLGlCQUExQixDQUFuQjtBQUVBM1IsV0FBRyxHQUFHRyxHQUFHLEdBQUcsZUFBWjs7QUFDQSxZQUFHO0FBQ0NTLGtCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQSxjQUFJZ1MsT0FBTyxHQUFHblIsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTNDLENBRkQsQ0FHQztBQUNBOztBQUNBK1EscUJBQVcsQ0FBQ0UsWUFBWixHQUEyQjNILFFBQVEsQ0FBQzBILE9BQU8sQ0FBQ0UsYUFBVCxDQUFuQztBQUNBSCxxQkFBVyxDQUFDSSxlQUFaLEdBQThCN0gsUUFBUSxDQUFDMEgsT0FBTyxDQUFDSSxpQkFBVCxDQUF0QztBQUNILFNBUEQsQ0FRQSxPQUFNL1IsQ0FBTixFQUFRO0FBQ0pDLGlCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUVETCxXQUFHLEdBQUdHLEdBQUcsR0FBRyxnQkFBTixHQUF1QlYsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUIyTCxZQUFwRDs7QUFDQSxZQUFHO0FBQ0N6UixrQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0EsY0FBSXNTLE1BQU0sR0FBR3pSLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUExQztBQUNBK1EscUJBQVcsQ0FBQ1EsV0FBWixHQUEwQmpJLFFBQVEsQ0FBQ2dJLE1BQUQsQ0FBbEM7QUFDSCxTQUpELENBS0EsT0FBTWpTLENBQU4sRUFBUTtBQUNKQyxpQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFFREwsV0FBRyxHQUFHRyxHQUFHLEdBQUcsOEJBQVo7O0FBQ0EsWUFBSTtBQUNBUyxrQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0EsY0FBSXdTLElBQUksR0FBRzNSLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUF4Qzs7QUFDQSxjQUFJd1IsSUFBSSxJQUFJQSxJQUFJLENBQUNoUixNQUFMLEdBQWMsQ0FBMUIsRUFBNEI7QUFDeEJ1USx1QkFBVyxDQUFDVSxhQUFaLEdBQTRCLEVBQTVCO0FBQ0FELGdCQUFJLENBQUMvUCxPQUFMLENBQWEsQ0FBQ2lRLE1BQUQsRUFBU3ZQLENBQVQsS0FBZTtBQUN4QjRPLHlCQUFXLENBQUNVLGFBQVosQ0FBMEJoSixJQUExQixDQUErQjtBQUMzQmtKLHFCQUFLLEVBQUVELE1BQU0sQ0FBQ0MsS0FEYTtBQUUzQkQsc0JBQU0sRUFBRXBRLFVBQVUsQ0FBQ29RLE1BQU0sQ0FBQ0EsTUFBUjtBQUZTLGVBQS9CO0FBSUgsYUFMRDtBQU1IO0FBQ0osU0FaRCxDQWFBLE9BQU9yUyxDQUFQLEVBQVM7QUFDTEMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBRURMLFdBQUcsR0FBR0csR0FBRyxHQUFHLG9CQUFaOztBQUNBLFlBQUc7QUFDQ1Msa0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLGNBQUk0UyxTQUFTLEdBQUcvUixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBN0M7O0FBQ0EsY0FBSTRSLFNBQUosRUFBYztBQUNWYix1QkFBVyxDQUFDYSxTQUFaLEdBQXdCdFEsVUFBVSxDQUFDc1EsU0FBRCxDQUFsQztBQUNIO0FBQ0osU0FORCxDQU9BLE9BQU12UyxDQUFOLEVBQVE7QUFDSkMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBRURMLFdBQUcsR0FBR0csR0FBRyxHQUFHLDRCQUFaOztBQUNBLFlBQUc7QUFDQ1Msa0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLGNBQUk2UyxVQUFVLEdBQUdoUyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFqQjs7QUFDQSxjQUFJOFIsVUFBSixFQUFlO0FBQ1hkLHVCQUFXLENBQUNlLGdCQUFaLEdBQStCeFEsVUFBVSxDQUFDdVEsVUFBVSxDQUFDN1IsTUFBWixDQUF6QztBQUNIO0FBQ0osU0FORCxDQU9BLE9BQU1YLENBQU4sRUFBUTtBQUNKQyxpQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFFRGlRLG1CQUFXLENBQUNyRyxNQUFaLENBQW1COEgsV0FBbkI7QUFDSCxPQW5HRixDQXFHQztBQUVBO0FBQ0E7OztBQUNBLGFBQU9ULEtBQUssQ0FBQ0csaUJBQWI7QUFDSCxLQTFHRCxDQTJHQSxPQUFPcFIsQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0EsYUFBTyw2QkFBUDtBQUNIO0FBQ0osR0E3SVU7QUE4SVgsMkJBQXlCLFlBQVU7QUFDL0JzRCxTQUFLLENBQUM0QixJQUFOLEdBQWFpQyxJQUFiLENBQWtCO0FBQUN1TCxhQUFPLEVBQUMsQ0FBQztBQUFWLEtBQWxCLEVBQWdDdEwsS0FBaEMsQ0FBc0MsQ0FBdEM7QUFDSCxHQWhKVTtBQWlKWCxtQkFBaUIsWUFBVTtBQUN2QixRQUFJNkosS0FBSyxHQUFHM04sS0FBSyxDQUFDN0IsT0FBTixDQUFjO0FBQUMwSixhQUFPLEVBQUUvTCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjhFO0FBQWpDLEtBQWQsQ0FBWjs7QUFFQSxRQUFJOEYsS0FBSyxJQUFJQSxLQUFLLENBQUMwQixXQUFuQixFQUErQjtBQUMzQjFTLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGlDQUFaO0FBQ0gsS0FGRCxNQUdLLElBQUlkLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0J3TSxLQUFoQixDQUFzQkQsV0FBMUIsRUFBdUM7QUFDeEMxUyxhQUFPLENBQUNDLEdBQVIsQ0FBWSx1Q0FBWjtBQUNBLFVBQUlLLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNULE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0J5TSxXQUF6QixDQUFmO0FBQ0EsVUFBSUMsT0FBTyxHQUFHdFMsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBZDtBQUNBLFVBQUlxUyxLQUFLLEdBQUdELE9BQU8sQ0FBQ0UsU0FBUixDQUFrQkQsS0FBbEIsSUFBMkJELE9BQU8sQ0FBQ0UsU0FBUixDQUFrQkMsWUFBekQ7QUFDQSxVQUFJQyxXQUFXLEdBQUc7QUFDZC9ILGVBQU8sRUFBRTJILE9BQU8sQ0FBQzFILFFBREg7QUFFZCtILG1CQUFXLEVBQUVMLE9BQU8sQ0FBQ00sWUFGUDtBQUdkQyx1QkFBZSxFQUFFUCxPQUFPLENBQUNRLGdCQUhYO0FBSWRDLFlBQUksRUFBRVQsT0FBTyxDQUFDRSxTQUFSLENBQWtCTyxJQUpWO0FBS2RDLFlBQUksRUFBRVYsT0FBTyxDQUFDRSxTQUFSLENBQWtCUSxJQUxWO0FBTWRDLGVBQU8sRUFBRTtBQUNMdEIsY0FBSSxFQUFFVyxPQUFPLENBQUNFLFNBQVIsQ0FBa0JTLE9BQWxCLENBQTBCdEIsSUFEM0I7QUFFTDdLLGdCQUFNLEVBQUV3TCxPQUFPLENBQUNFLFNBQVIsQ0FBa0JTLE9BQWxCLENBQTBCbk07QUFGN0IsU0FOSztBQVVkb00sWUFBSSxFQUFFWixPQUFPLENBQUNFLFNBQVIsQ0FBa0JVLElBVlY7QUFXZFgsYUFBSyxFQUFFO0FBQ0hZLHNCQUFZLEVBQUVaLEtBQUssQ0FBQ2EsYUFEakI7QUFFSEMsNEJBQWtCLEVBQUVkLEtBQUssQ0FBQ2Usb0JBRnZCO0FBR0hDLDZCQUFtQixFQUFFaEIsS0FBSyxDQUFDaUIscUJBSHhCO0FBSUhDLDZCQUFtQixFQUFFbEIsS0FBSyxDQUFDbUI7QUFKeEIsU0FYTztBQWlCZEMsV0FBRyxFQUFFLElBakJTO0FBa0JkQyxnQkFBUSxFQUFDO0FBQ0w5TSxnQkFBTSxFQUFFd0wsT0FBTyxDQUFDRSxTQUFSLENBQWtCb0IsUUFBbEIsQ0FBMkI5TTtBQUQ5QixTQWxCSztBQXFCZDJLLGNBQU0sRUFBRWEsT0FBTyxDQUFDRSxTQUFSLENBQWtCZixNQXJCWjtBQXNCZG9DLGNBQU0sRUFBRXZCLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQnFCO0FBdEJaLE9BQWxCO0FBeUJBLFVBQUkvRSxnQkFBZ0IsR0FBRyxDQUF2QixDQTlCd0MsQ0FnQ3hDOztBQUNBLFVBQUl3RCxPQUFPLENBQUNFLFNBQVIsQ0FBa0JzQixPQUFsQixJQUE2QnhCLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQnNCLE9BQWxCLENBQTBCQyxNQUF2RCxJQUFrRXpCLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQnNCLE9BQWxCLENBQTBCQyxNQUExQixDQUFpQ3BULE1BQWpDLEdBQTBDLENBQWhILEVBQW1IO0FBQy9HLGFBQUsyQixDQUFMLElBQVVnUSxPQUFPLENBQUNFLFNBQVIsQ0FBa0JzQixPQUFsQixDQUEwQkMsTUFBcEMsRUFBMkM7QUFDdkMsY0FBSUMsR0FBRyxHQUFHMUIsT0FBTyxDQUFDRSxTQUFSLENBQWtCc0IsT0FBbEIsQ0FBMEJDLE1BQTFCLENBQWlDelIsQ0FBakMsRUFBb0NoQyxLQUFwQyxDQUEwQzBULEdBQXBELENBRHVDLENBRXZDOztBQUNBLGVBQUtDLENBQUwsSUFBVUQsR0FBVixFQUFjO0FBQ1YsZ0JBQUlBLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU81VCxJQUFQLElBQWUsK0JBQW5CLEVBQW1EO0FBQy9DWixxQkFBTyxDQUFDQyxHQUFSLENBQVlzVSxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPM1QsS0FBbkIsRUFEK0MsQ0FFL0M7O0FBQ0Esa0JBQUlVLFNBQVMsR0FBRztBQUNab0csZ0NBQWdCLEVBQUU0TSxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPM1QsS0FBUCxDQUFhNFQsTUFEbkI7QUFFWmhJLDJCQUFXLEVBQUU4SCxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPM1QsS0FBUCxDQUFhNEwsV0FGZDtBQUdaNUssMEJBQVUsRUFBRTBTLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU8zVCxLQUFQLENBQWFnQixVQUhiO0FBSVorSyxtQ0FBbUIsRUFBRTJILEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU8zVCxLQUFQLENBQWErTCxtQkFKdEI7QUFLWmxMLGdDQUFnQixFQUFFNlMsR0FBRyxDQUFDQyxDQUFELENBQUgsQ0FBTzNULEtBQVAsQ0FBYXVJLGlCQUxuQjtBQU1aekgsaUNBQWlCLEVBQUU0UyxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPM1QsS0FBUCxDQUFhYyxpQkFOcEI7QUFPWjZJLDRCQUFZLEVBQUVpQixJQUFJLENBQUNpSixLQUFMLENBQVcxSyxRQUFRLENBQUN1SyxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPM1QsS0FBUCxDQUFhQSxLQUFiLENBQW1CdVIsTUFBcEIsQ0FBUixHQUFzQ2pULE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCdU8sZUFBeEUsQ0FQRjtBQVFaaEksc0JBQU0sRUFBRSxLQVJJO0FBU1o3RixzQkFBTSxFQUFFO0FBVEksZUFBaEI7QUFZQXVJLDhCQUFnQixJQUFJOU4sU0FBUyxDQUFDaUosWUFBOUI7QUFFQSxrQkFBSW9LLFdBQVcsR0FBR3pWLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QitNLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU8zVCxLQUFQLENBQWE0VCxNQUEzQyxDQUFsQixDQWpCK0MsQ0FrQi9DOztBQUVBbFQsdUJBQVMsQ0FBQzJLLE9BQVYsR0FBb0I7QUFDaEIsd0JBQU8sMEJBRFM7QUFFaEIseUJBQVEwSTtBQUZRLGVBQXBCO0FBS0FyVCx1QkFBUyxDQUFDcEIsT0FBVixHQUFvQjJELFVBQVUsQ0FBQ3ZDLFNBQVMsQ0FBQzJLLE9BQVgsQ0FBOUI7QUFDQTNLLHVCQUFTLENBQUM0SyxNQUFWLEdBQW1CaE4sTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCakcsU0FBUyxDQUFDMkssT0FBeEMsRUFBaUQvTSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmdHLGtCQUF4RSxDQUFuQjtBQUNBN0ssdUJBQVMsQ0FBQzhLLGVBQVYsR0FBNEJsTixNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJqRyxTQUFTLENBQUMySyxPQUF4QyxFQUFpRC9NLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCa0csa0JBQXhFLENBQTVCO0FBQ0E1SSxnQ0FBa0IsQ0FBQ2lHLE1BQW5CLENBQTBCO0FBQ3RCeEosdUJBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCLE9BREc7QUFFdEJpTixpQ0FBaUIsRUFBRSxDQUZHO0FBR3RCNUMsNEJBQVksRUFBRWpKLFNBQVMsQ0FBQ2lKLFlBSEY7QUFJdEI1SixvQkFBSSxFQUFFLEtBSmdCO0FBS3RCMkUsc0JBQU0sRUFBRSxDQUxjO0FBTXRCOEgsMEJBQVUsRUFBRXdGLE9BQU8sQ0FBQ007QUFORSxlQUExQjtBQVNBM1Qsd0JBQVUsQ0FBQ21LLE1BQVgsQ0FBa0JwSSxTQUFsQjtBQUNIO0FBQ0o7QUFDSjtBQUNKLE9BL0V1QyxDQWlGeEM7OztBQUNBdkIsYUFBTyxDQUFDQyxHQUFSLENBQVkscUNBQVo7O0FBQ0EsVUFBSTRTLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEJ0UCxVQUExQixJQUF3QzJPLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEJ0UCxVQUExQixDQUFxQ2hELE1BQXJDLEdBQThDLENBQTFGLEVBQTRGO0FBQ3hGbEIsZUFBTyxDQUFDQyxHQUFSLENBQVk0UyxPQUFPLENBQUNFLFNBQVIsQ0FBa0JTLE9BQWxCLENBQTBCdFAsVUFBMUIsQ0FBcUNoRCxNQUFqRDtBQUNBLFlBQUkyVCxnQkFBZ0IsR0FBR2hDLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEJ0UCxVQUFqRDtBQUNBLFlBQUlnTSxhQUFhLEdBQUcyQyxPQUFPLENBQUMzTyxVQUE1Qjs7QUFDQSxhQUFLLElBQUk1RSxDQUFULElBQWN1VixnQkFBZCxFQUErQjtBQUMzQjtBQUNBLGNBQUl0VCxTQUFTLEdBQUdzVCxnQkFBZ0IsQ0FBQ3ZWLENBQUQsQ0FBaEM7QUFDQWlDLG1CQUFTLENBQUNJLGlCQUFWLEdBQThCeEMsTUFBTSxDQUFDcUksSUFBUCxDQUFZLGNBQVosRUFBNEJxTixnQkFBZ0IsQ0FBQ3ZWLENBQUQsQ0FBaEIsQ0FBb0JvQyxnQkFBaEQsQ0FBOUI7QUFFQSxjQUFJa1QsV0FBVyxHQUFHelYsTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCakcsU0FBUyxDQUFDb0csZ0JBQXhDLENBQWxCO0FBRUFwRyxtQkFBUyxDQUFDMkssT0FBVixHQUFvQjtBQUNoQixvQkFBTywwQkFEUztBQUVoQixxQkFBUTBJO0FBRlEsV0FBcEI7QUFLQXJULG1CQUFTLENBQUNwQixPQUFWLEdBQW9CMkQsVUFBVSxDQUFDdkMsU0FBUyxDQUFDMkssT0FBWCxDQUE5QjtBQUNBM0ssbUJBQVMsQ0FBQzJLLE9BQVYsR0FBb0IzSyxTQUFTLENBQUMySyxPQUE5QjtBQUNBM0ssbUJBQVMsQ0FBQzRLLE1BQVYsR0FBbUJoTixNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJqRyxTQUFTLENBQUMySyxPQUF4QyxFQUFpRC9NLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCZ0csa0JBQXhFLENBQW5CO0FBQ0E3SyxtQkFBUyxDQUFDOEssZUFBVixHQUE0QmxOLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmpHLFNBQVMsQ0FBQzJLLE9BQXhDLEVBQWlEL00sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJrRyxrQkFBeEUsQ0FBNUI7QUFFQS9LLG1CQUFTLENBQUNpSixZQUFWLEdBQXlCeUYsZUFBZSxDQUFDMU8sU0FBRCxFQUFZMk8sYUFBWixDQUF4QztBQUNBYiwwQkFBZ0IsSUFBSTlOLFNBQVMsQ0FBQ2lKLFlBQTlCO0FBRUFoTCxvQkFBVSxDQUFDcUwsTUFBWCxDQUFrQjtBQUFDbEQsNEJBQWdCLEVBQUNwRyxTQUFTLENBQUNvRztBQUE1QixXQUFsQixFQUFnRXBHLFNBQWhFO0FBQ0FtQyw0QkFBa0IsQ0FBQ2lHLE1BQW5CLENBQTBCO0FBQ3RCeEosbUJBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCLE9BREc7QUFFdEJpTiw2QkFBaUIsRUFBRSxDQUZHO0FBR3RCNUMsd0JBQVksRUFBRWpKLFNBQVMsQ0FBQ2lKLFlBSEY7QUFJdEI1SixnQkFBSSxFQUFFLEtBSmdCO0FBS3RCMkUsa0JBQU0sRUFBRSxDQUxjO0FBTXRCOEgsc0JBQVUsRUFBRXdGLE9BQU8sQ0FBQ007QUFORSxXQUExQjtBQVFIO0FBQ0o7O0FBRURGLGlCQUFXLENBQUNQLFdBQVosR0FBMEIsSUFBMUI7QUFDQU8saUJBQVcsQ0FBQ3pCLGlCQUFaLEdBQWdDbkMsZ0JBQWhDO0FBQ0EsVUFBSTNPLE1BQU0sR0FBRzJDLEtBQUssQ0FBQ3dILE1BQU4sQ0FBYTtBQUFDSyxlQUFPLEVBQUMrSCxXQUFXLENBQUMvSDtBQUFyQixPQUFiLEVBQTRDO0FBQUNILFlBQUksRUFBQ2tJO0FBQU4sT0FBNUMsQ0FBYjtBQUdBalQsYUFBTyxDQUFDQyxHQUFSLENBQVksMENBQVo7QUFFSDs7QUFFRCxXQUFPLElBQVA7QUFDSDtBQXhSVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDZkEsSUFBSWQsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJK0QsS0FBSixFQUFVMk0sV0FBVjtBQUFzQjVRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ2dFLE9BQUssQ0FBQy9ELENBQUQsRUFBRztBQUFDK0QsU0FBSyxHQUFDL0QsQ0FBTjtBQUFRLEdBQWxCOztBQUFtQjBRLGFBQVcsQ0FBQzFRLENBQUQsRUFBRztBQUFDMFEsZUFBVyxHQUFDMVEsQ0FBWjtBQUFjOztBQUFoRCxDQUExQixFQUE0RSxDQUE1RTtBQUErRSxJQUFJd1YsU0FBSjtBQUFjMVYsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ3lWLFdBQVMsQ0FBQ3hWLENBQUQsRUFBRztBQUFDd1YsYUFBUyxHQUFDeFYsQ0FBVjtBQUFZOztBQUExQixDQUE3QyxFQUF5RSxDQUF6RTtBQUE0RSxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUs5UUgsTUFBTSxDQUFDNFYsT0FBUCxDQUFlLG9CQUFmLEVBQXFDLFlBQVk7QUFDN0MsU0FBTyxDQUNIL0UsV0FBVyxDQUFDL0ssSUFBWixDQUFpQixFQUFqQixFQUFvQjtBQUFDaUMsUUFBSSxFQUFDO0FBQUMzQixZQUFNLEVBQUMsQ0FBQztBQUFULEtBQU47QUFBa0I0QixTQUFLLEVBQUM7QUFBeEIsR0FBcEIsQ0FERyxFQUVIMk4sU0FBUyxDQUFDN1AsSUFBVixDQUFlLEVBQWYsRUFBa0I7QUFBQ2lDLFFBQUksRUFBQztBQUFDOE4scUJBQWUsRUFBQyxDQUFDO0FBQWxCLEtBQU47QUFBMkI3TixTQUFLLEVBQUM7QUFBakMsR0FBbEIsQ0FGRyxDQUFQO0FBSUgsQ0FMRDtBQU9Bc0ksZ0JBQWdCLENBQUMsY0FBRCxFQUFpQixZQUFVO0FBQ3ZDLFNBQU87QUFDSHhLLFFBQUksR0FBRTtBQUNGLGFBQU81QixLQUFLLENBQUM0QixJQUFOLENBQVc7QUFBQ2lHLGVBQU8sRUFBQy9MLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEU7QUFBaEMsT0FBWCxDQUFQO0FBQ0gsS0FIRTs7QUFJSHdFLFlBQVEsRUFBRSxDQUNOO0FBQ0l6SyxVQUFJLENBQUMrTCxLQUFELEVBQU87QUFDUCxlQUFPeFIsVUFBVSxDQUFDeUYsSUFBWCxDQUNILEVBREcsRUFFSDtBQUFDNEksZ0JBQU0sRUFBQztBQUNKMU4sbUJBQU8sRUFBQyxDQURKO0FBRUpzTSx1QkFBVyxFQUFDLENBRlI7QUFHSi9LLDRCQUFnQixFQUFDLENBSGI7QUFJSm9GLGtCQUFNLEVBQUMsQ0FBQyxDQUpKO0FBS0o2RixrQkFBTSxFQUFDLENBTEg7QUFNSkQsdUJBQVcsRUFBQztBQU5SO0FBQVIsU0FGRyxDQUFQO0FBV0g7O0FBYkwsS0FETTtBQUpQLEdBQVA7QUFzQkgsQ0F2QmUsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUNaQXROLE1BQU0sQ0FBQ3VRLE1BQVAsQ0FBYztBQUFDdE0sT0FBSyxFQUFDLE1BQUlBLEtBQVg7QUFBaUIyTSxhQUFXLEVBQUMsTUFBSUE7QUFBakMsQ0FBZDtBQUE2RCxJQUFJSixLQUFKO0FBQVV4USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN1USxPQUFLLENBQUN0USxDQUFELEVBQUc7QUFBQ3NRLFNBQUssR0FBQ3RRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBMUMsRUFBd0UsQ0FBeEU7QUFHakksTUFBTStELEtBQUssR0FBRyxJQUFJdU0sS0FBSyxDQUFDQyxVQUFWLENBQXFCLE9BQXJCLENBQWQ7QUFDQSxNQUFNRyxXQUFXLEdBQUcsSUFBSUosS0FBSyxDQUFDQyxVQUFWLENBQXFCLGNBQXJCLENBQXBCO0FBRVB4TSxLQUFLLENBQUN5TSxPQUFOLENBQWM7QUFDVkMsVUFBUSxHQUFFO0FBQ04sV0FBT3ZRLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQ3JCLGFBQU8sRUFBQyxLQUFLK0U7QUFBZCxLQUFuQixDQUFQO0FBQ0g7O0FBSFMsQ0FBZCxFOzs7Ozs7Ozs7OztBQ05BLElBQUkvRixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl3VixTQUFKO0FBQWMxVixNQUFNLENBQUNDLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDeVYsV0FBUyxDQUFDeFYsQ0FBRCxFQUFHO0FBQUN3VixhQUFTLEdBQUN4VixDQUFWO0FBQVk7O0FBQTFCLENBQS9CLEVBQTJELENBQTNEO0FBQThELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFJckpILE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsNEJBQTBCLFlBQVU7QUFDaEMsU0FBS0UsT0FBTDtBQUNBLFFBQUk2VSxNQUFNLEdBQUc5VixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjhPLFdBQXBDOztBQUNBLFFBQUlELE1BQUosRUFBVztBQUNQLFVBQUc7QUFDQyxZQUFJRSxHQUFHLEdBQUcsSUFBSTVTLElBQUosRUFBVjtBQUNBNFMsV0FBRyxDQUFDQyxVQUFKLENBQWUsQ0FBZjtBQUNBLFlBQUkxVixHQUFHLEdBQUcsdURBQXFEdVYsTUFBckQsR0FBNEQsd0hBQXRFO0FBQ0EsWUFBSTNVLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjs7QUFDQSxZQUFJWSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0I7QUFDQSxjQUFJZ0MsSUFBSSxHQUFHdkIsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBWDtBQUNBcUIsY0FBSSxHQUFHQSxJQUFJLENBQUNtVCxNQUFELENBQVgsQ0FIMkIsQ0FJM0I7O0FBQ0EsaUJBQU9ILFNBQVMsQ0FBQ2pLLE1BQVYsQ0FBaUI7QUFBQ21LLDJCQUFlLEVBQUNsVCxJQUFJLENBQUNrVDtBQUF0QixXQUFqQixFQUF5RDtBQUFDakssZ0JBQUksRUFBQ2pKO0FBQU4sV0FBekQsQ0FBUDtBQUNIO0FBQ0osT0FaRCxDQWFBLE9BQU0vQixDQUFOLEVBQVE7QUFDSkMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLEtBakJELE1Ba0JJO0FBQ0EsYUFBTywyQkFBUDtBQUNIO0FBQ0osR0F6QlU7QUEwQlgsd0JBQXNCLFlBQVU7QUFDNUIsU0FBS0ssT0FBTDtBQUNBLFFBQUk2VSxNQUFNLEdBQUc5VixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjhPLFdBQXBDOztBQUNBLFFBQUlELE1BQUosRUFBVztBQUNQLGFBQVFILFNBQVMsQ0FBQ3RULE9BQVYsQ0FBa0IsRUFBbEIsRUFBcUI7QUFBQzBGLFlBQUksRUFBQztBQUFDOE4seUJBQWUsRUFBQyxDQUFDO0FBQWxCO0FBQU4sT0FBckIsQ0FBUjtBQUNILEtBRkQsTUFHSTtBQUNBLGFBQU8sMkJBQVA7QUFDSDtBQUVKO0FBcENVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNKQTVWLE1BQU0sQ0FBQ3VRLE1BQVAsQ0FBYztBQUFDbUYsV0FBUyxFQUFDLE1BQUlBO0FBQWYsQ0FBZDtBQUF5QyxJQUFJbEYsS0FBSjtBQUFVeFEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDdVEsT0FBSyxDQUFDdFEsQ0FBRCxFQUFHO0FBQUNzUSxTQUFLLEdBQUN0USxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRTVDLE1BQU13VixTQUFTLEdBQUcsSUFBSWxGLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixZQUFyQixDQUFsQixDOzs7Ozs7Ozs7OztBQ0ZQLElBQUkxUSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUkrVixXQUFKO0FBQWdCalcsTUFBTSxDQUFDQyxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQ2dXLGFBQVcsQ0FBQy9WLENBQUQsRUFBRztBQUFDK1YsZUFBVyxHQUFDL1YsQ0FBWjtBQUFjOztBQUE5QixDQUFoQyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUlsS0gsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCxnQ0FBOEIsWUFBVTtBQUNwQyxTQUFLRSxPQUFMO0FBQ0EsUUFBSThELFVBQVUsR0FBRzFFLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0JFLEtBQXBCLEVBQWpCO0FBQ0EsUUFBSWhFLFdBQVcsR0FBRyxFQUFsQjtBQUNBbkIsV0FBTyxDQUFDQyxHQUFSLENBQVksNkJBQVo7O0FBQ0EsU0FBS1gsQ0FBTCxJQUFVNEUsVUFBVixFQUFxQjtBQUNqQixVQUFJQSxVQUFVLENBQUM1RSxDQUFELENBQVYsQ0FBY29DLGdCQUFsQixFQUFtQztBQUMvQixZQUFJaEMsR0FBRyxHQUFHRyxHQUFHLEdBQUcsc0JBQU4sR0FBNkJxRSxVQUFVLENBQUM1RSxDQUFELENBQVYsQ0FBY29DLGdCQUEzQyxHQUE0RCxjQUF0RTs7QUFDQSxZQUFHO0FBQ0MsY0FBSXBCLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjs7QUFDQSxjQUFJWSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0IsZ0JBQUk4QyxVQUFVLEdBQUdyQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBOUMsQ0FEMkIsQ0FFM0I7O0FBQ0FTLHVCQUFXLEdBQUdBLFdBQVcsQ0FBQ21VLE1BQVosQ0FBbUIxUyxVQUFuQixDQUFkO0FBQ0gsV0FKRCxNQUtJO0FBQ0E1QyxtQkFBTyxDQUFDQyxHQUFSLENBQVlLLFFBQVEsQ0FBQ1IsVUFBckI7QUFDSDtBQUNKLFNBVkQsQ0FXQSxPQUFPQyxDQUFQLEVBQVM7QUFDTEMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSjtBQUNKOztBQUVELFNBQUs4QyxDQUFMLElBQVUxQixXQUFWLEVBQXNCO0FBQ2xCLFVBQUlBLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxJQUFrQjFCLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxDQUFlZCxNQUFyQyxFQUNJWixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBZixHQUF3QkMsVUFBVSxDQUFDYixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBaEIsQ0FBbEM7QUFDUCxLQTVCbUMsQ0E4QnBDOzs7QUFDQSxRQUFJRCxJQUFJLEdBQUc7QUFDUFgsaUJBQVcsRUFBRUEsV0FETjtBQUVQb1UsZUFBUyxFQUFFLElBQUloVCxJQUFKO0FBRkosS0FBWDtBQUtBLFdBQU84UyxXQUFXLENBQUMxTCxNQUFaLENBQW1CN0gsSUFBbkIsQ0FBUDtBQUNILEdBdENVLENBdUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQXBEVyxDQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0pBMUMsTUFBTSxDQUFDdVEsTUFBUCxDQUFjO0FBQUMwRixhQUFXLEVBQUMsTUFBSUE7QUFBakIsQ0FBZDtBQUE2QyxJQUFJekYsS0FBSjtBQUFVeFEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDdVEsT0FBSyxDQUFDdFEsQ0FBRCxFQUFHO0FBQUNzUSxTQUFLLEdBQUN0USxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRWhELE1BQU0rVixXQUFXLEdBQUcsSUFBSXpGLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixhQUFyQixDQUFwQixDOzs7Ozs7Ozs7OztBQ0ZQLElBQUkxUSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSWtXLFVBQUo7QUFBZXBXLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUNtVyxZQUFVLENBQUNsVyxDQUFELEVBQUc7QUFBQ2tXLGNBQVUsR0FBQ2xXLENBQVg7QUFBYTs7QUFBNUIsQ0FBL0IsRUFBNkQsQ0FBN0Q7QUFJdklILE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsa0NBQWdDLFlBQVU7QUFDdEMsU0FBS0UsT0FBTDs7QUFDQSxRQUFHO0FBQ0MsVUFBSVYsR0FBRyxHQUFHRyxHQUFHLEdBQUcsaUJBQWhCO0FBQ0EsVUFBSVMsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsVUFBSStWLGNBQWMsR0FBR2xWLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUFsRDtBQUVBLFVBQUlnVixzQkFBc0IsR0FBRyxJQUFJQyxHQUFKLENBQVFILFVBQVUsQ0FBQ3ZRLElBQVgsQ0FDakM7QUFBQyxrQkFBUztBQUFDUSxhQUFHLEVBQUMsQ0FBQyxRQUFELEVBQVcsVUFBWDtBQUFMO0FBQVYsT0FEaUMsRUFFbkNOLEtBRm1DLEdBRTNCRSxHQUYyQixDQUV0QmxCLENBQUQsSUFBTUEsQ0FBQyxDQUFDeVIsSUFGZSxDQUFSLENBQTdCO0FBSUEsVUFBSUMsS0FBSyxHQUFHLEVBQVo7O0FBRUEsVUFBSUosY0FBYyxDQUFDdlUsTUFBZixHQUF3QixDQUE1QixFQUErQjtBQUMzQixjQUFNNFUsT0FBTyxHQUFHTixVQUFVLENBQUMxUCxhQUFYLEdBQTJCb0MseUJBQTNCLEVBQWhCOztBQUNBLGFBQUssSUFBSXJGLENBQVQsSUFBYzRTLGNBQWQsRUFBOEI7QUFDMUIsY0FBSU0sRUFBRSxHQUFHTixjQUFjLENBQUM1UyxDQUFELENBQXZCO0FBQ0FrVCxZQUFFLENBQUNILElBQUgsR0FBVTVMLFFBQVEsQ0FBQytMLEVBQUUsQ0FBQ0MsRUFBSixDQUFsQjs7QUFDQSxjQUFJRCxFQUFFLENBQUNILElBQUgsR0FBVSxDQUFWLElBQWUsQ0FBQ0Ysc0JBQXNCLENBQUNPLEdBQXZCLENBQTJCRixFQUFFLENBQUNILElBQTlCLENBQXBCLEVBQXlEO0FBQ3JELGdCQUFJO0FBQ0FFLHFCQUFPLENBQUM3USxJQUFSLENBQWE7QUFBQzJRLG9CQUFJLEVBQUVHLEVBQUUsQ0FBQ0g7QUFBVixlQUFiLEVBQThCL0ssTUFBOUIsR0FBdUNDLFNBQXZDLENBQWlEO0FBQUNDLG9CQUFJLEVBQUVnTDtBQUFQLGVBQWpEO0FBQ0FGLG1CQUFLLENBQUMxTSxJQUFOLENBQVc0TSxFQUFFLENBQUNILElBQWQ7QUFDSCxhQUhELENBR0UsT0FBTTdWLENBQU4sRUFBUztBQUNQK1YscUJBQU8sQ0FBQzdRLElBQVIsQ0FBYTtBQUFDMlEsb0JBQUksRUFBRUcsRUFBRSxDQUFDSDtBQUFWLGVBQWIsRUFBOEIvSyxNQUE5QixHQUF1Q0MsU0FBdkMsQ0FBaUQ7QUFBQ0Msb0JBQUksRUFBRWdMO0FBQVAsZUFBakQ7QUFDQUYsbUJBQUssQ0FBQzFNLElBQU4sQ0FBVzRNLEVBQUUsQ0FBQ0gsSUFBZDtBQUNBNVYscUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFDLENBQUNPLFFBQUYsQ0FBV0csT0FBdkI7QUFDSDtBQUNKO0FBQ0o7O0FBQ0QsWUFBR29WLEtBQUssQ0FBQzNVLE1BQU4sR0FBZSxDQUFsQixFQUFxQjtBQUNqQjRVLGlCQUFPLENBQUN6SCxPQUFSO0FBQ0g7QUFDSjs7QUFDRCxhQUFPLElBQVA7QUFDSCxLQWhDRCxDQWlDQSxPQUFPdE8sQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSjtBQXZDVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDSkEsSUFBSVosTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJa1csVUFBSjtBQUFlcFcsTUFBTSxDQUFDQyxJQUFQLENBQVksa0JBQVosRUFBK0I7QUFBQ21XLFlBQVUsQ0FBQ2xXLENBQUQsRUFBRztBQUFDa1csY0FBVSxHQUFDbFcsQ0FBWDtBQUFhOztBQUE1QixDQUEvQixFQUE2RCxDQUE3RDtBQUFnRSxJQUFJNFcsS0FBSjtBQUFVOVcsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDNlcsT0FBSyxDQUFDNVcsQ0FBRCxFQUFHO0FBQUM0VyxTQUFLLEdBQUM1VyxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBSXpKSCxNQUFNLENBQUM0VixPQUFQLENBQWUscUJBQWYsRUFBc0MsWUFBWTtBQUM5QyxTQUFPUyxVQUFVLENBQUN2USxJQUFYLENBQWdCLEVBQWhCLEVBQW9CO0FBQUNpQyxRQUFJLEVBQUM7QUFBQzBPLFVBQUksRUFBQyxDQUFDO0FBQVA7QUFBTixHQUFwQixDQUFQO0FBQ0gsQ0FGRDtBQUlBelcsTUFBTSxDQUFDNFYsT0FBUCxDQUFlLG1CQUFmLEVBQW9DLFVBQVVpQixFQUFWLEVBQWE7QUFDN0NFLE9BQUssQ0FBQ0YsRUFBRCxFQUFLRyxNQUFMLENBQUw7QUFDQSxTQUFPWCxVQUFVLENBQUN2USxJQUFYLENBQWdCO0FBQUMyUSxRQUFJLEVBQUNJO0FBQU4sR0FBaEIsQ0FBUDtBQUNILENBSEQsRTs7Ozs7Ozs7Ozs7QUNSQTVXLE1BQU0sQ0FBQ3VRLE1BQVAsQ0FBYztBQUFDNkYsWUFBVSxFQUFDLE1BQUlBO0FBQWhCLENBQWQ7QUFBMkMsSUFBSTVGLEtBQUo7QUFBVXhRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3VRLE9BQUssQ0FBQ3RRLENBQUQsRUFBRztBQUFDc1EsU0FBSyxHQUFDdFEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUU5QyxNQUFNa1csVUFBVSxHQUFHLElBQUk1RixLQUFLLENBQUNDLFVBQVYsQ0FBcUIsWUFBckIsQ0FBbkIsQzs7Ozs7Ozs7Ozs7QUNGUCxJQUFJdUcsYUFBSjs7QUFBa0JoWCxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQ0FBWixFQUFtRDtBQUFDZ1gsU0FBTyxDQUFDL1csQ0FBRCxFQUFHO0FBQUM4VyxpQkFBYSxHQUFDOVcsQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBbkQsRUFBaUYsQ0FBakY7QUFBbEIsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUVUSCxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLHdCQUFzQixVQUFTb1csTUFBVCxFQUFpQjtBQUNuQyxVQUFNNVcsR0FBRyxhQUFNRyxHQUFOLFNBQVQ7QUFDQWlDLFFBQUksR0FBRztBQUNILFlBQU13VSxNQUFNLENBQUN6VixLQURWO0FBRUgsY0FBUTtBQUZMLEtBQVA7QUFJQSxVQUFNMFYsU0FBUyxHQUFHLElBQUloVSxJQUFKLEdBQVdvSixPQUFYLEVBQWxCO0FBQ0EzTCxXQUFPLENBQUNDLEdBQVIsaUNBQXFDc1csU0FBckMsY0FBa0Q3VyxHQUFsRCx3QkFBbUVhLElBQUksQ0FBQ21FLFNBQUwsQ0FBZTVDLElBQWYsQ0FBbkU7QUFFQSxRQUFJeEIsUUFBUSxHQUFHZixJQUFJLENBQUNpWCxJQUFMLENBQVU5VyxHQUFWLEVBQWU7QUFBQ29DO0FBQUQsS0FBZixDQUFmO0FBQ0E5QixXQUFPLENBQUNDLEdBQVIsbUNBQXVDc1csU0FBdkMsY0FBb0Q3VyxHQUFwRCxlQUE0RGEsSUFBSSxDQUFDbUUsU0FBTCxDQUFlcEUsUUFBZixDQUE1RDs7QUFDQSxRQUFJQSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBZ0M7QUFDNUIsVUFBSWdDLElBQUksR0FBR3hCLFFBQVEsQ0FBQ3dCLElBQXBCO0FBQ0EsVUFBSUEsSUFBSSxDQUFDMlUsSUFBVCxFQUNJLE1BQU0sSUFBSXRYLE1BQU0sQ0FBQ3VYLEtBQVgsQ0FBaUI1VSxJQUFJLENBQUMyVSxJQUF0QixFQUE0QmxXLElBQUksQ0FBQ0MsS0FBTCxDQUFXc0IsSUFBSSxDQUFDNlUsT0FBaEIsRUFBeUJDLE9BQXJELENBQU47QUFDSixhQUFPdFcsUUFBUSxDQUFDd0IsSUFBVCxDQUFjK1UsTUFBckI7QUFDSDtBQUNKLEdBbEJVO0FBbUJYLHlCQUF1QixVQUFTQyxJQUFULEVBQWVDLElBQWYsRUFBcUI7QUFDeEMsVUFBTXJYLEdBQUcsYUFBTUcsR0FBTixjQUFha1gsSUFBYixDQUFUO0FBQ0FqVixRQUFJLEdBQUc7QUFDSCxvQ0FDT2dWLElBRFA7QUFFSSxvQkFBWTNYLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEUsT0FGdkM7QUFHSSxvQkFBWTtBQUhoQjtBQURHLEtBQVA7QUFPQSxRQUFJNUssUUFBUSxHQUFHZixJQUFJLENBQUNpWCxJQUFMLENBQVU5VyxHQUFWLEVBQWU7QUFBQ29DO0FBQUQsS0FBZixDQUFmOztBQUNBLFFBQUl4QixRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBZ0M7QUFDNUIsYUFBT1MsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBUDtBQUNIO0FBQ0osR0FoQ1U7QUFpQ1gsMEJBQXdCLFVBQVN1VyxLQUFULEVBQWdCeE4sSUFBaEIsRUFBc0J1TixJQUF0QixFQUE4QztBQUFBLFFBQWxCRSxVQUFrQix1RUFBUCxLQUFPO0FBQ2xFLFVBQU12WCxHQUFHLGFBQU1HLEdBQU4sY0FBYWtYLElBQWIsQ0FBVDtBQUNBalYsUUFBSSxxQkFBT2tWLEtBQVA7QUFDQSxrQkFBWTtBQUNSLGdCQUFReE4sSUFEQTtBQUVSLG9CQUFZckssTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RSxPQUYzQjtBQUdSLDBCQUFrQitMLFVBSFY7QUFJUixvQkFBWTtBQUpKO0FBRFosTUFBSjtBQVFBLFFBQUkzVyxRQUFRLEdBQUdmLElBQUksQ0FBQ2lYLElBQUwsQ0FBVTlXLEdBQVYsRUFBZTtBQUFDb0M7QUFBRCxLQUFmLENBQWY7O0FBQ0EsUUFBSXhCLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUFnQztBQUM1QixhQUFPUyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QnlXLFlBQXBDO0FBQ0g7QUFDSjtBQS9DVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDRkEsSUFBSS9YLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXNRLEtBQUo7QUFBVXhRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3VRLE9BQUssQ0FBQ3RRLENBQUQsRUFBRztBQUFDc1EsU0FBSyxHQUFDdFEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJaUUsZ0JBQUosRUFBcUJDLFNBQXJCLEVBQStCMlQsV0FBL0IsRUFBMkNDLG9CQUEzQztBQUFnRWhZLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ2tFLGtCQUFnQixDQUFDakUsQ0FBRCxFQUFHO0FBQUNpRSxvQkFBZ0IsR0FBQ2pFLENBQWpCO0FBQW1CLEdBQXhDOztBQUF5Q2tFLFdBQVMsQ0FBQ2xFLENBQUQsRUFBRztBQUFDa0UsYUFBUyxHQUFDbEUsQ0FBVjtBQUFZLEdBQWxFOztBQUFtRTZYLGFBQVcsQ0FBQzdYLENBQUQsRUFBRztBQUFDNlgsZUFBVyxHQUFDN1gsQ0FBWjtBQUFjLEdBQWhHOztBQUFpRzhYLHNCQUFvQixDQUFDOVgsQ0FBRCxFQUFHO0FBQUM4WCx3QkFBb0IsR0FBQzlYLENBQXJCO0FBQXVCOztBQUFoSixDQUE1QixFQUE4SyxDQUE5SztBQUFpTCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJZ0UsYUFBSjtBQUFrQmxFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtDQUFaLEVBQTREO0FBQUNpRSxlQUFhLENBQUNoRSxDQUFELEVBQUc7QUFBQ2dFLGlCQUFhLEdBQUNoRSxDQUFkO0FBQWdCOztBQUFsQyxDQUE1RCxFQUFnRyxDQUFoRztBQUFtRyxJQUFJK1gsTUFBSjtBQUFXalksTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQ2dZLFFBQU0sQ0FBQy9YLENBQUQsRUFBRztBQUFDK1gsVUFBTSxHQUFDL1gsQ0FBUDtBQUFTOztBQUFwQixDQUFyQyxFQUEyRCxDQUEzRDtBQUE4RCxJQUFJZ1ksaUJBQUo7QUFBc0JsWSxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNpWSxtQkFBaUIsQ0FBQ2hZLENBQUQsRUFBRztBQUFDZ1kscUJBQWlCLEdBQUNoWSxDQUFsQjtBQUFvQjs7QUFBMUMsQ0FBNUIsRUFBd0UsQ0FBeEU7QUFBMkUsSUFBSWlZLFlBQUo7QUFBaUJuWSxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNrWSxjQUFZLENBQUNqWSxDQUFELEVBQUc7QUFBQ2lZLGdCQUFZLEdBQUNqWSxDQUFiO0FBQWU7O0FBQWhDLENBQTVCLEVBQThELENBQTlEO0FBQWlFLElBQUk4RCxTQUFKO0FBQWNoRSxNQUFNLENBQUNDLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDK0QsV0FBUyxDQUFDOUQsQ0FBRCxFQUFHO0FBQUM4RCxhQUFTLEdBQUM5RCxDQUFWO0FBQVk7O0FBQTFCLENBQXJDLEVBQWlFLENBQWpFO0FBQW9FLElBQUkrRCxLQUFKO0FBQVVqRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDZ0UsT0FBSyxDQUFDL0QsQ0FBRCxFQUFHO0FBQUMrRCxTQUFLLEdBQUMvRCxDQUFOO0FBQVE7O0FBQWxCLENBQW5DLEVBQXVELENBQXZEOztBQUEwRCxJQUFJa1ksQ0FBSjs7QUFBTXBZLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQ2dYLFNBQU8sQ0FBQy9XLENBQUQsRUFBRztBQUFDa1ksS0FBQyxHQUFDbFksQ0FBRjtBQUFJOztBQUFoQixDQUFyQixFQUF1QyxFQUF2QztBQVd2OUIsTUFBTW1ZLGlCQUFpQixHQUFHLElBQTFCOztBQUVBLE1BQU1DLGFBQWEsR0FBRyxDQUFDdFEsV0FBRCxFQUFjdVEsWUFBZCxLQUErQjtBQUNqRCxNQUFJQyxVQUFVLEdBQUcsRUFBakI7QUFDQSxRQUFNQyxJQUFJLEdBQUc7QUFBQ0MsUUFBSSxFQUFFLENBQ2hCO0FBQUV2UyxZQUFNLEVBQUU7QUFBRXdTLFdBQUcsRUFBRTNRO0FBQVA7QUFBVixLQURnQixFQUVoQjtBQUFFN0IsWUFBTSxFQUFFO0FBQUV5UyxZQUFJLEVBQUVMO0FBQVI7QUFBVixLQUZnQjtBQUFQLEdBQWI7QUFHQSxRQUFNTSxPQUFPLEdBQUc7QUFBQy9RLFFBQUksRUFBQztBQUFDM0IsWUFBTSxFQUFFO0FBQVQ7QUFBTixHQUFoQjtBQUNBbkMsV0FBUyxDQUFDNkIsSUFBVixDQUFlNFMsSUFBZixFQUFxQkksT0FBckIsRUFBOEI5VixPQUE5QixDQUF1Q21ELEtBQUQsSUFBVztBQUM3Q3NTLGNBQVUsQ0FBQ3RTLEtBQUssQ0FBQ0MsTUFBUCxDQUFWLEdBQTJCO0FBQ3ZCQSxZQUFNLEVBQUVELEtBQUssQ0FBQ0MsTUFEUztBQUV2QkwscUJBQWUsRUFBRUksS0FBSyxDQUFDSixlQUZBO0FBR3ZCMEUscUJBQWUsRUFBRXRFLEtBQUssQ0FBQ3NFLGVBSEE7QUFJdkJLLHFCQUFlLEVBQUUzRSxLQUFLLENBQUMyRSxlQUpBO0FBS3ZCL0YsZ0JBQVUsRUFBRW9CLEtBQUssQ0FBQ3BCLFVBTEs7QUFNdkI1QixVQUFJLEVBQUVnRCxLQUFLLENBQUNoRDtBQU5XLEtBQTNCO0FBUUgsR0FURDtBQVdBa0IsV0FBUyxDQUFDeUIsSUFBVixDQUFlNFMsSUFBZixFQUFxQkksT0FBckIsRUFBOEI5VixPQUE5QixDQUF1Q21ELEtBQUQsSUFBVztBQUM3QyxRQUFJLENBQUNzUyxVQUFVLENBQUN0UyxLQUFLLENBQUNDLE1BQVAsQ0FBZixFQUErQjtBQUMzQnFTLGdCQUFVLENBQUN0UyxLQUFLLENBQUNDLE1BQVAsQ0FBVixHQUEyQjtBQUFFQSxjQUFNLEVBQUVELEtBQUssQ0FBQ0M7QUFBaEIsT0FBM0I7QUFDQXZGLGFBQU8sQ0FBQ0MsR0FBUixpQkFBcUJxRixLQUFLLENBQUNDLE1BQTNCO0FBQ0g7O0FBQ0RpUyxLQUFDLENBQUNVLE1BQUYsQ0FBU04sVUFBVSxDQUFDdFMsS0FBSyxDQUFDQyxNQUFQLENBQW5CLEVBQW1DO0FBQy9CMEQsZ0JBQVUsRUFBRTNELEtBQUssQ0FBQzJELFVBRGE7QUFFL0I2QyxzQkFBZ0IsRUFBRXhHLEtBQUssQ0FBQ3dHLGdCQUZPO0FBRy9CbEcsY0FBUSxFQUFFTixLQUFLLENBQUNNLFFBSGU7QUFJL0I0RSxrQkFBWSxFQUFFbEYsS0FBSyxDQUFDa0Y7QUFKVyxLQUFuQztBQU1ILEdBWEQ7QUFZQSxTQUFPb04sVUFBUDtBQUNILENBOUJEOztBQWdDQSxNQUFNTyxpQkFBaUIsR0FBRyxDQUFDQyxZQUFELEVBQWVsVCxlQUFmLEtBQW1DO0FBQ3pELE1BQUltVCxjQUFjLEdBQUdkLFlBQVksQ0FBQy9WLE9BQWIsQ0FDakI7QUFBQzhXLFNBQUssRUFBQ0YsWUFBUDtBQUFxQnJJLFlBQVEsRUFBQzdLLGVBQTlCO0FBQStDcVQsZUFBVyxFQUFFLENBQUM7QUFBN0QsR0FEaUIsQ0FBckI7QUFFQSxNQUFJQyxpQkFBaUIsR0FBR3JaLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QkQsV0FBL0M7QUFDQSxNQUFJcVIsU0FBUyxHQUFHLEVBQWhCOztBQUNBLE1BQUlKLGNBQUosRUFBb0I7QUFDaEJJLGFBQVMsR0FBR2pCLENBQUMsQ0FBQ2tCLElBQUYsQ0FBT0wsY0FBUCxFQUF1QixDQUFDLFdBQUQsRUFBYyxZQUFkLENBQXZCLENBQVo7QUFDSCxHQUZELE1BRU87QUFDSEksYUFBUyxHQUFHO0FBQ1JFLGVBQVMsRUFBRSxDQURIO0FBRVJDLGdCQUFVLEVBQUU7QUFGSixLQUFaO0FBSUg7O0FBQ0QsU0FBT0gsU0FBUDtBQUNILENBZEQ7O0FBZ0JBdFosTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCw0Q0FBMEMsWUFBVTtBQUNoRCxRQUFJLENBQUMyWSxpQkFBTCxFQUF1QjtBQUNuQixVQUFJO0FBQ0EsWUFBSUMsU0FBUyxHQUFHdlcsSUFBSSxDQUFDNFMsR0FBTCxFQUFoQjtBQUNBMEQseUJBQWlCLEdBQUcsSUFBcEI7QUFDQTdZLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLDhCQUFaO0FBQ0EsYUFBS0csT0FBTDtBQUNBLFlBQUk4RCxVQUFVLEdBQUcxRSxVQUFVLENBQUN5RixJQUFYLENBQWdCLEVBQWhCLEVBQW9CRSxLQUFwQixFQUFqQjtBQUNBLFlBQUl3UyxZQUFZLEdBQUd4WSxNQUFNLENBQUNxSSxJQUFQLENBQVkseUJBQVosQ0FBbkI7QUFDQSxZQUFJdVIsY0FBYyxHQUFHMUIsTUFBTSxDQUFDN1YsT0FBUCxDQUFlO0FBQUMwSixpQkFBTyxFQUFFL0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFqQyxTQUFmLENBQXJCO0FBQ0EsWUFBSTlELFdBQVcsR0FBSTJSLGNBQWMsSUFBRUEsY0FBYyxDQUFDQyw4QkFBaEMsR0FBZ0VELGNBQWMsQ0FBQ0MsOEJBQS9FLEdBQThHN1osTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCRCxXQUF2SjtBQUNBdVEsb0JBQVksR0FBR2xNLElBQUksQ0FBQ3dOLEdBQUwsQ0FBUzdSLFdBQVcsR0FBR3FRLGlCQUF2QixFQUEwQ0UsWUFBMUMsQ0FBZjtBQUNBLGNBQU11QixlQUFlLEdBQUczQixZQUFZLENBQUN6UixhQUFiLEdBQTZCcVQsdUJBQTdCLEVBQXhCO0FBRUEsWUFBSUMsYUFBYSxHQUFHLEVBQXBCO0FBQ0FsVixrQkFBVSxDQUFDL0IsT0FBWCxDQUFvQlosU0FBRCxJQUFlNlgsYUFBYSxDQUFDN1gsU0FBUyxDQUFDcEIsT0FBWCxDQUFiLEdBQW1Db0IsU0FBckUsRUFiQSxDQWVBOztBQUNBLFlBQUlxVyxVQUFVLEdBQUdGLGFBQWEsQ0FBQ3RRLFdBQUQsRUFBY3VRLFlBQWQsQ0FBOUIsQ0FoQkEsQ0FrQkE7O0FBQ0EsWUFBSTBCLGtCQUFrQixHQUFHLEVBQXpCOztBQUVBN0IsU0FBQyxDQUFDclYsT0FBRixDQUFVeVYsVUFBVixFQUFzQixDQUFDdFMsS0FBRCxFQUFRaVQsV0FBUixLQUF3QjtBQUMxQyxjQUFJclQsZUFBZSxHQUFHSSxLQUFLLENBQUNKLGVBQTVCO0FBQ0EsY0FBSW9VLGVBQWUsR0FBRyxJQUFJM0QsR0FBSixDQUFRclEsS0FBSyxDQUFDcEIsVUFBZCxDQUF0QjtBQUNBLGNBQUlxVixhQUFhLEdBQUdqVyxhQUFhLENBQUM5QixPQUFkLENBQXNCO0FBQUN1SSx3QkFBWSxFQUFDekUsS0FBSyxDQUFDQztBQUFwQixXQUF0QixDQUFwQjtBQUNBLGNBQUlpVSxnQkFBZ0IsR0FBRyxDQUF2QjtBQUVBRCx1QkFBYSxDQUFDclYsVUFBZCxDQUF5Qi9CLE9BQXpCLENBQWtDc1gsZUFBRCxJQUFxQjtBQUNsRCxnQkFBSUgsZUFBZSxDQUFDckQsR0FBaEIsQ0FBb0J3RCxlQUFlLENBQUN0WixPQUFwQyxDQUFKLEVBQ0lxWixnQkFBZ0IsSUFBSXhYLFVBQVUsQ0FBQ3lYLGVBQWUsQ0FBQ2pQLFlBQWpCLENBQTlCO0FBQ1AsV0FIRDtBQUtBK08sdUJBQWEsQ0FBQ3JWLFVBQWQsQ0FBeUIvQixPQUF6QixDQUFrQ3NYLGVBQUQsSUFBcUI7QUFDbEQsZ0JBQUlDLGdCQUFnQixHQUFHRCxlQUFlLENBQUN0WixPQUF2Qzs7QUFDQSxnQkFBSSxDQUFDcVgsQ0FBQyxDQUFDdkIsR0FBRixDQUFNb0Qsa0JBQU4sRUFBMEIsQ0FBQ25VLGVBQUQsRUFBa0J3VSxnQkFBbEIsQ0FBMUIsQ0FBTCxFQUFxRTtBQUNqRSxrQkFBSWpCLFNBQVMsR0FBR04saUJBQWlCLENBQUN1QixnQkFBRCxFQUFtQnhVLGVBQW5CLENBQWpDOztBQUNBc1MsZUFBQyxDQUFDbUMsR0FBRixDQUFNTixrQkFBTixFQUEwQixDQUFDblUsZUFBRCxFQUFrQndVLGdCQUFsQixDQUExQixFQUErRGpCLFNBQS9EO0FBQ0g7O0FBRURqQixhQUFDLENBQUMzTCxNQUFGLENBQVN3TixrQkFBVCxFQUE2QixDQUFDblUsZUFBRCxFQUFrQndVLGdCQUFsQixFQUFvQyxZQUFwQyxDQUE3QixFQUFpRkUsQ0FBRCxJQUFPQSxDQUFDLEdBQUMsQ0FBekY7O0FBQ0EsZ0JBQUksQ0FBQ04sZUFBZSxDQUFDckQsR0FBaEIsQ0FBb0J5RCxnQkFBcEIsQ0FBTCxFQUE0QztBQUN4Q2xDLGVBQUMsQ0FBQzNMLE1BQUYsQ0FBU3dOLGtCQUFULEVBQTZCLENBQUNuVSxlQUFELEVBQWtCd1UsZ0JBQWxCLEVBQW9DLFdBQXBDLENBQTdCLEVBQWdGRSxDQUFELElBQU9BLENBQUMsR0FBQyxDQUF4Rjs7QUFDQVYsNkJBQWUsQ0FBQ3ZQLE1BQWhCLENBQXVCO0FBQ25CMk8scUJBQUssRUFBRW9CLGdCQURZO0FBRW5CbkIsMkJBQVcsRUFBRWpULEtBQUssQ0FBQ0MsTUFGQTtBQUduQndLLHdCQUFRLEVBQUU3SyxlQUhTO0FBSW5CMEUsK0JBQWUsRUFBRXRFLEtBQUssQ0FBQ3NFLGVBSko7QUFLbkJLLCtCQUFlLEVBQUUzRSxLQUFLLENBQUMyRSxlQUxKO0FBTW5CM0gsb0JBQUksRUFBRWdELEtBQUssQ0FBQ2hELElBTk87QUFPbkIyRywwQkFBVSxFQUFFM0QsS0FBSyxDQUFDMkQsVUFQQztBQVFuQjZDLGdDQUFnQixFQUFFeEcsS0FBSyxDQUFDd0csZ0JBUkw7QUFTbkJsRyx3QkFBUSxFQUFFTixLQUFLLENBQUNNLFFBVEc7QUFVbkJpVSwyQkFBVyxFQUFFdlUsS0FBSyxDQUFDa0YsWUFWQTtBQVduQmdQLGdDQVhtQjtBQVluQk0seUJBQVMsRUFBRW5DLFlBWlE7QUFhbkJnQix5QkFBUyxFQUFFbkIsQ0FBQyxDQUFDNVgsR0FBRixDQUFNeVosa0JBQU4sRUFBMEIsQ0FBQ25VLGVBQUQsRUFBa0J3VSxnQkFBbEIsRUFBb0MsV0FBcEMsQ0FBMUIsQ0FiUTtBQWNuQmQsMEJBQVUsRUFBRXBCLENBQUMsQ0FBQzVYLEdBQUYsQ0FBTXlaLGtCQUFOLEVBQTBCLENBQUNuVSxlQUFELEVBQWtCd1UsZ0JBQWxCLEVBQW9DLFlBQXBDLENBQTFCO0FBZE8sZUFBdkI7QUFnQkg7QUFDSixXQTNCRDtBQTRCSCxTQXZDRDs7QUF5Q0FsQyxTQUFDLENBQUNyVixPQUFGLENBQVVrWCxrQkFBVixFQUE4QixDQUFDVSxNQUFELEVBQVM3VSxlQUFULEtBQTZCO0FBQ3ZEc1MsV0FBQyxDQUFDclYsT0FBRixDQUFVNFgsTUFBVixFQUFrQixDQUFDQyxLQUFELEVBQVE1QixZQUFSLEtBQXlCO0FBQ3ZDYywyQkFBZSxDQUFDalUsSUFBaEIsQ0FBcUI7QUFDakJxVCxtQkFBSyxFQUFFRixZQURVO0FBRWpCckksc0JBQVEsRUFBRTdLLGVBRk87QUFHakJxVCx5QkFBVyxFQUFFLENBQUM7QUFIRyxhQUFyQixFQUlHMU4sTUFKSCxHQUlZQyxTQUpaLENBSXNCO0FBQUNDLGtCQUFJLEVBQUU7QUFDekJ1TixxQkFBSyxFQUFFRixZQURrQjtBQUV6QnJJLHdCQUFRLEVBQUU3SyxlQUZlO0FBR3pCcVQsMkJBQVcsRUFBRSxDQUFDLENBSFc7QUFJekJ1Qix5QkFBUyxFQUFFbkMsWUFKYztBQUt6QmdCLHlCQUFTLEVBQUVuQixDQUFDLENBQUM1WCxHQUFGLENBQU1vYSxLQUFOLEVBQWEsV0FBYixDQUxjO0FBTXpCcEIsMEJBQVUsRUFBRXBCLENBQUMsQ0FBQzVYLEdBQUYsQ0FBTW9hLEtBQU4sRUFBYSxZQUFiO0FBTmE7QUFBUCxhQUp0QjtBQVlILFdBYkQ7QUFjSCxTQWZEOztBQWlCQSxZQUFJcEQsT0FBTyxHQUFHLEVBQWQ7O0FBQ0EsWUFBSXNDLGVBQWUsQ0FBQ2hZLE1BQWhCLEdBQXlCLENBQTdCLEVBQStCO0FBQzNCLGdCQUFNK1ksTUFBTSxHQUFHMUMsWUFBWSxDQUFDMkMsT0FBYixDQUFxQkMsS0FBckIsQ0FBMkJGLE1BQTFDLENBRDJCLENBRTNCO0FBQ0E7QUFDQTs7QUFDQSxjQUFJRyxXQUFXLEdBQUdsQixlQUFlLENBQUM3SyxPQUFoQixDQUF3QjtBQUFJO0FBQTVCLFlBQTZDZ00sSUFBN0MsQ0FDZGxiLE1BQU0sQ0FBQ21iLGVBQVAsQ0FBdUIsQ0FBQzVaLE1BQUQsRUFBUytJLEdBQVQsS0FBaUI7QUFDcEMsZ0JBQUlBLEdBQUosRUFBUTtBQUNKb1AsK0JBQWlCLEdBQUcsS0FBcEIsQ0FESSxDQUVKOztBQUNBLG9CQUFNcFAsR0FBTjtBQUNIOztBQUNELGdCQUFJL0ksTUFBSixFQUFXO0FBQ1A7QUFDQWtXLHFCQUFPLEdBQUcsV0FBSWxXLE1BQU0sQ0FBQ0EsTUFBUCxDQUFjNlosU0FBbEIsNkJBQ0k3WixNQUFNLENBQUNBLE1BQVAsQ0FBYzhaLFNBRGxCLDZCQUVJOVosTUFBTSxDQUFDQSxNQUFQLENBQWMrWixTQUZsQixlQUFWO0FBR0g7QUFDSixXQVpELENBRGMsQ0FBbEI7QUFlQXRYLGlCQUFPLENBQUN1RCxLQUFSLENBQWMwVCxXQUFkO0FBQ0g7O0FBRUR2Qix5QkFBaUIsR0FBRyxLQUFwQjtBQUNBeEIsY0FBTSxDQUFDeE0sTUFBUCxDQUFjO0FBQUNLLGlCQUFPLEVBQUUvTCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjhFO0FBQWpDLFNBQWQsRUFBeUQ7QUFBQ0gsY0FBSSxFQUFDO0FBQUNpTywwQ0FBOEIsRUFBQ3JCLFlBQWhDO0FBQThDK0Msd0NBQTRCLEVBQUUsSUFBSW5ZLElBQUo7QUFBNUU7QUFBTixTQUF6RDtBQUNBLGlDQUFrQkEsSUFBSSxDQUFDNFMsR0FBTCxLQUFhMkQsU0FBL0IsZ0JBQThDbEMsT0FBOUM7QUFDSCxPQTFHRCxDQTBHRSxPQUFPN1csQ0FBUCxFQUFVO0FBQ1I4WSx5QkFBaUIsR0FBRyxLQUFwQjtBQUNBLGNBQU05WSxDQUFOO0FBQ0g7QUFDSixLQS9HRCxNQWdISTtBQUNBLGFBQU8sYUFBUDtBQUNIO0FBQ0osR0FySFU7QUFzSFgsaURBQStDLFlBQVU7QUFDckQ7QUFDQTtBQUNBLFFBQUksQ0FBQzRhLHNCQUFMLEVBQTRCO0FBQ3hCQSw0QkFBc0IsR0FBRyxJQUF6QjtBQUNBM2EsYUFBTyxDQUFDQyxHQUFSLENBQVksOEJBQVo7QUFDQSxXQUFLRyxPQUFMO0FBQ0EsVUFBSThELFVBQVUsR0FBRzFFLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0JFLEtBQXBCLEVBQWpCO0FBQ0EsVUFBSXdTLFlBQVksR0FBR3hZLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSx5QkFBWixDQUFuQjtBQUNBLFVBQUl1UixjQUFjLEdBQUcxQixNQUFNLENBQUM3VixPQUFQLENBQWU7QUFBQzBKLGVBQU8sRUFBRS9MLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEU7QUFBakMsT0FBZixDQUFyQjtBQUNBLFVBQUk5RCxXQUFXLEdBQUkyUixjQUFjLElBQUVBLGNBQWMsQ0FBQzZCLHFCQUFoQyxHQUF1RDdCLGNBQWMsQ0FBQzZCLHFCQUF0RSxHQUE0RnpiLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QkQsV0FBckksQ0FQd0IsQ0FReEI7QUFDQTs7QUFDQSxZQUFNOFIsZUFBZSxHQUFHNUIsaUJBQWlCLENBQUN4UixhQUFsQixHQUFrQ29DLHlCQUFsQyxFQUF4Qjs7QUFDQSxXQUFLckYsQ0FBTCxJQUFVcUIsVUFBVixFQUFxQjtBQUNqQjtBQUNBLFlBQUlrVSxZQUFZLEdBQUdsVSxVQUFVLENBQUNyQixDQUFELENBQVYsQ0FBYzFDLE9BQWpDO0FBQ0EsWUFBSTBhLGFBQWEsR0FBR3RYLGdCQUFnQixDQUFDMEIsSUFBakIsQ0FBc0I7QUFDdEM5RSxpQkFBTyxFQUFDaVksWUFEOEI7QUFFdEM3TixnQkFBTSxFQUFDLEtBRitCO0FBR3RDdU4sY0FBSSxFQUFFLENBQUU7QUFBRXZTLGtCQUFNLEVBQUU7QUFBRXdTLGlCQUFHLEVBQUUzUTtBQUFQO0FBQVYsV0FBRixFQUFvQztBQUFFN0Isa0JBQU0sRUFBRTtBQUFFeVMsa0JBQUksRUFBRUw7QUFBUjtBQUFWLFdBQXBDO0FBSGdDLFNBQXRCLEVBSWpCeFMsS0FKaUIsRUFBcEI7QUFNQSxZQUFJMlYsTUFBTSxHQUFHLEVBQWIsQ0FUaUIsQ0FXakI7O0FBQ0EsYUFBS25WLENBQUwsSUFBVWtWLGFBQVYsRUFBd0I7QUFDcEIsY0FBSXZWLEtBQUssR0FBR2xDLFNBQVMsQ0FBQzVCLE9BQVYsQ0FBa0I7QUFBQytELGtCQUFNLEVBQUNzVixhQUFhLENBQUNsVixDQUFELENBQWIsQ0FBaUJKO0FBQXpCLFdBQWxCLENBQVo7QUFDQSxjQUFJd1YsY0FBYyxHQUFHekQsaUJBQWlCLENBQUM5VixPQUFsQixDQUEwQjtBQUFDOFcsaUJBQUssRUFBQ0YsWUFBUDtBQUFxQnJJLG9CQUFRLEVBQUN6SyxLQUFLLENBQUNKO0FBQXBDLFdBQTFCLENBQXJCOztBQUVBLGNBQUksT0FBTzRWLE1BQU0sQ0FBQ3hWLEtBQUssQ0FBQ0osZUFBUCxDQUFiLEtBQXlDLFdBQTdDLEVBQXlEO0FBQ3JELGdCQUFJNlYsY0FBSixFQUFtQjtBQUNmRCxvQkFBTSxDQUFDeFYsS0FBSyxDQUFDSixlQUFQLENBQU4sR0FBZ0M2VixjQUFjLENBQUM3WCxLQUFmLEdBQXFCLENBQXJEO0FBQ0gsYUFGRCxNQUdJO0FBQ0E0WCxvQkFBTSxDQUFDeFYsS0FBSyxDQUFDSixlQUFQLENBQU4sR0FBZ0MsQ0FBaEM7QUFDSDtBQUNKLFdBUEQsTUFRSTtBQUNBNFYsa0JBQU0sQ0FBQ3hWLEtBQUssQ0FBQ0osZUFBUCxDQUFOO0FBQ0g7QUFDSjs7QUFFRCxhQUFLL0UsT0FBTCxJQUFnQjJhLE1BQWhCLEVBQXVCO0FBQ25CLGNBQUloWixJQUFJLEdBQUc7QUFDUHdXLGlCQUFLLEVBQUVGLFlBREE7QUFFUHJJLG9CQUFRLEVBQUM1UCxPQUZGO0FBR1ArQyxpQkFBSyxFQUFFNFgsTUFBTSxDQUFDM2EsT0FBRDtBQUhOLFdBQVg7QUFNQStZLHlCQUFlLENBQUNqVSxJQUFoQixDQUFxQjtBQUFDcVQsaUJBQUssRUFBQ0YsWUFBUDtBQUFxQnJJLG9CQUFRLEVBQUM1UDtBQUE5QixXQUFyQixFQUE2RDBLLE1BQTdELEdBQXNFQyxTQUF0RSxDQUFnRjtBQUFDQyxnQkFBSSxFQUFDako7QUFBTixXQUFoRjtBQUNILFNBckNnQixDQXNDakI7O0FBRUg7O0FBRUQsVUFBSW9YLGVBQWUsQ0FBQ2hZLE1BQWhCLEdBQXlCLENBQTdCLEVBQStCO0FBQzNCZ1ksdUJBQWUsQ0FBQzdLLE9BQWhCLENBQXdCbFAsTUFBTSxDQUFDbWIsZUFBUCxDQUF1QixDQUFDN1EsR0FBRCxFQUFNL0ksTUFBTixLQUFpQjtBQUM1RCxjQUFJK0ksR0FBSixFQUFRO0FBQ0prUixrQ0FBc0IsR0FBRyxLQUF6QjtBQUNBM2EsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZd0osR0FBWjtBQUNIOztBQUNELGNBQUkvSSxNQUFKLEVBQVc7QUFDUDJXLGtCQUFNLENBQUN4TSxNQUFQLENBQWM7QUFBQ0sscUJBQU8sRUFBRS9MLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEU7QUFBakMsYUFBZCxFQUF5RDtBQUFDSCxrQkFBSSxFQUFDO0FBQUM2UCxxQ0FBcUIsRUFBQ2pELFlBQXZCO0FBQXFDcUQsbUNBQW1CLEVBQUUsSUFBSXpZLElBQUo7QUFBMUQ7QUFBTixhQUF6RDtBQUNBb1ksa0NBQXNCLEdBQUcsS0FBekI7QUFDQTNhLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0g7QUFDSixTQVZ1QixDQUF4QjtBQVdILE9BWkQsTUFhSTtBQUNBMGEsOEJBQXNCLEdBQUcsS0FBekI7QUFDSDs7QUFFRCxhQUFPLElBQVA7QUFDSCxLQXZFRCxNQXdFSTtBQUNBLGFBQU8sYUFBUDtBQUNIO0FBQ0osR0FwTVU7QUFxTVgsZ0RBQThDLFVBQVNyWSxJQUFULEVBQWM7QUFDeEQsU0FBS2xDLE9BQUw7QUFDQSxRQUFJK1UsR0FBRyxHQUFHLElBQUk1UyxJQUFKLEVBQVY7O0FBRUEsUUFBSUQsSUFBSSxJQUFJLEdBQVosRUFBZ0I7QUFDWixVQUFJd0osZ0JBQWdCLEdBQUcsQ0FBdkI7QUFDQSxVQUFJbVAsa0JBQWtCLEdBQUcsQ0FBekI7QUFFQSxVQUFJQyxTQUFTLEdBQUcxWCxTQUFTLENBQUN5QixJQUFWLENBQWU7QUFBRSxnQkFBUTtBQUFFOFMsYUFBRyxFQUFFLElBQUl4VixJQUFKLENBQVNBLElBQUksQ0FBQzRTLEdBQUwsS0FBYSxLQUFLLElBQTNCO0FBQVA7QUFBVixPQUFmLEVBQXNFaFEsS0FBdEUsRUFBaEI7O0FBQ0EsVUFBSStWLFNBQVMsQ0FBQ2hhLE1BQVYsR0FBbUIsQ0FBdkIsRUFBeUI7QUFDckIsYUFBSzJCLENBQUwsSUFBVXFZLFNBQVYsRUFBb0I7QUFDaEJwUCwwQkFBZ0IsSUFBSW9QLFNBQVMsQ0FBQ3JZLENBQUQsQ0FBVCxDQUFhK0MsUUFBakM7QUFDQXFWLDRCQUFrQixJQUFJQyxTQUFTLENBQUNyWSxDQUFELENBQVQsQ0FBYTJILFlBQW5DO0FBQ0g7O0FBQ0RzQix3QkFBZ0IsR0FBR0EsZ0JBQWdCLEdBQUdvUCxTQUFTLENBQUNoYSxNQUFoRDtBQUNBK1osMEJBQWtCLEdBQUdBLGtCQUFrQixHQUFHQyxTQUFTLENBQUNoYSxNQUFwRDtBQUVBbUMsYUFBSyxDQUFDd0ksTUFBTixDQUFhO0FBQUNYLGlCQUFPLEVBQUMvTCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjhFO0FBQWhDLFNBQWIsRUFBc0Q7QUFBQ0gsY0FBSSxFQUFDO0FBQUNvUSxpQ0FBcUIsRUFBQ0Ysa0JBQXZCO0FBQTJDRywrQkFBbUIsRUFBQ3RQO0FBQS9EO0FBQU4sU0FBdEQ7QUFDQXFMLG1CQUFXLENBQUN4TixNQUFaLENBQW1CO0FBQ2ZtQywwQkFBZ0IsRUFBRUEsZ0JBREg7QUFFZm1QLDRCQUFrQixFQUFFQSxrQkFGTDtBQUdmcmEsY0FBSSxFQUFFMEIsSUFIUztBQUlmaVQsbUJBQVMsRUFBRUo7QUFKSSxTQUFuQjtBQU1IO0FBQ0o7O0FBQ0QsUUFBSTdTLElBQUksSUFBSSxHQUFaLEVBQWdCO0FBQ1osVUFBSXdKLGdCQUFnQixHQUFHLENBQXZCO0FBQ0EsVUFBSW1QLGtCQUFrQixHQUFHLENBQXpCO0FBQ0EsVUFBSUMsU0FBUyxHQUFHMVgsU0FBUyxDQUFDeUIsSUFBVixDQUFlO0FBQUUsZ0JBQVE7QUFBRThTLGFBQUcsRUFBRSxJQUFJeFYsSUFBSixDQUFTQSxJQUFJLENBQUM0UyxHQUFMLEtBQWEsS0FBRyxFQUFILEdBQVEsSUFBOUI7QUFBUDtBQUFWLE9BQWYsRUFBeUVoUSxLQUF6RSxFQUFoQjs7QUFDQSxVQUFJK1YsU0FBUyxDQUFDaGEsTUFBVixHQUFtQixDQUF2QixFQUF5QjtBQUNyQixhQUFLMkIsQ0FBTCxJQUFVcVksU0FBVixFQUFvQjtBQUNoQnBQLDBCQUFnQixJQUFJb1AsU0FBUyxDQUFDclksQ0FBRCxDQUFULENBQWErQyxRQUFqQztBQUNBcVYsNEJBQWtCLElBQUlDLFNBQVMsQ0FBQ3JZLENBQUQsQ0FBVCxDQUFhMkgsWUFBbkM7QUFDSDs7QUFDRHNCLHdCQUFnQixHQUFHQSxnQkFBZ0IsR0FBR29QLFNBQVMsQ0FBQ2hhLE1BQWhEO0FBQ0ErWiwwQkFBa0IsR0FBR0Esa0JBQWtCLEdBQUdDLFNBQVMsQ0FBQ2hhLE1BQXBEO0FBRUFtQyxhQUFLLENBQUN3SSxNQUFOLENBQWE7QUFBQ1gsaUJBQU8sRUFBQy9MLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEU7QUFBaEMsU0FBYixFQUFzRDtBQUFDSCxjQUFJLEVBQUM7QUFBQ3NRLCtCQUFtQixFQUFDSixrQkFBckI7QUFBeUNLLDZCQUFpQixFQUFDeFA7QUFBM0Q7QUFBTixTQUF0RDtBQUNBcUwsbUJBQVcsQ0FBQ3hOLE1BQVosQ0FBbUI7QUFDZm1DLDBCQUFnQixFQUFFQSxnQkFESDtBQUVmbVAsNEJBQWtCLEVBQUVBLGtCQUZMO0FBR2ZyYSxjQUFJLEVBQUUwQixJQUhTO0FBSWZpVCxtQkFBUyxFQUFFSjtBQUpJLFNBQW5CO0FBTUg7QUFDSjs7QUFFRCxRQUFJN1MsSUFBSSxJQUFJLEdBQVosRUFBZ0I7QUFDWixVQUFJd0osZ0JBQWdCLEdBQUcsQ0FBdkI7QUFDQSxVQUFJbVAsa0JBQWtCLEdBQUcsQ0FBekI7QUFDQSxVQUFJQyxTQUFTLEdBQUcxWCxTQUFTLENBQUN5QixJQUFWLENBQWU7QUFBRSxnQkFBUTtBQUFFOFMsYUFBRyxFQUFFLElBQUl4VixJQUFKLENBQVNBLElBQUksQ0FBQzRTLEdBQUwsS0FBYSxLQUFHLEVBQUgsR0FBTSxFQUFOLEdBQVcsSUFBakM7QUFBUDtBQUFWLE9BQWYsRUFBNEVoUSxLQUE1RSxFQUFoQjs7QUFDQSxVQUFJK1YsU0FBUyxDQUFDaGEsTUFBVixHQUFtQixDQUF2QixFQUF5QjtBQUNyQixhQUFLMkIsQ0FBTCxJQUFVcVksU0FBVixFQUFvQjtBQUNoQnBQLDBCQUFnQixJQUFJb1AsU0FBUyxDQUFDclksQ0FBRCxDQUFULENBQWErQyxRQUFqQztBQUNBcVYsNEJBQWtCLElBQUlDLFNBQVMsQ0FBQ3JZLENBQUQsQ0FBVCxDQUFhMkgsWUFBbkM7QUFDSDs7QUFDRHNCLHdCQUFnQixHQUFHQSxnQkFBZ0IsR0FBR29QLFNBQVMsQ0FBQ2hhLE1BQWhEO0FBQ0ErWiwwQkFBa0IsR0FBR0Esa0JBQWtCLEdBQUdDLFNBQVMsQ0FBQ2hhLE1BQXBEO0FBRUFtQyxhQUFLLENBQUN3SSxNQUFOLENBQWE7QUFBQ1gsaUJBQU8sRUFBQy9MLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEU7QUFBaEMsU0FBYixFQUFzRDtBQUFDSCxjQUFJLEVBQUM7QUFBQ3dRLDhCQUFrQixFQUFDTixrQkFBcEI7QUFBd0NPLDRCQUFnQixFQUFDMVA7QUFBekQ7QUFBTixTQUF0RDtBQUNBcUwsbUJBQVcsQ0FBQ3hOLE1BQVosQ0FBbUI7QUFDZm1DLDBCQUFnQixFQUFFQSxnQkFESDtBQUVmbVAsNEJBQWtCLEVBQUVBLGtCQUZMO0FBR2ZyYSxjQUFJLEVBQUUwQixJQUhTO0FBSWZpVCxtQkFBUyxFQUFFSjtBQUpJLFNBQW5CO0FBTUg7QUFDSixLQXBFdUQsQ0FzRXhEOztBQUNILEdBNVFVO0FBNlFYLGdEQUE4QyxZQUFVO0FBQ3BELFNBQUsvVSxPQUFMO0FBQ0EsUUFBSThELFVBQVUsR0FBRzFFLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0JFLEtBQXBCLEVBQWpCO0FBQ0EsUUFBSWdRLEdBQUcsR0FBRyxJQUFJNVMsSUFBSixFQUFWOztBQUNBLFNBQUtNLENBQUwsSUFBVXFCLFVBQVYsRUFBcUI7QUFDakIsVUFBSTRILGdCQUFnQixHQUFHLENBQXZCO0FBRUEsVUFBSTlHLE1BQU0sR0FBRzVCLFNBQVMsQ0FBQzZCLElBQVYsQ0FBZTtBQUFDQyx1QkFBZSxFQUFDaEIsVUFBVSxDQUFDckIsQ0FBRCxDQUFWLENBQWMxQyxPQUEvQjtBQUF3QyxnQkFBUTtBQUFFNFgsYUFBRyxFQUFFLElBQUl4VixJQUFKLENBQVNBLElBQUksQ0FBQzRTLEdBQUwsS0FBYSxLQUFHLEVBQUgsR0FBTSxFQUFOLEdBQVcsSUFBakM7QUFBUDtBQUFoRCxPQUFmLEVBQWlIO0FBQUN0SCxjQUFNLEVBQUM7QUFBQ3RJLGdCQUFNLEVBQUM7QUFBUjtBQUFSLE9BQWpILEVBQXNJSixLQUF0SSxFQUFiOztBQUVBLFVBQUlILE1BQU0sQ0FBQzlELE1BQVAsR0FBZ0IsQ0FBcEIsRUFBc0I7QUFDbEIsWUFBSXVhLFlBQVksR0FBRyxFQUFuQjs7QUFDQSxhQUFLOVYsQ0FBTCxJQUFVWCxNQUFWLEVBQWlCO0FBQ2J5VyxzQkFBWSxDQUFDdFMsSUFBYixDQUFrQm5FLE1BQU0sQ0FBQ1csQ0FBRCxDQUFOLENBQVVKLE1BQTVCO0FBQ0g7O0FBRUQsWUFBSTJWLFNBQVMsR0FBRzFYLFNBQVMsQ0FBQ3lCLElBQVYsQ0FBZTtBQUFDTSxnQkFBTSxFQUFFO0FBQUNFLGVBQUcsRUFBQ2dXO0FBQUw7QUFBVCxTQUFmLEVBQTZDO0FBQUM1TixnQkFBTSxFQUFDO0FBQUN0SSxrQkFBTSxFQUFDLENBQVI7QUFBVUssb0JBQVEsRUFBQztBQUFuQjtBQUFSLFNBQTdDLEVBQTZFVCxLQUE3RSxFQUFoQjs7QUFHQSxhQUFLdVcsQ0FBTCxJQUFVUixTQUFWLEVBQW9CO0FBQ2hCcFAsMEJBQWdCLElBQUlvUCxTQUFTLENBQUNRLENBQUQsQ0FBVCxDQUFhOVYsUUFBakM7QUFDSDs7QUFFRGtHLHdCQUFnQixHQUFHQSxnQkFBZ0IsR0FBR29QLFNBQVMsQ0FBQ2hhLE1BQWhEO0FBQ0g7O0FBRURrVywwQkFBb0IsQ0FBQ3pOLE1BQXJCLENBQTRCO0FBQ3hCekUsdUJBQWUsRUFBRWhCLFVBQVUsQ0FBQ3JCLENBQUQsQ0FBVixDQUFjMUMsT0FEUDtBQUV4QjJMLHdCQUFnQixFQUFFQSxnQkFGTTtBQUd4QmxMLFlBQUksRUFBRSxnQ0FIa0I7QUFJeEIyVSxpQkFBUyxFQUFFSjtBQUphLE9BQTVCO0FBTUg7O0FBRUQsV0FBTyxJQUFQO0FBQ0g7QUEvU1UsQ0FBZixFOzs7Ozs7Ozs7OztBQzdEQSxJQUFJaFcsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJaUUsZ0JBQUosRUFBcUJDLFNBQXJCLEVBQStCK1QsWUFBL0IsRUFBNENELGlCQUE1QyxFQUE4RDdULGVBQTlEO0FBQThFckUsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDa0Usa0JBQWdCLENBQUNqRSxDQUFELEVBQUc7QUFBQ2lFLG9CQUFnQixHQUFDakUsQ0FBakI7QUFBbUIsR0FBeEM7O0FBQXlDa0UsV0FBUyxDQUFDbEUsQ0FBRCxFQUFHO0FBQUNrRSxhQUFTLEdBQUNsRSxDQUFWO0FBQVksR0FBbEU7O0FBQW1FaVksY0FBWSxDQUFDalksQ0FBRCxFQUFHO0FBQUNpWSxnQkFBWSxHQUFDalksQ0FBYjtBQUFlLEdBQWxHOztBQUFtR2dZLG1CQUFpQixDQUFDaFksQ0FBRCxFQUFHO0FBQUNnWSxxQkFBaUIsR0FBQ2hZLENBQWxCO0FBQW9CLEdBQTVJOztBQUE2SW1FLGlCQUFlLENBQUNuRSxDQUFELEVBQUc7QUFBQ21FLG1CQUFlLEdBQUNuRSxDQUFoQjtBQUFrQjs7QUFBbEwsQ0FBNUIsRUFBZ04sQ0FBaE47QUFBbU4sSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBN0MsRUFBMkUsQ0FBM0U7QUFJaFhILE1BQU0sQ0FBQzRWLE9BQVAsQ0FBZSx1QkFBZixFQUF3QyxZQUFZO0FBQ2hELFNBQU94UixnQkFBZ0IsQ0FBQzBCLElBQWpCLEVBQVA7QUFDSCxDQUZEO0FBSUE5RixNQUFNLENBQUM0VixPQUFQLENBQWUsMEJBQWYsRUFBMkMsVUFBUzVVLE9BQVQsRUFBa0J3YixHQUFsQixFQUFzQjtBQUM3RCxTQUFPcFksZ0JBQWdCLENBQUMwQixJQUFqQixDQUFzQjtBQUFDOUUsV0FBTyxFQUFDQTtBQUFULEdBQXRCLEVBQXdDO0FBQUNnSCxTQUFLLEVBQUN3VSxHQUFQO0FBQVl6VSxRQUFJLEVBQUM7QUFBQzNCLFlBQU0sRUFBQyxDQUFDO0FBQVQ7QUFBakIsR0FBeEMsQ0FBUDtBQUNILENBRkQ7QUFJQXBHLE1BQU0sQ0FBQzRWLE9BQVAsQ0FBZSxtQkFBZixFQUFvQyxZQUFVO0FBQzFDLFNBQU92UixTQUFTLENBQUN5QixJQUFWLENBQWUsRUFBZixFQUFrQjtBQUFDaUMsUUFBSSxFQUFDO0FBQUMzQixZQUFNLEVBQUMsQ0FBQztBQUFULEtBQU47QUFBa0I0QixTQUFLLEVBQUM7QUFBeEIsR0FBbEIsQ0FBUDtBQUNILENBRkQ7QUFJQWhJLE1BQU0sQ0FBQzRWLE9BQVAsQ0FBZSx1QkFBZixFQUF3QyxZQUFVO0FBQzlDLFNBQU90UixlQUFlLENBQUN3QixJQUFoQixDQUFxQixFQUFyQixFQUF3QjtBQUFDaUMsUUFBSSxFQUFDO0FBQUMzQixZQUFNLEVBQUMsQ0FBQztBQUFULEtBQU47QUFBbUI0QixTQUFLLEVBQUM7QUFBekIsR0FBeEIsQ0FBUDtBQUNILENBRkQ7QUFJQXNJLGdCQUFnQixDQUFDLHdCQUFELEVBQTJCLFVBQVN0UCxPQUFULEVBQWtCUyxJQUFsQixFQUF1QjtBQUM5RCxNQUFJZ2IsVUFBVSxHQUFHLEVBQWpCOztBQUNBLE1BQUloYixJQUFJLElBQUksT0FBWixFQUFvQjtBQUNoQmdiLGNBQVUsR0FBRztBQUNUdEQsV0FBSyxFQUFFblk7QUFERSxLQUFiO0FBR0gsR0FKRCxNQUtJO0FBQ0F5YixjQUFVLEdBQUc7QUFDVDdMLGNBQVEsRUFBRTVQO0FBREQsS0FBYjtBQUdIOztBQUNELFNBQU87QUFDSDhFLFFBQUksR0FBRTtBQUNGLGFBQU9xUyxpQkFBaUIsQ0FBQ3JTLElBQWxCLENBQXVCMlcsVUFBdkIsQ0FBUDtBQUNILEtBSEU7O0FBSUhsTSxZQUFRLEVBQUUsQ0FDTjtBQUNJekssVUFBSSxDQUFDK1UsS0FBRCxFQUFPO0FBQ1AsZUFBT3hhLFVBQVUsQ0FBQ3lGLElBQVgsQ0FDSCxFQURHLEVBRUg7QUFBQzRJLGdCQUFNLEVBQUM7QUFBQzFOLG1CQUFPLEVBQUMsQ0FBVDtBQUFZc00sdUJBQVcsRUFBQyxDQUF4QjtBQUEyQkMsdUJBQVcsRUFBQztBQUF2QztBQUFSLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE07QUFKUCxHQUFQO0FBZUgsQ0EzQmUsQ0FBaEI7QUE2QkErQyxnQkFBZ0IsQ0FBQyx5QkFBRCxFQUE0QixVQUFTdFAsT0FBVCxFQUFrQlMsSUFBbEIsRUFBdUI7QUFDL0QsU0FBTztBQUNIcUUsUUFBSSxHQUFFO0FBQ0YsYUFBT3NTLFlBQVksQ0FBQ3RTLElBQWIsQ0FDSDtBQUFDLFNBQUNyRSxJQUFELEdBQVFUO0FBQVQsT0FERyxFQUVIO0FBQUMrRyxZQUFJLEVBQUU7QUFBQzRTLG1CQUFTLEVBQUUsQ0FBQztBQUFiO0FBQVAsT0FGRyxDQUFQO0FBSUgsS0FORTs7QUFPSHBLLFlBQVEsRUFBRSxDQUNOO0FBQ0l6SyxVQUFJLEdBQUU7QUFDRixlQUFPekYsVUFBVSxDQUFDeUYsSUFBWCxDQUNILEVBREcsRUFFSDtBQUFDNEksZ0JBQU0sRUFBQztBQUFDMU4sbUJBQU8sRUFBQyxDQUFUO0FBQVlzTSx1QkFBVyxFQUFDLENBQXhCO0FBQTJCL0ssNEJBQWdCLEVBQUM7QUFBNUM7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNO0FBUFAsR0FBUDtBQWtCSCxDQW5CZSxDQUFoQixDOzs7Ozs7Ozs7OztBQ2pEQXRDLE1BQU0sQ0FBQ3VRLE1BQVAsQ0FBYztBQUFDcE0sa0JBQWdCLEVBQUMsTUFBSUEsZ0JBQXRCO0FBQXVDQyxXQUFTLEVBQUMsTUFBSUEsU0FBckQ7QUFBK0Q4VCxtQkFBaUIsRUFBQyxNQUFJQSxpQkFBckY7QUFBdUdDLGNBQVksRUFBQyxNQUFJQSxZQUF4SDtBQUFxSTlULGlCQUFlLEVBQUMsTUFBSUEsZUFBeko7QUFBeUswVCxhQUFXLEVBQUMsTUFBSUEsV0FBekw7QUFBcU1DLHNCQUFvQixFQUFDLE1BQUlBO0FBQTlOLENBQWQ7QUFBbVEsSUFBSXhILEtBQUo7QUFBVXhRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3VRLE9BQUssQ0FBQ3RRLENBQUQsRUFBRztBQUFDc1EsU0FBSyxHQUFDdFEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUF2QyxFQUFxRSxDQUFyRTtBQUd2VSxNQUFNaUUsZ0JBQWdCLEdBQUcsSUFBSXFNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixtQkFBckIsQ0FBekI7QUFDQSxNQUFNck0sU0FBUyxHQUFHLElBQUlvTSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsV0FBckIsQ0FBbEI7QUFDQSxNQUFNeUgsaUJBQWlCLEdBQUcsSUFBSTFILEtBQUssQ0FBQ0MsVUFBVixDQUFxQixxQkFBckIsQ0FBMUI7QUFDQSxNQUFNMEgsWUFBWSxHQUFHLElBQUszSCxLQUFLLENBQUNDLFVBQVgsQ0FBc0IsZUFBdEIsQ0FBckI7QUFDQSxNQUFNcE0sZUFBZSxHQUFHLElBQUltTSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsNEJBQXJCLENBQXhCO0FBQ0EsTUFBTXNILFdBQVcsR0FBRyxJQUFJdkgsS0FBSyxDQUFDQyxVQUFWLENBQXFCLGNBQXJCLENBQXBCO0FBQ0EsTUFBTXVILG9CQUFvQixHQUFHLElBQUl4SCxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsd0JBQXJCLENBQTdCO0FBRVB5SCxpQkFBaUIsQ0FBQ3hILE9BQWxCLENBQTBCO0FBQ3RCK0wsaUJBQWUsR0FBRTtBQUNiLFFBQUl0YSxTQUFTLEdBQUcvQixVQUFVLENBQUNnQyxPQUFYLENBQW1CO0FBQUNyQixhQUFPLEVBQUMsS0FBSzRQO0FBQWQsS0FBbkIsQ0FBaEI7QUFDQSxXQUFReE8sU0FBUyxDQUFDa0wsV0FBWCxHQUF3QmxMLFNBQVMsQ0FBQ2tMLFdBQVYsQ0FBc0JxUCxPQUE5QyxHQUFzRCxLQUFLL0wsUUFBbEU7QUFDSCxHQUpxQjs7QUFLdEJnTSxjQUFZLEdBQUU7QUFDVixRQUFJeGEsU0FBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDckIsYUFBTyxFQUFDLEtBQUttWTtBQUFkLEtBQW5CLENBQWhCO0FBQ0EsV0FBUS9XLFNBQVMsQ0FBQ2tMLFdBQVgsR0FBd0JsTCxTQUFTLENBQUNrTCxXQUFWLENBQXNCcVAsT0FBOUMsR0FBc0QsS0FBS3hELEtBQWxFO0FBQ0g7O0FBUnFCLENBQTFCLEU7Ozs7Ozs7Ozs7O0FDWEEsSUFBSW5aLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSStYLE1BQUo7QUFBV2pZLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ2dZLFFBQU0sQ0FBQy9YLENBQUQsRUFBRztBQUFDK1gsVUFBTSxHQUFDL1gsQ0FBUDtBQUFTOztBQUFwQixDQUEzQixFQUFpRCxDQUFqRDtBQUFvRCxJQUFJNFcsS0FBSjtBQUFVOVcsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDNlcsT0FBSyxDQUFDNVcsQ0FBRCxFQUFHO0FBQUM0VyxTQUFLLEdBQUM1VyxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBSXpJSCxNQUFNLENBQUM0VixPQUFQLENBQWUsZUFBZixFQUFnQyxZQUFZO0FBQ3hDLFNBQU9zQyxNQUFNLENBQUNwUyxJQUFQLENBQVk7QUFBQ2lHLFdBQU8sRUFBQy9MLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEU7QUFBaEMsR0FBWixDQUFQO0FBQ0gsQ0FGRCxFOzs7Ozs7Ozs7OztBQ0pBOUwsTUFBTSxDQUFDdVEsTUFBUCxDQUFjO0FBQUMwSCxRQUFNLEVBQUMsTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUl6SCxLQUFKO0FBQVV4USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN1USxPQUFLLENBQUN0USxDQUFELEVBQUc7QUFBQ3NRLFNBQUssR0FBQ3RRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFdEMsTUFBTStYLE1BQU0sR0FBRyxJQUFJekgsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFFBQXJCLENBQWYsQzs7Ozs7Ozs7Ozs7QUNGUCxJQUFJMVEsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUlxRSxZQUFKO0FBQWlCdkUsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ3NFLGNBQVksQ0FBQ3JFLENBQUQsRUFBRztBQUFDcUUsZ0JBQVksR0FBQ3JFLENBQWI7QUFBZTs7QUFBaEMsQ0FBakQsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBN0MsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSW9FLGtCQUFKO0FBQXVCdEUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0JBQVosRUFBNEM7QUFBQ3FFLG9CQUFrQixDQUFDcEUsQ0FBRCxFQUFHO0FBQUNvRSxzQkFBa0IsR0FBQ3BFLENBQW5CO0FBQXFCOztBQUE1QyxDQUE1QyxFQUEwRixDQUExRjtBQU1uVixNQUFNMGMsYUFBYSxHQUFHLEVBQXRCO0FBRUE3YyxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLHdCQUFzQixVQUFTc0ksSUFBVCxFQUFlNkMsU0FBZixFQUF5QjtBQUMzQyxTQUFLakwsT0FBTDtBQUNBb0ksUUFBSSxHQUFHQSxJQUFJLENBQUN5VCxXQUFMLEVBQVA7QUFDQSxRQUFJdmMsR0FBRyxHQUFHRyxHQUFHLEdBQUUsT0FBTCxHQUFhMkksSUFBdkI7QUFDQSxRQUFJbEksUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsUUFBSXdjLEVBQUUsR0FBRzNiLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQVQ7QUFFQVQsV0FBTyxDQUFDQyxHQUFSLENBQVl1SSxJQUFaO0FBRUEwVCxNQUFFLENBQUMzVyxNQUFILEdBQVl5RSxRQUFRLENBQUNrUyxFQUFFLENBQUMzVyxNQUFKLENBQXBCLENBVDJDLENBVzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBR0EsUUFBSTRXLElBQUksR0FBR3hZLFlBQVksQ0FBQ2dHLE1BQWIsQ0FBb0J1UyxFQUFwQixDQUFYOztBQUNBLFFBQUlDLElBQUosRUFBUztBQUNMLGFBQU9BLElBQVA7QUFDSCxLQUZELE1BR0ssT0FBTyxLQUFQO0FBQ1IsR0E5RFU7QUErRFgsaUNBQStCLFVBQVNoYyxPQUFULEVBQWtCb0YsTUFBbEIsRUFBeUI7QUFDcEQ7QUFDQSxXQUFPNUIsWUFBWSxDQUFDc0IsSUFBYixDQUFrQjtBQUNyQnhELFNBQUcsRUFBRSxDQUFDO0FBQUNxVyxZQUFJLEVBQUUsQ0FDVDtBQUFDLHlCQUFlO0FBQWhCLFNBRFMsRUFFVDtBQUFDLG1DQUF5QjtBQUExQixTQUZTLEVBR1Q7QUFBQyxxQ0FBMkIzWDtBQUE1QixTQUhTO0FBQVAsT0FBRCxFQUlEO0FBQUMyWCxZQUFJLEVBQUMsQ0FDTjtBQUFDLG1DQUF5QjtBQUExQixTQURNLEVBRU47QUFBQyxxQ0FBMkI7QUFBNUIsU0FGTSxFQUdOO0FBQUMsbUNBQXlCO0FBQTFCLFNBSE0sRUFJTjtBQUFDLHFDQUEyQjNYO0FBQTVCLFNBSk07QUFBTixPQUpDLEVBU0Q7QUFBQzJYLFlBQUksRUFBQyxDQUNOO0FBQUMseUJBQWU7QUFBaEIsU0FETSxFQUVOO0FBQUMsbUNBQXlCO0FBQTFCLFNBRk0sRUFHTjtBQUFDLHFDQUEyQjNYO0FBQTVCLFNBSE07QUFBTixPQVRDLEVBYUQ7QUFBQzJYLFlBQUksRUFBQyxDQUNOO0FBQUMseUJBQWU7QUFBaEIsU0FETSxFQUVOO0FBQUMsbUNBQXlCO0FBQTFCLFNBRk0sRUFHTjtBQUFDLHFDQUEyQjNYO0FBQTVCLFNBSE07QUFBTixPQWJDLEVBaUJEO0FBQUMyWCxZQUFJLEVBQUMsQ0FDTjtBQUFDLHlCQUFlO0FBQWhCLFNBRE0sRUFFTjtBQUFDLG1DQUF5QjtBQUExQixTQUZNLEVBR047QUFBQyxxQ0FBMkIzWDtBQUE1QixTQUhNO0FBQU4sT0FqQkMsQ0FEZ0I7QUF1QnJCLGNBQVE7QUFBQ2tLLGVBQU8sRUFBRTtBQUFWLE9BdkJhO0FBd0JyQjlFLFlBQU0sRUFBQztBQUFDNlcsV0FBRyxFQUFDN1c7QUFBTDtBQXhCYyxLQUFsQixFQXlCUDtBQUFDMkIsVUFBSSxFQUFDO0FBQUMzQixjQUFNLEVBQUMsQ0FBQztBQUFULE9BQU47QUFDSTRCLFdBQUssRUFBRTtBQURYLEtBekJPLEVBMkJMaEMsS0EzQkssRUFBUDtBQTRCSCxHQTdGVTtBQThGWCwyQkFBeUIsVUFBU2hGLE9BQVQsRUFBOEI7QUFBQSxRQUFaME4sTUFBWSx1RUFBTCxJQUFLO0FBQ25EO0FBQ0EsUUFBSXRNLFNBQUo7QUFDQSxRQUFJLENBQUNzTSxNQUFMLEVBQ0lBLE1BQU0sR0FBRztBQUFDMU4sYUFBTyxFQUFDLENBQVQ7QUFBWXNNLGlCQUFXLEVBQUMsQ0FBeEI7QUFBMkIvSyxzQkFBZ0IsRUFBQyxDQUE1QztBQUErQ0MsdUJBQWlCLEVBQUM7QUFBakUsS0FBVDs7QUFDSixRQUFJeEIsT0FBTyxDQUFDa2MsUUFBUixDQUFpQmxkLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCa1csbUJBQXhDLENBQUosRUFBaUU7QUFDN0Q7QUFDQS9hLGVBQVMsR0FBRy9CLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQ0Usd0JBQWdCLEVBQUN2QjtBQUFsQixPQUFuQixFQUErQztBQUFDME47QUFBRCxPQUEvQyxDQUFaO0FBQ0gsS0FIRCxNQUlLLElBQUkxTixPQUFPLENBQUNrYyxRQUFSLENBQWlCbGQsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJtVyxtQkFBeEMsQ0FBSixFQUFpRTtBQUNsRTtBQUNBaGIsZUFBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDRyx5QkFBaUIsRUFBQ3hCO0FBQW5CLE9BQW5CLEVBQWdEO0FBQUMwTjtBQUFELE9BQWhELENBQVo7QUFDSCxLQUhJLE1BSUEsSUFBSTFOLE9BQU8sQ0FBQ2UsTUFBUixLQUFtQjhhLGFBQXZCLEVBQXNDO0FBQ3ZDemEsZUFBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDckIsZUFBTyxFQUFDQTtBQUFULE9BQW5CLEVBQXNDO0FBQUMwTjtBQUFELE9BQXRDLENBQVo7QUFDSDs7QUFDRCxRQUFJdE0sU0FBSixFQUFjO0FBQ1YsYUFBT0EsU0FBUDtBQUNIOztBQUNELFdBQU8sS0FBUDtBQUVIO0FBbkhVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNSQSxJQUFJcEMsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJcUUsWUFBSjtBQUFpQnZFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9CQUFaLEVBQWlDO0FBQUNzRSxjQUFZLENBQUNyRSxDQUFELEVBQUc7QUFBQ3FFLGdCQUFZLEdBQUNyRSxDQUFiO0FBQWU7O0FBQWhDLENBQWpDLEVBQW1FLENBQW5FO0FBQXNFLElBQUk4RCxTQUFKO0FBQWNoRSxNQUFNLENBQUNDLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDK0QsV0FBUyxDQUFDOUQsQ0FBRCxFQUFHO0FBQUM4RCxhQUFTLEdBQUM5RCxDQUFWO0FBQVk7O0FBQTFCLENBQXJDLEVBQWlFLENBQWpFO0FBS3JLbVEsZ0JBQWdCLENBQUMsbUJBQUQsRUFBc0IsWUFBb0I7QUFBQSxNQUFYdEksS0FBVyx1RUFBSCxFQUFHO0FBQ3RELFNBQU87QUFDSGxDLFFBQUksR0FBRTtBQUNGLGFBQU90QixZQUFZLENBQUNzQixJQUFiLENBQWtCLEVBQWxCLEVBQXFCO0FBQUNpQyxZQUFJLEVBQUM7QUFBQzNCLGdCQUFNLEVBQUMsQ0FBQztBQUFULFNBQU47QUFBbUI0QixhQUFLLEVBQUNBO0FBQXpCLE9BQXJCLENBQVA7QUFDSCxLQUhFOztBQUlIdUksWUFBUSxFQUFFLENBQ047QUFDSXpLLFVBQUksQ0FBQ2lYLEVBQUQsRUFBSTtBQUNKLGVBQU85WSxTQUFTLENBQUM2QixJQUFWLENBQ0g7QUFBQ00sZ0JBQU0sRUFBQzJXLEVBQUUsQ0FBQzNXO0FBQVgsU0FERyxFQUVIO0FBQUNzSSxnQkFBTSxFQUFDO0FBQUN2TCxnQkFBSSxFQUFDLENBQU47QUFBU2lELGtCQUFNLEVBQUM7QUFBaEI7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNO0FBSlAsR0FBUDtBQWVILENBaEJlLENBQWhCO0FBa0JBa0ssZ0JBQWdCLENBQUMsd0JBQUQsRUFBMkIsVUFBUytNLGdCQUFULEVBQTJCQyxnQkFBM0IsRUFBdUQ7QUFBQSxNQUFWdFYsS0FBVSx1RUFBSixHQUFJO0FBQzlGLE1BQUl1VixLQUFLLEdBQUcsRUFBWjs7QUFDQSxNQUFJRixnQkFBZ0IsSUFBSUMsZ0JBQXhCLEVBQXlDO0FBQ3JDQyxTQUFLLEdBQUc7QUFBQ2piLFNBQUcsRUFBQyxDQUFDO0FBQUMsbUNBQTBCK2E7QUFBM0IsT0FBRCxFQUErQztBQUFDLG1DQUEwQkM7QUFBM0IsT0FBL0M7QUFBTCxLQUFSO0FBQ0g7O0FBRUQsTUFBSSxDQUFDRCxnQkFBRCxJQUFxQkMsZ0JBQXpCLEVBQTBDO0FBQ3RDQyxTQUFLLEdBQUc7QUFBQyxpQ0FBMEJEO0FBQTNCLEtBQVI7QUFDSDs7QUFFRCxTQUFPO0FBQ0h4WCxRQUFJLEdBQUU7QUFDRixhQUFPdEIsWUFBWSxDQUFDc0IsSUFBYixDQUFrQnlYLEtBQWxCLEVBQXlCO0FBQUN4VixZQUFJLEVBQUM7QUFBQzNCLGdCQUFNLEVBQUMsQ0FBQztBQUFULFNBQU47QUFBbUI0QixhQUFLLEVBQUNBO0FBQXpCLE9BQXpCLENBQVA7QUFDSCxLQUhFOztBQUlIdUksWUFBUSxFQUFDLENBQ0w7QUFDSXpLLFVBQUksQ0FBQ2lYLEVBQUQsRUFBSTtBQUNKLGVBQU85WSxTQUFTLENBQUM2QixJQUFWLENBQ0g7QUFBQ00sZ0JBQU0sRUFBQzJXLEVBQUUsQ0FBQzNXO0FBQVgsU0FERyxFQUVIO0FBQUNzSSxnQkFBTSxFQUFDO0FBQUN2TCxnQkFBSSxFQUFDLENBQU47QUFBU2lELGtCQUFNLEVBQUM7QUFBaEI7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURLO0FBSk4sR0FBUDtBQWVILENBekJlLENBQWhCO0FBMkJBa0ssZ0JBQWdCLENBQUMsc0JBQUQsRUFBeUIsVUFBU2pILElBQVQsRUFBYztBQUNuRCxTQUFPO0FBQ0h2RCxRQUFJLEdBQUU7QUFDRixhQUFPdEIsWUFBWSxDQUFDc0IsSUFBYixDQUFrQjtBQUFDNFIsY0FBTSxFQUFDck87QUFBUixPQUFsQixDQUFQO0FBQ0gsS0FIRTs7QUFJSGtILFlBQVEsRUFBRSxDQUNOO0FBQ0l6SyxVQUFJLENBQUNpWCxFQUFELEVBQUk7QUFDSixlQUFPOVksU0FBUyxDQUFDNkIsSUFBVixDQUNIO0FBQUNNLGdCQUFNLEVBQUMyVyxFQUFFLENBQUMzVztBQUFYLFNBREcsRUFFSDtBQUFDc0ksZ0JBQU0sRUFBQztBQUFDdkwsZ0JBQUksRUFBQyxDQUFOO0FBQVNpRCxrQkFBTSxFQUFDO0FBQWhCO0FBQVIsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FETTtBQUpQLEdBQVA7QUFlSCxDQWhCZSxDQUFoQjtBQWtCQWtLLGdCQUFnQixDQUFDLHFCQUFELEVBQXdCLFVBQVNsSyxNQUFULEVBQWdCO0FBQ3BELFNBQU87QUFDSE4sUUFBSSxHQUFFO0FBQ0YsYUFBT3RCLFlBQVksQ0FBQ3NCLElBQWIsQ0FBa0I7QUFBQ00sY0FBTSxFQUFDQTtBQUFSLE9BQWxCLENBQVA7QUFDSCxLQUhFOztBQUlIbUssWUFBUSxFQUFFLENBQ047QUFDSXpLLFVBQUksQ0FBQ2lYLEVBQUQsRUFBSTtBQUNKLGVBQU85WSxTQUFTLENBQUM2QixJQUFWLENBQ0g7QUFBQ00sZ0JBQU0sRUFBQzJXLEVBQUUsQ0FBQzNXO0FBQVgsU0FERyxFQUVIO0FBQUNzSSxnQkFBTSxFQUFDO0FBQUN2TCxnQkFBSSxFQUFDLENBQU47QUFBU2lELGtCQUFNLEVBQUM7QUFBaEI7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNO0FBSlAsR0FBUDtBQWVILENBaEJlLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDcEVBbkcsTUFBTSxDQUFDdVEsTUFBUCxDQUFjO0FBQUNoTSxjQUFZLEVBQUMsTUFBSUE7QUFBbEIsQ0FBZDtBQUErQyxJQUFJaU0sS0FBSjtBQUFVeFEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDdVEsT0FBSyxDQUFDdFEsQ0FBRCxFQUFHO0FBQUNzUSxTQUFLLEdBQUN0USxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUk4RCxTQUFKO0FBQWNoRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDK0QsV0FBUyxDQUFDOUQsQ0FBRCxFQUFHO0FBQUM4RCxhQUFTLEdBQUM5RCxDQUFWO0FBQVk7O0FBQTFCLENBQWxDLEVBQThELENBQTlEO0FBQWlFLElBQUlxZCxNQUFKO0FBQVd2ZCxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQkFBWixFQUE0QztBQUFDc2QsUUFBTSxDQUFDcmQsQ0FBRCxFQUFHO0FBQUNxZCxVQUFNLEdBQUNyZCxDQUFQO0FBQVM7O0FBQXBCLENBQTVDLEVBQWtFLENBQWxFO0FBSTlMLE1BQU1xRSxZQUFZLEdBQUcsSUFBSWlNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixjQUFyQixDQUFyQjtBQUVQbE0sWUFBWSxDQUFDbU0sT0FBYixDQUFxQjtBQUNqQnhLLE9BQUssR0FBRTtBQUNILFdBQU9sQyxTQUFTLENBQUM1QixPQUFWLENBQWtCO0FBQUMrRCxZQUFNLEVBQUMsS0FBS0E7QUFBYixLQUFsQixDQUFQO0FBQ0g7O0FBSGdCLENBQXJCLEU7Ozs7Ozs7Ozs7O0FDTkEsSUFBSXBHLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXFFLFlBQUo7QUFBaUJ2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDc0UsY0FBWSxDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxnQkFBWSxHQUFDckUsQ0FBYjtBQUFlOztBQUFoQyxDQUFqRCxFQUFtRixDQUFuRjtBQUFzRixJQUFJOEQsU0FBSjtBQUFjaEUsTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQytELFdBQVMsQ0FBQzlELENBQUQsRUFBRztBQUFDOEQsYUFBUyxHQUFDOUQsQ0FBVjtBQUFZOztBQUExQixDQUFyQyxFQUFpRSxDQUFqRTtBQUFvRSxJQUFJK1YsV0FBSjtBQUFnQmpXLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtDQUFaLEVBQStDO0FBQUNnVyxhQUFXLENBQUMvVixDQUFELEVBQUc7QUFBQytWLGVBQVcsR0FBQy9WLENBQVo7QUFBYzs7QUFBOUIsQ0FBL0MsRUFBK0UsQ0FBL0U7QUFLelFILE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsd0NBQXNDLFVBQVNDLE9BQVQsRUFBaUI7QUFDbkQ7QUFDQSxRQUFJK2IsRUFBRSxHQUFHdlksWUFBWSxDQUFDbkMsT0FBYixDQUFxQjtBQUFDc1csVUFBSSxFQUFDLENBQ2hDO0FBQUMsZ0RBQXVDM1g7QUFBeEMsT0FEZ0MsRUFFaEM7QUFBQyw2QkFBb0I7QUFBckIsT0FGZ0MsRUFHaEM7QUFBQ3NXLFlBQUksRUFBQztBQUFDcE0saUJBQU8sRUFBQztBQUFUO0FBQU4sT0FIZ0M7QUFBTixLQUFyQixDQUFUOztBQU1BLFFBQUk2UixFQUFKLEVBQU87QUFDSCxVQUFJNVcsS0FBSyxHQUFHbEMsU0FBUyxDQUFDNUIsT0FBVixDQUFrQjtBQUFDK0QsY0FBTSxFQUFDMlcsRUFBRSxDQUFDM1c7QUFBWCxPQUFsQixDQUFaOztBQUNBLFVBQUlELEtBQUosRUFBVTtBQUNOLGVBQU9BLEtBQUssQ0FBQ2hELElBQWI7QUFDSDtBQUNKLEtBTEQsTUFNSTtBQUNBO0FBQ0EsYUFBTyxLQUFQO0FBQ0g7QUFDSixHQW5CVTs7QUFvQlg7QUFDQSxpQ0FBK0JuQyxPQUEvQixFQUF1QztBQUNuQyxRQUFJVCxHQUFHLEdBQUdHLEdBQUcsR0FBRyxzQkFBTixHQUE2Qk0sT0FBN0IsR0FBcUMsY0FBL0M7O0FBRUEsUUFBRztBQUNDLFVBQUlnQixXQUFXLEdBQUc1QixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFsQjs7QUFDQSxVQUFJeUIsV0FBVyxDQUFDckIsVUFBWixJQUEwQixHQUE5QixFQUFrQztBQUM5QnFCLG1CQUFXLEdBQUdaLElBQUksQ0FBQ0MsS0FBTCxDQUFXVyxXQUFXLENBQUNWLE9BQXZCLEVBQWdDQyxNQUE5QztBQUNBUyxtQkFBVyxDQUFDZ0IsT0FBWixDQUFvQixDQUFDUyxVQUFELEVBQWFDLENBQWIsS0FBbUI7QUFDbkMsY0FBSTFCLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxJQUFrQjFCLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxDQUFlZCxNQUFyQyxFQUNJWixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBZixHQUF3QkMsVUFBVSxDQUFDYixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBaEIsQ0FBbEM7QUFDUCxTQUhEO0FBS0EsZUFBT1osV0FBUDtBQUNIOztBQUFBO0FBQ0osS0FYRCxDQVlBLE9BQU9wQixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKOztBQXZDVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTEEsSUFBSVosTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUEvQixFQUE2RCxDQUE3RDtBQUFnRSxJQUFJaUUsZ0JBQUo7QUFBcUJuRSxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDa0Usa0JBQWdCLENBQUNqRSxDQUFELEVBQUc7QUFBQ2lFLG9CQUFnQixHQUFDakUsQ0FBakI7QUFBbUI7O0FBQXhDLENBQXZDLEVBQWlGLENBQWpGO0FBQW9GLElBQUlvRSxrQkFBSjtBQUF1QnRFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtCQUFaLEVBQTRDO0FBQUNxRSxvQkFBa0IsQ0FBQ3BFLENBQUQsRUFBRztBQUFDb0Usc0JBQWtCLEdBQUNwRSxDQUFuQjtBQUFxQjs7QUFBNUMsQ0FBNUMsRUFBMEYsQ0FBMUY7QUFLL1FILE1BQU0sQ0FBQzRWLE9BQVAsQ0FBZSxnQkFBZixFQUFpQyxZQUFtRTtBQUFBLE1BQXpEN04sSUFBeUQsdUVBQWxELHFCQUFrRDtBQUFBLE1BQTNCMFYsU0FBMkIsdUVBQWYsQ0FBQyxDQUFjO0FBQUEsTUFBWC9PLE1BQVcsdUVBQUosRUFBSTtBQUNoRyxTQUFPck8sVUFBVSxDQUFDeUYsSUFBWCxDQUFnQixFQUFoQixFQUFvQjtBQUFDaUMsUUFBSSxFQUFFO0FBQUMsT0FBQ0EsSUFBRCxHQUFRMFY7QUFBVCxLQUFQO0FBQTRCL08sVUFBTSxFQUFFQTtBQUFwQyxHQUFwQixDQUFQO0FBQ0gsQ0FGRDtBQUlBNEIsZ0JBQWdCLENBQUMsc0JBQUQsRUFBd0I7QUFDcEN4SyxNQUFJLEdBQUc7QUFDSCxXQUFPekYsVUFBVSxDQUFDeUYsSUFBWCxDQUFnQixFQUFoQixDQUFQO0FBQ0gsR0FIbUM7O0FBSXBDeUssVUFBUSxFQUFFLENBQ047QUFDSXpLLFFBQUksQ0FBQzRYLEdBQUQsRUFBTTtBQUNOLGFBQU90WixnQkFBZ0IsQ0FBQzBCLElBQWpCLENBQ0g7QUFBRTlFLGVBQU8sRUFBRTBjLEdBQUcsQ0FBQzFjO0FBQWYsT0FERyxFQUVIO0FBQUUrRyxZQUFJLEVBQUU7QUFBQzNCLGdCQUFNLEVBQUU7QUFBVCxTQUFSO0FBQXFCNEIsYUFBSyxFQUFFO0FBQTVCLE9BRkcsQ0FBUDtBQUlIOztBQU5MLEdBRE07QUFKMEIsQ0FBeEIsQ0FBaEI7QUFnQkFoSSxNQUFNLENBQUM0VixPQUFQLENBQWUseUJBQWYsRUFBMEMsWUFBVTtBQUNoRCxTQUFPdlYsVUFBVSxDQUFDeUYsSUFBWCxDQUFnQjtBQUNuQjZCLFVBQU0sRUFBRSxDQURXO0FBRW5CNkYsVUFBTSxFQUFDO0FBRlksR0FBaEIsRUFHTDtBQUNFekYsUUFBSSxFQUFDO0FBQ0RzRCxrQkFBWSxFQUFDLENBQUM7QUFEYixLQURQO0FBSUVxRCxVQUFNLEVBQUM7QUFDSDFOLGFBQU8sRUFBRSxDQUROO0FBRUhzTSxpQkFBVyxFQUFDLENBRlQ7QUFHSGpDLGtCQUFZLEVBQUMsQ0FIVjtBQUlIa0MsaUJBQVcsRUFBQztBQUpUO0FBSlQsR0FISyxDQUFQO0FBZUgsQ0FoQkQ7QUFrQkErQyxnQkFBZ0IsQ0FBQyxtQkFBRCxFQUFzQixVQUFTdFAsT0FBVCxFQUFpQjtBQUNuRCxNQUFJOFgsT0FBTyxHQUFHO0FBQUM5WCxXQUFPLEVBQUNBO0FBQVQsR0FBZDs7QUFDQSxNQUFJQSxPQUFPLENBQUN3RSxPQUFSLENBQWdCeEYsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJrVyxtQkFBdkMsS0FBK0QsQ0FBQyxDQUFwRSxFQUFzRTtBQUNsRXJFLFdBQU8sR0FBRztBQUFDdlcsc0JBQWdCLEVBQUN2QjtBQUFsQixLQUFWO0FBQ0g7O0FBQ0QsU0FBTztBQUNIOEUsUUFBSSxHQUFFO0FBQ0YsYUFBT3pGLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0JnVCxPQUFoQixDQUFQO0FBQ0gsS0FIRTs7QUFJSHZJLFlBQVEsRUFBRSxDQUNOO0FBQ0l6SyxVQUFJLENBQUM0WCxHQUFELEVBQUs7QUFDTCxlQUFPblosa0JBQWtCLENBQUN1QixJQUFuQixDQUNIO0FBQUM5RSxpQkFBTyxFQUFDMGMsR0FBRyxDQUFDMWM7QUFBYixTQURHLEVBRUg7QUFBQytHLGNBQUksRUFBQztBQUFDM0Isa0JBQU0sRUFBQyxDQUFDO0FBQVQsV0FBTjtBQUFtQjRCLGVBQUssRUFBQztBQUF6QixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNLEVBU047QUFDSWxDLFVBQUksQ0FBQzRYLEdBQUQsRUFBTTtBQUNOLGVBQU90WixnQkFBZ0IsQ0FBQzBCLElBQWpCLENBQ0g7QUFBRTlFLGlCQUFPLEVBQUUwYyxHQUFHLENBQUMxYztBQUFmLFNBREcsRUFFSDtBQUFFK0csY0FBSSxFQUFFO0FBQUMzQixrQkFBTSxFQUFFLENBQUM7QUFBVixXQUFSO0FBQXNCNEIsZUFBSyxFQUFFaEksTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJDO0FBQXBELFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBVE07QUFKUCxHQUFQO0FBdUJILENBNUJlLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDM0NBakgsTUFBTSxDQUFDdVEsTUFBUCxDQUFjO0FBQUNuUSxZQUFVLEVBQUMsTUFBSUE7QUFBaEIsQ0FBZDtBQUEyQyxJQUFJb1EsS0FBSjtBQUFVeFEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDdVEsT0FBSyxDQUFDdFEsQ0FBRCxFQUFHO0FBQUNzUSxTQUFLLEdBQUN0USxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlpRSxnQkFBSjtBQUFxQm5FLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVCQUFaLEVBQW9DO0FBQUNrRSxrQkFBZ0IsQ0FBQ2pFLENBQUQsRUFBRztBQUFDaUUsb0JBQWdCLEdBQUNqRSxDQUFqQjtBQUFtQjs7QUFBeEMsQ0FBcEMsRUFBOEUsQ0FBOUU7QUFBaUYsSUFBSW9FLGtCQUFKO0FBQXVCdEUsTUFBTSxDQUFDQyxJQUFQLENBQVksNEJBQVosRUFBeUM7QUFBQ3FFLG9CQUFrQixDQUFDcEUsQ0FBRCxFQUFHO0FBQUNvRSxzQkFBa0IsR0FBQ3BFLENBQW5CO0FBQXFCOztBQUE1QyxDQUF6QyxFQUF1RixDQUF2RjtBQUk3TixNQUFNRSxVQUFVLEdBQUcsSUFBSW9RLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixZQUFyQixDQUFuQjtBQUVQclEsVUFBVSxDQUFDc1EsT0FBWCxDQUFtQjtBQUNmZ04sV0FBUyxHQUFFO0FBQ1AsV0FBT3ZaLGdCQUFnQixDQUFDL0IsT0FBakIsQ0FBeUI7QUFBQ3JCLGFBQU8sRUFBQyxLQUFLQTtBQUFkLEtBQXpCLENBQVA7QUFDSCxHQUhjOztBQUlmNGMsU0FBTyxHQUFFO0FBQ0wsV0FBT3JaLGtCQUFrQixDQUFDdUIsSUFBbkIsQ0FBd0I7QUFBQzlFLGFBQU8sRUFBQyxLQUFLQTtBQUFkLEtBQXhCLEVBQWdEO0FBQUMrRyxVQUFJLEVBQUM7QUFBQzNCLGNBQU0sRUFBQyxDQUFDO0FBQVQsT0FBTjtBQUFtQjRCLFdBQUssRUFBQztBQUF6QixLQUFoRCxFQUE4RWhDLEtBQTlFLEVBQVA7QUFDSDs7QUFOYyxDQUFuQixFLENBUUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzQkEvRixNQUFNLENBQUN1USxNQUFQLENBQWM7QUFBQ2pNLG9CQUFrQixFQUFDLE1BQUlBO0FBQXhCLENBQWQ7QUFBMkQsSUFBSWtNLEtBQUo7QUFBVXhRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3VRLE9BQUssQ0FBQ3RRLENBQUQsRUFBRztBQUFDc1EsU0FBSyxHQUFDdFEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUU5RCxNQUFNb0Usa0JBQWtCLEdBQUcsSUFBSWtNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixzQkFBckIsQ0FBM0IsQzs7Ozs7Ozs7Ozs7QUNGUHpRLE1BQU0sQ0FBQ3VRLE1BQVAsQ0FBYztBQUFDL0wsV0FBUyxFQUFDLE1BQUlBO0FBQWYsQ0FBZDtBQUF5QyxJQUFJZ00sS0FBSjtBQUFVeFEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDdVEsT0FBSyxDQUFDdFEsQ0FBRCxFQUFHO0FBQUNzUSxTQUFLLEdBQUN0USxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRTVDLE1BQU1zRSxTQUFTLEdBQUcsSUFBSWdNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixXQUFyQixDQUFsQixDOzs7Ozs7Ozs7OztBQ0ZQelEsTUFBTSxDQUFDdVEsTUFBUCxDQUFjO0FBQUNyTSxlQUFhLEVBQUMsTUFBSUE7QUFBbkIsQ0FBZDtBQUFpRCxJQUFJc00sS0FBSjtBQUFVeFEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDdVEsT0FBSyxDQUFDdFEsQ0FBRCxFQUFHO0FBQUNzUSxTQUFLLEdBQUN0USxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRXBELE1BQU1nRSxhQUFhLEdBQUcsSUFBSXNNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixnQkFBckIsQ0FBdEIsQzs7Ozs7Ozs7Ozs7QUNGUDtBQUNBLHdDOzs7Ozs7Ozs7OztBQ0RBLElBQUl6TSxTQUFKO0FBQWNoRSxNQUFNLENBQUNDLElBQVAsQ0FBWSw0QkFBWixFQUF5QztBQUFDK0QsV0FBUyxDQUFDOUQsQ0FBRCxFQUFHO0FBQUM4RCxhQUFTLEdBQUM5RCxDQUFWO0FBQVk7O0FBQTFCLENBQXpDLEVBQXFFLENBQXJFO0FBQXdFLElBQUlpRSxnQkFBSixFQUFxQkMsU0FBckIsRUFBK0I4VCxpQkFBL0IsRUFBaURDLFlBQWpELEVBQThESixXQUE5RCxFQUEwRUMsb0JBQTFFO0FBQStGaFksTUFBTSxDQUFDQyxJQUFQLENBQVksOEJBQVosRUFBMkM7QUFBQ2tFLGtCQUFnQixDQUFDakUsQ0FBRCxFQUFHO0FBQUNpRSxvQkFBZ0IsR0FBQ2pFLENBQWpCO0FBQW1CLEdBQXhDOztBQUF5Q2tFLFdBQVMsQ0FBQ2xFLENBQUQsRUFBRztBQUFDa0UsYUFBUyxHQUFDbEUsQ0FBVjtBQUFZLEdBQWxFOztBQUFtRWdZLG1CQUFpQixDQUFDaFksQ0FBRCxFQUFHO0FBQUNnWSxxQkFBaUIsR0FBQ2hZLENBQWxCO0FBQW9CLEdBQTVHOztBQUE2R2lZLGNBQVksQ0FBQ2pZLENBQUQsRUFBRztBQUFDaVksZ0JBQVksR0FBQ2pZLENBQWI7QUFBZSxHQUE1STs7QUFBNkk2WCxhQUFXLENBQUM3WCxDQUFELEVBQUc7QUFBQzZYLGVBQVcsR0FBQzdYLENBQVo7QUFBYyxHQUExSzs7QUFBMks4WCxzQkFBb0IsQ0FBQzlYLENBQUQsRUFBRztBQUFDOFgsd0JBQW9CLEdBQUM5WCxDQUFyQjtBQUF1Qjs7QUFBMU4sQ0FBM0MsRUFBdVEsQ0FBdlE7QUFBMFEsSUFBSXFFLFlBQUo7QUFBaUJ2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSx3Q0FBWixFQUFxRDtBQUFDc0UsY0FBWSxDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxnQkFBWSxHQUFDckUsQ0FBYjtBQUFlOztBQUFoQyxDQUFyRCxFQUF1RixDQUF2RjtBQUEwRixJQUFJZ0UsYUFBSjtBQUFrQmxFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDRDQUFaLEVBQXlEO0FBQUNpRSxlQUFhLENBQUNoRSxDQUFELEVBQUc7QUFBQ2dFLGlCQUFhLEdBQUNoRSxDQUFkO0FBQWdCOztBQUFsQyxDQUF6RCxFQUE2RixDQUE3RjtBQUFnRyxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUFqRCxFQUErRSxDQUEvRTtBQUFrRixJQUFJb0Usa0JBQUo7QUFBdUJ0RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQ0FBWixFQUFnRDtBQUFDcUUsb0JBQWtCLENBQUNwRSxDQUFELEVBQUc7QUFBQ29FLHNCQUFrQixHQUFDcEUsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQWhELEVBQThGLENBQTlGO0FBQWlHLElBQUlzRSxTQUFKO0FBQWN4RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxrQ0FBWixFQUErQztBQUFDdUUsV0FBUyxDQUFDdEUsQ0FBRCxFQUFHO0FBQUNzRSxhQUFTLEdBQUN0RSxDQUFWO0FBQVk7O0FBQTFCLENBQS9DLEVBQTJFLENBQTNFO0FBQThFLElBQUl3VixTQUFKO0FBQWMxVixNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDeVYsV0FBUyxDQUFDeFYsQ0FBRCxFQUFHO0FBQUN3VixhQUFTLEdBQUN4VixDQUFWO0FBQVk7O0FBQTFCLENBQWpELEVBQTZFLENBQTdFO0FBQWdGLElBQUkwUSxXQUFKO0FBQWdCNVEsTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQzJRLGFBQVcsQ0FBQzFRLENBQUQsRUFBRztBQUFDMFEsZUFBVyxHQUFDMVEsQ0FBWjtBQUFjOztBQUE5QixDQUF2QyxFQUF1RSxDQUF2RTtBQVkvakMwUSxXQUFXLENBQUNsSyxhQUFaLEdBQTRCa1gsV0FBNUIsQ0FBd0M7QUFBQ3pYLFFBQU0sRUFBRSxDQUFDO0FBQVYsQ0FBeEMsRUFBcUQ7QUFBQzBYLFFBQU0sRUFBQztBQUFSLENBQXJEO0FBRUE3WixTQUFTLENBQUMwQyxhQUFWLEdBQTBCa1gsV0FBMUIsQ0FBc0M7QUFBQ3pYLFFBQU0sRUFBRSxDQUFDO0FBQVYsQ0FBdEMsRUFBbUQ7QUFBQzBYLFFBQU0sRUFBQztBQUFSLENBQW5EO0FBQ0E3WixTQUFTLENBQUMwQyxhQUFWLEdBQTBCa1gsV0FBMUIsQ0FBc0M7QUFBQzlYLGlCQUFlLEVBQUM7QUFBakIsQ0FBdEM7QUFFQXRCLFNBQVMsQ0FBQ2tDLGFBQVYsR0FBMEJrWCxXQUExQixDQUFzQztBQUFDelgsUUFBTSxFQUFFLENBQUM7QUFBVixDQUF0QyxFLENBRUE7O0FBRUFoQyxnQkFBZ0IsQ0FBQ3VDLGFBQWpCLEdBQWlDa1gsV0FBakMsQ0FBNkM7QUFBQzdjLFNBQU8sRUFBQyxDQUFUO0FBQVdvRixRQUFNLEVBQUUsQ0FBQztBQUFwQixDQUE3QyxFQUFxRTtBQUFDMFgsUUFBTSxFQUFDO0FBQVIsQ0FBckU7QUFDQTFaLGdCQUFnQixDQUFDdUMsYUFBakIsR0FBaUNrWCxXQUFqQyxDQUE2QztBQUFDN2MsU0FBTyxFQUFDLENBQVQ7QUFBV29LLFFBQU0sRUFBQyxDQUFsQjtBQUFxQmhGLFFBQU0sRUFBRSxDQUFDO0FBQTlCLENBQTdDO0FBRUEvQixTQUFTLENBQUNzQyxhQUFWLEdBQTBCa1gsV0FBMUIsQ0FBc0M7QUFBQ3pYLFFBQU0sRUFBRSxDQUFDO0FBQVYsQ0FBdEMsRUFBb0Q7QUFBQzBYLFFBQU0sRUFBQztBQUFSLENBQXBEO0FBRUExRixZQUFZLENBQUN6UixhQUFiLEdBQTZCa1gsV0FBN0IsQ0FBeUM7QUFBQ2pOLFVBQVEsRUFBQyxDQUFWO0FBQWF1SSxPQUFLLEVBQUMsQ0FBbkI7QUFBc0J3QixXQUFTLEVBQUUsQ0FBQztBQUFsQyxDQUF6QztBQUNBdkMsWUFBWSxDQUFDelIsYUFBYixHQUE2QmtYLFdBQTdCLENBQXlDO0FBQUNqTixVQUFRLEVBQUMsQ0FBVjtBQUFhd0ksYUFBVyxFQUFDLENBQUM7QUFBMUIsQ0FBekM7QUFDQWhCLFlBQVksQ0FBQ3pSLGFBQWIsR0FBNkJrWCxXQUE3QixDQUF5QztBQUFDMUUsT0FBSyxFQUFDLENBQVA7QUFBVUMsYUFBVyxFQUFDLENBQUM7QUFBdkIsQ0FBekM7QUFDQWhCLFlBQVksQ0FBQ3pSLGFBQWIsR0FBNkJrWCxXQUE3QixDQUF5QztBQUFDMUUsT0FBSyxFQUFDLENBQVA7QUFBVXZJLFVBQVEsRUFBQyxDQUFuQjtBQUFzQndJLGFBQVcsRUFBQyxDQUFDO0FBQW5DLENBQXpDLEVBQWdGO0FBQUMwRSxRQUFNLEVBQUM7QUFBUixDQUFoRjtBQUVBM0YsaUJBQWlCLENBQUN4UixhQUFsQixHQUFrQ2tYLFdBQWxDLENBQThDO0FBQUNqTixVQUFRLEVBQUM7QUFBVixDQUE5QztBQUNBdUgsaUJBQWlCLENBQUN4UixhQUFsQixHQUFrQ2tYLFdBQWxDLENBQThDO0FBQUMxRSxPQUFLLEVBQUM7QUFBUCxDQUE5QztBQUNBaEIsaUJBQWlCLENBQUN4UixhQUFsQixHQUFrQ2tYLFdBQWxDLENBQThDO0FBQUNqTixVQUFRLEVBQUMsQ0FBVjtBQUFhdUksT0FBSyxFQUFDO0FBQW5CLENBQTlDLEVBQW9FO0FBQUMyRSxRQUFNLEVBQUM7QUFBUixDQUFwRTtBQUVBOUYsV0FBVyxDQUFDclIsYUFBWixHQUE0QmtYLFdBQTVCLENBQXdDO0FBQUNwYyxNQUFJLEVBQUMsQ0FBTjtBQUFTMlUsV0FBUyxFQUFDLENBQUM7QUFBcEIsQ0FBeEMsRUFBK0Q7QUFBQzBILFFBQU0sRUFBQztBQUFSLENBQS9EO0FBQ0E3RixvQkFBb0IsQ0FBQ3RSLGFBQXJCLEdBQXFDa1gsV0FBckMsQ0FBaUQ7QUFBQzlYLGlCQUFlLEVBQUMsQ0FBakI7QUFBbUJxUSxXQUFTLEVBQUMsQ0FBQztBQUE5QixDQUFqRCxFQUFrRjtBQUFDMEgsUUFBTSxFQUFDO0FBQVIsQ0FBbEYsRSxDQUNBOztBQUVBdFosWUFBWSxDQUFDbUMsYUFBYixHQUE2QmtYLFdBQTdCLENBQXlDO0FBQUNuRyxRQUFNLEVBQUM7QUFBUixDQUF6QyxFQUFvRDtBQUFDb0csUUFBTSxFQUFDO0FBQVIsQ0FBcEQ7QUFDQXRaLFlBQVksQ0FBQ21DLGFBQWIsR0FBNkJrWCxXQUE3QixDQUF5QztBQUFDelgsUUFBTSxFQUFDLENBQUM7QUFBVCxDQUF6QyxFLENBQ0E7O0FBQ0E1QixZQUFZLENBQUNtQyxhQUFiLEdBQTZCa1gsV0FBN0IsQ0FBeUM7QUFBQywyQkFBd0I7QUFBekIsQ0FBekM7QUFDQXJaLFlBQVksQ0FBQ21DLGFBQWIsR0FBNkJrWCxXQUE3QixDQUF5QztBQUFDLDZCQUEwQjtBQUEzQixDQUF6QztBQUVBMVosYUFBYSxDQUFDd0MsYUFBZCxHQUE4QmtYLFdBQTlCLENBQTBDO0FBQUNqVCxjQUFZLEVBQUMsQ0FBQztBQUFmLENBQTFDO0FBRUF2SyxVQUFVLENBQUNzRyxhQUFYLEdBQTJCa1gsV0FBM0IsQ0FBdUM7QUFBQzdjLFNBQU8sRUFBQztBQUFULENBQXZDLEVBQW1EO0FBQUM4YyxRQUFNLEVBQUMsSUFBUjtBQUFjQyx5QkFBdUIsRUFBRTtBQUFFL2MsV0FBTyxFQUFFO0FBQUVrSyxhQUFPLEVBQUU7QUFBWDtBQUFYO0FBQXZDLENBQW5EO0FBQ0E3SyxVQUFVLENBQUNzRyxhQUFYLEdBQTJCa1gsV0FBM0IsQ0FBdUM7QUFBQ3JWLGtCQUFnQixFQUFDO0FBQWxCLENBQXZDLEVBQTREO0FBQUNzVixRQUFNLEVBQUM7QUFBUixDQUE1RDtBQUNBemQsVUFBVSxDQUFDc0csYUFBWCxHQUEyQmtYLFdBQTNCLENBQXVDO0FBQUMsbUJBQWdCO0FBQWpCLENBQXZDLEVBQTJEO0FBQUNDLFFBQU0sRUFBQyxJQUFSO0FBQWNDLHlCQUF1QixFQUFFO0FBQUUscUJBQWlCO0FBQUU3UyxhQUFPLEVBQUU7QUFBWDtBQUFuQjtBQUF2QyxDQUEzRDtBQUVBM0csa0JBQWtCLENBQUNvQyxhQUFuQixHQUFtQ2tYLFdBQW5DLENBQStDO0FBQUM3YyxTQUFPLEVBQUMsQ0FBVDtBQUFXb0YsUUFBTSxFQUFDLENBQUM7QUFBbkIsQ0FBL0M7QUFDQTdCLGtCQUFrQixDQUFDb0MsYUFBbkIsR0FBbUNrWCxXQUFuQyxDQUErQztBQUFDcGMsTUFBSSxFQUFDO0FBQU4sQ0FBL0M7QUFFQWtVLFNBQVMsQ0FBQ2hQLGFBQVYsR0FBMEJrWCxXQUExQixDQUFzQztBQUFDaEksaUJBQWUsRUFBQyxDQUFDO0FBQWxCLENBQXRDLEVBQTJEO0FBQUNpSSxRQUFNLEVBQUM7QUFBUixDQUEzRCxFOzs7Ozs7Ozs7OztBQ3REQTdkLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVo7QUFBeUJELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG1CQUFaO0FBQWlDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQkFBWjtBQUFtQyxJQUFJOGQsVUFBSjtBQUFlL2QsTUFBTSxDQUFDQyxJQUFQLENBQVksc0JBQVosRUFBbUM7QUFBQzhkLFlBQVUsQ0FBQzdkLENBQUQsRUFBRztBQUFDNmQsY0FBVSxHQUFDN2QsQ0FBWDtBQUFhOztBQUE1QixDQUFuQyxFQUFpRSxDQUFqRTtBQUFvRSxJQUFJOGQsTUFBSjtBQUFXaGUsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDK2QsUUFBTSxDQUFDOWQsQ0FBRCxFQUFHO0FBQUM4ZCxVQUFNLEdBQUM5ZCxDQUFQO0FBQVM7O0FBQXBCLENBQTNCLEVBQWlELENBQWpEO0FBYzNMO0FBRUE2ZCxVQUFVLENBQUNFLElBQUksSUFBSTtBQUNmO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQSxRQUFNQyxNQUFNLEdBQUdGLE1BQU0sQ0FBQ0csWUFBUCxFQUFmO0FBQ0FGLE1BQUksQ0FBQ0csWUFBTCxDQUFrQkYsTUFBTSxDQUFDRyxJQUFQLENBQVlDLFFBQVosRUFBbEI7QUFDQUwsTUFBSSxDQUFDRyxZQUFMLENBQWtCRixNQUFNLENBQUNLLEtBQVAsQ0FBYUQsUUFBYixFQUFsQixFQWRlLENBZ0JmO0FBQ0gsQ0FqQlMsQ0FBVixDOzs7Ozs7Ozs7OztBQ2hCQXRlLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaO0FBQWtERCxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQ0FBWjtBQUFpREQsTUFBTSxDQUFDQyxJQUFQLENBQVksd0NBQVo7QUFBc0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaO0FBQWtERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx5Q0FBWjtBQUF1REQsTUFBTSxDQUFDQyxJQUFQLENBQVksd0NBQVo7QUFBc0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZDQUFaO0FBQTJERCxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQ0FBWjtBQUFtREQsTUFBTSxDQUFDQyxJQUFQLENBQVksMENBQVo7QUFBd0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdDQUFaO0FBQXNERCxNQUFNLENBQUNDLElBQVAsQ0FBWSw2Q0FBWjtBQUEyREQsTUFBTSxDQUFDQyxJQUFQLENBQVksK0NBQVo7QUFBNkRELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBDQUFaO0FBQXdERCxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQ0FBWjtBQUE2REQsTUFBTSxDQUFDQyxJQUFQLENBQVkseUNBQVo7QUFBdURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDhDQUFaO0FBQTRERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx5Q0FBWjtBQUF1REQsTUFBTSxDQUFDQyxJQUFQLENBQVksc0NBQVo7QUFBb0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdDQUFaLEU7Ozs7Ozs7Ozs7O0FDQS85QixJQUFJdWUsTUFBSjtBQUFXeGUsTUFBTSxDQUFDQyxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDZ1gsU0FBTyxDQUFDL1csQ0FBRCxFQUFHO0FBQUNzZSxVQUFNLEdBQUN0ZSxDQUFQO0FBQVM7O0FBQXJCLENBQXJCLEVBQTRDLENBQTVDO0FBQStDLElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSXlFLE9BQUo7QUFBWTNFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFNBQVosRUFBc0I7QUFBQyxNQUFJQyxDQUFKLEVBQU07QUFBQ3lFLFdBQU8sR0FBQ3pFLENBQVI7QUFBVTs7QUFBbEIsQ0FBdEIsRUFBMEMsQ0FBMUM7O0FBSTlIO0FBQ0EsSUFBSXVlLE1BQU0sR0FBR0MsR0FBRyxDQUFDQyxPQUFKLENBQVksZUFBWixDQUFiLEMsQ0FDQTs7O0FBQ0EsSUFBSUMsSUFBSSxHQUFHRixHQUFHLENBQUNDLE9BQUosQ0FBWSxlQUFaLEVBQTZCQyxJQUF4Qzs7QUFFQSxTQUFTQyxXQUFULENBQXFCQyxTQUFyQixFQUFnQztBQUM1QixTQUFPQSxTQUFTLENBQUM3WSxHQUFWLENBQWMsVUFBUzhZLElBQVQsRUFBZTtBQUNoQyxXQUFPLENBQUMsTUFBTSxDQUFDQSxJQUFJLEdBQUcsSUFBUixFQUFjVCxRQUFkLENBQXVCLEVBQXZCLENBQVAsRUFBbUNVLEtBQW5DLENBQXlDLENBQUMsQ0FBMUMsQ0FBUDtBQUNILEdBRk0sRUFFSkMsSUFGSSxDQUVDLEVBRkQsQ0FBUDtBQUdIOztBQUVEbGYsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWG9lLGdCQUFjLEVBQUUsVUFBUzdKLE1BQVQsRUFBaUI4SixNQUFqQixFQUF5QjtBQUNyQztBQUNBLFFBQUlDLGlCQUFpQixHQUFHalYsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUEwQixLQUExQixDQUF4QjtBQUNBLFFBQUlpVixNQUFNLEdBQUdsVixNQUFNLENBQUNtVixLQUFQLENBQWEsRUFBYixDQUFiO0FBQ0FGLHFCQUFpQixDQUFDRyxJQUFsQixDQUF1QkYsTUFBdkIsRUFBK0IsQ0FBL0I7QUFDQWxWLFVBQU0sQ0FBQ0MsSUFBUCxDQUFZaUwsTUFBTSxDQUFDNVQsS0FBbkIsRUFBMEIsUUFBMUIsRUFBb0M4ZCxJQUFwQyxDQUF5Q0YsTUFBekMsRUFBaURELGlCQUFpQixDQUFDdGQsTUFBbkU7QUFDQSxXQUFPMGMsTUFBTSxDQUFDZ0IsTUFBUCxDQUFjTCxNQUFkLEVBQXNCWCxNQUFNLENBQUNpQixPQUFQLENBQWVKLE1BQWYsQ0FBdEIsQ0FBUDtBQUNILEdBUlU7QUFTWEssZ0JBQWMsRUFBRSxVQUFTckssTUFBVCxFQUFpQjtBQUM3QjtBQUNBLFFBQUkrSixpQkFBaUIsR0FBR2pWLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBMEIsS0FBMUIsQ0FBeEI7QUFDQSxRQUFJaVYsTUFBTSxHQUFHbFYsTUFBTSxDQUFDQyxJQUFQLENBQVlvVSxNQUFNLENBQUNtQixTQUFQLENBQWlCbkIsTUFBTSxDQUFDb0IsTUFBUCxDQUFjdkssTUFBZCxFQUFzQndLLEtBQXZDLENBQVosQ0FBYjtBQUNBLFdBQU9SLE1BQU0sQ0FBQ0wsS0FBUCxDQUFhSSxpQkFBaUIsQ0FBQ3RkLE1BQS9CLEVBQXVDd2MsUUFBdkMsQ0FBZ0QsUUFBaEQsQ0FBUDtBQUNILEdBZFU7QUFlWHdCLGNBQVksRUFBRSxVQUFTQyxZQUFULEVBQXNCO0FBQ2hDLFFBQUloZixPQUFPLEdBQUd5ZCxNQUFNLENBQUNvQixNQUFQLENBQWNHLFlBQWQsQ0FBZDtBQUNBLFdBQU92QixNQUFNLENBQUNnQixNQUFQLENBQWN6ZixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1Qm1XLG1CQUFyQyxFQUEwRHBjLE9BQU8sQ0FBQzhlLEtBQWxFLENBQVA7QUFDSCxHQWxCVTtBQW1CWEcsbUJBQWlCLEVBQUUsVUFBU0MsVUFBVCxFQUFvQjtBQUNuQyxRQUFJemEsUUFBUSxHQUFHckYsSUFBSSxDQUFDSyxHQUFMLENBQVN5ZixVQUFULENBQWY7O0FBQ0EsUUFBSXphLFFBQVEsQ0FBQzlFLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0IsVUFBSStFLElBQUksR0FBR2QsT0FBTyxDQUFDZSxJQUFSLENBQWFGLFFBQVEsQ0FBQ25FLE9BQXRCLENBQVg7QUFDQSxhQUFPb0UsSUFBSSxDQUFDLG1CQUFELENBQUosQ0FBMEJFLElBQTFCLENBQStCLEtBQS9CLENBQVA7QUFDSDtBQUNKO0FBekJVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNmQTNGLE1BQU0sQ0FBQ3VRLE1BQVAsQ0FBYztBQUFDMlAsYUFBVyxFQUFDLE1BQUlBLFdBQWpCO0FBQTZCQyxvQkFBa0IsRUFBQyxNQUFJQSxrQkFBcEQ7QUFBdUVDLFVBQVEsRUFBQyxNQUFJQSxRQUFwRjtBQUE2RjdDLFFBQU0sRUFBQyxNQUFJQSxNQUF4RztBQUErRzhDLFVBQVEsRUFBQyxNQUFJQTtBQUE1SCxDQUFkO0FBQXFKLElBQUlDLEtBQUo7QUFBVXRnQixNQUFNLENBQUNDLElBQVAsQ0FBWSxPQUFaLEVBQW9CO0FBQUNnWCxTQUFPLENBQUMvVyxDQUFELEVBQUc7QUFBQ29nQixTQUFLLEdBQUNwZ0IsQ0FBTjtBQUFROztBQUFwQixDQUFwQixFQUEwQyxDQUExQztBQUE2QyxJQUFJcWdCLG1CQUFKO0FBQXdCdmdCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ3NnQixxQkFBbUIsQ0FBQ3JnQixDQUFELEVBQUc7QUFBQ3FnQix1QkFBbUIsR0FBQ3JnQixDQUFwQjtBQUFzQjs7QUFBOUMsQ0FBekIsRUFBeUUsQ0FBekU7O0FBRzdOLE1BQU1nZ0IsV0FBVyxHQUFJTSxLQUFELElBQVc7QUFDbEMsVUFBUUEsS0FBSyxDQUFDdk4sS0FBZDtBQUNBLFNBQUssT0FBTDtBQUNJLGFBQU8sSUFBUDs7QUFDSjtBQUNJLGFBQU8sSUFBUDtBQUpKO0FBTUgsQ0FQTTs7QUFVQSxNQUFNa04sa0JBQWtCLEdBQUlLLEtBQUQsSUFBVztBQUN6QyxVQUFRQSxLQUFLLENBQUM5WSxNQUFkO0FBQ0EsU0FBSyxRQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssVUFBTDtBQUNJLGFBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSixTQUFLLFNBQUw7QUFDSSxhQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxlQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssY0FBTDtBQUNJLGFBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSjtBQUNJLGFBQU8sOEJBQVA7QUFaSjtBQWNILENBZk07O0FBaUJBLE1BQU0wWSxRQUFRLEdBQUlJLEtBQUQsSUFBVztBQUMvQixVQUFRQSxLQUFLLENBQUNDLElBQWQ7QUFDQSxTQUFLLEtBQUw7QUFDSSxhQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxJQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssU0FBTDtBQUNJLGFBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSixTQUFLLGNBQUw7QUFDSSxhQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0o7QUFDSSxhQUFPLDhCQUFQO0FBVko7QUFZSCxDQWJNOztBQWVBLE1BQU1sRCxNQUFNLEdBQUlpRCxLQUFELElBQVc7QUFDN0IsTUFBSUEsS0FBSyxDQUFDRSxLQUFWLEVBQWdCO0FBQ1osV0FBTztBQUFNLGVBQVMsRUFBQztBQUFoQixPQUEyQztBQUFHLGVBQVMsRUFBQztBQUFiLE1BQTNDLENBQVA7QUFDSCxHQUZELE1BR0k7QUFDQSxXQUFPO0FBQU0sZUFBUyxFQUFDO0FBQWhCLE9BQTBDO0FBQUcsZUFBUyxFQUFDO0FBQWIsTUFBMUMsQ0FBUDtBQUNIO0FBQ0osQ0FQTTs7QUFTQSxNQUFNTCxRQUFOLFNBQXVCQyxLQUFLLENBQUNLLFNBQTdCLENBQXVDO0FBQzFDQyxhQUFXLENBQUNKLEtBQUQsRUFBUTtBQUNmLFVBQU1BLEtBQU47QUFDQSxTQUFLSyxHQUFMLEdBQVdQLEtBQUssQ0FBQ1EsU0FBTixFQUFYO0FBQ0g7O0FBRURDLFFBQU0sR0FBRztBQUNMLFdBQU8sQ0FDSDtBQUFHLFNBQUcsRUFBQyxNQUFQO0FBQWMsZUFBUyxFQUFDLDBCQUF4QjtBQUFtRCxTQUFHLEVBQUUsS0FBS0Y7QUFBN0QsY0FERyxFQUVILG9CQUFDLG1CQUFEO0FBQXFCLFNBQUcsRUFBQyxTQUF6QjtBQUFtQyxlQUFTLEVBQUMsT0FBN0M7QUFBcUQsWUFBTSxFQUFFLEtBQUtBO0FBQWxFLE9BQ0ssS0FBS0wsS0FBTCxDQUFXbFEsUUFBWCxHQUFvQixLQUFLa1EsS0FBTCxDQUFXbFEsUUFBL0IsR0FBd0MsS0FBS2tRLEtBQUwsQ0FBV1EsV0FEeEQsQ0FGRyxDQUFQO0FBTUg7O0FBYnlDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEQ5Q2hoQixNQUFNLENBQUN1USxNQUFQLENBQWM7QUFBQzBHLFNBQU8sRUFBQyxNQUFJZ0s7QUFBYixDQUFkO0FBQWtDLElBQUlsaEIsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJZ2hCLE1BQUo7QUFBV2xoQixNQUFNLENBQUNDLElBQVAsQ0FBWSxRQUFaLEVBQXFCO0FBQUNnWCxTQUFPLENBQUMvVyxDQUFELEVBQUc7QUFBQ2doQixVQUFNLEdBQUNoaEIsQ0FBUDtBQUFTOztBQUFyQixDQUFyQixFQUE0QyxDQUE1Qzs7QUFHN0dpaEIsVUFBVSxHQUFJMWYsS0FBRCxJQUFXO0FBQ3ZCLE1BQUkyZixTQUFTLEdBQUcsVUFBaEI7QUFDQTNmLE9BQUssR0FBRzRLLElBQUksQ0FBQzZFLEtBQUwsQ0FBV3pQLEtBQUssR0FBRyxJQUFuQixJQUEyQixJQUFuQztBQUNBLE1BQUk0SyxJQUFJLENBQUM2RSxLQUFMLENBQVd6UCxLQUFYLE1BQXNCQSxLQUExQixFQUNDMmYsU0FBUyxHQUFHLEtBQVosQ0FERCxLQUVLLElBQUkvVSxJQUFJLENBQUM2RSxLQUFMLENBQVd6UCxLQUFLLEdBQUMsRUFBakIsTUFBeUJBLEtBQUssR0FBQyxFQUFuQyxFQUNKMmYsU0FBUyxHQUFHLE9BQVosQ0FESSxLQUVBLElBQUkvVSxJQUFJLENBQUM2RSxLQUFMLENBQVd6UCxLQUFLLEdBQUMsR0FBakIsTUFBMEJBLEtBQUssR0FBQyxHQUFwQyxFQUNKMmYsU0FBUyxHQUFHLFFBQVosQ0FESSxLQUVBLElBQUkvVSxJQUFJLENBQUM2RSxLQUFMLENBQVd6UCxLQUFLLEdBQUMsSUFBakIsTUFBMkJBLEtBQUssR0FBQyxJQUFyQyxFQUNKMmYsU0FBUyxHQUFHLFNBQVo7QUFDRCxTQUFPRixNQUFNLENBQUN6ZixLQUFELENBQU4sQ0FBYzRmLE1BQWQsQ0FBcUJELFNBQXJCLENBQVA7QUFDQSxDQVpEOztBQWNlLE1BQU1ILElBQU4sQ0FBVztBQU96QkwsYUFBVyxDQUFDNU4sTUFBRCxFQUFxQjtBQUFBLFFBQVpDLEtBQVksdUVBQU4sSUFBTTtBQUMvQixRQUFJLE9BQU9ELE1BQVAsS0FBa0IsUUFBdEIsRUFDQyxDQUFDO0FBQUNBLFlBQUQ7QUFBU0M7QUFBVCxRQUFrQkQsTUFBbkI7O0FBQ0QsUUFBSSxDQUFDQyxLQUFELElBQVVBLEtBQUssQ0FBQ3FPLFdBQU4sT0FBd0JMLElBQUksQ0FBQ00sWUFBTCxDQUFrQkQsV0FBbEIsRUFBdEMsRUFBdUU7QUFDdEUsV0FBS0UsT0FBTCxHQUFlekssTUFBTSxDQUFDL0QsTUFBRCxDQUFyQjtBQUNBLEtBRkQsTUFFTyxJQUFJQyxLQUFLLENBQUNxTyxXQUFOLE9BQXdCTCxJQUFJLENBQUNRLFlBQUwsQ0FBa0JILFdBQWxCLEVBQTVCLEVBQTZEO0FBQ25FLFdBQUtFLE9BQUwsR0FBZXpLLE1BQU0sQ0FBQy9ELE1BQUQsQ0FBTixHQUFpQmlPLElBQUksQ0FBQ1MsZUFBckM7QUFDQSxLQUZNLE1BR0Y7QUFDSixZQUFNcEssS0FBSyw2QkFBc0JyRSxLQUF0QixFQUFYO0FBQ0E7QUFDRDs7QUFFRCxNQUFJRCxNQUFKLEdBQWM7QUFDYixXQUFPLEtBQUt3TyxPQUFaO0FBQ0E7O0FBRUQsTUFBSUcsYUFBSixHQUFxQjtBQUNwQixXQUFPLEtBQUtILE9BQUwsR0FBZVAsSUFBSSxDQUFDUyxlQUEzQjtBQUNBOztBQUVEcEQsVUFBUSxDQUFFc0QsU0FBRixFQUFhO0FBQ3BCO0FBQ0EsUUFBSUMsUUFBUSxHQUFHWixJQUFJLENBQUNTLGVBQUwsSUFBc0JFLFNBQVMsR0FBQ3ZWLElBQUksQ0FBQ3lWLEdBQUwsQ0FBUyxFQUFULEVBQWFGLFNBQWIsQ0FBRCxHQUF5QixLQUF4RCxDQUFmOztBQUNBLFFBQUksS0FBSzVPLE1BQUwsR0FBYzZPLFFBQWxCLEVBQTRCO0FBQzNCLHVCQUFVWCxNQUFNLENBQUMsS0FBS2xPLE1BQU4sQ0FBTixDQUFvQnFPLE1BQXBCLENBQTJCLEtBQTNCLENBQVYsY0FBK0NKLElBQUksQ0FBQ00sWUFBcEQ7QUFDQSxLQUZELE1BRU87QUFDTix1QkFBVUssU0FBUyxHQUFDVixNQUFNLENBQUMsS0FBS1MsYUFBTixDQUFOLENBQTJCTixNQUEzQixDQUFrQyxTQUFTLElBQUlVLE1BQUosQ0FBV0gsU0FBWCxDQUEzQyxDQUFELEdBQW1FVCxVQUFVLENBQUMsS0FBS1EsYUFBTixDQUFoRyxjQUF3SFYsSUFBSSxDQUFDUSxZQUE3SDtBQUNBO0FBQ0Q7O0FBRURPLFlBQVUsQ0FBRVosU0FBRixFQUFhO0FBQ3RCLFFBQUlwTyxNQUFNLEdBQUcsS0FBS0EsTUFBbEI7O0FBQ0EsUUFBSW9PLFNBQUosRUFBZTtBQUNkcE8sWUFBTSxHQUFHa08sTUFBTSxDQUFDbE8sTUFBRCxDQUFOLENBQWVxTyxNQUFmLENBQXNCRCxTQUF0QixDQUFUO0FBQ0E7O0FBQ0QscUJBQVVwTyxNQUFWLGNBQW9CaU8sSUFBSSxDQUFDTSxZQUF6QjtBQUNBOztBQUVEVSxhQUFXLENBQUViLFNBQUYsRUFBYTtBQUN2QixRQUFJcE8sTUFBTSxHQUFHLEtBQUsyTyxhQUFsQjs7QUFDQSxRQUFJUCxTQUFKLEVBQWU7QUFDZHBPLFlBQU0sR0FBR2tPLE1BQU0sQ0FBQ2xPLE1BQUQsQ0FBTixDQUFlcU8sTUFBZixDQUFzQkQsU0FBdEIsQ0FBVDtBQUNBOztBQUNELHFCQUFVcE8sTUFBVixjQUFvQmlPLElBQUksQ0FBQ1EsWUFBekI7QUFDQTs7QUFwRHdCOztBQUFMUixJLENBQ2JRLFksR0FBZTFoQixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmtiLFk7QUFEekJqQixJLENBRWJrQixrQixHQUFxQnBpQixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1Qm9iLGtCQUF2QixJQUE4Q25CLElBQUksQ0FBQ1EsWUFBTCxHQUFvQixHO0FBRjFFUixJLENBR2JNLFksR0FBZXhoQixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjJMLFk7QUFIekJzTyxJLENBSWJTLGUsR0FBa0IzSyxNQUFNLENBQUNoWCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QnVPLGVBQXhCLEM7QUFKWDBMLEksQ0FLYm9CLFEsR0FBVyxJQUFJdEwsTUFBTSxDQUFDaFgsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJ1TyxlQUF4QixDOzs7Ozs7Ozs7OztBQ3RCN0J2VixNQUFNLENBQUNDLElBQVAsQ0FBWSx5QkFBWjtBQUF1Q0QsTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVo7QUFJdkM7QUFDQTtBQUVBaUksT0FBTyxHQUFHLEtBQVY7QUFDQXVSLGlCQUFpQixHQUFHLEtBQXBCO0FBQ0E4QixzQkFBc0IsR0FBRyxLQUF6QjtBQUNBOVQsR0FBRyxHQUFHMUgsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQnViLE1BQWhCLENBQXVCQyxHQUE3QjtBQUNBOWhCLEdBQUcsR0FBR1YsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQnViLE1BQWhCLENBQXVCRSxHQUE3QjtBQUNBQyxXQUFXLEdBQUcsQ0FBZDtBQUNBQyxVQUFVLEdBQUcsQ0FBYjtBQUNBQyxjQUFjLEdBQUcsQ0FBakI7QUFDQUMsYUFBYSxHQUFHLENBQWhCO0FBQ0FDLHFCQUFxQixHQUFHLENBQXhCO0FBQ0FDLGdCQUFnQixHQUFHLENBQW5CO0FBQ0FDLGVBQWUsR0FBRyxDQUFsQjtBQUNBQyxjQUFjLEdBQUcsQ0FBakI7QUFFQSxNQUFNQyxlQUFlLEdBQUcsd0JBQXhCOztBQUVBQyxpQkFBaUIsR0FBRyxNQUFNO0FBQ3RCbmpCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSxvQkFBWixFQUFrQyxDQUFDK2EsS0FBRCxFQUFRN2hCLE1BQVIsS0FBbUI7QUFDakQsUUFBSTZoQixLQUFKLEVBQVU7QUFDTnZpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxtQkFBaUJzaUIsS0FBN0I7QUFDSCxLQUZELE1BR0k7QUFDQXZpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxtQkFBaUJTLE1BQTdCO0FBQ0g7QUFDSixHQVBEO0FBUUgsQ0FURDs7QUFXQThoQixXQUFXLEdBQUcsTUFBTTtBQUNoQnJqQixRQUFNLENBQUNxSSxJQUFQLENBQVkscUJBQVosRUFBbUMsQ0FBQythLEtBQUQsRUFBUTdoQixNQUFSLEtBQW1CO0FBQ2xELFFBQUk2aEIsS0FBSixFQUFVO0FBQ052aUIsYUFBTyxDQUFDQyxHQUFSLENBQVksbUJBQWlCc2lCLEtBQTdCO0FBQ0gsS0FGRCxNQUdJO0FBQ0F2aUIsYUFBTyxDQUFDQyxHQUFSLENBQVksbUJBQWlCUyxNQUE3QjtBQUNIO0FBQ0osR0FQRDtBQVFILENBVEQ7O0FBV0EraEIsaUJBQWlCLEdBQUcsTUFBTTtBQUN0QnRqQixRQUFNLENBQUNxSSxJQUFQLENBQVkseUJBQVosRUFBdUMsQ0FBQythLEtBQUQsRUFBUTdoQixNQUFSLEtBQW1CO0FBQ3RELFFBQUk2aEIsS0FBSixFQUFVO0FBQ052aUIsYUFBTyxDQUFDQyxHQUFSLENBQVksb0JBQWtCc2lCLEtBQTlCO0FBQ0g7QUFDSixHQUpEO0FBS0gsQ0FORDs7QUFRQUcsaUJBQWlCLEdBQUcsTUFBTTtBQUN2QnZqQixRQUFNLENBQUNxSSxJQUFQLENBQVksOEJBQVosRUFBNEMsQ0FBQythLEtBQUQsRUFBUTdoQixNQUFSLEtBQW1CO0FBQzNELFFBQUk2aEIsS0FBSixFQUFVO0FBQ052aUIsYUFBTyxDQUFDQyxHQUFSLENBQVksYUFBWXNpQixLQUF4QjtBQUNIOztBQUNELFFBQUk3aEIsTUFBSixFQUFXO0FBQ1BWLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGFBQVdTLE1BQXZCO0FBQ0g7QUFDSixHQVBEO0FBUUYsQ0FURCxDLENBV0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFFQWlpQixrQkFBa0IsR0FBRyxNQUFNO0FBQ3ZCeGpCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSx3Q0FBWixFQUFzRCxDQUFDK2EsS0FBRCxFQUFRN2hCLE1BQVIsS0FBa0I7QUFDcEUsUUFBSTZoQixLQUFKLEVBQVU7QUFDTnZpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSwwQkFBeUJzaUIsS0FBckM7QUFDSDs7QUFDRCxRQUFJN2hCLE1BQUosRUFBVztBQUNQVixhQUFPLENBQUNDLEdBQVIsQ0FBWSxzQkFBc0JTLE1BQWxDO0FBQ0g7QUFDSixHQVBEO0FBUUo7Ozs7Ozs7Ozs7QUFVQyxDQW5CRDs7QUFxQkFraUIsY0FBYyxHQUFHLE1BQU07QUFDbkJ6akIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLDRCQUFaLEVBQTBDLENBQUMrYSxLQUFELEVBQVE3aEIsTUFBUixLQUFtQjtBQUN6RCxRQUFJNmhCLEtBQUosRUFBVTtBQUNOdmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUEyQnNpQixLQUF2QztBQUNILEtBRkQsTUFHSTtBQUNBdmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHlCQUF3QlMsTUFBcEM7QUFDSDtBQUNKLEdBUEQ7QUFRSCxDQVREOztBQVdBbWlCLGlCQUFpQixHQUFHLE1BQUs7QUFDckI7QUFDQTFqQixRQUFNLENBQUNxSSxJQUFQLENBQVksNENBQVosRUFBMEQsR0FBMUQsRUFBK0QsQ0FBQythLEtBQUQsRUFBUTdoQixNQUFSLEtBQW1CO0FBQzlFLFFBQUk2aEIsS0FBSixFQUFVO0FBQ052aUIsYUFBTyxDQUFDQyxHQUFSLENBQVksMENBQXdDc2lCLEtBQXBEO0FBQ0gsS0FGRCxNQUdJO0FBQ0F2aUIsYUFBTyxDQUFDQyxHQUFSLENBQVksdUNBQXFDUyxNQUFqRDtBQUNIO0FBQ0osR0FQRDtBQVNBdkIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLHdCQUFaLEVBQXNDLENBQUMrYSxLQUFELEVBQVE3aEIsTUFBUixLQUFtQjtBQUNyRCxRQUFJNmhCLEtBQUosRUFBVTtBQUNOdmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDJCQUF5QnNpQixLQUFyQztBQUNILEtBRkQsTUFHSTtBQUNBdmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHdCQUFzQlMsTUFBbEM7QUFDSDtBQUNKLEdBUEQ7QUFRSCxDQW5CRDs7QUFxQkFvaUIsZUFBZSxHQUFHLE1BQUs7QUFDbkI7QUFDQTNqQixRQUFNLENBQUNxSSxJQUFQLENBQVksNENBQVosRUFBMEQsR0FBMUQsRUFBK0QsQ0FBQythLEtBQUQsRUFBUTdoQixNQUFSLEtBQW1CO0FBQzlFLFFBQUk2aEIsS0FBSixFQUFVO0FBQ052aUIsYUFBTyxDQUFDQyxHQUFSLENBQVksd0NBQXNDc2lCLEtBQWxEO0FBQ0gsS0FGRCxNQUdJO0FBQ0F2aUIsYUFBTyxDQUFDQyxHQUFSLENBQVkscUNBQW1DUyxNQUEvQztBQUNIO0FBQ0osR0FQRDtBQVFILENBVkQ7O0FBWUFxaUIsY0FBYyxHQUFHLE1BQUs7QUFDbEI7QUFDQTVqQixRQUFNLENBQUNxSSxJQUFQLENBQVksNENBQVosRUFBMEQsR0FBMUQsRUFBK0QsQ0FBQythLEtBQUQsRUFBUTdoQixNQUFSLEtBQW1CO0FBQzlFLFFBQUk2aEIsS0FBSixFQUFVO0FBQ052aUIsYUFBTyxDQUFDQyxHQUFSLENBQVksdUNBQXFDc2lCLEtBQWpEO0FBQ0gsS0FGRCxNQUdJO0FBQ0F2aUIsYUFBTyxDQUFDQyxHQUFSLENBQVksb0NBQWtDUyxNQUE5QztBQUNIO0FBQ0osR0FQRDtBQVNBdkIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLDRDQUFaLEVBQTBELENBQUMrYSxLQUFELEVBQVE3aEIsTUFBUixLQUFtQjtBQUN6RSxRQUFJNmhCLEtBQUosRUFBVTtBQUNOdmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDJDQUEwQ3NpQixLQUF0RDtBQUNILEtBRkQsTUFHSztBQUNEdmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHdDQUF1Q1MsTUFBbkQ7QUFDSDtBQUNKLEdBUEQ7QUFRSCxDQW5CRDs7QUF1QkF2QixNQUFNLENBQUM2akIsT0FBUCxDQUFlLFlBQVU7QUFDckIsTUFBSTdqQixNQUFNLENBQUM4akIsYUFBWCxFQUF5QjtBQS9LN0IsUUFBSUMsbUJBQUo7QUFBd0I5akIsVUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ2dYLGFBQU8sQ0FBQy9XLENBQUQsRUFBRztBQUFDNGpCLDJCQUFtQixHQUFDNWpCLENBQXBCO0FBQXNCOztBQUFsQyxLQUF2QyxFQUEyRSxDQUEzRTtBQWdMaEI2akIsV0FBTyxDQUFDQyxHQUFSLENBQVlDLDRCQUFaLEdBQTJDLENBQTNDO0FBRUF4YixVQUFNLENBQUNDLElBQVAsQ0FBWW9iLG1CQUFaLEVBQWlDL2dCLE9BQWpDLENBQTBDbWhCLEdBQUQsSUFBUztBQUM5QyxVQUFJbmtCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JtZCxHQUFoQixLQUF3QnZWLFNBQTVCLEVBQXVDO0FBQ25DL04sZUFBTyxDQUFDdWpCLElBQVIsZ0NBQXFDRCxHQUFyQztBQUNBbmtCLGNBQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JtZCxHQUFoQixJQUF1QixFQUF2QjtBQUNIOztBQUNEemIsWUFBTSxDQUFDQyxJQUFQLENBQVlvYixtQkFBbUIsQ0FBQ0ksR0FBRCxDQUEvQixFQUFzQ25oQixPQUF0QyxDQUErQ3FoQixLQUFELElBQVc7QUFDckQsWUFBSXJrQixNQUFNLENBQUNnSCxRQUFQLENBQWdCbWQsR0FBaEIsRUFBcUJFLEtBQXJCLEtBQStCelYsU0FBbkMsRUFBNkM7QUFDekMvTixpQkFBTyxDQUFDdWpCLElBQVIsZ0NBQXFDRCxHQUFyQyxjQUE0Q0UsS0FBNUM7QUFDQXJrQixnQkFBTSxDQUFDZ0gsUUFBUCxDQUFnQm1kLEdBQWhCLEVBQXFCRSxLQUFyQixJQUE4Qk4sbUJBQW1CLENBQUNJLEdBQUQsQ0FBbkIsQ0FBeUJFLEtBQXpCLENBQTlCO0FBQ0g7QUFDSixPQUxEO0FBTUgsS0FYRDtBQVlIOztBQUVEcmtCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSxlQUFaLEVBQTZCLENBQUNpQyxHQUFELEVBQU0vSSxNQUFOLEtBQWlCO0FBQzFDLFFBQUkrSSxHQUFKLEVBQVE7QUFDSnpKLGFBQU8sQ0FBQ0MsR0FBUixDQUFZd0osR0FBWjtBQUNIOztBQUNELFFBQUkvSSxNQUFKLEVBQVc7QUFDUCxVQUFJdkIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQndNLEtBQWhCLENBQXNCOFEsVUFBMUIsRUFBcUM7QUFDakMxQixzQkFBYyxHQUFHNWlCLE1BQU0sQ0FBQ3VrQixXQUFQLENBQW1CLFlBQVU7QUFDMUNqQiwyQkFBaUI7QUFDcEIsU0FGZ0IsRUFFZHRqQixNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUJzYyxpQkFGVCxDQUFqQjtBQUlBOUIsbUJBQVcsR0FBRzFpQixNQUFNLENBQUN1a0IsV0FBUCxDQUFtQixZQUFVO0FBQ3ZDbEIscUJBQVc7QUFDZCxTQUZhLEVBRVhyakIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCdWMsYUFGWixDQUFkO0FBSUE5QixrQkFBVSxHQUFHM2lCLE1BQU0sQ0FBQ3VrQixXQUFQLENBQW1CLFlBQVU7QUFDdENwQiwyQkFBaUI7QUFDcEIsU0FGWSxFQUVWbmpCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QndjLGNBRmIsQ0FBYjtBQUlBQywwQkFBa0IsR0FBRzNrQixNQUFNLENBQUN1a0IsV0FBUCxDQUFvQixZQUFXO0FBQ2hEaEIsMkJBQWlCO0FBQ3BCLFNBRm9CLEVBRWxCdmpCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QjBjLGdCQUZMLENBQXJCLENBYmlDLENBaUJqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFZ0I3Qix3QkFBZ0IsR0FBRy9pQixNQUFNLENBQUN1a0IsV0FBUCxDQUFtQixZQUFVO0FBQzVDZiw0QkFBa0I7QUFDckIsU0FGa0IsRUFFaEJ4akIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCMmMsb0JBRlAsQ0FBbkI7QUFJQTdCLHVCQUFlLEdBQUdoakIsTUFBTSxDQUFDdWtCLFdBQVAsQ0FBbUIsWUFBVTtBQUMzQ2Qsd0JBQWM7QUFDakIsU0FGaUIsRUFFZnpqQixNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUI0YyxrQkFGUixDQUFsQjtBQUlBN0Isc0JBQWMsR0FBR2pqQixNQUFNLENBQUN1a0IsV0FBUCxDQUFtQixZQUFVO0FBQzFDLGNBQUl2TyxHQUFHLEdBQUcsSUFBSTVTLElBQUosRUFBVjs7QUFDQSxjQUFLNFMsR0FBRyxDQUFDK08sYUFBSixNQUF1QixDQUE1QixFQUErQjtBQUMzQnJCLDZCQUFpQjtBQUNwQjs7QUFFRCxjQUFLMU4sR0FBRyxDQUFDZ1AsYUFBSixNQUF1QixDQUF4QixJQUErQmhQLEdBQUcsQ0FBQytPLGFBQUosTUFBdUIsQ0FBMUQsRUFBNkQ7QUFDekRwQiwyQkFBZTtBQUNsQjs7QUFFRCxjQUFLM04sR0FBRyxDQUFDaVAsV0FBSixNQUFxQixDQUF0QixJQUE2QmpQLEdBQUcsQ0FBQ2dQLGFBQUosTUFBdUIsQ0FBcEQsSUFBMkRoUCxHQUFHLENBQUMrTyxhQUFKLE1BQXVCLENBQXRGLEVBQXlGO0FBQ3JGbkIsMEJBQWM7QUFDakI7QUFDSixTQWJnQixFQWFkLElBYmMsQ0FBakI7QUFjSDtBQUNKO0FBQ0osR0F0REQ7QUF3REgsQ0ExRUQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuY29uc3QgZmV0Y2hGcm9tVXJsID0gKHVybCkgPT4ge1xuICAgIHRyeXtcbiAgICAgICAgbGV0IHJlcyA9IEhUVFAuZ2V0KExDRCArIHVybCk7XG4gICAgICAgIGlmIChyZXMuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgcmV0dXJuIHJlc1xuICAgICAgICB9O1xuICAgIH1cbiAgICBjYXRjaCAoZSl7XG4gICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgIH1cbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdhY2NvdW50cy5nZXRBY2NvdW50RGV0YWlsJzogZnVuY3Rpb24oYWRkcmVzcyl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgdXJsID0gTENEICsgJy9hdXRoL2FjY291bnRzLycrIGFkZHJlc3M7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCBhdmFpbGFibGUgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGF2YWlsYWJsZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSlNPTi5wYXJzZShhdmFpbGFibGUuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgIGxldCBhY2NvdW50O1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS50eXBlID09PSAnY29zbW9zLXNkay9BY2NvdW50JylcbiAgICAgICAgICAgICAgICAgICAgYWNjb3VudCA9IHJlc3BvbnNlLnZhbHVlO1xuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHJlc3BvbnNlLnR5cGUgPT09ICdjb3Ntb3Mtc2RrL0RlbGF5ZWRWZXN0aW5nQWNjb3VudCcgfHwgcmVzcG9uc2UudHlwZSA9PT0gJ2Nvc21vcy1zZGsvQ29udGludW91c1Zlc3RpbmdBY2NvdW50JylcbiAgICAgICAgICAgICAgICAgICAgYWNjb3VudCA9IHJlc3BvbnNlLnZhbHVlLkJhc2VWZXN0aW5nQWNjb3VudC5CYXNlQWNjb3VudFxuICAgICAgICAgICAgICAgIGlmIChhY2NvdW50ICYmIGFjY291bnQuYWNjb3VudF9udW1iZXIgIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFjY291bnRcbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbFxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgIH1cbiAgICB9LFxuICAgICdhY2NvdW50cy5nZXRCYWxhbmNlJzogZnVuY3Rpb24oYWRkcmVzcyl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgYmFsYW5jZSA9IHt9XG5cbiAgICAgICAgLy8gZ2V0IGF2YWlsYWJsZSBhdG9tc1xuICAgICAgICBsZXQgdXJsID0gTENEICsgJy9iYW5rL2JhbGFuY2VzLycrIGFkZHJlc3M7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCBhdmFpbGFibGUgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGF2YWlsYWJsZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coSlNPTi5wYXJzZShhdmFpbGFibGUuY29udGVudCkpXG4gICAgICAgICAgICAgICAgYmFsYW5jZS5hdmFpbGFibGUgPSBKU09OLnBhcnNlKGF2YWlsYWJsZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgaWYgKGJhbGFuY2UuYXZhaWxhYmxlICYmIGJhbGFuY2UuYXZhaWxhYmxlLmxlbmd0aCA+IDApXG4gICAgICAgICAgICAgICAgICAgIGJhbGFuY2UuYXZhaWxhYmxlID0gYmFsYW5jZS5hdmFpbGFibGVbMF07XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGdldCBkZWxlZ2F0ZWQgYW1ub3VudHNcbiAgICAgICAgdXJsID0gTENEICsgJy9zdGFraW5nL2RlbGVnYXRvcnMvJythZGRyZXNzKycvZGVsZWdhdGlvbnMnO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgZGVsZWdhdGlvbnMgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICBiYWxhbmNlLmRlbGVnYXRpb25zID0gSlNPTi5wYXJzZShkZWxlZ2F0aW9ucy5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gZ2V0IHVuYm9uZGluZ1xuICAgICAgICB1cmwgPSBMQ0QgKyAnL3N0YWtpbmcvZGVsZWdhdG9ycy8nK2FkZHJlc3MrJy91bmJvbmRpbmdfZGVsZWdhdGlvbnMnO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgdW5ib25kaW5nID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmICh1bmJvbmRpbmcuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIGJhbGFuY2UudW5ib25kaW5nID0gSlNPTi5wYXJzZSh1bmJvbmRpbmcuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gZ2V0IHJld2FyZHNcbiAgICAgICAgdXJsID0gTENEICsgJy9kaXN0cmlidXRpb24vZGVsZWdhdG9ycy8nK2FkZHJlc3MrJy9yZXdhcmRzJztcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IHJld2FyZHMgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKHJld2FyZHMuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIGJhbGFuY2UucmV3YXJkcyA9IEpTT04ucGFyc2UocmV3YXJkcy5jb250ZW50KS5yZXN1bHQudG90YWw7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBnZXQgY29tbWlzc2lvblxuICAgICAgICBsZXQgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKFxuICAgICAgICAgICAgeyRvcjogW3tvcGVyYXRvcl9hZGRyZXNzOmFkZHJlc3N9LCB7ZGVsZWdhdG9yX2FkZHJlc3M6YWRkcmVzc30sIHthZGRyZXNzOmFkZHJlc3N9XX0pXG4gICAgICAgIGlmICh2YWxpZGF0b3IpIHtcbiAgICAgICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL2Rpc3RyaWJ1dGlvbi92YWxpZGF0b3JzLycgKyB2YWxpZGF0b3Iub3BlcmF0b3JfYWRkcmVzcztcbiAgICAgICAgICAgIGJhbGFuY2Uub3BlcmF0b3JfYWRkcmVzcyA9IHZhbGlkYXRvci5vcGVyYXRvcl9hZGRyZXNzO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBsZXQgcmV3YXJkcyA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgaWYgKHJld2FyZHMuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICBsZXQgY29udGVudCA9IEpTT04ucGFyc2UocmV3YXJkcy5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb250ZW50LnZhbF9jb21taXNzaW9uICYmIGNvbnRlbnQudmFsX2NvbW1pc3Npb24ubGVuZ3RoID4gMClcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhbGFuY2UuY29tbWlzc2lvbiA9IGNvbnRlbnQudmFsX2NvbW1pc3Npb25bMF07XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBiYWxhbmNlO1xuICAgIH0sXG4gICAgJ2FjY291bnRzLmdldERlbGVnYXRpb24nKGFkZHJlc3MsIHZhbGlkYXRvcil7XG4gICAgICAgIGxldCB1cmwgPSBgL3N0YWtpbmcvZGVsZWdhdG9ycy8ke2FkZHJlc3N9L2RlbGVnYXRpb25zLyR7dmFsaWRhdG9yfWA7XG4gICAgICAgIGxldCBkZWxlZ2F0aW9ucyA9IGZldGNoRnJvbVVybCh1cmwpO1xuICAgICAgICBkZWxlZ2F0aW9ucyA9IGRlbGVnYXRpb25zICYmIGRlbGVnYXRpb25zLmRhdGEucmVzdWx0O1xuICAgICAgICBpZiAoZGVsZWdhdGlvbnMgJiYgZGVsZWdhdGlvbnMuc2hhcmVzKVxuICAgICAgICAgICAgZGVsZWdhdGlvbnMuc2hhcmVzID0gcGFyc2VGbG9hdChkZWxlZ2F0aW9ucy5zaGFyZXMpO1xuXG4gICAgICAgIHVybCA9IGAvc3Rha2luZy9yZWRlbGVnYXRpb25zP2RlbGVnYXRvcj0ke2FkZHJlc3N9JnZhbGlkYXRvcl90bz0ke3ZhbGlkYXRvcn1gO1xuICAgICAgICBsZXQgcmVsZWdhdGlvbnMgPSBmZXRjaEZyb21VcmwodXJsKTtcbiAgICAgICAgcmVsZWdhdGlvbnMgPSByZWxlZ2F0aW9ucyAmJiByZWxlZ2F0aW9ucy5kYXRhLnJlc3VsdDtcbiAgICAgICAgbGV0IGNvbXBsZXRpb25UaW1lO1xuICAgICAgICBpZiAocmVsZWdhdGlvbnMpIHtcbiAgICAgICAgICAgIHJlbGVnYXRpb25zLmZvckVhY2goKHJlbGVnYXRpb24pID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgZW50cmllcyA9IHJlbGVnYXRpb24uZW50cmllc1xuICAgICAgICAgICAgICAgIGxldCB0aW1lID0gbmV3IERhdGUoZW50cmllc1tlbnRyaWVzLmxlbmd0aC0xXS5jb21wbGV0aW9uX3RpbWUpXG4gICAgICAgICAgICAgICAgaWYgKCFjb21wbGV0aW9uVGltZSB8fCB0aW1lID4gY29tcGxldGlvblRpbWUpXG4gICAgICAgICAgICAgICAgICAgIGNvbXBsZXRpb25UaW1lID0gdGltZVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIGRlbGVnYXRpb25zLnJlZGVsZWdhdGlvbkNvbXBsZXRpb25UaW1lID0gY29tcGxldGlvblRpbWU7XG4gICAgICAgIH1cblxuICAgICAgICB1cmwgPSBgL3N0YWtpbmcvZGVsZWdhdG9ycy8ke2FkZHJlc3N9L3VuYm9uZGluZ19kZWxlZ2F0aW9ucy8ke3ZhbGlkYXRvcn1gO1xuICAgICAgICBsZXQgdW5kZWxlZ2F0aW9ucyA9IGZldGNoRnJvbVVybCh1cmwpO1xuICAgICAgICB1bmRlbGVnYXRpb25zID0gdW5kZWxlZ2F0aW9ucyAmJiB1bmRlbGVnYXRpb25zLmRhdGEucmVzdWx0O1xuICAgICAgICBpZiAodW5kZWxlZ2F0aW9ucykge1xuICAgICAgICAgICAgZGVsZWdhdGlvbnMudW5ib25kaW5nID0gdW5kZWxlZ2F0aW9ucy5lbnRyaWVzLmxlbmd0aDtcbiAgICAgICAgICAgIGRlbGVnYXRpb25zLnVuYm9uZGluZ0NvbXBsZXRpb25UaW1lID0gdW5kZWxlZ2F0aW9ucy5lbnRyaWVzWzBdLmNvbXBsZXRpb25fdGltZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZGVsZWdhdGlvbnM7XG4gICAgfSxcbiAgICAnYWNjb3VudHMuZ2V0QWxsRGVsZWdhdGlvbnMnKGFkZHJlc3Mpe1xuICAgICAgICBsZXQgdXJsID0gTENEICsgJy9zdGFraW5nL2RlbGVnYXRvcnMvJythZGRyZXNzKycvZGVsZWdhdGlvbnMnO1xuXG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCBkZWxlZ2F0aW9ucyA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBpZiAoZGVsZWdhdGlvbnMuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zID0gSlNPTi5wYXJzZShkZWxlZ2F0aW9ucy5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zICYmIGRlbGVnYXRpb25zLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICBkZWxlZ2F0aW9ucy5mb3JFYWNoKChkZWxlZ2F0aW9uLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZGVsZWdhdGlvbnNbaV0gJiYgZGVsZWdhdGlvbnNbaV0uc2hhcmVzKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zW2ldLnNoYXJlcyA9IHBhcnNlRmxvYXQoZGVsZWdhdGlvbnNbaV0uc2hhcmVzKTtcbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gZGVsZWdhdGlvbnM7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAnYWNjb3VudHMuZ2V0QWxsVW5ib25kaW5ncycoYWRkcmVzcyl7XG4gICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL3N0YWtpbmcvZGVsZWdhdG9ycy8nK2FkZHJlc3MrJy91bmJvbmRpbmdfZGVsZWdhdGlvbnMnO1xuXG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCB1bmJvbmRpbmdzID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmICh1bmJvbmRpbmdzLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICB1bmJvbmRpbmdzID0gSlNPTi5wYXJzZSh1bmJvbmRpbmdzLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICByZXR1cm4gdW5ib25kaW5ncztcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdhY2NvdW50cy5nZXRBbGxSZWRlbGVnYXRpb25zJyhhZGRyZXNzLCB2YWxpZGF0b3Ipe1xuICAgICAgICBsZXQgdXJsID0gYC9zdGFraW5nL3JlZGVsZWdhdGlvbnM/ZGVsZWdhdG9yPSR7YWRkcmVzc30mdmFsaWRhdG9yX2Zyb209JHt2YWxpZGF0b3J9YDtcbiAgICAgICAgbGV0IHJlc3VsdCA9IGZldGNoRnJvbVVybCh1cmwpO1xuICAgICAgICBpZiAocmVzdWx0ICYmIHJlc3VsdC5kYXRhKSB7XG4gICAgICAgICAgICBsZXQgcmVkZWxlZ2F0aW9ucyA9IHt9XG4gICAgICAgICAgICByZXN1bHQuZGF0YS5mb3JFYWNoKChyZWRlbGVnYXRpb24pID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgZW50cmllcyA9IHJlZGVsZWdhdGlvbi5lbnRyaWVzO1xuICAgICAgICAgICAgICAgIHJlZGVsZWdhdGlvbnNbcmVkZWxlZ2F0aW9uLnZhbGlkYXRvcl9kc3RfYWRkcmVzc10gPSB7XG4gICAgICAgICAgICAgICAgICAgIGNvdW50OiBlbnRyaWVzLmxlbmd0aCxcbiAgICAgICAgICAgICAgICAgICAgY29tcGxldGlvblRpbWU6IGVudHJpZXNbMF0uY29tcGxldGlvbl90aW1lXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIHJldHVybiByZWRlbGVnYXRpb25zXG4gICAgICAgIH1cbiAgICB9XG59KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IFByb21pc2UgfSBmcm9tIFwibWV0ZW9yL3Byb21pc2VcIjtcbmltcG9ydCB7IEJsb2Nrc2NvbiB9IGZyb20gJy9pbXBvcnRzL2FwaS9ibG9ja3MvYmxvY2tzLmpzJztcbmltcG9ydCB7IENoYWluIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2NoYWluL2NoYWluLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclNldHMgfSBmcm9tICcvaW1wb3J0cy9hcGkvdmFsaWRhdG9yLXNldHMvdmFsaWRhdG9yLXNldHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9yUmVjb3JkcywgQW5hbHl0aWNzLCBWUERpc3RyaWJ1dGlvbnN9IGZyb20gJy9pbXBvcnRzL2FwaS9yZWNvcmRzL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnL2ltcG9ydHMvYXBpL3ZvdGluZy1wb3dlci9oaXN0b3J5LmpzJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uLy4uL3RyYW5zYWN0aW9ucy90cmFuc2FjdGlvbnMuanMnO1xuaW1wb3J0IHsgRXZpZGVuY2VzIH0gZnJvbSAnLi4vLi4vZXZpZGVuY2VzL2V2aWRlbmNlcy5qcyc7XG5pbXBvcnQgeyBzaGEyNTYgfSBmcm9tICdqcy1zaGEyNTYnO1xuaW1wb3J0IHsgZ2V0QWRkcmVzcyB9IGZyb20gJ3RlbmRlcm1pbnQvbGliL3B1YmtleSc7XG5pbXBvcnQgKiBhcyBjaGVlcmlvIGZyb20gJ2NoZWVyaW8nO1xuXG4vLyBpbXBvcnQgQmxvY2sgZnJvbSAnLi4vLi4vLi4vdWkvY29tcG9uZW50cy9CbG9jayc7XG5cbi8vIGdldFZhbGlkYXRvclZvdGluZ1Bvd2VyID0gKHZhbGlkYXRvcnMsIGFkZHJlc3MpID0+IHtcbi8vICAgICBmb3IgKHYgaW4gdmFsaWRhdG9ycyl7XG4vLyAgICAgICAgIGlmICh2YWxpZGF0b3JzW3ZdLmFkZHJlc3MgPT0gYWRkcmVzcyl7XG4vLyAgICAgICAgICAgICByZXR1cm4gcGFyc2VJbnQodmFsaWRhdG9yc1t2XS52b3RpbmdfcG93ZXIpO1xuLy8gICAgICAgICB9XG4vLyAgICAgfVxuLy8gfVxuXG5nZXRSZW1vdmVkVmFsaWRhdG9ycyA9IChwcmV2VmFsaWRhdG9ycywgdmFsaWRhdG9ycykgPT4ge1xuICAgIC8vIGxldCByZW1vdmVWYWxpZGF0b3JzID0gW107XG4gICAgZm9yIChwIGluIHByZXZWYWxpZGF0b3JzKXtcbiAgICAgICAgZm9yICh2IGluIHZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgaWYgKHByZXZWYWxpZGF0b3JzW3BdLmFkZHJlc3MgPT0gdmFsaWRhdG9yc1t2XS5hZGRyZXNzKXtcbiAgICAgICAgICAgICAgICBwcmV2VmFsaWRhdG9ycy5zcGxpY2UocCwxKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBwcmV2VmFsaWRhdG9ycztcbn1cblxuZ2V0VmFsaWRhdG9yUHJvZmlsZVVybCA9IChpZGVudGl0eSkgPT4ge1xuICAgIGlmIChpZGVudGl0eS5sZW5ndGggPT0gMTYpe1xuICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldChgaHR0cHM6Ly9rZXliYXNlLmlvL18vYXBpLzEuMC91c2VyL2xvb2t1cC5qc29uP2tleV9zdWZmaXg9JHtpZGVudGl0eX0mZmllbGRzPXBpY3R1cmVzYClcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKSB7XG4gICAgICAgICAgICBsZXQgdGhlbSA9IHJlc3BvbnNlLmRhdGEudGhlbVxuICAgICAgICAgICAgcmV0dXJuIHRoZW0gJiYgdGhlbS5sZW5ndGggJiYgdGhlbVswXS5waWN0dXJlcyAmJiB0aGVtWzBdLnBpY3R1cmVzLnByaW1hcnkgJiYgdGhlbVswXS5waWN0dXJlcy5wcmltYXJ5LnVybDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlKSlcbiAgICAgICAgfVxuICAgIH0gZWxzZSBpZiAoaWRlbnRpdHkuaW5kZXhPZihcImtleWJhc2UuaW8vdGVhbS9cIik+MCl7XG4gICAgICAgIGxldCB0ZWFtUGFnZSA9IEhUVFAuZ2V0KGlkZW50aXR5KTtcbiAgICAgICAgaWYgKHRlYW1QYWdlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgIGxldCBwYWdlID0gY2hlZXJpby5sb2FkKHRlYW1QYWdlLmNvbnRlbnQpO1xuICAgICAgICAgICAgcmV0dXJuIHBhZ2UoXCIua2ItbWFpbi1jYXJkIGltZ1wiKS5hdHRyKCdzcmMnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHRlYW1QYWdlKSlcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLy8gdmFyIGZpbHRlcmVkID0gWzEsIDIsIDMsIDQsIDVdLmZpbHRlcihub3RDb250YWluZWRJbihbMSwgMiwgMywgNV0pKTtcbi8vIGNvbnNvbGUubG9nKGZpbHRlcmVkKTsgLy8gWzRdXG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnYmxvY2tzLmF2ZXJhZ2VCbG9ja1RpbWUnKGFkZHJlc3Mpe1xuICAgICAgICBsZXQgYmxvY2tzID0gQmxvY2tzY29uLmZpbmQoe3Byb3Bvc2VyQWRkcmVzczphZGRyZXNzfSkuZmV0Y2goKTtcbiAgICAgICAgbGV0IGhlaWdodHMgPSBibG9ja3MubWFwKChibG9jaywgaSkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIGJsb2NrLmhlaWdodDtcbiAgICAgICAgfSk7XG4gICAgICAgIGxldCBibG9ja3NTdGF0cyA9IEFuYWx5dGljcy5maW5kKHtoZWlnaHQ6eyRpbjpoZWlnaHRzfX0pLmZldGNoKCk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGJsb2Nrc1N0YXRzKTtcblxuICAgICAgICBsZXQgdG90YWxCbG9ja0RpZmYgPSAwO1xuICAgICAgICBmb3IgKGIgaW4gYmxvY2tzU3RhdHMpe1xuICAgICAgICAgICAgdG90YWxCbG9ja0RpZmYgKz0gYmxvY2tzU3RhdHNbYl0udGltZURpZmY7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRvdGFsQmxvY2tEaWZmL2hlaWdodHMubGVuZ3RoO1xuICAgIH0sXG4gICAgJ2Jsb2Nrcy5maW5kVXBUaW1lJyhhZGRyZXNzKXtcbiAgICAgICAgbGV0IGNvbGxlY3Rpb24gPSBWYWxpZGF0b3JSZWNvcmRzLnJhd0NvbGxlY3Rpb24oKTtcbiAgICAgICAgLy8gbGV0IGFnZ3JlZ2F0ZVF1ZXJ5ID0gTWV0ZW9yLndyYXBBc3luYyhjb2xsZWN0aW9uLmFnZ3JlZ2F0ZSwgY29sbGVjdGlvbik7XG4gICAgICAgIHZhciBwaXBlbGluZSA9IFtcbiAgICAgICAgICAgIHskbWF0Y2g6e1wiYWRkcmVzc1wiOmFkZHJlc3N9fSxcbiAgICAgICAgICAgIC8vIHskcHJvamVjdDp7YWRkcmVzczoxLGhlaWdodDoxLGV4aXN0czoxfX0sXG4gICAgICAgICAgICB7JHNvcnQ6e1wiaGVpZ2h0XCI6LTF9fSxcbiAgICAgICAgICAgIHskbGltaXQ6KE1ldGVvci5zZXR0aW5ncy5wdWJsaWMudXB0aW1lV2luZG93LTEpfSxcbiAgICAgICAgICAgIHskdW53aW5kOiBcIiRfaWRcIn0sXG4gICAgICAgICAgICB7JGdyb3VwOntcbiAgICAgICAgICAgICAgICBcIl9pZFwiOiBcIiRhZGRyZXNzXCIsXG4gICAgICAgICAgICAgICAgXCJ1cHRpbWVcIjoge1xuICAgICAgICAgICAgICAgICAgICBcIiRzdW1cIjp7XG4gICAgICAgICAgICAgICAgICAgICAgICAkY29uZDogW3skZXE6IFsnJGV4aXN0cycsIHRydWVdfSwgMSwgMF1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1dO1xuICAgICAgICAvLyBsZXQgcmVzdWx0ID0gYWdncmVnYXRlUXVlcnkocGlwZWxpbmUsIHsgY3Vyc29yOiB7fSB9KTtcblxuICAgICAgICByZXR1cm4gUHJvbWlzZS5hd2FpdChjb2xsZWN0aW9uLmFnZ3JlZ2F0ZShwaXBlbGluZSkudG9BcnJheSgpKTtcbiAgICAgICAgLy8gcmV0dXJuIC5hZ2dyZWdhdGUoKVxuICAgIH0sXG4gICAgJ2Jsb2Nrcy5nZXRMYXRlc3RIZWlnaHQnOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB1cmwgPSBSUEMrJy9zdGF0dXMnO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgbGV0IHN0YXR1cyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICByZXR1cm4gKHN0YXR1cy5yZXN1bHQuc3luY19pbmZvLmxhdGVzdF9ibG9ja19oZWlnaHQpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAnYmxvY2tzLmdldEN1cnJlbnRIZWlnaHQnOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCBjdXJySGVpZ2h0ID0gQmxvY2tzY29uLmZpbmQoe30se3NvcnQ6e2hlaWdodDotMX0sbGltaXQ6MX0pLmZldGNoKCk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiY3VycmVudEhlaWdodDpcIitjdXJySGVpZ2h0KTtcbiAgICAgICAgbGV0IHN0YXJ0SGVpZ2h0ID0gTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGFydEhlaWdodDtcbiAgICAgICAgaWYgKGN1cnJIZWlnaHQgJiYgY3VyckhlaWdodC5sZW5ndGggPT0gMSkge1xuICAgICAgICAgICAgbGV0IGhlaWdodCA9IGN1cnJIZWlnaHRbMF0uaGVpZ2h0O1xuICAgICAgICAgICAgaWYgKGhlaWdodCA+IHN0YXJ0SGVpZ2h0KVxuICAgICAgICAgICAgICAgIHJldHVybiBoZWlnaHRcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc3RhcnRIZWlnaHRcbiAgICB9LFxuICAgICdibG9ja3MuYmxvY2tzVXBkYXRlJzogZnVuY3Rpb24oKSB7XG4gICAgICAgIGlmIChTWU5DSU5HKVxuICAgICAgICAgICAgcmV0dXJuIFwiU3luY2luZy4uLlwiO1xuICAgICAgICBlbHNlIGNvbnNvbGUubG9nKFwic3RhcnQgdG8gc3luY1wiKTtcbiAgICAgICAgLy8gTWV0ZW9yLmNsZWFySW50ZXJ2YWwoTWV0ZW9yLnRpbWVySGFuZGxlKTtcbiAgICAgICAgLy8gZ2V0IHRoZSBsYXRlc3QgaGVpZ2h0XG4gICAgICAgIGxldCB1bnRpbCA9IE1ldGVvci5jYWxsKCdibG9ja3MuZ2V0TGF0ZXN0SGVpZ2h0Jyk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHVudGlsKTtcbiAgICAgICAgLy8gZ2V0IHRoZSBjdXJyZW50IGhlaWdodCBpbiBkYlxuICAgICAgICBsZXQgY3VyciA9IE1ldGVvci5jYWxsKCdibG9ja3MuZ2V0Q3VycmVudEhlaWdodCcpO1xuICAgICAgICBjb25zb2xlLmxvZyhjdXJyKTtcbiAgICAgICAgLy8gbG9vcCBpZiB0aGVyZSdzIHVwZGF0ZSBpbiBkYlxuICAgICAgICBpZiAodW50aWwgPiBjdXJyKSB7XG4gICAgICAgICAgICBTWU5DSU5HID0gdHJ1ZTtcblxuICAgICAgICAgICAgbGV0IHZhbGlkYXRvclNldCA9IHt9XG4gICAgICAgICAgICAvLyBnZXQgbGF0ZXN0IHZhbGlkYXRvciBjYW5kaWRhdGUgaW5mb3JtYXRpb25cbiAgICAgICAgICAgIHVybCA9IExDRCsnL3N0YWtpbmcvdmFsaWRhdG9ycyc7XG5cbiAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQuZm9yRWFjaCgodmFsaWRhdG9yKSA9PiB2YWxpZGF0b3JTZXRbdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXldID0gdmFsaWRhdG9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB1cmwgPSBMQ0QrJy9zdGFraW5nL3ZhbGlkYXRvcnM/c3RhdHVzPXVuYm9uZGluZyc7XG5cbiAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQuZm9yRWFjaCgodmFsaWRhdG9yKSA9PiB2YWxpZGF0b3JTZXRbdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXldID0gdmFsaWRhdG9yKVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHVybCA9IExDRCsnL3N0YWtpbmcvdmFsaWRhdG9ycz9zdGF0dXM9dW5ib25kZWQnO1xuXG4gICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgIEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0LmZvckVhY2goKHZhbGlkYXRvcikgPT4gdmFsaWRhdG9yU2V0W3ZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5XSA9IHZhbGlkYXRvcilcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IHRvdGFsVmFsaWRhdG9ycyA9IE9iamVjdC5rZXlzKHZhbGlkYXRvclNldCkubGVuZ3RoO1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhbGwgdmFsaWRhdG9yczogXCIrIHRvdGFsVmFsaWRhdG9ycyk7XG4gICAgICAgICAgICBmb3IgKGxldCBoZWlnaHQgPSBjdXJyKzEgOyBoZWlnaHQgPD0gdW50aWwgOyBoZWlnaHQrKykge1xuICAgICAgICAgICAgICAgIGxldCBzdGFydEJsb2NrVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgLy8gYWRkIHRpbWVvdXQgaGVyZT8gYW5kIG91dHNpZGUgdGhpcyBsb29wIChmb3IgY2F0Y2hlZCB1cCBhbmQga2VlcCBmZXRjaGluZyk/XG4gICAgICAgICAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgICAgICAgICAgbGV0IHVybCA9IFJQQysnL2Jsb2NrP2hlaWdodD0nICsgaGVpZ2h0O1xuICAgICAgICAgICAgICAgIGxldCBhbmFseXRpY3NEYXRhID0ge307XG5cbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYnVsa1ZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLnJhd0NvbGxlY3Rpb24oKS5pbml0aWFsaXplVW5vcmRlcmVkQnVsa09wKCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtWYWxpZGF0b3JSZWNvcmRzID0gVmFsaWRhdG9yUmVjb3Jkcy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBidWxrVlBIaXN0b3J5ID0gVm90aW5nUG93ZXJIaXN0b3J5LnJhd0NvbGxlY3Rpb24oKS5pbml0aWFsaXplVW5vcmRlcmVkQnVsa09wKCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtUcmFuc2F0aW9ucyA9IFRyYW5zYWN0aW9ucy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuXG4gICAgICAgICAgICAgICAgICAgIGxldCBzdGFydEdldEhlaWdodFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJsb2NrID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrID0gYmxvY2sucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gc3RvcmUgaGVpZ2h0LCBoYXNoLCBudW10cmFuc2FjdGlvbiBhbmQgdGltZSBpbiBkYlxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJsb2NrRGF0YSA9IHt9O1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLmhlaWdodCA9IGhlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS5oYXNoID0gYmxvY2suYmxvY2tfbWV0YS5ibG9ja19pZC5oYXNoO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLnRyYW5zTnVtID0gYmxvY2suYmxvY2tfbWV0YS5oZWFkZXIubnVtX3R4cztcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS50aW1lID0gbmV3IERhdGUoYmxvY2suYmxvY2suaGVhZGVyLnRpbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLmxhc3RCbG9ja0hhc2ggPSBibG9jay5ibG9jay5oZWFkZXIubGFzdF9ibG9ja19pZC5oYXNoO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLnByb3Bvc2VyQWRkcmVzcyA9IGJsb2NrLmJsb2NrLmhlYWRlci5wcm9wb3Nlcl9hZGRyZXNzO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLnZhbGlkYXRvcnMgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwcmVjb21taXRzID0gYmxvY2suYmxvY2subGFzdF9jb21taXQucHJlY29tbWl0cztcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmVjb21taXRzICE9IG51bGwpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHByZWNvbW1pdHMubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpPTA7IGk8cHJlY29tbWl0cy5sZW5ndGg7IGkrKyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmVjb21taXRzW2ldICE9IG51bGwpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLnZhbGlkYXRvcnMucHVzaChwcmVjb21taXRzW2ldLnZhbGlkYXRvcl9hZGRyZXNzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuYWx5dGljc0RhdGEucHJlY29tbWl0cyA9IHByZWNvbW1pdHMubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHJlY29yZCBmb3IgYW5hbHl0aWNzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUHJlY29tbWl0UmVjb3Jkcy5pbnNlcnQoe2hlaWdodDpoZWlnaHQsIHByZWNvbW1pdHM6cHJlY29tbWl0cy5sZW5ndGh9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gc2F2ZSB0eHMgaW4gZGF0YWJhc2VcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChibG9jay5ibG9jay5kYXRhLnR4cyAmJiBibG9jay5ibG9jay5kYXRhLnR4cy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHQgaW4gYmxvY2suYmxvY2suZGF0YS50eHMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBNZXRlb3IuY2FsbCgnVHJhbnNhY3Rpb25zLmluZGV4Jywgc2hhMjU2KEJ1ZmZlci5mcm9tKGJsb2NrLmJsb2NrLmRhdGEudHhzW3RdLCAnYmFzZTY0JykpLCBibG9ja0RhdGEudGltZSwgKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHNhdmUgZG91YmxlIHNpZ24gZXZpZGVuY2VzXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYmxvY2suYmxvY2suZXZpZGVuY2UuZXZpZGVuY2Upe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEV2aWRlbmNlcy5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXZpZGVuY2U6IGJsb2NrLmJsb2NrLmV2aWRlbmNlLmV2aWRlbmNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS5wcmVjb21taXRzQ291bnQgPSBibG9ja0RhdGEudmFsaWRhdG9ycy5sZW5ndGg7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGFuYWx5dGljc0RhdGEuaGVpZ2h0ID0gaGVpZ2h0O1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZW5kR2V0SGVpZ2h0VGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkdldCBoZWlnaHQgdGltZTogXCIrKChlbmRHZXRIZWlnaHRUaW1lLXN0YXJ0R2V0SGVpZ2h0VGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcblxuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRHZXRWYWxpZGF0b3JzVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB1cGRhdGUgY2hhaW4gc3RhdHVzXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmwgPSBSUEMrJy92YWxpZGF0b3JzP2hlaWdodD0nK2hlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9ycyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JzLnJlc3VsdC5ibG9ja19oZWlnaHQgPSBwYXJzZUludCh2YWxpZGF0b3JzLnJlc3VsdC5ibG9ja19oZWlnaHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgVmFsaWRhdG9yU2V0cy5pbnNlcnQodmFsaWRhdG9ycy5yZXN1bHQpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEudmFsaWRhdG9yc0NvdW50ID0gdmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9ycy5sZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRCbG9ja0luc2VydFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgQmxvY2tzY29uLmluc2VydChibG9ja0RhdGEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGVuZEJsb2NrSW5zZXJ0VGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkJsb2NrIGluc2VydCB0aW1lOiBcIisoKGVuZEJsb2NrSW5zZXJ0VGltZS1zdGFydEJsb2NrSW5zZXJ0VGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gc3RvcmUgdmFsZGlhdG9ycyBleGlzdCByZWNvcmRzXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZXhpc3RpbmdWYWxpZGF0b3JzID0gVmFsaWRhdG9ycy5maW5kKHthZGRyZXNzOnskZXhpc3RzOnRydWV9fSkuZmV0Y2goKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGhlaWdodCA+IDEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHJlY29yZCBwcmVjb21taXRzIGFuZCBjYWxjdWxhdGUgdXB0aW1lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gb25seSByZWNvcmQgZnJvbSBibG9jayAyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChpIGluIHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgYWRkcmVzcyA9IHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnNbaV0uYWRkcmVzcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlY29yZCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0czogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IHBhcnNlSW50KHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnNbaV0udm90aW5nX3Bvd2VyKS8vZ2V0VmFsaWRhdG9yVm90aW5nUG93ZXIoZXhpc3RpbmdWYWxpZGF0b3JzLCBhZGRyZXNzKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChqIGluIHByZWNvbW1pdHMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByZWNvbW1pdHNbal0gIT0gbnVsbCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGFkZHJlc3MgPT0gcHJlY29tbWl0c1tqXS52YWxpZGF0b3JfYWRkcmVzcyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlY29yZC5leGlzdHMgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmVjb21taXRzLnNwbGljZShqLDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjYWxjdWxhdGUgdGhlIHVwdGltZSBiYXNlZCBvbiB0aGUgcmVjb3JkcyBzdG9yZWQgaW4gcHJldmlvdXMgYmxvY2tzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIG9ubHkgZG8gdGhpcyBldmVyeSAxNSBibG9ja3MgflxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICgoaGVpZ2h0ICUgMTUpID09IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGV0IHN0YXJ0QWdnVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgbnVtQmxvY2tzID0gTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5maW5kVXBUaW1lJywgYWRkcmVzcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdXB0aW1lID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGxldCBlbmRBZ2dUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwiR2V0IGFnZ3JlZ2F0ZWQgdXB0aW1lIGZvciBcIitleGlzdGluZ1ZhbGlkYXRvcnNbaV0uYWRkcmVzcytcIjogXCIrKChlbmRBZ2dUaW1lLXN0YXJ0QWdnVGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICgobnVtQmxvY2tzWzBdICE9IG51bGwpICYmIChudW1CbG9ja3NbMF0udXB0aW1lICE9IG51bGwpKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cHRpbWUgPSBudW1CbG9ja3NbMF0udXB0aW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgYmFzZSA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMudXB0aW1lV2luZG93O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGhlaWdodCA8IGJhc2Upe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhc2UgPSBoZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZWNvcmQuZXhpc3RzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodXB0aW1lIDwgYmFzZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwdGltZSsrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cHRpbWUgPSAodXB0aW1lIC8gYmFzZSkqMTAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JzLmZpbmQoe2FkZHJlc3M6YWRkcmVzc30pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDp7dXB0aW1lOnVwdGltZSwgbGFzdFNlZW46YmxvY2tEYXRhLnRpbWV9fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNle1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwdGltZSA9ICh1cHRpbWUgLyBiYXNlKSoxMDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7YWRkcmVzczphZGRyZXNzfSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0Ont1cHRpbWU6dXB0aW1lfX0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvclJlY29yZHMuaW5zZXJ0KHJlY29yZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFZhbGlkYXRvclJlY29yZHMudXBkYXRlKHtoZWlnaHQ6aGVpZ2h0LGFkZHJlc3M6cmVjb3JkLmFkZHJlc3N9LHJlY29yZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY2hhaW5TdGF0dXMgPSBDaGFpbi5maW5kT25lKHtjaGFpbklkOmJsb2NrLmJsb2NrX21ldGEuaGVhZGVyLmNoYWluX2lkfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgbGFzdFN5bmNlZFRpbWUgPSBjaGFpblN0YXR1cz9jaGFpblN0YXR1cy5sYXN0U3luY2VkVGltZTowO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHRpbWVEaWZmO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJsb2NrVGltZSA9IE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuZGVmYXVsdEJsb2NrVGltZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChsYXN0U3luY2VkVGltZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGVMYXRlc3QgPSBibG9ja0RhdGEudGltZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgZGF0ZUxhc3QgPSBuZXcgRGF0ZShsYXN0U3luY2VkVGltZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZURpZmYgPSBNYXRoLmFicyhkYXRlTGF0ZXN0LmdldFRpbWUoKSAtIGRhdGVMYXN0LmdldFRpbWUoKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tUaW1lID0gKGNoYWluU3RhdHVzLmJsb2NrVGltZSAqIChibG9ja0RhdGEuaGVpZ2h0IC0gMSkgKyB0aW1lRGlmZikgLyBibG9ja0RhdGEuaGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZW5kR2V0VmFsaWRhdG9yc1RpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJHZXQgaGVpZ2h0IHZhbGlkYXRvcnMgdGltZTogXCIrKChlbmRHZXRWYWxpZGF0b3JzVGltZS1zdGFydEdldFZhbGlkYXRvcnNUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6YmxvY2suYmxvY2tfbWV0YS5oZWFkZXIuY2hhaW5faWR9LCB7JHNldDp7bGFzdFN5bmNlZFRpbWU6YmxvY2tEYXRhLnRpbWUsIGJsb2NrVGltZTpibG9ja1RpbWV9fSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGFuYWx5dGljc0RhdGEuYXZlcmFnZUJsb2NrVGltZSA9IGJsb2NrVGltZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFuYWx5dGljc0RhdGEudGltZURpZmYgPSB0aW1lRGlmZjtcblxuICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS50aW1lID0gYmxvY2tEYXRhLnRpbWU7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGluaXRpYWxpemUgdmFsaWRhdG9yIGRhdGEgYXQgZmlyc3QgYmxvY2tcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGlmIChoZWlnaHQgPT0gMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgVmFsaWRhdG9ycy5yZW1vdmUoe30pO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLnZvdGluZ19wb3dlciA9IDA7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzdGFydEZpbmRWYWxpZGF0b3JzTmFtZVRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvcnMucmVzdWx0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3JzIGFyZSBhbGwgdGhlIHZhbGlkYXRvcnMgaW4gdGhlIGN1cnJlbnQgaGVpZ2h0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJ2YWxpZGF0b3JTZXQgc2l6ZTogXCIrdmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9ycy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodiBpbiB2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gVmFsaWRhdG9ycy5pbnNlcnQodmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9yc1t2XSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3IgPSB2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzW3ZdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyID0gcGFyc2VJbnQodmFsaWRhdG9yLnZvdGluZ19wb3dlcik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5wcm9wb3Nlcl9wcmlvcml0eSA9IHBhcnNlSW50KHZhbGlkYXRvci5wcm9wb3Nlcl9wcmlvcml0eSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbEV4aXN0ID0gVmFsaWRhdG9ycy5maW5kT25lKHtcInB1Yl9rZXkudmFsdWVcIjp2YWxpZGF0b3IucHViX2tleS52YWx1ZX0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXZhbEV4aXN0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGB2YWxpZGF0b3IgcHViX2tleSAke3ZhbGlkYXRvci5hZGRyZXNzfSAke3ZhbGlkYXRvci5wdWJfa2V5LnZhbHVlfSBub3QgaW4gZGJgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGxldCBjb21tYW5kID0gTWV0ZW9yLnNldHRpbmdzLmJpbi5nYWlhZGVidWcrXCIgcHVia2V5IFwiK3ZhbGlkYXRvci5wdWJfa2V5LnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coY29tbWFuZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBsZXQgdGVtcFZhbCA9IHZhbGlkYXRvcjtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFkZHJlc3MgPSBnZXRBZGRyZXNzKHZhbGlkYXRvci5wdWJfa2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5hY2NwdWIgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3IucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhBY2NQdWIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLm9wZXJhdG9yX3B1YmtleSA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbGlkYXRvci5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeFZhbFB1Yik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleSA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbGlkYXRvci5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeENvbnNQdWIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yRGF0YSA9IHZhbGlkYXRvclNldFt2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JEYXRhKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yRGF0YS5kZXNjcmlwdGlvbi5pZGVudGl0eSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnByb2ZpbGVfdXJsID0gIGdldFZhbGlkYXRvclByb2ZpbGVVcmwodmFsaWRhdG9yRGF0YS5kZXNjcmlwdGlvbi5pZGVudGl0eSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iub3BlcmF0b3JfYWRkcmVzcyA9IHZhbGlkYXRvckRhdGEub3BlcmF0b3JfYWRkcmVzcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuZGVsZWdhdG9yX2FkZHJlc3MgPSBNZXRlb3IuY2FsbCgnZ2V0RGVsZWdhdG9yJywgdmFsaWRhdG9yRGF0YS5vcGVyYXRvcl9hZGRyZXNzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuamFpbGVkID0gdmFsaWRhdG9yRGF0YS5qYWlsZWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnN0YXR1cyA9IHZhbGlkYXRvckRhdGEuc3RhdHVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5taW5fc2VsZl9kZWxlZ2F0aW9uID0gdmFsaWRhdG9yRGF0YS5taW5fc2VsZl9kZWxlZ2F0aW9uO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci50b2tlbnMgPSB2YWxpZGF0b3JEYXRhLnRva2VucztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuZGVsZWdhdG9yX3NoYXJlcyA9IHZhbGlkYXRvckRhdGEuZGVsZWdhdG9yX3NoYXJlcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuZGVzY3JpcHRpb24gPSB2YWxpZGF0b3JEYXRhLmRlc2NyaXB0aW9uO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5ib25kX2hlaWdodCA9IHZhbGlkYXRvckRhdGEuYm9uZF9oZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmJvbmRfaW50cmFfdHhfY291bnRlciA9IHZhbGlkYXRvckRhdGEuYm9uZF9pbnRyYV90eF9jb3VudGVyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci51bmJvbmRpbmdfaGVpZ2h0ID0gdmFsaWRhdG9yRGF0YS51bmJvbmRpbmdfaGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci51bmJvbmRpbmdfdGltZSA9IHZhbGlkYXRvckRhdGEudW5ib25kaW5nX3RpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmNvbW1pc3Npb24gPSB2YWxpZGF0b3JEYXRhLmNvbW1pc3Npb247XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnNlbGZfZGVsZWdhdGlvbiA9IHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5yZW1vdmVkID0gZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLnJlbW92ZWRBdCA9IDBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3JTZXQuc3BsaWNlKHZhbCwgMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdubyBjb24gcHViIGtleT8nKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBidWxrVmFsaWRhdG9ycy5pbnNlcnQodmFsaWRhdG9yKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JzLmZpbmQoe2NvbnNlbnN1c19wdWJrZXk6IHZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5fSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OnZhbGlkYXRvcn0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCJ2YWxpZGF0b3IgZmlyc3QgYXBwZWFyczogXCIrYnVsa1ZhbGlkYXRvcnMubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWUEhpc3RvcnkuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOiB2YWxpZGF0b3IuYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmV2X3ZvdGluZ19wb3dlcjogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IHZhbGlkYXRvci52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2FkZCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBibG9ja0RhdGEuaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrX3RpbWU6IGJsb2NrRGF0YS50aW1lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gTWV0ZW9yLmNhbGwoJ3J1bkNvZGUnLCBjb21tYW5kLCBmdW5jdGlvbihlcnJvciwgcmVzdWx0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5hZGRyZXNzID0gcmVzdWx0Lm1hdGNoKC9cXHNbMC05QS1GXXs0MH0kL2lnbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuYWRkcmVzcyA9IHZhbGlkYXRvci5hZGRyZXNzWzBdLnRyaW0oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5oZXggPSByZXN1bHQubWF0Y2goL1xcc1swLTlBLUZdezY0fSQvaWdtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5oZXggPSB2YWxpZGF0b3IuaGV4WzBdLnRyaW0oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5jb3Ntb3NhY2NwdWIgPSByZXN1bHQubWF0Y2goL2Nvc21vc3B1Yi4qJC9pZ20pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmNvc21vc2FjY3B1YiA9IHZhbGlkYXRvci5jb3Ntb3NhY2NwdWJbMF0udHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLm9wZXJhdG9yX3B1YmtleSA9IHJlc3VsdC5tYXRjaCgvY29zbW9zdmFsb3BlcnB1Yi4qJC9pZ20pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLm9wZXJhdG9yX3B1YmtleSA9IHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXlbMF0udHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXkgPSByZXN1bHQubWF0Y2goL2Nvc21vc3ZhbGNvbnNwdWIuKiQvaWdtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5ID0gdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXlbMF0udHJpbSgpO1xuXG5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3JEYXRhID0gdmFsaWRhdG9yU2V0W3ZhbEV4aXN0LmNvbnNlbnN1c19wdWJrZXldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yRGF0YSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvckRhdGEuZGVzY3JpcHRpb24gJiYgKCF2YWxFeGlzdC5kZXNjcmlwdGlvbiB8fCB2YWxpZGF0b3JEYXRhLmRlc2NyaXB0aW9uLmlkZW50aXR5ICE9PSB2YWxFeGlzdC5kZXNjcmlwdGlvbi5pZGVudGl0eSkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5wcm9maWxlX3VybCA9ICBnZXRWYWxpZGF0b3JQcm9maWxlVXJsKHZhbGlkYXRvckRhdGEuZGVzY3JpcHRpb24uaWRlbnRpdHkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmphaWxlZCA9IHZhbGlkYXRvckRhdGEuamFpbGVkO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5zdGF0dXMgPSB2YWxpZGF0b3JEYXRhLnN0YXR1cztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IudG9rZW5zID0gdmFsaWRhdG9yRGF0YS50b2tlbnM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmRlbGVnYXRvcl9zaGFyZXMgPSB2YWxpZGF0b3JEYXRhLmRlbGVnYXRvcl9zaGFyZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmRlc2NyaXB0aW9uID0gdmFsaWRhdG9yRGF0YS5kZXNjcmlwdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYm9uZF9oZWlnaHQgPSB2YWxpZGF0b3JEYXRhLmJvbmRfaGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5ib25kX2ludHJhX3R4X2NvdW50ZXIgPSB2YWxpZGF0b3JEYXRhLmJvbmRfaW50cmFfdHhfY291bnRlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IudW5ib25kaW5nX2hlaWdodCA9IHZhbGlkYXRvckRhdGEudW5ib25kaW5nX2hlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IudW5ib25kaW5nX3RpbWUgPSB2YWxpZGF0b3JEYXRhLnVuYm9uZGluZ190aW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5jb21taXNzaW9uID0gdmFsaWRhdG9yRGF0YS5jb21taXNzaW9uO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2FsY3VsYXRlIHNlbGYgZGVsZWdhdGlvbiBwZXJjZW50YWdlIGV2ZXJ5IDMwIGJsb2Nrc1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGhlaWdodCAlIDMwID09IDEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldChMQ0QgKyAnL3N0YWtpbmcvZGVsZWdhdG9ycy8nK3ZhbEV4aXN0LmRlbGVnYXRvcl9hZGRyZXNzKycvZGVsZWdhdGlvbnMvJyt2YWxFeGlzdC5vcGVyYXRvcl9hZGRyZXNzKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgc2VsZkRlbGVnYXRpb24gPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc2VsZkRlbGVnYXRpb24uc2hhcmVzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnNlbGZfZGVsZWdhdGlvbiA9IHBhcnNlRmxvYXQoc2VsZkRlbGVnYXRpb24uc2hhcmVzKS9wYXJzZUZsb2F0KHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JzLmZpbmQoe2NvbnNlbnN1c19wdWJrZXk6IHZhbEV4aXN0LmNvbnNlbnN1c19wdWJrZXl9KS51cGRhdGVPbmUoeyRzZXQ6dmFsaWRhdG9yfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCJ2YWxpZGF0b3IgZXhpc2l0czogXCIrYnVsa1ZhbGlkYXRvcnMubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3JTZXQuc3BsaWNlKHZhbCwgMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9ICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnbm8gY29uIHB1YiBrZXk/JylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwcmV2Vm90aW5nUG93ZXIgPSBWb3RpbmdQb3dlckhpc3RvcnkuZmluZE9uZSh7YWRkcmVzczp2YWxpZGF0b3IuYWRkcmVzc30sIHtoZWlnaHQ6LTEsIGxpbWl0OjF9KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByZXZWb3RpbmdQb3dlcil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByZXZWb3RpbmdQb3dlci52b3RpbmdfcG93ZXIgIT0gdmFsaWRhdG9yLnZvdGluZ19wb3dlcil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjaGFuZ2VUeXBlID0gKHByZXZWb3RpbmdQb3dlci52b3RpbmdfcG93ZXIgPiB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyKT8nZG93bic6J3VwJztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNoYW5nZURhdGEgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOiB2YWxpZGF0b3IuYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZXZfdm90aW5nX3Bvd2VyOiBwcmV2Vm90aW5nUG93ZXIudm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogY2hhbmdlVHlwZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogYmxvY2tEYXRhLmhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrX3RpbWU6IGJsb2NrRGF0YS50aW1lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCd2b3RpbmcgcG93ZXIgY2hhbmdlZC4nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coY2hhbmdlRGF0YSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWUEhpc3RvcnkuaW5zZXJ0KGNoYW5nZURhdGEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyh2YWxpZGF0b3IpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuYWx5dGljc0RhdGEudm90aW5nX3Bvd2VyICs9IHZhbGlkYXRvci52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaWYgdGhlcmUgaXMgdmFsaWRhdG9yIHJlbW92ZWRcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwcmV2VmFsaWRhdG9ycyA9IFZhbGlkYXRvclNldHMuZmluZE9uZSh7YmxvY2tfaGVpZ2h0OmhlaWdodC0xfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJldlZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVtb3ZlZFZhbGlkYXRvcnMgPSBnZXRSZW1vdmVkVmFsaWRhdG9ycyhwcmV2VmFsaWRhdG9ycy52YWxpZGF0b3JzLCB2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHIgaW4gcmVtb3ZlZFZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZQSGlzdG9yeS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IHJlbW92ZWRWYWxpZGF0b3JzW3JdLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IHJlbW92ZWRWYWxpZGF0b3JzW3JdLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3JlbW92ZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBibG9ja0RhdGEuaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrX3RpbWU6IGJsb2NrRGF0YS50aW1lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNoZWNrIGlmIHRoZXJlJ3MgYW55IHZhbGlkYXRvciBub3QgaW4gZGIgMTQ0MDAgYmxvY2tzKH4xIGRheSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChoZWlnaHQgJSAxNDQwMCA9PSAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnQ2hlY2tpbmcgYWxsIHZhbGlkYXRvcnMgYWdhaW5zdCBkYi4uLicpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBkYlZhbGlkYXRvcnMgPSB7fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBWYWxpZGF0b3JzLmZpbmQoe30sIHtmaWVsZHM6IHtjb25zZW5zdXNfcHVia2V5OiAxLCBzdGF0dXM6IDF9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS5mb3JFYWNoKCh2KSA9PiBkYlZhbGlkYXRvcnNbdi5jb25zZW5zdXNfcHVia2V5XSA9IHYuc3RhdHVzKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPYmplY3Qua2V5cyh2YWxpZGF0b3JTZXQpLmZvckVhY2goKGNvblB1YktleSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvckRhdGEgPSB2YWxpZGF0b3JTZXRbY29uUHViS2V5XTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEFjdGl2ZSB2YWxpZGF0b3JzIHNob3VsZCBoYXZlIGJlZW4gdXBkYXRlZCBpbiBwcmV2aW91cyBzdGVwc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvckRhdGEuc3RhdHVzID09PSAyKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVyblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZGJWYWxpZGF0b3JzW2NvblB1YktleV0gPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coYHZhbGlkYXRvciB3aXRoIGNvbnNlbnN1c19wdWJrZXkgJHtjb25QdWJLZXl9IG5vdCBpbiBkYmApO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yRGF0YS5wdWJfa2V5ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInR5cGVcIiA6IFwidGVuZGVybWludC9QdWJLZXlFZDI1NTE5XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwidmFsdWVcIjogTWV0ZW9yLmNhbGwoJ2JlY2gzMlRvUHVia2V5JywgY29uUHViS2V5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JEYXRhLmFkZHJlc3MgPSBnZXRBZGRyZXNzKHZhbGlkYXRvckRhdGEucHViX2tleSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yRGF0YS5kZWxlZ2F0b3JfYWRkcmVzcyA9IE1ldGVvci5jYWxsKCdnZXREZWxlZ2F0b3InLCB2YWxpZGF0b3JEYXRhLm9wZXJhdG9yX2FkZHJlc3MpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yRGF0YS5hY2NwdWIgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3JEYXRhLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4QWNjUHViKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JEYXRhLm9wZXJhdG9yX3B1YmtleSA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbGlkYXRvckRhdGEucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhWYWxQdWIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHZhbGlkYXRvckRhdGEpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JzLmZpbmQoe2NvbnNlbnN1c19wdWJrZXk6IGNvblB1YktleX0pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDp2YWxpZGF0b3JEYXRhfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGRiVmFsaWRhdG9yc1tjb25QdWJLZXldID09IDIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHtjb25zZW5zdXNfcHVia2V5OiBjb25QdWJLZXl9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6dmFsaWRhdG9yRGF0YX0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZmV0Y2hpbmcga2V5YmFzZSBldmVyeSAxNDQwMCBibG9ja3MofjEgZGF5KVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGhlaWdodCAlIDE0NDAwID09IDEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdGZXRjaGluZyBrZXliYXNlLi4uJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBWYWxpZGF0b3JzLmZpbmQoe30pLmZvckVhY2goKHZhbGlkYXRvcikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByb2ZpbGVVcmwgPSAgZ2V0VmFsaWRhdG9yUHJvZmlsZVVybCh2YWxpZGF0b3IuZGVzY3JpcHRpb24uaWRlbnRpdHkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJvZmlsZVVybCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JzLmZpbmQoe2FkZHJlc3M6IHZhbGlkYXRvci5hZGRyZXNzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDp7J3Byb2ZpbGVfdXJsJzpwcm9maWxlVXJsfX0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGVuZEZpbmRWYWxpZGF0b3JzTmFtZVRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJHZXQgdmFsaWRhdG9ycyBuYW1lIHRpbWU6IFwiKygoZW5kRmluZFZhbGlkYXRvcnNOYW1lVGltZS1zdGFydEZpbmRWYWxpZGF0b3JzTmFtZVRpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHJlY29yZCBmb3IgYW5hbHl0aWNzXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRBbmF5dGljc0luc2VydFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgQW5hbHl0aWNzLmluc2VydChhbmFseXRpY3NEYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlbmRBbmFseXRpY3NJbnNlcnRUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQW5hbHl0aWNzIGluc2VydCB0aW1lOiBcIisoKGVuZEFuYWx5dGljc0luc2VydFRpbWUtc3RhcnRBbmF5dGljc0luc2VydFRpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzdGFydFZVcFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGJ1bGtWYWxpZGF0b3JzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGJ1bGtWYWxpZGF0b3JzLmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZXhlY3V0ZSgoZXJyLCByZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2cocmVzdWx0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZW5kVlVwVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlZhbGlkYXRvciB1cGRhdGUgdGltZTogXCIrKChlbmRWVXBUaW1lLXN0YXJ0VlVwVGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0VlJUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChidWxrVmFsaWRhdG9yUmVjb3Jkcy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9yUmVjb3Jkcy5leGVjdXRlKChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGVuZFZSVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlZhbGlkYXRvciByZWNvcmRzIHVwZGF0ZSB0aW1lOiBcIisoKGVuZFZSVGltZS1zdGFydFZSVGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGJ1bGtWUEhpc3RvcnkubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZQSGlzdG9yeS5leGVjdXRlKChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGJ1bGtUcmFuc2F0aW9ucy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVHJhbnNhdGlvbnMuZXhlY3V0ZSgoZXJyLCByZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNhbGN1bGF0ZSB2b3RpbmcgcG93ZXIgZGlzdHJpYnV0aW9uIGV2ZXJ5IDYwIGJsb2NrcyB+IDVtaW5zXG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChoZWlnaHQgJSA2MCA9PSAxKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIj09PT09IGNhbGN1bGF0ZSB2b3RpbmcgcG93ZXIgZGlzdHJpYnV0aW9uID09PT09XCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBhY3RpdmVWYWxpZGF0b3JzID0gVmFsaWRhdG9ycy5maW5kKHtzdGF0dXM6MixqYWlsZWQ6ZmFsc2V9LHtzb3J0Ont2b3RpbmdfcG93ZXI6LTF9fSkuZmV0Y2goKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgbnVtVG9wVHdlbnR5ID0gTWF0aC5jZWlsKGFjdGl2ZVZhbGlkYXRvcnMubGVuZ3RoKjAuMik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG51bUJvdHRvbUVpZ2h0eSA9IGFjdGl2ZVZhbGlkYXRvcnMubGVuZ3RoIC0gbnVtVG9wVHdlbnR5O1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHRvcFR3ZW50eVBvd2VyID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgYm90dG9tRWlnaHR5UG93ZXIgPSAwO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG51bVRvcFRoaXJ0eUZvdXIgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBudW1Cb3R0b21TaXh0eVNpeCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHRvcFRoaXJ0eUZvdXJQZXJjZW50ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgYm90dG9tU2l4dHlTaXhQZXJjZW50ID0gMDtcblxuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHYgaW4gYWN0aXZlVmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2IDwgbnVtVG9wVHdlbnR5KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvcFR3ZW50eVBvd2VyICs9IGFjdGl2ZVZhbGlkYXRvcnNbdl0udm90aW5nX3Bvd2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3R0b21FaWdodHlQb3dlciArPSBhY3RpdmVWYWxpZGF0b3JzW3ZdLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRvcFRoaXJ0eUZvdXJQZXJjZW50IDwgMC4zNCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3BUaGlydHlGb3VyUGVyY2VudCArPSBhY3RpdmVWYWxpZGF0b3JzW3ZdLnZvdGluZ19wb3dlciAvIGFuYWx5dGljc0RhdGEudm90aW5nX3Bvd2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVtVG9wVGhpcnR5Rm91cisrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm90dG9tU2l4dHlTaXhQZXJjZW50ID0gMSAtIHRvcFRoaXJ0eUZvdXJQZXJjZW50O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bUJvdHRvbVNpeHR5U2l4ID0gYWN0aXZlVmFsaWRhdG9ycy5sZW5ndGggLSBudW1Ub3BUaGlydHlGb3VyO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZwRGlzdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBoZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bVRvcFR3ZW50eTogbnVtVG9wVHdlbnR5LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3BUd2VudHlQb3dlcjogdG9wVHdlbnR5UG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bUJvdHRvbUVpZ2h0eTogbnVtQm90dG9tRWlnaHR5LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3R0b21FaWdodHlQb3dlcjogYm90dG9tRWlnaHR5UG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bVRvcFRoaXJ0eUZvdXI6IG51bVRvcFRoaXJ0eUZvdXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvcFRoaXJ0eUZvdXJQZXJjZW50OiB0b3BUaGlydHlGb3VyUGVyY2VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVtQm90dG9tU2l4dHlTaXg6IG51bUJvdHRvbVNpeHR5U2l4LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3R0b21TaXh0eVNpeFBlcmNlbnQ6IGJvdHRvbVNpeHR5U2l4UGVyY2VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVtVmFsaWRhdG9yczogYWN0aXZlVmFsaWRhdG9ycy5sZW5ndGgsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsVm90aW5nUG93ZXI6IGFuYWx5dGljc0RhdGEudm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja1RpbWU6IGJsb2NrRGF0YS50aW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjcmVhdGVBdDogbmV3IERhdGUoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHZwRGlzdCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBWUERpc3RyaWJ1dGlvbnMuaW5zZXJ0KHZwRGlzdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgICAgICAgICAgU1lOQ0lORyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJTdG9wcGVkXCI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGxldCBlbmRCbG9ja1RpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiVGhpcyBibG9jayB1c2VkOiBcIisoKGVuZEJsb2NrVGltZS1zdGFydEJsb2NrVGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFNZTkNJTkcgPSBmYWxzZTtcbiAgICAgICAgICAgIENoYWluLnVwZGF0ZSh7Y2hhaW5JZDpNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LCB7JHNldDp7bGFzdEJsb2Nrc1N5bmNlZFRpbWU6bmV3IERhdGUoKSwgdG90YWxWYWxpZGF0b3JzOnRvdGFsVmFsaWRhdG9yc319KTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB1bnRpbDtcbiAgICB9LFxuICAgICdhZGRMaW1pdCc6IGZ1bmN0aW9uKGxpbWl0KSB7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGxpbWl0KzEwKVxuICAgICAgICByZXR1cm4gKGxpbWl0KzEwKTtcbiAgICB9LFxuICAgICdoYXNNb3JlJzogZnVuY3Rpb24obGltaXQpIHtcbiAgICAgICAgaWYgKGxpbWl0ID4gTWV0ZW9yLmNhbGwoJ2dldEN1cnJlbnRIZWlnaHQnKSkge1xuICAgICAgICAgICAgcmV0dXJuIChmYWxzZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gKHRydWUpO1xuICAgICAgICB9XG4gICAgfVxufSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEJsb2Nrc2NvbiB9IGZyb20gJy4uL2Jsb2Nrcy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uLy4uL3RyYW5zYWN0aW9ucy90cmFuc2FjdGlvbnMuanMnO1xuXG5wdWJsaXNoQ29tcG9zaXRlKCdibG9ja3MuaGVpZ2h0JywgZnVuY3Rpb24obGltaXQpe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZCh7fSwge2xpbWl0OiBsaW1pdCwgc29ydDoge2hlaWdodDogLTF9fSlcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKGJsb2NrKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHthZGRyZXNzOmJsb2NrLnByb3Bvc2VyQWRkcmVzc30sXG4gICAgICAgICAgICAgICAgICAgICAgICB7bGltaXQ6MX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pO1xuXG5wdWJsaXNoQ29tcG9zaXRlKCdibG9ja3MuZmluZE9uZScsIGZ1bmN0aW9uKGhlaWdodCl7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKHtoZWlnaHQ6aGVpZ2h0fSlcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKGJsb2NrKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFRyYW5zYWN0aW9ucy5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2hlaWdodDpibG9jay5oZWlnaHR9XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQoYmxvY2spe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2FkZHJlc3M6YmxvY2sucHJvcG9zZXJBZGRyZXNzfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtsaW1pdDoxfVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcblxuZXhwb3J0IGNvbnN0IEJsb2Nrc2NvbiA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdibG9ja3MnKTtcblxuQmxvY2tzY29uLmhlbHBlcnMoe1xuICAgIHByb3Bvc2VyKCl7XG4gICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmRPbmUoe2FkZHJlc3M6dGhpcy5wcm9wb3NlckFkZHJlc3N9KTtcbiAgICB9XG59KTtcblxuLy8gQmxvY2tzY29uLmhlbHBlcnMoe1xuLy8gICAgIHNvcnRlZChsaW1pdCkge1xuLy8gICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmQoe30sIHtzb3J0OiB7aGVpZ2h0Oi0xfSwgbGltaXQ6IGxpbWl0fSk7XG4vLyAgICAgfVxuLy8gfSk7XG5cblxuLy8gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCkge1xuLy8gICAgIE1ldGVvci5jYWxsKCdibG9ja3NVcGRhdGUnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuLy8gICAgICAgICBjb25zb2xlLmxvZyhyZXN1bHQpO1xuLy8gICAgIH0pXG4vLyB9LCAzMDAwMDAwMCk7IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuaW1wb3J0IHsgZ2V0QWRkcmVzcyB9IGZyb20gJ3RlbmRlcm1pbnQvbGliL3B1YmtleS5qcyc7XG5pbXBvcnQgeyBDaGFpbiwgQ2hhaW5TdGF0ZXMgfSBmcm9tICcuLi9jaGFpbi5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcbmltcG9ydCB7IFZvdGluZ1Bvd2VySGlzdG9yeSB9IGZyb20gJy4uLy4uL3ZvdGluZy1wb3dlci9oaXN0b3J5LmpzJztcblxuZmluZFZvdGluZ1Bvd2VyID0gKHZhbGlkYXRvciwgZ2VuVmFsaWRhdG9ycykgPT4ge1xuICAgIGZvciAobGV0IHYgaW4gZ2VuVmFsaWRhdG9ycyl7XG4gICAgICAgIGlmICh2YWxpZGF0b3IucHViX2tleS52YWx1ZSA9PSBnZW5WYWxpZGF0b3JzW3ZdLnB1Yl9rZXkudmFsdWUpe1xuICAgICAgICAgICAgcmV0dXJuIHBhcnNlSW50KGdlblZhbGlkYXRvcnNbdl0ucG93ZXIpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ2NoYWluLmdldENvbnNlbnN1c1N0YXRlJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB1cmwgPSBSUEMrJy9kdW1wX2NvbnNlbnN1c19zdGF0ZSc7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBsZXQgY29uc2Vuc3VzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgIGNvbnNlbnN1cyA9IGNvbnNlbnN1cy5yZXN1bHQ7XG4gICAgICAgICAgICBsZXQgaGVpZ2h0ID0gY29uc2Vuc3VzLnJvdW5kX3N0YXRlLmhlaWdodDtcbiAgICAgICAgICAgIGxldCByb3VuZCA9IGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS5yb3VuZDtcbiAgICAgICAgICAgIGxldCBzdGVwID0gY29uc2Vuc3VzLnJvdW5kX3N0YXRlLnN0ZXA7XG4gICAgICAgICAgICBsZXQgdm90ZWRQb3dlciA9IE1hdGgucm91bmQocGFyc2VGbG9hdChjb25zZW5zdXMucm91bmRfc3RhdGUudm90ZXNbcm91bmRdLnByZXZvdGVzX2JpdF9hcnJheS5zcGxpdChcIiBcIilbM10pKjEwMCk7XG5cbiAgICAgICAgICAgIENoYWluLnVwZGF0ZSh7Y2hhaW5JZDpNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LCB7JHNldDp7XG4gICAgICAgICAgICAgICAgdm90aW5nSGVpZ2h0OiBoZWlnaHQsXG4gICAgICAgICAgICAgICAgdm90aW5nUm91bmQ6IHJvdW5kLFxuICAgICAgICAgICAgICAgIHZvdGluZ1N0ZXA6IHN0ZXAsXG4gICAgICAgICAgICAgICAgdm90ZWRQb3dlcjogdm90ZWRQb3dlcixcbiAgICAgICAgICAgICAgICBwcm9wb3NlckFkZHJlc3M6IGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS52YWxpZGF0b3JzLnByb3Bvc2VyLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgcHJldm90ZXM6IGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS52b3Rlc1tyb3VuZF0ucHJldm90ZXMsXG4gICAgICAgICAgICAgICAgcHJlY29tbWl0czogY29uc2Vuc3VzLnJvdW5kX3N0YXRlLnZvdGVzW3JvdW5kXS5wcmVjb21taXRzXG4gICAgICAgICAgICB9fSk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ2NoYWluLnVwZGF0ZVN0YXR1cyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgdXJsID0gUlBDKycvc3RhdHVzJztcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGxldCBzdGF0dXMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgc3RhdHVzID0gc3RhdHVzLnJlc3VsdDtcbiAgICAgICAgICAgIGxldCBjaGFpbiA9IHt9O1xuICAgICAgICAgICAgY2hhaW4uY2hhaW5JZCA9IHN0YXR1cy5ub2RlX2luZm8ubmV0d29yaztcbiAgICAgICAgICAgIGNoYWluLmxhdGVzdEJsb2NrSGVpZ2h0ID0gc3RhdHVzLnN5bmNfaW5mby5sYXRlc3RfYmxvY2tfaGVpZ2h0O1xuICAgICAgICAgICAgY2hhaW4ubGF0ZXN0QmxvY2tUaW1lID0gc3RhdHVzLnN5bmNfaW5mby5sYXRlc3RfYmxvY2tfdGltZTtcblxuICAgICAgICAgICAgbGV0IGxhdGVzdFN0YXRlID0gQ2hhaW5TdGF0ZXMuZmluZE9uZSh7fSwge3NvcnQ6IHtoZWlnaHQ6IC0xfX0pXG4gICAgICAgICAgICBpZiAobGF0ZXN0U3RhdGUgJiYgbGF0ZXN0U3RhdGUuaGVpZ2h0ID49IGNoYWluLmxhdGVzdEJsb2NrSGVpZ2h0KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGBubyB1cGRhdGVzIChnZXR0aW5nIGJsb2NrICR7Y2hhaW4ubGF0ZXN0QmxvY2tIZWlnaHR9IGF0IGJsb2NrICR7bGF0ZXN0U3RhdGUuaGVpZ2h0fSlgXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHVybCA9IFJQQysnL3ZhbGlkYXRvcnMnO1xuICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgbGV0IHZhbGlkYXRvcnMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgdmFsaWRhdG9ycyA9IHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnM7XG4gICAgICAgICAgICBjaGFpbi52YWxpZGF0b3JzID0gdmFsaWRhdG9ycy5sZW5ndGg7XG4gICAgICAgICAgICBsZXQgYWN0aXZlVlAgPSAwO1xuICAgICAgICAgICAgZm9yICh2IGluIHZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgICAgIGFjdGl2ZVZQICs9IHBhcnNlSW50KHZhbGlkYXRvcnNbdl0udm90aW5nX3Bvd2VyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNoYWluLmFjdGl2ZVZvdGluZ1Bvd2VyID0gYWN0aXZlVlA7XG5cblxuICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOmNoYWluLmNoYWluSWR9LCB7JHNldDpjaGFpbn0sIHt1cHNlcnQ6IHRydWV9KTtcbiAgICAgICAgICAgIC8vIEdldCBjaGFpbiBzdGF0ZXNcbiAgICAgICAgICAgIGlmIChwYXJzZUludChjaGFpbi5sYXRlc3RCbG9ja0hlaWdodCkgPiAwKXtcbiAgICAgICAgICAgICAgICBsZXQgY2hhaW5TdGF0ZXMgPSB7fTtcbiAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5oZWlnaHQgPSBwYXJzZUludChzdGF0dXMuc3luY19pbmZvLmxhdGVzdF9ibG9ja19oZWlnaHQpO1xuICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLnRpbWUgPSBuZXcgRGF0ZShzdGF0dXMuc3luY19pbmZvLmxhdGVzdF9ibG9ja190aW1lKTtcblxuICAgICAgICAgICAgICAgIHVybCA9IExDRCArICcvc3Rha2luZy9wb29sJztcbiAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGJvbmRpbmcgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgLy8gY2hhaW4uYm9uZGVkVG9rZW5zID0gYm9uZGluZy5ib25kZWRfdG9rZW5zO1xuICAgICAgICAgICAgICAgICAgICAvLyBjaGFpbi5ub3RCb25kZWRUb2tlbnMgPSBib25kaW5nLm5vdF9ib25kZWRfdG9rZW5zO1xuICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5ib25kZWRUb2tlbnMgPSBwYXJzZUludChib25kaW5nLmJvbmRlZF90b2tlbnMpO1xuICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5ub3RCb25kZWRUb2tlbnMgPSBwYXJzZUludChib25kaW5nLm5vdF9ib25kZWRfdG9rZW5zKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHVybCA9IExDRCArICcvc3VwcGx5L3RvdGFsLycrTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5taW50aW5nRGVub207XG4gICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBzdXBwbHkgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMudG90YWxTdXBwbHkgPSBwYXJzZUludChzdXBwbHkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdXJsID0gTENEICsgJy9kaXN0cmlidXRpb24vY29tbXVuaXR5X3Bvb2wnO1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHBvb2wgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBvb2wgJiYgcG9vbC5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLmNvbW11bml0eVBvb2wgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvb2wuZm9yRWFjaCgoYW1vdW50LCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMuY29tbXVuaXR5UG9vbC5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVub206IGFtb3VudC5kZW5vbSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW1vdW50OiBwYXJzZUZsb2F0KGFtb3VudC5hbW91bnQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHVybCA9IExDRCArICcvbWludGluZy9pbmZsYXRpb24nO1xuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgaW5mbGF0aW9uID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpbmZsYXRpb24pe1xuICAgICAgICAgICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMuaW5mbGF0aW9uID0gcGFyc2VGbG9hdChpbmZsYXRpb24pXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHVybCA9IExDRCArICcvbWludGluZy9hbm51YWwtcHJvdmlzaW9ucyc7XG4gICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBwcm92aXNpb25zID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb3Zpc2lvbnMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMuYW5udWFsUHJvdmlzaW9ucyA9IHBhcnNlRmxvYXQocHJvdmlzaW9ucy5yZXN1bHQpXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIENoYWluU3RhdGVzLmluc2VydChjaGFpblN0YXRlcyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIGNoYWluLnRvdGFsVm90aW5nUG93ZXIgPSB0b3RhbFZQO1xuXG4gICAgICAgICAgICAvLyB2YWxpZGF0b3JzID0gVmFsaWRhdG9ycy5maW5kKHt9KS5mZXRjaCgpO1xuICAgICAgICAgICAgLy8gY29uc29sZS5sb2codmFsaWRhdG9ycyk7XG4gICAgICAgICAgICByZXR1cm4gY2hhaW4ubGF0ZXN0QmxvY2tIZWlnaHQ7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICByZXR1cm4gXCJFcnJvciBnZXR0aW5nIGNoYWluIHN0YXR1cy5cIjtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ2NoYWluLmdldExhdGVzdFN0YXR1cyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIENoYWluLmZpbmQoKS5zb3J0KHtjcmVhdGVkOi0xfSkubGltaXQoMSk7XG4gICAgfSxcbiAgICAnY2hhaW4uZ2VuZXNpcyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIGxldCBjaGFpbiA9IENoYWluLmZpbmRPbmUoe2NoYWluSWQ6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0pO1xuXG4gICAgICAgIGlmIChjaGFpbiAmJiBjaGFpbi5yZWFkR2VuZXNpcyl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnR2VuZXNpcyBmaWxlIGhhcyBiZWVuIHByb2Nlc3NlZCcpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKE1ldGVvci5zZXR0aW5ncy5kZWJ1Zy5yZWFkR2VuZXNpcykge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJz09PSBTdGFydCBwcm9jZXNzaW5nIGdlbmVzaXMgZmlsZSA9PT0nKTtcbiAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KE1ldGVvci5zZXR0aW5ncy5nZW5lc2lzRmlsZSk7XG4gICAgICAgICAgICBsZXQgZ2VuZXNpcyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICBsZXQgZGlzdHIgPSBnZW5lc2lzLmFwcF9zdGF0ZS5kaXN0ciB8fCBnZW5lc2lzLmFwcF9zdGF0ZS5kaXN0cmlidXRpb25cbiAgICAgICAgICAgIGxldCBjaGFpblBhcmFtcyA9IHtcbiAgICAgICAgICAgICAgICBjaGFpbklkOiBnZW5lc2lzLmNoYWluX2lkLFxuICAgICAgICAgICAgICAgIGdlbmVzaXNUaW1lOiBnZW5lc2lzLmdlbmVzaXNfdGltZSxcbiAgICAgICAgICAgICAgICBjb25zZW5zdXNQYXJhbXM6IGdlbmVzaXMuY29uc2Vuc3VzX3BhcmFtcyxcbiAgICAgICAgICAgICAgICBhdXRoOiBnZW5lc2lzLmFwcF9zdGF0ZS5hdXRoLFxuICAgICAgICAgICAgICAgIGJhbms6IGdlbmVzaXMuYXBwX3N0YXRlLmJhbmssXG4gICAgICAgICAgICAgICAgc3Rha2luZzoge1xuICAgICAgICAgICAgICAgICAgICBwb29sOiBnZW5lc2lzLmFwcF9zdGF0ZS5zdGFraW5nLnBvb2wsXG4gICAgICAgICAgICAgICAgICAgIHBhcmFtczogZ2VuZXNpcy5hcHBfc3RhdGUuc3Rha2luZy5wYXJhbXNcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIG1pbnQ6IGdlbmVzaXMuYXBwX3N0YXRlLm1pbnQsXG4gICAgICAgICAgICAgICAgZGlzdHI6IHtcbiAgICAgICAgICAgICAgICAgICAgY29tbXVuaXR5VGF4OiBkaXN0ci5jb21tdW5pdHlfdGF4LFxuICAgICAgICAgICAgICAgICAgICBiYXNlUHJvcG9zZXJSZXdhcmQ6IGRpc3RyLmJhc2VfcHJvcG9zZXJfcmV3YXJkLFxuICAgICAgICAgICAgICAgICAgICBib251c1Byb3Bvc2VyUmV3YXJkOiBkaXN0ci5ib251c19wcm9wb3Nlcl9yZXdhcmQsXG4gICAgICAgICAgICAgICAgICAgIHdpdGhkcmF3QWRkckVuYWJsZWQ6IGRpc3RyLndpdGhkcmF3X2FkZHJfZW5hYmxlZFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgZ292OiBudWxsLFxuICAgICAgICAgICAgICAgIHNsYXNoaW5nOntcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1zOiBnZW5lc2lzLmFwcF9zdGF0ZS5zbGFzaGluZy5wYXJhbXNcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHN1cHBseTogZ2VuZXNpcy5hcHBfc3RhdGUuc3VwcGx5LFxuICAgICAgICAgICAgICAgIGNyaXNpczogZ2VuZXNpcy5hcHBfc3RhdGUuY3Jpc2lzXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGxldCB0b3RhbFZvdGluZ1Bvd2VyID0gMDtcblxuICAgICAgICAgICAgLy8gcmVhZCBnZW50eFxuICAgICAgICAgICAgaWYgKGdlbmVzaXMuYXBwX3N0YXRlLmdlbnV0aWwgJiYgZ2VuZXNpcy5hcHBfc3RhdGUuZ2VudXRpbC5nZW50eHMgJiYgKGdlbmVzaXMuYXBwX3N0YXRlLmdlbnV0aWwuZ2VudHhzLmxlbmd0aCA+IDApKXtcbiAgICAgICAgICAgICAgICBmb3IgKGkgaW4gZ2VuZXNpcy5hcHBfc3RhdGUuZ2VudXRpbC5nZW50eHMpe1xuICAgICAgICAgICAgICAgICAgICBsZXQgbXNnID0gZ2VuZXNpcy5hcHBfc3RhdGUuZ2VudXRpbC5nZW50eHNbaV0udmFsdWUubXNnO1xuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhtc2cudHlwZSk7XG4gICAgICAgICAgICAgICAgICAgIGZvciAobSBpbiBtc2cpe1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1zZ1ttXS50eXBlID09IFwiY29zbW9zLXNkay9Nc2dDcmVhdGVWYWxpZGF0b3JcIil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cobXNnW21dLnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBsZXQgY29tbWFuZCA9IE1ldGVvci5zZXR0aW5ncy5iaW4uZ2FpYWRlYnVnK1wiIHB1YmtleSBcIittc2dbbV0udmFsdWUucHVia2V5O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3IgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNlbnN1c19wdWJrZXk6IG1zZ1ttXS52YWx1ZS5wdWJrZXksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBtc2dbbV0udmFsdWUuZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb246IG1zZ1ttXS52YWx1ZS5jb21taXNzaW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5fc2VsZl9kZWxlZ2F0aW9uOiBtc2dbbV0udmFsdWUubWluX3NlbGZfZGVsZWdhdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3BlcmF0b3JfYWRkcmVzczogbXNnW21dLnZhbHVlLnZhbGlkYXRvcl9hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxlZ2F0b3JfYWRkcmVzczogbXNnW21dLnZhbHVlLmRlbGVnYXRvcl9hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IE1hdGguZmxvb3IocGFyc2VJbnQobXNnW21dLnZhbHVlLnZhbHVlLmFtb3VudCkgLyBNZXRlb3Iuc2V0dGluZ3MucHVibGljLnN0YWtpbmdGcmFjdGlvbiksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGphaWxlZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogMlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsVm90aW5nUG93ZXIgKz0gdmFsaWRhdG9yLnZvdGluZ19wb3dlcjtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwdWJrZXlWYWx1ZSA9IE1ldGVvci5jYWxsKCdiZWNoMzJUb1B1YmtleScsIG1zZ1ttXS52YWx1ZS5wdWJrZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFZhbGlkYXRvcnMudXBzZXJ0KHtjb25zZW5zdXNfcHVia2V5Om1zZ1ttXS52YWx1ZS5wdWJrZXl9LHZhbGlkYXRvcik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHViX2tleSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6XCJ0ZW5kZXJtaW50L1B1YktleUVkMjU1MTlcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ2YWx1ZVwiOnB1YmtleVZhbHVlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFkZHJlc3MgPSBnZXRBZGRyZXNzKHZhbGlkYXRvci5wdWJfa2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYWNjcHViID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4QWNjUHViKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsUHViKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBWb3RpbmdQb3dlckhpc3RvcnkuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogdmFsaWRhdG9yLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZXZfdm90aW5nX3Bvd2VyOiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IHZhbGlkYXRvci52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdhZGQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrX3RpbWU6IGdlbmVzaXMuZ2VuZXNpc190aW1lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBWYWxpZGF0b3JzLmluc2VydCh2YWxpZGF0b3IpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyByZWFkIHZhbGlkYXRvcnMgZnJvbSBwcmV2aW91cyBjaGFpblxuICAgICAgICAgICAgY29uc29sZS5sb2coJ3JlYWQgdmFsaWRhdG9ycyBmcm9tIHByZXZpb3VzIGNoYWluJyk7XG4gICAgICAgICAgICBpZiAoZ2VuZXNpcy5hcHBfc3RhdGUuc3Rha2luZy52YWxpZGF0b3JzICYmIGdlbmVzaXMuYXBwX3N0YXRlLnN0YWtpbmcudmFsaWRhdG9ycy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhnZW5lc2lzLmFwcF9zdGF0ZS5zdGFraW5nLnZhbGlkYXRvcnMubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICBsZXQgZ2VuVmFsaWRhdG9yc1NldCA9IGdlbmVzaXMuYXBwX3N0YXRlLnN0YWtpbmcudmFsaWRhdG9ycztcbiAgICAgICAgICAgICAgICBsZXQgZ2VuVmFsaWRhdG9ycyA9IGdlbmVzaXMudmFsaWRhdG9ycztcbiAgICAgICAgICAgICAgICBmb3IgKGxldCB2IGluIGdlblZhbGlkYXRvcnNTZXQpe1xuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhnZW5WYWxpZGF0b3JzW3ZdKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvciA9IGdlblZhbGlkYXRvcnNTZXRbdl07XG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZWxlZ2F0b3JfYWRkcmVzcyA9IE1ldGVvci5jYWxsKCdnZXREZWxlZ2F0b3InLCBnZW5WYWxpZGF0b3JzU2V0W3ZdLm9wZXJhdG9yX2FkZHJlc3MpO1xuXG4gICAgICAgICAgICAgICAgICAgIGxldCBwdWJrZXlWYWx1ZSA9IE1ldGVvci5jYWxsKCdiZWNoMzJUb1B1YmtleScsIHZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5KTtcblxuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHViX2tleSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIFwidHlwZVwiOlwidGVuZGVybWludC9QdWJLZXlFZDI1NTE5XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBcInZhbHVlXCI6cHVia2V5VmFsdWVcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5hZGRyZXNzID0gZ2V0QWRkcmVzcyh2YWxpZGF0b3IucHViX2tleSk7XG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5wdWJfa2V5ID0gdmFsaWRhdG9yLnB1Yl9rZXk7XG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5hY2NwdWIgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3IucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhBY2NQdWIpO1xuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsUHViKTtcblxuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyID0gZmluZFZvdGluZ1Bvd2VyKHZhbGlkYXRvciwgZ2VuVmFsaWRhdG9ycyk7XG4gICAgICAgICAgICAgICAgICAgIHRvdGFsVm90aW5nUG93ZXIgKz0gdmFsaWRhdG9yLnZvdGluZ19wb3dlcjtcblxuICAgICAgICAgICAgICAgICAgICBWYWxpZGF0b3JzLnVwc2VydCh7Y29uc2Vuc3VzX3B1YmtleTp2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleX0sdmFsaWRhdG9yKTtcbiAgICAgICAgICAgICAgICAgICAgVm90aW5nUG93ZXJIaXN0b3J5Lmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOiB2YWxpZGF0b3IuYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByZXZfdm90aW5nX3Bvd2VyOiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2FkZCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja190aW1lOiBnZW5lc2lzLmdlbmVzaXNfdGltZVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNoYWluUGFyYW1zLnJlYWRHZW5lc2lzID0gdHJ1ZTtcbiAgICAgICAgICAgIGNoYWluUGFyYW1zLmFjdGl2ZVZvdGluZ1Bvd2VyID0gdG90YWxWb3RpbmdQb3dlcjtcbiAgICAgICAgICAgIGxldCByZXN1bHQgPSBDaGFpbi51cHNlcnQoe2NoYWluSWQ6Y2hhaW5QYXJhbXMuY2hhaW5JZH0sIHskc2V0OmNoYWluUGFyYW1zfSk7XG5cblxuICAgICAgICAgICAgY29uc29sZS5sb2coJz09PSBGaW5pc2hlZCBwcm9jZXNzaW5nIGdlbmVzaXMgZmlsZSA9PT0nKTtcblxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQ2hhaW4sIENoYWluU3RhdGVzIH0gZnJvbSAnLi4vY2hhaW4uanMnO1xuaW1wb3J0IHsgQ29pblN0YXRzIH0gZnJvbSAnLi4vLi4vY29pbi1zdGF0cy9jb2luLXN0YXRzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuXG5NZXRlb3IucHVibGlzaCgnY2hhaW5TdGF0ZXMubGF0ZXN0JywgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBbXG4gICAgICAgIENoYWluU3RhdGVzLmZpbmQoe30se3NvcnQ6e2hlaWdodDotMX0sbGltaXQ6MX0pLFxuICAgICAgICBDb2luU3RhdHMuZmluZCh7fSx7c29ydDp7bGFzdF91cGRhdGVkX2F0Oi0xfSxsaW1pdDoxfSlcbiAgICBdO1xufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ2NoYWluLnN0YXR1cycsIGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIENoYWluLmZpbmQoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSk7XG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZChjaGFpbil7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6MSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjoxLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wZXJhdG9yX2FkZHJlc3M6MSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6LTEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgamFpbGVkOjEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvZmlsZV91cmw6MVxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pOyIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuXG5leHBvcnQgY29uc3QgQ2hhaW4gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY2hhaW4nKTtcbmV4cG9ydCBjb25zdCBDaGFpblN0YXRlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjaGFpbl9zdGF0ZXMnKVxuXG5DaGFpbi5oZWxwZXJzKHtcbiAgICBwcm9wb3Nlcigpe1xuICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kT25lKHthZGRyZXNzOnRoaXMucHJvcG9zZXJBZGRyZXNzfSk7XG4gICAgfVxufSkiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IENvaW5TdGF0cyB9IGZyb20gJy4uL2NvaW4tc3RhdHMuanMnO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdjb2luU3RhdHMuZ2V0Q29pblN0YXRzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCBjb2luSWQgPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNvaW5nZWNrb0lkO1xuICAgICAgICBpZiAoY29pbklkKXtcbiAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICBsZXQgbm93ID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICBub3cuc2V0TWludXRlcygwKTtcbiAgICAgICAgICAgICAgICBsZXQgdXJsID0gXCJodHRwczovL2FwaS5jb2luZ2Vja28uY29tL2FwaS92My9zaW1wbGUvcHJpY2U/aWRzPVwiK2NvaW5JZCtcIiZ2c19jdXJyZW5jaWVzPXVzZCZpbmNsdWRlX21hcmtldF9jYXA9dHJ1ZSZpbmNsdWRlXzI0aHJfdm9sPXRydWUmaW5jbHVkZV8yNGhyX2NoYW5nZT10cnVlJmluY2x1ZGVfbGFzdF91cGRhdGVkX2F0PXRydWVcIjtcbiAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgZGF0YSA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICAgICAgICAgIGRhdGEgPSBkYXRhW2NvaW5JZF07XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGNvaW5TdGF0cyk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBDb2luU3RhdHMudXBzZXJ0KHtsYXN0X3VwZGF0ZWRfYXQ6ZGF0YS5sYXN0X3VwZGF0ZWRfYXR9LCB7JHNldDpkYXRhfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIHJldHVybiBcIk5vIGNvaW5nZWNrbyBJZCBwcm92aWRlZC5cIlxuICAgICAgICB9XG4gICAgfSxcbiAgICAnY29pblN0YXRzLmdldFN0YXRzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCBjb2luSWQgPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNvaW5nZWNrb0lkO1xuICAgICAgICBpZiAoY29pbklkKXtcbiAgICAgICAgICAgIHJldHVybiAoQ29pblN0YXRzLmZpbmRPbmUoe30se3NvcnQ6e2xhc3RfdXBkYXRlZF9hdDotMX19KSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIHJldHVybiBcIk5vIGNvaW5nZWNrbyBJZCBwcm92aWRlZC5cIjtcbiAgICAgICAgfVxuXG4gICAgfVxufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBDb2luU3RhdHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY29pbl9zdGF0cycpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBEZWxlZ2F0aW9ucyB9IGZyb20gJy4uL2RlbGVnYXRpb25zLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ2RlbGVnYXRpb25zLmdldERlbGVnYXRpb25zJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB2YWxpZGF0b3JzID0gVmFsaWRhdG9ycy5maW5kKHt9KS5mZXRjaCgpO1xuICAgICAgICBsZXQgZGVsZWdhdGlvbnMgPSBbXTtcbiAgICAgICAgY29uc29sZS5sb2coXCI9PT0gR2V0dGluZyBkZWxlZ2F0aW9ucyA9PT1cIik7XG4gICAgICAgIGZvciAodiBpbiB2YWxpZGF0b3JzKXtcbiAgICAgICAgICAgIGlmICh2YWxpZGF0b3JzW3ZdLm9wZXJhdG9yX2FkZHJlc3Mpe1xuICAgICAgICAgICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL3N0YWtpbmcvdmFsaWRhdG9ycy8nK3ZhbGlkYXRvcnNbdl0ub3BlcmF0b3JfYWRkcmVzcytcIi9kZWxlZ2F0aW9uc1wiO1xuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBkZWxlZ2F0aW9uID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhkZWxlZ2F0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zID0gZGVsZWdhdGlvbnMuY29uY2F0KGRlbGVnYXRpb24pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZS5zdGF0dXNDb2RlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgIH0gICAgXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBmb3IgKGkgaW4gZGVsZWdhdGlvbnMpe1xuICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zW2ldICYmIGRlbGVnYXRpb25zW2ldLnNoYXJlcylcbiAgICAgICAgICAgICAgICBkZWxlZ2F0aW9uc1tpXS5zaGFyZXMgPSBwYXJzZUZsb2F0KGRlbGVnYXRpb25zW2ldLnNoYXJlcyk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBjb25zb2xlLmxvZyhkZWxlZ2F0aW9ucyk7XG4gICAgICAgIGxldCBkYXRhID0ge1xuICAgICAgICAgICAgZGVsZWdhdGlvbnM6IGRlbGVnYXRpb25zLFxuICAgICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIERlbGVnYXRpb25zLmluc2VydChkYXRhKTtcbiAgICB9XG4gICAgLy8gJ2Jsb2Nrcy5hdmVyYWdlQmxvY2tUaW1lJyhhZGRyZXNzKXtcbiAgICAvLyAgICAgbGV0IGJsb2NrcyA9IEJsb2Nrc2Nvbi5maW5kKHtwcm9wb3NlckFkZHJlc3M6YWRkcmVzc30pLmZldGNoKCk7XG4gICAgLy8gICAgIGxldCBoZWlnaHRzID0gYmxvY2tzLm1hcCgoYmxvY2ssIGkpID0+IHtcbiAgICAvLyAgICAgICAgIHJldHVybiBibG9jay5oZWlnaHQ7XG4gICAgLy8gICAgIH0pO1xuICAgIC8vICAgICBsZXQgYmxvY2tzU3RhdHMgPSBBbmFseXRpY3MuZmluZCh7aGVpZ2h0OnskaW46aGVpZ2h0c319KS5mZXRjaCgpO1xuICAgIC8vICAgICAvLyBjb25zb2xlLmxvZyhibG9ja3NTdGF0cyk7XG5cbiAgICAvLyAgICAgbGV0IHRvdGFsQmxvY2tEaWZmID0gMDtcbiAgICAvLyAgICAgZm9yIChiIGluIGJsb2Nrc1N0YXRzKXtcbiAgICAvLyAgICAgICAgIHRvdGFsQmxvY2tEaWZmICs9IGJsb2Nrc1N0YXRzW2JdLnRpbWVEaWZmO1xuICAgIC8vICAgICB9XG4gICAgLy8gICAgIHJldHVybiB0b3RhbEJsb2NrRGlmZi9oZWlnaHRzLmxlbmd0aDtcbiAgICAvLyB9XG59KSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IERlbGVnYXRpb25zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2RlbGVnYXRpb25zJyk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5pbXBvcnQgeyBFbnRlcnByaXNlIH0gZnJvbSAnLi4vZW50ZXJwcmlzZS5qcyc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnZW50ZXJwcmlzZS5nZXRQdXJjaGFzZU9yZGVycyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgdXJsID0gTENEICsgJy9lbnRlcnByaXNlL3Bvcyc7XG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgbGV0IHB1cmNoYXNlT3JkZXJzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG5cbiAgICAgICAgICAgIGxldCBmaW5pc2hlZFB1cmNoYXNlT3JkZXJzID0gbmV3IFNldChFbnRlcnByaXNlLmZpbmQoXG4gICAgICAgICAgICAgICAge1wic3RhdHVzXCI6eyRpbjpbXCJyZWplY3RcIiwgXCJjb21wbGV0ZVwiXX19XG4gICAgICAgICAgICApLmZldGNoKCkubWFwKChwKT0+IHAucG9JZCkpO1xuXG4gICAgICAgICAgICBsZXQgcG9JZHMgPSBbXTtcblxuICAgICAgICAgICAgaWYgKHB1cmNoYXNlT3JkZXJzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICBjb25zdCBidWxrUG9zID0gRW50ZXJwcmlzZS5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgaW4gcHVyY2hhc2VPcmRlcnMpIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHBvID0gcHVyY2hhc2VPcmRlcnNbaV1cbiAgICAgICAgICAgICAgICAgICAgcG8ucG9JZCA9IHBhcnNlSW50KHBvLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBvLnBvSWQgPiAwICYmICFmaW5pc2hlZFB1cmNoYXNlT3JkZXJzLmhhcyhwby5wb0lkKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrUG9zLmZpbmQoe3BvSWQ6IHBvLnBvSWR9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6IHBvfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9JZHMucHVzaChwby5wb0lkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2goZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtQb3MuZmluZCh7cG9JZDogcG8ucG9JZH0pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDogcG99KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwb0lkcy5wdXNoKHBvLnBvSWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUucmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYocG9JZHMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICBidWxrUG9zLmV4ZWN1dGUoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG4gICAgfVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgRW50ZXJwcmlzZSB9IGZyb20gJy4uL2VudGVycHJpc2UuanMnO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snXG5cbk1ldGVvci5wdWJsaXNoKCdlbnRlcnByaXNlLmxpc3RfcG9zJywgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBFbnRlcnByaXNlLmZpbmQoe30sIHtzb3J0Ontwb0lkOi0xfX0pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKCdlbnRlcnByaXNlLm9uZV9wbycsIGZ1bmN0aW9uIChpZCl7XG4gICAgY2hlY2soaWQsIE51bWJlcik7XG4gICAgcmV0dXJuIEVudGVycHJpc2UuZmluZCh7cG9JZDppZH0pO1xufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBFbnRlcnByaXNlID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2VudGVycHJpc2UnKTtcbiIsImltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAndHJhbnNhY3Rpb24uc3VibWl0JzogZnVuY3Rpb24odHhJbmZvKSB7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke0xDRH0vdHhzYDtcbiAgICAgICAgZGF0YSA9IHtcbiAgICAgICAgICAgIFwidHhcIjogdHhJbmZvLnZhbHVlLFxuICAgICAgICAgICAgXCJtb2RlXCI6IFwic3luY1wiXG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdGltZXN0YW1wID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBzdWJtaXR0aW5nIHRyYW5zYWN0aW9uJHt0aW1lc3RhbXB9ICR7dXJsfSB3aXRoIGRhdGEgJHtKU09OLnN0cmluZ2lmeShkYXRhKX1gKVxuXG4gICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAucG9zdCh1cmwsIHtkYXRhfSk7XG4gICAgICAgIGNvbnNvbGUubG9nKGByZXNwb25zZSBmb3IgdHJhbnNhY3Rpb24ke3RpbWVzdGFtcH0gJHt1cmx9OiAke0pTT04uc3RyaW5naWZ5KHJlc3BvbnNlKX1gKVxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApIHtcbiAgICAgICAgICAgIGxldCBkYXRhID0gcmVzcG9uc2UuZGF0YVxuICAgICAgICAgICAgaWYgKGRhdGEuY29kZSlcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKGRhdGEuY29kZSwgSlNPTi5wYXJzZShkYXRhLnJhd19sb2cpLm1lc3NhZ2UpXG4gICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YS50eGhhc2g7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICd0cmFuc2FjdGlvbi5leGVjdXRlJzogZnVuY3Rpb24oYm9keSwgcGF0aCkge1xuICAgICAgICBjb25zdCB1cmwgPSBgJHtMQ0R9LyR7cGF0aH1gO1xuICAgICAgICBkYXRhID0ge1xuICAgICAgICAgICAgXCJiYXNlX3JlcVwiOiB7XG4gICAgICAgICAgICAgICAgLi4uYm9keSxcbiAgICAgICAgICAgICAgICBcImNoYWluX2lkXCI6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZCxcbiAgICAgICAgICAgICAgICBcInNpbXVsYXRlXCI6IGZhbHNlXG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAucG9zdCh1cmwsIHtkYXRhfSk7XG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCkge1xuICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICd0cmFuc2FjdGlvbi5zaW11bGF0ZSc6IGZ1bmN0aW9uKHR4TXNnLCBmcm9tLCBwYXRoLCBhZGp1c3RtZW50PScxLjInKSB7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke0xDRH0vJHtwYXRofWA7XG4gICAgICAgIGRhdGEgPSB7Li4udHhNc2csXG4gICAgICAgICAgICBcImJhc2VfcmVxXCI6IHtcbiAgICAgICAgICAgICAgICBcImZyb21cIjogZnJvbSxcbiAgICAgICAgICAgICAgICBcImNoYWluX2lkXCI6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZCxcbiAgICAgICAgICAgICAgICBcImdhc19hZGp1c3RtZW50XCI6IGFkanVzdG1lbnQsXG4gICAgICAgICAgICAgICAgXCJzaW11bGF0ZVwiOiB0cnVlXG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAucG9zdCh1cmwsIHtkYXRhfSk7XG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCkge1xuICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkuZ2FzX2VzdGltYXRlO1xuICAgICAgICB9XG4gICAgfSxcbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JSZWNvcmRzLCBBbmFseXRpY3MsIEF2ZXJhZ2VEYXRhLCBBdmVyYWdlVmFsaWRhdG9yRGF0YSB9IGZyb20gJy4uL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JTZXRzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL3ZhbGlkYXRvci1zZXRzL3ZhbGlkYXRvci1zZXRzLmpzJztcbmltcG9ydCB7IFN0YXR1cyB9IGZyb20gJy4uLy4uL3N0YXR1cy9zdGF0dXMuanMnO1xuaW1wb3J0IHsgTWlzc2VkQmxvY2tzU3RhdHMgfSBmcm9tICcuLi9yZWNvcmRzLmpzJztcbmltcG9ydCB7IE1pc3NlZEJsb2NrcyB9IGZyb20gJy4uL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vLi4vYmxvY2tzL2Jsb2Nrcy5qcyc7XG5pbXBvcnQgeyBDaGFpbiB9IGZyb20gJy4uLy4uL2NoYWluL2NoYWluLmpzJztcbmltcG9ydCBfIGZyb20gJ2xvZGFzaCc7XG5jb25zdCBCVUxLVVBEQVRFTUFYU0laRSA9IDEwMDA7XG5cbmNvbnN0IGdldEJsb2NrU3RhdHMgPSAoc3RhcnRIZWlnaHQsIGxhdGVzdEhlaWdodCkgPT4ge1xuICAgIGxldCBibG9ja1N0YXRzID0ge307XG4gICAgY29uc3QgY29uZCA9IHskYW5kOiBbXG4gICAgICAgIHsgaGVpZ2h0OiB7ICRndDogc3RhcnRIZWlnaHQgfSB9LFxuICAgICAgICB7IGhlaWdodDogeyAkbHRlOiBsYXRlc3RIZWlnaHQgfSB9IF19O1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7c29ydDp7aGVpZ2h0OiAxfX07XG4gICAgQmxvY2tzY29uLmZpbmQoY29uZCwgb3B0aW9ucykuZm9yRWFjaCgoYmxvY2spID0+IHtcbiAgICAgICAgYmxvY2tTdGF0c1tibG9jay5oZWlnaHRdID0ge1xuICAgICAgICAgICAgaGVpZ2h0OiBibG9jay5oZWlnaHQsXG4gICAgICAgICAgICBwcm9wb3NlckFkZHJlc3M6IGJsb2NrLnByb3Bvc2VyQWRkcmVzcyxcbiAgICAgICAgICAgIHByZWNvbW1pdHNDb3VudDogYmxvY2sucHJlY29tbWl0c0NvdW50LFxuICAgICAgICAgICAgdmFsaWRhdG9yc0NvdW50OiBibG9jay52YWxpZGF0b3JzQ291bnQsXG4gICAgICAgICAgICB2YWxpZGF0b3JzOiBibG9jay52YWxpZGF0b3JzLFxuICAgICAgICAgICAgdGltZTogYmxvY2sudGltZVxuICAgICAgICB9XG4gICAgfSk7XG5cbiAgICBBbmFseXRpY3MuZmluZChjb25kLCBvcHRpb25zKS5mb3JFYWNoKChibG9jaykgPT4ge1xuICAgICAgICBpZiAoIWJsb2NrU3RhdHNbYmxvY2suaGVpZ2h0XSkge1xuICAgICAgICAgICAgYmxvY2tTdGF0c1tibG9jay5oZWlnaHRdID0geyBoZWlnaHQ6IGJsb2NrLmhlaWdodCB9O1xuICAgICAgICAgICAgY29uc29sZS5sb2coYGJsb2NrICR7YmxvY2suaGVpZ2h0fSBkb2VzIG5vdCBoYXZlIGFuIGVudHJ5YCk7XG4gICAgICAgIH1cbiAgICAgICAgXy5hc3NpZ24oYmxvY2tTdGF0c1tibG9jay5oZWlnaHRdLCB7XG4gICAgICAgICAgICBwcmVjb21taXRzOiBibG9jay5wcmVjb21taXRzLFxuICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZTogYmxvY2suYXZlcmFnZUJsb2NrVGltZSxcbiAgICAgICAgICAgIHRpbWVEaWZmOiBibG9jay50aW1lRGlmZixcbiAgICAgICAgICAgIHZvdGluZ19wb3dlcjogYmxvY2sudm90aW5nX3Bvd2VyXG4gICAgICAgIH0pO1xuICAgIH0pO1xuICAgIHJldHVybiBibG9ja1N0YXRzO1xufVxuXG5jb25zdCBnZXRQcmV2aW91c1JlY29yZCA9ICh2b3RlckFkZHJlc3MsIHByb3Bvc2VyQWRkcmVzcykgPT4ge1xuICAgIGxldCBwcmV2aW91c1JlY29yZCA9IE1pc3NlZEJsb2Nrcy5maW5kT25lKFxuICAgICAgICB7dm90ZXI6dm90ZXJBZGRyZXNzLCBwcm9wb3Nlcjpwcm9wb3NlckFkZHJlc3MsIGJsb2NrSGVpZ2h0OiAtMX0pO1xuICAgIGxldCBsYXN0VXBkYXRlZEhlaWdodCA9IE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuc3RhcnRIZWlnaHQ7XG4gICAgbGV0IHByZXZTdGF0cyA9IHt9O1xuICAgIGlmIChwcmV2aW91c1JlY29yZCkge1xuICAgICAgICBwcmV2U3RhdHMgPSBfLnBpY2socHJldmlvdXNSZWNvcmQsIFsnbWlzc0NvdW50JywgJ3RvdGFsQ291bnQnXSk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgcHJldlN0YXRzID0ge1xuICAgICAgICAgICAgbWlzc0NvdW50OiAwLFxuICAgICAgICAgICAgdG90YWxDb3VudDogMFxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBwcmV2U3RhdHM7XG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnVmFsaWRhdG9yUmVjb3Jkcy5jYWxjdWxhdGVNaXNzZWRCbG9ja3MnOiBmdW5jdGlvbigpe1xuICAgICAgICBpZiAoIUNPVU5UTUlTU0VEQkxPQ0tTKXtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgbGV0IHN0YXJ0VGltZSA9IERhdGUubm93KCk7XG4gICAgICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1MgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdjYWx1bGF0ZSBtaXNzZWQgYmxvY2tzIGNvdW50Jyk7XG4gICAgICAgICAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe30pLmZldGNoKCk7XG4gICAgICAgICAgICAgICAgbGV0IGxhdGVzdEhlaWdodCA9IE1ldGVvci5jYWxsKCdibG9ja3MuZ2V0Q3VycmVudEhlaWdodCcpO1xuICAgICAgICAgICAgICAgIGxldCBleHBsb3JlclN0YXR1cyA9IFN0YXR1cy5maW5kT25lKHtjaGFpbklkOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9KTtcbiAgICAgICAgICAgICAgICBsZXQgc3RhcnRIZWlnaHQgPSAoZXhwbG9yZXJTdGF0dXMmJmV4cGxvcmVyU3RhdHVzLmxhc3RQcm9jZXNzZWRNaXNzZWRCbG9ja0hlaWdodCk/ZXhwbG9yZXJTdGF0dXMubGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrSGVpZ2h0Ok1ldGVvci5zZXR0aW5ncy5wYXJhbXMuc3RhcnRIZWlnaHQ7XG4gICAgICAgICAgICAgICAgbGF0ZXN0SGVpZ2h0ID0gTWF0aC5taW4oc3RhcnRIZWlnaHQgKyBCVUxLVVBEQVRFTUFYU0laRSwgbGF0ZXN0SGVpZ2h0KTtcbiAgICAgICAgICAgICAgICBjb25zdCBidWxrTWlzc2VkU3RhdHMgPSBNaXNzZWRCbG9ja3MucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVPcmRlcmVkQnVsa09wKCk7XG5cbiAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yc01hcCA9IHt9O1xuICAgICAgICAgICAgICAgIHZhbGlkYXRvcnMuZm9yRWFjaCgodmFsaWRhdG9yKSA9PiB2YWxpZGF0b3JzTWFwW3ZhbGlkYXRvci5hZGRyZXNzXSA9IHZhbGlkYXRvcik7XG5cbiAgICAgICAgICAgICAgICAvLyBhIG1hcCBvZiBibG9jayBoZWlnaHQgdG8gYmxvY2sgc3RhdHNcbiAgICAgICAgICAgICAgICBsZXQgYmxvY2tTdGF0cyA9IGdldEJsb2NrU3RhdHMoc3RhcnRIZWlnaHQsIGxhdGVzdEhlaWdodCk7XG5cbiAgICAgICAgICAgICAgICAvLyBwcm9wb3NlclZvdGVyU3RhdHMgaXMgYSBwcm9wb3Nlci12b3RlciBtYXAgY291bnRpbmcgbnVtYmVycyBvZiBwcm9wb3NlZCBibG9ja3Mgb2Ygd2hpY2ggdm90ZXIgaXMgYW4gYWN0aXZlIHZhbGlkYXRvclxuICAgICAgICAgICAgICAgIGxldCBwcm9wb3NlclZvdGVyU3RhdHMgPSB7fVxuXG4gICAgICAgICAgICAgICAgXy5mb3JFYWNoKGJsb2NrU3RhdHMsIChibG9jaywgYmxvY2tIZWlnaHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHByb3Bvc2VyQWRkcmVzcyA9IGJsb2NrLnByb3Bvc2VyQWRkcmVzcztcbiAgICAgICAgICAgICAgICAgICAgbGV0IHZvdGVkVmFsaWRhdG9ycyA9IG5ldyBTZXQoYmxvY2sudmFsaWRhdG9ycyk7XG4gICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3JTZXRzID0gVmFsaWRhdG9yU2V0cy5maW5kT25lKHtibG9ja19oZWlnaHQ6YmxvY2suaGVpZ2h0fSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCB2b3RlZFZvdGluZ1Bvd2VyID0gMDtcblxuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JTZXRzLnZhbGlkYXRvcnMuZm9yRWFjaCgoYWN0aXZlVmFsaWRhdG9yKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodm90ZWRWYWxpZGF0b3JzLmhhcyhhY3RpdmVWYWxpZGF0b3IuYWRkcmVzcykpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90ZWRWb3RpbmdQb3dlciArPSBwYXJzZUZsb2F0KGFjdGl2ZVZhbGlkYXRvci52b3RpbmdfcG93ZXIpXG4gICAgICAgICAgICAgICAgICAgIH0pXG5cbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yU2V0cy52YWxpZGF0b3JzLmZvckVhY2goKGFjdGl2ZVZhbGlkYXRvcikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRWYWxpZGF0b3IgPSBhY3RpdmVWYWxpZGF0b3IuYWRkcmVzc1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFfLmhhcyhwcm9wb3NlclZvdGVyU3RhdHMsIFtwcm9wb3NlckFkZHJlc3MsIGN1cnJlbnRWYWxpZGF0b3JdKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwcmV2U3RhdHMgPSBnZXRQcmV2aW91c1JlY29yZChjdXJyZW50VmFsaWRhdG9yLCBwcm9wb3NlckFkZHJlc3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF8uc2V0KHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvcl0sIHByZXZTdGF0cyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIF8udXBkYXRlKHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvciwgJ3RvdGFsQ291bnQnXSwgKG4pID0+IG4rMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXZvdGVkVmFsaWRhdG9ycy5oYXMoY3VycmVudFZhbGlkYXRvcikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfLnVwZGF0ZShwcm9wb3NlclZvdGVyU3RhdHMsIFtwcm9wb3NlckFkZHJlc3MsIGN1cnJlbnRWYWxpZGF0b3IsICdtaXNzQ291bnQnXSwgKG4pID0+IG4rMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa01pc3NlZFN0YXRzLmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGVyOiBjdXJyZW50VmFsaWRhdG9yLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja0hlaWdodDogYmxvY2suaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wb3NlcjogcHJvcG9zZXJBZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmVjb21taXRzQ291bnQ6IGJsb2NrLnByZWNvbW1pdHNDb3VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yc0NvdW50OiBibG9jay52YWxpZGF0b3JzQ291bnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpbWU6IGJsb2NrLnRpbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZWNvbW1pdHM6IGJsb2NrLnByZWNvbW1pdHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGJsb2NrLmF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpbWVEaWZmOiBibG9jay50aW1lRGlmZixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nUG93ZXI6IGJsb2NrLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90ZWRWb3RpbmdQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEF0OiBsYXRlc3RIZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pc3NDb3VudDogXy5nZXQocHJvcG9zZXJWb3RlclN0YXRzLCBbcHJvcG9zZXJBZGRyZXNzLCBjdXJyZW50VmFsaWRhdG9yLCAnbWlzc0NvdW50J10pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbENvdW50OiBfLmdldChwcm9wb3NlclZvdGVyU3RhdHMsIFtwcm9wb3NlckFkZHJlc3MsIGN1cnJlbnRWYWxpZGF0b3IsICd0b3RhbENvdW50J10pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICBfLmZvckVhY2gocHJvcG9zZXJWb3RlclN0YXRzLCAodm90ZXJzLCBwcm9wb3NlckFkZHJlc3MpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgXy5mb3JFYWNoKHZvdGVycywgKHN0YXRzLCB2b3RlckFkZHJlc3MpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtNaXNzZWRTdGF0cy5maW5kKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3Rlcjogdm90ZXJBZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2VyOiBwcm9wb3NlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tIZWlnaHQ6IC0xXG4gICAgICAgICAgICAgICAgICAgICAgICB9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3Rlcjogdm90ZXJBZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2VyOiBwcm9wb3NlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tIZWlnaHQ6IC0xLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRBdDogbGF0ZXN0SGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pc3NDb3VudDogXy5nZXQoc3RhdHMsICdtaXNzQ291bnQnKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbENvdW50OiBfLmdldChzdGF0cywgJ3RvdGFsQ291bnQnKVxuICAgICAgICAgICAgICAgICAgICAgICAgfX0pO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIGxldCBtZXNzYWdlID0gJyc7XG4gICAgICAgICAgICAgICAgaWYgKGJ1bGtNaXNzZWRTdGF0cy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY2xpZW50ID0gTWlzc2VkQmxvY2tzLl9kcml2ZXIubW9uZ28uY2xpZW50O1xuICAgICAgICAgICAgICAgICAgICAvLyBUT0RPOiBhZGQgdHJhbnNhY3Rpb24gYmFjayBhZnRlciByZXBsaWNhIHNldCgjMTQ2KSBpcyBzZXQgdXBcbiAgICAgICAgICAgICAgICAgICAgLy8gbGV0IHNlc3Npb24gPSBjbGllbnQuc3RhcnRTZXNzaW9uKCk7XG4gICAgICAgICAgICAgICAgICAgIC8vIHNlc3Npb24uc3RhcnRUcmFuc2FjdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgYnVsa1Byb21pc2UgPSBidWxrTWlzc2VkU3RhdHMuZXhlY3V0ZShudWxsLyosIHtzZXNzaW9ufSovKS50aGVuKFxuICAgICAgICAgICAgICAgICAgICAgICAgTWV0ZW9yLmJpbmRFbnZpcm9ubWVudCgocmVzdWx0LCBlcnIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1MgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUHJvbWlzZS5hd2FpdChzZXNzaW9uLmFib3J0VHJhbnNhY3Rpb24oKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFByb21pc2UuYXdhaXQoc2Vzc2lvbi5jb21taXRUcmFuc2FjdGlvbigpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZSA9IGAoJHtyZXN1bHQucmVzdWx0Lm5JbnNlcnRlZH0gaW5zZXJ0ZWQsIGAgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAke3Jlc3VsdC5yZXN1bHQublVwc2VydGVkfSB1cHNlcnRlZCwgYCArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYCR7cmVzdWx0LnJlc3VsdC5uTW9kaWZpZWR9IG1vZGlmaWVkKWA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgICAgICAgICAgICAgIFByb21pc2UuYXdhaXQoYnVsa1Byb21pc2UpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgU3RhdHVzLnVwc2VydCh7Y2hhaW5JZDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSwgeyRzZXQ6e2xhc3RQcm9jZXNzZWRNaXNzZWRCbG9ja0hlaWdodDpsYXRlc3RIZWlnaHQsIGxhc3RQcm9jZXNzZWRNaXNzZWRCbG9ja1RpbWU6IG5ldyBEYXRlKCl9fSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGBkb25lIGluICR7RGF0ZS5ub3coKSAtIHN0YXJ0VGltZX1tcyAke21lc3NhZ2V9YDtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLUyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIHJldHVybiBcInVwZGF0aW5nLi4uXCI7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdWYWxpZGF0b3JSZWNvcmRzLmNhbGN1bGF0ZU1pc3NlZEJsb2Nrc1N0YXRzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgLy8gVE9ETzogZGVwcmVjYXRlIHRoaXMgbWV0aG9kIGFuZCBNaXNzZWRCbG9ja3NTdGF0cyBjb2xsZWN0aW9uXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiVmFsaWRhdG9yUmVjb3Jkcy5jYWxjdWxhdGVNaXNzZWRCbG9ja3M6IFwiK0NPVU5UTUlTU0VEQkxPQ0tTKTtcbiAgICAgICAgaWYgKCFDT1VOVE1JU1NFREJMT0NLU1NUQVRTKXtcbiAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTU1RBVFMgPSB0cnVlO1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ2NhbHVsYXRlIG1pc3NlZCBibG9ja3Mgc3RhdHMnKTtcbiAgICAgICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICAgICAgbGV0IHZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe30pLmZldGNoKCk7XG4gICAgICAgICAgICBsZXQgbGF0ZXN0SGVpZ2h0ID0gTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5nZXRDdXJyZW50SGVpZ2h0Jyk7XG4gICAgICAgICAgICBsZXQgZXhwbG9yZXJTdGF0dXMgPSBTdGF0dXMuZmluZE9uZSh7Y2hhaW5JZDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSk7XG4gICAgICAgICAgICBsZXQgc3RhcnRIZWlnaHQgPSAoZXhwbG9yZXJTdGF0dXMmJmV4cGxvcmVyU3RhdHVzLmxhc3RNaXNzZWRCbG9ja0hlaWdodCk/ZXhwbG9yZXJTdGF0dXMubGFzdE1pc3NlZEJsb2NrSGVpZ2h0Ok1ldGVvci5zZXR0aW5ncy5wYXJhbXMuc3RhcnRIZWlnaHQ7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhsYXRlc3RIZWlnaHQpO1xuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coc3RhcnRIZWlnaHQpO1xuICAgICAgICAgICAgY29uc3QgYnVsa01pc3NlZFN0YXRzID0gTWlzc2VkQmxvY2tzU3RhdHMucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AoKTtcbiAgICAgICAgICAgIGZvciAoaSBpbiB2YWxpZGF0b3JzKXtcbiAgICAgICAgICAgICAgICAvLyBpZiAoKHZhbGlkYXRvcnNbaV0uYWRkcmVzcyA9PSBcIkI4NTUyRUFDMEQxMjNBNkJGNjA5MTIzMDQ3QTUxODFENDVFRTkwQjVcIikgfHwgKHZhbGlkYXRvcnNbaV0uYWRkcmVzcyA9PSBcIjY5RDk5QjJDNjYwNDNBQ0JFQUE4NDQ3NTI1QzM1NkFGQzY0MDhFMENcIikgfHwgKHZhbGlkYXRvcnNbaV0uYWRkcmVzcyA9PSBcIjM1QUQ3QTJDRDJGQzcxNzExQTY3NTgzMEVDMTE1ODA4MjI3M0Q0NTdcIikpe1xuICAgICAgICAgICAgICAgIGxldCB2b3RlckFkZHJlc3MgPSB2YWxpZGF0b3JzW2ldLmFkZHJlc3M7XG4gICAgICAgICAgICAgICAgbGV0IG1pc3NlZFJlY29yZHMgPSBWYWxpZGF0b3JSZWNvcmRzLmZpbmQoe1xuICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOnZvdGVyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgZXhpc3RzOmZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAkYW5kOiBbIHsgaGVpZ2h0OiB7ICRndDogc3RhcnRIZWlnaHQgfSB9LCB7IGhlaWdodDogeyAkbHRlOiBsYXRlc3RIZWlnaHQgfSB9IF1cbiAgICAgICAgICAgICAgICB9KS5mZXRjaCgpO1xuXG4gICAgICAgICAgICAgICAgbGV0IGNvdW50cyA9IHt9O1xuXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCJtaXNzZWRSZWNvcmRzIHRvIHByb2Nlc3M6IFwiK21pc3NlZFJlY29yZHMubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICBmb3IgKGIgaW4gbWlzc2VkUmVjb3Jkcyl7XG4gICAgICAgICAgICAgICAgICAgIGxldCBibG9jayA9IEJsb2Nrc2Nvbi5maW5kT25lKHtoZWlnaHQ6bWlzc2VkUmVjb3Jkc1tiXS5oZWlnaHR9KTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGV4aXN0aW5nUmVjb3JkID0gTWlzc2VkQmxvY2tzU3RhdHMuZmluZE9uZSh7dm90ZXI6dm90ZXJBZGRyZXNzLCBwcm9wb3NlcjpibG9jay5wcm9wb3NlckFkZHJlc3N9KTtcblxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGNvdW50c1tibG9jay5wcm9wb3NlckFkZHJlc3NdID09PSAndW5kZWZpbmVkJyl7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXhpc3RpbmdSZWNvcmQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50c1tibG9jay5wcm9wb3NlckFkZHJlc3NdID0gZXhpc3RpbmdSZWNvcmQuY291bnQrMTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY291bnRzW2Jsb2NrLnByb3Bvc2VyQWRkcmVzc10gPSAxO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb3VudHNbYmxvY2sucHJvcG9zZXJBZGRyZXNzXSsrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgZm9yIChhZGRyZXNzIGluIGNvdW50cyl7XG4gICAgICAgICAgICAgICAgICAgIGxldCBkYXRhID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdm90ZXI6IHZvdGVyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2VyOmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3VudDogY291bnRzW2FkZHJlc3NdXG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBidWxrTWlzc2VkU3RhdHMuZmluZCh7dm90ZXI6dm90ZXJBZGRyZXNzLCBwcm9wb3NlcjphZGRyZXNzfSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OmRhdGF9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gfVxuXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChidWxrTWlzc2VkU3RhdHMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgYnVsa01pc3NlZFN0YXRzLmV4ZWN1dGUoTWV0ZW9yLmJpbmRFbnZpcm9ubWVudCgoZXJyLCByZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLU1NUQVRTID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgU3RhdHVzLnVwc2VydCh7Y2hhaW5JZDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSwgeyRzZXQ6e2xhc3RNaXNzZWRCbG9ja0hlaWdodDpsYXRlc3RIZWlnaHQsIGxhc3RNaXNzZWRCbG9ja1RpbWU6IG5ldyBEYXRlKCl9fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLU1NUQVRTID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImRvbmVcIik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNle1xuICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTU1RBVFMgPSBmYWxzZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIHJldHVybiBcInVwZGF0aW5nLi4uXCI7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdBbmFseXRpY3MuYWdncmVnYXRlQmxvY2tUaW1lQW5kVm90aW5nUG93ZXInOiBmdW5jdGlvbih0aW1lKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCBub3cgPSBuZXcgRGF0ZSgpO1xuXG4gICAgICAgIGlmICh0aW1lID09ICdtJyl7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZUJsb2NrVGltZSA9IDA7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZVZvdGluZ1Bvd2VyID0gMDtcblxuICAgICAgICAgICAgbGV0IGFuYWx5dGljcyA9IEFuYWx5dGljcy5maW5kKHsgXCJ0aW1lXCI6IHsgJGd0OiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gNjAgKiAxMDAwKSB9IH0pLmZldGNoKCk7XG4gICAgICAgICAgICBpZiAoYW5hbHl0aWNzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgIGZvciAoaSBpbiBhbmFseXRpY3Mpe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lICs9IGFuYWx5dGljc1tpXS50aW1lRGlmZjtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyICs9IGFuYWx5dGljc1tpXS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgPSBhdmVyYWdlQmxvY2tUaW1lIC8gYW5hbHl0aWNzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgPSBhdmVyYWdlVm90aW5nUG93ZXIgLyBhbmFseXRpY3MubGVuZ3RoO1xuXG4gICAgICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0seyRzZXQ6e2xhc3RNaW51dGVWb3RpbmdQb3dlcjphdmVyYWdlVm90aW5nUG93ZXIsIGxhc3RNaW51dGVCbG9ja1RpbWU6YXZlcmFnZUJsb2NrVGltZX19KTtcbiAgICAgICAgICAgICAgICBBdmVyYWdlRGF0YS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lOiBhdmVyYWdlQmxvY2tUaW1lLFxuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXI6IGF2ZXJhZ2VWb3RpbmdQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogdGltZSxcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBub3dcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICh0aW1lID09ICdoJyl7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZUJsb2NrVGltZSA9IDA7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZVZvdGluZ1Bvd2VyID0gMDtcbiAgICAgICAgICAgIGxldCBhbmFseXRpY3MgPSBBbmFseXRpY3MuZmluZCh7IFwidGltZVwiOiB7ICRndDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDYwKjYwICogMTAwMCkgfSB9KS5mZXRjaCgpO1xuICAgICAgICAgICAgaWYgKGFuYWx5dGljcy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICBmb3IgKGkgaW4gYW5hbHl0aWNzKXtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSArPSBhbmFseXRpY3NbaV0udGltZURpZmY7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlciArPSBhbmFseXRpY3NbaV0udm90aW5nX3Bvd2VyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lID0gYXZlcmFnZUJsb2NrVGltZSAvIGFuYWx5dGljcy5sZW5ndGg7XG4gICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyID0gYXZlcmFnZVZvdGluZ1Bvd2VyIC8gYW5hbHl0aWNzLmxlbmd0aDtcblxuICAgICAgICAgICAgICAgIENoYWluLnVwZGF0ZSh7Y2hhaW5JZDpNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LHskc2V0OntsYXN0SG91clZvdGluZ1Bvd2VyOmF2ZXJhZ2VWb3RpbmdQb3dlciwgbGFzdEhvdXJCbG9ja1RpbWU6YXZlcmFnZUJsb2NrVGltZX19KTtcbiAgICAgICAgICAgICAgICBBdmVyYWdlRGF0YS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lOiBhdmVyYWdlQmxvY2tUaW1lLFxuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXI6IGF2ZXJhZ2VWb3RpbmdQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogdGltZSxcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBub3dcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRpbWUgPT0gJ2QnKXtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlQmxvY2tUaW1lID0gMDtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlVm90aW5nUG93ZXIgPSAwO1xuICAgICAgICAgICAgbGV0IGFuYWx5dGljcyA9IEFuYWx5dGljcy5maW5kKHsgXCJ0aW1lXCI6IHsgJGd0OiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gMjQqNjAqNjAgKiAxMDAwKSB9IH0pLmZldGNoKCk7XG4gICAgICAgICAgICBpZiAoYW5hbHl0aWNzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgIGZvciAoaSBpbiBhbmFseXRpY3Mpe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lICs9IGFuYWx5dGljc1tpXS50aW1lRGlmZjtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyICs9IGFuYWx5dGljc1tpXS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgPSBhdmVyYWdlQmxvY2tUaW1lIC8gYW5hbHl0aWNzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgPSBhdmVyYWdlVm90aW5nUG93ZXIgLyBhbmFseXRpY3MubGVuZ3RoO1xuXG4gICAgICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0seyRzZXQ6e2xhc3REYXlWb3RpbmdQb3dlcjphdmVyYWdlVm90aW5nUG93ZXIsIGxhc3REYXlCbG9ja1RpbWU6YXZlcmFnZUJsb2NrVGltZX19KTtcbiAgICAgICAgICAgICAgICBBdmVyYWdlRGF0YS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lOiBhdmVyYWdlQmxvY2tUaW1lLFxuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXI6IGF2ZXJhZ2VWb3RpbmdQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogdGltZSxcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBub3dcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gcmV0dXJuIGFuYWx5dGljcy5sZW5ndGg7XG4gICAgfSxcbiAgICAnQW5hbHl0aWNzLmFnZ3JlZ2F0ZVZhbGlkYXRvckRhaWx5QmxvY2tUaW1lJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB2YWxpZGF0b3JzID0gVmFsaWRhdG9ycy5maW5kKHt9KS5mZXRjaCgpO1xuICAgICAgICBsZXQgbm93ID0gbmV3IERhdGUoKTtcbiAgICAgICAgZm9yIChpIGluIHZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgbGV0IGF2ZXJhZ2VCbG9ja1RpbWUgPSAwO1xuXG4gICAgICAgICAgICBsZXQgYmxvY2tzID0gQmxvY2tzY29uLmZpbmQoe3Byb3Bvc2VyQWRkcmVzczp2YWxpZGF0b3JzW2ldLmFkZHJlc3MsIFwidGltZVwiOiB7ICRndDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDI0KjYwKjYwICogMTAwMCkgfX0sIHtmaWVsZHM6e2hlaWdodDoxfX0pLmZldGNoKCk7XG5cbiAgICAgICAgICAgIGlmIChibG9ja3MubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgbGV0IGJsb2NrSGVpZ2h0cyA9IFtdO1xuICAgICAgICAgICAgICAgIGZvciAoYiBpbiBibG9ja3Mpe1xuICAgICAgICAgICAgICAgICAgICBibG9ja0hlaWdodHMucHVzaChibG9ja3NbYl0uaGVpZ2h0KTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBsZXQgYW5hbHl0aWNzID0gQW5hbHl0aWNzLmZpbmQoe2hlaWdodDogeyRpbjpibG9ja0hlaWdodHN9fSwge2ZpZWxkczp7aGVpZ2h0OjEsdGltZURpZmY6MX19KS5mZXRjaCgpO1xuXG5cbiAgICAgICAgICAgICAgICBmb3IgKGEgaW4gYW5hbHl0aWNzKXtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSArPSBhbmFseXRpY3NbYV0udGltZURpZmY7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSA9IGF2ZXJhZ2VCbG9ja1RpbWUgLyBhbmFseXRpY3MubGVuZ3RoO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBBdmVyYWdlVmFsaWRhdG9yRGF0YS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgIHByb3Bvc2VyQWRkcmVzczogdmFsaWRhdG9yc1tpXS5hZGRyZXNzLFxuICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICAgICAgdHlwZTogJ1ZhbGlkYXRvckRhaWx5QXZlcmFnZUJsb2NrVGltZScsXG4gICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBub3dcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBWYWxpZGF0b3JSZWNvcmRzLCBBbmFseXRpY3MsIE1pc3NlZEJsb2NrcywgTWlzc2VkQmxvY2tzU3RhdHMsIFZQRGlzdHJpYnV0aW9ucyB9IGZyb20gJy4uL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5cbk1ldGVvci5wdWJsaXNoKCd2YWxpZGF0b3JfcmVjb3Jkcy5hbGwnLCBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIFZhbGlkYXRvclJlY29yZHMuZmluZCgpO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKCd2YWxpZGF0b3JfcmVjb3Jkcy51cHRpbWUnLCBmdW5jdGlvbihhZGRyZXNzLCBudW0pe1xuICAgIHJldHVybiBWYWxpZGF0b3JSZWNvcmRzLmZpbmQoe2FkZHJlc3M6YWRkcmVzc30se2xpbWl0Om51bSwgc29ydDp7aGVpZ2h0Oi0xfX0pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKCdhbmFseXRpY3MuaGlzdG9yeScsIGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuIEFuYWx5dGljcy5maW5kKHt9LHtzb3J0OntoZWlnaHQ6LTF9LGxpbWl0OjUwfSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ3ZwRGlzdHJpYnV0aW9uLmxhdGVzdCcsIGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuIFZQRGlzdHJpYnV0aW9ucy5maW5kKHt9LHtzb3J0OntoZWlnaHQ6LTF9LCBsaW1pdDoxfSk7XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgnbWlzc2VkYmxvY2tzLnZhbGlkYXRvcicsIGZ1bmN0aW9uKGFkZHJlc3MsIHR5cGUpe1xuICAgIGxldCBjb25kaXRpb25zID0ge307XG4gICAgaWYgKHR5cGUgPT0gJ3ZvdGVyJyl7XG4gICAgICAgIGNvbmRpdGlvbnMgPSB7XG4gICAgICAgICAgICB2b3RlcjogYWRkcmVzc1xuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2V7XG4gICAgICAgIGNvbmRpdGlvbnMgPSB7XG4gICAgICAgICAgICBwcm9wb3NlcjogYWRkcmVzc1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBNaXNzZWRCbG9ja3NTdGF0cy5maW5kKGNvbmRpdGlvbnMpXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZChzdGF0cyl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e2FkZHJlc3M6MSwgZGVzY3JpcHRpb246MSwgcHJvZmlsZV91cmw6MX19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgnbWlzc2VkcmVjb3Jkcy52YWxpZGF0b3InLCBmdW5jdGlvbihhZGRyZXNzLCB0eXBlKXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gTWlzc2VkQmxvY2tzLmZpbmQoXG4gICAgICAgICAgICAgICAge1t0eXBlXTogYWRkcmVzc30sXG4gICAgICAgICAgICAgICAge3NvcnQ6IHt1cGRhdGVkQXQ6IC0xfX1cbiAgICAgICAgICAgIClcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e2FkZHJlc3M6MSwgZGVzY3JpcHRpb246MSwgb3BlcmF0b3JfYWRkcmVzczoxfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycyc7XG5cbmV4cG9ydCBjb25zdCBWYWxpZGF0b3JSZWNvcmRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3ZhbGlkYXRvcl9yZWNvcmRzJyk7XG5leHBvcnQgY29uc3QgQW5hbHl0aWNzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2FuYWx5dGljcycpO1xuZXhwb3J0IGNvbnN0IE1pc3NlZEJsb2Nrc1N0YXRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ21pc3NlZF9ibG9ja3Nfc3RhdHMnKTtcbmV4cG9ydCBjb25zdCBNaXNzZWRCbG9ja3MgPSBuZXcgIE1vbmdvLkNvbGxlY3Rpb24oJ21pc3NlZF9ibG9ja3MnKTtcbmV4cG9ydCBjb25zdCBWUERpc3RyaWJ1dGlvbnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndm90aW5nX3Bvd2VyX2Rpc3RyaWJ1dGlvbnMnKTtcbmV4cG9ydCBjb25zdCBBdmVyYWdlRGF0YSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdhdmVyYWdlX2RhdGEnKTtcbmV4cG9ydCBjb25zdCBBdmVyYWdlVmFsaWRhdG9yRGF0YSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdhdmVyYWdlX3ZhbGlkYXRvcl9kYXRhJyk7XG5cbk1pc3NlZEJsb2Nrc1N0YXRzLmhlbHBlcnMoe1xuICAgIHByb3Bvc2VyTW9uaWtlcigpe1xuICAgICAgICBsZXQgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKHthZGRyZXNzOnRoaXMucHJvcG9zZXJ9KTtcbiAgICAgICAgcmV0dXJuICh2YWxpZGF0b3IuZGVzY3JpcHRpb24pP3ZhbGlkYXRvci5kZXNjcmlwdGlvbi5tb25pa2VyOnRoaXMucHJvcG9zZXI7XG4gICAgfSxcbiAgICB2b3Rlck1vbmlrZXIoKXtcbiAgICAgICAgbGV0IHZhbGlkYXRvciA9IFZhbGlkYXRvcnMuZmluZE9uZSh7YWRkcmVzczp0aGlzLnZvdGVyfSk7XG4gICAgICAgIHJldHVybiAodmFsaWRhdG9yLmRlc2NyaXB0aW9uKT92YWxpZGF0b3IuZGVzY3JpcHRpb24ubW9uaWtlcjp0aGlzLnZvdGVyO1xuICAgIH1cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFN0YXR1cyB9IGZyb20gJy4uL3N0YXR1cy5qcyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjaydcblxuTWV0ZW9yLnB1Ymxpc2goJ3N0YXR1cy5zdGF0dXMnLCBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIFN0YXR1cy5maW5kKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0pO1xufSk7XG5cbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IFN0YXR1cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdzdGF0dXMnKTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi8uLi90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnLi4vLi4vdm90aW5nLXBvd2VyL2hpc3RvcnkuanMnO1xuXG5jb25zdCBBZGRyZXNzTGVuZ3RoID0gNDA7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnVHJhbnNhY3Rpb25zLmluZGV4JzogZnVuY3Rpb24oaGFzaCwgYmxvY2tUaW1lKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGhhc2ggPSBoYXNoLnRvVXBwZXJDYXNlKCk7XG4gICAgICAgIGxldCB1cmwgPSBMQ0QrICcvdHhzLycraGFzaDtcbiAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgbGV0IHR4ID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcblxuICAgICAgICBjb25zb2xlLmxvZyhoYXNoKTtcblxuICAgICAgICB0eC5oZWlnaHQgPSBwYXJzZUludCh0eC5oZWlnaHQpO1xuXG4gICAgICAgIC8vIGlmICghdHguY29kZSl7XG4gICAgICAgIC8vICAgICBsZXQgbXNnID0gdHgudHgudmFsdWUubXNnO1xuICAgICAgICAvLyAgICAgZm9yIChsZXQgbSBpbiBtc2cpe1xuICAgICAgICAvLyAgICAgICAgIGlmIChtc2dbbV0udHlwZSA9PSBcImNvc21vcy1zZGsvTXNnQ3JlYXRlVmFsaWRhdG9yXCIpe1xuICAgICAgICAvLyAgICAgICAgICAgICBjb25zb2xlLmxvZyhtc2dbbV0udmFsdWUpO1xuICAgICAgICAvLyAgICAgICAgICAgICBsZXQgY29tbWFuZCA9IE1ldGVvci5zZXR0aW5ncy5iaW4uZ2FpYWRlYnVnK1wiIHB1YmtleSBcIittc2dbbV0udmFsdWUucHVia2V5O1xuICAgICAgICAvLyAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yID0ge1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgY29uc2Vuc3VzX3B1YmtleTogbXNnW21dLnZhbHVlLnB1YmtleSxcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBtc2dbbV0udmFsdWUuZGVzY3JpcHRpb24sXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBjb21taXNzaW9uOiBtc2dbbV0udmFsdWUuY29tbWlzc2lvbixcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIG1pbl9zZWxmX2RlbGVnYXRpb246IG1zZ1ttXS52YWx1ZS5taW5fc2VsZl9kZWxlZ2F0aW9uLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgb3BlcmF0b3JfYWRkcmVzczogbXNnW21dLnZhbHVlLnZhbGlkYXRvcl9hZGRyZXNzLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgZGVsZWdhdG9yX2FkZHJlc3M6IG1zZ1ttXS52YWx1ZS5kZWxlZ2F0b3JfYWRkcmVzcyxcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogTWF0aC5mbG9vcihwYXJzZUludChtc2dbbV0udmFsdWUudmFsdWUuYW1vdW50KSAvIDEwMDAwMDApXG4gICAgICAgIC8vICAgICAgICAgICAgIH1cblxuICAgICAgICAvLyAgICAgICAgICAgICBNZXRlb3IuY2FsbCgncnVuQ29kZScsIGNvbW1hbmQsIGZ1bmN0aW9uKGVycm9yLCByZXN1bHQpe1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFkZHJlc3MgPSByZXN1bHQubWF0Y2goL1xcc1swLTlBLUZdezQwfSQvaWdtKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHZhbGlkYXRvci5hZGRyZXNzID0gdmFsaWRhdG9yLmFkZHJlc3NbMF0udHJpbSgpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmhleCA9IHJlc3VsdC5tYXRjaCgvXFxzWzAtOUEtRl17NjR9JC9pZ20pO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmhleCA9IHZhbGlkYXRvci5oZXhbMF0udHJpbSgpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnB1Yl9rZXkgPSByZXN1bHQubWF0Y2goL3tcIi4qXCJ9L2lnbSk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHViX2tleSA9IEpTT04ucGFyc2UodmFsaWRhdG9yLnB1Yl9rZXlbMF0udHJpbSgpKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIGxldCByZSA9IG5ldyBSZWdFeHAoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhBY2NQdWIrXCIuKiRcIixcImlnbVwiKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHZhbGlkYXRvci5jb3Ntb3NhY2NwdWIgPSByZXN1bHQubWF0Y2gocmUpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmNvc21vc2FjY3B1YiA9IHZhbGlkYXRvci5jb3Ntb3NhY2NwdWJbMF0udHJpbSgpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgcmUgPSBuZXcgUmVnRXhwKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsUHViK1wiLiokXCIsXCJpZ21cIik7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gcmVzdWx0Lm1hdGNoKHJlKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXkgPSB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5WzBdLnRyaW0oKTtcblxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgVmFsaWRhdG9ycy51cHNlcnQoe2NvbnNlbnN1c19wdWJrZXk6bXNnW21dLnZhbHVlLnB1YmtleX0sdmFsaWRhdG9yKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIFZvdGluZ1Bvd2VySGlzdG9yeS5pbnNlcnQoe1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IHZhbGlkYXRvci5hZGRyZXNzLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgIHByZXZfdm90aW5nX3Bvd2VyOiAwLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogdmFsaWRhdG9yLnZvdGluZ19wb3dlcixcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICB0eXBlOiAnYWRkJyxcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IHR4LmhlaWdodCsyLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgIGJsb2NrX3RpbWU6IGJsb2NrVGltZVxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgIC8vICAgICAgICAgICAgIH0pXG4gICAgICAgIC8vICAgICAgICAgfVxuICAgICAgICAvLyAgICAgfVxuICAgICAgICAvLyB9XG5cblxuICAgICAgICBsZXQgdHhJZCA9IFRyYW5zYWN0aW9ucy5pbnNlcnQodHgpO1xuICAgICAgICBpZiAodHhJZCl7XG4gICAgICAgICAgICByZXR1cm4gdHhJZDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHJldHVybiBmYWxzZTtcbiAgICB9LFxuICAgICdUcmFuc2FjdGlvbnMuZmluZERlbGVnYXRpb24nOiBmdW5jdGlvbihhZGRyZXNzLCBoZWlnaHQpe1xuICAgICAgICAvLyBmb2xsb3dpbmcgY29zbW9zLXNkay94L3NsYXNoaW5nL3NwZWMvMDZfZXZlbnRzLm1kIGFuZCBjb3Ntb3Mtc2RrL3gvc3Rha2luZy9zcGVjLzA2X2V2ZW50cy5tZFxuICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQoe1xuICAgICAgICAgICAgJG9yOiBbeyRhbmQ6IFtcbiAgICAgICAgICAgICAgICB7XCJldmVudHMudHlwZVwiOiBcImRlbGVnYXRlXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOiBcInZhbGlkYXRvclwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOiBhZGRyZXNzfVxuICAgICAgICAgICAgXX0sIHskYW5kOltcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy5rZXlcIjogXCJhY3Rpb25cIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjogXCJ1bmphaWxcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCI6IFwic2VuZGVyXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6IGFkZHJlc3N9XG4gICAgICAgICAgICBdfSwgeyRhbmQ6W1xuICAgICAgICAgICAgICAgIHtcImV2ZW50cy50eXBlXCI6IFwiY3JlYXRlX3ZhbGlkYXRvclwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy5rZXlcIjogXCJ2YWxpZGF0b3JcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjogYWRkcmVzc31cbiAgICAgICAgICAgIF19LCB7JGFuZDpbXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLnR5cGVcIjogXCJ1bmJvbmRcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCI6IFwidmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6IGFkZHJlc3N9XG4gICAgICAgICAgICBdfSwgeyRhbmQ6W1xuICAgICAgICAgICAgICAgIHtcImV2ZW50cy50eXBlXCI6IFwicmVkZWxlZ2F0ZVwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy5rZXlcIjogXCJkZXN0aW5hdGlvbl92YWxpZGF0b3JcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjogYWRkcmVzc31cbiAgICAgICAgICAgIF19XSxcbiAgICAgICAgICAgIFwiY29kZVwiOiB7JGV4aXN0czogZmFsc2V9LFxuICAgICAgICAgICAgaGVpZ2h0OnskbHQ6aGVpZ2h0fX0sXG4gICAgICAgIHtzb3J0OntoZWlnaHQ6LTF9LFxuICAgICAgICAgICAgbGltaXQ6IDF9XG4gICAgICAgICkuZmV0Y2goKTtcbiAgICB9LFxuICAgICdUcmFuc2FjdGlvbnMuZmluZFVzZXInOiBmdW5jdGlvbihhZGRyZXNzLCBmaWVsZHM9bnVsbCl7XG4gICAgICAgIC8vIGFkZHJlc3MgaXMgZWl0aGVyIGRlbGVnYXRvciBhZGRyZXNzIG9yIHZhbGlkYXRvciBvcGVyYXRvciBhZGRyZXNzXG4gICAgICAgIGxldCB2YWxpZGF0b3I7XG4gICAgICAgIGlmICghZmllbGRzKVxuICAgICAgICAgICAgZmllbGRzID0ge2FkZHJlc3M6MSwgZGVzY3JpcHRpb246MSwgb3BlcmF0b3JfYWRkcmVzczoxLCBkZWxlZ2F0b3JfYWRkcmVzczoxfTtcbiAgICAgICAgaWYgKGFkZHJlc3MuaW5jbHVkZXMoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhWYWxBZGRyKSl7XG4gICAgICAgICAgICAvLyB2YWxpZGF0b3Igb3BlcmF0b3IgYWRkcmVzc1xuICAgICAgICAgICAgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKHtvcGVyYXRvcl9hZGRyZXNzOmFkZHJlc3N9LCB7ZmllbGRzfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoYWRkcmVzcy5pbmNsdWRlcyhNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY0FkZHIpKXtcbiAgICAgICAgICAgIC8vIGRlbGVnYXRvciBhZGRyZXNzXG4gICAgICAgICAgICB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe2RlbGVnYXRvcl9hZGRyZXNzOmFkZHJlc3N9LCB7ZmllbGRzfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoYWRkcmVzcy5sZW5ndGggPT09IEFkZHJlc3NMZW5ndGgpIHtcbiAgICAgICAgICAgIHZhbGlkYXRvciA9IFZhbGlkYXRvcnMuZmluZE9uZSh7YWRkcmVzczphZGRyZXNzfSwge2ZpZWxkc30pO1xuICAgICAgICB9XG4gICAgICAgIGlmICh2YWxpZGF0b3Ipe1xuICAgICAgICAgICAgcmV0dXJuIHZhbGlkYXRvcjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG5cbiAgICB9XG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgVHJhbnNhY3Rpb25zIH0gZnJvbSAnLi4vdHJhbnNhY3Rpb25zLmpzJztcbmltcG9ydCB7IEJsb2Nrc2NvbiB9IGZyb20gJy4uLy4uL2Jsb2Nrcy9ibG9ja3MuanMnO1xuXG5cbnB1Ymxpc2hDb21wb3NpdGUoJ3RyYW5zYWN0aW9ucy5saXN0JywgZnVuY3Rpb24obGltaXQgPSAzMCl7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIFRyYW5zYWN0aW9ucy5maW5kKHt9LHtzb3J0OntoZWlnaHQ6LTF9LCBsaW1pdDpsaW1pdH0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZCh0eCl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHtoZWlnaHQ6dHguaGVpZ2h0fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e3RpbWU6MSwgaGVpZ2h0OjF9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ3RyYW5zYWN0aW9ucy52YWxpZGF0b3InLCBmdW5jdGlvbih2YWxpZGF0b3JBZGRyZXNzLCBkZWxlZ2F0b3JBZGRyZXNzLCBsaW1pdD0xMDApe1xuICAgIGxldCBxdWVyeSA9IHt9O1xuICAgIGlmICh2YWxpZGF0b3JBZGRyZXNzICYmIGRlbGVnYXRvckFkZHJlc3Mpe1xuICAgICAgICBxdWVyeSA9IHskb3I6W3tcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6dmFsaWRhdG9yQWRkcmVzc30sIHtcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6ZGVsZWdhdG9yQWRkcmVzc31dfVxuICAgIH1cblxuICAgIGlmICghdmFsaWRhdG9yQWRkcmVzcyAmJiBkZWxlZ2F0b3JBZGRyZXNzKXtcbiAgICAgICAgcXVlcnkgPSB7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOmRlbGVnYXRvckFkZHJlc3N9XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIFRyYW5zYWN0aW9ucy5maW5kKHF1ZXJ5LCB7c29ydDp7aGVpZ2h0Oi0xfSwgbGltaXQ6bGltaXR9KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjpbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZCh0eCl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHtoZWlnaHQ6dHguaGVpZ2h0fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e3RpbWU6MSwgaGVpZ2h0OjF9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSlcblxucHVibGlzaENvbXBvc2l0ZSgndHJhbnNhY3Rpb25zLmZpbmRPbmUnLCBmdW5jdGlvbihoYXNoKXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQoe3R4aGFzaDpoYXNofSlcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHR4KXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2hlaWdodDp0eC5oZWlnaHR9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7dGltZToxLCBoZWlnaHQ6MX19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KVxuXG5wdWJsaXNoQ29tcG9zaXRlKCd0cmFuc2FjdGlvbnMuaGVpZ2h0JywgZnVuY3Rpb24oaGVpZ2h0KXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQoe2hlaWdodDpoZWlnaHR9KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQodHgpe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7aGVpZ2h0OnR4LmhlaWdodH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmllbGRzOnt0aW1lOjEsIGhlaWdodDoxfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vYmxvY2tzL2Jsb2Nrcy5qcyc7XG5pbXBvcnQgeyBUeEljb24gfSBmcm9tICcuLi8uLi91aS9jb21wb25lbnRzL0ljb25zLmpzeCc7XG5cbmV4cG9ydCBjb25zdCBUcmFuc2FjdGlvbnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndHJhbnNhY3Rpb25zJyk7XG5cblRyYW5zYWN0aW9ucy5oZWxwZXJzKHtcbiAgICBibG9jaygpe1xuICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmRPbmUoe2hlaWdodDp0aGlzLmhlaWdodH0pO1xuICAgIH1cbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi8uLi90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzJztcbmltcG9ydCB7IEJsb2Nrc2NvbiB9IGZyb20gJy4uLy4uL2Jsb2Nrcy9ibG9ja3MuanMnO1xuaW1wb3J0IHsgRGVsZWdhdGlvbnMgfSBmcm9tICcuLi8uLi9kZWxlZ2F0aW9ucy9kZWxlZ2F0aW9ucy5qcyc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnVmFsaWRhdG9ycy5maW5kQ3JlYXRlVmFsaWRhdG9yVGltZSc6IGZ1bmN0aW9uKGFkZHJlc3Mpe1xuICAgICAgICAvLyBsb29rIHVwIHRoZSBjcmVhdGUgdmFsaWRhdG9yIHRpbWUgdG8gY29uc2lkZXIgaWYgdGhlIHZhbGlkYXRvciBoYXMgbmV2ZXIgdXBkYXRlZCB0aGUgY29tbWlzc2lvblxuICAgICAgICBsZXQgdHggPSBUcmFuc2FjdGlvbnMuZmluZE9uZSh7JGFuZDpbXG4gICAgICAgICAgICB7XCJ0eC52YWx1ZS5tc2cudmFsdWUuZGVsZWdhdG9yX2FkZHJlc3NcIjphZGRyZXNzfSxcbiAgICAgICAgICAgIHtcInR4LnZhbHVlLm1zZy50eXBlXCI6XCJjb3Ntb3Mtc2RrL01zZ0NyZWF0ZVZhbGlkYXRvclwifSxcbiAgICAgICAgICAgIHtjb2RlOnskZXhpc3RzOmZhbHNlfX1cbiAgICAgICAgXX0pO1xuXG4gICAgICAgIGlmICh0eCl7XG4gICAgICAgICAgICBsZXQgYmxvY2sgPSBCbG9ja3Njb24uZmluZE9uZSh7aGVpZ2h0OnR4LmhlaWdodH0pO1xuICAgICAgICAgICAgaWYgKGJsb2NrKXtcbiAgICAgICAgICAgICAgICByZXR1cm4gYmxvY2sudGltZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgLy8gbm8gc3VjaCBjcmVhdGUgdmFsaWRhdG9yIHR4XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIC8vIGFzeW5jICdWYWxpZGF0b3JzLmdldEFsbERlbGVnYXRpb25zJyhhZGRyZXNzKXtcbiAgICAnVmFsaWRhdG9ycy5nZXRBbGxEZWxlZ2F0aW9ucycoYWRkcmVzcyl7XG4gICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL3N0YWtpbmcvdmFsaWRhdG9ycy8nK2FkZHJlc3MrJy9kZWxlZ2F0aW9ucyc7XG5cbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IGRlbGVnYXRpb25zID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmIChkZWxlZ2F0aW9ucy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgZGVsZWdhdGlvbnMgPSBKU09OLnBhcnNlKGRlbGVnYXRpb25zLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICBkZWxlZ2F0aW9ucy5mb3JFYWNoKChkZWxlZ2F0aW9uLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChkZWxlZ2F0aW9uc1tpXSAmJiBkZWxlZ2F0aW9uc1tpXS5zaGFyZXMpXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWxlZ2F0aW9uc1tpXS5zaGFyZXMgPSBwYXJzZUZsb2F0KGRlbGVnYXRpb25zW2ldLnNoYXJlcyk7XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICByZXR1cm4gZGVsZWdhdGlvbnM7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG4gICAgfVxufSk7IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JSZWNvcmRzIH0gZnJvbSAnLi4vLi4vcmVjb3Jkcy9yZWNvcmRzLmpzJztcbmltcG9ydCB7IFZvdGluZ1Bvd2VySGlzdG9yeSB9IGZyb20gJy4uLy4uL3ZvdGluZy1wb3dlci9oaXN0b3J5LmpzJztcblxuTWV0ZW9yLnB1Ymxpc2goJ3ZhbGlkYXRvcnMuYWxsJywgZnVuY3Rpb24gKHNvcnQgPSBcImRlc2NyaXB0aW9uLm1vbmlrZXJcIiwgZGlyZWN0aW9uID0gLTEsIGZpZWxkcz17fSkge1xuICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoe30sIHtzb3J0OiB7W3NvcnRdOiBkaXJlY3Rpb259LCBmaWVsZHM6IGZpZWxkc30pO1xufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ3ZhbGlkYXRvcnMuZmlyc3RTZWVuJyx7XG4gICAgZmluZCgpIHtcbiAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZCh7fSk7XG4gICAgfSxcbiAgICBjaGlsZHJlbjogW1xuICAgICAgICB7XG4gICAgICAgICAgICBmaW5kKHZhbCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JSZWNvcmRzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgIHsgYWRkcmVzczogdmFsLmFkZHJlc3MgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBzb3J0OiB7aGVpZ2h0OiAxfSwgbGltaXQ6IDF9XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIF1cbn0pO1xuXG5NZXRlb3IucHVibGlzaCgndmFsaWRhdG9ycy52b3RpbmdfcG93ZXInLCBmdW5jdGlvbigpe1xuICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoe1xuICAgICAgICBzdGF0dXM6IDIsXG4gICAgICAgIGphaWxlZDpmYWxzZVxuICAgIH0se1xuICAgICAgICBzb3J0OntcbiAgICAgICAgICAgIHZvdGluZ19wb3dlcjotMVxuICAgICAgICB9LFxuICAgICAgICBmaWVsZHM6e1xuICAgICAgICAgICAgYWRkcmVzczogMSxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOjEsXG4gICAgICAgICAgICB2b3RpbmdfcG93ZXI6MSxcbiAgICAgICAgICAgIHByb2ZpbGVfdXJsOjFcbiAgICAgICAgfVxuICAgIH1cbiAgICApO1xufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ3ZhbGlkYXRvci5kZXRhaWxzJywgZnVuY3Rpb24oYWRkcmVzcyl7XG4gICAgbGV0IG9wdGlvbnMgPSB7YWRkcmVzczphZGRyZXNzfTtcbiAgICBpZiAoYWRkcmVzcy5pbmRleE9mKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsQWRkcikgIT0gLTEpe1xuICAgICAgICBvcHRpb25zID0ge29wZXJhdG9yX2FkZHJlc3M6YWRkcmVzc31cbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChvcHRpb25zKVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQodmFsKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZvdGluZ1Bvd2VySGlzdG9yeS5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2FkZHJlc3M6dmFsLmFkZHJlc3N9LFxuICAgICAgICAgICAgICAgICAgICAgICAge3NvcnQ6e2hlaWdodDotMX0sIGxpbWl0OjUwfVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHZhbCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVmFsaWRhdG9yUmVjb3Jkcy5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBhZGRyZXNzOiB2YWwuYWRkcmVzcyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBzb3J0OiB7aGVpZ2h0OiAtMX0sIGxpbWl0OiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLnVwdGltZVdpbmRvd31cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMgfSBmcm9tICcuLi9yZWNvcmRzL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnLi4vdm90aW5nLXBvd2VyL2hpc3RvcnkuanMnO1xuXG5leHBvcnQgY29uc3QgVmFsaWRhdG9ycyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd2YWxpZGF0b3JzJyk7XG5cblZhbGlkYXRvcnMuaGVscGVycyh7XG4gICAgZmlyc3RTZWVuKCl7XG4gICAgICAgIHJldHVybiBWYWxpZGF0b3JSZWNvcmRzLmZpbmRPbmUoe2FkZHJlc3M6dGhpcy5hZGRyZXNzfSk7XG4gICAgfSxcbiAgICBoaXN0b3J5KCl7XG4gICAgICAgIHJldHVybiBWb3RpbmdQb3dlckhpc3RvcnkuZmluZCh7YWRkcmVzczp0aGlzLmFkZHJlc3N9LCB7c29ydDp7aGVpZ2h0Oi0xfSwgbGltaXQ6NTB9KS5mZXRjaCgpO1xuICAgIH1cbn0pXG4vLyBWYWxpZGF0b3JzLmhlbHBlcnMoe1xuLy8gICAgIHVwdGltZSgpe1xuLy8gICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLmFkZHJlc3MpO1xuLy8gICAgICAgICBsZXQgbGFzdEh1bmRyZWQgPSBWYWxpZGF0b3JSZWNvcmRzLmZpbmQoe2FkZHJlc3M6dGhpcy5hZGRyZXNzfSwge3NvcnQ6e2hlaWdodDotMX0sIGxpbWl0OjEwMH0pLmZldGNoKCk7XG4vLyAgICAgICAgIGNvbnNvbGUubG9nKGxhc3RIdW5kcmVkKTtcbi8vICAgICAgICAgbGV0IHVwdGltZSA9IDA7XG4vLyAgICAgICAgIGZvciAoaSBpbiBsYXN0SHVuZHJlZCl7XG4vLyAgICAgICAgICAgICBpZiAobGFzdEh1bmRyZWRbaV0uZXhpc3RzKXtcbi8vICAgICAgICAgICAgICAgICB1cHRpbWUrPTE7XG4vLyAgICAgICAgICAgICB9XG4vLyAgICAgICAgIH1cbi8vICAgICAgICAgcmV0dXJuIHVwdGltZTtcbi8vICAgICB9XG4vLyB9KSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IFZvdGluZ1Bvd2VySGlzdG9yeSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd2b3RpbmdfcG93ZXJfaGlzdG9yeScpO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgRXZpZGVuY2VzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2V2aWRlbmNlcycpO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgVmFsaWRhdG9yU2V0cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd2YWxpZGF0b3Jfc2V0cycpO1xuIiwiLy8gSW1wb3J0IG1vZHVsZXMgdXNlZCBieSBib3RoIGNsaWVudCBhbmQgc2VydmVyIHRocm91Z2ggYSBzaW5nbGUgaW5kZXggZW50cnkgcG9pbnRcbi8vIGUuZy4gdXNlcmFjY291bnRzIGNvbmZpZ3VyYXRpb24gZmlsZS5cbiIsImltcG9ydCB7IEJsb2Nrc2NvbiB9IGZyb20gJy4uLy4uL2FwaS9ibG9ja3MvYmxvY2tzLmpzJztcbi8vaW1wb3J0IHsgUHJvcG9zYWxzIH0gZnJvbSAnLi4vLi4vYXBpL3Byb3Bvc2Fscy9wcm9wb3NhbHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9yUmVjb3JkcywgQW5hbHl0aWNzLCBNaXNzZWRCbG9ja3NTdGF0cywgTWlzc2VkQmxvY2tzLCBBdmVyYWdlRGF0YSwgQXZlcmFnZVZhbGlkYXRvckRhdGEgfSBmcm9tICcuLi8uLi9hcGkvcmVjb3Jkcy9yZWNvcmRzLmpzJztcbi8vIGltcG9ydCB7IFN0YXR1cyB9IGZyb20gJy4uLy4uL2FwaS9zdGF0dXMvc3RhdHVzLmpzJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uLy4uL2FwaS90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclNldHMgfSBmcm9tICcuLi8uLi9hcGkvdmFsaWRhdG9yLXNldHMvdmFsaWRhdG9yLXNldHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL2FwaS92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnLi4vLi4vYXBpL3ZvdGluZy1wb3dlci9oaXN0b3J5LmpzJztcbmltcG9ydCB7IEV2aWRlbmNlcyB9IGZyb20gJy4uLy4uL2FwaS9ldmlkZW5jZXMvZXZpZGVuY2VzLmpzJztcbmltcG9ydCB7IENvaW5TdGF0cyB9IGZyb20gJy4uLy4uL2FwaS9jb2luLXN0YXRzL2NvaW4tc3RhdHMuanMnO1xuaW1wb3J0IHsgQ2hhaW5TdGF0ZXMgfSBmcm9tICcuLi8uLi9hcGkvY2hhaW4vY2hhaW4uanMnO1xuXG5DaGFpblN0YXRlcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2hlaWdodDogLTF9LHt1bmlxdWU6dHJ1ZX0pO1xuXG5CbG9ja3Njb24ucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtoZWlnaHQ6IC0xfSx7dW5pcXVlOnRydWV9KTtcbkJsb2Nrc2Nvbi5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2VyQWRkcmVzczoxfSk7XG5cbkV2aWRlbmNlcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2hlaWdodDogLTF9KTtcblxuLy9Qcm9wb3NhbHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NhbElkOiAxfSwge3VuaXF1ZTp0cnVlfSk7XG5cblZhbGlkYXRvclJlY29yZHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHthZGRyZXNzOjEsaGVpZ2h0OiAtMX0sIHt1bmlxdWU6MX0pO1xuVmFsaWRhdG9yUmVjb3Jkcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2FkZHJlc3M6MSxleGlzdHM6MSwgaGVpZ2h0OiAtMX0pO1xuXG5BbmFseXRpY3MucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtoZWlnaHQ6IC0xfSwge3VuaXF1ZTp0cnVlfSlcblxuTWlzc2VkQmxvY2tzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7cHJvcG9zZXI6MSwgdm90ZXI6MSwgdXBkYXRlZEF0OiAtMX0pO1xuTWlzc2VkQmxvY2tzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7cHJvcG9zZXI6MSwgYmxvY2tIZWlnaHQ6LTF9KTtcbk1pc3NlZEJsb2Nrcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3ZvdGVyOjEsIGJsb2NrSGVpZ2h0Oi0xfSk7XG5NaXNzZWRCbG9ja3MucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHt2b3RlcjoxLCBwcm9wb3NlcjoxLCBibG9ja0hlaWdodDotMX0sIHt1bmlxdWU6dHJ1ZX0pO1xuXG5NaXNzZWRCbG9ja3NTdGF0cy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2VyOjF9KTtcbk1pc3NlZEJsb2Nrc1N0YXRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7dm90ZXI6MX0pO1xuTWlzc2VkQmxvY2tzU3RhdHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NlcjoxLCB2b3RlcjoxfSx7dW5pcXVlOnRydWV9KTtcblxuQXZlcmFnZURhdGEucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHt0eXBlOjEsIGNyZWF0ZWRBdDotMX0se3VuaXF1ZTp0cnVlfSk7XG5BdmVyYWdlVmFsaWRhdG9yRGF0YS5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2VyQWRkcmVzczoxLGNyZWF0ZWRBdDotMX0se3VuaXF1ZTp0cnVlfSk7XG4vLyBTdGF0dXMucmF3Q29sbGVjdGlvbi5jcmVhdGVJbmRleCh7fSlcblxuVHJhbnNhY3Rpb25zLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7dHhoYXNoOjF9LHt1bmlxdWU6dHJ1ZX0pO1xuVHJhbnNhY3Rpb25zLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7aGVpZ2h0Oi0xfSk7XG4vLyBUcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHthY3Rpb246MX0pO1xuVHJhbnNhY3Rpb25zLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7XCJldmVudHMuYXR0cmlidXRlcy5rZXlcIjoxfSk7XG5UcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6MX0pO1xuXG5WYWxpZGF0b3JTZXRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7YmxvY2tfaGVpZ2h0Oi0xfSk7XG5cblZhbGlkYXRvcnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHthZGRyZXNzOjF9LHt1bmlxdWU6dHJ1ZSwgcGFydGlhbEZpbHRlckV4cHJlc3Npb246IHsgYWRkcmVzczogeyAkZXhpc3RzOiB0cnVlIH0gfSB9KTtcblZhbGlkYXRvcnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtjb25zZW5zdXNfcHVia2V5OjF9LHt1bmlxdWU6dHJ1ZX0pO1xuVmFsaWRhdG9ycy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe1wicHViX2tleS52YWx1ZVwiOjF9LHt1bmlxdWU6dHJ1ZSwgcGFydGlhbEZpbHRlckV4cHJlc3Npb246IHsgXCJwdWJfa2V5LnZhbHVlXCI6IHsgJGV4aXN0czogdHJ1ZSB9IH19KTtcblxuVm90aW5nUG93ZXJIaXN0b3J5LnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7YWRkcmVzczoxLGhlaWdodDotMX0pO1xuVm90aW5nUG93ZXJIaXN0b3J5LnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7dHlwZToxfSk7XG5cbkNvaW5TdGF0cy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2xhc3RfdXBkYXRlZF9hdDotMX0se3VuaXF1ZTp0cnVlfSk7XG4iLCIvLyBJbXBvcnQgc2VydmVyIHN0YXJ0dXAgdGhyb3VnaCBhIHNpbmdsZSBpbmRleCBlbnRyeSBwb2ludFxuXG5pbXBvcnQgJy4vdXRpbC5qcyc7XG5pbXBvcnQgJy4vcmVnaXN0ZXItYXBpLmpzJztcbmltcG9ydCAnLi9jcmVhdGUtaW5kZXhlcy5qcyc7XG5cbi8vIGltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG4vLyBpbXBvcnQgeyByZW5kZXJUb05vZGVTdHJlYW0gfSBmcm9tICdyZWFjdC1kb20vc2VydmVyJztcbi8vIGltcG9ydCB7IHJlbmRlclRvU3RyaW5nIH0gZnJvbSBcInJlYWN0LWRvbS9zZXJ2ZXJcIjtcbmltcG9ydCB7IG9uUGFnZUxvYWQgfSBmcm9tICdtZXRlb3Ivc2VydmVyLXJlbmRlcic7XG4vLyBpbXBvcnQgeyBTdGF0aWNSb3V0ZXIgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbi8vIGltcG9ydCB7IFNlcnZlclN0eWxlU2hlZXQgfSBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIlxuaW1wb3J0IHsgSGVsbWV0IH0gZnJvbSAncmVhY3QtaGVsbWV0JztcblxuLy8gaW1wb3J0IEFwcCBmcm9tICcuLi8uLi91aS9BcHAuanN4Jztcblxub25QYWdlTG9hZChzaW5rID0+IHtcbiAgICAvLyBjb25zdCBjb250ZXh0ID0ge307XG4gICAgLy8gY29uc3Qgc2hlZXQgPSBuZXcgU2VydmVyU3R5bGVTaGVldCgpXG5cbiAgICAvLyBjb25zdCBodG1sID0gcmVuZGVyVG9TdHJpbmcoc2hlZXQuY29sbGVjdFN0eWxlcyhcbiAgICAvLyAgICAgPFN0YXRpY1JvdXRlciBsb2NhdGlvbj17c2luay5yZXF1ZXN0LnVybH0gY29udGV4dD17Y29udGV4dH0+XG4gICAgLy8gICAgICAgICA8QXBwIC8+XG4gICAgLy8gICAgIDwvU3RhdGljUm91dGVyPlxuICAgIC8vICAgKSk7XG5cbiAgICAvLyBzaW5rLnJlbmRlckludG9FbGVtZW50QnlJZCgnYXBwJywgaHRtbCk7XG5cbiAgICBjb25zdCBoZWxtZXQgPSBIZWxtZXQucmVuZGVyU3RhdGljKCk7XG4gICAgc2luay5hcHBlbmRUb0hlYWQoaGVsbWV0Lm1ldGEudG9TdHJpbmcoKSk7XG4gICAgc2luay5hcHBlbmRUb0hlYWQoaGVsbWV0LnRpdGxlLnRvU3RyaW5nKCkpO1xuXG4gICAgLy8gc2luay5hcHBlbmRUb0hlYWQoc2hlZXQuZ2V0U3R5bGVUYWdzKCkpO1xufSk7IiwiLy8gUmVnaXN0ZXIgeW91ciBhcGlzIGhlcmVcblxuaW1wb3J0ICcuLi8uLi9hcGkvbGVkZ2VyL3NlcnZlci9tZXRob2RzLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvY2hhaW4vc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvY2hhaW4vc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL2Jsb2Nrcy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9ibG9ja3Mvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL3ZhbGlkYXRvcnMvc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvdmFsaWRhdG9ycy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvcmVjb3Jkcy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9yZWNvcmRzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG4vL2ltcG9ydCAnLi4vLi4vYXBpL3Byb3Bvc2Fscy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG4vL2ltcG9ydCAnLi4vLi4vYXBpL3Byb3Bvc2Fscy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL2VudGVycHJpc2Uvc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvZW50ZXJwcmlzZS9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvdm90aW5nLXBvd2VyL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS90cmFuc2FjdGlvbnMvc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvdHJhbnNhY3Rpb25zL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9kZWxlZ2F0aW9ucy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9kZWxlZ2F0aW9ucy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvc3RhdHVzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9hY2NvdW50cy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL2NvaW4tc3RhdHMvc2VydmVyL21ldGhvZHMuanMnO1xuIiwiaW1wb3J0IGJlY2gzMiBmcm9tICdiZWNoMzInXG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuaW1wb3J0ICogYXMgY2hlZXJpbyBmcm9tICdjaGVlcmlvJztcblxuLy8gTG9hZCBmdXR1cmUgZnJvbSBmaWJlcnNcbnZhciBGdXR1cmUgPSBOcG0ucmVxdWlyZShcImZpYmVycy9mdXR1cmVcIik7XG4vLyBMb2FkIGV4ZWNcbnZhciBleGVjID0gTnBtLnJlcXVpcmUoXCJjaGlsZF9wcm9jZXNzXCIpLmV4ZWM7XG5cbmZ1bmN0aW9uIHRvSGV4U3RyaW5nKGJ5dGVBcnJheSkge1xuICAgIHJldHVybiBieXRlQXJyYXkubWFwKGZ1bmN0aW9uKGJ5dGUpIHtcbiAgICAgICAgcmV0dXJuICgnMCcgKyAoYnl0ZSAmIDB4RkYpLnRvU3RyaW5nKDE2KSkuc2xpY2UoLTIpO1xuICAgIH0pLmpvaW4oJycpXG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICBwdWJrZXlUb0JlY2gzMjogZnVuY3Rpb24ocHVia2V5LCBwcmVmaXgpIHtcbiAgICAgICAgLy8gJzE2MjRERTY0MjAnIGlzIGVkMjU1MTkgcHVia2V5IHByZWZpeFxuICAgICAgICBsZXQgcHVia2V5QW1pbm9QcmVmaXggPSBCdWZmZXIuZnJvbSgnMTYyNERFNjQyMCcsICdoZXgnKVxuICAgICAgICBsZXQgYnVmZmVyID0gQnVmZmVyLmFsbG9jKDM3KVxuICAgICAgICBwdWJrZXlBbWlub1ByZWZpeC5jb3B5KGJ1ZmZlciwgMClcbiAgICAgICAgQnVmZmVyLmZyb20ocHVia2V5LnZhbHVlLCAnYmFzZTY0JykuY29weShidWZmZXIsIHB1YmtleUFtaW5vUHJlZml4Lmxlbmd0aClcbiAgICAgICAgcmV0dXJuIGJlY2gzMi5lbmNvZGUocHJlZml4LCBiZWNoMzIudG9Xb3JkcyhidWZmZXIpKVxuICAgIH0sXG4gICAgYmVjaDMyVG9QdWJrZXk6IGZ1bmN0aW9uKHB1YmtleSkge1xuICAgICAgICAvLyAnMTYyNERFNjQyMCcgaXMgZWQyNTUxOSBwdWJrZXkgcHJlZml4XG4gICAgICAgIGxldCBwdWJrZXlBbWlub1ByZWZpeCA9IEJ1ZmZlci5mcm9tKCcxNjI0REU2NDIwJywgJ2hleCcpXG4gICAgICAgIGxldCBidWZmZXIgPSBCdWZmZXIuZnJvbShiZWNoMzIuZnJvbVdvcmRzKGJlY2gzMi5kZWNvZGUocHVia2V5KS53b3JkcykpO1xuICAgICAgICByZXR1cm4gYnVmZmVyLnNsaWNlKHB1YmtleUFtaW5vUHJlZml4Lmxlbmd0aCkudG9TdHJpbmcoJ2Jhc2U2NCcpO1xuICAgIH0sXG4gICAgZ2V0RGVsZWdhdG9yOiBmdW5jdGlvbihvcGVyYXRvckFkZHIpe1xuICAgICAgICBsZXQgYWRkcmVzcyA9IGJlY2gzMi5kZWNvZGUob3BlcmF0b3JBZGRyKTtcbiAgICAgICAgcmV0dXJuIGJlY2gzMi5lbmNvZGUoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhBY2NBZGRyLCBhZGRyZXNzLndvcmRzKTtcbiAgICB9LFxuICAgIGdldEtleWJhc2VUZWFtUGljOiBmdW5jdGlvbihrZXliYXNlVXJsKXtcbiAgICAgICAgbGV0IHRlYW1QYWdlID0gSFRUUC5nZXQoa2V5YmFzZVVybCk7XG4gICAgICAgIGlmICh0ZWFtUGFnZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICBsZXQgcGFnZSA9IGNoZWVyaW8ubG9hZCh0ZWFtUGFnZS5jb250ZW50KTtcbiAgICAgICAgICAgIHJldHVybiBwYWdlKFwiLmtiLW1haW4tY2FyZCBpbWdcIikuYXR0cignc3JjJyk7XG4gICAgICAgIH1cbiAgICB9XG59KVxuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFVuY29udHJvbGxlZFRvb2x0aXAgfSBmcm9tICdyZWFjdHN0cmFwJztcblxuZXhwb3J0IGNvbnN0IERlbm9tU3ltYm9sID0gKHByb3BzKSA9PiB7XG4gICAgc3dpdGNoIChwcm9wcy5kZW5vbSl7XG4gICAgY2FzZSBcInN0ZWFrXCI6XG4gICAgICAgIHJldHVybiAn8J+lqSc7XG4gICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuICfwn42FJztcbiAgICB9XG59XG5cblxuZXhwb3J0IGNvbnN0IFByb3Bvc2FsU3RhdHVzSWNvbiA9IChwcm9wcykgPT4ge1xuICAgIHN3aXRjaCAocHJvcHMuc3RhdHVzKXtcbiAgICBjYXNlICdQYXNzZWQnOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLWNoZWNrLWNpcmNsZSB0ZXh0LXN1Y2Nlc3NcIj48L2k+O1xuICAgIGNhc2UgJ1JlamVjdGVkJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS10aW1lcy1jaXJjbGUgdGV4dC1kYW5nZXJcIj48L2k+O1xuICAgIGNhc2UgJ1JlbW92ZWQnOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLXRyYXNoLWFsdCB0ZXh0LWRhcmtcIj48L2k+XG4gICAgY2FzZSAnRGVwb3NpdFBlcmlvZCc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtYmF0dGVyeS1oYWxmIHRleHQtd2FybmluZ1wiPjwvaT47XG4gICAgY2FzZSAnVm90aW5nUGVyaW9kJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1oYW5kLXBhcGVyIHRleHQtaW5mb1wiPjwvaT47XG4gICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIDxpPjwvaT47XG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgVm90ZUljb24gPSAocHJvcHMpID0+IHtcbiAgICBzd2l0Y2ggKHByb3BzLnZvdGUpe1xuICAgIGNhc2UgJ3llcyc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtY2hlY2sgdGV4dC1zdWNjZXNzXCI+PC9pPjtcbiAgICBjYXNlICdubyc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtdGltZXMgdGV4dC1kYW5nZXJcIj48L2k+O1xuICAgIGNhc2UgJ2Fic3RhaW4nOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLXVzZXItc2xhc2ggdGV4dC13YXJuaW5nXCI+PC9pPjtcbiAgICBjYXNlICdub193aXRoX3ZldG8nOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLWV4Y2xhbWF0aW9uLXRyaWFuZ2xlIHRleHQtaW5mb1wiPjwvaT47XG4gICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIDxpPjwvaT47XG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgVHhJY29uID0gKHByb3BzKSA9PiB7XG4gICAgaWYgKHByb3BzLnZhbGlkKXtcbiAgICAgICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc3VjY2VzcyB0ZXh0LW5vd3JhcFwiPjxpIGNsYXNzTmFtZT1cImZhcyBmYS1jaGVjay1jaXJjbGVcIj48L2k+PC9zcGFuPjtcbiAgICB9XG4gICAgZWxzZXtcbiAgICAgICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZGFuZ2VyIHRleHQtbm93cmFwXCI+PGkgY2xhc3NOYW1lPVwiZmFzIGZhLXRpbWVzLWNpcmNsZVwiPjwvaT48L3NwYW4+O1xuICAgIH1cbn1cblxuZXhwb3J0IGNsYXNzIEluZm9JY29uIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50IHtcbiAgICBjb25zdHJ1Y3Rvcihwcm9wcykge1xuICAgICAgICBzdXBlcihwcm9wcyk7XG4gICAgICAgIHRoaXMucmVmID0gUmVhY3QuY3JlYXRlUmVmKCk7XG4gICAgfVxuXG4gICAgcmVuZGVyKCkge1xuICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgPGkga2V5PSdpY29uJyBjbGFzc05hbWU9J21hdGVyaWFsLWljb25zIGluZm8taWNvbicgcmVmPXt0aGlzLnJlZn0+aW5mbzwvaT4sXG4gICAgICAgICAgICA8VW5jb250cm9sbGVkVG9vbHRpcCBrZXk9J3Rvb2x0aXAnIHBsYWNlbWVudD0ncmlnaHQnIHRhcmdldD17dGhpcy5yZWZ9PlxuICAgICAgICAgICAgICAgIHt0aGlzLnByb3BzLmNoaWxkcmVuP3RoaXMucHJvcHMuY2hpbGRyZW46dGhpcy5wcm9wcy50b29sdGlwVGV4dH1cbiAgICAgICAgICAgIDwvVW5jb250cm9sbGVkVG9vbHRpcD5cbiAgICAgICAgXVxuICAgIH1cbn0iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCBudW1icm8gZnJvbSAnbnVtYnJvJztcblxuYXV0b2Zvcm1hdCA9ICh2YWx1ZSkgPT4ge1xuXHRsZXQgZm9ybWF0dGVyID0gJzAsMC4wMDAwJztcblx0dmFsdWUgPSBNYXRoLnJvdW5kKHZhbHVlICogMTAwMCkgLyAxMDAwXG5cdGlmIChNYXRoLnJvdW5kKHZhbHVlKSA9PT0gdmFsdWUpXG5cdFx0Zm9ybWF0dGVyID0gJzAsMCdcblx0ZWxzZSBpZiAoTWF0aC5yb3VuZCh2YWx1ZSoxMCkgPT09IHZhbHVlKjEwKVxuXHRcdGZvcm1hdHRlciA9ICcwLDAuMCdcblx0ZWxzZSBpZiAoTWF0aC5yb3VuZCh2YWx1ZSoxMDApID09PSB2YWx1ZSoxMDApXG5cdFx0Zm9ybWF0dGVyID0gJzAsMC4wMCdcblx0ZWxzZSBpZiAoTWF0aC5yb3VuZCh2YWx1ZSoxMDAwKSA9PT0gdmFsdWUqMTAwMClcblx0XHRmb3JtYXR0ZXIgPSAnMCwwLjAwMCdcblx0cmV0dXJuIG51bWJybyh2YWx1ZSkuZm9ybWF0KGZvcm1hdHRlcilcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ29pbiB7XG5cdHN0YXRpYyBTdGFraW5nRGVub20gPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLnN0YWtpbmdEZW5vbTtcblx0c3RhdGljIFN0YWtpbmdEZW5vbVBsdXJhbCA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuc3Rha2luZ0Rlbm9tUGx1cmFsIHx8IChDb2luLlN0YWtpbmdEZW5vbSArICdzJyk7XG5cdHN0YXRpYyBNaW50aW5nRGVub20gPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLm1pbnRpbmdEZW5vbTtcblx0c3RhdGljIFN0YWtpbmdGcmFjdGlvbiA9IE51bWJlcihNZXRlb3Iuc2V0dGluZ3MucHVibGljLnN0YWtpbmdGcmFjdGlvbik7XG5cdHN0YXRpYyBNaW5TdGFrZSA9IDEgLyBOdW1iZXIoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5zdGFraW5nRnJhY3Rpb24pO1xuXG5cdGNvbnN0cnVjdG9yKGFtb3VudCwgZGVub209bnVsbCkge1xuXHRcdGlmICh0eXBlb2YgYW1vdW50ID09PSAnb2JqZWN0Jylcblx0XHRcdCh7YW1vdW50LCBkZW5vbX0gPSBhbW91bnQpXG5cdFx0aWYgKCFkZW5vbSB8fCBkZW5vbS50b0xvd2VyQ2FzZSgpID09PSBDb2luLk1pbnRpbmdEZW5vbS50b0xvd2VyQ2FzZSgpKSB7XG5cdFx0XHR0aGlzLl9hbW91bnQgPSBOdW1iZXIoYW1vdW50KTtcblx0XHR9IGVsc2UgaWYgKGRlbm9tLnRvTG93ZXJDYXNlKCkgPT09IENvaW4uU3Rha2luZ0Rlbm9tLnRvTG93ZXJDYXNlKCkpIHtcblx0XHRcdHRoaXMuX2Ftb3VudCA9IE51bWJlcihhbW91bnQpICogQ29pbi5TdGFraW5nRnJhY3Rpb247XG5cdFx0fVxuXHRcdGVsc2Uge1xuXHRcdFx0dGhyb3cgRXJyb3IoYHVuc3VwcG9ydGVkIGRlbm9tICR7ZGVub219YCk7XG5cdFx0fVxuXHR9XG5cblx0Z2V0IGFtb3VudCAoKSB7XG5cdFx0cmV0dXJuIHRoaXMuX2Ftb3VudDtcblx0fVxuXG5cdGdldCBzdGFraW5nQW1vdW50ICgpIHtcblx0XHRyZXR1cm4gdGhpcy5fYW1vdW50IC8gQ29pbi5TdGFraW5nRnJhY3Rpb247XG5cdH1cblxuXHR0b1N0cmluZyAocHJlY2lzaW9uKSB7XG5cdFx0Ly8gZGVmYXVsdCB0byBkaXNwbGF5IGluIG1pbnQgZGVub20gaWYgaXQgaGFzIG1vcmUgdGhhbiA0IGRlY2ltYWwgcGxhY2VzXG5cdFx0bGV0IG1pblN0YWtlID0gQ29pbi5TdGFraW5nRnJhY3Rpb24vKHByZWNpc2lvbj9NYXRoLnBvdygxMCwgcHJlY2lzaW9uKToxMDAwMClcblx0XHRpZiAodGhpcy5hbW91bnQgPCBtaW5TdGFrZSkge1xuXHRcdFx0cmV0dXJuIGAke251bWJybyh0aGlzLmFtb3VudCkuZm9ybWF0KCcwLDAnKX0gJHtDb2luLk1pbnRpbmdEZW5vbX1gO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRyZXR1cm4gYCR7cHJlY2lzaW9uP251bWJybyh0aGlzLnN0YWtpbmdBbW91bnQpLmZvcm1hdCgnMCwwLicgKyAnMCcucmVwZWF0KHByZWNpc2lvbikpOmF1dG9mb3JtYXQodGhpcy5zdGFraW5nQW1vdW50KX0gJHtDb2luLlN0YWtpbmdEZW5vbX1gXG5cdFx0fVxuXHR9XG5cblx0bWludFN0cmluZyAoZm9ybWF0dGVyKSB7XG5cdFx0bGV0IGFtb3VudCA9IHRoaXMuYW1vdW50XG5cdFx0aWYgKGZvcm1hdHRlcikge1xuXHRcdFx0YW1vdW50ID0gbnVtYnJvKGFtb3VudCkuZm9ybWF0KGZvcm1hdHRlcilcblx0XHR9XG5cdFx0cmV0dXJuIGAke2Ftb3VudH0gJHtDb2luLk1pbnRpbmdEZW5vbX1gO1xuXHR9XG5cblx0c3Rha2VTdHJpbmcgKGZvcm1hdHRlcikge1xuXHRcdGxldCBhbW91bnQgPSB0aGlzLnN0YWtpbmdBbW91bnRcblx0XHRpZiAoZm9ybWF0dGVyKSB7XG5cdFx0XHRhbW91bnQgPSBudW1icm8oYW1vdW50KS5mb3JtYXQoZm9ybWF0dGVyKVxuXHRcdH1cblx0XHRyZXR1cm4gYCR7YW1vdW50fSAke0NvaW4uU3Rha2luZ0Rlbm9tfWA7XG5cdH1cbn0iLCIvLyBTZXJ2ZXIgZW50cnkgcG9pbnQsIGltcG9ydHMgYWxsIHNlcnZlciBjb2RlXG5cbmltcG9ydCAnL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXInO1xuaW1wb3J0ICcvaW1wb3J0cy9zdGFydHVwL2JvdGgnO1xuLy8gaW1wb3J0IG1vbWVudCBmcm9tICdtb21lbnQnO1xuLy8gaW1wb3J0ICcvaW1wb3J0cy9hcGkvYmxvY2tzL2Jsb2Nrcy5qcyc7XG5cblNZTkNJTkcgPSBmYWxzZTtcbkNPVU5UTUlTU0VEQkxPQ0tTID0gZmFsc2U7XG5DT1VOVE1JU1NFREJMT0NLU1NUQVRTID0gZmFsc2U7XG5SUEMgPSBNZXRlb3Iuc2V0dGluZ3MucmVtb3RlLnJwYztcbkxDRCA9IE1ldGVvci5zZXR0aW5ncy5yZW1vdGUubGNkO1xudGltZXJCbG9ja3MgPSAwO1xudGltZXJDaGFpbiA9IDA7XG50aW1lckNvbnNlbnN1cyA9IDA7XG50aW1lclByb3Bvc2FsID0gMDtcbnRpbWVyUHJvcG9zYWxzUmVzdWx0cyA9IDA7XG50aW1lck1pc3NlZEJsb2NrID0gMDtcbnRpbWVyRGVsZWdhdGlvbiA9IDA7XG50aW1lckFnZ3JlZ2F0ZSA9IDA7XG5cbmNvbnN0IERFRkFVTFRTRVRUSU5HUyA9ICcvZGVmYXVsdF9zZXR0aW5ncy5qc29uJztcblxudXBkYXRlQ2hhaW5TdGF0dXMgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ2NoYWluLnVwZGF0ZVN0YXR1cycsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInVwZGF0ZVN0YXR1czogXCIrZXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInVwZGF0ZVN0YXR1czogXCIrcmVzdWx0KTtcbiAgICAgICAgfVxuICAgIH0pXG59XG5cbnVwZGF0ZUJsb2NrID0gKCkgPT4ge1xuICAgIE1ldGVvci5jYWxsKCdibG9ja3MuYmxvY2tzVXBkYXRlJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidXBkYXRlQmxvY2tzOiBcIitlcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidXBkYXRlQmxvY2tzOiBcIityZXN1bHQpO1xuICAgICAgICB9XG4gICAgfSlcbn1cblxuZ2V0Q29uc2Vuc3VzU3RhdGUgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ2NoYWluLmdldENvbnNlbnN1c1N0YXRlJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IGNvbnNlbnN1czogXCIrZXJyb3IpXG4gICAgICAgIH1cbiAgICB9KVxufVxuXG5nZXRQdXJjaGFzZU9yZGVycyA9ICgpID0+IHtcbiAgIE1ldGVvci5jYWxsKCdlbnRlcnByaXNlLmdldFB1cmNoYXNlT3JkZXJzJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBwbzogXCIrIGVycm9yKTtcbiAgICAgICB9XG4gICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IHBvOiBcIityZXN1bHQpO1xuICAgICAgIH1cbiAgIH0pO1xufVxuXG4vL2dldFByb3Bvc2FscyA9ICgpID0+IHtcbi8vICAgIE1ldGVvci5jYWxsKCdwcm9wb3NhbHMuZ2V0UHJvcG9zYWxzJywgKGVycm9yLCByZXN1bHQpID0+IHtcbi8vICAgICAgICBpZiAoZXJyb3Ipe1xuLy8gICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBwcm9wb3NhbDogXCIrIGVycm9yKTtcbi8vICAgICAgICB9XG4vLyAgICAgICAgaWYgKHJlc3VsdCl7XG4vLyAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IHByb3Bvc2FsOiBcIityZXN1bHQpO1xuLy8gICAgICAgIH1cbi8vICAgIH0pO1xuLy99XG4vL1xuLy9nZXRQcm9wb3NhbHNSZXN1bHRzID0gKCkgPT4ge1xuLy8gICAgTWV0ZW9yLmNhbGwoJ3Byb3Bvc2Fscy5nZXRQcm9wb3NhbFJlc3VsdHMnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuLy8gICAgICAgIGlmIChlcnJvcil7XG4vLyAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IHByb3Bvc2FscyByZXN1bHQ6IFwiK2Vycm9yKTtcbi8vICAgICAgICB9XG4vLyAgICAgICAgaWYgKHJlc3VsdCl7XG4vLyAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IHByb3Bvc2FscyByZXN1bHQ6IFwiK3Jlc3VsdCk7XG4vLyAgICAgICAgfVxuLy8gICAgfSk7XG4vL31cblxudXBkYXRlTWlzc2VkQmxvY2tzID0gKCkgPT4ge1xuICAgIE1ldGVvci5jYWxsKCdWYWxpZGF0b3JSZWNvcmRzLmNhbGN1bGF0ZU1pc3NlZEJsb2NrcycsIChlcnJvciwgcmVzdWx0KSA9PntcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwibWlzc2VkIGJsb2NrcyBlcnJvcjogXCIrIGVycm9yKVxuICAgICAgICB9XG4gICAgICAgIGlmIChyZXN1bHQpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJtaXNzZWQgYmxvY2tzIG9rOlwiICsgcmVzdWx0KTtcbiAgICAgICAgfVxuICAgIH0pO1xuLypcbiAgICBNZXRlb3IuY2FsbCgnVmFsaWRhdG9yUmVjb3Jkcy5jYWxjdWxhdGVNaXNzZWRCbG9ja3NTdGF0cycsIChlcnJvciwgcmVzdWx0KSA9PntcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwibWlzc2VkIGJsb2NrcyBzdGF0cyBlcnJvcjogXCIrIGVycm9yKVxuICAgICAgICB9XG4gICAgICAgIGlmIChyZXN1bHQpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJtaXNzZWQgYmxvY2tzIHN0YXRzIG9rOlwiICsgcmVzdWx0KTtcbiAgICAgICAgfVxuICAgIH0pO1xuKi9cbn1cblxuZ2V0RGVsZWdhdGlvbnMgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ2RlbGVnYXRpb25zLmdldERlbGVnYXRpb25zJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IGRlbGVnYXRpb25zIGVycm9yOiBcIisgZXJyb3IpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IGRlbGVnYXRpb25zIG9rOiBcIisgcmVzdWx0KVxuICAgICAgICB9XG4gICAgfSk7XG59XG5cbmFnZ3JlZ2F0ZU1pbnV0ZWx5ID0gKCkgPT57XG4gICAgLy8gZG9pbmcgc29tZXRoaW5nIGV2ZXJ5IG1pblxuICAgIE1ldGVvci5jYWxsKCdBbmFseXRpY3MuYWdncmVnYXRlQmxvY2tUaW1lQW5kVm90aW5nUG93ZXInLCBcIm1cIiwgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRlIG1pbnV0ZWx5IGJsb2NrIHRpbWUgZXJyb3I6IFwiK2Vycm9yKVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSBtaW51dGVseSBibG9jayB0aW1lIG9rOiBcIityZXN1bHQpXG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIE1ldGVvci5jYWxsKCdjb2luU3RhdHMuZ2V0Q29pblN0YXRzJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IGNvaW4gc3RhdHMgZXJyb3I6IFwiK2Vycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgY29pbiBzdGF0cyBvazogXCIrcmVzdWx0KVxuICAgICAgICB9XG4gICAgfSk7XG59XG5cbmFnZ3JlZ2F0ZUhvdXJseSA9ICgpID0+e1xuICAgIC8vIGRvaW5nIHNvbWV0aGluZyBldmVyeSBob3VyXG4gICAgTWV0ZW9yLmNhbGwoJ0FuYWx5dGljcy5hZ2dyZWdhdGVCbG9ja1RpbWVBbmRWb3RpbmdQb3dlcicsIFwiaFwiLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgaG91cmx5IGJsb2NrIHRpbWUgZXJyb3I6IFwiK2Vycm9yKVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSBob3VybHkgYmxvY2sgdGltZSBvazogXCIrcmVzdWx0KVxuICAgICAgICB9XG4gICAgfSk7XG59XG5cbmFnZ3JlZ2F0ZURhaWx5ID0gKCkgPT57XG4gICAgLy8gZG9pbmcgc29tdGhpbmcgZXZlcnkgZGF5XG4gICAgTWV0ZW9yLmNhbGwoJ0FuYWx5dGljcy5hZ2dyZWdhdGVCbG9ja1RpbWVBbmRWb3RpbmdQb3dlcicsIFwiZFwiLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgZGFpbHkgYmxvY2sgdGltZSBlcnJvcjogXCIrZXJyb3IpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRlIGRhaWx5IGJsb2NrIHRpbWUgb2s6IFwiK3Jlc3VsdClcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgTWV0ZW9yLmNhbGwoJ0FuYWx5dGljcy5hZ2dyZWdhdGVWYWxpZGF0b3JEYWlseUJsb2NrVGltZScsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSB2YWxpZGF0b3JzIGJsb2NrIHRpbWUgZXJyb3I6XCIrIGVycm9yKVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgdmFsaWRhdG9ycyBibG9jayB0aW1lIG9rOlwiKyByZXN1bHQpO1xuICAgICAgICB9XG4gICAgfSlcbn1cblxuXG5cbk1ldGVvci5zdGFydHVwKGZ1bmN0aW9uKCl7XG4gICAgaWYgKE1ldGVvci5pc0RldmVsb3BtZW50KXtcbiAgICAgICAgcHJvY2Vzcy5lbnYuTk9ERV9UTFNfUkVKRUNUX1VOQVVUSE9SSVpFRCA9IDA7XG4gICAgICAgIGltcG9ydCBERUZBVUxUU0VUVElOR1NKU09OIGZyb20gJy4uL2RlZmF1bHRfc2V0dGluZ3MuanNvbidcbiAgICAgICAgT2JqZWN0LmtleXMoREVGQVVMVFNFVFRJTkdTSlNPTikuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICAgICAgICBpZiAoTWV0ZW9yLnNldHRpbmdzW2tleV0gPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKGBDSEVDSyBTRVRUSU5HUyBKU09OOiAke2tleX0gaXMgbWlzc2luZyBmcm9tIHNldHRpbmdzYClcbiAgICAgICAgICAgICAgICBNZXRlb3Iuc2V0dGluZ3Nba2V5XSA9IHt9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgT2JqZWN0LmtleXMoREVGQVVMVFNFVFRJTkdTSlNPTltrZXldKS5mb3JFYWNoKChwYXJhbSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChNZXRlb3Iuc2V0dGluZ3Nba2V5XVtwYXJhbV0gPT0gdW5kZWZpbmVkKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKGBDSEVDSyBTRVRUSU5HUyBKU09OOiAke2tleX0uJHtwYXJhbX0gaXMgbWlzc2luZyBmcm9tIHNldHRpbmdzYClcbiAgICAgICAgICAgICAgICAgICAgTWV0ZW9yLnNldHRpbmdzW2tleV1bcGFyYW1dID0gREVGQVVMVFNFVFRJTkdTSlNPTltrZXldW3BhcmFtXVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0pXG4gICAgfVxuXG4gICAgTWV0ZW9yLmNhbGwoJ2NoYWluLmdlbmVzaXMnLCAoZXJyLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZXN1bHQpe1xuICAgICAgICAgICAgaWYgKE1ldGVvci5zZXR0aW5ncy5kZWJ1Zy5zdGFydFRpbWVyKXtcbiAgICAgICAgICAgICAgICB0aW1lckNvbnNlbnN1cyA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgICAgICBnZXRDb25zZW5zdXNTdGF0ZSgpO1xuICAgICAgICAgICAgICAgIH0sIE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuY29uc2Vuc3VzSW50ZXJ2YWwpO1xuXG4gICAgICAgICAgICAgICAgdGltZXJCbG9ja3MgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlQmxvY2soKTtcbiAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLmJsb2NrSW50ZXJ2YWwpO1xuXG4gICAgICAgICAgICAgICAgdGltZXJDaGFpbiA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVDaGFpblN0YXR1cygpO1xuICAgICAgICAgICAgICAgIH0sIE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuc3RhdHVzSW50ZXJ2YWwpO1xuXG4gICAgICAgICAgICAgICAgdGltZXJQdXJjaGFzZU9yZGVyID0gTWV0ZW9yLnNldEludGVydmFsKCBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgZ2V0UHVyY2hhc2VPcmRlcnMoKTtcbiAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLnByb3Bvc2FsSW50ZXJ2YWwpO1xuXG4vLyAgICAgICAgICAgICAgICB0aW1lclByb3Bvc2FsID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCl7XG4vLyAgICAgICAgICAgICAgICAgICAgZ2V0UHJvcG9zYWxzKCk7XG4vLyAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLnByb3Bvc2FsSW50ZXJ2YWwpO1xuLy9cbi8vICAgICAgICAgICAgICAgIHRpbWVyUHJvcG9zYWxzUmVzdWx0cyA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuLy8gICAgICAgICAgICAgICAgICAgIGdldFByb3Bvc2Fsc1Jlc3VsdHMoKTtcbi8vICAgICAgICAgICAgICAgIH0sIE1ldGVvci5zZXR0aW5ncy5wYXJhbXMucHJvcG9zYWxJbnRlcnZhbCk7XG5cbiAgICAgICAgICAgICAgICB0aW1lck1pc3NlZEJsb2NrID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZU1pc3NlZEJsb2NrcygpO1xuICAgICAgICAgICAgICAgIH0sIE1ldGVvci5zZXR0aW5ncy5wYXJhbXMubWlzc2VkQmxvY2tzSW50ZXJ2YWwpO1xuXG4gICAgICAgICAgICAgICAgdGltZXJEZWxlZ2F0aW9uID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgIGdldERlbGVnYXRpb25zKCk7XG4gICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5kZWxlZ2F0aW9uSW50ZXJ2YWwpO1xuXG4gICAgICAgICAgICAgICAgdGltZXJBZ2dyZWdhdGUgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IG5vdyA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgIGlmICgobm93LmdldFVUQ1NlY29uZHMoKSA9PSAwKSl7XG4gICAgICAgICAgICAgICAgICAgICAgICBhZ2dyZWdhdGVNaW51dGVseSgpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKChub3cuZ2V0VVRDTWludXRlcygpID09IDApICYmIChub3cuZ2V0VVRDU2Vjb25kcygpID09IDApKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFnZ3JlZ2F0ZUhvdXJseSgpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKChub3cuZ2V0VVRDSG91cnMoKSA9PSAwKSAmJiAobm93LmdldFVUQ01pbnV0ZXMoKSA9PSAwKSAmJiAobm93LmdldFVUQ1NlY29uZHMoKSA9PSAwKSl7XG4gICAgICAgICAgICAgICAgICAgICAgICBhZ2dyZWdhdGVEYWlseSgpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSwgMTAwMClcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0pXG5cbn0pO1xuIl19
