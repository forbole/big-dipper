var require = meteorInstall({"imports":{"api":{"accounts":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/accounts/server/methods.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Validators;
module.link("/imports/api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);

const fetchFromUrl = url => {
  try {
    let res = HTTP.get(LCD + url);

    if (res.statusCode == 200) {
      return res;
    }

    ;
  } catch (e) {
    console.log(e);
  }
};

Meteor.methods({
  'accounts.getAccountDetail': function (address) {
    this.unblock();
    let url = LCD + '/auth/accounts/' + address;

    try {
      let available = HTTP.get(url);

      if (available.statusCode == 200) {
        let response = JSON.parse(available.content).result;
        let account;
        if (response.type === 'cosmos-sdk/Account') account = response.value;else if (response.type === 'cosmos-sdk/DelayedVestingAccount' || response.type === 'cosmos-sdk/ContinuousVestingAccount') account = response.value.BaseVestingAccount.BaseAccount;
        if (account && account.account_number != null) return account;
        return null;
      }
    } catch (e) {
      console.log(e);
    }
  },
  'accounts.getBalance': function (address) {
    this.unblock();
    let balance = {}; // get available atoms

    let url = LCD + '/bank/balances/' + address;

    try {
      let available = HTTP.get(url);

      if (available.statusCode == 200) {
        // console.log(JSON.parse(available.content))
        balance.available = JSON.parse(available.content).result;
        if (balance.available && balance.available.length > 0) balance.available = balance.available[0];
      }
    } catch (e) {
      console.log(e);
    } // get delegated amnounts


    url = LCD + '/staking/delegators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        balance.delegations = JSON.parse(delegations.content).result;
      }
    } catch (e) {
      console.log(e);
    } // get unbonding


    url = LCD + '/staking/delegators/' + address + '/unbonding_delegations';

    try {
      let unbonding = HTTP.get(url);

      if (unbonding.statusCode == 200) {
        balance.unbonding = JSON.parse(unbonding.content).result;
      }
    } catch (e) {
      console.log(e);
    } // get rewards


    url = LCD + '/distribution/delegators/' + address + '/rewards';

    try {
      let rewards = HTTP.get(url);

      if (rewards.statusCode == 200) {
        balance.rewards = JSON.parse(rewards.content).result.total;
      }
    } catch (e) {
      console.log(e);
    } // get commission


    let validator = Validators.findOne({
      $or: [{
        operator_address: address
      }, {
        delegator_address: address
      }, {
        address: address
      }]
    });

    if (validator) {
      let url = LCD + '/distribution/validators/' + validator.operator_address;
      balance.operator_address = validator.operator_address;

      try {
        let rewards = HTTP.get(url);

        if (rewards.statusCode == 200) {
          let content = JSON.parse(rewards.content).result;
          if (content.val_commission && content.val_commission.length > 0) balance.commission = content.val_commission[0];
        }
      } catch (e) {
        console.log(e);
      }
    }

    return balance;
  },

  'accounts.getDelegation'(address, validator) {
    let url = "/staking/delegators/".concat(address, "/delegations/").concat(validator);
    let delegations = fetchFromUrl(url);
    delegations = delegations && delegations.data.result;
    if (delegations && delegations.shares) delegations.shares = parseFloat(delegations.shares);
    url = "/staking/redelegations?delegator=".concat(address, "&validator_to=").concat(validator);
    let relegations = fetchFromUrl(url);
    relegations = relegations && relegations.data.result;
    let completionTime;

    if (relegations) {
      relegations.forEach(relegation => {
        let entries = relegation.entries;
        let time = new Date(entries[entries.length - 1].completion_time);
        if (!completionTime || time > completionTime) completionTime = time;
      });
      delegations.redelegationCompletionTime = completionTime;
    }

    url = "/staking/delegators/".concat(address, "/unbonding_delegations/").concat(validator);
    let undelegations = fetchFromUrl(url);
    undelegations = undelegations && undelegations.data.result;

    if (undelegations) {
      delegations.unbonding = undelegations.entries.length;
      delegations.unbondingCompletionTime = undelegations.entries[0].completion_time;
    }

    return delegations;
  },

  'accounts.getAllDelegations'(address) {
    let url = LCD + '/staking/delegators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        delegations = JSON.parse(delegations.content).result;

        if (delegations && delegations.length > 0) {
          delegations.forEach((delegation, i) => {
            if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
          });
        }

        return delegations;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  },

  'accounts.getAllUnbondings'(address) {
    let url = LCD + '/staking/delegators/' + address + '/unbonding_delegations';

    try {
      let unbondings = HTTP.get(url);

      if (unbondings.statusCode == 200) {
        unbondings = JSON.parse(unbondings.content).result;
        return unbondings;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  },

  'accounts.getAllRedelegations'(address, validator) {
    let url = "/staking/redelegations?delegator=".concat(address, "&validator_from=").concat(validator);
    let result = fetchFromUrl(url);

    if (result && result.data) {
      let redelegations = {};
      result.data.forEach(redelegation => {
        let entries = redelegation.entries;
        redelegations[redelegation.validator_dst_address] = {
          count: entries.length,
          completionTime: entries[0].completion_time
        };
      });
      return redelegations;
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"blocks":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/server/methods.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Promise;
module.link("meteor/promise", {
  Promise(v) {
    Promise = v;
  }

}, 2);
let Blockscon;
module.link("/imports/api/blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 3);
let Chain;
module.link("/imports/api/chain/chain.js", {
  Chain(v) {
    Chain = v;
  }

}, 4);
let ValidatorSets;
module.link("/imports/api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 5);
let Validators;
module.link("/imports/api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 6);
let ValidatorRecords, Analytics, VPDistributions;
module.link("/imports/api/records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  VPDistributions(v) {
    VPDistributions = v;
  }

}, 7);
let VotingPowerHistory;
module.link("/imports/api/voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 8);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 9);
let Evidences;
module.link("../../evidences/evidences.js", {
  Evidences(v) {
    Evidences = v;
  }

}, 10);
let sha256;
module.link("js-sha256", {
  sha256(v) {
    sha256 = v;
  }

}, 11);
let getAddress;
module.link("tendermint/lib/pubkey", {
  getAddress(v) {
    getAddress = v;
  }

}, 12);
let cheerio;
module.link("cheerio", {
  "*"(v) {
    cheerio = v;
  }

}, 13);

// import Block from '../../../ui/components/Block';
// getValidatorVotingPower = (validators, address) => {
//     for (v in validators){
//         if (validators[v].address == address){
//             return parseInt(validators[v].voting_power);
//         }
//     }
// }
getRemovedValidators = (prevValidators, validators) => {
  // let removeValidators = [];
  for (p in prevValidators) {
    for (v in validators) {
      if (prevValidators[p].address == validators[v].address) {
        prevValidators.splice(p, 1);
      }
    }
  }

  return prevValidators;
};

getValidatorProfileUrl = identity => {
  if (identity.length == 16) {
    let response = HTTP.get("https://keybase.io/_/api/1.0/user/lookup.json?key_suffix=".concat(identity, "&fields=pictures"));

    if (response.statusCode == 200) {
      let them = response.data.them;
      return them && them.length && them[0].pictures && them[0].pictures.primary && them[0].pictures.primary.url;
    } else {
      console.log(JSON.stringify(response));
    }
  } else if (identity.indexOf("keybase.io/team/") > 0) {
    let teamPage = HTTP.get(identity);

    if (teamPage.statusCode == 200) {
      let page = cheerio.load(teamPage.content);
      return page(".kb-main-card img").attr('src');
    } else {
      console.log(JSON.stringify(teamPage));
    }
  }
}; // var filtered = [1, 2, 3, 4, 5].filter(notContainedIn([1, 2, 3, 5]));
// console.log(filtered); // [4]


Meteor.methods({
  'blocks.averageBlockTime'(address) {
    let blocks = Blockscon.find({
      proposerAddress: address
    }).fetch();
    let heights = blocks.map((block, i) => {
      return block.height;
    });
    let blocksStats = Analytics.find({
      height: {
        $in: heights
      }
    }).fetch(); // console.log(blocksStats);

    let totalBlockDiff = 0;

    for (b in blocksStats) {
      totalBlockDiff += blocksStats[b].timeDiff;
    }

    return totalBlockDiff / heights.length;
  },

  'blocks.findUpTime'(address) {
    let collection = ValidatorRecords.rawCollection(); // let aggregateQuery = Meteor.wrapAsync(collection.aggregate, collection);

    var pipeline = [{
      $match: {
        "address": address
      }
    }, // {$project:{address:1,height:1,exists:1}},
    {
      $sort: {
        "height": -1
      }
    }, {
      $limit: Meteor.settings.public.uptimeWindow - 1
    }, {
      $unwind: "$_id"
    }, {
      $group: {
        "_id": "$address",
        "uptime": {
          "$sum": {
            $cond: [{
              $eq: ['$exists', true]
            }, 1, 0]
          }
        }
      }
    }]; // let result = aggregateQuery(pipeline, { cursor: {} });

    return Promise.await(collection.aggregate(pipeline).toArray()); // return .aggregate()
  },

  'blocks.getLatestHeight': function () {
    this.unblock();
    let url = RPC + '/status';

    try {
      let response = HTTP.get(url);
      let status = JSON.parse(response.content);
      return status.result.sync_info.latest_block_height;
    } catch (e) {
      return 0;
    }
  },
  'blocks.getCurrentHeight': function () {
    this.unblock();
    let currHeight = Blockscon.find({}, {
      sort: {
        height: -1
      },
      limit: 1
    }).fetch(); // console.log("currentHeight:"+currHeight);

    let startHeight = Meteor.settings.params.startHeight;

    if (currHeight && currHeight.length == 1) {
      let height = currHeight[0].height;
      if (height > startHeight) return height;
    }

    return startHeight;
  },
  'blocks.blocksUpdate': function () {
    if (SYNCING) return "Syncing...";else console.log("start to sync"); // Meteor.clearInterval(Meteor.timerHandle);
    // get the latest height

    let until = Meteor.call('blocks.getLatestHeight'); // console.log(until);
    // get the current height in db

    let curr = Meteor.call('blocks.getCurrentHeight');
    console.log(curr); // loop if there's update in db

    if (until > curr) {
      SYNCING = true;
      let validatorSet = {}; // get latest validator candidate information

      url = LCD + '/staking/validators';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      url = LCD + '/staking/validators?status=unbonding';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      url = LCD + '/staking/validators?status=unbonded';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      let totalValidators = Object.keys(validatorSet).length;
      console.log("all validators: " + totalValidators);

      for (let height = curr + 1; height <= until; height++) {
        let startBlockTime = new Date(); // add timeout here? and outside this loop (for catched up and keep fetching)?

        this.unblock();
        let url = RPC + '/block?height=' + height;
        let analyticsData = {};
        console.log(url);

        try {
          const bulkValidators = Validators.rawCollection().initializeUnorderedBulkOp();
          const bulkValidatorRecords = ValidatorRecords.rawCollection().initializeUnorderedBulkOp();
          const bulkVPHistory = VotingPowerHistory.rawCollection().initializeUnorderedBulkOp();
          const bulkTransations = Transactions.rawCollection().initializeUnorderedBulkOp();
          let startGetHeightTime = new Date();
          let response = HTTP.get(url);

          if (response.statusCode == 200) {
            let block = JSON.parse(response.content);
            block = block.result; // store height, hash, numtransaction and time in db

            let blockData = {};
            blockData.height = height;
            blockData.hash = block.block_id.hash;
            blockData.transNum = block.block.data.txs === null ? 0 : block.block.data.txs.length;
            blockData.time = new Date(block.block.header.time);
            blockData.lastBlockHash = block.block.header.last_block_id.hash;
            blockData.proposerAddress = block.block.header.proposer_address;
            blockData.validators = [];
            let precommits = block.block.last_commit.signatures;

            if (precommits != null) {
              // console.log(precommits.length);
              for (let i = 0; i < precommits.length; i++) {
                if (precommits[i] != null) {
                  blockData.validators.push(precommits[i].validator_address);
                }
              }

              analyticsData.precommits = precommits.length; // record for analytics
              // PrecommitRecords.insert({height:height, precommits:precommits.length});
            } // save txs in database


            if (block.block.data.txs && block.block.data.txs.length > 0) {
              for (t in block.block.data.txs) {
                Meteor.call('Transactions.index', sha256(Buffer.from(block.block.data.txs[t], 'base64')), blockData.time, (err, result) => {
                  if (err) {
                    console.log(err);
                  }
                });
              }
            } // save double sign evidences


            if (block.block.evidence.evidence) {
              Evidences.insert({
                height: height,
                evidence: block.block.evidence.evidence
              });
            }

            blockData.precommitsCount = blockData.validators.length;
            analyticsData.height = height;
            let endGetHeightTime = new Date();
            console.log("Get height time: " + (endGetHeightTime - startGetHeightTime) / 1000 + "seconds.");
            let startGetValidatorsTime = new Date(); // update chain status

            url = RPC + '/validators?height=' + height;
            response = HTTP.get(url);
            console.log(url);
            let validators = JSON.parse(response.content);
            validators.result.block_height = parseInt(validators.result.block_height);
            ValidatorSets.insert(validators.result);
            blockData.validatorsCount = validators.result.validators.length;
            let startBlockInsertTime = new Date();
            Blockscon.insert(blockData);
            let endBlockInsertTime = new Date();
            console.log("Block insert time: " + (endBlockInsertTime - startBlockInsertTime) / 1000 + "seconds."); // store valdiators exist records

            let existingValidators = Validators.find({
              address: {
                $exists: true
              }
            }).fetch();

            if (height > 1) {
              // record precommits and calculate uptime
              // only record from block 2
              for (i in validators.result.validators) {
                let address = validators.result.validators[i].address;
                let record = {
                  height: height,
                  address: address,
                  exists: false,
                  voting_power: parseInt(validators.result.validators[i].voting_power) //getValidatorVotingPower(existingValidators, address)

                };

                for (j in precommits) {
                  if (precommits[j] != null) {
                    if (address == precommits[j].validator_address) {
                      record.exists = true;
                      precommits.splice(j, 1);
                      break;
                    }
                  }
                } // calculate the uptime based on the records stored in previous blocks
                // only do this every 15 blocks ~


                if (height % 15 == 0) {
                  // let startAggTime = new Date();
                  let numBlocks = Meteor.call('blocks.findUpTime', address);
                  let uptime = 0; // let endAggTime = new Date();
                  // console.log("Get aggregated uptime for "+existingValidators[i].address+": "+((endAggTime-startAggTime)/1000)+"seconds.");

                  if (numBlocks[0] != null && numBlocks[0].uptime != null) {
                    uptime = numBlocks[0].uptime;
                  }

                  let base = Meteor.settings.public.uptimeWindow;

                  if (height < base) {
                    base = height;
                  }

                  if (record.exists) {
                    if (uptime < base) {
                      uptime++;
                    }

                    uptime = uptime / base * 100;
                    bulkValidators.find({
                      address: address
                    }).upsert().updateOne({
                      $set: {
                        uptime: uptime,
                        lastSeen: blockData.time
                      }
                    });
                  } else {
                    uptime = uptime / base * 100;
                    bulkValidators.find({
                      address: address
                    }).upsert().updateOne({
                      $set: {
                        uptime: uptime
                      }
                    });
                  }
                }

                bulkValidatorRecords.insert(record); // ValidatorRecords.update({height:height,address:record.address},record);
              }
            }

            let chainStatus = Chain.findOne({
              chainId: block.block.header.chain_id
            });
            let lastSyncedTime = chainStatus ? chainStatus.lastSyncedTime : 0;
            let timeDiff;
            let blockTime = Meteor.settings.params.defaultBlockTime;

            if (lastSyncedTime) {
              let dateLatest = blockData.time;
              let dateLast = new Date(lastSyncedTime);
              timeDiff = Math.abs(dateLatest.getTime() - dateLast.getTime()); // disregard first couple of blocks to avoid high avg time due to genesis date

              if (blockData.height > 2) {
                blockTime = (chainStatus.blockTime * (blockData.height - 1) + timeDiff) / blockData.height;
              }
            }

            let endGetValidatorsTime = new Date();
            console.log("Get height validators time: " + (endGetValidatorsTime - startGetValidatorsTime) / 1000 + "seconds.");
            Chain.update({
              chainId: block.block.header.chain_id
            }, {
              $set: {
                lastSyncedTime: blockData.time,
                blockTime: blockTime
              }
            });
            analyticsData.averageBlockTime = blockTime;
            analyticsData.timeDiff = timeDiff;
            analyticsData.time = blockData.time; // initialize validator data at first block
            // if (height == 1){
            //     Validators.remove({});
            // }

            analyticsData.voting_power = 0;
            let startFindValidatorsNameTime = new Date();

            if (validators.result) {
              // validators are all the validators in the current height
              console.log("validatorSet size: " + validators.result.validators.length);

              for (v in validators.result.validators) {
                // Validators.insert(validators.result.validators[v]);
                let validator = validators.result.validators[v];
                validator.voting_power = parseInt(validator.voting_power);
                validator.proposer_priority = parseInt(validator.proposer_priority);
                let valExist = Validators.findOne({
                  "pub_key.value": validator.pub_key.value
                });

                if (!valExist) {
                  console.log("validator pub_key ".concat(validator.address, " ").concat(validator.pub_key.value, " not in db")); // let command = Meteor.settings.bin.gaiadebug+" pubkey "+validator.pub_key.value;
                  // console.log(command);
                  // let tempVal = validator;

                  validator.address = getAddress(validator.pub_key);
                  validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
                  validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
                  validator.consensus_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixConsPub);
                  let validatorData = validatorSet[validator.consensus_pubkey];

                  if (validatorData) {
                    if (validatorData.description.identity) validator.profile_url = getValidatorProfileUrl(validatorData.description.identity);
                    validator.operator_address = validatorData.operator_address;
                    validator.delegator_address = Meteor.call('getDelegator', validatorData.operator_address);
                    validator.jailed = validatorData.jailed;
                    validator.status = validatorData.status;
                    validator.min_self_delegation = validatorData.min_self_delegation;
                    validator.tokens = validatorData.tokens;
                    validator.delegator_shares = validatorData.delegator_shares;
                    validator.description = validatorData.description;
                    validator.bond_height = validatorData.bond_height;
                    validator.bond_intra_tx_counter = validatorData.bond_intra_tx_counter;
                    validator.unbonding_height = validatorData.unbonding_height;
                    validator.unbonding_time = validatorData.unbonding_time;
                    validator.commission = validatorData.commission;
                    validator.self_delegation = validator.delegator_shares; // validator.removed = false,
                    // validator.removedAt = 0
                    // validatorSet.splice(val, 1);
                  } else {
                    console.log('no con pub key?');
                  } // bulkValidators.insert(validator);


                  bulkValidators.find({
                    consensus_pubkey: validator.consensus_pubkey
                  }).upsert().updateOne({
                    $set: validator
                  }); // console.log("validator first appears: "+bulkValidators.length);

                  bulkVPHistory.insert({
                    address: validator.address,
                    prev_voting_power: 0,
                    voting_power: validator.voting_power,
                    type: 'add',
                    height: blockData.height,
                    block_time: blockData.time
                  }); // Meteor.call('runCode', command, function(error, result){
                  // validator.address = result.match(/\s[0-9A-F]{40}$/igm);
                  // validator.address = validator.address[0].trim();
                  // validator.hex = result.match(/\s[0-9A-F]{64}$/igm);
                  // validator.hex = validator.hex[0].trim();
                  // validator.cosmosaccpub = result.match(/cosmospub.*$/igm);
                  // validator.cosmosaccpub = validator.cosmosaccpub[0].trim();
                  // validator.operator_pubkey = result.match(/cosmosvaloperpub.*$/igm);
                  // validator.operator_pubkey = validator.operator_pubkey[0].trim();
                  // validator.consensus_pubkey = result.match(/cosmosvalconspub.*$/igm);
                  // validator.consensus_pubkey = validator.consensus_pubkey[0].trim();
                  // });
                } else {
                  let validatorData = validatorSet[valExist.consensus_pubkey];

                  if (validatorData) {
                    if (validatorData.description && (!valExist.description || validatorData.description.identity !== valExist.description.identity)) validator.profile_url = getValidatorProfileUrl(validatorData.description.identity);
                    validator.jailed = validatorData.jailed;
                    validator.status = validatorData.status;
                    validator.tokens = validatorData.tokens;
                    validator.delegator_shares = validatorData.delegator_shares;
                    validator.description = validatorData.description;
                    validator.bond_height = validatorData.bond_height;
                    validator.bond_intra_tx_counter = validatorData.bond_intra_tx_counter;
                    validator.unbonding_height = validatorData.unbonding_height;
                    validator.unbonding_time = validatorData.unbonding_time;
                    validator.commission = validatorData.commission; // calculate self delegation percentage every 30 blocks

                    if (height % 30 == 1) {
                      try {
                        let response = HTTP.get(LCD + '/staking/delegators/' + valExist.delegator_address + '/delegations/' + valExist.operator_address);

                        if (response.statusCode == 200) {
                          let selfDelegation = JSON.parse(response.content).result;

                          if (selfDelegation.shares) {
                            validator.self_delegation = parseFloat(selfDelegation.shares) / parseFloat(validator.delegator_shares);
                          }
                        }
                      } catch (e) {// console.log(e);
                      }
                    }

                    bulkValidators.find({
                      consensus_pubkey: valExist.consensus_pubkey
                    }).updateOne({
                      $set: validator
                    }); // console.log("validator exisits: "+bulkValidators.length);
                    // validatorSet.splice(val, 1);
                  } else {
                    console.log('no con pub key?');
                  }

                  let prevVotingPower = VotingPowerHistory.findOne({
                    address: validator.address
                  }, {
                    height: -1,
                    limit: 1
                  });

                  if (prevVotingPower) {
                    if (prevVotingPower.voting_power != validator.voting_power) {
                      let changeType = prevVotingPower.voting_power > validator.voting_power ? 'down' : 'up';
                      let changeData = {
                        address: validator.address,
                        prev_voting_power: prevVotingPower.voting_power,
                        voting_power: validator.voting_power,
                        type: changeType,
                        height: blockData.height,
                        block_time: blockData.time
                      }; // console.log('voting power changed.');
                      // console.log(changeData);

                      bulkVPHistory.insert(changeData);
                    }
                  }
                } // console.log(validator);


                analyticsData.voting_power += validator.voting_power;
              } // if there is validator removed


              let prevValidators = ValidatorSets.findOne({
                block_height: height - 1
              });

              if (prevValidators) {
                let removedValidators = getRemovedValidators(prevValidators.validators, validators.result.validators);

                for (r in removedValidators) {
                  bulkVPHistory.insert({
                    address: removedValidators[r].address,
                    prev_voting_power: removedValidators[r].voting_power,
                    voting_power: 0,
                    type: 'remove',
                    height: blockData.height,
                    block_time: blockData.time
                  });
                }
              }
            } // check if there's any validator not in db 14400 blocks(~1 day)


            if (height % 14400 == 0) {
              try {
                console.log('Checking all validators against db...');
                let dbValidators = {};
                Validators.find({}, {
                  fields: {
                    consensus_pubkey: 1,
                    status: 1
                  }
                }).forEach(v => dbValidators[v.consensus_pubkey] = v.status);
                Object.keys(validatorSet).forEach(conPubKey => {
                  let validatorData = validatorSet[conPubKey]; // Active validators should have been updated in previous steps

                  if (validatorData.status === 2) return;

                  if (dbValidators[conPubKey] == undefined) {
                    console.log("validator with consensus_pubkey ".concat(conPubKey, " not in db"));
                    validatorData.pub_key = {
                      "type": "tendermint/PubKeyEd25519",
                      "value": Meteor.call('bech32ToPubkey', conPubKey)
                    };
                    validatorData.address = getAddress(validatorData.pub_key);
                    validatorData.delegator_address = Meteor.call('getDelegator', validatorData.operator_address);
                    validatorData.accpub = Meteor.call('pubkeyToBech32', validatorData.pub_key, Meteor.settings.public.bech32PrefixAccPub);
                    validatorData.operator_pubkey = Meteor.call('pubkeyToBech32', validatorData.pub_key, Meteor.settings.public.bech32PrefixValPub);
                    console.log(JSON.stringify(validatorData));
                    bulkValidators.find({
                      consensus_pubkey: conPubKey
                    }).upsert().updateOne({
                      $set: validatorData
                    });
                  } else if (dbValidators[conPubKey] == 2) {
                    bulkValidators.find({
                      consensus_pubkey: conPubKey
                    }).upsert().updateOne({
                      $set: validatorData
                    });
                  }
                });
              } catch (e) {
                console.log(e);
              }
            } // fetching keybase every 14400 blocks(~1 day)


            if (height % 14400 == 1) {
              console.log('Fetching keybase...');
              Validators.find({}).forEach(validator => {
                try {
                  let profileUrl = getValidatorProfileUrl(validator.description.identity);

                  if (profileUrl) {
                    bulkValidators.find({
                      address: validator.address
                    }).upsert().updateOne({
                      $set: {
                        'profile_url': profileUrl
                      }
                    });
                  }
                } catch (e) {
                  console.log(e);
                }
              });
            }

            let endFindValidatorsNameTime = new Date();
            console.log("Get validators name time: " + (endFindValidatorsNameTime - startFindValidatorsNameTime) / 1000 + "seconds."); // record for analytics

            let startAnayticsInsertTime = new Date();
            Analytics.insert(analyticsData);
            let endAnalyticsInsertTime = new Date();
            console.log("Analytics insert time: " + (endAnalyticsInsertTime - startAnayticsInsertTime) / 1000 + "seconds.");
            let startVUpTime = new Date();

            if (bulkValidators.length > 0) {
              // console.log(bulkValidators.length);
              bulkValidators.execute((err, result) => {
                if (err) {
                  console.log(err);
                }

                if (result) {// console.log(result);
                }
              });
            }

            let endVUpTime = new Date();
            console.log("Validator update time: " + (endVUpTime - startVUpTime) / 1000 + "seconds.");
            let startVRTime = new Date();

            if (bulkValidatorRecords.length > 0) {
              bulkValidatorRecords.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            }

            let endVRTime = new Date();
            console.log("Validator records update time: " + (endVRTime - startVRTime) / 1000 + "seconds.");

            if (bulkVPHistory.length > 0) {
              bulkVPHistory.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            }

            if (bulkTransations.length > 0) {
              bulkTransations.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            } // calculate voting power distribution every 60 blocks ~ 5mins


            if (height % 60 == 1) {
              console.log("===== calculate voting power distribution =====");
              let activeValidators = Validators.find({
                status: 2,
                jailed: false
              }, {
                sort: {
                  voting_power: -1
                }
              }).fetch();
              let numTopTwenty = Math.ceil(activeValidators.length * 0.2);
              let numBottomEighty = activeValidators.length - numTopTwenty;
              let topTwentyPower = 0;
              let bottomEightyPower = 0;
              let numTopThirtyFour = 0;
              let numBottomSixtySix = 0;
              let topThirtyFourPercent = 0;
              let bottomSixtySixPercent = 0;

              for (v in activeValidators) {
                if (v < numTopTwenty) {
                  topTwentyPower += activeValidators[v].voting_power;
                } else {
                  bottomEightyPower += activeValidators[v].voting_power;
                }

                if (topThirtyFourPercent < 0.34) {
                  topThirtyFourPercent += activeValidators[v].voting_power / analyticsData.voting_power;
                  numTopThirtyFour++;
                }
              }

              bottomSixtySixPercent = 1 - topThirtyFourPercent;
              numBottomSixtySix = activeValidators.length - numTopThirtyFour;
              let vpDist = {
                height: height,
                numTopTwenty: numTopTwenty,
                topTwentyPower: topTwentyPower,
                numBottomEighty: numBottomEighty,
                bottomEightyPower: bottomEightyPower,
                numTopThirtyFour: numTopThirtyFour,
                topThirtyFourPercent: topThirtyFourPercent,
                numBottomSixtySix: numBottomSixtySix,
                bottomSixtySixPercent: bottomSixtySixPercent,
                numValidators: activeValidators.length,
                totalVotingPower: analyticsData.voting_power,
                blockTime: blockData.time,
                createAt: new Date()
              };
              console.log(vpDist);
              VPDistributions.insert(vpDist);
            }
          }
        } catch (e) {
          console.log(e);
          SYNCING = false;
          return "Stopped";
        }

        let endBlockTime = new Date();
        console.log("This block used: " + (endBlockTime - startBlockTime) / 1000 + "seconds.");
      }

      SYNCING = false;
      Chain.update({
        chainId: Meteor.settings.public.chainId
      }, {
        $set: {
          lastBlocksSyncedTime: new Date(),
          totalValidators: totalValidators
        }
      });
    }

    return until;
  },
  'addLimit': function (limit) {
    // console.log(limit+10)
    return limit + 10;
  },
  'hasMore': function (limit) {
    if (limit > Meteor.call('getCurrentHeight')) {
      return false;
    } else {
      return true;
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/server/publications.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Blockscon;
module.link("../blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 3);
publishComposite('blocks.height', function (limit) {
  return {
    find() {
      return Blockscon.find({}, {
        limit: limit,
        sort: {
          height: -1
        }
      });
    },

    children: [{
      find(block) {
        return Validators.find({
          address: block.proposerAddress
        }, {
          limit: 1
        });
      }

    }]
  };
});
publishComposite('blocks.findOne', function (height) {
  return {
    find() {
      return Blockscon.find({
        height: height
      });
    },

    children: [{
      find(block) {
        return Transactions.find({
          height: block.height
        });
      }

    }, {
      find(block) {
        return Validators.find({
          address: block.proposerAddress
        }, {
          limit: 1
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"blocks.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/blocks.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Blockscon: () => Blockscon
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const Blockscon = new Mongo.Collection('blocks');
Blockscon.helpers({
  proposer() {
    return Validators.findOne({
      address: this.proposerAddress
    });
  }

}); // Blockscon.helpers({
//     sorted(limit) {
//         return Blockscon.find({}, {sort: {height:-1}, limit: limit});
//     }
// });
// Meteor.setInterval(function() {
//     Meteor.call('blocksUpdate', (error, result) => {
//         console.log(result);
//     })
// }, 30000000);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chain":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/server/methods.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let getAddress;
module.link("tendermint/lib/pubkey.js", {
  getAddress(v) {
    getAddress = v;
  }

}, 2);
let Chain, ChainStates;
module.link("../chain.js", {
  Chain(v) {
    Chain = v;
  },

  ChainStates(v) {
    ChainStates = v;
  }

}, 3);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 4);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 5);

findVotingPower = (validator, genValidators) => {
  for (let v in genValidators) {
    if (validator.pub_key.value == genValidators[v].pub_key.value) {
      return parseInt(genValidators[v].power);
    }
  }
};

Meteor.methods({
  'chain.getConsensusState': function () {
    this.unblock();
    let url = RPC + '/dump_consensus_state';

    try {
      let response = HTTP.get(url);
      let consensus = JSON.parse(response.content);
      consensus = consensus.result;
      let height = consensus.round_state.height;
      let round = consensus.round_state.round;
      let step = consensus.round_state.step;
      let votedPower = Math.round(parseFloat(consensus.round_state.votes[round].prevotes_bit_array.split(" ")[3]) * 100);
      Chain.update({
        chainId: Meteor.settings.public.chainId
      }, {
        $set: {
          votingHeight: height,
          votingRound: round,
          votingStep: step,
          votedPower: votedPower,
          proposerAddress: consensus.round_state.validators.proposer.address,
          prevotes: consensus.round_state.votes[round].prevotes,
          precommits: consensus.round_state.votes[round].precommits
        }
      });
    } catch (e) {
      console.log(e);
    }
  },
  'chain.updateStatus': function () {
    this.unblock();
    let url = RPC + '/status';

    try {
      let response = HTTP.get(url);
      let status = JSON.parse(response.content);
      status = status.result;
      let chain = {};
      chain.chainId = status.node_info.network;
      chain.latestBlockHeight = status.sync_info.latest_block_height;
      chain.latestBlockTime = status.sync_info.latest_block_time;
      let latestState = ChainStates.findOne({}, {
        sort: {
          height: -1
        }
      });

      if (latestState && latestState.height >= chain.latestBlockHeight) {
        return "no updates (getting block ".concat(chain.latestBlockHeight, " at block ").concat(latestState.height, ")");
      }

      url = RPC + '/validators';
      response = HTTP.get(url);
      let validators = JSON.parse(response.content);
      validators = validators.result.validators;
      chain.validators = validators.length;
      let activeVP = 0;

      for (v in validators) {
        activeVP += parseInt(validators[v].voting_power);
      }

      chain.activeVotingPower = activeVP;
      Chain.update({
        chainId: chain.chainId
      }, {
        $set: chain
      }, {
        upsert: true
      }); // Get chain states

      if (parseInt(chain.latestBlockHeight) > 0) {
        let chainStates = {};
        chainStates.height = parseInt(status.sync_info.latest_block_height);
        chainStates.time = new Date(status.sync_info.latest_block_time);
        url = LCD + '/staking/pool';

        try {
          response = HTTP.get(url);
          let bonding = JSON.parse(response.content).result; // chain.bondedTokens = bonding.bonded_tokens;
          // chain.notBondedTokens = bonding.not_bonded_tokens;

          chainStates.bondedTokens = parseInt(bonding.bonded_tokens);
          chainStates.notBondedTokens = parseInt(bonding.not_bonded_tokens);
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/supply/total/' + Meteor.settings.public.mintingDenom;

        try {
          response = HTTP.get(url);
          let supply = JSON.parse(response.content).result;
          chainStates.totalSupply = parseInt(supply);
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/distribution/community_pool';

        try {
          response = HTTP.get(url);
          let pool = JSON.parse(response.content).result;

          if (pool && pool.length > 0) {
            chainStates.communityPool = [];
            pool.forEach((amount, i) => {
              chainStates.communityPool.push({
                denom: amount.denom,
                amount: parseFloat(amount.amount)
              });
            });
          }
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/minting/inflation';

        try {
          response = HTTP.get(url);
          let inflation = JSON.parse(response.content).result;

          if (inflation) {
            chainStates.inflation = parseFloat(inflation);
          }
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/minting/annual-provisions';

        try {
          response = HTTP.get(url);
          let provisions = JSON.parse(response.content);

          if (provisions) {
            chainStates.annualProvisions = parseFloat(provisions.result);
          }
        } catch (e) {
          console.log(e);
        }

        ChainStates.insert(chainStates);
      } // chain.totalVotingPower = totalVP;
      // validators = Validators.find({}).fetch();
      // console.log(validators);


      return chain.latestBlockHeight;
    } catch (e) {
      console.log(e);
      return "Error getting chain status.";
    }
  },
  'chain.getLatestStatus': function () {
    Chain.find().sort({
      created: -1
    }).limit(1);
  },
  'chain.genesis': function () {
    let chain = Chain.findOne({
      chainId: Meteor.settings.public.chainId
    });

    if (chain && chain.readGenesis) {
      console.log('Genesis file has been processed');
    } else if (Meteor.settings.debug.readGenesis) {
      console.log('=== Start processing genesis file ===');
      let response = HTTP.get(Meteor.settings.genesisFile);
      let genesis = JSON.parse(response.content);
      let distr = genesis.app_state.distr || genesis.app_state.distribution;
      let chainParams = {
        chainId: genesis.chain_id,
        genesisTime: genesis.genesis_time,
        consensusParams: genesis.consensus_params,
        auth: genesis.app_state.auth,
        bank: genesis.app_state.bank,
        staking: {
          pool: genesis.app_state.staking.pool,
          params: genesis.app_state.staking.params
        },
        mint: genesis.app_state.mint,
        distr: {
          communityTax: distr.community_tax,
          baseProposerReward: distr.base_proposer_reward,
          bonusProposerReward: distr.bonus_proposer_reward,
          withdrawAddrEnabled: distr.withdraw_addr_enabled
        },
        gov: {
          startingProposalId: 0,
          depositParams: {},
          votingParams: {},
          tallyParams: {}
        },
        slashing: {
          params: genesis.app_state.slashing.params
        },
        supply: genesis.app_state.supply,
        crisis: genesis.app_state.crisis
      };

      if (genesis.app_state.gov) {
        chainParams.gov = {
          startingProposalId: genesis.app_state.gov.starting_proposal_id,
          depositParams: genesis.app_state.gov.deposit_params,
          votingParams: genesis.app_state.gov.voting_params,
          tallyParams: genesis.app_state.gov.tally_params
        };
      }

      let totalVotingPower = 0; // read gentx

      if (genesis.app_state.genutil && genesis.app_state.genutil.gentxs && genesis.app_state.genutil.gentxs.length > 0) {
        for (i in genesis.app_state.genutil.gentxs) {
          let msg = genesis.app_state.genutil.gentxs[i].value.msg; // console.log(msg.type);

          for (m in msg) {
            if (msg[m].type == "cosmos-sdk/MsgCreateValidator") {
              console.log(msg[m].value); // let command = Meteor.settings.bin.gaiadebug+" pubkey "+msg[m].value.pubkey;

              let validator = {
                consensus_pubkey: msg[m].value.pubkey,
                description: msg[m].value.description,
                commission: msg[m].value.commission,
                min_self_delegation: msg[m].value.min_self_delegation,
                operator_address: msg[m].value.validator_address,
                delegator_address: msg[m].value.delegator_address,
                voting_power: Math.floor(parseInt(msg[m].value.value.amount) / Meteor.settings.public.stakingFraction),
                jailed: false,
                status: 2
              };
              totalVotingPower += validator.voting_power;
              let pubkeyValue = Meteor.call('bech32ToPubkey', msg[m].value.pubkey); // Validators.upsert({consensus_pubkey:msg[m].value.pubkey},validator);

              validator.pub_key = {
                "type": "tendermint/PubKeyEd25519",
                "value": pubkeyValue
              };
              validator.address = getAddress(validator.pub_key);
              validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
              validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
              VotingPowerHistory.insert({
                address: validator.address,
                prev_voting_power: 0,
                voting_power: validator.voting_power,
                type: 'add',
                height: 0,
                block_time: genesis.genesis_time
              });
              Validators.insert(validator);
            }
          }
        }
      } // read validators from previous chain


      console.log('read validators from previous chain');

      if (genesis.app_state.staking.validators && genesis.app_state.staking.validators.length > 0) {
        console.log(genesis.app_state.staking.validators.length);
        let genValidatorsSet = genesis.app_state.staking.validators;
        let genValidators = genesis.validators;

        for (let v in genValidatorsSet) {
          // console.log(genValidators[v]);
          let validator = genValidatorsSet[v];
          validator.delegator_address = Meteor.call('getDelegator', genValidatorsSet[v].operator_address);
          let pubkeyValue = Meteor.call('bech32ToPubkey', validator.consensus_pubkey);
          validator.pub_key = {
            "type": "tendermint/PubKeyEd25519",
            "value": pubkeyValue
          };
          validator.address = getAddress(validator.pub_key);
          validator.pub_key = validator.pub_key;
          validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
          validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
          validator.voting_power = findVotingPower(validator, genValidators);
          totalVotingPower += validator.voting_power;
          Validators.upsert({
            consensus_pubkey: validator.consensus_pubkey
          }, validator);
          VotingPowerHistory.insert({
            address: validator.address,
            prev_voting_power: 0,
            voting_power: validator.voting_power,
            type: 'add',
            height: 0,
            block_time: genesis.genesis_time
          });
        }
      }

      chainParams.readGenesis = true;
      chainParams.activeVotingPower = totalVotingPower;
      let result = Chain.upsert({
        chainId: chainParams.chainId
      }, {
        $set: chainParams
      });
      console.log('=== Finished processing genesis file ===');
    }

    return true;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/server/publications.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Chain, ChainStates;
module.link("../chain.js", {
  Chain(v) {
    Chain = v;
  },

  ChainStates(v) {
    ChainStates = v;
  }

}, 1);
let CoinStats;
module.link("../../coin-stats/coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
Meteor.publish('chainStates.latest', function () {
  return [ChainStates.find({}, {
    sort: {
      height: -1
    },
    limit: 1
  }), CoinStats.find({}, {
    sort: {
      last_updated_at: -1
    },
    limit: 1
  })];
});
publishComposite('chain.status', function () {
  return {
    find() {
      return Chain.find({
        chainId: Meteor.settings.public.chainId
      });
    },

    children: [{
      find(chain) {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            operator_address: 1,
            status: -1,
            jailed: 1,
            profile_url: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chain.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/chain.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Chain: () => Chain,
  ChainStates: () => ChainStates
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const Chain = new Mongo.Collection('chain');
const ChainStates = new Mongo.Collection('chain_states');
Chain.helpers({
  proposer() {
    return Validators.findOne({
      address: this.proposerAddress
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"coin-stats":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/coin-stats/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let CoinStats;
module.link("../coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 1);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 2);
Meteor.methods({
  'coinStats.getCoinStats': function () {
    this.unblock();
    let coinId = Meteor.settings.public.coingeckoId;

    if (coinId) {
      try {
        let now = new Date();
        now.setMinutes(0);
        let url = "https://api.coingecko.com/api/v3/simple/price?ids=" + coinId + "&vs_currencies=usd&include_market_cap=true&include_24hr_vol=true&include_24hr_change=true&include_last_updated_at=true";
        let response = HTTP.get(url);

        if (response.statusCode == 200) {
          // console.log(JSON.parse(response.content));
          let data = JSON.parse(response.content);
          data = data[coinId]; // console.log(coinStats);

          return CoinStats.upsert({
            last_updated_at: data.last_updated_at
          }, {
            $set: data
          });
        }
      } catch (e) {
        console.log(e);
      }
    } else {
      return "No coingecko Id provided.";
    }
  },
  'coinStats.getStats': function () {
    this.unblock();
    let coinId = Meteor.settings.public.coingeckoId;

    if (coinId) {
      return CoinStats.findOne({}, {
        sort: {
          last_updated_at: -1
        }
      });
    } else {
      return "No coingecko Id provided.";
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"coin-stats.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/coin-stats/coin-stats.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  CoinStats: () => CoinStats
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const CoinStats = new Mongo.Collection('coin_stats');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"delegations":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/server/methods.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Delegations;
module.link("../delegations.js", {
  Delegations(v) {
    Delegations = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
Meteor.methods({
  'delegations.getDelegations': function () {
    this.unblock();
    let validators = Validators.find({}).fetch();
    let delegations = [];
    console.log("=== Getting delegations ===");

    for (v in validators) {
      if (validators[v].operator_address) {
        let url = LCD + '/staking/validators/' + validators[v].operator_address + "/delegations";

        try {
          let response = HTTP.get(url);

          if (response.statusCode == 200) {
            let delegation = JSON.parse(response.content).result; // console.log(delegation);

            delegations = delegations.concat(delegation);
          } else {
            console.log(response.statusCode);
          }
        } catch (e) {
          console.log(e);
        }
      }
    }

    for (i in delegations) {
      if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
    } // console.log(delegations);


    let data = {
      delegations: delegations,
      createdAt: new Date()
    };
    return Delegations.insert(data);
  } // 'blocks.averageBlockTime'(address){
  //     let blocks = Blockscon.find({proposerAddress:address}).fetch();
  //     let heights = blocks.map((block, i) => {
  //         return block.height;
  //     });
  //     let blocksStats = Analytics.find({height:{$in:heights}}).fetch();
  //     // console.log(blocksStats);
  //     let totalBlockDiff = 0;
  //     for (b in blocksStats){
  //         totalBlockDiff += blocksStats[b].timeDiff;
  //     }
  //     return totalBlockDiff/heights.length;
  // }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/server/publications.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"delegations.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/delegations.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Delegations: () => Delegations
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Delegations = new Mongo.Collection('delegations');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"enterprise":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/enterprise/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Enterprise;
module.link("../enterprise.js", {
  Enterprise(v) {
    Enterprise = v;
  }

}, 2);
Meteor.methods({
  'enterprise.getPurchaseOrders': function () {
    this.unblock();

    try {
      let url = LCD + '/enterprise/pos';
      let response = HTTP.get(url);
      let purchaseOrders = JSON.parse(response.content).result;
      let finishedPurchaseOrders = new Set(Enterprise.find({
        "status": {
          $in: ["reject", "complete"]
        }
      }).fetch().map(p => p.poId));
      let poIds = [];

      if (purchaseOrders.length > 0) {
        const bulkPos = Enterprise.rawCollection().initializeUnorderedBulkOp();

        for (let i in purchaseOrders) {
          let po = purchaseOrders[i];
          po.poId = parseInt(po.id);

          if (po.poId > 0 && !finishedPurchaseOrders.has(po.poId)) {
            try {
              bulkPos.find({
                poId: po.poId
              }).upsert().updateOne({
                $set: po
              });
              poIds.push(po.poId);
            } catch (e) {
              bulkPos.find({
                poId: po.poId
              }).upsert().updateOne({
                $set: po
              });
              poIds.push(po.poId);
              console.log(e.response.content);
            }
          }
        }

        if (poIds.length > 0) {
          bulkPos.execute();
        }
      }

      return true;
    } catch (e) {
      console.log(e);
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/enterprise/server/publications.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Enterprise;
module.link("../enterprise.js", {
  Enterprise(v) {
    Enterprise = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
Meteor.publish('enterprise.list_pos', function () {
  return Enterprise.find({}, {
    sort: {
      poId: -1
    }
  });
});
Meteor.publish('enterprise.one_po', function (id) {
  check(id, Number);
  return Enterprise.find({
    poId: id
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"enterprise.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/enterprise/enterprise.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Enterprise: () => Enterprise
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Enterprise = new Mongo.Collection('enterprise');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"ledger":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/ledger/server/methods.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 0);
Meteor.methods({
  'transaction.submit': function (txInfo) {
    const url = "".concat(LCD, "/txs");
    data = {
      "tx": txInfo.value,
      "mode": "sync"
    };
    const timestamp = new Date().getTime();
    console.log("submitting transaction".concat(timestamp, " ").concat(url, " with data ").concat(JSON.stringify(data)));
    let response = HTTP.post(url, {
      data
    });
    console.log("response for transaction".concat(timestamp, " ").concat(url, ": ").concat(JSON.stringify(response)));

    if (response.statusCode == 200) {
      let data = response.data;
      if (data.code) throw new Meteor.Error(data.code, JSON.parse(data.raw_log).message);
      return response.data.txhash;
    }
  },
  'transaction.execute': function (body, path) {
    const url = "".concat(LCD, "/").concat(path);
    data = {
      "base_req": _objectSpread({}, body, {
        "chain_id": Meteor.settings.public.chainId,
        "simulate": false
      })
    };
    let response = HTTP.post(url, {
      data
    });

    if (response.statusCode == 200) {
      return JSON.parse(response.content);
    }
  },
  'transaction.simulate': function (txMsg, from, path) {
    let adjustment = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '1.2';
    const url = "".concat(LCD, "/").concat(path);
    data = _objectSpread({}, txMsg, {
      "base_req": {
        "from": from,
        "chain_id": Meteor.settings.public.chainId,
        "gas_adjustment": adjustment,
        "simulate": true
      }
    });
    let response = HTTP.post(url, {
      data
    });

    if (response.statusCode == 200) {
      return JSON.parse(response.content).gas_estimate;
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"proposals":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/proposals/server/methods.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Proposals;
module.link("../proposals.js", {
  Proposals(v) {
    Proposals = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
// import { Promise } from 'meteor/promise';
Meteor.methods({
  'proposals.getProposals': function () {
    this.unblock();

    try {
      let url = LCD + '/gov/proposals';
      let response = HTTP.get(url);
      let proposals = JSON.parse(response.content).result; // console.log(proposals);

      let finishedProposalIds = new Set(Proposals.find({
        "proposal_status": {
          $in: ["Passed", "Rejected", "Removed"]
        }
      }).fetch().map(p => p.proposalId));
      let proposalIds = [];

      if (proposals.length > 0) {
        // Proposals.upsert()
        const bulkProposals = Proposals.rawCollection().initializeUnorderedBulkOp();

        for (let i in proposals) {
          let proposal = proposals[i];
          proposal.proposalId = parseInt(proposal.id);

          if (proposal.proposalId > 0 && !finishedProposalIds.has(proposal.proposalId)) {
            try {
              let url = LCD + '/gov/proposals/' + proposal.proposalId + '/proposer';
              let response = HTTP.get(url);

              if (response.statusCode == 200) {
                let proposer = JSON.parse(response.content).result;

                if (proposer.proposal_id && proposer.proposal_id == proposal.id) {
                  proposal.proposer = proposer.proposer;
                }
              }

              bulkProposals.find({
                proposalId: proposal.proposalId
              }).upsert().updateOne({
                $set: proposal
              });
              proposalIds.push(proposal.proposalId);
            } catch (e) {
              bulkProposals.find({
                proposalId: proposal.proposalId
              }).upsert().updateOne({
                $set: proposal
              });
              proposalIds.push(proposal.proposalId);
              console.log(e.response.content);
            }
          }
        }

        bulkProposals.find({
          proposalId: {
            $nin: proposalIds
          },
          proposal_status: {
            $nin: ["Passed", "Rejected", "Removed"]
          }
        }).update({
          $set: {
            "proposal_status": "Removed"
          }
        });
        bulkProposals.execute();
      }

      return true;
    } catch (e) {
      console.log(e);
    }
  },
  'proposals.getProposalResults': function () {
    this.unblock();
    let proposals = Proposals.find({
      "proposal_status": {
        $nin: ["Passed", "Rejected", "Removed"]
      }
    }).fetch();

    if (proposals && proposals.length > 0) {
      for (let i in proposals) {
        if (parseInt(proposals[i].proposalId) > 0) {
          try {
            // get proposal deposits
            let url = LCD + '/gov/proposals/' + proposals[i].proposalId + '/deposits';
            let response = HTTP.get(url);
            let proposal = {
              proposalId: proposals[i].proposalId
            };

            if (response.statusCode == 200) {
              let deposits = JSON.parse(response.content).result;
              proposal.deposits = deposits;
            }

            url = LCD + '/gov/proposals/' + proposals[i].proposalId + '/votes';
            response = HTTP.get(url);

            if (response.statusCode == 200) {
              let votes = JSON.parse(response.content).result;
              proposal.votes = getVoteDetail(votes);
            }

            url = LCD + '/gov/proposals/' + proposals[i].proposalId + '/tally';
            response = HTTP.get(url);

            if (response.statusCode == 200) {
              let tally = JSON.parse(response.content).result;
              proposal.tally = tally;
            }

            proposal.updatedAt = new Date();
            Proposals.update({
              proposalId: proposals[i].proposalId
            }, {
              $set: proposal
            });
          } catch (e) {}
        }
      }
    }

    return true;
  }
});

const getVoteDetail = votes => {
  if (!votes) {
    return [];
  }

  let voters = votes.map(vote => vote.voter);
  let votingPowerMap = {};
  let validatorAddressMap = {};
  Validators.find({
    delegator_address: {
      $in: voters
    }
  }).forEach(validator => {
    votingPowerMap[validator.delegator_address] = {
      moniker: validator.description.moniker,
      address: validator.address,
      tokens: parseFloat(validator.tokens),
      delegatorShares: parseFloat(validator.delegator_shares),
      deductedShares: parseFloat(validator.delegator_shares)
    };
    validatorAddressMap[validator.operator_address] = validator.delegator_address;
  });
  voters.forEach(voter => {
    if (!votingPowerMap[voter]) {
      // voter is not a validator
      let url = "".concat(LCD, "/staking/delegators/").concat(voter, "/delegations");
      let delegations;
      let votingPower = 0;

      try {
        let response = HTTP.get(url);

        if (response.statusCode == 200) {
          delegations = JSON.parse(response.content).result;

          if (delegations && delegations.length > 0) {
            delegations.forEach(delegation => {
              let shares = parseFloat(delegation.shares);

              if (validatorAddressMap[delegation.validator_address]) {
                // deduct delegated shareds from validator if a delegator votes
                let validator = votingPowerMap[validatorAddressMap[delegation.validator_address]];
                validator.deductedShares -= shares;

                if (validator.delegator_shares != 0) {
                  // avoiding division by zero
                  votingPower += shares / validator.delegatorShares * validator.tokens;
                }
              } else {
                let validator = Validators.findOne({
                  operator_address: delegation.validator_address
                });

                if (validator && validator.delegator_shares != 0) {
                  // avoiding division by zero
                  votingPower += shares / parseFloat(validator.delegator_shares) * parseFloat(validator.tokens);
                }
              }
            });
          }
        }
      } catch (e) {
        console.log(e);
      }

      votingPowerMap[voter] = {
        votingPower: votingPower
      };
    }
  });
  return votes.map(vote => {
    let voter = votingPowerMap[vote.voter];
    let votingPower = voter.votingPower;

    if (votingPower == undefined) {
      // voter is a validator
      votingPower = voter.delegatorShares ? voter.deductedShares / voter.delegatorShares * voter.tokens : 0;
    }

    return _objectSpread({}, vote, {
      votingPower
    });
  });
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/proposals/server/publications.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Proposals;
module.link("../proposals.js", {
  Proposals(v) {
    Proposals = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
Meteor.publish('proposals.list', function () {
  return Proposals.find({}, {
    sort: {
      proposalId: -1
    }
  });
});
Meteor.publish('proposals.one', function (id) {
  check(id, Number);
  return Proposals.find({
    proposalId: id
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"proposals.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/proposals/proposals.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Proposals: () => Proposals
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Proposals = new Mongo.Collection('proposals');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"records":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/server/methods.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let ValidatorRecords, Analytics, AverageData, AverageValidatorData;
module.link("../records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  AverageData(v) {
    AverageData = v;
  },

  AverageValidatorData(v) {
    AverageValidatorData = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
let ValidatorSets;
module.link("/imports/api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 4);
let Status;
module.link("../../status/status.js", {
  Status(v) {
    Status = v;
  }

}, 5);
let MissedBlocksStats;
module.link("../records.js", {
  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  }

}, 6);
let MissedBlocks;
module.link("../records.js", {
  MissedBlocks(v) {
    MissedBlocks = v;
  }

}, 7);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 8);
let Chain;
module.link("../../chain/chain.js", {
  Chain(v) {
    Chain = v;
  }

}, 9);

let _;

module.link("lodash", {
  default(v) {
    _ = v;
  }

}, 10);
const BULKUPDATEMAXSIZE = 1000;

const getBlockStats = (startHeight, latestHeight) => {
  let blockStats = {};
  const cond = {
    $and: [{
      height: {
        $gt: startHeight
      }
    }, {
      height: {
        $lte: latestHeight
      }
    }]
  };
  const options = {
    sort: {
      height: 1
    }
  };
  Blockscon.find(cond, options).forEach(block => {
    blockStats[block.height] = {
      height: block.height,
      proposerAddress: block.proposerAddress,
      precommitsCount: block.precommitsCount,
      validatorsCount: block.validatorsCount,
      validators: block.validators,
      time: block.time
    };
  });
  Analytics.find(cond, options).forEach(block => {
    if (!blockStats[block.height]) {
      blockStats[block.height] = {
        height: block.height
      };
      console.log("block ".concat(block.height, " does not have an entry"));
    }

    _.assign(blockStats[block.height], {
      precommits: block.precommits,
      averageBlockTime: block.averageBlockTime,
      timeDiff: block.timeDiff,
      voting_power: block.voting_power
    });
  });
  return blockStats;
};

const getPreviousRecord = (voterAddress, proposerAddress) => {
  let previousRecord = MissedBlocks.findOne({
    voter: voterAddress,
    proposer: proposerAddress,
    blockHeight: -1
  });
  let lastUpdatedHeight = Meteor.settings.params.startHeight;
  let prevStats = {};

  if (previousRecord) {
    prevStats = _.pick(previousRecord, ['missCount', 'totalCount']);
  } else {
    prevStats = {
      missCount: 0,
      totalCount: 0
    };
  }

  return prevStats;
};

Meteor.methods({
  'ValidatorRecords.calculateMissedBlocks': function () {
    if (!COUNTMISSEDBLOCKS) {
      try {
        let startTime = Date.now();
        COUNTMISSEDBLOCKS = true;
        console.log('calulate missed blocks count');
        this.unblock();
        let validators = Validators.find({}).fetch();
        let latestHeight = Meteor.call('blocks.getCurrentHeight');
        let explorerStatus = Status.findOne({
          chainId: Meteor.settings.public.chainId
        });
        let startHeight = explorerStatus && explorerStatus.lastProcessedMissedBlockHeight ? explorerStatus.lastProcessedMissedBlockHeight : Meteor.settings.params.startHeight;
        latestHeight = Math.min(startHeight + BULKUPDATEMAXSIZE, latestHeight);
        const bulkMissedStats = MissedBlocks.rawCollection().initializeOrderedBulkOp();
        let validatorsMap = {};
        validators.forEach(validator => validatorsMap[validator.address] = validator); // a map of block height to block stats

        let blockStats = getBlockStats(startHeight, latestHeight); // proposerVoterStats is a proposer-voter map counting numbers of proposed blocks of which voter is an active validator

        let proposerVoterStats = {};

        _.forEach(blockStats, (block, blockHeight) => {
          let proposerAddress = block.proposerAddress;
          let votedValidators = new Set(block.validators);
          let validatorSets = ValidatorSets.findOne({
            block_height: block.height
          });
          let votedVotingPower = 0;
          validatorSets.validators.forEach(activeValidator => {
            if (votedValidators.has(activeValidator.address)) votedVotingPower += parseFloat(activeValidator.voting_power);
          });
          validatorSets.validators.forEach(activeValidator => {
            let currentValidator = activeValidator.address;

            if (!_.has(proposerVoterStats, [proposerAddress, currentValidator])) {
              let prevStats = getPreviousRecord(currentValidator, proposerAddress);

              _.set(proposerVoterStats, [proposerAddress, currentValidator], prevStats);
            }

            _.update(proposerVoterStats, [proposerAddress, currentValidator, 'totalCount'], n => n + 1);

            if (!votedValidators.has(currentValidator)) {
              _.update(proposerVoterStats, [proposerAddress, currentValidator, 'missCount'], n => n + 1);

              bulkMissedStats.insert({
                voter: currentValidator,
                blockHeight: block.height,
                proposer: proposerAddress,
                precommitsCount: block.precommitsCount,
                validatorsCount: block.validatorsCount,
                time: block.time,
                precommits: block.precommits,
                averageBlockTime: block.averageBlockTime,
                timeDiff: block.timeDiff,
                votingPower: block.voting_power,
                votedVotingPower,
                updatedAt: latestHeight,
                missCount: _.get(proposerVoterStats, [proposerAddress, currentValidator, 'missCount']),
                totalCount: _.get(proposerVoterStats, [proposerAddress, currentValidator, 'totalCount'])
              });
            }
          });
        });

        _.forEach(proposerVoterStats, (voters, proposerAddress) => {
          _.forEach(voters, (stats, voterAddress) => {
            bulkMissedStats.find({
              voter: voterAddress,
              proposer: proposerAddress,
              blockHeight: -1
            }).upsert().updateOne({
              $set: {
                voter: voterAddress,
                proposer: proposerAddress,
                blockHeight: -1,
                updatedAt: latestHeight,
                missCount: _.get(stats, 'missCount'),
                totalCount: _.get(stats, 'totalCount')
              }
            });
          });
        });

        let message = '';

        if (bulkMissedStats.length > 0) {
          const client = MissedBlocks._driver.mongo.client; // TODO: add transaction back after replica set(#146) is set up
          // let session = client.startSession();
          // session.startTransaction();

          let bulkPromise = bulkMissedStats.execute(null
          /*, {session}*/
          ).then(Meteor.bindEnvironment((result, err) => {
            if (err) {
              COUNTMISSEDBLOCKS = false; // Promise.await(session.abortTransaction());

              throw err;
            }

            if (result) {
              // Promise.await(session.commitTransaction());
              message = "(".concat(result.result.nInserted, " inserted, ") + "".concat(result.result.nUpserted, " upserted, ") + "".concat(result.result.nModified, " modified)");
            }
          }));
          Promise.await(bulkPromise);
        }

        COUNTMISSEDBLOCKS = false;
        Status.upsert({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastProcessedMissedBlockHeight: latestHeight,
            lastProcessedMissedBlockTime: new Date()
          }
        });
        return "done in ".concat(Date.now() - startTime, "ms ").concat(message);
      } catch (e) {
        COUNTMISSEDBLOCKS = false;
        throw e;
      }
    } else {
      return "updating...";
    }
  },
  'ValidatorRecords.calculateMissedBlocksStats': function () {
    // TODO: deprecate this method and MissedBlocksStats collection
    // console.log("ValidatorRecords.calculateMissedBlocks: "+COUNTMISSEDBLOCKS);
    if (!COUNTMISSEDBLOCKSSTATS) {
      COUNTMISSEDBLOCKSSTATS = true;
      console.log('calulate missed blocks stats');
      this.unblock();
      let validators = Validators.find({}).fetch();
      let latestHeight = Meteor.call('blocks.getCurrentHeight');
      let explorerStatus = Status.findOne({
        chainId: Meteor.settings.public.chainId
      });
      let startHeight = explorerStatus && explorerStatus.lastMissedBlockHeight ? explorerStatus.lastMissedBlockHeight : Meteor.settings.params.startHeight; // console.log(latestHeight);
      // console.log(startHeight);

      const bulkMissedStats = MissedBlocksStats.rawCollection().initializeUnorderedBulkOp();

      for (i in validators) {
        // if ((validators[i].address == "B8552EAC0D123A6BF609123047A5181D45EE90B5") || (validators[i].address == "69D99B2C66043ACBEAA8447525C356AFC6408E0C") || (validators[i].address == "35AD7A2CD2FC71711A675830EC1158082273D457")){
        let voterAddress = validators[i].address;
        let missedRecords = ValidatorRecords.find({
          address: voterAddress,
          exists: false,
          $and: [{
            height: {
              $gt: startHeight
            }
          }, {
            height: {
              $lte: latestHeight
            }
          }]
        }).fetch();
        let counts = {}; // console.log("missedRecords to process: "+missedRecords.length);

        for (b in missedRecords) {
          let block = Blockscon.findOne({
            height: missedRecords[b].height
          });
          let existingRecord = MissedBlocksStats.findOne({
            voter: voterAddress,
            proposer: block.proposerAddress
          });

          if (typeof counts[block.proposerAddress] === 'undefined') {
            if (existingRecord) {
              counts[block.proposerAddress] = existingRecord.count + 1;
            } else {
              counts[block.proposerAddress] = 1;
            }
          } else {
            counts[block.proposerAddress]++;
          }
        }

        for (address in counts) {
          let data = {
            voter: voterAddress,
            proposer: address,
            count: counts[address]
          };
          bulkMissedStats.find({
            voter: voterAddress,
            proposer: address
          }).upsert().updateOne({
            $set: data
          });
        } // }

      }

      if (bulkMissedStats.length > 0) {
        bulkMissedStats.execute(Meteor.bindEnvironment((err, result) => {
          if (err) {
            COUNTMISSEDBLOCKSSTATS = false;
            console.log(err);
          }

          if (result) {
            Status.upsert({
              chainId: Meteor.settings.public.chainId
            }, {
              $set: {
                lastMissedBlockHeight: latestHeight,
                lastMissedBlockTime: new Date()
              }
            });
            COUNTMISSEDBLOCKSSTATS = false;
            console.log("done");
          }
        }));
      } else {
        COUNTMISSEDBLOCKSSTATS = false;
      }

      return true;
    } else {
      return "updating...";
    }
  },
  'Analytics.aggregateBlockTimeAndVotingPower': function (time) {
    this.unblock();
    let now = new Date();

    if (time == 'm') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastMinuteVotingPower: averageVotingPower,
            lastMinuteBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    }

    if (time == 'h') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 60 * 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastHourVotingPower: averageVotingPower,
            lastHourBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    }

    if (time == 'd') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastDayVotingPower: averageVotingPower,
            lastDayBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    } // return analytics.length;

  },
  'Analytics.aggregateValidatorDailyBlockTime': function () {
    this.unblock();
    let validators = Validators.find({}).fetch();
    let now = new Date();

    for (i in validators) {
      let averageBlockTime = 0;
      let blocks = Blockscon.find({
        proposerAddress: validators[i].address,
        "time": {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }, {
        fields: {
          height: 1
        }
      }).fetch();

      if (blocks.length > 0) {
        let blockHeights = [];

        for (b in blocks) {
          blockHeights.push(blocks[b].height);
        }

        let analytics = Analytics.find({
          height: {
            $in: blockHeights
          }
        }, {
          fields: {
            height: 1,
            timeDiff: 1
          }
        }).fetch();

        for (a in analytics) {
          averageBlockTime += analytics[a].timeDiff;
        }

        averageBlockTime = averageBlockTime / analytics.length;
      }

      AverageValidatorData.insert({
        proposerAddress: validators[i].address,
        averageBlockTime: averageBlockTime,
        type: 'ValidatorDailyAverageBlockTime',
        createdAt: now
      });
    }

    return true;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/server/publications.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatorRecords, Analytics, MissedBlocks, MissedBlocksStats, VPDistributions;
module.link("../records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  MissedBlocks(v) {
    MissedBlocks = v;
  },

  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  },

  VPDistributions(v) {
    VPDistributions = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
Meteor.publish('validator_records.all', function () {
  return ValidatorRecords.find();
});
Meteor.publish('validator_records.uptime', function (address, num) {
  return ValidatorRecords.find({
    address: address
  }, {
    limit: num,
    sort: {
      height: -1
    }
  });
});
Meteor.publish('analytics.history', function () {
  return Analytics.find({}, {
    sort: {
      height: -1
    },
    limit: 50
  });
});
Meteor.publish('vpDistribution.latest', function () {
  return VPDistributions.find({}, {
    sort: {
      height: -1
    },
    limit: 1
  });
});
publishComposite('missedblocks.validator', function (address, type) {
  let conditions = {};

  if (type == 'voter') {
    conditions = {
      voter: address
    };
  } else {
    conditions = {
      proposer: address
    };
  }

  return {
    find() {
      return MissedBlocksStats.find(conditions);
    },

    children: [{
      find(stats) {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            profile_url: 1
          }
        });
      }

    }]
  };
});
publishComposite('missedrecords.validator', function (address, type) {
  return {
    find() {
      return MissedBlocks.find({
        [type]: address
      }, {
        sort: {
          updatedAt: -1
        }
      });
    },

    children: [{
      find() {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            operator_address: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"records.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/records.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  ValidatorRecords: () => ValidatorRecords,
  Analytics: () => Analytics,
  MissedBlocksStats: () => MissedBlocksStats,
  MissedBlocks: () => MissedBlocks,
  VPDistributions: () => VPDistributions,
  AverageData: () => AverageData,
  AverageValidatorData: () => AverageValidatorData
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const ValidatorRecords = new Mongo.Collection('validator_records');
const Analytics = new Mongo.Collection('analytics');
const MissedBlocksStats = new Mongo.Collection('missed_blocks_stats');
const MissedBlocks = new Mongo.Collection('missed_blocks');
const VPDistributions = new Mongo.Collection('voting_power_distributions');
const AverageData = new Mongo.Collection('average_data');
const AverageValidatorData = new Mongo.Collection('average_validator_data');
MissedBlocksStats.helpers({
  proposerMoniker() {
    let validator = Validators.findOne({
      address: this.proposer
    });
    return validator.description ? validator.description.moniker : this.proposer;
  },

  voterMoniker() {
    let validator = Validators.findOne({
      address: this.voter
    });
    return validator.description ? validator.description.moniker : this.voter;
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"status":{"server":{"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/status/server/publications.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Status;
module.link("../status.js", {
  Status(v) {
    Status = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
Meteor.publish('status.status', function () {
  return Status.find({
    chainId: Meteor.settings.public.chainId
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"status.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/status/status.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Status: () => Status
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Status = new Mongo.Collection('status');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactions":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/server/methods.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 4);
const AddressLength = 40;
Meteor.methods({
  'Transactions.index': function (hash, blockTime) {
    this.unblock();
    hash = hash.toUpperCase();
    let url = LCD + '/txs/' + hash;
    let response = HTTP.get(url);
    let tx = JSON.parse(response.content);
    console.log(hash);
    tx.height = parseInt(tx.height); // if (!tx.code){
    //     let msg = tx.tx.value.msg;
    //     for (let m in msg){
    //         if (msg[m].type == "cosmos-sdk/MsgCreateValidator"){
    //             console.log(msg[m].value);
    //             let command = Meteor.settings.bin.gaiadebug+" pubkey "+msg[m].value.pubkey;
    //             let validator = {
    //                 consensus_pubkey: msg[m].value.pubkey,
    //                 description: msg[m].value.description,
    //                 commission: msg[m].value.commission,
    //                 min_self_delegation: msg[m].value.min_self_delegation,
    //                 operator_address: msg[m].value.validator_address,
    //                 delegator_address: msg[m].value.delegator_address,
    //                 voting_power: Math.floor(parseInt(msg[m].value.value.amount) / 1000000)
    //             }
    //             Meteor.call('runCode', command, function(error, result){
    //                 validator.address = result.match(/\s[0-9A-F]{40}$/igm);
    //                 validator.address = validator.address[0].trim();
    //                 validator.hex = result.match(/\s[0-9A-F]{64}$/igm);
    //                 validator.hex = validator.hex[0].trim();
    //                 validator.pub_key = result.match(/{".*"}/igm);
    //                 validator.pub_key = JSON.parse(validator.pub_key[0].trim());
    //                 let re = new RegExp(Meteor.settings.public.bech32PrefixAccPub+".*$","igm");
    //                 validator.cosmosaccpub = result.match(re);
    //                 validator.cosmosaccpub = validator.cosmosaccpub[0].trim();
    //                 re = new RegExp(Meteor.settings.public.bech32PrefixValPub+".*$","igm");
    //                 validator.operator_pubkey = result.match(re);
    //                 validator.operator_pubkey = validator.operator_pubkey[0].trim();
    //                 Validators.upsert({consensus_pubkey:msg[m].value.pubkey},validator);
    //                 VotingPowerHistory.insert({
    //                     address: validator.address,
    //                     prev_voting_power: 0,
    //                     voting_power: validator.voting_power,
    //                     type: 'add',
    //                     height: tx.height+2,
    //                     block_time: blockTime
    //                 });
    //             })
    //         }
    //     }
    // }

    let txId = Transactions.insert(tx);

    if (txId) {
      return txId;
    } else return false;
  },
  'Transactions.findDelegation': function (address, height) {
    // following cosmos-sdk/x/slashing/spec/06_events.md and cosmos-sdk/x/staking/spec/06_events.md
    return Transactions.find({
      $or: [{
        $and: [{
          "events.type": "delegate"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.attributes.key": "action"
        }, {
          "events.attributes.value": "unjail"
        }, {
          "events.attributes.key": "sender"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "create_validator"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "unbond"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "redelegate"
        }, {
          "events.attributes.key": "destination_validator"
        }, {
          "events.attributes.value": address
        }]
      }],
      "code": {
        $exists: false
      },
      height: {
        $lt: height
      }
    }, {
      sort: {
        height: -1
      },
      limit: 1
    }).fetch();
  },
  'Transactions.findUser': function (address) {
    let fields = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    // address is either delegator address or validator operator address
    let validator;
    if (!fields) fields = {
      address: 1,
      description: 1,
      operator_address: 1,
      delegator_address: 1
    };

    if (address.includes(Meteor.settings.public.bech32PrefixValAddr)) {
      // validator operator address
      validator = Validators.findOne({
        operator_address: address
      }, {
        fields
      });
    } else if (address.includes(Meteor.settings.public.bech32PrefixAccAddr)) {
      // delegator address
      validator = Validators.findOne({
        delegator_address: address
      }, {
        fields
      });
    } else if (address.length === AddressLength) {
      validator = Validators.findOne({
        address: address
      }, {
        fields
      });
    }

    if (validator) {
      return validator;
    }

    return false;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/server/publications.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Transactions;
module.link("../transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 1);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 2);
publishComposite('transactions.list', function () {
  let limit = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 30;
  return {
    find() {
      return Transactions.find({}, {
        sort: {
          height: -1
        },
        limit: limit
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.validator', function (validatorAddress, delegatorAddress) {
  let limit = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 100;
  let query = {};

  if (validatorAddress && delegatorAddress) {
    query = {
      $or: [{
        "events.attributes.value": validatorAddress
      }, {
        "events.attributes.value": delegatorAddress
      }]
    };
  }

  if (!validatorAddress && delegatorAddress) {
    query = {
      "events.attributes.value": delegatorAddress
    };
  }

  return {
    find() {
      return Transactions.find(query, {
        sort: {
          height: -1
        },
        limit: limit
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.findOne', function (hash) {
  return {
    find() {
      return Transactions.find({
        txhash: hash
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.height', function (height) {
  return {
    find() {
      return Transactions.find({
        height: height
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactions.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/transactions.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Transactions: () => Transactions
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Blockscon;
module.link("../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 1);
let TxIcon;
module.link("../../ui/components/Icons.jsx", {
  TxIcon(v) {
    TxIcon = v;
  }

}, 2);
const Transactions = new Mongo.Collection('transactions');
Transactions.helpers({
  block() {
    return Blockscon.findOne({
      height: this.height
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validators":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 1);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 2);
let Delegations;
module.link("../../delegations/delegations.js", {
  Delegations(v) {
    Delegations = v;
  }

}, 3);
Meteor.methods({
  'Validators.findCreateValidatorTime': function (address) {
    // look up the create validator time to consider if the validator has never updated the commission
    let tx = Transactions.findOne({
      $and: [{
        "tx.value.msg.value.delegator_address": address
      }, {
        "tx.value.msg.type": "cosmos-sdk/MsgCreateValidator"
      }, {
        code: {
          $exists: false
        }
      }]
    });

    if (tx) {
      let block = Blockscon.findOne({
        height: tx.height
      });

      if (block) {
        return block.time;
      }
    } else {
      // no such create validator tx
      return false;
    }
  },

  // async 'Validators.getAllDelegations'(address){
  'Validators.getAllDelegations'(address) {
    let url = LCD + '/staking/validators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        delegations = JSON.parse(delegations.content).result;
        delegations.forEach((delegation, i) => {
          if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
        });
        return delegations;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/server/publications.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Validators;
module.link("../validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
let ValidatorRecords;
module.link("../../records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  }

}, 2);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 3);
Meteor.publish('validators.all', function () {
  let sort = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "description.moniker";
  let direction = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : -1;
  let fields = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return Validators.find({}, {
    sort: {
      [sort]: direction
    },
    fields: fields
  });
});
publishComposite('validators.firstSeen', {
  find() {
    return Validators.find({});
  },

  children: [{
    find(val) {
      return ValidatorRecords.find({
        address: val.address
      }, {
        sort: {
          height: 1
        },
        limit: 1
      });
    }

  }]
});
Meteor.publish('validators.voting_power', function () {
  return Validators.find({
    status: 2,
    jailed: false
  }, {
    sort: {
      voting_power: -1
    },
    fields: {
      address: 1,
      description: 1,
      voting_power: 1,
      profile_url: 1
    }
  });
});
publishComposite('validator.details', function (address) {
  let options = {
    address: address
  };

  if (address.indexOf(Meteor.settings.public.bech32PrefixValAddr) != -1) {
    options = {
      operator_address: address
    };
  }

  return {
    find() {
      return Validators.find(options);
    },

    children: [{
      find(val) {
        return VotingPowerHistory.find({
          address: val.address
        }, {
          sort: {
            height: -1
          },
          limit: 50
        });
      }

    }, {
      find(val) {
        return ValidatorRecords.find({
          address: val.address
        }, {
          sort: {
            height: -1
          },
          limit: Meteor.settings.public.uptimeWindow
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validators.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/validators.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Validators: () => Validators
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let ValidatorRecords;
module.link("../records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  }

}, 1);
let VotingPowerHistory;
module.link("../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 2);
const Validators = new Mongo.Collection('validators');
Validators.helpers({
  firstSeen() {
    return ValidatorRecords.findOne({
      address: this.address
    });
  },

  history() {
    return VotingPowerHistory.find({
      address: this.address
    }, {
      sort: {
        height: -1
      },
      limit: 50
    }).fetch();
  }

}); // Validators.helpers({
//     uptime(){
//         // console.log(this.address);
//         let lastHundred = ValidatorRecords.find({address:this.address}, {sort:{height:-1}, limit:100}).fetch();
//         console.log(lastHundred);
//         let uptime = 0;
//         for (i in lastHundred){
//             if (lastHundred[i].exists){
//                 uptime+=1;
//             }
//         }
//         return uptime;
//     }
// })
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"voting-power":{"server":{"publications.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/voting-power/server/publications.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"history.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/voting-power/history.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  VotingPowerHistory: () => VotingPowerHistory
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const VotingPowerHistory = new Mongo.Collection('voting_power_history');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"evidences":{"evidences.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/evidences/evidences.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Evidences: () => Evidences
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Evidences = new Mongo.Collection('evidences');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validator-sets":{"validator-sets.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validator-sets/validator-sets.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  ValidatorSets: () => ValidatorSets
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const ValidatorSets = new Mongo.Collection('validator_sets');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"startup":{"both":{"index.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/both/index.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Import modules used by both client and server through a single index entry point
// e.g. useraccounts configuration file.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"create-indexes.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/create-indexes.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Blockscon;
module.link("../../api/blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 0);
let Proposals;
module.link("../../api/proposals/proposals.js", {
  Proposals(v) {
    Proposals = v;
  }

}, 1);
let ValidatorRecords, Analytics, MissedBlocksStats, MissedBlocks, AverageData, AverageValidatorData;
module.link("../../api/records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  },

  MissedBlocks(v) {
    MissedBlocks = v;
  },

  AverageData(v) {
    AverageData = v;
  },

  AverageValidatorData(v) {
    AverageValidatorData = v;
  }

}, 2);
let Transactions;
module.link("../../api/transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 3);
let ValidatorSets;
module.link("../../api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 4);
let Validators;
module.link("../../api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 5);
let VotingPowerHistory;
module.link("../../api/voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 6);
let Evidences;
module.link("../../api/evidences/evidences.js", {
  Evidences(v) {
    Evidences = v;
  }

}, 7);
let CoinStats;
module.link("../../api/coin-stats/coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 8);
let ChainStates;
module.link("../../api/chain/chain.js", {
  ChainStates(v) {
    ChainStates = v;
  }

}, 9);
ChainStates.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
Blockscon.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
Blockscon.rawCollection().createIndex({
  proposerAddress: 1
});
Evidences.rawCollection().createIndex({
  height: -1
}); //Proposals.rawCollection().createIndex({proposalId: 1}, {unique:true});

ValidatorRecords.rawCollection().createIndex({
  address: 1,
  height: -1
}, {
  unique: 1
});
ValidatorRecords.rawCollection().createIndex({
  address: 1,
  exists: 1,
  height: -1
});
Analytics.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
MissedBlocks.rawCollection().createIndex({
  proposer: 1,
  voter: 1,
  updatedAt: -1
});
MissedBlocks.rawCollection().createIndex({
  proposer: 1,
  blockHeight: -1
});
MissedBlocks.rawCollection().createIndex({
  voter: 1,
  blockHeight: -1
});
MissedBlocks.rawCollection().createIndex({
  voter: 1,
  proposer: 1,
  blockHeight: -1
}, {
  unique: true
});
MissedBlocksStats.rawCollection().createIndex({
  proposer: 1
});
MissedBlocksStats.rawCollection().createIndex({
  voter: 1
});
MissedBlocksStats.rawCollection().createIndex({
  proposer: 1,
  voter: 1
}, {
  unique: true
});
AverageData.rawCollection().createIndex({
  type: 1,
  createdAt: -1
}, {
  unique: true
});
AverageValidatorData.rawCollection().createIndex({
  proposerAddress: 1,
  createdAt: -1
}, {
  unique: true
}); // Status.rawCollection.createIndex({})

Transactions.rawCollection().createIndex({
  txhash: 1
}, {
  unique: true
});
Transactions.rawCollection().createIndex({
  height: -1
}); // Transactions.rawCollection().createIndex({action:1});

Transactions.rawCollection().createIndex({
  "events.attributes.key": 1
});
Transactions.rawCollection().createIndex({
  "events.attributes.value": 1
});
ValidatorSets.rawCollection().createIndex({
  block_height: -1
});
Validators.rawCollection().createIndex({
  address: 1
}, {
  unique: true,
  partialFilterExpression: {
    address: {
      $exists: true
    }
  }
});
Validators.rawCollection().createIndex({
  consensus_pubkey: 1
}, {
  unique: true
});
Validators.rawCollection().createIndex({
  "pub_key.value": 1
}, {
  unique: true,
  partialFilterExpression: {
    "pub_key.value": {
      $exists: true
    }
  }
});
VotingPowerHistory.rawCollection().createIndex({
  address: 1,
  height: -1
});
VotingPowerHistory.rawCollection().createIndex({
  type: 1
});
CoinStats.rawCollection().createIndex({
  last_updated_at: -1
}, {
  unique: true
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/index.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("./util.js");
module.link("./register-api.js");
module.link("./create-indexes.js");
let onPageLoad;
module.link("meteor/server-render", {
  onPageLoad(v) {
    onPageLoad = v;
  }

}, 0);
let Helmet;
module.link("react-helmet", {
  Helmet(v) {
    Helmet = v;
  }

}, 1);
// import App from '../../ui/App.jsx';
onPageLoad(sink => {
  // const context = {};
  // const sheet = new ServerStyleSheet()
  // const html = renderToString(sheet.collectStyles(
  //     <StaticRouter location={sink.request.url} context={context}>
  //         <App />
  //     </StaticRouter>
  //   ));
  // sink.renderIntoElementById('app', html);
  const helmet = Helmet.renderStatic();
  sink.appendToHead(helmet.meta.toString());
  sink.appendToHead(helmet.title.toString()); // sink.appendToHead(sheet.getStyleTags());
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"register-api.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/register-api.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("../../api/ledger/server/methods.js");
module.link("../../api/chain/server/methods.js");
module.link("../../api/chain/server/publications.js");
module.link("../../api/blocks/server/methods.js");
module.link("../../api/blocks/server/publications.js");
module.link("../../api/validators/server/methods.js");
module.link("../../api/validators/server/publications.js");
module.link("../../api/records/server/methods.js");
module.link("../../api/records/server/publications.js");
module.link("../../api/proposals/server/methods.js");
module.link("../../api/proposals/server/publications.js");
module.link("../../api/enterprise/server/methods.js");
module.link("../../api/enterprise/server/publications.js");
module.link("../../api/voting-power/server/publications.js");
module.link("../../api/transactions/server/methods.js");
module.link("../../api/transactions/server/publications.js");
module.link("../../api/delegations/server/methods.js");
module.link("../../api/delegations/server/publications.js");
module.link("../../api/status/server/publications.js");
module.link("../../api/accounts/server/methods.js");
module.link("../../api/coin-stats/server/methods.js");
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"util.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/util.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let bech32;
module.link("bech32", {
  default(v) {
    bech32 = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let cheerio;
module.link("cheerio", {
  "*"(v) {
    cheerio = v;
  }

}, 2);

// Load future from fibers
var Future = Npm.require("fibers/future"); // Load exec


var exec = Npm.require("child_process").exec;

function toHexString(byteArray) {
  return byteArray.map(function (byte) {
    return ('0' + (byte & 0xFF).toString(16)).slice(-2);
  }).join('');
}

Meteor.methods({
  pubkeyToBech32: function (pubkey, prefix) {
    // '1624DE6420' is ed25519 pubkey prefix
    let pubkeyAminoPrefix = Buffer.from('1624DE6420', 'hex');
    let buffer = Buffer.alloc(37);
    pubkeyAminoPrefix.copy(buffer, 0);
    Buffer.from(pubkey.value, 'base64').copy(buffer, pubkeyAminoPrefix.length);
    return bech32.encode(prefix, bech32.toWords(buffer));
  },
  bech32ToPubkey: function (pubkey) {
    // '1624DE6420' is ed25519 pubkey prefix
    let pubkeyAminoPrefix = Buffer.from('1624DE6420', 'hex');
    let buffer = Buffer.from(bech32.fromWords(bech32.decode(pubkey).words));
    return buffer.slice(pubkeyAminoPrefix.length).toString('base64');
  },
  getDelegator: function (operatorAddr) {
    let address = bech32.decode(operatorAddr);
    return bech32.encode(Meteor.settings.public.bech32PrefixAccAddr, address.words);
  },
  getKeybaseTeamPic: function (keybaseUrl) {
    let teamPage = HTTP.get(keybaseUrl);

    if (teamPage.statusCode == 200) {
      let page = cheerio.load(teamPage.content);
      return page(".kb-main-card img").attr('src');
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"ui":{"components":{"Icons.jsx":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/ui/components/Icons.jsx                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  DenomSymbol: () => DenomSymbol,
  ProposalStatusIcon: () => ProposalStatusIcon,
  VoteIcon: () => VoteIcon,
  TxIcon: () => TxIcon,
  InfoIcon: () => InfoIcon
});
let React;
module.link("react", {
  default(v) {
    React = v;
  }

}, 0);
let UncontrolledTooltip;
module.link("reactstrap", {
  UncontrolledTooltip(v) {
    UncontrolledTooltip = v;
  }

}, 1);

const DenomSymbol = props => {
  switch (props.denom) {
    case "steak":
      return '🥩';

    default:
      return '🍅';
  }
};

const ProposalStatusIcon = props => {
  switch (props.status) {
    case 'Passed':
      return React.createElement("i", {
        className: "fas fa-check-circle text-success"
      });

    case 'Rejected':
      return React.createElement("i", {
        className: "fas fa-times-circle text-danger"
      });

    case 'Removed':
      return React.createElement("i", {
        className: "fas fa-trash-alt text-dark"
      });

    case 'DepositPeriod':
      return React.createElement("i", {
        className: "fas fa-battery-half text-warning"
      });

    case 'VotingPeriod':
      return React.createElement("i", {
        className: "fas fa-hand-paper text-info"
      });

    default:
      return React.createElement("i", null);
  }
};

const VoteIcon = props => {
  switch (props.vote) {
    case 'yes':
      return React.createElement("i", {
        className: "fas fa-check text-success"
      });

    case 'no':
      return React.createElement("i", {
        className: "fas fa-times text-danger"
      });

    case 'abstain':
      return React.createElement("i", {
        className: "fas fa-user-slash text-warning"
      });

    case 'no_with_veto':
      return React.createElement("i", {
        className: "fas fa-exclamation-triangle text-info"
      });

    default:
      return React.createElement("i", null);
  }
};

const TxIcon = props => {
  if (props.valid) {
    return React.createElement("span", {
      className: "text-success text-nowrap"
    }, React.createElement("i", {
      className: "fas fa-check-circle"
    }));
  } else {
    return React.createElement("span", {
      className: "text-danger text-nowrap"
    }, React.createElement("i", {
      className: "fas fa-times-circle"
    }));
  }
};

class InfoIcon extends React.Component {
  constructor(props) {
    super(props);
    this.ref = React.createRef();
  }

  render() {
    return [React.createElement("i", {
      key: "icon",
      className: "material-icons info-icon",
      ref: this.ref
    }, "info"), React.createElement(UncontrolledTooltip, {
      key: "tooltip",
      placement: "right",
      target: this.ref
    }, this.props.children ? this.props.children : this.props.tooltipText)];
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"both":{"i18n":{"en-us.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/en-us.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('en-US','',{"common":{"height":"Height","voter":"Voter","votingPower":"Voting Power","addresses":"Addresses","amounts":"Amounts","delegators":"delegators","block":"block","blocks":"blocks","precommit":"precommit","precommits":"precommits","last":"last","backToList":"Back to List","information":"Information","time":"Time","hash":"Hash","more":"More","fullStop":".","searchPlaceholder":"Search with tx hash / block height / address","cancel":"Cancel","retry":"Retry"},"navbar":{"siteName":"Unification Mainchain","version":"beta","validators":"Validators","blocks":"Blocks","transactions":"Transactions","proposals":"Proposals","votingPower":"Voting Power","lang":"ENG","english":"English","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"Fork me!","signers":"Signers"},"consensus":{"consensusState":"Consensus State","round":"Round","step":"Step"},"chainStates":{"price":"Price","marketCap":"Market Cap","inflation":"Inflation","communityPool":"Community Pool"},"chainStatus":{"startMessage":"The chain is going to start in","stopWarning":"The chain appears to be stopped for <em>{$time}</em>! Feed me with new blocks 😭!","latestHeight":"Latest Block Height","averageBlockTime":"Average Block Time","all":"All","now":"Now","allTime":"All Time","lastMinute":"Last Minute","lastHour":"Last Hour","lastDay":"Last Day","seconds":"seconds","activeValidators":"Active Validators","outOfValidators":"out of {$totalValidators} validators","onlineVotingPower":"Online Voting Power","fromTotalStakes":"{$percent} from {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"Block Time History","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"Random Validators","moniker":"Moniker","uptime":"Uptime","selfPercentage":"Self%","commission":"Commission","lastSeen":"Last Seen","status":"Status","jailed":"Jailed","navActive":"Active","navInactive":"Inactive","active":"Active Validators","inactive":"Inactive Validators","listOfActive":"Here is a list of active validators.","listOfInactive":"Here is a list of inactive validators.","validatorDetails":"Validator Details","lastNumBlocks":"Last {$numBlocks} blocks","validatorInfo":"Validator Info","operatorAddress":"Operator Address","selfDelegationAddress":"Self-Delegate Address","commissionRate":"Commission Rate","maxRate":"Max Rate","maxChangeRate":"Max Change Rate","selfDelegationRatio":"Self Delegation Ratio","proposerPriority":"Proposer Priority","delegatorShares":"Delegator Shares","userDelegateShares":"Shares Delegated by you","tokens":"Tokens","unbondingHeight":"Unbonding Height","unbondingTime":"Unbonding Time","powerChange":"Power Change","delegations":"Delegations","transactions":"Transactions","validatorNotExists":"Validator does not exist.","backToValidator":"Back to Validator","missedBlocks":"Missed Blocks","missedPrecommits":"Missed Precommits","missedBlocksTitle":"Missed blocks of {$moniker}","totalMissed":"Total missed","block":"Block","missedCount":"Miss Count","iDontMiss":"I do not miss ","lastSyncTime":"Last sync time","delegator":"Delegator","amount":"Amount","website":"Website"},"blocks":{"block":"Block","proposer":"Proposer","latestBlocks":"Latest blocks","noBlock":"No block.","numOfTxs":"No. of Txs","numOfTransactions":"No. of Transactions","notFound":"No such block found."},"transactions":{"transaction":"Transaction","transactions":"Transactions","notFound":"No transaction found.","activities":"Activities","txHash":"Tx Hash","valid":"Valid","fee":"Fee","gasUsedWanted":"Gas (used / wanted)","noTxFound":"No such transaction found.","noValidatorTxsFound":"No transaction related to this validator was found.","memo":"Memo","transfer":"Transfer","staking":"Staking","distribution":"Distribution","governance":"Governance","slashing":"Slashing","enterprise":"Enterprise","wrkchain":"WRKChain","beacon":"BEACON"},"proposals":{"notFound":"No proposal found.","listOfProposals":"Here is a list of governance proposals.","proposer":"Proposer","proposal":"proposal","proposals":"Proposals","proposalID":"Proposal ID","title":"Title","status":"Status","submitTime":"Submit Time","depositEndTime":"Deposit End Time","votingStartTime":"Voting Start Time","votingEndTime":"End Voting Time","totalDeposit":"Total Deposit","description":"Description","changes":"Parameter Changes","proposalType":"Proposal Type","proposalStatus":"Proposal Status","notStarted":"not started","final":"final","deposit":"Deposit","tallyResult":"Tally Result","yes":"Yes","abstain":"Abstain","no":"No","noWithVeto":"No with Veto","percentageVoted":"<span class=\"text-info\">{$percent}</span> of online voting power has been voted.","validMessage":"This proposal is {$tentative}<strong>valid</strong>.","invalidMessage":"Less than {$quorum} of voting power is voted. This proposal is <strong>invalid</strong>.","moreVoteMessage":"It will be a valid proposal once <span class=\"text-info\">{$moreVotes}</span> more votes are casted."},"votingPower":{"distribution":"Voting Power Distribution","pareto":"Pareto Principle (20/80 rule)","minValidators34":"Min no. of validators hold 34%+ power"},"accounts":{"accountDetails":"Account Details","available":"Available","delegated":"Delegated","unbonding":"Unbonding","rewards":"Rewards","total":"Total","notFound":"This account does not exist. Are you looking for a wrong address?","validators":"Validators","shares":"Shares","mature":"Mature","no":"No ","delegation":"Delegation","plural":"s","signOut":"Sign out","signInText":"You are signed in as ","toLoginAs":"To log in as","signInWithLedger":"Sign In With Ledger","signInWarning":"Please make sure your Ledger device is connected and <strong class=\"text-primary\">Cosmos App 1.5.0 or above</strong> is opened.","pleaseAccept":"please accept in your Ledger device."},"signers":{"latestSigners":"Latest Signers","signers":"Signers","active":"Active Signers","activeValidators":"Active Validators","blocksSigned":"Blocks Signed","signed":"Signed","percentMissed":"% Missed","lastSigned":"Last # Signed"},"activities":{"single":"A","happened":"happened.","senders":"The following sender(s)","sent":"sent","receivers":"to the following receipient(s)","received":"received","failedTo":"failed to ","to":"to","from":"from","operatingAt":"operating at","withMoniker":"with moniker","withTitle":"with title","withA":"with a","purchased":"purchased","decision":"decision"},"messageTypes":{"send":"Send","multiSend":"Multi Send","createValidator":"Create Validator","editValidator":"Edit Validator","delegate":"Delegate","undelegate":"Undelegate","redelegate":"Redelegate","submitProposal":"Submit Proposal","deposit":"Deposit","vote":"Vote","withdrawComission":"Withdraw Commission","withdrawReward":"Withdraw Reward","modifyWithdrawAddress":"Modify Withdraw Address","unjail":"Unjail","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive","enterprisePurchase":"Purchase Enterprise UND","enterpriseProcess":"Process Enterprise Purchase Order","wrkchainRegister":"Register WRKChain","wrkchainRecord":"Record WRKChain Hashes","beaconRegister":"Register BEACON","beaconRecord":"Record BEACON Timestamp"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"zh-hans.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/zh-hans.i18n.yml.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('zh-Hans','',{"common":{"height":"高度","voter":"投票人","votingPower":"投票权","addresses":"地址","amounts":"数量","delegators":"委托人","block":"区块","blocks":"区块","precommit":"建块前保证","precommits":"建块前保证","last":"最后","backToList":"回到列表","information":"资讯","time":"时间","hash":"哈希","more":"更多","fullStop":"。","searchPlaceholder":"搜寻交易哈希 / 区块高度 / 地址","cancel":"取消","retry":"重试"},"navbar":{"siteName":"北斗","version":"beta","validators":"验证人","blocks":"区块","transactions":"交易","proposals":"治理提案","votingPower":"投票权分布","lang":"中文（简）","english":"English","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"Fork me!","signers":"签名人"},"consensus":{"consensusState":"共识状态","round":"轮数","step":"阶数"},"chainStates":{"price":"价格","marketCap":"市值","inflation":"通胀率","communityPool":"社区储备"},"chainStatus":{"startMessage":"这链将还有以下时间便会开始","stopWarning":"这链似乎已经停了 <em>{$time}</em>！ 请继续喂我吃新的区块 😭!","latestHeight":"最新区块高度","averageBlockTime":"平均区块时间","all":"全部","now":"现在","allTime":"全部","lastMinute":"前一分钟","lastHour":"前一小时","lastDay":"前一天","seconds":"秒","activeValidators":"有效验证人","outOfValidators":"来自总共 {$totalValidators} 个验证人","onlineVotingPower":"在线投票权","fromTotalStakes":"为 {$totalStakes} 颗 {$denom} 的 {$percent}"},"analytics":{"blockTimeHistory":"在线投票权","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"随机验证人","moniker":"验证人代号","uptime":"上线时间比重","selfPercentage":"自我委托%","commission":"佣金","lastSeen":"最后投票时间","status":"状态","jailed":"被禁制","navActive":"有效","navInactive":"无效","active":"有效验证人","inactive":"无效验证人","listOfActive":"这名单显示所有有效验证人","listOfInactive":"这名单显示所有无效验证人","validatorDetails":"验证人详情","lastNumBlocks":"最后 {$numBlocks} 个区块","validatorInfo":"验证人资讯","operatorAddress":"操作地址","selfDelegationAddress":"自我委托地址","commissionRate":"佣金","maxRate":"最大佣金限制","maxChangeRate":"每天最大佣金变化限制","selfDelegationRatio":"自我委托比例","proposerPriority":"建块优先权","delegatorShares":"委托股数","userDelegateShares":"你委托的股数","tokens":"代币数量","unbondingHeight":"解绑高度","unbondingTime":"解绑时间","powerChange":"投票权变更","delegations":"委托","transactions":"交易","validatorNotExists":"验证人不存在。","backToValidator":"回到验证人页面","missedBlocks":"错过了的区块","missedPrecommits":"遗留了的建块前保证","missedBlocksTitle":"错过了 {$moniker} 的区块","totalMissed":"一共错过了","block":"区块","missedCount":"错过数量","iDontMiss":"我不会错过任何一个","lastSyncTime":"上一次同步时间","delegator":"委托人","amount":"数量","website":"网站"},"blocks":{"proposer":"建块人","block":"区块","latestBlocks":"最近区块","noBlock":"没有区块。","numOfTxs":"交易数量","numOfTransactions":"交易数量","notFound":"没有这个区块。"},"transactions":{"transaction":"交易","transactions":"交易","notFound":"沒有交易。","activities":"活动","txHash":"交易哈希","valid":"有效","fee":"费用","gasUsedWanted":"瓦斯 (已用 / 要求)","noTxFound":"没有这笔交易。","noValidatorTxsFound":"没有跟这个验证人有关的交易","memo":"备忘录","transfer":"代币转移","staking":"委托","distribution":"收益分配","governance":"链上治理","slashing":"削减","enterprise":"企业","wrkchain":"WRKChain","beacon":"BEACON"},"proposals":{"notFound":"没有治理提案","listOfProposals":"这名单显示所有治理提案","proposer":"提案人","proposal":"治理提案","proposals":"治理提案","proposalID":"提案编号","title":"主题","status":"状态","submitTime":"提案时间","depositEndTime":"存入押金","votingStartTime":"投票开始时间","votingEndTime":"投票结束时间","totalDeposit":"押金总额","description":"详细内容","changes":"Parameter Changes","proposalType":"提案类型","proposalStatus":"提案状态","notStarted":"未开始","final":"最后结果","deposit":"押金","tallyResult":"投票结果","yes":"赞成","abstain":"弃权","no":"反对","noWithVeto":"强烈反对","percentageVoted":"现时在线投票权的投票率是 <span class=\"text-info\">{$percent}</span>。","validMessage":"这个提案 {$tentative} <strong>有效</strong>.","invalidMessage":"已投票的在线投票权少于 {$quorum}。这个提案 <strong>無效</strong>。","moreVoteMessage":"当再有多 <span class=\"text-info\">{$moreVotes}</span> 投票权投了票的话，这个提案将会有效。"},"votingPower":{"distribution":"投票权分布","pareto":"帕累托原则 (20/80 定率)","minValidators34":"最少合共有超过 34% 投票权的验证人"},"accounts":{"accountDetails":"帐户详情","available":"可用的","delegated":"委托中","unbonding":"解绑中","rewards":"未取回收益","total":"总共","notFound":"这个帐户不存在。你是否在查看一个错误的地址？","validators":"验证人","shares":"股数","mature":"成熟日期","no":"没有","delegation":"委托","plural":"","signOut":"登出","signInText":"你已登录以下帐户","toLoginAs":"登录以下帐户","signInWithLedger":"透过 Ledger 登录","signInWarning":"请确定你已经连接 Ledger 设备，并已开启 <strong class=\"text-primary\">Cosmos App 版本 1.5.0 或以上</strong>。","pleaseAccept":"请从你的 Ledger 设备确认。"},"signers":{"latestSigners":"Latest Signers","signers":"Signers","active":"Active Signers","activeValidators":"Active Validators","blocksSigned":"Blocks Signed","signed":"Signed","percentMissed":"% Missed","lastSigned":"Last # Signed"},"activities":{"single":"一个","happened":"发生了","senders":"以下的帐户","sent":"发了","receivers":"到以下的帐户","received":"收到","failedTo":"未能","to":"到","from":"从","operatingAt":"操作地址为","withMoniker":"而验证人代号为","withTitle":"治理提案主题为","withA":"投了","purchased":"已购买","decision":"决定"},"messageTypes":{"send":"发送","multiSend":"多重发送","createValidator":"建立验证人","editValidator":"编辑验证人资料","delegate":"委托","undelegate":"解委托","redelegate":"转委托","submitProposal":"提交议案","deposit":"存入","vote":"投票","withdrawComission":"提取手续费","withdrawReward":"提取收益","modifyWithdrawAddress":"更改收益取回地址","unjail":"赦免","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive","enterprisePurchase":"Purchase Enterprise UND","enterpriseProcess":"Process Enterprise Purchase Order","wrkchainRegister":"Register WRKChain","wrkchainRecord":"Record WRKChain Hashes","beaconRegister":"Register BEACON","beaconRecord":"Record BEACON Timestamp"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"zh-hant.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/zh-hant.i18n.yml.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('zh-Hant','',{"common":{"height":"高度","voter":"投票人","votingPower":"投票權","addresses":"地址","amounts":"數量","delegators":"委托人","block":"區塊","blocks":"區塊","precommit":"建塊前保證","precommits":"建塊前保證","last":"最後","backToList":"回到列表","information":"資訊","time":"時間","hash":"哈希","more":"更多","fullStop":"。","searchPlaceholder":"搜尋交易哈希 / 區塊高度 / 地址","cancel":"取消","retry":"重試"},"navbar":{"siteName":"北斗","version":"beta","validators":"驗證人","blocks":"區塊","transactions":"交易","proposals":"治理提案","votingPower":"投票權分佈","lang":"中文（繁）","english":"English","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"Fork me!","signers":"簽名人"},"consensus":{"consensusState":"共識狀態","round":"輪數","step":"階數"},"chainStates":{"price":"價格","marketCap":"市值","inflation":"通漲率","communityPool":"社區儲備"},"chainStatus":{"startMessage":"這鏈將還有以下時間便會開始","stopWarning":"這鏈似乎已經停了 <em>{$time}</em>！ 請繼續餵我吃新的區塊 😭!","latestHeight":"最新區塊高度","averageBlockTime":"平均區塊時間","all":"全部","now":"現在","allTime":"全部","lastMinute":"前一分鐘","lastHour":"前一小時","lastDay":"前一天","seconds":"秒","activeValidators":"有效驗證人","outOfValidators":"來自總共 {$totalValidators} 個驗證人","onlineVotingPower":"在線投票權","fromTotalStakes":"為 {$totalStakes} 顆 {$denom} 的 {$percent}"},"analytics":{"blockTimeHistory":"在線投票權","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"隨機驗證人","moniker":"驗證人代號","uptime":"上線時間比重","selfPercentage":"自我委托%","commission":"佣金","lastSeen":"最後投票時間","status":"狀態","jailed":"被禁制","navActive":"有效","navInactive":"無效","active":"有效驗證人","inactive":"無效驗證人","listOfActive":"這名單顯示所有有效驗證人","listOfInactive":"這名單顯示所有無效驗證人","validatorDetails":"驗證人詳情","lastNumBlocks":"最後 {$numBlocks} 個區塊","validatorInfo":"驗證人資訊","operatorAddress":"操作地址","selfDelegationAddress":"自我委托地址","commissionRate":"佣金","maxRate":"最大佣金限制","maxChangeRate":"每天最大佣金變化限制","selfDelegationRatio":"自我委托比列","proposerPriority":"建塊優先權","delegatorShares":"委托股數","userDelegateShares":"你委托的股數","tokens":"代幣數量","unbondingHeight":"解綁高度","unbondingTime":"解綁時間","powerChange":"投票權變更","delegations":"委托","transactions":"交易","validatorNotExists":"驗證人不存在。","backToValidator":"回到驗證人頁面","missedBlocks":"錯過了的區塊","missedPrecommits":"遺留了的建塊前保證","missedBlocksTitle":"錯過了 {$moniker} 的區塊","totalMissed":"一共錯過了","block":"區塊","missedCount":"錯過數量","iDontMiss":"我不會錯過任何一個","lastSyncTime":"上一次同步時間","delegator":"委托人","amount":"數量","website":"網站"},"blocks":{"proposer":"建塊人","block":"區塊","latestBlocks":"最近區塊","noBlock":"沒有區塊。","numOfTxs":"交易數量","numOfTransactions":"交易數量","notFound":"沒有這個區塊。"},"transactions":{"transaction":"交易","transactions":"交易","notFound":"沒有交易。","activities":"活動","txHash":"交易哈希","valid":"有效","fee":"費用","gasUsedWanted":"瓦斯 (已用 / 要求)","noTxFound":"沒有這筆交易。","noValidatorTxsFound":"沒有跟這個驗證人有關的交易","memo":"備忘錄","transfer":"代幣轉移","staking":"委托","distribution":"收益分配","governance":"鏈上治理","slashing":"削減","enterprise":"企業","wrkchain":"WRKChain","beacon":"BEACON"},"proposals":{"notFound":"沒有治理提案","listOfProposals":"這名單顯示所有治理提案","proposer":"提案人","proposal":"治理提案","proposals":"治理提案","proposalID":"提案編號","title":"主題","status":"狀態","submitTime":"提案時間","depositEndTime":"存入押金","votingStartTime":"投票開始時間","votingEndTime":"投票結束時間","totalDeposit":"押金總額","description":"詳細內容","changes":"Parameter Changes","proposalType":"提案類型","proposalStatus":"提案狀態","notStarted":"未開始","final":"最後結果","deposit":"押金","tallyResult":"投票結果","yes":"贊成","abstain":"棄權","no":"反對","noWithVeto":"強烈反對","percentageVoted":"現時在線投票權的投票率是 <span class=\"text-info\">{$percent}</span>。","validMessage":"這個提案 {$tentative} <strong>有效</strong>.","invalidMessage":"已投票的在線投票權少於 {$quorum}。這個 <strong>無效</strong>。","moreVoteMessage":"當再有多 <span class=\"text-info\">{$moreVotes}</span> 投票權投了票的話，這個提案將會有效。"},"votingPower":{"distribution":"投票權分佈","pareto":"帕累托原則 (20/80 定率)","minValidators34":"最少合共有超過 34% 投票權的驗證人"},"accounts":{"accountDetails":"帳戶詳情","available":"可用的","delegated":"委托中","unbonding":"解綁中","rewards":"未取回收益","total":"總共","notFound":"這個帳戶不存在。你是否在查看一個錯誤的地址？","validators":"驗證人","shares":"股數","mature":"成熟日期","no":"沒有","delegation":"委托","plural":"","signOut":"登出","signInText":"你已登入以下帳戶","toLoginAs":"登入以下帳戶","signInWithLedger":"透過 Ledger 登入","signInWarning":"請確定你已經連接 Ledger 設備，並已開啓 <strong class=\"text-primary\">Cosmos App 版本 1.5.0 或以上</strong>。","pleaseAccept":"請從你的 Ledger 設備確認。"},"signers":{"latestSigners":"Latest Signers","signers":"Signers","active":"Active Signers","activeValidators":"Active Validators","blocksSigned":"Blocks Signed","signed":"Signed","percentMissed":"% Missed","lastSigned":"Last # Signed"},"activities":{"single":"一個","happened":"發生了","senders":"以下的帳戶","sent":"發了","receivers":"到以下的帳戶","received":"收到","failedTo":"未能","to":"到","from":"從","operatingAt":"操作地止為","withMoniker":"而驗證人代號為","withTitle":"治理提案主題為","withA":"投了","purchased":"已購買","decision":"決定"},"messageTypes":{"send":"發送","multiSend":"多重發送","createValidator":"建立驗證人","editValidator":"編輯驗證人資料","delegate":"委托","undelegate":"解委托","redelegate":"轉委托","submitProposal":"提交議案","deposit":"存入","vote":"投票","withdrawComission":"提取手續費","withdrawReward":"提取收益","modifyWithdrawAddress":"更改收益取回地址","unjail":"赦免","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive","enterprisePurchase":"Purchase Enterprise UND","enterpriseProcess":"Process Enterprise Purchase Order","wrkchainRegister":"Register WRKChain","wrkchainRecord":"Record WRKChain Hashes","beaconRegister":"Register BEACON","beaconRecord":"Record BEACON Timestamp"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"utils":{"coins.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/utils/coins.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => Coin
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let numbro;
module.link("numbro", {
  default(v) {
    numbro = v;
  }

}, 1);

autoformat = value => {
  let formatter = '0,0.0000';
  value = Math.round(value * 1000) / 1000;
  if (Math.round(value) === value) formatter = '0,0';else if (Math.round(value * 10) === value * 10) formatter = '0,0.0';else if (Math.round(value * 100) === value * 100) formatter = '0,0.00';else if (Math.round(value * 1000) === value * 1000) formatter = '0,0.000';
  return numbro(value).format(formatter);
};

class Coin {
  constructor(amount) {
    let denom = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    if (typeof amount === 'object') ({
      amount,
      denom
    } = amount);

    if (!denom || denom.toLowerCase() === Coin.MintingDenom.toLowerCase()) {
      this._amount = Number(amount);
    } else if (denom.toLowerCase() === Coin.StakingDenom.toLowerCase()) {
      this._amount = Number(amount) * Coin.StakingFraction;
    } else {
      throw Error("unsupported denom ".concat(denom));
    }
  }

  get amount() {
    return this._amount;
  }

  get stakingAmount() {
    return this._amount / Coin.StakingFraction;
  }

  toString(precision) {
    // default to display in mint denom if it has more than 4 decimal places
    let minStake = Coin.StakingFraction / (precision ? Math.pow(10, precision) : 10000);

    if (this.amount < minStake) {
      return "".concat(numbro(this.amount).format('0,0'), " ").concat(Coin.MintingDenom);
    } else {
      return "".concat(precision ? numbro(this.stakingAmount).format('0,0.' + '0'.repeat(precision)) : autoformat(this.stakingAmount), " ").concat(Coin.StakingDenom);
    }
  }

  mintString(formatter) {
    let amount = this.amount;

    if (formatter) {
      amount = numbro(amount).format(formatter);
    }

    return "".concat(amount, " ").concat(Coin.MintingDenom);
  }

  stakeString(formatter) {
    let amount = this.stakingAmount;

    if (formatter) {
      amount = numbro(amount).format(formatter);
    }

    return "".concat(amount, " ").concat(Coin.StakingDenom);
  }

}

Coin.StakingDenom = Meteor.settings.public.stakingDenom;
Coin.StakingDenomPlural = Meteor.settings.public.stakingDenomPlural || Coin.StakingDenom + 's';
Coin.MintingDenom = Meteor.settings.public.mintingDenom;
Coin.StakingFraction = Number(Meteor.settings.public.stakingFraction);
Coin.MinStake = 1 / Number(Meteor.settings.public.stakingFraction);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("/imports/startup/server");
module.link("/imports/startup/both");
// import moment from 'moment';
// import '/imports/api/blocks/blocks.js';
SYNCING = false;
COUNTMISSEDBLOCKS = false;
COUNTMISSEDBLOCKSSTATS = false;
RPC = Meteor.settings.remote.rpc;
LCD = Meteor.settings.remote.lcd;
timerBlocks = 0;
timerChain = 0;
timerConsensus = 0;
timerProposal = 0;
timerProposalsResults = 0;
timerMissedBlock = 0;
timerDelegation = 0;
timerAggregate = 0;
const DEFAULTSETTINGS = '/default_settings.json';

updateChainStatus = () => {
  Meteor.call('chain.updateStatus', (error, result) => {
    if (error) {
      console.log("updateStatus: " + error);
    } else {
      console.log("updateStatus: " + result);
    }
  });
};

updateBlock = () => {
  Meteor.call('blocks.blocksUpdate', (error, result) => {
    if (error) {
      console.log("updateBlocks: " + error);
    } else {
      console.log("updateBlocks: " + result);
    }
  });
};

getConsensusState = () => {
  Meteor.call('chain.getConsensusState', (error, result) => {
    if (error) {
      console.log("get consensus: " + error);
    }
  });
};

getPurchaseOrders = () => {
  Meteor.call('enterprise.getPurchaseOrders', (error, result) => {
    if (error) {
      console.log("get po: " + error);
    }

    if (result) {
      console.log("get po: " + result);
    }
  });
};

getProposals = () => {
  Meteor.call('proposals.getProposals', (error, result) => {
    if (error) {
      console.log("get proposal: " + error);
    }

    if (result) {
      console.log("get proposal: " + result);
    }
  });
};

getProposalsResults = () => {
  Meteor.call('proposals.getProposalResults', (error, result) => {
    if (error) {
      console.log("get proposals result: " + error);
    }

    if (result) {
      console.log("get proposals result: " + result);
    }
  });
};

updateMissedBlocks = () => {
  Meteor.call('ValidatorRecords.calculateMissedBlocks', (error, result) => {
    if (error) {
      console.log("missed blocks error: " + error);
    }

    if (result) {
      console.log("missed blocks ok:" + result);
    }
  });
  /*
      Meteor.call('ValidatorRecords.calculateMissedBlocksStats', (error, result) =>{
          if (error){
              console.log("missed blocks stats error: "+ error)
          }
          if (result){
              console.log("missed blocks stats ok:" + result);
          }
      });
  */
};

getDelegations = () => {
  Meteor.call('delegations.getDelegations', (error, result) => {
    if (error) {
      console.log("get delegations error: " + error);
    } else {
      console.log("get delegations ok: " + result);
    }
  });
};

aggregateMinutely = () => {
  // doing something every min
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "m", (error, result) => {
    if (error) {
      console.log("aggregate minutely block time error: " + error);
    } else {
      console.log("aggregate minutely block time ok: " + result);
    }
  });
  Meteor.call('coinStats.getCoinStats', (error, result) => {
    if (error) {
      console.log("get coin stats error: " + error);
    } else {
      console.log("get coin stats ok: " + result);
    }
  });
};

aggregateHourly = () => {
  // doing something every hour
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "h", (error, result) => {
    if (error) {
      console.log("aggregate hourly block time error: " + error);
    } else {
      console.log("aggregate hourly block time ok: " + result);
    }
  });
};

aggregateDaily = () => {
  // doing somthing every day
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "d", (error, result) => {
    if (error) {
      console.log("aggregate daily block time error: " + error);
    } else {
      console.log("aggregate daily block time ok: " + result);
    }
  });
  Meteor.call('Analytics.aggregateValidatorDailyBlockTime', (error, result) => {
    if (error) {
      console.log("aggregate validators block time error:" + error);
    } else {
      console.log("aggregate validators block time ok:" + result);
    }
  });
};

Meteor.startup(function () {
  if (Meteor.isDevelopment) {
    let DEFAULTSETTINGSJSON;
    module.link("../default_settings.json", {
      default(v) {
        DEFAULTSETTINGSJSON = v;
      }

    }, 0);
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;
    Object.keys(DEFAULTSETTINGSJSON).forEach(key => {
      if (Meteor.settings[key] == undefined) {
        console.warn("CHECK SETTINGS JSON: ".concat(key, " is missing from settings"));
        Meteor.settings[key] = {};
      }

      Object.keys(DEFAULTSETTINGSJSON[key]).forEach(param => {
        if (Meteor.settings[key][param] == undefined) {
          console.warn("CHECK SETTINGS JSON: ".concat(key, ".").concat(param, " is missing from settings"));
          Meteor.settings[key][param] = DEFAULTSETTINGSJSON[key][param];
        }
      });
    });
  }

  Meteor.call('chain.genesis', (err, result) => {
    if (err) {
      console.log(err);
    }

    if (result) {
      if (Meteor.settings.debug.startTimer) {
        timerConsensus = Meteor.setInterval(function () {
          getConsensusState();
        }, Meteor.settings.params.consensusInterval);
        timerBlocks = Meteor.setInterval(function () {
          updateBlock();
        }, Meteor.settings.params.blockInterval);
        timerChain = Meteor.setInterval(function () {
          updateChainStatus();
        }, Meteor.settings.params.statusInterval);
        timerPurchaseOrder = Meteor.setInterval(function () {
          getPurchaseOrders();
        }, Meteor.settings.params.proposalInterval);
        timerProposal = Meteor.setInterval(function () {
          getProposals();
        }, Meteor.settings.params.proposalInterval);
        timerProposalsResults = Meteor.setInterval(function () {
          getProposalsResults();
        }, Meteor.settings.params.proposalInterval);
        timerMissedBlock = Meteor.setInterval(function () {
          updateMissedBlocks();
        }, Meteor.settings.params.missedBlocksInterval);
        timerDelegation = Meteor.setInterval(function () {
          getDelegations();
        }, Meteor.settings.params.delegationInterval);
        timerAggregate = Meteor.setInterval(function () {
          let now = new Date();

          if (now.getUTCSeconds() == 0) {
            aggregateMinutely();
          }

          if (now.getUTCMinutes() == 0 && now.getUTCSeconds() == 0) {
            aggregateHourly();
          }

          if (now.getUTCHours() == 0 && now.getUTCMinutes() == 0 && now.getUTCSeconds() == 0) {
            aggregateDaily();
          }
        }, 1000);
      }
    }
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"default_settings.json":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// default_settings.json                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "public": {
    "chainName": "Cosmos Testnet",
    "chainId": "{Chain ID}",
    "gtm": "{Add your Google Tag Manager ID here}",
    "slashingWindow": 10000,
    "uptimeWindow": 250,
    "initialPageSize": 30,
    "bech32PrefixAccAddr": "cosmos",
    "bech32PrefixAccPub": "cosmospub",
    "bech32PrefixValAddr": "cosmosvaloper",
    "bech32PrefixValPub": "cosmosvaloperpub",
    "bech32PrefixConsAddr": "cosmosvalcons",
    "bech32PrefixConsPub": "cosmosvalconspub",
    "stakingDenom": "ATOM",
    "stakingDenomPlural": null,
    "mintingDenom": "uatom",
    "stakingFraction": 1000000,
    "powerReduction": null,
    "gasPrice": 0.02,
    "coingeckoId": "cosmos"
  },
  "genesisFile": "{Replace the address of the genesis file of the chain}",
  "remote": {
    "rpc": "https://gaia-seeds.interblock.io",
    "lcd": "https://gaia-seeds.interblock.io:1317"
  },
  "debug": {
    "startTimer": true,
    "readGenesis": true
  },
  "params": {
    "startHeight": 0,
    "defaultBlockTime": 5000,
    "blockInterval": 15000,
    "consensusInterval": 1000,
    "statusInterval": 7500,
    "signingInfoInterval": 1800000,
    "proposalInterval": 5000,
    "missedBlocksInterval": 60000,
    "delegationInterval": 900000
  }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx",
    ".mjs",
    ".i18n.yml"
  ]
});

require("/both/i18n/en-us.i18n.yml.js");
require("/both/i18n/zh-hans.i18n.yml.js");
require("/both/i18n/zh-hant.i18n.yml.js");
require("/both/utils/coins.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWNjb3VudHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jsb2Nrcy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYmxvY2tzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jsb2Nrcy9ibG9ja3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2NoYWluL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jaGFpbi9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jaGFpbi9jaGFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29pbi1zdGF0cy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29pbi1zdGF0cy9jb2luLXN0YXRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9kZWxlZ2F0aW9ucy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZGVsZWdhdGlvbnMvZGVsZWdhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2VudGVycHJpc2Uvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2VudGVycHJpc2Uvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZW50ZXJwcmlzZS9lbnRlcnByaXNlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9sZWRnZXIvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3Byb3Bvc2Fscy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcHJvcG9zYWxzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3Byb3Bvc2Fscy9wcm9wb3NhbHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3JlY29yZHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3JlY29yZHMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcmVjb3Jkcy9yZWNvcmRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zdGF0dXMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc3RhdHVzL3N0YXR1cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdHJhbnNhY3Rpb25zL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90cmFuc2FjdGlvbnMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdHJhbnNhY3Rpb25zL3RyYW5zYWN0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdmFsaWRhdG9ycy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdmFsaWRhdG9ycy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3ZvdGluZy1wb3dlci9oaXN0b3J5LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9ldmlkZW5jZXMvZXZpZGVuY2VzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS92YWxpZGF0b3Itc2V0cy92YWxpZGF0b3Itc2V0cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL2JvdGgvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvY3JlYXRlLWluZGV4ZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvcmVnaXN0ZXItYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL3V0aWwuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdWkvY29tcG9uZW50cy9JY29ucy5qc3giLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvdXRpbHMvY29pbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIk1ldGVvciIsIm1vZHVsZSIsImxpbmsiLCJ2IiwiSFRUUCIsIlZhbGlkYXRvcnMiLCJmZXRjaEZyb21VcmwiLCJ1cmwiLCJyZXMiLCJnZXQiLCJMQ0QiLCJzdGF0dXNDb2RlIiwiZSIsImNvbnNvbGUiLCJsb2ciLCJtZXRob2RzIiwiYWRkcmVzcyIsInVuYmxvY2siLCJhdmFpbGFibGUiLCJyZXNwb25zZSIsIkpTT04iLCJwYXJzZSIsImNvbnRlbnQiLCJyZXN1bHQiLCJhY2NvdW50IiwidHlwZSIsInZhbHVlIiwiQmFzZVZlc3RpbmdBY2NvdW50IiwiQmFzZUFjY291bnQiLCJhY2NvdW50X251bWJlciIsImJhbGFuY2UiLCJsZW5ndGgiLCJkZWxlZ2F0aW9ucyIsInVuYm9uZGluZyIsInJld2FyZHMiLCJ0b3RhbCIsInZhbGlkYXRvciIsImZpbmRPbmUiLCIkb3IiLCJvcGVyYXRvcl9hZGRyZXNzIiwiZGVsZWdhdG9yX2FkZHJlc3MiLCJ2YWxfY29tbWlzc2lvbiIsImNvbW1pc3Npb24iLCJkYXRhIiwic2hhcmVzIiwicGFyc2VGbG9hdCIsInJlbGVnYXRpb25zIiwiY29tcGxldGlvblRpbWUiLCJmb3JFYWNoIiwicmVsZWdhdGlvbiIsImVudHJpZXMiLCJ0aW1lIiwiRGF0ZSIsImNvbXBsZXRpb25fdGltZSIsInJlZGVsZWdhdGlvbkNvbXBsZXRpb25UaW1lIiwidW5kZWxlZ2F0aW9ucyIsInVuYm9uZGluZ0NvbXBsZXRpb25UaW1lIiwiZGVsZWdhdGlvbiIsImkiLCJ1bmJvbmRpbmdzIiwicmVkZWxlZ2F0aW9ucyIsInJlZGVsZWdhdGlvbiIsInZhbGlkYXRvcl9kc3RfYWRkcmVzcyIsImNvdW50IiwiUHJvbWlzZSIsIkJsb2Nrc2NvbiIsIkNoYWluIiwiVmFsaWRhdG9yU2V0cyIsIlZhbGlkYXRvclJlY29yZHMiLCJBbmFseXRpY3MiLCJWUERpc3RyaWJ1dGlvbnMiLCJWb3RpbmdQb3dlckhpc3RvcnkiLCJUcmFuc2FjdGlvbnMiLCJFdmlkZW5jZXMiLCJzaGEyNTYiLCJnZXRBZGRyZXNzIiwiY2hlZXJpbyIsImdldFJlbW92ZWRWYWxpZGF0b3JzIiwicHJldlZhbGlkYXRvcnMiLCJ2YWxpZGF0b3JzIiwicCIsInNwbGljZSIsImdldFZhbGlkYXRvclByb2ZpbGVVcmwiLCJpZGVudGl0eSIsInRoZW0iLCJwaWN0dXJlcyIsInByaW1hcnkiLCJzdHJpbmdpZnkiLCJpbmRleE9mIiwidGVhbVBhZ2UiLCJwYWdlIiwibG9hZCIsImF0dHIiLCJibG9ja3MiLCJmaW5kIiwicHJvcG9zZXJBZGRyZXNzIiwiZmV0Y2giLCJoZWlnaHRzIiwibWFwIiwiYmxvY2siLCJoZWlnaHQiLCJibG9ja3NTdGF0cyIsIiRpbiIsInRvdGFsQmxvY2tEaWZmIiwiYiIsInRpbWVEaWZmIiwiY29sbGVjdGlvbiIsInJhd0NvbGxlY3Rpb24iLCJwaXBlbGluZSIsIiRtYXRjaCIsIiRzb3J0IiwiJGxpbWl0Iiwic2V0dGluZ3MiLCJwdWJsaWMiLCJ1cHRpbWVXaW5kb3ciLCIkdW53aW5kIiwiJGdyb3VwIiwiJGNvbmQiLCIkZXEiLCJhd2FpdCIsImFnZ3JlZ2F0ZSIsInRvQXJyYXkiLCJSUEMiLCJzdGF0dXMiLCJzeW5jX2luZm8iLCJsYXRlc3RfYmxvY2tfaGVpZ2h0IiwiY3VyckhlaWdodCIsInNvcnQiLCJsaW1pdCIsInN0YXJ0SGVpZ2h0IiwicGFyYW1zIiwiU1lOQ0lORyIsInVudGlsIiwiY2FsbCIsImN1cnIiLCJ2YWxpZGF0b3JTZXQiLCJjb25zZW5zdXNfcHVia2V5IiwidG90YWxWYWxpZGF0b3JzIiwiT2JqZWN0Iiwia2V5cyIsInN0YXJ0QmxvY2tUaW1lIiwiYW5hbHl0aWNzRGF0YSIsImJ1bGtWYWxpZGF0b3JzIiwiaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCIsImJ1bGtWYWxpZGF0b3JSZWNvcmRzIiwiYnVsa1ZQSGlzdG9yeSIsImJ1bGtUcmFuc2F0aW9ucyIsInN0YXJ0R2V0SGVpZ2h0VGltZSIsImJsb2NrRGF0YSIsImhhc2giLCJibG9ja19pZCIsInRyYW5zTnVtIiwidHhzIiwiaGVhZGVyIiwibGFzdEJsb2NrSGFzaCIsImxhc3RfYmxvY2tfaWQiLCJwcm9wb3Nlcl9hZGRyZXNzIiwicHJlY29tbWl0cyIsImxhc3RfY29tbWl0Iiwic2lnbmF0dXJlcyIsInB1c2giLCJ2YWxpZGF0b3JfYWRkcmVzcyIsInQiLCJCdWZmZXIiLCJmcm9tIiwiZXJyIiwiZXZpZGVuY2UiLCJpbnNlcnQiLCJwcmVjb21taXRzQ291bnQiLCJlbmRHZXRIZWlnaHRUaW1lIiwic3RhcnRHZXRWYWxpZGF0b3JzVGltZSIsImJsb2NrX2hlaWdodCIsInBhcnNlSW50IiwidmFsaWRhdG9yc0NvdW50Iiwic3RhcnRCbG9ja0luc2VydFRpbWUiLCJlbmRCbG9ja0luc2VydFRpbWUiLCJleGlzdGluZ1ZhbGlkYXRvcnMiLCIkZXhpc3RzIiwicmVjb3JkIiwiZXhpc3RzIiwidm90aW5nX3Bvd2VyIiwiaiIsIm51bUJsb2NrcyIsInVwdGltZSIsImJhc2UiLCJ1cHNlcnQiLCJ1cGRhdGVPbmUiLCIkc2V0IiwibGFzdFNlZW4iLCJjaGFpblN0YXR1cyIsImNoYWluSWQiLCJjaGFpbl9pZCIsImxhc3RTeW5jZWRUaW1lIiwiYmxvY2tUaW1lIiwiZGVmYXVsdEJsb2NrVGltZSIsImRhdGVMYXRlc3QiLCJkYXRlTGFzdCIsIk1hdGgiLCJhYnMiLCJnZXRUaW1lIiwiZW5kR2V0VmFsaWRhdG9yc1RpbWUiLCJ1cGRhdGUiLCJhdmVyYWdlQmxvY2tUaW1lIiwic3RhcnRGaW5kVmFsaWRhdG9yc05hbWVUaW1lIiwicHJvcG9zZXJfcHJpb3JpdHkiLCJ2YWxFeGlzdCIsInB1Yl9rZXkiLCJhY2NwdWIiLCJiZWNoMzJQcmVmaXhBY2NQdWIiLCJvcGVyYXRvcl9wdWJrZXkiLCJiZWNoMzJQcmVmaXhWYWxQdWIiLCJiZWNoMzJQcmVmaXhDb25zUHViIiwidmFsaWRhdG9yRGF0YSIsImRlc2NyaXB0aW9uIiwicHJvZmlsZV91cmwiLCJqYWlsZWQiLCJtaW5fc2VsZl9kZWxlZ2F0aW9uIiwidG9rZW5zIiwiZGVsZWdhdG9yX3NoYXJlcyIsImJvbmRfaGVpZ2h0IiwiYm9uZF9pbnRyYV90eF9jb3VudGVyIiwidW5ib25kaW5nX2hlaWdodCIsInVuYm9uZGluZ190aW1lIiwic2VsZl9kZWxlZ2F0aW9uIiwicHJldl92b3RpbmdfcG93ZXIiLCJibG9ja190aW1lIiwic2VsZkRlbGVnYXRpb24iLCJwcmV2Vm90aW5nUG93ZXIiLCJjaGFuZ2VUeXBlIiwiY2hhbmdlRGF0YSIsInJlbW92ZWRWYWxpZGF0b3JzIiwiciIsImRiVmFsaWRhdG9ycyIsImZpZWxkcyIsImNvblB1YktleSIsInVuZGVmaW5lZCIsInByb2ZpbGVVcmwiLCJlbmRGaW5kVmFsaWRhdG9yc05hbWVUaW1lIiwic3RhcnRBbmF5dGljc0luc2VydFRpbWUiLCJlbmRBbmFseXRpY3NJbnNlcnRUaW1lIiwic3RhcnRWVXBUaW1lIiwiZXhlY3V0ZSIsImVuZFZVcFRpbWUiLCJzdGFydFZSVGltZSIsImVuZFZSVGltZSIsImFjdGl2ZVZhbGlkYXRvcnMiLCJudW1Ub3BUd2VudHkiLCJjZWlsIiwibnVtQm90dG9tRWlnaHR5IiwidG9wVHdlbnR5UG93ZXIiLCJib3R0b21FaWdodHlQb3dlciIsIm51bVRvcFRoaXJ0eUZvdXIiLCJudW1Cb3R0b21TaXh0eVNpeCIsInRvcFRoaXJ0eUZvdXJQZXJjZW50IiwiYm90dG9tU2l4dHlTaXhQZXJjZW50IiwidnBEaXN0IiwibnVtVmFsaWRhdG9ycyIsInRvdGFsVm90aW5nUG93ZXIiLCJjcmVhdGVBdCIsImVuZEJsb2NrVGltZSIsImxhc3RCbG9ja3NTeW5jZWRUaW1lIiwicHVibGlzaENvbXBvc2l0ZSIsImNoaWxkcmVuIiwiZXhwb3J0IiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwiaGVscGVycyIsInByb3Bvc2VyIiwiQ2hhaW5TdGF0ZXMiLCJmaW5kVm90aW5nUG93ZXIiLCJnZW5WYWxpZGF0b3JzIiwicG93ZXIiLCJjb25zZW5zdXMiLCJyb3VuZF9zdGF0ZSIsInJvdW5kIiwic3RlcCIsInZvdGVkUG93ZXIiLCJ2b3RlcyIsInByZXZvdGVzX2JpdF9hcnJheSIsInNwbGl0Iiwidm90aW5nSGVpZ2h0Iiwidm90aW5nUm91bmQiLCJ2b3RpbmdTdGVwIiwicHJldm90ZXMiLCJjaGFpbiIsIm5vZGVfaW5mbyIsIm5ldHdvcmsiLCJsYXRlc3RCbG9ja0hlaWdodCIsImxhdGVzdEJsb2NrVGltZSIsImxhdGVzdF9ibG9ja190aW1lIiwibGF0ZXN0U3RhdGUiLCJhY3RpdmVWUCIsImFjdGl2ZVZvdGluZ1Bvd2VyIiwiY2hhaW5TdGF0ZXMiLCJib25kaW5nIiwiYm9uZGVkVG9rZW5zIiwiYm9uZGVkX3Rva2VucyIsIm5vdEJvbmRlZFRva2VucyIsIm5vdF9ib25kZWRfdG9rZW5zIiwibWludGluZ0Rlbm9tIiwic3VwcGx5IiwidG90YWxTdXBwbHkiLCJwb29sIiwiY29tbXVuaXR5UG9vbCIsImFtb3VudCIsImRlbm9tIiwiaW5mbGF0aW9uIiwicHJvdmlzaW9ucyIsImFubnVhbFByb3Zpc2lvbnMiLCJjcmVhdGVkIiwicmVhZEdlbmVzaXMiLCJkZWJ1ZyIsImdlbmVzaXNGaWxlIiwiZ2VuZXNpcyIsImRpc3RyIiwiYXBwX3N0YXRlIiwiZGlzdHJpYnV0aW9uIiwiY2hhaW5QYXJhbXMiLCJnZW5lc2lzVGltZSIsImdlbmVzaXNfdGltZSIsImNvbnNlbnN1c1BhcmFtcyIsImNvbnNlbnN1c19wYXJhbXMiLCJhdXRoIiwiYmFuayIsInN0YWtpbmciLCJtaW50IiwiY29tbXVuaXR5VGF4IiwiY29tbXVuaXR5X3RheCIsImJhc2VQcm9wb3NlclJld2FyZCIsImJhc2VfcHJvcG9zZXJfcmV3YXJkIiwiYm9udXNQcm9wb3NlclJld2FyZCIsImJvbnVzX3Byb3Bvc2VyX3Jld2FyZCIsIndpdGhkcmF3QWRkckVuYWJsZWQiLCJ3aXRoZHJhd19hZGRyX2VuYWJsZWQiLCJnb3YiLCJzdGFydGluZ1Byb3Bvc2FsSWQiLCJkZXBvc2l0UGFyYW1zIiwidm90aW5nUGFyYW1zIiwidGFsbHlQYXJhbXMiLCJzbGFzaGluZyIsImNyaXNpcyIsInN0YXJ0aW5nX3Byb3Bvc2FsX2lkIiwiZGVwb3NpdF9wYXJhbXMiLCJ2b3RpbmdfcGFyYW1zIiwidGFsbHlfcGFyYW1zIiwiZ2VudXRpbCIsImdlbnR4cyIsIm1zZyIsIm0iLCJwdWJrZXkiLCJmbG9vciIsInN0YWtpbmdGcmFjdGlvbiIsInB1YmtleVZhbHVlIiwiZ2VuVmFsaWRhdG9yc1NldCIsIkNvaW5TdGF0cyIsInB1Ymxpc2giLCJsYXN0X3VwZGF0ZWRfYXQiLCJjb2luSWQiLCJjb2luZ2Vja29JZCIsIm5vdyIsInNldE1pbnV0ZXMiLCJEZWxlZ2F0aW9ucyIsImNvbmNhdCIsImNyZWF0ZWRBdCIsIkVudGVycHJpc2UiLCJwdXJjaGFzZU9yZGVycyIsImZpbmlzaGVkUHVyY2hhc2VPcmRlcnMiLCJTZXQiLCJwb0lkIiwicG9JZHMiLCJidWxrUG9zIiwicG8iLCJpZCIsImhhcyIsImNoZWNrIiwiTnVtYmVyIiwiX29iamVjdFNwcmVhZCIsImRlZmF1bHQiLCJ0eEluZm8iLCJ0aW1lc3RhbXAiLCJwb3N0IiwiY29kZSIsIkVycm9yIiwicmF3X2xvZyIsIm1lc3NhZ2UiLCJ0eGhhc2giLCJib2R5IiwicGF0aCIsInR4TXNnIiwiYWRqdXN0bWVudCIsImdhc19lc3RpbWF0ZSIsIlByb3Bvc2FscyIsInByb3Bvc2FscyIsImZpbmlzaGVkUHJvcG9zYWxJZHMiLCJwcm9wb3NhbElkIiwicHJvcG9zYWxJZHMiLCJidWxrUHJvcG9zYWxzIiwicHJvcG9zYWwiLCJwcm9wb3NhbF9pZCIsIiRuaW4iLCJwcm9wb3NhbF9zdGF0dXMiLCJkZXBvc2l0cyIsImdldFZvdGVEZXRhaWwiLCJ0YWxseSIsInVwZGF0ZWRBdCIsInZvdGVycyIsInZvdGUiLCJ2b3RlciIsInZvdGluZ1Bvd2VyTWFwIiwidmFsaWRhdG9yQWRkcmVzc01hcCIsIm1vbmlrZXIiLCJkZWxlZ2F0b3JTaGFyZXMiLCJkZWR1Y3RlZFNoYXJlcyIsInZvdGluZ1Bvd2VyIiwiQXZlcmFnZURhdGEiLCJBdmVyYWdlVmFsaWRhdG9yRGF0YSIsIlN0YXR1cyIsIk1pc3NlZEJsb2Nrc1N0YXRzIiwiTWlzc2VkQmxvY2tzIiwiXyIsIkJVTEtVUERBVEVNQVhTSVpFIiwiZ2V0QmxvY2tTdGF0cyIsImxhdGVzdEhlaWdodCIsImJsb2NrU3RhdHMiLCJjb25kIiwiJGFuZCIsIiRndCIsIiRsdGUiLCJvcHRpb25zIiwiYXNzaWduIiwiZ2V0UHJldmlvdXNSZWNvcmQiLCJ2b3RlckFkZHJlc3MiLCJwcmV2aW91c1JlY29yZCIsImJsb2NrSGVpZ2h0IiwibGFzdFVwZGF0ZWRIZWlnaHQiLCJwcmV2U3RhdHMiLCJwaWNrIiwibWlzc0NvdW50IiwidG90YWxDb3VudCIsIkNPVU5UTUlTU0VEQkxPQ0tTIiwic3RhcnRUaW1lIiwiZXhwbG9yZXJTdGF0dXMiLCJsYXN0UHJvY2Vzc2VkTWlzc2VkQmxvY2tIZWlnaHQiLCJtaW4iLCJidWxrTWlzc2VkU3RhdHMiLCJpbml0aWFsaXplT3JkZXJlZEJ1bGtPcCIsInZhbGlkYXRvcnNNYXAiLCJwcm9wb3NlclZvdGVyU3RhdHMiLCJ2b3RlZFZhbGlkYXRvcnMiLCJ2YWxpZGF0b3JTZXRzIiwidm90ZWRWb3RpbmdQb3dlciIsImFjdGl2ZVZhbGlkYXRvciIsImN1cnJlbnRWYWxpZGF0b3IiLCJzZXQiLCJuIiwic3RhdHMiLCJjbGllbnQiLCJfZHJpdmVyIiwibW9uZ28iLCJidWxrUHJvbWlzZSIsInRoZW4iLCJiaW5kRW52aXJvbm1lbnQiLCJuSW5zZXJ0ZWQiLCJuVXBzZXJ0ZWQiLCJuTW9kaWZpZWQiLCJsYXN0UHJvY2Vzc2VkTWlzc2VkQmxvY2tUaW1lIiwiQ09VTlRNSVNTRURCTE9DS1NTVEFUUyIsImxhc3RNaXNzZWRCbG9ja0hlaWdodCIsIm1pc3NlZFJlY29yZHMiLCJjb3VudHMiLCJleGlzdGluZ1JlY29yZCIsImxhc3RNaXNzZWRCbG9ja1RpbWUiLCJhdmVyYWdlVm90aW5nUG93ZXIiLCJhbmFseXRpY3MiLCJsYXN0TWludXRlVm90aW5nUG93ZXIiLCJsYXN0TWludXRlQmxvY2tUaW1lIiwibGFzdEhvdXJWb3RpbmdQb3dlciIsImxhc3RIb3VyQmxvY2tUaW1lIiwibGFzdERheVZvdGluZ1Bvd2VyIiwibGFzdERheUJsb2NrVGltZSIsImJsb2NrSGVpZ2h0cyIsImEiLCJudW0iLCJjb25kaXRpb25zIiwicHJvcG9zZXJNb25pa2VyIiwidm90ZXJNb25pa2VyIiwiQWRkcmVzc0xlbmd0aCIsInRvVXBwZXJDYXNlIiwidHgiLCJ0eElkIiwiJGx0IiwiaW5jbHVkZXMiLCJiZWNoMzJQcmVmaXhWYWxBZGRyIiwiYmVjaDMyUHJlZml4QWNjQWRkciIsInZhbGlkYXRvckFkZHJlc3MiLCJkZWxlZ2F0b3JBZGRyZXNzIiwicXVlcnkiLCJUeEljb24iLCJkaXJlY3Rpb24iLCJ2YWwiLCJmaXJzdFNlZW4iLCJoaXN0b3J5IiwiY3JlYXRlSW5kZXgiLCJ1bmlxdWUiLCJwYXJ0aWFsRmlsdGVyRXhwcmVzc2lvbiIsIm9uUGFnZUxvYWQiLCJIZWxtZXQiLCJzaW5rIiwiaGVsbWV0IiwicmVuZGVyU3RhdGljIiwiYXBwZW5kVG9IZWFkIiwibWV0YSIsInRvU3RyaW5nIiwidGl0bGUiLCJiZWNoMzIiLCJGdXR1cmUiLCJOcG0iLCJyZXF1aXJlIiwiZXhlYyIsInRvSGV4U3RyaW5nIiwiYnl0ZUFycmF5IiwiYnl0ZSIsInNsaWNlIiwiam9pbiIsInB1YmtleVRvQmVjaDMyIiwicHJlZml4IiwicHVia2V5QW1pbm9QcmVmaXgiLCJidWZmZXIiLCJhbGxvYyIsImNvcHkiLCJlbmNvZGUiLCJ0b1dvcmRzIiwiYmVjaDMyVG9QdWJrZXkiLCJmcm9tV29yZHMiLCJkZWNvZGUiLCJ3b3JkcyIsImdldERlbGVnYXRvciIsIm9wZXJhdG9yQWRkciIsImdldEtleWJhc2VUZWFtUGljIiwia2V5YmFzZVVybCIsIkRlbm9tU3ltYm9sIiwiUHJvcG9zYWxTdGF0dXNJY29uIiwiVm90ZUljb24iLCJJbmZvSWNvbiIsIlJlYWN0IiwiVW5jb250cm9sbGVkVG9vbHRpcCIsInByb3BzIiwidmFsaWQiLCJDb21wb25lbnQiLCJjb25zdHJ1Y3RvciIsInJlZiIsImNyZWF0ZVJlZiIsInJlbmRlciIsInRvb2x0aXBUZXh0IiwiQ29pbiIsIm51bWJybyIsImF1dG9mb3JtYXQiLCJmb3JtYXR0ZXIiLCJmb3JtYXQiLCJ0b0xvd2VyQ2FzZSIsIk1pbnRpbmdEZW5vbSIsIl9hbW91bnQiLCJTdGFraW5nRGVub20iLCJTdGFraW5nRnJhY3Rpb24iLCJzdGFraW5nQW1vdW50IiwicHJlY2lzaW9uIiwibWluU3Rha2UiLCJwb3ciLCJyZXBlYXQiLCJtaW50U3RyaW5nIiwic3Rha2VTdHJpbmciLCJzdGFraW5nRGVub20iLCJTdGFraW5nRGVub21QbHVyYWwiLCJzdGFraW5nRGVub21QbHVyYWwiLCJNaW5TdGFrZSIsInJlbW90ZSIsInJwYyIsImxjZCIsInRpbWVyQmxvY2tzIiwidGltZXJDaGFpbiIsInRpbWVyQ29uc2Vuc3VzIiwidGltZXJQcm9wb3NhbCIsInRpbWVyUHJvcG9zYWxzUmVzdWx0cyIsInRpbWVyTWlzc2VkQmxvY2siLCJ0aW1lckRlbGVnYXRpb24iLCJ0aW1lckFnZ3JlZ2F0ZSIsIkRFRkFVTFRTRVRUSU5HUyIsInVwZGF0ZUNoYWluU3RhdHVzIiwiZXJyb3IiLCJ1cGRhdGVCbG9jayIsImdldENvbnNlbnN1c1N0YXRlIiwiZ2V0UHVyY2hhc2VPcmRlcnMiLCJnZXRQcm9wb3NhbHMiLCJnZXRQcm9wb3NhbHNSZXN1bHRzIiwidXBkYXRlTWlzc2VkQmxvY2tzIiwiZ2V0RGVsZWdhdGlvbnMiLCJhZ2dyZWdhdGVNaW51dGVseSIsImFnZ3JlZ2F0ZUhvdXJseSIsImFnZ3JlZ2F0ZURhaWx5Iiwic3RhcnR1cCIsImlzRGV2ZWxvcG1lbnQiLCJERUZBVUxUU0VUVElOR1NKU09OIiwicHJvY2VzcyIsImVudiIsIk5PREVfVExTX1JFSkVDVF9VTkFVVEhPUklaRUQiLCJrZXkiLCJ3YXJuIiwicGFyYW0iLCJzdGFydFRpbWVyIiwic2V0SW50ZXJ2YWwiLCJjb25zZW5zdXNJbnRlcnZhbCIsImJsb2NrSW50ZXJ2YWwiLCJzdGF0dXNJbnRlcnZhbCIsInRpbWVyUHVyY2hhc2VPcmRlciIsInByb3Bvc2FsSW50ZXJ2YWwiLCJtaXNzZWRCbG9ja3NJbnRlcnZhbCIsImRlbGVnYXRpb25JbnRlcnZhbCIsImdldFVUQ1NlY29uZHMiLCJnZXRVVENNaW51dGVzIiwiZ2V0VVRDSG91cnMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksdUNBQVosRUFBb0Q7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQXBELEVBQWtGLENBQWxGOztBQUd2SSxNQUFNRyxZQUFZLEdBQUlDLEdBQUQsSUFBUztBQUMxQixNQUFHO0FBQ0MsUUFBSUMsR0FBRyxHQUFHSixJQUFJLENBQUNLLEdBQUwsQ0FBU0MsR0FBRyxHQUFHSCxHQUFmLENBQVY7O0FBQ0EsUUFBSUMsR0FBRyxDQUFDRyxVQUFKLElBQWtCLEdBQXRCLEVBQTBCO0FBQ3RCLGFBQU9ILEdBQVA7QUFDSDs7QUFBQTtBQUNKLEdBTEQsQ0FNQSxPQUFPSSxDQUFQLEVBQVM7QUFDTEMsV0FBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLENBVkQ7O0FBWUFaLE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsK0JBQTZCLFVBQVNDLE9BQVQsRUFBaUI7QUFDMUMsU0FBS0MsT0FBTDtBQUNBLFFBQUlWLEdBQUcsR0FBR0csR0FBRyxHQUFHLGlCQUFOLEdBQXlCTSxPQUFuQzs7QUFDQSxRQUFHO0FBQ0MsVUFBSUUsU0FBUyxHQUFHZCxJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFoQjs7QUFDQSxVQUFJVyxTQUFTLENBQUNQLFVBQVYsSUFBd0IsR0FBNUIsRUFBZ0M7QUFDNUIsWUFBSVEsUUFBUSxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0gsU0FBUyxDQUFDSSxPQUFyQixFQUE4QkMsTUFBN0M7QUFDQSxZQUFJQyxPQUFKO0FBQ0EsWUFBSUwsUUFBUSxDQUFDTSxJQUFULEtBQWtCLG9CQUF0QixFQUNJRCxPQUFPLEdBQUdMLFFBQVEsQ0FBQ08sS0FBbkIsQ0FESixLQUVLLElBQUlQLFFBQVEsQ0FBQ00sSUFBVCxLQUFrQixrQ0FBbEIsSUFBd0ROLFFBQVEsQ0FBQ00sSUFBVCxLQUFrQixxQ0FBOUUsRUFDREQsT0FBTyxHQUFHTCxRQUFRLENBQUNPLEtBQVQsQ0FBZUMsa0JBQWYsQ0FBa0NDLFdBQTVDO0FBQ0osWUFBSUosT0FBTyxJQUFJQSxPQUFPLENBQUNLLGNBQVIsSUFBMEIsSUFBekMsRUFDSSxPQUFPTCxPQUFQO0FBQ0osZUFBTyxJQUFQO0FBQ0g7QUFDSixLQWJELENBY0EsT0FBT1osQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixHQXJCVTtBQXNCWCx5QkFBdUIsVUFBU0ksT0FBVCxFQUFpQjtBQUNwQyxTQUFLQyxPQUFMO0FBQ0EsUUFBSWEsT0FBTyxHQUFHLEVBQWQsQ0FGb0MsQ0FJcEM7O0FBQ0EsUUFBSXZCLEdBQUcsR0FBR0csR0FBRyxHQUFHLGlCQUFOLEdBQXlCTSxPQUFuQzs7QUFDQSxRQUFHO0FBQ0MsVUFBSUUsU0FBUyxHQUFHZCxJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFoQjs7QUFDQSxVQUFJVyxTQUFTLENBQUNQLFVBQVYsSUFBd0IsR0FBNUIsRUFBZ0M7QUFDNUI7QUFDQW1CLGVBQU8sQ0FBQ1osU0FBUixHQUFvQkUsSUFBSSxDQUFDQyxLQUFMLENBQVdILFNBQVMsQ0FBQ0ksT0FBckIsRUFBOEJDLE1BQWxEO0FBQ0EsWUFBSU8sT0FBTyxDQUFDWixTQUFSLElBQXFCWSxPQUFPLENBQUNaLFNBQVIsQ0FBa0JhLE1BQWxCLEdBQTJCLENBQXBELEVBQ0lELE9BQU8sQ0FBQ1osU0FBUixHQUFvQlksT0FBTyxDQUFDWixTQUFSLENBQWtCLENBQWxCLENBQXBCO0FBQ1A7QUFDSixLQVJELENBU0EsT0FBT04sQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0gsS0FqQm1DLENBbUJwQzs7O0FBQ0FMLE9BQUcsR0FBR0csR0FBRyxHQUFHLHNCQUFOLEdBQTZCTSxPQUE3QixHQUFxQyxjQUEzQzs7QUFDQSxRQUFHO0FBQ0MsVUFBSWdCLFdBQVcsR0FBRzVCLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWxCOztBQUNBLFVBQUl5QixXQUFXLENBQUNyQixVQUFaLElBQTBCLEdBQTlCLEVBQWtDO0FBQzlCbUIsZUFBTyxDQUFDRSxXQUFSLEdBQXNCWixJQUFJLENBQUNDLEtBQUwsQ0FBV1csV0FBVyxDQUFDVixPQUF2QixFQUFnQ0MsTUFBdEQ7QUFDSDtBQUNKLEtBTEQsQ0FNQSxPQUFPWCxDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxLQTdCbUMsQ0E4QnBDOzs7QUFDQUwsT0FBRyxHQUFHRyxHQUFHLEdBQUcsc0JBQU4sR0FBNkJNLE9BQTdCLEdBQXFDLHdCQUEzQzs7QUFDQSxRQUFHO0FBQ0MsVUFBSWlCLFNBQVMsR0FBRzdCLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWhCOztBQUNBLFVBQUkwQixTQUFTLENBQUN0QixVQUFWLElBQXdCLEdBQTVCLEVBQWdDO0FBQzVCbUIsZUFBTyxDQUFDRyxTQUFSLEdBQW9CYixJQUFJLENBQUNDLEtBQUwsQ0FBV1ksU0FBUyxDQUFDWCxPQUFyQixFQUE4QkMsTUFBbEQ7QUFDSDtBQUNKLEtBTEQsQ0FNQSxPQUFPWCxDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxLQXhDbUMsQ0EwQ3BDOzs7QUFDQUwsT0FBRyxHQUFHRyxHQUFHLEdBQUcsMkJBQU4sR0FBa0NNLE9BQWxDLEdBQTBDLFVBQWhEOztBQUNBLFFBQUc7QUFDQyxVQUFJa0IsT0FBTyxHQUFHOUIsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZDs7QUFDQSxVQUFJMkIsT0FBTyxDQUFDdkIsVUFBUixJQUFzQixHQUExQixFQUE4QjtBQUMxQm1CLGVBQU8sQ0FBQ0ksT0FBUixHQUFrQmQsSUFBSSxDQUFDQyxLQUFMLENBQVdhLE9BQU8sQ0FBQ1osT0FBbkIsRUFBNEJDLE1BQTVCLENBQW1DWSxLQUFyRDtBQUNIO0FBQ0osS0FMRCxDQU1BLE9BQU92QixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxLQXBEbUMsQ0FzRHBDOzs7QUFDQSxRQUFJd0IsU0FBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUNaO0FBQUNDLFNBQUcsRUFBRSxDQUFDO0FBQUNDLHdCQUFnQixFQUFDdkI7QUFBbEIsT0FBRCxFQUE2QjtBQUFDd0IseUJBQWlCLEVBQUN4QjtBQUFuQixPQUE3QixFQUEwRDtBQUFDQSxlQUFPLEVBQUNBO0FBQVQsT0FBMUQ7QUFBTixLQURZLENBQWhCOztBQUVBLFFBQUlvQixTQUFKLEVBQWU7QUFDWCxVQUFJN0IsR0FBRyxHQUFHRyxHQUFHLEdBQUcsMkJBQU4sR0FBb0MwQixTQUFTLENBQUNHLGdCQUF4RDtBQUNBVCxhQUFPLENBQUNTLGdCQUFSLEdBQTJCSCxTQUFTLENBQUNHLGdCQUFyQzs7QUFDQSxVQUFJO0FBQ0EsWUFBSUwsT0FBTyxHQUFHOUIsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZDs7QUFDQSxZQUFJMkIsT0FBTyxDQUFDdkIsVUFBUixJQUFzQixHQUExQixFQUE4QjtBQUMxQixjQUFJVyxPQUFPLEdBQUdGLElBQUksQ0FBQ0MsS0FBTCxDQUFXYSxPQUFPLENBQUNaLE9BQW5CLEVBQTRCQyxNQUExQztBQUNBLGNBQUlELE9BQU8sQ0FBQ21CLGNBQVIsSUFBMEJuQixPQUFPLENBQUNtQixjQUFSLENBQXVCVixNQUF2QixHQUFnQyxDQUE5RCxFQUNJRCxPQUFPLENBQUNZLFVBQVIsR0FBcUJwQixPQUFPLENBQUNtQixjQUFSLENBQXVCLENBQXZCLENBQXJCO0FBQ1A7QUFFSixPQVJELENBU0EsT0FBTzdCLENBQVAsRUFBUztBQUNMQyxlQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0o7O0FBRUQsV0FBT2tCLE9BQVA7QUFDSCxHQWpHVTs7QUFrR1gsMkJBQXlCZCxPQUF6QixFQUFrQ29CLFNBQWxDLEVBQTRDO0FBQ3hDLFFBQUk3QixHQUFHLGlDQUEwQlMsT0FBMUIsMEJBQWlEb0IsU0FBakQsQ0FBUDtBQUNBLFFBQUlKLFdBQVcsR0FBRzFCLFlBQVksQ0FBQ0MsR0FBRCxDQUE5QjtBQUNBeUIsZUFBVyxHQUFHQSxXQUFXLElBQUlBLFdBQVcsQ0FBQ1csSUFBWixDQUFpQnBCLE1BQTlDO0FBQ0EsUUFBSVMsV0FBVyxJQUFJQSxXQUFXLENBQUNZLE1BQS9CLEVBQ0laLFdBQVcsQ0FBQ1ksTUFBWixHQUFxQkMsVUFBVSxDQUFDYixXQUFXLENBQUNZLE1BQWIsQ0FBL0I7QUFFSnJDLE9BQUcsOENBQXVDUyxPQUF2QywyQkFBK0RvQixTQUEvRCxDQUFIO0FBQ0EsUUFBSVUsV0FBVyxHQUFHeEMsWUFBWSxDQUFDQyxHQUFELENBQTlCO0FBQ0F1QyxlQUFXLEdBQUdBLFdBQVcsSUFBSUEsV0FBVyxDQUFDSCxJQUFaLENBQWlCcEIsTUFBOUM7QUFDQSxRQUFJd0IsY0FBSjs7QUFDQSxRQUFJRCxXQUFKLEVBQWlCO0FBQ2JBLGlCQUFXLENBQUNFLE9BQVosQ0FBcUJDLFVBQUQsSUFBZ0I7QUFDaEMsWUFBSUMsT0FBTyxHQUFHRCxVQUFVLENBQUNDLE9BQXpCO0FBQ0EsWUFBSUMsSUFBSSxHQUFHLElBQUlDLElBQUosQ0FBU0YsT0FBTyxDQUFDQSxPQUFPLENBQUNuQixNQUFSLEdBQWUsQ0FBaEIsQ0FBUCxDQUEwQnNCLGVBQW5DLENBQVg7QUFDQSxZQUFJLENBQUNOLGNBQUQsSUFBbUJJLElBQUksR0FBR0osY0FBOUIsRUFDSUEsY0FBYyxHQUFHSSxJQUFqQjtBQUNQLE9BTEQ7QUFNQW5CLGlCQUFXLENBQUNzQiwwQkFBWixHQUF5Q1AsY0FBekM7QUFDSDs7QUFFRHhDLE9BQUcsaUNBQTBCUyxPQUExQixvQ0FBMkRvQixTQUEzRCxDQUFIO0FBQ0EsUUFBSW1CLGFBQWEsR0FBR2pELFlBQVksQ0FBQ0MsR0FBRCxDQUFoQztBQUNBZ0QsaUJBQWEsR0FBR0EsYUFBYSxJQUFJQSxhQUFhLENBQUNaLElBQWQsQ0FBbUJwQixNQUFwRDs7QUFDQSxRQUFJZ0MsYUFBSixFQUFtQjtBQUNmdkIsaUJBQVcsQ0FBQ0MsU0FBWixHQUF3QnNCLGFBQWEsQ0FBQ0wsT0FBZCxDQUFzQm5CLE1BQTlDO0FBQ0FDLGlCQUFXLENBQUN3Qix1QkFBWixHQUFzQ0QsYUFBYSxDQUFDTCxPQUFkLENBQXNCLENBQXRCLEVBQXlCRyxlQUEvRDtBQUNIOztBQUNELFdBQU9yQixXQUFQO0FBQ0gsR0EvSFU7O0FBZ0lYLCtCQUE2QmhCLE9BQTdCLEVBQXFDO0FBQ2pDLFFBQUlULEdBQUcsR0FBR0csR0FBRyxHQUFHLHNCQUFOLEdBQTZCTSxPQUE3QixHQUFxQyxjQUEvQzs7QUFFQSxRQUFHO0FBQ0MsVUFBSWdCLFdBQVcsR0FBRzVCLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWxCOztBQUNBLFVBQUl5QixXQUFXLENBQUNyQixVQUFaLElBQTBCLEdBQTlCLEVBQWtDO0FBQzlCcUIsbUJBQVcsR0FBR1osSUFBSSxDQUFDQyxLQUFMLENBQVdXLFdBQVcsQ0FBQ1YsT0FBdkIsRUFBZ0NDLE1BQTlDOztBQUNBLFlBQUlTLFdBQVcsSUFBSUEsV0FBVyxDQUFDRCxNQUFaLEdBQXFCLENBQXhDLEVBQTBDO0FBQ3RDQyxxQkFBVyxDQUFDZ0IsT0FBWixDQUFvQixDQUFDUyxVQUFELEVBQWFDLENBQWIsS0FBbUI7QUFDbkMsZ0JBQUkxQixXQUFXLENBQUMwQixDQUFELENBQVgsSUFBa0IxQixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBckMsRUFDSVosV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLENBQWVkLE1BQWYsR0FBd0JDLFVBQVUsQ0FBQ2IsV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLENBQWVkLE1BQWhCLENBQWxDO0FBQ1AsV0FIRDtBQUlIOztBQUVELGVBQU9aLFdBQVA7QUFDSDs7QUFBQTtBQUNKLEtBYkQsQ0FjQSxPQUFPcEIsQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixHQXBKVTs7QUFxSlgsOEJBQTRCSSxPQUE1QixFQUFvQztBQUNoQyxRQUFJVCxHQUFHLEdBQUdHLEdBQUcsR0FBRyxzQkFBTixHQUE2Qk0sT0FBN0IsR0FBcUMsd0JBQS9DOztBQUVBLFFBQUc7QUFDQyxVQUFJMkMsVUFBVSxHQUFHdkQsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBakI7O0FBQ0EsVUFBSW9ELFVBQVUsQ0FBQ2hELFVBQVgsSUFBeUIsR0FBN0IsRUFBaUM7QUFDN0JnRCxrQkFBVSxHQUFHdkMsSUFBSSxDQUFDQyxLQUFMLENBQVdzQyxVQUFVLENBQUNyQyxPQUF0QixFQUErQkMsTUFBNUM7QUFDQSxlQUFPb0MsVUFBUDtBQUNIOztBQUFBO0FBQ0osS0FORCxDQU9BLE9BQU8vQyxDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLEdBbEtVOztBQW1LWCxpQ0FBK0JJLE9BQS9CLEVBQXdDb0IsU0FBeEMsRUFBa0Q7QUFDOUMsUUFBSTdCLEdBQUcsOENBQXVDUyxPQUF2Qyw2QkFBaUVvQixTQUFqRSxDQUFQO0FBQ0EsUUFBSWIsTUFBTSxHQUFHakIsWUFBWSxDQUFDQyxHQUFELENBQXpCOztBQUNBLFFBQUlnQixNQUFNLElBQUlBLE1BQU0sQ0FBQ29CLElBQXJCLEVBQTJCO0FBQ3ZCLFVBQUlpQixhQUFhLEdBQUcsRUFBcEI7QUFDQXJDLFlBQU0sQ0FBQ29CLElBQVAsQ0FBWUssT0FBWixDQUFxQmEsWUFBRCxJQUFrQjtBQUNsQyxZQUFJWCxPQUFPLEdBQUdXLFlBQVksQ0FBQ1gsT0FBM0I7QUFDQVUscUJBQWEsQ0FBQ0MsWUFBWSxDQUFDQyxxQkFBZCxDQUFiLEdBQW9EO0FBQ2hEQyxlQUFLLEVBQUViLE9BQU8sQ0FBQ25CLE1BRGlDO0FBRWhEZ0Isd0JBQWMsRUFBRUcsT0FBTyxDQUFDLENBQUQsQ0FBUCxDQUFXRztBQUZxQixTQUFwRDtBQUlILE9BTkQ7QUFPQSxhQUFPTyxhQUFQO0FBQ0g7QUFDSjs7QUFqTFUsQ0FBZixFOzs7Ozs7Ozs7OztBQ2ZBLElBQUk1RCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSTZELE9BQUo7QUFBWS9ELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUM4RCxTQUFPLENBQUM3RCxDQUFELEVBQUc7QUFBQzZELFdBQU8sR0FBQzdELENBQVI7QUFBVTs7QUFBdEIsQ0FBN0IsRUFBcUQsQ0FBckQ7QUFBd0QsSUFBSThELFNBQUo7QUFBY2hFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtCQUFaLEVBQTRDO0FBQUMrRCxXQUFTLENBQUM5RCxDQUFELEVBQUc7QUFBQzhELGFBQVMsR0FBQzlELENBQVY7QUFBWTs7QUFBMUIsQ0FBNUMsRUFBd0UsQ0FBeEU7QUFBMkUsSUFBSStELEtBQUo7QUFBVWpFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUNnRSxPQUFLLENBQUMvRCxDQUFELEVBQUc7QUFBQytELFNBQUssR0FBQy9ELENBQU47QUFBUTs7QUFBbEIsQ0FBMUMsRUFBOEQsQ0FBOUQ7QUFBaUUsSUFBSWdFLGFBQUo7QUFBa0JsRSxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQ0FBWixFQUE0RDtBQUFDaUUsZUFBYSxDQUFDaEUsQ0FBRCxFQUFHO0FBQUNnRSxpQkFBYSxHQUFDaEUsQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBNUQsRUFBZ0csQ0FBaEc7QUFBbUcsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSx1Q0FBWixFQUFvRDtBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBcEQsRUFBa0YsQ0FBbEY7QUFBcUYsSUFBSWlFLGdCQUFKLEVBQXFCQyxTQUFyQixFQUErQkMsZUFBL0I7QUFBK0NyRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxpQ0FBWixFQUE4QztBQUFDa0Usa0JBQWdCLENBQUNqRSxDQUFELEVBQUc7QUFBQ2lFLG9CQUFnQixHQUFDakUsQ0FBakI7QUFBbUIsR0FBeEM7O0FBQXlDa0UsV0FBUyxDQUFDbEUsQ0FBRCxFQUFHO0FBQUNrRSxhQUFTLEdBQUNsRSxDQUFWO0FBQVksR0FBbEU7O0FBQW1FbUUsaUJBQWUsQ0FBQ25FLENBQUQsRUFBRztBQUFDbUUsbUJBQWUsR0FBQ25FLENBQWhCO0FBQWtCOztBQUF4RyxDQUE5QyxFQUF3SixDQUF4SjtBQUEySixJQUFJb0Usa0JBQUo7QUFBdUJ0RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQ0FBWixFQUFtRDtBQUFDcUUsb0JBQWtCLENBQUNwRSxDQUFELEVBQUc7QUFBQ29FLHNCQUFrQixHQUFDcEUsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQW5ELEVBQWlHLENBQWpHO0FBQW9HLElBQUlxRSxZQUFKO0FBQWlCdkUsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ3NFLGNBQVksQ0FBQ3JFLENBQUQsRUFBRztBQUFDcUUsZ0JBQVksR0FBQ3JFLENBQWI7QUFBZTs7QUFBaEMsQ0FBakQsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSXNFLFNBQUo7QUFBY3hFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDhCQUFaLEVBQTJDO0FBQUN1RSxXQUFTLENBQUN0RSxDQUFELEVBQUc7QUFBQ3NFLGFBQVMsR0FBQ3RFLENBQVY7QUFBWTs7QUFBMUIsQ0FBM0MsRUFBdUUsRUFBdkU7QUFBMkUsSUFBSXVFLE1BQUo7QUFBV3pFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQ3dFLFFBQU0sQ0FBQ3ZFLENBQUQsRUFBRztBQUFDdUUsVUFBTSxHQUFDdkUsQ0FBUDtBQUFTOztBQUFwQixDQUF4QixFQUE4QyxFQUE5QztBQUFrRCxJQUFJd0UsVUFBSjtBQUFlMUUsTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQ3lFLFlBQVUsQ0FBQ3hFLENBQUQsRUFBRztBQUFDd0UsY0FBVSxHQUFDeEUsQ0FBWDtBQUFhOztBQUE1QixDQUFwQyxFQUFrRSxFQUFsRTtBQUFzRSxJQUFJeUUsT0FBSjtBQUFZM0UsTUFBTSxDQUFDQyxJQUFQLENBQVksU0FBWixFQUFzQjtBQUFDLE1BQUlDLENBQUosRUFBTTtBQUFDeUUsV0FBTyxHQUFDekUsQ0FBUjtBQUFVOztBQUFsQixDQUF0QixFQUEwQyxFQUExQzs7QUFlNXRDO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTBFLG9CQUFvQixHQUFHLENBQUNDLGNBQUQsRUFBaUJDLFVBQWpCLEtBQWdDO0FBQ25EO0FBQ0EsT0FBS0MsQ0FBTCxJQUFVRixjQUFWLEVBQXlCO0FBQ3JCLFNBQUszRSxDQUFMLElBQVU0RSxVQUFWLEVBQXFCO0FBQ2pCLFVBQUlELGNBQWMsQ0FBQ0UsQ0FBRCxDQUFkLENBQWtCaEUsT0FBbEIsSUFBNkIrRCxVQUFVLENBQUM1RSxDQUFELENBQVYsQ0FBY2EsT0FBL0MsRUFBdUQ7QUFDbkQ4RCxzQkFBYyxDQUFDRyxNQUFmLENBQXNCRCxDQUF0QixFQUF3QixDQUF4QjtBQUNIO0FBQ0o7QUFDSjs7QUFFRCxTQUFPRixjQUFQO0FBQ0gsQ0FYRDs7QUFhQUksc0JBQXNCLEdBQUlDLFFBQUQsSUFBYztBQUNuQyxNQUFJQSxRQUFRLENBQUNwRCxNQUFULElBQW1CLEVBQXZCLEVBQTBCO0FBQ3RCLFFBQUlaLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLG9FQUFxRTBFLFFBQXJFLHNCQUFmOztBQUNBLFFBQUloRSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBZ0M7QUFDNUIsVUFBSXlFLElBQUksR0FBR2pFLFFBQVEsQ0FBQ3dCLElBQVQsQ0FBY3lDLElBQXpCO0FBQ0EsYUFBT0EsSUFBSSxJQUFJQSxJQUFJLENBQUNyRCxNQUFiLElBQXVCcUQsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRQyxRQUEvQixJQUEyQ0QsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRQyxRQUFSLENBQWlCQyxPQUE1RCxJQUF1RUYsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRQyxRQUFSLENBQWlCQyxPQUFqQixDQUF5Qi9FLEdBQXZHO0FBQ0gsS0FIRCxNQUdPO0FBQ0hNLGFBQU8sQ0FBQ0MsR0FBUixDQUFZTSxJQUFJLENBQUNtRSxTQUFMLENBQWVwRSxRQUFmLENBQVo7QUFDSDtBQUNKLEdBUkQsTUFRTyxJQUFJZ0UsUUFBUSxDQUFDSyxPQUFULENBQWlCLGtCQUFqQixJQUFxQyxDQUF6QyxFQUEyQztBQUM5QyxRQUFJQyxRQUFRLEdBQUdyRixJQUFJLENBQUNLLEdBQUwsQ0FBUzBFLFFBQVQsQ0FBZjs7QUFDQSxRQUFJTSxRQUFRLENBQUM5RSxVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCLFVBQUkrRSxJQUFJLEdBQUdkLE9BQU8sQ0FBQ2UsSUFBUixDQUFhRixRQUFRLENBQUNuRSxPQUF0QixDQUFYO0FBQ0EsYUFBT29FLElBQUksQ0FBQyxtQkFBRCxDQUFKLENBQTBCRSxJQUExQixDQUErQixLQUEvQixDQUFQO0FBQ0gsS0FIRCxNQUdPO0FBQ0gvRSxhQUFPLENBQUNDLEdBQVIsQ0FBWU0sSUFBSSxDQUFDbUUsU0FBTCxDQUFlRSxRQUFmLENBQVo7QUFDSDtBQUNKO0FBQ0osQ0FsQkQsQyxDQW9CQTtBQUNBOzs7QUFFQXpGLE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsNEJBQTBCQyxPQUExQixFQUFrQztBQUM5QixRQUFJNkUsTUFBTSxHQUFHNUIsU0FBUyxDQUFDNkIsSUFBVixDQUFlO0FBQUNDLHFCQUFlLEVBQUMvRTtBQUFqQixLQUFmLEVBQTBDZ0YsS0FBMUMsRUFBYjtBQUNBLFFBQUlDLE9BQU8sR0FBR0osTUFBTSxDQUFDSyxHQUFQLENBQVcsQ0FBQ0MsS0FBRCxFQUFRekMsQ0FBUixLQUFjO0FBQ25DLGFBQU95QyxLQUFLLENBQUNDLE1BQWI7QUFDSCxLQUZhLENBQWQ7QUFHQSxRQUFJQyxXQUFXLEdBQUdoQyxTQUFTLENBQUN5QixJQUFWLENBQWU7QUFBQ00sWUFBTSxFQUFDO0FBQUNFLFdBQUcsRUFBQ0w7QUFBTDtBQUFSLEtBQWYsRUFBdUNELEtBQXZDLEVBQWxCLENBTDhCLENBTTlCOztBQUVBLFFBQUlPLGNBQWMsR0FBRyxDQUFyQjs7QUFDQSxTQUFLQyxDQUFMLElBQVVILFdBQVYsRUFBc0I7QUFDbEJFLG9CQUFjLElBQUlGLFdBQVcsQ0FBQ0csQ0FBRCxDQUFYLENBQWVDLFFBQWpDO0FBQ0g7O0FBQ0QsV0FBT0YsY0FBYyxHQUFDTixPQUFPLENBQUNsRSxNQUE5QjtBQUNILEdBZFU7O0FBZVgsc0JBQW9CZixPQUFwQixFQUE0QjtBQUN4QixRQUFJMEYsVUFBVSxHQUFHdEMsZ0JBQWdCLENBQUN1QyxhQUFqQixFQUFqQixDQUR3QixDQUV4Qjs7QUFDQSxRQUFJQyxRQUFRLEdBQUcsQ0FDWDtBQUFDQyxZQUFNLEVBQUM7QUFBQyxtQkFBVTdGO0FBQVg7QUFBUixLQURXLEVBRVg7QUFDQTtBQUFDOEYsV0FBSyxFQUFDO0FBQUMsa0JBQVMsQ0FBQztBQUFYO0FBQVAsS0FIVyxFQUlYO0FBQUNDLFlBQU0sRUFBRS9HLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCQyxZQUF2QixHQUFvQztBQUE3QyxLQUpXLEVBS1g7QUFBQ0MsYUFBTyxFQUFFO0FBQVYsS0FMVyxFQU1YO0FBQUNDLFlBQU0sRUFBQztBQUNKLGVBQU8sVUFESDtBQUVKLGtCQUFVO0FBQ04sa0JBQU87QUFDSEMsaUJBQUssRUFBRSxDQUFDO0FBQUNDLGlCQUFHLEVBQUUsQ0FBQyxTQUFELEVBQVksSUFBWjtBQUFOLGFBQUQsRUFBMkIsQ0FBM0IsRUFBOEIsQ0FBOUI7QUFESjtBQUREO0FBRk47QUFBUixLQU5XLENBQWYsQ0FId0IsQ0FrQnhCOztBQUVBLFdBQU90RCxPQUFPLENBQUN1RCxLQUFSLENBQWNiLFVBQVUsQ0FBQ2MsU0FBWCxDQUFxQlosUUFBckIsRUFBK0JhLE9BQS9CLEVBQWQsQ0FBUCxDQXBCd0IsQ0FxQnhCO0FBQ0gsR0FyQ1U7O0FBc0NYLDRCQUEwQixZQUFXO0FBQ2pDLFNBQUt4RyxPQUFMO0FBQ0EsUUFBSVYsR0FBRyxHQUFHbUgsR0FBRyxHQUFDLFNBQWQ7O0FBQ0EsUUFBRztBQUNDLFVBQUl2RyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxVQUFJb0gsTUFBTSxHQUFHdkcsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBYjtBQUNBLGFBQVFxRyxNQUFNLENBQUNwRyxNQUFQLENBQWNxRyxTQUFkLENBQXdCQyxtQkFBaEM7QUFDSCxLQUpELENBS0EsT0FBT2pILENBQVAsRUFBUztBQUNMLGFBQU8sQ0FBUDtBQUNIO0FBQ0osR0FqRFU7QUFrRFgsNkJBQTJCLFlBQVc7QUFDbEMsU0FBS0ssT0FBTDtBQUNBLFFBQUk2RyxVQUFVLEdBQUc3RCxTQUFTLENBQUM2QixJQUFWLENBQWUsRUFBZixFQUFrQjtBQUFDaUMsVUFBSSxFQUFDO0FBQUMzQixjQUFNLEVBQUMsQ0FBQztBQUFULE9BQU47QUFBa0I0QixXQUFLLEVBQUM7QUFBeEIsS0FBbEIsRUFBOENoQyxLQUE5QyxFQUFqQixDQUZrQyxDQUdsQzs7QUFDQSxRQUFJaUMsV0FBVyxHQUFHakksTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCRCxXQUF6Qzs7QUFDQSxRQUFJSCxVQUFVLElBQUlBLFVBQVUsQ0FBQy9GLE1BQVgsSUFBcUIsQ0FBdkMsRUFBMEM7QUFDdEMsVUFBSXFFLE1BQU0sR0FBRzBCLFVBQVUsQ0FBQyxDQUFELENBQVYsQ0FBYzFCLE1BQTNCO0FBQ0EsVUFBSUEsTUFBTSxHQUFHNkIsV0FBYixFQUNJLE9BQU83QixNQUFQO0FBQ1A7O0FBQ0QsV0FBTzZCLFdBQVA7QUFDSCxHQTdEVTtBQThEWCx5QkFBdUIsWUFBVztBQUM5QixRQUFJRSxPQUFKLEVBQ0ksT0FBTyxZQUFQLENBREosS0FFS3RILE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQVosRUFIeUIsQ0FJOUI7QUFDQTs7QUFDQSxRQUFJc0gsS0FBSyxHQUFHcEksTUFBTSxDQUFDcUksSUFBUCxDQUFZLHdCQUFaLENBQVosQ0FOOEIsQ0FPOUI7QUFDQTs7QUFDQSxRQUFJQyxJQUFJLEdBQUd0SSxNQUFNLENBQUNxSSxJQUFQLENBQVkseUJBQVosQ0FBWDtBQUNBeEgsV0FBTyxDQUFDQyxHQUFSLENBQVl3SCxJQUFaLEVBVjhCLENBVzlCOztBQUNBLFFBQUlGLEtBQUssR0FBR0UsSUFBWixFQUFrQjtBQUNkSCxhQUFPLEdBQUcsSUFBVjtBQUVBLFVBQUlJLFlBQVksR0FBRyxFQUFuQixDQUhjLENBSWQ7O0FBQ0FoSSxTQUFHLEdBQUdHLEdBQUcsR0FBQyxxQkFBVjs7QUFFQSxVQUFHO0FBQ0NTLGdCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQWEsWUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTdCLENBQW9DeUIsT0FBcEMsQ0FBNkNaLFNBQUQsSUFBZW1HLFlBQVksQ0FBQ25HLFNBQVMsQ0FBQ29HLGdCQUFYLENBQVosR0FBMkNwRyxTQUF0RztBQUNILE9BSEQsQ0FJQSxPQUFNeEIsQ0FBTixFQUFRO0FBQ0pDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBRURMLFNBQUcsR0FBR0csR0FBRyxHQUFDLHNDQUFWOztBQUVBLFVBQUc7QUFDQ1MsZ0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBYSxZQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBN0IsQ0FBb0N5QixPQUFwQyxDQUE2Q1osU0FBRCxJQUFlbUcsWUFBWSxDQUFDbkcsU0FBUyxDQUFDb0csZ0JBQVgsQ0FBWixHQUEyQ3BHLFNBQXRHO0FBQ0gsT0FIRCxDQUlBLE9BQU14QixDQUFOLEVBQVE7QUFDSkMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFFREwsU0FBRyxHQUFHRyxHQUFHLEdBQUMscUNBQVY7O0FBRUEsVUFBRztBQUNDUyxnQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0FhLFlBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE3QixDQUFvQ3lCLE9BQXBDLENBQTZDWixTQUFELElBQWVtRyxZQUFZLENBQUNuRyxTQUFTLENBQUNvRyxnQkFBWCxDQUFaLEdBQTJDcEcsU0FBdEc7QUFDSCxPQUhELENBSUEsT0FBTXhCLENBQU4sRUFBUTtBQUNKQyxlQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUNELFVBQUk2SCxlQUFlLEdBQUdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZSixZQUFaLEVBQTBCeEcsTUFBaEQ7QUFDQWxCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHFCQUFvQjJILGVBQWhDOztBQUNBLFdBQUssSUFBSXJDLE1BQU0sR0FBR2tDLElBQUksR0FBQyxDQUF2QixFQUEyQmxDLE1BQU0sSUFBSWdDLEtBQXJDLEVBQTZDaEMsTUFBTSxFQUFuRCxFQUF1RDtBQUNuRCxZQUFJd0MsY0FBYyxHQUFHLElBQUl4RixJQUFKLEVBQXJCLENBRG1ELENBRW5EOztBQUNBLGFBQUtuQyxPQUFMO0FBQ0EsWUFBSVYsR0FBRyxHQUFHbUgsR0FBRyxHQUFDLGdCQUFKLEdBQXVCdEIsTUFBakM7QUFDQSxZQUFJeUMsYUFBYSxHQUFHLEVBQXBCO0FBRUFoSSxlQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjs7QUFDQSxZQUFHO0FBQ0MsZ0JBQU11SSxjQUFjLEdBQUd6SSxVQUFVLENBQUNzRyxhQUFYLEdBQTJCb0MseUJBQTNCLEVBQXZCO0FBQ0EsZ0JBQU1DLG9CQUFvQixHQUFHNUUsZ0JBQWdCLENBQUN1QyxhQUFqQixHQUFpQ29DLHlCQUFqQyxFQUE3QjtBQUNBLGdCQUFNRSxhQUFhLEdBQUcxRSxrQkFBa0IsQ0FBQ29DLGFBQW5CLEdBQW1Db0MseUJBQW5DLEVBQXRCO0FBQ0EsZ0JBQU1HLGVBQWUsR0FBRzFFLFlBQVksQ0FBQ21DLGFBQWIsR0FBNkJvQyx5QkFBN0IsRUFBeEI7QUFFQSxjQUFJSSxrQkFBa0IsR0FBRyxJQUFJL0YsSUFBSixFQUF6QjtBQUNBLGNBQUlqQyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7O0FBQ0EsY0FBSVksUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCLGdCQUFJd0YsS0FBSyxHQUFHL0UsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBWjtBQUNBNkUsaUJBQUssR0FBR0EsS0FBSyxDQUFDNUUsTUFBZCxDQUYyQixDQUczQjs7QUFDQSxnQkFBSTZILFNBQVMsR0FBRyxFQUFoQjtBQUNBQSxxQkFBUyxDQUFDaEQsTUFBVixHQUFtQkEsTUFBbkI7QUFDQWdELHFCQUFTLENBQUNDLElBQVYsR0FBaUJsRCxLQUFLLENBQUNtRCxRQUFOLENBQWVELElBQWhDO0FBQ0FELHFCQUFTLENBQUNHLFFBQVYsR0FBc0JwRCxLQUFLLENBQUNBLEtBQU4sQ0FBWXhELElBQVosQ0FBaUI2RyxHQUFqQixLQUF5QixJQUExQixHQUFrQyxDQUFsQyxHQUFzQ3JELEtBQUssQ0FBQ0EsS0FBTixDQUFZeEQsSUFBWixDQUFpQjZHLEdBQWpCLENBQXFCekgsTUFBaEY7QUFDQXFILHFCQUFTLENBQUNqRyxJQUFWLEdBQWlCLElBQUlDLElBQUosQ0FBUytDLEtBQUssQ0FBQ0EsS0FBTixDQUFZc0QsTUFBWixDQUFtQnRHLElBQTVCLENBQWpCO0FBQ0FpRyxxQkFBUyxDQUFDTSxhQUFWLEdBQTBCdkQsS0FBSyxDQUFDQSxLQUFOLENBQVlzRCxNQUFaLENBQW1CRSxhQUFuQixDQUFpQ04sSUFBM0Q7QUFDQUQscUJBQVMsQ0FBQ3JELGVBQVYsR0FBNEJJLEtBQUssQ0FBQ0EsS0FBTixDQUFZc0QsTUFBWixDQUFtQkcsZ0JBQS9DO0FBQ0FSLHFCQUFTLENBQUNyRSxVQUFWLEdBQXVCLEVBQXZCO0FBQ0EsZ0JBQUk4RSxVQUFVLEdBQUcxRCxLQUFLLENBQUNBLEtBQU4sQ0FBWTJELFdBQVosQ0FBd0JDLFVBQXpDOztBQUNBLGdCQUFJRixVQUFVLElBQUksSUFBbEIsRUFBdUI7QUFDbkI7QUFDQSxtQkFBSyxJQUFJbkcsQ0FBQyxHQUFDLENBQVgsRUFBY0EsQ0FBQyxHQUFDbUcsVUFBVSxDQUFDOUgsTUFBM0IsRUFBbUMyQixDQUFDLEVBQXBDLEVBQXVDO0FBQ25DLG9CQUFJbUcsVUFBVSxDQUFDbkcsQ0FBRCxDQUFWLElBQWlCLElBQXJCLEVBQTBCO0FBQ3RCMEYsMkJBQVMsQ0FBQ3JFLFVBQVYsQ0FBcUJpRixJQUFyQixDQUEwQkgsVUFBVSxDQUFDbkcsQ0FBRCxDQUFWLENBQWN1RyxpQkFBeEM7QUFDSDtBQUNKOztBQUVEcEIsMkJBQWEsQ0FBQ2dCLFVBQWQsR0FBMkJBLFVBQVUsQ0FBQzlILE1BQXRDLENBUm1CLENBU25CO0FBQ0E7QUFDSCxhQXhCMEIsQ0EwQjNCOzs7QUFDQSxnQkFBSW9FLEtBQUssQ0FBQ0EsS0FBTixDQUFZeEQsSUFBWixDQUFpQjZHLEdBQWpCLElBQXdCckQsS0FBSyxDQUFDQSxLQUFOLENBQVl4RCxJQUFaLENBQWlCNkcsR0FBakIsQ0FBcUJ6SCxNQUFyQixHQUE4QixDQUExRCxFQUE0RDtBQUN4RCxtQkFBS21JLENBQUwsSUFBVS9ELEtBQUssQ0FBQ0EsS0FBTixDQUFZeEQsSUFBWixDQUFpQjZHLEdBQTNCLEVBQStCO0FBQzNCeEosc0JBQU0sQ0FBQ3FJLElBQVAsQ0FBWSxvQkFBWixFQUFrQzNELE1BQU0sQ0FBQ3lGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZakUsS0FBSyxDQUFDQSxLQUFOLENBQVl4RCxJQUFaLENBQWlCNkcsR0FBakIsQ0FBcUJVLENBQXJCLENBQVosRUFBcUMsUUFBckMsQ0FBRCxDQUF4QyxFQUEwRmQsU0FBUyxDQUFDakcsSUFBcEcsRUFBMEcsQ0FBQ2tILEdBQUQsRUFBTTlJLE1BQU4sS0FBaUI7QUFDdkgsc0JBQUk4SSxHQUFKLEVBQVE7QUFDSnhKLDJCQUFPLENBQUNDLEdBQVIsQ0FBWXVKLEdBQVo7QUFDSDtBQUNKLGlCQUpEO0FBS0g7QUFDSixhQW5DMEIsQ0FxQzNCOzs7QUFDQSxnQkFBSWxFLEtBQUssQ0FBQ0EsS0FBTixDQUFZbUUsUUFBWixDQUFxQkEsUUFBekIsRUFBa0M7QUFDOUI3Rix1QkFBUyxDQUFDOEYsTUFBVixDQUFpQjtBQUNibkUsc0JBQU0sRUFBRUEsTUFESztBQUVia0Usd0JBQVEsRUFBRW5FLEtBQUssQ0FBQ0EsS0FBTixDQUFZbUUsUUFBWixDQUFxQkE7QUFGbEIsZUFBakI7QUFJSDs7QUFFRGxCLHFCQUFTLENBQUNvQixlQUFWLEdBQTRCcEIsU0FBUyxDQUFDckUsVUFBVixDQUFxQmhELE1BQWpEO0FBRUE4Ryx5QkFBYSxDQUFDekMsTUFBZCxHQUF1QkEsTUFBdkI7QUFFQSxnQkFBSXFFLGdCQUFnQixHQUFHLElBQUlySCxJQUFKLEVBQXZCO0FBQ0F2QyxtQkFBTyxDQUFDQyxHQUFSLENBQVksc0JBQXFCLENBQUMySixnQkFBZ0IsR0FBQ3RCLGtCQUFsQixJQUFzQyxJQUEzRCxHQUFpRSxVQUE3RTtBQUdBLGdCQUFJdUIsc0JBQXNCLEdBQUcsSUFBSXRILElBQUosRUFBN0IsQ0FyRDJCLENBc0QzQjs7QUFDQTdDLGVBQUcsR0FBR21ILEdBQUcsR0FBQyxxQkFBSixHQUEwQnRCLE1BQWhDO0FBQ0FqRixvQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0FNLG1CQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjtBQUNBLGdCQUFJd0UsVUFBVSxHQUFHM0QsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBakI7QUFDQXlELHNCQUFVLENBQUN4RCxNQUFYLENBQWtCb0osWUFBbEIsR0FBaUNDLFFBQVEsQ0FBQzdGLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0JvSixZQUFuQixDQUF6QztBQUNBeEcseUJBQWEsQ0FBQ29HLE1BQWQsQ0FBcUJ4RixVQUFVLENBQUN4RCxNQUFoQztBQUVBNkgscUJBQVMsQ0FBQ3lCLGVBQVYsR0FBNEI5RixVQUFVLENBQUN4RCxNQUFYLENBQWtCd0QsVUFBbEIsQ0FBNkJoRCxNQUF6RDtBQUNBLGdCQUFJK0ksb0JBQW9CLEdBQUcsSUFBSTFILElBQUosRUFBM0I7QUFDQWEscUJBQVMsQ0FBQ3NHLE1BQVYsQ0FBaUJuQixTQUFqQjtBQUNBLGdCQUFJMkIsa0JBQWtCLEdBQUcsSUFBSTNILElBQUosRUFBekI7QUFDQXZDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBdUIsQ0FBQ2lLLGtCQUFrQixHQUFDRCxvQkFBcEIsSUFBMEMsSUFBakUsR0FBdUUsVUFBbkYsRUFsRTJCLENBb0UzQjs7QUFDQSxnQkFBSUUsa0JBQWtCLEdBQUczSyxVQUFVLENBQUN5RixJQUFYLENBQWdCO0FBQUM5RSxxQkFBTyxFQUFDO0FBQUNpSyx1QkFBTyxFQUFDO0FBQVQ7QUFBVCxhQUFoQixFQUEwQ2pGLEtBQTFDLEVBQXpCOztBQUVBLGdCQUFJSSxNQUFNLEdBQUcsQ0FBYixFQUFlO0FBQ1g7QUFDQTtBQUNBLG1CQUFLMUMsQ0FBTCxJQUFVcUIsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQTVCLEVBQXVDO0FBQ25DLG9CQUFJL0QsT0FBTyxHQUFHK0QsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQWxCLENBQTZCckIsQ0FBN0IsRUFBZ0MxQyxPQUE5QztBQUNBLG9CQUFJa0ssTUFBTSxHQUFHO0FBQ1Q5RSx3QkFBTSxFQUFFQSxNQURDO0FBRVRwRix5QkFBTyxFQUFFQSxPQUZBO0FBR1RtSyx3QkFBTSxFQUFFLEtBSEM7QUFJVEMsOEJBQVksRUFBRVIsUUFBUSxDQUFDN0YsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQWxCLENBQTZCckIsQ0FBN0IsRUFBZ0MwSCxZQUFqQyxDQUpiLENBSTJEOztBQUozRCxpQkFBYjs7QUFPQSxxQkFBS0MsQ0FBTCxJQUFVeEIsVUFBVixFQUFxQjtBQUNqQixzQkFBSUEsVUFBVSxDQUFDd0IsQ0FBRCxDQUFWLElBQWlCLElBQXJCLEVBQTBCO0FBQ3RCLHdCQUFJckssT0FBTyxJQUFJNkksVUFBVSxDQUFDd0IsQ0FBRCxDQUFWLENBQWNwQixpQkFBN0IsRUFBK0M7QUFDM0NpQiw0QkFBTSxDQUFDQyxNQUFQLEdBQWdCLElBQWhCO0FBQ0F0QixnQ0FBVSxDQUFDNUUsTUFBWCxDQUFrQm9HLENBQWxCLEVBQW9CLENBQXBCO0FBQ0E7QUFDSDtBQUNKO0FBQ0osaUJBakJrQyxDQW1CbkM7QUFDQTs7O0FBRUEsb0JBQUtqRixNQUFNLEdBQUcsRUFBVixJQUFpQixDQUFyQixFQUF1QjtBQUNuQjtBQUNBLHNCQUFJa0YsU0FBUyxHQUFHdEwsTUFBTSxDQUFDcUksSUFBUCxDQUFZLG1CQUFaLEVBQWlDckgsT0FBakMsQ0FBaEI7QUFDQSxzQkFBSXVLLE1BQU0sR0FBRyxDQUFiLENBSG1CLENBSW5CO0FBQ0E7O0FBQ0Esc0JBQUtELFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsSUFBakIsSUFBMkJBLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYUMsTUFBYixJQUF1QixJQUF0RCxFQUE0RDtBQUN4REEsMEJBQU0sR0FBR0QsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhQyxNQUF0QjtBQUNIOztBQUVELHNCQUFJQyxJQUFJLEdBQUd4TCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QkMsWUFBbEM7O0FBQ0Esc0JBQUlkLE1BQU0sR0FBR29GLElBQWIsRUFBa0I7QUFDZEEsd0JBQUksR0FBR3BGLE1BQVA7QUFDSDs7QUFFRCxzQkFBSThFLE1BQU0sQ0FBQ0MsTUFBWCxFQUFrQjtBQUNkLHdCQUFJSSxNQUFNLEdBQUdDLElBQWIsRUFBa0I7QUFDZEQsNEJBQU07QUFDVDs7QUFDREEsMEJBQU0sR0FBSUEsTUFBTSxHQUFHQyxJQUFWLEdBQWdCLEdBQXpCO0FBQ0ExQyxrQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDOUUsNkJBQU8sRUFBQ0E7QUFBVCxxQkFBcEIsRUFBdUN5SyxNQUF2QyxHQUFnREMsU0FBaEQsQ0FBMEQ7QUFBQ0MsMEJBQUksRUFBQztBQUFDSiw4QkFBTSxFQUFDQSxNQUFSO0FBQWdCSyxnQ0FBUSxFQUFDeEMsU0FBUyxDQUFDakc7QUFBbkM7QUFBTixxQkFBMUQ7QUFDSCxtQkFORCxNQU9JO0FBQ0FvSSwwQkFBTSxHQUFJQSxNQUFNLEdBQUdDLElBQVYsR0FBZ0IsR0FBekI7QUFDQTFDLGtDQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUM5RSw2QkFBTyxFQUFDQTtBQUFULHFCQUFwQixFQUF1Q3lLLE1BQXZDLEdBQWdEQyxTQUFoRCxDQUEwRDtBQUFDQywwQkFBSSxFQUFDO0FBQUNKLDhCQUFNLEVBQUNBO0FBQVI7QUFBTixxQkFBMUQ7QUFDSDtBQUNKOztBQUVEdkMsb0NBQW9CLENBQUN1QixNQUFyQixDQUE0QlcsTUFBNUIsRUFsRG1DLENBbURuQztBQUNIO0FBQ0o7O0FBRUQsZ0JBQUlXLFdBQVcsR0FBRzNILEtBQUssQ0FBQzdCLE9BQU4sQ0FBYztBQUFDeUoscUJBQU8sRUFBQzNGLEtBQUssQ0FBQ0EsS0FBTixDQUFZc0QsTUFBWixDQUFtQnNDO0FBQTVCLGFBQWQsQ0FBbEI7QUFDQSxnQkFBSUMsY0FBYyxHQUFHSCxXQUFXLEdBQUNBLFdBQVcsQ0FBQ0csY0FBYixHQUE0QixDQUE1RDtBQUNBLGdCQUFJdkYsUUFBSjtBQUNBLGdCQUFJd0YsU0FBUyxHQUFHak0sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCZ0UsZ0JBQXZDOztBQUNBLGdCQUFJRixjQUFKLEVBQW1CO0FBQ2Ysa0JBQUlHLFVBQVUsR0FBRy9DLFNBQVMsQ0FBQ2pHLElBQTNCO0FBQ0Esa0JBQUlpSixRQUFRLEdBQUcsSUFBSWhKLElBQUosQ0FBUzRJLGNBQVQsQ0FBZjtBQUNBdkYsc0JBQVEsR0FBRzRGLElBQUksQ0FBQ0MsR0FBTCxDQUFTSCxVQUFVLENBQUNJLE9BQVgsS0FBdUJILFFBQVEsQ0FBQ0csT0FBVCxFQUFoQyxDQUFYLENBSGUsQ0FJZjs7QUFDQSxrQkFBR25ELFNBQVMsQ0FBQ2hELE1BQVYsR0FBbUIsQ0FBdEIsRUFBeUI7QUFDckI2Rix5QkFBUyxHQUFHLENBQUNKLFdBQVcsQ0FBQ0ksU0FBWixJQUF5QjdDLFNBQVMsQ0FBQ2hELE1BQVYsR0FBbUIsQ0FBNUMsSUFBaURLLFFBQWxELElBQThEMkMsU0FBUyxDQUFDaEQsTUFBcEY7QUFDSDtBQUNKOztBQUVELGdCQUFJb0csb0JBQW9CLEdBQUcsSUFBSXBKLElBQUosRUFBM0I7QUFDQXZDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSxpQ0FBZ0MsQ0FBQzBMLG9CQUFvQixHQUFDOUIsc0JBQXRCLElBQThDLElBQTlFLEdBQW9GLFVBQWhHO0FBRUF4RyxpQkFBSyxDQUFDdUksTUFBTixDQUFhO0FBQUNYLHFCQUFPLEVBQUMzRixLQUFLLENBQUNBLEtBQU4sQ0FBWXNELE1BQVosQ0FBbUJzQztBQUE1QixhQUFiLEVBQW9EO0FBQUNKLGtCQUFJLEVBQUM7QUFBQ0ssOEJBQWMsRUFBQzVDLFNBQVMsQ0FBQ2pHLElBQTFCO0FBQWdDOEkseUJBQVMsRUFBQ0E7QUFBMUM7QUFBTixhQUFwRDtBQUVBcEQseUJBQWEsQ0FBQzZELGdCQUFkLEdBQWlDVCxTQUFqQztBQUNBcEQseUJBQWEsQ0FBQ3BDLFFBQWQsR0FBeUJBLFFBQXpCO0FBRUFvQyx5QkFBYSxDQUFDMUYsSUFBZCxHQUFxQmlHLFNBQVMsQ0FBQ2pHLElBQS9CLENBdkoyQixDQXlKM0I7QUFDQTtBQUNBO0FBQ0E7O0FBRUEwRix5QkFBYSxDQUFDdUMsWUFBZCxHQUE2QixDQUE3QjtBQUVBLGdCQUFJdUIsMkJBQTJCLEdBQUcsSUFBSXZKLElBQUosRUFBbEM7O0FBQ0EsZ0JBQUkyQixVQUFVLENBQUN4RCxNQUFmLEVBQXNCO0FBQ2xCO0FBQ0FWLHFCQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBc0JpRSxVQUFVLENBQUN4RCxNQUFYLENBQWtCd0QsVUFBbEIsQ0FBNkJoRCxNQUEvRDs7QUFDQSxtQkFBSzVCLENBQUwsSUFBVTRFLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0J3RCxVQUE1QixFQUF1QztBQUNuQztBQUNBLG9CQUFJM0MsU0FBUyxHQUFHMkMsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQWxCLENBQTZCNUUsQ0FBN0IsQ0FBaEI7QUFDQWlDLHlCQUFTLENBQUNnSixZQUFWLEdBQXlCUixRQUFRLENBQUN4SSxTQUFTLENBQUNnSixZQUFYLENBQWpDO0FBQ0FoSix5QkFBUyxDQUFDd0ssaUJBQVYsR0FBOEJoQyxRQUFRLENBQUN4SSxTQUFTLENBQUN3SyxpQkFBWCxDQUF0QztBQUVBLG9CQUFJQyxRQUFRLEdBQUd4TSxVQUFVLENBQUNnQyxPQUFYLENBQW1CO0FBQUMsbUNBQWdCRCxTQUFTLENBQUMwSyxPQUFWLENBQWtCcEw7QUFBbkMsaUJBQW5CLENBQWY7O0FBQ0Esb0JBQUksQ0FBQ21MLFFBQUwsRUFBYztBQUNWaE0seUJBQU8sQ0FBQ0MsR0FBUiw2QkFBaUNzQixTQUFTLENBQUNwQixPQUEzQyxjQUFzRG9CLFNBQVMsQ0FBQzBLLE9BQVYsQ0FBa0JwTCxLQUF4RSxpQkFEVSxDQUVWO0FBQ0E7QUFDQTs7QUFFQVUsMkJBQVMsQ0FBQ3BCLE9BQVYsR0FBb0IyRCxVQUFVLENBQUN2QyxTQUFTLENBQUMwSyxPQUFYLENBQTlCO0FBQ0ExSywyQkFBUyxDQUFDMkssTUFBVixHQUFtQi9NLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmpHLFNBQVMsQ0FBQzBLLE9BQXhDLEVBQWlEOU0sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUIrRixrQkFBeEUsQ0FBbkI7QUFDQTVLLDJCQUFTLENBQUM2SyxlQUFWLEdBQTRCak4sTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCakcsU0FBUyxDQUFDMEssT0FBeEMsRUFBaUQ5TSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmlHLGtCQUF4RSxDQUE1QjtBQUNBOUssMkJBQVMsQ0FBQ29HLGdCQUFWLEdBQTZCeEksTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCakcsU0FBUyxDQUFDMEssT0FBeEMsRUFBaUQ5TSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmtHLG1CQUF4RSxDQUE3QjtBQUVBLHNCQUFJQyxhQUFhLEdBQUc3RSxZQUFZLENBQUNuRyxTQUFTLENBQUNvRyxnQkFBWCxDQUFoQzs7QUFDQSxzQkFBSTRFLGFBQUosRUFBa0I7QUFDZCx3QkFBSUEsYUFBYSxDQUFDQyxXQUFkLENBQTBCbEksUUFBOUIsRUFDSS9DLFNBQVMsQ0FBQ2tMLFdBQVYsR0FBeUJwSSxzQkFBc0IsQ0FBQ2tJLGFBQWEsQ0FBQ0MsV0FBZCxDQUEwQmxJLFFBQTNCLENBQS9DO0FBQ0ovQyw2QkFBUyxDQUFDRyxnQkFBVixHQUE2QjZLLGFBQWEsQ0FBQzdLLGdCQUEzQztBQUNBSCw2QkFBUyxDQUFDSSxpQkFBVixHQUE4QnhDLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxjQUFaLEVBQTRCK0UsYUFBYSxDQUFDN0ssZ0JBQTFDLENBQTlCO0FBQ0FILDZCQUFTLENBQUNtTCxNQUFWLEdBQW1CSCxhQUFhLENBQUNHLE1BQWpDO0FBQ0FuTCw2QkFBUyxDQUFDdUYsTUFBVixHQUFtQnlGLGFBQWEsQ0FBQ3pGLE1BQWpDO0FBQ0F2Riw2QkFBUyxDQUFDb0wsbUJBQVYsR0FBZ0NKLGFBQWEsQ0FBQ0ksbUJBQTlDO0FBQ0FwTCw2QkFBUyxDQUFDcUwsTUFBVixHQUFtQkwsYUFBYSxDQUFDSyxNQUFqQztBQUNBckwsNkJBQVMsQ0FBQ3NMLGdCQUFWLEdBQTZCTixhQUFhLENBQUNNLGdCQUEzQztBQUNBdEwsNkJBQVMsQ0FBQ2lMLFdBQVYsR0FBd0JELGFBQWEsQ0FBQ0MsV0FBdEM7QUFDQWpMLDZCQUFTLENBQUN1TCxXQUFWLEdBQXdCUCxhQUFhLENBQUNPLFdBQXRDO0FBQ0F2TCw2QkFBUyxDQUFDd0wscUJBQVYsR0FBa0NSLGFBQWEsQ0FBQ1EscUJBQWhEO0FBQ0F4TCw2QkFBUyxDQUFDeUwsZ0JBQVYsR0FBNkJULGFBQWEsQ0FBQ1MsZ0JBQTNDO0FBQ0F6TCw2QkFBUyxDQUFDMEwsY0FBVixHQUEyQlYsYUFBYSxDQUFDVSxjQUF6QztBQUNBMUwsNkJBQVMsQ0FBQ00sVUFBVixHQUF1QjBLLGFBQWEsQ0FBQzFLLFVBQXJDO0FBQ0FOLDZCQUFTLENBQUMyTCxlQUFWLEdBQTRCM0wsU0FBUyxDQUFDc0wsZ0JBQXRDLENBaEJjLENBaUJkO0FBQ0E7QUFDQTtBQUNILG1CQXBCRCxNQW9CTztBQUNIN00sMkJBQU8sQ0FBQ0MsR0FBUixDQUFZLGlCQUFaO0FBQ0gsbUJBbENTLENBb0NWOzs7QUFDQWdJLGdDQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUMwQyxvQ0FBZ0IsRUFBRXBHLFNBQVMsQ0FBQ29HO0FBQTdCLG1CQUFwQixFQUFvRWlELE1BQXBFLEdBQTZFQyxTQUE3RSxDQUF1RjtBQUFDQyx3QkFBSSxFQUFDdko7QUFBTixtQkFBdkYsRUFyQ1UsQ0FzQ1Y7O0FBQ0E2RywrQkFBYSxDQUFDc0IsTUFBZCxDQUFxQjtBQUNqQnZKLDJCQUFPLEVBQUVvQixTQUFTLENBQUNwQixPQURGO0FBRWpCZ04scUNBQWlCLEVBQUUsQ0FGRjtBQUdqQjVDLGdDQUFZLEVBQUVoSixTQUFTLENBQUNnSixZQUhQO0FBSWpCM0osd0JBQUksRUFBRSxLQUpXO0FBS2pCMkUsMEJBQU0sRUFBRWdELFNBQVMsQ0FBQ2hELE1BTEQ7QUFNakI2SCw4QkFBVSxFQUFFN0UsU0FBUyxDQUFDakc7QUFOTCxtQkFBckIsRUF2Q1UsQ0FnRFY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBO0FBQ0gsaUJBL0RELE1BZ0VJO0FBQ0Esc0JBQUlpSyxhQUFhLEdBQUc3RSxZQUFZLENBQUNzRSxRQUFRLENBQUNyRSxnQkFBVixDQUFoQzs7QUFDQSxzQkFBSTRFLGFBQUosRUFBa0I7QUFDZCx3QkFBSUEsYUFBYSxDQUFDQyxXQUFkLEtBQThCLENBQUNSLFFBQVEsQ0FBQ1EsV0FBVixJQUF5QkQsYUFBYSxDQUFDQyxXQUFkLENBQTBCbEksUUFBMUIsS0FBdUMwSCxRQUFRLENBQUNRLFdBQVQsQ0FBcUJsSSxRQUFuSCxDQUFKLEVBQ0kvQyxTQUFTLENBQUNrTCxXQUFWLEdBQXlCcEksc0JBQXNCLENBQUNrSSxhQUFhLENBQUNDLFdBQWQsQ0FBMEJsSSxRQUEzQixDQUEvQztBQUNKL0MsNkJBQVMsQ0FBQ21MLE1BQVYsR0FBbUJILGFBQWEsQ0FBQ0csTUFBakM7QUFDQW5MLDZCQUFTLENBQUN1RixNQUFWLEdBQW1CeUYsYUFBYSxDQUFDekYsTUFBakM7QUFDQXZGLDZCQUFTLENBQUNxTCxNQUFWLEdBQW1CTCxhQUFhLENBQUNLLE1BQWpDO0FBQ0FyTCw2QkFBUyxDQUFDc0wsZ0JBQVYsR0FBNkJOLGFBQWEsQ0FBQ00sZ0JBQTNDO0FBQ0F0TCw2QkFBUyxDQUFDaUwsV0FBVixHQUF3QkQsYUFBYSxDQUFDQyxXQUF0QztBQUNBakwsNkJBQVMsQ0FBQ3VMLFdBQVYsR0FBd0JQLGFBQWEsQ0FBQ08sV0FBdEM7QUFDQXZMLDZCQUFTLENBQUN3TCxxQkFBVixHQUFrQ1IsYUFBYSxDQUFDUSxxQkFBaEQ7QUFDQXhMLDZCQUFTLENBQUN5TCxnQkFBVixHQUE2QlQsYUFBYSxDQUFDUyxnQkFBM0M7QUFDQXpMLDZCQUFTLENBQUMwTCxjQUFWLEdBQTJCVixhQUFhLENBQUNVLGNBQXpDO0FBQ0ExTCw2QkFBUyxDQUFDTSxVQUFWLEdBQXVCMEssYUFBYSxDQUFDMUssVUFBckMsQ0FaYyxDQWNkOztBQUVBLHdCQUFJMEQsTUFBTSxHQUFHLEVBQVQsSUFBZSxDQUFuQixFQUFxQjtBQUNqQiwwQkFBRztBQUNDLDRCQUFJakYsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0MsR0FBRyxHQUFHLHNCQUFOLEdBQTZCbU0sUUFBUSxDQUFDckssaUJBQXRDLEdBQXdELGVBQXhELEdBQXdFcUssUUFBUSxDQUFDdEssZ0JBQTFGLENBQWY7O0FBRUEsNEJBQUlwQixRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0IsOEJBQUl1TixjQUFjLEdBQUc5TSxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBbEQ7O0FBQ0EsOEJBQUkyTSxjQUFjLENBQUN0TCxNQUFuQixFQUEwQjtBQUN0QlIscUNBQVMsQ0FBQzJMLGVBQVYsR0FBNEJsTCxVQUFVLENBQUNxTCxjQUFjLENBQUN0TCxNQUFoQixDQUFWLEdBQWtDQyxVQUFVLENBQUNULFNBQVMsQ0FBQ3NMLGdCQUFYLENBQXhFO0FBQ0g7QUFDSjtBQUNKLHVCQVRELENBVUEsT0FBTTlNLENBQU4sRUFBUSxDQUNKO0FBQ0g7QUFDSjs7QUFFRGtJLGtDQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUMwQyxzQ0FBZ0IsRUFBRXFFLFFBQVEsQ0FBQ3JFO0FBQTVCLHFCQUFwQixFQUFtRWtELFNBQW5FLENBQTZFO0FBQUNDLDBCQUFJLEVBQUN2SjtBQUFOLHFCQUE3RSxFQWhDYyxDQWlDZDtBQUNBO0FBQ0gsbUJBbkNELE1BbUNRO0FBQ0p2QiwyQkFBTyxDQUFDQyxHQUFSLENBQVksaUJBQVo7QUFDSDs7QUFDRCxzQkFBSXFOLGVBQWUsR0FBRzVKLGtCQUFrQixDQUFDbEMsT0FBbkIsQ0FBMkI7QUFBQ3JCLDJCQUFPLEVBQUNvQixTQUFTLENBQUNwQjtBQUFuQixtQkFBM0IsRUFBd0Q7QUFBQ29GLDBCQUFNLEVBQUMsQ0FBQyxDQUFUO0FBQVk0Qix5QkFBSyxFQUFDO0FBQWxCLG1CQUF4RCxDQUF0Qjs7QUFFQSxzQkFBSW1HLGVBQUosRUFBb0I7QUFDaEIsd0JBQUlBLGVBQWUsQ0FBQy9DLFlBQWhCLElBQWdDaEosU0FBUyxDQUFDZ0osWUFBOUMsRUFBMkQ7QUFDdkQsMEJBQUlnRCxVQUFVLEdBQUlELGVBQWUsQ0FBQy9DLFlBQWhCLEdBQStCaEosU0FBUyxDQUFDZ0osWUFBMUMsR0FBd0QsTUFBeEQsR0FBK0QsSUFBaEY7QUFDQSwwQkFBSWlELFVBQVUsR0FBRztBQUNick4sK0JBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCLE9BRE47QUFFYmdOLHlDQUFpQixFQUFFRyxlQUFlLENBQUMvQyxZQUZ0QjtBQUdiQSxvQ0FBWSxFQUFFaEosU0FBUyxDQUFDZ0osWUFIWDtBQUliM0osNEJBQUksRUFBRTJNLFVBSk87QUFLYmhJLDhCQUFNLEVBQUVnRCxTQUFTLENBQUNoRCxNQUxMO0FBTWI2SCxrQ0FBVSxFQUFFN0UsU0FBUyxDQUFDakc7QUFOVCx1QkFBakIsQ0FGdUQsQ0FVdkQ7QUFDQTs7QUFDQThGLG1DQUFhLENBQUNzQixNQUFkLENBQXFCOEQsVUFBckI7QUFDSDtBQUNKO0FBRUosaUJBbElrQyxDQXFJbkM7OztBQUVBeEYsNkJBQWEsQ0FBQ3VDLFlBQWQsSUFBOEJoSixTQUFTLENBQUNnSixZQUF4QztBQUNILGVBM0lpQixDQTZJbEI7OztBQUVBLGtCQUFJdEcsY0FBYyxHQUFHWCxhQUFhLENBQUM5QixPQUFkLENBQXNCO0FBQUNzSSw0QkFBWSxFQUFDdkUsTUFBTSxHQUFDO0FBQXJCLGVBQXRCLENBQXJCOztBQUVBLGtCQUFJdEIsY0FBSixFQUFtQjtBQUNmLG9CQUFJd0osaUJBQWlCLEdBQUd6SixvQkFBb0IsQ0FBQ0MsY0FBYyxDQUFDQyxVQUFoQixFQUE0QkEsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQTlDLENBQTVDOztBQUVBLHFCQUFLd0osQ0FBTCxJQUFVRCxpQkFBVixFQUE0QjtBQUN4QnJGLCtCQUFhLENBQUNzQixNQUFkLENBQXFCO0FBQ2pCdkosMkJBQU8sRUFBRXNOLGlCQUFpQixDQUFDQyxDQUFELENBQWpCLENBQXFCdk4sT0FEYjtBQUVqQmdOLHFDQUFpQixFQUFFTSxpQkFBaUIsQ0FBQ0MsQ0FBRCxDQUFqQixDQUFxQm5ELFlBRnZCO0FBR2pCQSxnQ0FBWSxFQUFFLENBSEc7QUFJakIzSix3QkFBSSxFQUFFLFFBSlc7QUFLakIyRSwwQkFBTSxFQUFFZ0QsU0FBUyxDQUFDaEQsTUFMRDtBQU1qQjZILDhCQUFVLEVBQUU3RSxTQUFTLENBQUNqRztBQU5MLG1CQUFyQjtBQVFIO0FBQ0o7QUFFSixhQWpVMEIsQ0FvVTNCOzs7QUFDQSxnQkFBSWlELE1BQU0sR0FBRyxLQUFULElBQWtCLENBQXRCLEVBQXdCO0FBQ3BCLGtCQUFJO0FBQ0F2Rix1QkFBTyxDQUFDQyxHQUFSLENBQVksdUNBQVo7QUFDQSxvQkFBSTBOLFlBQVksR0FBRyxFQUFuQjtBQUNBbk8sMEJBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0I7QUFBQzJJLHdCQUFNLEVBQUU7QUFBQ2pHLG9DQUFnQixFQUFFLENBQW5CO0FBQXNCYiwwQkFBTSxFQUFFO0FBQTlCO0FBQVQsaUJBQXBCLEVBQ00zRSxPQUROLENBQ2U3QyxDQUFELElBQU9xTyxZQUFZLENBQUNyTyxDQUFDLENBQUNxSSxnQkFBSCxDQUFaLEdBQW1DckksQ0FBQyxDQUFDd0gsTUFEMUQ7QUFFQWUsc0JBQU0sQ0FBQ0MsSUFBUCxDQUFZSixZQUFaLEVBQTBCdkYsT0FBMUIsQ0FBbUMwTCxTQUFELElBQWU7QUFDN0Msc0JBQUl0QixhQUFhLEdBQUc3RSxZQUFZLENBQUNtRyxTQUFELENBQWhDLENBRDZDLENBRTdDOztBQUNBLHNCQUFJdEIsYUFBYSxDQUFDekYsTUFBZCxLQUF5QixDQUE3QixFQUNJOztBQUVKLHNCQUFJNkcsWUFBWSxDQUFDRSxTQUFELENBQVosSUFBMkJDLFNBQS9CLEVBQTBDO0FBQ3RDOU4sMkJBQU8sQ0FBQ0MsR0FBUiwyQ0FBK0M0TixTQUEvQztBQUVBdEIsaUNBQWEsQ0FBQ04sT0FBZCxHQUF3QjtBQUNwQiw4QkFBUywwQkFEVztBQUVwQiwrQkFBUzlNLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QnFHLFNBQTlCO0FBRlcscUJBQXhCO0FBSUF0QixpQ0FBYSxDQUFDcE0sT0FBZCxHQUF3QjJELFVBQVUsQ0FBQ3lJLGFBQWEsQ0FBQ04sT0FBZixDQUFsQztBQUNBTSxpQ0FBYSxDQUFDNUssaUJBQWQsR0FBa0N4QyxNQUFNLENBQUNxSSxJQUFQLENBQVksY0FBWixFQUE0QitFLGFBQWEsQ0FBQzdLLGdCQUExQyxDQUFsQztBQUVBNkssaUNBQWEsQ0FBQ0wsTUFBZCxHQUF1Qi9NLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QitFLGFBQWEsQ0FBQ04sT0FBNUMsRUFBcUQ5TSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QitGLGtCQUE1RSxDQUF2QjtBQUNBSSxpQ0FBYSxDQUFDSCxlQUFkLEdBQWdDak4sTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCK0UsYUFBYSxDQUFDTixPQUE1QyxFQUFxRDlNLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCaUcsa0JBQTVFLENBQWhDO0FBQ0FyTSwyQkFBTyxDQUFDQyxHQUFSLENBQVlNLElBQUksQ0FBQ21FLFNBQUwsQ0FBZTZILGFBQWYsQ0FBWjtBQUNBdEUsa0NBQWMsQ0FBQ2hELElBQWYsQ0FBb0I7QUFBQzBDLHNDQUFnQixFQUFFa0c7QUFBbkIscUJBQXBCLEVBQW1EakQsTUFBbkQsR0FBNERDLFNBQTVELENBQXNFO0FBQUNDLDBCQUFJLEVBQUN5QjtBQUFOLHFCQUF0RTtBQUNILG1CQWRELE1BY08sSUFBSW9CLFlBQVksQ0FBQ0UsU0FBRCxDQUFaLElBQTJCLENBQS9CLEVBQWtDO0FBQ3JDNUYsa0NBQWMsQ0FBQ2hELElBQWYsQ0FBb0I7QUFBQzBDLHNDQUFnQixFQUFFa0c7QUFBbkIscUJBQXBCLEVBQW1EakQsTUFBbkQsR0FBNERDLFNBQTVELENBQXNFO0FBQUNDLDBCQUFJLEVBQUN5QjtBQUFOLHFCQUF0RTtBQUNIO0FBQ0osaUJBdkJEO0FBd0JILGVBN0JELENBNkJFLE9BQU94TSxDQUFQLEVBQVM7QUFDUEMsdUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixhQXRXMEIsQ0F3VzNCOzs7QUFDQSxnQkFBSXdGLE1BQU0sR0FBRyxLQUFULElBQWtCLENBQXRCLEVBQXdCO0FBQ3BCdkYscUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHFCQUFaO0FBQ0FULHdCQUFVLENBQUN5RixJQUFYLENBQWdCLEVBQWhCLEVBQW9COUMsT0FBcEIsQ0FBNkJaLFNBQUQsSUFBZTtBQUN2QyxvQkFBSTtBQUNBLHNCQUFJd00sVUFBVSxHQUFJMUosc0JBQXNCLENBQUM5QyxTQUFTLENBQUNpTCxXQUFWLENBQXNCbEksUUFBdkIsQ0FBeEM7O0FBQ0Esc0JBQUl5SixVQUFKLEVBQWdCO0FBQ1o5RixrQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDOUUsNkJBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCO0FBQXBCLHFCQUFwQixFQUNNeUssTUFETixHQUNlQyxTQURmLENBQ3lCO0FBQUNDLDBCQUFJLEVBQUM7QUFBQyx1Q0FBY2lEO0FBQWY7QUFBTixxQkFEekI7QUFFSDtBQUNKLGlCQU5ELENBTUUsT0FBT2hPLENBQVAsRUFBVTtBQUNSQyx5QkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLGVBVkQ7QUFXSDs7QUFFRCxnQkFBSWlPLHlCQUF5QixHQUFHLElBQUl6TCxJQUFKLEVBQWhDO0FBQ0F2QyxtQkFBTyxDQUFDQyxHQUFSLENBQVksK0JBQThCLENBQUMrTix5QkFBeUIsR0FBQ2xDLDJCQUEzQixJQUF3RCxJQUF0RixHQUE0RixVQUF4RyxFQXpYMkIsQ0EyWDNCOztBQUNBLGdCQUFJbUMsdUJBQXVCLEdBQUcsSUFBSTFMLElBQUosRUFBOUI7QUFDQWlCLHFCQUFTLENBQUNrRyxNQUFWLENBQWlCMUIsYUFBakI7QUFDQSxnQkFBSWtHLHNCQUFzQixHQUFHLElBQUkzTCxJQUFKLEVBQTdCO0FBQ0F2QyxtQkFBTyxDQUFDQyxHQUFSLENBQVksNEJBQTJCLENBQUNpTyxzQkFBc0IsR0FBQ0QsdUJBQXhCLElBQWlELElBQTVFLEdBQWtGLFVBQTlGO0FBRUEsZ0JBQUlFLFlBQVksR0FBRyxJQUFJNUwsSUFBSixFQUFuQjs7QUFDQSxnQkFBSTBGLGNBQWMsQ0FBQy9HLE1BQWYsR0FBd0IsQ0FBNUIsRUFBOEI7QUFDMUI7QUFDQStHLDRCQUFjLENBQUNtRyxPQUFmLENBQXVCLENBQUM1RSxHQUFELEVBQU05SSxNQUFOLEtBQWlCO0FBQ3BDLG9CQUFJOEksR0FBSixFQUFRO0FBQ0p4Six5QkFBTyxDQUFDQyxHQUFSLENBQVl1SixHQUFaO0FBQ0g7O0FBQ0Qsb0JBQUk5SSxNQUFKLEVBQVcsQ0FDUDtBQUNIO0FBQ0osZUFQRDtBQVFIOztBQUVELGdCQUFJMk4sVUFBVSxHQUFHLElBQUk5TCxJQUFKLEVBQWpCO0FBQ0F2QyxtQkFBTyxDQUFDQyxHQUFSLENBQVksNEJBQTJCLENBQUNvTyxVQUFVLEdBQUNGLFlBQVosSUFBMEIsSUFBckQsR0FBMkQsVUFBdkU7QUFFQSxnQkFBSUcsV0FBVyxHQUFHLElBQUkvTCxJQUFKLEVBQWxCOztBQUNBLGdCQUFJNEYsb0JBQW9CLENBQUNqSCxNQUFyQixHQUE4QixDQUFsQyxFQUFvQztBQUNoQ2lILGtDQUFvQixDQUFDaUcsT0FBckIsQ0FBNkIsQ0FBQzVFLEdBQUQsRUFBTTlJLE1BQU4sS0FBaUI7QUFDMUMsb0JBQUk4SSxHQUFKLEVBQVE7QUFDSnhKLHlCQUFPLENBQUNDLEdBQVIsQ0FBWXVKLEdBQVo7QUFDSDtBQUNKLGVBSkQ7QUFLSDs7QUFFRCxnQkFBSStFLFNBQVMsR0FBRyxJQUFJaE0sSUFBSixFQUFoQjtBQUNBdkMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLG9DQUFtQyxDQUFDc08sU0FBUyxHQUFDRCxXQUFYLElBQXdCLElBQTNELEdBQWlFLFVBQTdFOztBQUVBLGdCQUFJbEcsYUFBYSxDQUFDbEgsTUFBZCxHQUF1QixDQUEzQixFQUE2QjtBQUN6QmtILDJCQUFhLENBQUNnRyxPQUFkLENBQXNCLENBQUM1RSxHQUFELEVBQU05SSxNQUFOLEtBQWlCO0FBQ25DLG9CQUFJOEksR0FBSixFQUFRO0FBQ0p4Six5QkFBTyxDQUFDQyxHQUFSLENBQVl1SixHQUFaO0FBQ0g7QUFDSixlQUpEO0FBS0g7O0FBRUQsZ0JBQUluQixlQUFlLENBQUNuSCxNQUFoQixHQUF5QixDQUE3QixFQUErQjtBQUMzQm1ILDZCQUFlLENBQUMrRixPQUFoQixDQUF3QixDQUFDNUUsR0FBRCxFQUFNOUksTUFBTixLQUFpQjtBQUNyQyxvQkFBSThJLEdBQUosRUFBUTtBQUNKeEoseUJBQU8sQ0FBQ0MsR0FBUixDQUFZdUosR0FBWjtBQUNIO0FBQ0osZUFKRDtBQUtILGFBM2EwQixDQTZhM0I7OztBQUVBLGdCQUFJakUsTUFBTSxHQUFHLEVBQVQsSUFBZSxDQUFuQixFQUFxQjtBQUNqQnZGLHFCQUFPLENBQUNDLEdBQVIsQ0FBWSxpREFBWjtBQUNBLGtCQUFJdU8sZ0JBQWdCLEdBQUdoUCxVQUFVLENBQUN5RixJQUFYLENBQWdCO0FBQUM2QixzQkFBTSxFQUFDLENBQVI7QUFBVTRGLHNCQUFNLEVBQUM7QUFBakIsZUFBaEIsRUFBd0M7QUFBQ3hGLG9CQUFJLEVBQUM7QUFBQ3FELDhCQUFZLEVBQUMsQ0FBQztBQUFmO0FBQU4sZUFBeEMsRUFBa0VwRixLQUFsRSxFQUF2QjtBQUNBLGtCQUFJc0osWUFBWSxHQUFHakQsSUFBSSxDQUFDa0QsSUFBTCxDQUFVRixnQkFBZ0IsQ0FBQ3ROLE1BQWpCLEdBQXdCLEdBQWxDLENBQW5CO0FBQ0Esa0JBQUl5TixlQUFlLEdBQUdILGdCQUFnQixDQUFDdE4sTUFBakIsR0FBMEJ1TixZQUFoRDtBQUVBLGtCQUFJRyxjQUFjLEdBQUcsQ0FBckI7QUFDQSxrQkFBSUMsaUJBQWlCLEdBQUcsQ0FBeEI7QUFFQSxrQkFBSUMsZ0JBQWdCLEdBQUcsQ0FBdkI7QUFDQSxrQkFBSUMsaUJBQWlCLEdBQUcsQ0FBeEI7QUFDQSxrQkFBSUMsb0JBQW9CLEdBQUcsQ0FBM0I7QUFDQSxrQkFBSUMscUJBQXFCLEdBQUcsQ0FBNUI7O0FBSUEsbUJBQUszUCxDQUFMLElBQVVrUCxnQkFBVixFQUEyQjtBQUN2QixvQkFBSWxQLENBQUMsR0FBR21QLFlBQVIsRUFBcUI7QUFDakJHLGdDQUFjLElBQUlKLGdCQUFnQixDQUFDbFAsQ0FBRCxDQUFoQixDQUFvQmlMLFlBQXRDO0FBQ0gsaUJBRkQsTUFHSTtBQUNBc0UsbUNBQWlCLElBQUlMLGdCQUFnQixDQUFDbFAsQ0FBRCxDQUFoQixDQUFvQmlMLFlBQXpDO0FBQ0g7O0FBR0Qsb0JBQUl5RSxvQkFBb0IsR0FBRyxJQUEzQixFQUFnQztBQUM1QkEsc0NBQW9CLElBQUlSLGdCQUFnQixDQUFDbFAsQ0FBRCxDQUFoQixDQUFvQmlMLFlBQXBCLEdBQW1DdkMsYUFBYSxDQUFDdUMsWUFBekU7QUFDQXVFLGtDQUFnQjtBQUNuQjtBQUNKOztBQUVERyxtQ0FBcUIsR0FBRyxJQUFJRCxvQkFBNUI7QUFDQUQsK0JBQWlCLEdBQUdQLGdCQUFnQixDQUFDdE4sTUFBakIsR0FBMEI0TixnQkFBOUM7QUFFQSxrQkFBSUksTUFBTSxHQUFHO0FBQ1QzSixzQkFBTSxFQUFFQSxNQURDO0FBRVRrSiw0QkFBWSxFQUFFQSxZQUZMO0FBR1RHLDhCQUFjLEVBQUVBLGNBSFA7QUFJVEQsK0JBQWUsRUFBRUEsZUFKUjtBQUtURSxpQ0FBaUIsRUFBRUEsaUJBTFY7QUFNVEMsZ0NBQWdCLEVBQUVBLGdCQU5UO0FBT1RFLG9DQUFvQixFQUFFQSxvQkFQYjtBQVFURCxpQ0FBaUIsRUFBRUEsaUJBUlY7QUFTVEUscUNBQXFCLEVBQUVBLHFCQVRkO0FBVVRFLDZCQUFhLEVBQUVYLGdCQUFnQixDQUFDdE4sTUFWdkI7QUFXVGtPLGdDQUFnQixFQUFFcEgsYUFBYSxDQUFDdUMsWUFYdkI7QUFZVGEseUJBQVMsRUFBRTdDLFNBQVMsQ0FBQ2pHLElBWlo7QUFhVCtNLHdCQUFRLEVBQUUsSUFBSTlNLElBQUo7QUFiRCxlQUFiO0FBZ0JBdkMscUJBQU8sQ0FBQ0MsR0FBUixDQUFZaVAsTUFBWjtBQUVBekwsNkJBQWUsQ0FBQ2lHLE1BQWhCLENBQXVCd0YsTUFBdkI7QUFDSDtBQUNKO0FBQ0osU0E5ZUQsQ0ErZUEsT0FBT25QLENBQVAsRUFBUztBQUNMQyxpQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDQXVILGlCQUFPLEdBQUcsS0FBVjtBQUNBLGlCQUFPLFNBQVA7QUFDSDs7QUFDRCxZQUFJZ0ksWUFBWSxHQUFHLElBQUkvTSxJQUFKLEVBQW5CO0FBQ0F2QyxlQUFPLENBQUNDLEdBQVIsQ0FBWSxzQkFBcUIsQ0FBQ3FQLFlBQVksR0FBQ3ZILGNBQWQsSUFBOEIsSUFBbkQsR0FBeUQsVUFBckU7QUFDSDs7QUFDRFQsYUFBTyxHQUFHLEtBQVY7QUFDQWpFLFdBQUssQ0FBQ3VJLE1BQU4sQ0FBYTtBQUFDWCxlQUFPLEVBQUM5TCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjZFO0FBQWhDLE9BQWIsRUFBdUQ7QUFBQ0gsWUFBSSxFQUFDO0FBQUN5RSw4QkFBb0IsRUFBQyxJQUFJaE4sSUFBSixFQUF0QjtBQUFrQ3FGLHlCQUFlLEVBQUNBO0FBQWxEO0FBQU4sT0FBdkQ7QUFDSDs7QUFFRCxXQUFPTCxLQUFQO0FBQ0gsR0FsbkJVO0FBbW5CWCxjQUFZLFVBQVNKLEtBQVQsRUFBZ0I7QUFDeEI7QUFDQSxXQUFRQSxLQUFLLEdBQUMsRUFBZDtBQUNILEdBdG5CVTtBQXVuQlgsYUFBVyxVQUFTQSxLQUFULEVBQWdCO0FBQ3ZCLFFBQUlBLEtBQUssR0FBR2hJLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxrQkFBWixDQUFaLEVBQTZDO0FBQ3pDLGFBQVEsS0FBUjtBQUNILEtBRkQsTUFFTztBQUNILGFBQVEsSUFBUjtBQUNIO0FBQ0o7QUE3bkJVLENBQWYsRTs7Ozs7Ozs7Ozs7QUM3REEsSUFBSXJJLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSThELFNBQUo7QUFBY2hFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQytELFdBQVMsQ0FBQzlELENBQUQsRUFBRztBQUFDOEQsYUFBUyxHQUFDOUQsQ0FBVjtBQUFZOztBQUExQixDQUEzQixFQUF1RCxDQUF2RDtBQUEwRCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJcUUsWUFBSjtBQUFpQnZFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUNzRSxjQUFZLENBQUNyRSxDQUFELEVBQUc7QUFBQ3FFLGdCQUFZLEdBQUNyRSxDQUFiO0FBQWU7O0FBQWhDLENBQWpELEVBQW1GLENBQW5GO0FBS3RQa1EsZ0JBQWdCLENBQUMsZUFBRCxFQUFrQixVQUFTckksS0FBVCxFQUFlO0FBQzdDLFNBQU87QUFDSGxDLFFBQUksR0FBRTtBQUNGLGFBQU83QixTQUFTLENBQUM2QixJQUFWLENBQWUsRUFBZixFQUFtQjtBQUFDa0MsYUFBSyxFQUFFQSxLQUFSO0FBQWVELFlBQUksRUFBRTtBQUFDM0IsZ0JBQU0sRUFBRSxDQUFDO0FBQVY7QUFBckIsT0FBbkIsQ0FBUDtBQUNILEtBSEU7O0FBSUhrSyxZQUFRLEVBQUUsQ0FDTjtBQUNJeEssVUFBSSxDQUFDSyxLQUFELEVBQU87QUFDUCxlQUFPOUYsVUFBVSxDQUFDeUYsSUFBWCxDQUNIO0FBQUM5RSxpQkFBTyxFQUFDbUYsS0FBSyxDQUFDSjtBQUFmLFNBREcsRUFFSDtBQUFDaUMsZUFBSyxFQUFDO0FBQVAsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FETTtBQUpQLEdBQVA7QUFlSCxDQWhCZSxDQUFoQjtBQWtCQXFJLGdCQUFnQixDQUFDLGdCQUFELEVBQW1CLFVBQVNqSyxNQUFULEVBQWdCO0FBQy9DLFNBQU87QUFDSE4sUUFBSSxHQUFFO0FBQ0YsYUFBTzdCLFNBQVMsQ0FBQzZCLElBQVYsQ0FBZTtBQUFDTSxjQUFNLEVBQUNBO0FBQVIsT0FBZixDQUFQO0FBQ0gsS0FIRTs7QUFJSGtLLFlBQVEsRUFBRSxDQUNOO0FBQ0l4SyxVQUFJLENBQUNLLEtBQUQsRUFBTztBQUNQLGVBQU8zQixZQUFZLENBQUNzQixJQUFiLENBQ0g7QUFBQ00sZ0JBQU0sRUFBQ0QsS0FBSyxDQUFDQztBQUFkLFNBREcsQ0FBUDtBQUdIOztBQUxMLEtBRE0sRUFRTjtBQUNJTixVQUFJLENBQUNLLEtBQUQsRUFBTztBQUNQLGVBQU85RixVQUFVLENBQUN5RixJQUFYLENBQ0g7QUFBQzlFLGlCQUFPLEVBQUNtRixLQUFLLENBQUNKO0FBQWYsU0FERyxFQUVIO0FBQUNpQyxlQUFLLEVBQUM7QUFBUCxTQUZHLENBQVA7QUFJSDs7QUFOTCxLQVJNO0FBSlAsR0FBUDtBQXNCSCxDQXZCZSxDQUFoQixDOzs7Ozs7Ozs7OztBQ3ZCQS9ILE1BQU0sQ0FBQ3NRLE1BQVAsQ0FBYztBQUFDdE0sV0FBUyxFQUFDLE1BQUlBO0FBQWYsQ0FBZDtBQUF5QyxJQUFJdU0sS0FBSjtBQUFVdlEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDc1EsT0FBSyxDQUFDclEsQ0FBRCxFQUFHO0FBQUNxUSxTQUFLLEdBQUNyUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksNkJBQVosRUFBMEM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTFDLEVBQXdFLENBQXhFO0FBRzdHLE1BQU04RCxTQUFTLEdBQUcsSUFBSXVNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixRQUFyQixDQUFsQjtBQUVQeE0sU0FBUyxDQUFDeU0sT0FBVixDQUFrQjtBQUNkQyxVQUFRLEdBQUU7QUFDTixXQUFPdFEsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDckIsYUFBTyxFQUFDLEtBQUsrRTtBQUFkLEtBQW5CLENBQVA7QUFDSDs7QUFIYSxDQUFsQixFLENBTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0I7Ozs7Ozs7Ozs7O0FDdEJBLElBQUkvRixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSXdFLFVBQUo7QUFBZTFFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUN5RSxZQUFVLENBQUN4RSxDQUFELEVBQUc7QUFBQ3dFLGNBQVUsR0FBQ3hFLENBQVg7QUFBYTs7QUFBNUIsQ0FBdkMsRUFBcUUsQ0FBckU7QUFBd0UsSUFBSStELEtBQUosRUFBVTBNLFdBQVY7QUFBc0IzUSxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNnRSxPQUFLLENBQUMvRCxDQUFELEVBQUc7QUFBQytELFNBQUssR0FBQy9ELENBQU47QUFBUSxHQUFsQjs7QUFBbUJ5USxhQUFXLENBQUN6USxDQUFELEVBQUc7QUFBQ3lRLGVBQVcsR0FBQ3pRLENBQVo7QUFBYzs7QUFBaEQsQ0FBMUIsRUFBNEUsQ0FBNUU7QUFBK0UsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBN0MsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSW9FLGtCQUFKO0FBQXVCdEUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0JBQVosRUFBNEM7QUFBQ3FFLG9CQUFrQixDQUFDcEUsQ0FBRCxFQUFHO0FBQUNvRSxzQkFBa0IsR0FBQ3BFLENBQW5CO0FBQXFCOztBQUE1QyxDQUE1QyxFQUEwRixDQUExRjs7QUFPeGEwUSxlQUFlLEdBQUcsQ0FBQ3pPLFNBQUQsRUFBWTBPLGFBQVosS0FBOEI7QUFDNUMsT0FBSyxJQUFJM1EsQ0FBVCxJQUFjMlEsYUFBZCxFQUE0QjtBQUN4QixRQUFJMU8sU0FBUyxDQUFDMEssT0FBVixDQUFrQnBMLEtBQWxCLElBQTJCb1AsYUFBYSxDQUFDM1EsQ0FBRCxDQUFiLENBQWlCMk0sT0FBakIsQ0FBeUJwTCxLQUF4RCxFQUE4RDtBQUMxRCxhQUFPa0osUUFBUSxDQUFDa0csYUFBYSxDQUFDM1EsQ0FBRCxDQUFiLENBQWlCNFEsS0FBbEIsQ0FBZjtBQUNIO0FBQ0o7QUFDSixDQU5EOztBQVFBL1EsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCw2QkFBMkIsWUFBVTtBQUNqQyxTQUFLRSxPQUFMO0FBQ0EsUUFBSVYsR0FBRyxHQUFHbUgsR0FBRyxHQUFDLHVCQUFkOztBQUNBLFFBQUc7QUFDQyxVQUFJdkcsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsVUFBSXlRLFNBQVMsR0FBRzVQLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWhCO0FBQ0EwUCxlQUFTLEdBQUdBLFNBQVMsQ0FBQ3pQLE1BQXRCO0FBQ0EsVUFBSTZFLE1BQU0sR0FBRzRLLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQjdLLE1BQW5DO0FBQ0EsVUFBSThLLEtBQUssR0FBR0YsU0FBUyxDQUFDQyxXQUFWLENBQXNCQyxLQUFsQztBQUNBLFVBQUlDLElBQUksR0FBR0gsU0FBUyxDQUFDQyxXQUFWLENBQXNCRSxJQUFqQztBQUNBLFVBQUlDLFVBQVUsR0FBRy9FLElBQUksQ0FBQzZFLEtBQUwsQ0FBV3JPLFVBQVUsQ0FBQ21PLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQkksS0FBdEIsQ0FBNEJILEtBQTVCLEVBQW1DSSxrQkFBbkMsQ0FBc0RDLEtBQXRELENBQTRELEdBQTVELEVBQWlFLENBQWpFLENBQUQsQ0FBVixHQUFnRixHQUEzRixDQUFqQjtBQUVBck4sV0FBSyxDQUFDdUksTUFBTixDQUFhO0FBQUNYLGVBQU8sRUFBQzlMLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNkU7QUFBaEMsT0FBYixFQUF1RDtBQUFDSCxZQUFJLEVBQUM7QUFDekQ2RixzQkFBWSxFQUFFcEwsTUFEMkM7QUFFekRxTCxxQkFBVyxFQUFFUCxLQUY0QztBQUd6RFEsb0JBQVUsRUFBRVAsSUFINkM7QUFJekRDLG9CQUFVLEVBQUVBLFVBSjZDO0FBS3pEckwseUJBQWUsRUFBRWlMLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQmxNLFVBQXRCLENBQWlDNEwsUUFBakMsQ0FBMEMzUCxPQUxGO0FBTXpEMlEsa0JBQVEsRUFBRVgsU0FBUyxDQUFDQyxXQUFWLENBQXNCSSxLQUF0QixDQUE0QkgsS0FBNUIsRUFBbUNTLFFBTlk7QUFPekQ5SCxvQkFBVSxFQUFFbUgsU0FBUyxDQUFDQyxXQUFWLENBQXNCSSxLQUF0QixDQUE0QkgsS0FBNUIsRUFBbUNySDtBQVBVO0FBQU4sT0FBdkQ7QUFTSCxLQWxCRCxDQW1CQSxPQUFNakosQ0FBTixFQUFRO0FBQ0pDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixHQTFCVTtBQTJCWCx3QkFBc0IsWUFBVTtBQUM1QixTQUFLSyxPQUFMO0FBQ0EsUUFBSVYsR0FBRyxHQUFHbUgsR0FBRyxHQUFDLFNBQWQ7O0FBQ0EsUUFBRztBQUNDLFVBQUl2RyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxVQUFJb0gsTUFBTSxHQUFHdkcsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBYjtBQUNBcUcsWUFBTSxHQUFHQSxNQUFNLENBQUNwRyxNQUFoQjtBQUNBLFVBQUlxUSxLQUFLLEdBQUcsRUFBWjtBQUNBQSxXQUFLLENBQUM5RixPQUFOLEdBQWdCbkUsTUFBTSxDQUFDa0ssU0FBUCxDQUFpQkMsT0FBakM7QUFDQUYsV0FBSyxDQUFDRyxpQkFBTixHQUEwQnBLLE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQkMsbUJBQTNDO0FBQ0ErSixXQUFLLENBQUNJLGVBQU4sR0FBd0JySyxNQUFNLENBQUNDLFNBQVAsQ0FBaUJxSyxpQkFBekM7QUFFQSxVQUFJQyxXQUFXLEdBQUd0QixXQUFXLENBQUN2TyxPQUFaLENBQW9CLEVBQXBCLEVBQXdCO0FBQUMwRixZQUFJLEVBQUU7QUFBQzNCLGdCQUFNLEVBQUUsQ0FBQztBQUFWO0FBQVAsT0FBeEIsQ0FBbEI7O0FBQ0EsVUFBSThMLFdBQVcsSUFBSUEsV0FBVyxDQUFDOUwsTUFBWixJQUFzQndMLEtBQUssQ0FBQ0csaUJBQS9DLEVBQWtFO0FBQzlELG1EQUFvQ0gsS0FBSyxDQUFDRyxpQkFBMUMsdUJBQXdFRyxXQUFXLENBQUM5TCxNQUFwRjtBQUNIOztBQUVEN0YsU0FBRyxHQUFHbUgsR0FBRyxHQUFDLGFBQVY7QUFDQXZHLGNBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLFVBQUl3RSxVQUFVLEdBQUczRCxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFqQjtBQUNBeUQsZ0JBQVUsR0FBR0EsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQS9CO0FBQ0E2TSxXQUFLLENBQUM3TSxVQUFOLEdBQW1CQSxVQUFVLENBQUNoRCxNQUE5QjtBQUNBLFVBQUlvUSxRQUFRLEdBQUcsQ0FBZjs7QUFDQSxXQUFLaFMsQ0FBTCxJQUFVNEUsVUFBVixFQUFxQjtBQUNqQm9OLGdCQUFRLElBQUl2SCxRQUFRLENBQUM3RixVQUFVLENBQUM1RSxDQUFELENBQVYsQ0FBY2lMLFlBQWYsQ0FBcEI7QUFDSDs7QUFDRHdHLFdBQUssQ0FBQ1EsaUJBQU4sR0FBMEJELFFBQTFCO0FBR0FqTyxXQUFLLENBQUN1SSxNQUFOLENBQWE7QUFBQ1gsZUFBTyxFQUFDOEYsS0FBSyxDQUFDOUY7QUFBZixPQUFiLEVBQXNDO0FBQUNILFlBQUksRUFBQ2lHO0FBQU4sT0FBdEMsRUFBb0Q7QUFBQ25HLGNBQU0sRUFBRTtBQUFULE9BQXBELEVBMUJELENBMkJDOztBQUNBLFVBQUliLFFBQVEsQ0FBQ2dILEtBQUssQ0FBQ0csaUJBQVAsQ0FBUixHQUFvQyxDQUF4QyxFQUEwQztBQUN0QyxZQUFJTSxXQUFXLEdBQUcsRUFBbEI7QUFDQUEsbUJBQVcsQ0FBQ2pNLE1BQVosR0FBcUJ3RSxRQUFRLENBQUNqRCxNQUFNLENBQUNDLFNBQVAsQ0FBaUJDLG1CQUFsQixDQUE3QjtBQUNBd0ssbUJBQVcsQ0FBQ2xQLElBQVosR0FBbUIsSUFBSUMsSUFBSixDQUFTdUUsTUFBTSxDQUFDQyxTQUFQLENBQWlCcUssaUJBQTFCLENBQW5CO0FBRUExUixXQUFHLEdBQUdHLEdBQUcsR0FBRyxlQUFaOztBQUNBLFlBQUc7QUFDQ1Msa0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLGNBQUkrUixPQUFPLEdBQUdsUixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBM0MsQ0FGRCxDQUdDO0FBQ0E7O0FBQ0E4USxxQkFBVyxDQUFDRSxZQUFaLEdBQTJCM0gsUUFBUSxDQUFDMEgsT0FBTyxDQUFDRSxhQUFULENBQW5DO0FBQ0FILHFCQUFXLENBQUNJLGVBQVosR0FBOEI3SCxRQUFRLENBQUMwSCxPQUFPLENBQUNJLGlCQUFULENBQXRDO0FBQ0gsU0FQRCxDQVFBLE9BQU05UixDQUFOLEVBQVE7QUFDSkMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBRURMLFdBQUcsR0FBR0csR0FBRyxHQUFHLGdCQUFOLEdBQXVCVixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjBMLFlBQXBEOztBQUNBLFlBQUc7QUFDQ3hSLGtCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQSxjQUFJcVMsTUFBTSxHQUFHeFIsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTFDO0FBQ0E4USxxQkFBVyxDQUFDUSxXQUFaLEdBQTBCakksUUFBUSxDQUFDZ0ksTUFBRCxDQUFsQztBQUNILFNBSkQsQ0FLQSxPQUFNaFMsQ0FBTixFQUFRO0FBQ0pDLGlCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUVETCxXQUFHLEdBQUdHLEdBQUcsR0FBRyw4QkFBWjs7QUFDQSxZQUFJO0FBQ0FTLGtCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQSxjQUFJdVMsSUFBSSxHQUFHMVIsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQXhDOztBQUNBLGNBQUl1UixJQUFJLElBQUlBLElBQUksQ0FBQy9RLE1BQUwsR0FBYyxDQUExQixFQUE0QjtBQUN4QnNRLHVCQUFXLENBQUNVLGFBQVosR0FBNEIsRUFBNUI7QUFDQUQsZ0JBQUksQ0FBQzlQLE9BQUwsQ0FBYSxDQUFDZ1EsTUFBRCxFQUFTdFAsQ0FBVCxLQUFlO0FBQ3hCMk8seUJBQVcsQ0FBQ1UsYUFBWixDQUEwQi9JLElBQTFCLENBQStCO0FBQzNCaUoscUJBQUssRUFBRUQsTUFBTSxDQUFDQyxLQURhO0FBRTNCRCxzQkFBTSxFQUFFblEsVUFBVSxDQUFDbVEsTUFBTSxDQUFDQSxNQUFSO0FBRlMsZUFBL0I7QUFJSCxhQUxEO0FBTUg7QUFDSixTQVpELENBYUEsT0FBT3BTLENBQVAsRUFBUztBQUNMQyxpQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFFREwsV0FBRyxHQUFHRyxHQUFHLEdBQUcsb0JBQVo7O0FBQ0EsWUFBRztBQUNDUyxrQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0EsY0FBSTJTLFNBQVMsR0FBRzlSLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE3Qzs7QUFDQSxjQUFJMlIsU0FBSixFQUFjO0FBQ1ZiLHVCQUFXLENBQUNhLFNBQVosR0FBd0JyUSxVQUFVLENBQUNxUSxTQUFELENBQWxDO0FBQ0g7QUFDSixTQU5ELENBT0EsT0FBTXRTLENBQU4sRUFBUTtBQUNKQyxpQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFFREwsV0FBRyxHQUFHRyxHQUFHLEdBQUcsNEJBQVo7O0FBQ0EsWUFBRztBQUNDUyxrQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0EsY0FBSTRTLFVBQVUsR0FBRy9SLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWpCOztBQUNBLGNBQUk2UixVQUFKLEVBQWU7QUFDWGQsdUJBQVcsQ0FBQ2UsZ0JBQVosR0FBK0J2USxVQUFVLENBQUNzUSxVQUFVLENBQUM1UixNQUFaLENBQXpDO0FBQ0g7QUFDSixTQU5ELENBT0EsT0FBTVgsQ0FBTixFQUFRO0FBQ0pDLGlCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUVEZ1EsbUJBQVcsQ0FBQ3JHLE1BQVosQ0FBbUI4SCxXQUFuQjtBQUNILE9BbkdGLENBcUdDO0FBRUE7QUFDQTs7O0FBQ0EsYUFBT1QsS0FBSyxDQUFDRyxpQkFBYjtBQUNILEtBMUdELENBMkdBLE9BQU9uUixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDQSxhQUFPLDZCQUFQO0FBQ0g7QUFDSixHQTdJVTtBQThJWCwyQkFBeUIsWUFBVTtBQUMvQnNELFNBQUssQ0FBQzRCLElBQU4sR0FBYWlDLElBQWIsQ0FBa0I7QUFBQ3NMLGFBQU8sRUFBQyxDQUFDO0FBQVYsS0FBbEIsRUFBZ0NyTCxLQUFoQyxDQUFzQyxDQUF0QztBQUNILEdBaEpVO0FBaUpYLG1CQUFpQixZQUFVO0FBQ3ZCLFFBQUk0SixLQUFLLEdBQUcxTixLQUFLLENBQUM3QixPQUFOLENBQWM7QUFBQ3lKLGFBQU8sRUFBRTlMLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNkU7QUFBakMsS0FBZCxDQUFaOztBQUVBLFFBQUk4RixLQUFLLElBQUlBLEtBQUssQ0FBQzBCLFdBQW5CLEVBQStCO0FBQzNCelMsYUFBTyxDQUFDQyxHQUFSLENBQVksaUNBQVo7QUFDSCxLQUZELE1BR0ssSUFBSWQsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQnVNLEtBQWhCLENBQXNCRCxXQUExQixFQUF1QztBQUN4Q3pTLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHVDQUFaO0FBQ0EsVUFBSUssUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU1QsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQndNLFdBQXpCLENBQWY7QUFDQSxVQUFJQyxPQUFPLEdBQUdyUyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFkO0FBQ0EsVUFBSW9TLEtBQUssR0FBR0QsT0FBTyxDQUFDRSxTQUFSLENBQWtCRCxLQUFsQixJQUEyQkQsT0FBTyxDQUFDRSxTQUFSLENBQWtCQyxZQUF6RDtBQUNBLFVBQUlDLFdBQVcsR0FBRztBQUNkL0gsZUFBTyxFQUFFMkgsT0FBTyxDQUFDMUgsUUFESDtBQUVkK0gsbUJBQVcsRUFBRUwsT0FBTyxDQUFDTSxZQUZQO0FBR2RDLHVCQUFlLEVBQUVQLE9BQU8sQ0FBQ1EsZ0JBSFg7QUFJZEMsWUFBSSxFQUFFVCxPQUFPLENBQUNFLFNBQVIsQ0FBa0JPLElBSlY7QUFLZEMsWUFBSSxFQUFFVixPQUFPLENBQUNFLFNBQVIsQ0FBa0JRLElBTFY7QUFNZEMsZUFBTyxFQUFFO0FBQ0x0QixjQUFJLEVBQUVXLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEJ0QixJQUQzQjtBQUVMNUssZ0JBQU0sRUFBRXVMLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEJsTTtBQUY3QixTQU5LO0FBVWRtTSxZQUFJLEVBQUVaLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlUsSUFWVjtBQVdkWCxhQUFLLEVBQUU7QUFDSFksc0JBQVksRUFBRVosS0FBSyxDQUFDYSxhQURqQjtBQUVIQyw0QkFBa0IsRUFBRWQsS0FBSyxDQUFDZSxvQkFGdkI7QUFHSEMsNkJBQW1CLEVBQUVoQixLQUFLLENBQUNpQixxQkFIeEI7QUFJSEMsNkJBQW1CLEVBQUVsQixLQUFLLENBQUNtQjtBQUp4QixTQVhPO0FBaUJkQyxXQUFHLEVBQUU7QUFDREMsNEJBQWtCLEVBQUUsQ0FEbkI7QUFFREMsdUJBQWEsRUFBRSxFQUZkO0FBR0RDLHNCQUFZLEVBQUUsRUFIYjtBQUlEQyxxQkFBVyxFQUFFO0FBSlosU0FqQlM7QUF1QmRDLGdCQUFRLEVBQUM7QUFDTGpOLGdCQUFNLEVBQUV1TCxPQUFPLENBQUNFLFNBQVIsQ0FBa0J3QixRQUFsQixDQUEyQmpOO0FBRDlCLFNBdkJLO0FBMEJkMEssY0FBTSxFQUFFYSxPQUFPLENBQUNFLFNBQVIsQ0FBa0JmLE1BMUJaO0FBMkJkd0MsY0FBTSxFQUFFM0IsT0FBTyxDQUFDRSxTQUFSLENBQWtCeUI7QUEzQlosT0FBbEI7O0FBOEJBLFVBQUkzQixPQUFPLENBQUNFLFNBQVIsQ0FBa0JtQixHQUF0QixFQUEyQjtBQUN2QmpCLG1CQUFXLENBQUNpQixHQUFaLEdBQWtCO0FBQ2RDLDRCQUFrQixFQUFFdEIsT0FBTyxDQUFDRSxTQUFSLENBQWtCbUIsR0FBbEIsQ0FBc0JPLG9CQUQ1QjtBQUVkTCx1QkFBYSxFQUFFdkIsT0FBTyxDQUFDRSxTQUFSLENBQWtCbUIsR0FBbEIsQ0FBc0JRLGNBRnZCO0FBR2RMLHNCQUFZLEVBQUV4QixPQUFPLENBQUNFLFNBQVIsQ0FBa0JtQixHQUFsQixDQUFzQlMsYUFIdEI7QUFJZEwscUJBQVcsRUFBRXpCLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQm1CLEdBQWxCLENBQXNCVTtBQUpyQixTQUFsQjtBQU1IOztBQUVELFVBQUl2RixnQkFBZ0IsR0FBRyxDQUF2QixDQTVDd0MsQ0E4Q3hDOztBQUNBLFVBQUl3RCxPQUFPLENBQUNFLFNBQVIsQ0FBa0I4QixPQUFsQixJQUE2QmhDLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQjhCLE9BQWxCLENBQTBCQyxNQUF2RCxJQUFrRWpDLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQjhCLE9BQWxCLENBQTBCQyxNQUExQixDQUFpQzNULE1BQWpDLEdBQTBDLENBQWhILEVBQW1IO0FBQy9HLGFBQUsyQixDQUFMLElBQVUrUCxPQUFPLENBQUNFLFNBQVIsQ0FBa0I4QixPQUFsQixDQUEwQkMsTUFBcEMsRUFBMkM7QUFDdkMsY0FBSUMsR0FBRyxHQUFHbEMsT0FBTyxDQUFDRSxTQUFSLENBQWtCOEIsT0FBbEIsQ0FBMEJDLE1BQTFCLENBQWlDaFMsQ0FBakMsRUFBb0NoQyxLQUFwQyxDQUEwQ2lVLEdBQXBELENBRHVDLENBRXZDOztBQUNBLGVBQUtDLENBQUwsSUFBVUQsR0FBVixFQUFjO0FBQ1YsZ0JBQUlBLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU9uVSxJQUFQLElBQWUsK0JBQW5CLEVBQW1EO0FBQy9DWixxQkFBTyxDQUFDQyxHQUFSLENBQVk2VSxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPbFUsS0FBbkIsRUFEK0MsQ0FFL0M7O0FBQ0Esa0JBQUlVLFNBQVMsR0FBRztBQUNab0csZ0NBQWdCLEVBQUVtTixHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPbFUsS0FBUCxDQUFhbVUsTUFEbkI7QUFFWnhJLDJCQUFXLEVBQUVzSSxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPbFUsS0FBUCxDQUFhMkwsV0FGZDtBQUdaM0ssMEJBQVUsRUFBRWlULEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU9sVSxLQUFQLENBQWFnQixVQUhiO0FBSVo4SyxtQ0FBbUIsRUFBRW1JLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU9sVSxLQUFQLENBQWE4TCxtQkFKdEI7QUFLWmpMLGdDQUFnQixFQUFFb1QsR0FBRyxDQUFDQyxDQUFELENBQUgsQ0FBT2xVLEtBQVAsQ0FBYXVJLGlCQUxuQjtBQU1aekgsaUNBQWlCLEVBQUVtVCxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPbFUsS0FBUCxDQUFhYyxpQkFOcEI7QUFPWjRJLDRCQUFZLEVBQUVpQixJQUFJLENBQUN5SixLQUFMLENBQVdsTCxRQUFRLENBQUMrSyxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPbFUsS0FBUCxDQUFhQSxLQUFiLENBQW1Cc1IsTUFBcEIsQ0FBUixHQUFzQ2hULE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOE8sZUFBeEUsQ0FQRjtBQVFaeEksc0JBQU0sRUFBRSxLQVJJO0FBU1o1RixzQkFBTSxFQUFFO0FBVEksZUFBaEI7QUFZQXNJLDhCQUFnQixJQUFJN04sU0FBUyxDQUFDZ0osWUFBOUI7QUFFQSxrQkFBSTRLLFdBQVcsR0FBR2hXLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QnNOLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU9sVSxLQUFQLENBQWFtVSxNQUEzQyxDQUFsQixDQWpCK0MsQ0FrQi9DOztBQUVBelQsdUJBQVMsQ0FBQzBLLE9BQVYsR0FBb0I7QUFDaEIsd0JBQU8sMEJBRFM7QUFFaEIseUJBQVFrSjtBQUZRLGVBQXBCO0FBS0E1VCx1QkFBUyxDQUFDcEIsT0FBVixHQUFvQjJELFVBQVUsQ0FBQ3ZDLFNBQVMsQ0FBQzBLLE9BQVgsQ0FBOUI7QUFDQTFLLHVCQUFTLENBQUMySyxNQUFWLEdBQW1CL00sTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCakcsU0FBUyxDQUFDMEssT0FBeEMsRUFBaUQ5TSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QitGLGtCQUF4RSxDQUFuQjtBQUNBNUssdUJBQVMsQ0FBQzZLLGVBQVYsR0FBNEJqTixNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJqRyxTQUFTLENBQUMwSyxPQUF4QyxFQUFpRDlNLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCaUcsa0JBQXhFLENBQTVCO0FBQ0EzSSxnQ0FBa0IsQ0FBQ2dHLE1BQW5CLENBQTBCO0FBQ3RCdkosdUJBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCLE9BREc7QUFFdEJnTixpQ0FBaUIsRUFBRSxDQUZHO0FBR3RCNUMsNEJBQVksRUFBRWhKLFNBQVMsQ0FBQ2dKLFlBSEY7QUFJdEIzSixvQkFBSSxFQUFFLEtBSmdCO0FBS3RCMkUsc0JBQU0sRUFBRSxDQUxjO0FBTXRCNkgsMEJBQVUsRUFBRXdGLE9BQU8sQ0FBQ007QUFORSxlQUExQjtBQVNBMVQsd0JBQVUsQ0FBQ2tLLE1BQVgsQ0FBa0JuSSxTQUFsQjtBQUNIO0FBQ0o7QUFDSjtBQUNKLE9BN0Z1QyxDQStGeEM7OztBQUNBdkIsYUFBTyxDQUFDQyxHQUFSLENBQVkscUNBQVo7O0FBQ0EsVUFBSTJTLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEJyUCxVQUExQixJQUF3QzBPLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEJyUCxVQUExQixDQUFxQ2hELE1BQXJDLEdBQThDLENBQTFGLEVBQTRGO0FBQ3hGbEIsZUFBTyxDQUFDQyxHQUFSLENBQVkyUyxPQUFPLENBQUNFLFNBQVIsQ0FBa0JTLE9BQWxCLENBQTBCclAsVUFBMUIsQ0FBcUNoRCxNQUFqRDtBQUNBLFlBQUlrVSxnQkFBZ0IsR0FBR3hDLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEJyUCxVQUFqRDtBQUNBLFlBQUkrTCxhQUFhLEdBQUcyQyxPQUFPLENBQUMxTyxVQUE1Qjs7QUFDQSxhQUFLLElBQUk1RSxDQUFULElBQWM4VixnQkFBZCxFQUErQjtBQUMzQjtBQUNBLGNBQUk3VCxTQUFTLEdBQUc2VCxnQkFBZ0IsQ0FBQzlWLENBQUQsQ0FBaEM7QUFDQWlDLG1CQUFTLENBQUNJLGlCQUFWLEdBQThCeEMsTUFBTSxDQUFDcUksSUFBUCxDQUFZLGNBQVosRUFBNEI0TixnQkFBZ0IsQ0FBQzlWLENBQUQsQ0FBaEIsQ0FBb0JvQyxnQkFBaEQsQ0FBOUI7QUFFQSxjQUFJeVQsV0FBVyxHQUFHaFcsTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCakcsU0FBUyxDQUFDb0csZ0JBQXhDLENBQWxCO0FBRUFwRyxtQkFBUyxDQUFDMEssT0FBVixHQUFvQjtBQUNoQixvQkFBTywwQkFEUztBQUVoQixxQkFBUWtKO0FBRlEsV0FBcEI7QUFLQTVULG1CQUFTLENBQUNwQixPQUFWLEdBQW9CMkQsVUFBVSxDQUFDdkMsU0FBUyxDQUFDMEssT0FBWCxDQUE5QjtBQUNBMUssbUJBQVMsQ0FBQzBLLE9BQVYsR0FBb0IxSyxTQUFTLENBQUMwSyxPQUE5QjtBQUNBMUssbUJBQVMsQ0FBQzJLLE1BQVYsR0FBbUIvTSxNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJqRyxTQUFTLENBQUMwSyxPQUF4QyxFQUFpRDlNLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCK0Ysa0JBQXhFLENBQW5CO0FBQ0E1SyxtQkFBUyxDQUFDNkssZUFBVixHQUE0QmpOLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmpHLFNBQVMsQ0FBQzBLLE9BQXhDLEVBQWlEOU0sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJpRyxrQkFBeEUsQ0FBNUI7QUFFQTlLLG1CQUFTLENBQUNnSixZQUFWLEdBQXlCeUYsZUFBZSxDQUFDek8sU0FBRCxFQUFZME8sYUFBWixDQUF4QztBQUNBYiwwQkFBZ0IsSUFBSTdOLFNBQVMsQ0FBQ2dKLFlBQTlCO0FBRUEvSyxvQkFBVSxDQUFDb0wsTUFBWCxDQUFrQjtBQUFDakQsNEJBQWdCLEVBQUNwRyxTQUFTLENBQUNvRztBQUE1QixXQUFsQixFQUFnRXBHLFNBQWhFO0FBQ0FtQyw0QkFBa0IsQ0FBQ2dHLE1BQW5CLENBQTBCO0FBQ3RCdkosbUJBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCLE9BREc7QUFFdEJnTiw2QkFBaUIsRUFBRSxDQUZHO0FBR3RCNUMsd0JBQVksRUFBRWhKLFNBQVMsQ0FBQ2dKLFlBSEY7QUFJdEIzSixnQkFBSSxFQUFFLEtBSmdCO0FBS3RCMkUsa0JBQU0sRUFBRSxDQUxjO0FBTXRCNkgsc0JBQVUsRUFBRXdGLE9BQU8sQ0FBQ007QUFORSxXQUExQjtBQVFIO0FBQ0o7O0FBRURGLGlCQUFXLENBQUNQLFdBQVosR0FBMEIsSUFBMUI7QUFDQU8saUJBQVcsQ0FBQ3pCLGlCQUFaLEdBQWdDbkMsZ0JBQWhDO0FBQ0EsVUFBSTFPLE1BQU0sR0FBRzJDLEtBQUssQ0FBQ3VILE1BQU4sQ0FBYTtBQUFDSyxlQUFPLEVBQUMrSCxXQUFXLENBQUMvSDtBQUFyQixPQUFiLEVBQTRDO0FBQUNILFlBQUksRUFBQ2tJO0FBQU4sT0FBNUMsQ0FBYjtBQUdBaFQsYUFBTyxDQUFDQyxHQUFSLENBQVksMENBQVo7QUFFSDs7QUFFRCxXQUFPLElBQVA7QUFDSDtBQXRTVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDZkEsSUFBSWQsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJK0QsS0FBSixFQUFVME0sV0FBVjtBQUFzQjNRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ2dFLE9BQUssQ0FBQy9ELENBQUQsRUFBRztBQUFDK0QsU0FBSyxHQUFDL0QsQ0FBTjtBQUFRLEdBQWxCOztBQUFtQnlRLGFBQVcsQ0FBQ3pRLENBQUQsRUFBRztBQUFDeVEsZUFBVyxHQUFDelEsQ0FBWjtBQUFjOztBQUFoRCxDQUExQixFQUE0RSxDQUE1RTtBQUErRSxJQUFJK1YsU0FBSjtBQUFjalcsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ2dXLFdBQVMsQ0FBQy9WLENBQUQsRUFBRztBQUFDK1YsYUFBUyxHQUFDL1YsQ0FBVjtBQUFZOztBQUExQixDQUE3QyxFQUF5RSxDQUF6RTtBQUE0RSxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUs5UUgsTUFBTSxDQUFDbVcsT0FBUCxDQUFlLG9CQUFmLEVBQXFDLFlBQVk7QUFDN0MsU0FBTyxDQUNIdkYsV0FBVyxDQUFDOUssSUFBWixDQUFpQixFQUFqQixFQUFvQjtBQUFDaUMsUUFBSSxFQUFDO0FBQUMzQixZQUFNLEVBQUMsQ0FBQztBQUFULEtBQU47QUFBa0I0QixTQUFLLEVBQUM7QUFBeEIsR0FBcEIsQ0FERyxFQUVIa08sU0FBUyxDQUFDcFEsSUFBVixDQUFlLEVBQWYsRUFBa0I7QUFBQ2lDLFFBQUksRUFBQztBQUFDcU8scUJBQWUsRUFBQyxDQUFDO0FBQWxCLEtBQU47QUFBMkJwTyxTQUFLLEVBQUM7QUFBakMsR0FBbEIsQ0FGRyxDQUFQO0FBSUgsQ0FMRDtBQU9BcUksZ0JBQWdCLENBQUMsY0FBRCxFQUFpQixZQUFVO0FBQ3ZDLFNBQU87QUFDSHZLLFFBQUksR0FBRTtBQUNGLGFBQU81QixLQUFLLENBQUM0QixJQUFOLENBQVc7QUFBQ2dHLGVBQU8sRUFBQzlMLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNkU7QUFBaEMsT0FBWCxDQUFQO0FBQ0gsS0FIRTs7QUFJSHdFLFlBQVEsRUFBRSxDQUNOO0FBQ0l4SyxVQUFJLENBQUM4TCxLQUFELEVBQU87QUFDUCxlQUFPdlIsVUFBVSxDQUFDeUYsSUFBWCxDQUNILEVBREcsRUFFSDtBQUFDMkksZ0JBQU0sRUFBQztBQUNKek4sbUJBQU8sRUFBQyxDQURKO0FBRUpxTSx1QkFBVyxFQUFDLENBRlI7QUFHSjlLLDRCQUFnQixFQUFDLENBSGI7QUFJSm9GLGtCQUFNLEVBQUMsQ0FBQyxDQUpKO0FBS0o0RixrQkFBTSxFQUFDLENBTEg7QUFNSkQsdUJBQVcsRUFBQztBQU5SO0FBQVIsU0FGRyxDQUFQO0FBV0g7O0FBYkwsS0FETTtBQUpQLEdBQVA7QUFzQkgsQ0F2QmUsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUNaQXJOLE1BQU0sQ0FBQ3NRLE1BQVAsQ0FBYztBQUFDck0sT0FBSyxFQUFDLE1BQUlBLEtBQVg7QUFBaUIwTSxhQUFXLEVBQUMsTUFBSUE7QUFBakMsQ0FBZDtBQUE2RCxJQUFJSixLQUFKO0FBQVV2USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNzUSxPQUFLLENBQUNyUSxDQUFELEVBQUc7QUFBQ3FRLFNBQUssR0FBQ3JRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBMUMsRUFBd0UsQ0FBeEU7QUFHakksTUFBTStELEtBQUssR0FBRyxJQUFJc00sS0FBSyxDQUFDQyxVQUFWLENBQXFCLE9BQXJCLENBQWQ7QUFDQSxNQUFNRyxXQUFXLEdBQUcsSUFBSUosS0FBSyxDQUFDQyxVQUFWLENBQXFCLGNBQXJCLENBQXBCO0FBRVB2TSxLQUFLLENBQUN3TSxPQUFOLENBQWM7QUFDVkMsVUFBUSxHQUFFO0FBQ04sV0FBT3RRLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQ3JCLGFBQU8sRUFBQyxLQUFLK0U7QUFBZCxLQUFuQixDQUFQO0FBQ0g7O0FBSFMsQ0FBZCxFOzs7Ozs7Ozs7OztBQ05BLElBQUkvRixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUkrVixTQUFKO0FBQWNqVyxNQUFNLENBQUNDLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDZ1csV0FBUyxDQUFDL1YsQ0FBRCxFQUFHO0FBQUMrVixhQUFTLEdBQUMvVixDQUFWO0FBQVk7O0FBQTFCLENBQS9CLEVBQTJELENBQTNEO0FBQThELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFJckpILE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsNEJBQTBCLFlBQVU7QUFDaEMsU0FBS0UsT0FBTDtBQUNBLFFBQUlvVixNQUFNLEdBQUdyVyxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QnFQLFdBQXBDOztBQUNBLFFBQUlELE1BQUosRUFBVztBQUNQLFVBQUc7QUFDQyxZQUFJRSxHQUFHLEdBQUcsSUFBSW5ULElBQUosRUFBVjtBQUNBbVQsV0FBRyxDQUFDQyxVQUFKLENBQWUsQ0FBZjtBQUNBLFlBQUlqVyxHQUFHLEdBQUcsdURBQXFEOFYsTUFBckQsR0FBNEQsd0hBQXRFO0FBQ0EsWUFBSWxWLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjs7QUFDQSxZQUFJWSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0I7QUFDQSxjQUFJZ0MsSUFBSSxHQUFHdkIsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBWDtBQUNBcUIsY0FBSSxHQUFHQSxJQUFJLENBQUMwVCxNQUFELENBQVgsQ0FIMkIsQ0FJM0I7O0FBQ0EsaUJBQU9ILFNBQVMsQ0FBQ3pLLE1BQVYsQ0FBaUI7QUFBQzJLLDJCQUFlLEVBQUN6VCxJQUFJLENBQUN5VDtBQUF0QixXQUFqQixFQUF5RDtBQUFDekssZ0JBQUksRUFBQ2hKO0FBQU4sV0FBekQsQ0FBUDtBQUNIO0FBQ0osT0FaRCxDQWFBLE9BQU0vQixDQUFOLEVBQVE7QUFDSkMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLEtBakJELE1Ba0JJO0FBQ0EsYUFBTywyQkFBUDtBQUNIO0FBQ0osR0F6QlU7QUEwQlgsd0JBQXNCLFlBQVU7QUFDNUIsU0FBS0ssT0FBTDtBQUNBLFFBQUlvVixNQUFNLEdBQUdyVyxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QnFQLFdBQXBDOztBQUNBLFFBQUlELE1BQUosRUFBVztBQUNQLGFBQVFILFNBQVMsQ0FBQzdULE9BQVYsQ0FBa0IsRUFBbEIsRUFBcUI7QUFBQzBGLFlBQUksRUFBQztBQUFDcU8seUJBQWUsRUFBQyxDQUFDO0FBQWxCO0FBQU4sT0FBckIsQ0FBUjtBQUNILEtBRkQsTUFHSTtBQUNBLGFBQU8sMkJBQVA7QUFDSDtBQUVKO0FBcENVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNKQW5XLE1BQU0sQ0FBQ3NRLE1BQVAsQ0FBYztBQUFDMkYsV0FBUyxFQUFDLE1BQUlBO0FBQWYsQ0FBZDtBQUF5QyxJQUFJMUYsS0FBSjtBQUFVdlEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDc1EsT0FBSyxDQUFDclEsQ0FBRCxFQUFHO0FBQUNxUSxTQUFLLEdBQUNyUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRTVDLE1BQU0rVixTQUFTLEdBQUcsSUFBSTFGLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixZQUFyQixDQUFsQixDOzs7Ozs7Ozs7OztBQ0ZQLElBQUl6USxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlzVyxXQUFKO0FBQWdCeFcsTUFBTSxDQUFDQyxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQ3VXLGFBQVcsQ0FBQ3RXLENBQUQsRUFBRztBQUFDc1csZUFBVyxHQUFDdFcsQ0FBWjtBQUFjOztBQUE5QixDQUFoQyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUlsS0gsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCxnQ0FBOEIsWUFBVTtBQUNwQyxTQUFLRSxPQUFMO0FBQ0EsUUFBSThELFVBQVUsR0FBRzFFLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0JFLEtBQXBCLEVBQWpCO0FBQ0EsUUFBSWhFLFdBQVcsR0FBRyxFQUFsQjtBQUNBbkIsV0FBTyxDQUFDQyxHQUFSLENBQVksNkJBQVo7O0FBQ0EsU0FBS1gsQ0FBTCxJQUFVNEUsVUFBVixFQUFxQjtBQUNqQixVQUFJQSxVQUFVLENBQUM1RSxDQUFELENBQVYsQ0FBY29DLGdCQUFsQixFQUFtQztBQUMvQixZQUFJaEMsR0FBRyxHQUFHRyxHQUFHLEdBQUcsc0JBQU4sR0FBNkJxRSxVQUFVLENBQUM1RSxDQUFELENBQVYsQ0FBY29DLGdCQUEzQyxHQUE0RCxjQUF0RTs7QUFDQSxZQUFHO0FBQ0MsY0FBSXBCLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjs7QUFDQSxjQUFJWSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0IsZ0JBQUk4QyxVQUFVLEdBQUdyQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBOUMsQ0FEMkIsQ0FFM0I7O0FBQ0FTLHVCQUFXLEdBQUdBLFdBQVcsQ0FBQzBVLE1BQVosQ0FBbUJqVCxVQUFuQixDQUFkO0FBQ0gsV0FKRCxNQUtJO0FBQ0E1QyxtQkFBTyxDQUFDQyxHQUFSLENBQVlLLFFBQVEsQ0FBQ1IsVUFBckI7QUFDSDtBQUNKLFNBVkQsQ0FXQSxPQUFPQyxDQUFQLEVBQVM7QUFDTEMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSjtBQUNKOztBQUVELFNBQUs4QyxDQUFMLElBQVUxQixXQUFWLEVBQXNCO0FBQ2xCLFVBQUlBLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxJQUFrQjFCLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxDQUFlZCxNQUFyQyxFQUNJWixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBZixHQUF3QkMsVUFBVSxDQUFDYixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBaEIsQ0FBbEM7QUFDUCxLQTVCbUMsQ0E4QnBDOzs7QUFDQSxRQUFJRCxJQUFJLEdBQUc7QUFDUFgsaUJBQVcsRUFBRUEsV0FETjtBQUVQMlUsZUFBUyxFQUFFLElBQUl2VCxJQUFKO0FBRkosS0FBWDtBQUtBLFdBQU9xVCxXQUFXLENBQUNsTSxNQUFaLENBQW1CNUgsSUFBbkIsQ0FBUDtBQUNILEdBdENVLENBdUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQXBEVyxDQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0pBMUMsTUFBTSxDQUFDc1EsTUFBUCxDQUFjO0FBQUNrRyxhQUFXLEVBQUMsTUFBSUE7QUFBakIsQ0FBZDtBQUE2QyxJQUFJakcsS0FBSjtBQUFVdlEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDc1EsT0FBSyxDQUFDclEsQ0FBRCxFQUFHO0FBQUNxUSxTQUFLLEdBQUNyUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRWhELE1BQU1zVyxXQUFXLEdBQUcsSUFBSWpHLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixhQUFyQixDQUFwQixDOzs7Ozs7Ozs7OztBQ0ZQLElBQUl6USxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSXlXLFVBQUo7QUFBZTNXLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUMwVyxZQUFVLENBQUN6VyxDQUFELEVBQUc7QUFBQ3lXLGNBQVUsR0FBQ3pXLENBQVg7QUFBYTs7QUFBNUIsQ0FBL0IsRUFBNkQsQ0FBN0Q7QUFJdklILE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsa0NBQWdDLFlBQVU7QUFDdEMsU0FBS0UsT0FBTDs7QUFDQSxRQUFHO0FBQ0MsVUFBSVYsR0FBRyxHQUFHRyxHQUFHLEdBQUcsaUJBQWhCO0FBQ0EsVUFBSVMsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsVUFBSXNXLGNBQWMsR0FBR3pWLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUFsRDtBQUVBLFVBQUl1VixzQkFBc0IsR0FBRyxJQUFJQyxHQUFKLENBQVFILFVBQVUsQ0FBQzlRLElBQVgsQ0FDakM7QUFBQyxrQkFBUztBQUFDUSxhQUFHLEVBQUMsQ0FBQyxRQUFELEVBQVcsVUFBWDtBQUFMO0FBQVYsT0FEaUMsRUFFbkNOLEtBRm1DLEdBRTNCRSxHQUYyQixDQUV0QmxCLENBQUQsSUFBTUEsQ0FBQyxDQUFDZ1MsSUFGZSxDQUFSLENBQTdCO0FBSUEsVUFBSUMsS0FBSyxHQUFHLEVBQVo7O0FBRUEsVUFBSUosY0FBYyxDQUFDOVUsTUFBZixHQUF3QixDQUE1QixFQUErQjtBQUMzQixjQUFNbVYsT0FBTyxHQUFHTixVQUFVLENBQUNqUSxhQUFYLEdBQTJCb0MseUJBQTNCLEVBQWhCOztBQUNBLGFBQUssSUFBSXJGLENBQVQsSUFBY21ULGNBQWQsRUFBOEI7QUFDMUIsY0FBSU0sRUFBRSxHQUFHTixjQUFjLENBQUNuVCxDQUFELENBQXZCO0FBQ0F5VCxZQUFFLENBQUNILElBQUgsR0FBVXBNLFFBQVEsQ0FBQ3VNLEVBQUUsQ0FBQ0MsRUFBSixDQUFsQjs7QUFDQSxjQUFJRCxFQUFFLENBQUNILElBQUgsR0FBVSxDQUFWLElBQWUsQ0FBQ0Ysc0JBQXNCLENBQUNPLEdBQXZCLENBQTJCRixFQUFFLENBQUNILElBQTlCLENBQXBCLEVBQXlEO0FBQ3JELGdCQUFJO0FBQ0FFLHFCQUFPLENBQUNwUixJQUFSLENBQWE7QUFBQ2tSLG9CQUFJLEVBQUVHLEVBQUUsQ0FBQ0g7QUFBVixlQUFiLEVBQThCdkwsTUFBOUIsR0FBdUNDLFNBQXZDLENBQWlEO0FBQUNDLG9CQUFJLEVBQUV3TDtBQUFQLGVBQWpEO0FBQ0FGLG1CQUFLLENBQUNqTixJQUFOLENBQVdtTixFQUFFLENBQUNILElBQWQ7QUFDSCxhQUhELENBR0UsT0FBTXBXLENBQU4sRUFBUztBQUNQc1cscUJBQU8sQ0FBQ3BSLElBQVIsQ0FBYTtBQUFDa1Isb0JBQUksRUFBRUcsRUFBRSxDQUFDSDtBQUFWLGVBQWIsRUFBOEJ2TCxNQUE5QixHQUF1Q0MsU0FBdkMsQ0FBaUQ7QUFBQ0Msb0JBQUksRUFBRXdMO0FBQVAsZUFBakQ7QUFDQUYsbUJBQUssQ0FBQ2pOLElBQU4sQ0FBV21OLEVBQUUsQ0FBQ0gsSUFBZDtBQUNBblcscUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFDLENBQUNPLFFBQUYsQ0FBV0csT0FBdkI7QUFDSDtBQUNKO0FBQ0o7O0FBQ0QsWUFBRzJWLEtBQUssQ0FBQ2xWLE1BQU4sR0FBZSxDQUFsQixFQUFxQjtBQUNqQm1WLGlCQUFPLENBQUNqSSxPQUFSO0FBQ0g7QUFDSjs7QUFDRCxhQUFPLElBQVA7QUFDSCxLQWhDRCxDQWlDQSxPQUFPck8sQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSjtBQXZDVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDSkEsSUFBSVosTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeVcsVUFBSjtBQUFlM1csTUFBTSxDQUFDQyxJQUFQLENBQVksa0JBQVosRUFBK0I7QUFBQzBXLFlBQVUsQ0FBQ3pXLENBQUQsRUFBRztBQUFDeVcsY0FBVSxHQUFDelcsQ0FBWDtBQUFhOztBQUE1QixDQUEvQixFQUE2RCxDQUE3RDtBQUFnRSxJQUFJbVgsS0FBSjtBQUFVclgsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDb1gsT0FBSyxDQUFDblgsQ0FBRCxFQUFHO0FBQUNtWCxTQUFLLEdBQUNuWCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBSXpKSCxNQUFNLENBQUNtVyxPQUFQLENBQWUscUJBQWYsRUFBc0MsWUFBWTtBQUM5QyxTQUFPUyxVQUFVLENBQUM5USxJQUFYLENBQWdCLEVBQWhCLEVBQW9CO0FBQUNpQyxRQUFJLEVBQUM7QUFBQ2lQLFVBQUksRUFBQyxDQUFDO0FBQVA7QUFBTixHQUFwQixDQUFQO0FBQ0gsQ0FGRDtBQUlBaFgsTUFBTSxDQUFDbVcsT0FBUCxDQUFlLG1CQUFmLEVBQW9DLFVBQVVpQixFQUFWLEVBQWE7QUFDN0NFLE9BQUssQ0FBQ0YsRUFBRCxFQUFLRyxNQUFMLENBQUw7QUFDQSxTQUFPWCxVQUFVLENBQUM5USxJQUFYLENBQWdCO0FBQUNrUixRQUFJLEVBQUNJO0FBQU4sR0FBaEIsQ0FBUDtBQUNILENBSEQsRTs7Ozs7Ozs7Ozs7QUNSQW5YLE1BQU0sQ0FBQ3NRLE1BQVAsQ0FBYztBQUFDcUcsWUFBVSxFQUFDLE1BQUlBO0FBQWhCLENBQWQ7QUFBMkMsSUFBSXBHLEtBQUo7QUFBVXZRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3NRLE9BQUssQ0FBQ3JRLENBQUQsRUFBRztBQUFDcVEsU0FBSyxHQUFDclEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUU5QyxNQUFNeVcsVUFBVSxHQUFHLElBQUlwRyxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsWUFBckIsQ0FBbkIsQzs7Ozs7Ozs7Ozs7QUNGUCxJQUFJK0csYUFBSjs7QUFBa0J2WCxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQ0FBWixFQUFtRDtBQUFDdVgsU0FBTyxDQUFDdFgsQ0FBRCxFQUFHO0FBQUNxWCxpQkFBYSxHQUFDclgsQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBbkQsRUFBaUYsQ0FBakY7QUFBbEIsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUVUSCxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLHdCQUFzQixVQUFTMlcsTUFBVCxFQUFpQjtBQUNuQyxVQUFNblgsR0FBRyxhQUFNRyxHQUFOLFNBQVQ7QUFDQWlDLFFBQUksR0FBRztBQUNILFlBQU0rVSxNQUFNLENBQUNoVyxLQURWO0FBRUgsY0FBUTtBQUZMLEtBQVA7QUFJQSxVQUFNaVcsU0FBUyxHQUFHLElBQUl2VSxJQUFKLEdBQVdtSixPQUFYLEVBQWxCO0FBQ0ExTCxXQUFPLENBQUNDLEdBQVIsaUNBQXFDNlcsU0FBckMsY0FBa0RwWCxHQUFsRCx3QkFBbUVhLElBQUksQ0FBQ21FLFNBQUwsQ0FBZTVDLElBQWYsQ0FBbkU7QUFFQSxRQUFJeEIsUUFBUSxHQUFHZixJQUFJLENBQUN3WCxJQUFMLENBQVVyWCxHQUFWLEVBQWU7QUFBQ29DO0FBQUQsS0FBZixDQUFmO0FBQ0E5QixXQUFPLENBQUNDLEdBQVIsbUNBQXVDNlcsU0FBdkMsY0FBb0RwWCxHQUFwRCxlQUE0RGEsSUFBSSxDQUFDbUUsU0FBTCxDQUFlcEUsUUFBZixDQUE1RDs7QUFDQSxRQUFJQSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBZ0M7QUFDNUIsVUFBSWdDLElBQUksR0FBR3hCLFFBQVEsQ0FBQ3dCLElBQXBCO0FBQ0EsVUFBSUEsSUFBSSxDQUFDa1YsSUFBVCxFQUNJLE1BQU0sSUFBSTdYLE1BQU0sQ0FBQzhYLEtBQVgsQ0FBaUJuVixJQUFJLENBQUNrVixJQUF0QixFQUE0QnpXLElBQUksQ0FBQ0MsS0FBTCxDQUFXc0IsSUFBSSxDQUFDb1YsT0FBaEIsRUFBeUJDLE9BQXJELENBQU47QUFDSixhQUFPN1csUUFBUSxDQUFDd0IsSUFBVCxDQUFjc1YsTUFBckI7QUFDSDtBQUNKLEdBbEJVO0FBbUJYLHlCQUF1QixVQUFTQyxJQUFULEVBQWVDLElBQWYsRUFBcUI7QUFDeEMsVUFBTTVYLEdBQUcsYUFBTUcsR0FBTixjQUFheVgsSUFBYixDQUFUO0FBQ0F4VixRQUFJLEdBQUc7QUFDSCxvQ0FDT3VWLElBRFA7QUFFSSxvQkFBWWxZLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNkUsT0FGdkM7QUFHSSxvQkFBWTtBQUhoQjtBQURHLEtBQVA7QUFPQSxRQUFJM0ssUUFBUSxHQUFHZixJQUFJLENBQUN3WCxJQUFMLENBQVVyWCxHQUFWLEVBQWU7QUFBQ29DO0FBQUQsS0FBZixDQUFmOztBQUNBLFFBQUl4QixRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBZ0M7QUFDNUIsYUFBT1MsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBUDtBQUNIO0FBQ0osR0FoQ1U7QUFpQ1gsMEJBQXdCLFVBQVM4VyxLQUFULEVBQWdCaE8sSUFBaEIsRUFBc0IrTixJQUF0QixFQUE4QztBQUFBLFFBQWxCRSxVQUFrQix1RUFBUCxLQUFPO0FBQ2xFLFVBQU05WCxHQUFHLGFBQU1HLEdBQU4sY0FBYXlYLElBQWIsQ0FBVDtBQUNBeFYsUUFBSSxxQkFBT3lWLEtBQVA7QUFDQSxrQkFBWTtBQUNSLGdCQUFRaE8sSUFEQTtBQUVSLG9CQUFZcEssTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI2RSxPQUYzQjtBQUdSLDBCQUFrQnVNLFVBSFY7QUFJUixvQkFBWTtBQUpKO0FBRFosTUFBSjtBQVFBLFFBQUlsWCxRQUFRLEdBQUdmLElBQUksQ0FBQ3dYLElBQUwsQ0FBVXJYLEdBQVYsRUFBZTtBQUFDb0M7QUFBRCxLQUFmLENBQWY7O0FBQ0EsUUFBSXhCLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUFnQztBQUM1QixhQUFPUyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QmdYLFlBQXBDO0FBQ0g7QUFDSjtBQS9DVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDRkEsSUFBSWQsYUFBSjs7QUFBa0J2WCxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQ0FBWixFQUFtRDtBQUFDdVgsU0FBTyxDQUFDdFgsQ0FBRCxFQUFHO0FBQUNxWCxpQkFBYSxHQUFDclgsQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBbkQsRUFBaUYsQ0FBakY7QUFBbEIsSUFBSUgsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUlvWSxTQUFKO0FBQWN0WSxNQUFNLENBQUNDLElBQVAsQ0FBWSxpQkFBWixFQUE4QjtBQUFDcVksV0FBUyxDQUFDcFksQ0FBRCxFQUFHO0FBQUNvWSxhQUFTLEdBQUNwWSxDQUFWO0FBQVk7O0FBQTFCLENBQTlCLEVBQTBELENBQTFEO0FBQTZELElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBSWxOO0FBRUFILE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsNEJBQTBCLFlBQVU7QUFDaEMsU0FBS0UsT0FBTDs7QUFDQSxRQUFHO0FBQ0MsVUFBSVYsR0FBRyxHQUFHRyxHQUFHLEdBQUcsZ0JBQWhCO0FBQ0EsVUFBSVMsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsVUFBSWlZLFNBQVMsR0FBR3BYLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE3QyxDQUhELENBSUM7O0FBRUEsVUFBSWtYLG1CQUFtQixHQUFHLElBQUkxQixHQUFKLENBQVF3QixTQUFTLENBQUN6UyxJQUFWLENBQzlCO0FBQUMsMkJBQWtCO0FBQUNRLGFBQUcsRUFBQyxDQUFDLFFBQUQsRUFBVyxVQUFYLEVBQXVCLFNBQXZCO0FBQUw7QUFBbkIsT0FEOEIsRUFFaENOLEtBRmdDLEdBRXhCRSxHQUZ3QixDQUVuQmxCLENBQUQsSUFBTUEsQ0FBQyxDQUFDMFQsVUFGWSxDQUFSLENBQTFCO0FBSUEsVUFBSUMsV0FBVyxHQUFHLEVBQWxCOztBQUNBLFVBQUlILFNBQVMsQ0FBQ3pXLE1BQVYsR0FBbUIsQ0FBdkIsRUFBeUI7QUFDckI7QUFDQSxjQUFNNlcsYUFBYSxHQUFHTCxTQUFTLENBQUM1UixhQUFWLEdBQTBCb0MseUJBQTFCLEVBQXRCOztBQUNBLGFBQUssSUFBSXJGLENBQVQsSUFBYzhVLFNBQWQsRUFBd0I7QUFDcEIsY0FBSUssUUFBUSxHQUFHTCxTQUFTLENBQUM5VSxDQUFELENBQXhCO0FBQ0FtVixrQkFBUSxDQUFDSCxVQUFULEdBQXNCOU4sUUFBUSxDQUFDaU8sUUFBUSxDQUFDekIsRUFBVixDQUE5Qjs7QUFDQSxjQUFJeUIsUUFBUSxDQUFDSCxVQUFULEdBQXNCLENBQXRCLElBQTJCLENBQUNELG1CQUFtQixDQUFDcEIsR0FBcEIsQ0FBd0J3QixRQUFRLENBQUNILFVBQWpDLENBQWhDLEVBQThFO0FBQzFFLGdCQUFHO0FBQ0Msa0JBQUluWSxHQUFHLEdBQUdHLEdBQUcsR0FBRyxpQkFBTixHQUF3Qm1ZLFFBQVEsQ0FBQ0gsVUFBakMsR0FBNEMsV0FBdEQ7QUFDQSxrQkFBSXZYLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjs7QUFDQSxrQkFBSVksUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCLG9CQUFJZ1EsUUFBUSxHQUFHdlAsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTVDOztBQUNBLG9CQUFJb1AsUUFBUSxDQUFDbUksV0FBVCxJQUF5Qm5JLFFBQVEsQ0FBQ21JLFdBQVQsSUFBd0JELFFBQVEsQ0FBQ3pCLEVBQTlELEVBQWtFO0FBQzlEeUIsMEJBQVEsQ0FBQ2xJLFFBQVQsR0FBb0JBLFFBQVEsQ0FBQ0EsUUFBN0I7QUFDSDtBQUNKOztBQUNEaUksMkJBQWEsQ0FBQzlTLElBQWQsQ0FBbUI7QUFBQzRTLDBCQUFVLEVBQUVHLFFBQVEsQ0FBQ0g7QUFBdEIsZUFBbkIsRUFBc0RqTixNQUF0RCxHQUErREMsU0FBL0QsQ0FBeUU7QUFBQ0Msb0JBQUksRUFBQ2tOO0FBQU4sZUFBekU7QUFDQUYseUJBQVcsQ0FBQzNPLElBQVosQ0FBaUI2TyxRQUFRLENBQUNILFVBQTFCO0FBQ0gsYUFYRCxDQVlBLE9BQU05WCxDQUFOLEVBQVE7QUFDSmdZLDJCQUFhLENBQUM5UyxJQUFkLENBQW1CO0FBQUM0UywwQkFBVSxFQUFFRyxRQUFRLENBQUNIO0FBQXRCLGVBQW5CLEVBQXNEak4sTUFBdEQsR0FBK0RDLFNBQS9ELENBQXlFO0FBQUNDLG9CQUFJLEVBQUNrTjtBQUFOLGVBQXpFO0FBQ0FGLHlCQUFXLENBQUMzTyxJQUFaLENBQWlCNk8sUUFBUSxDQUFDSCxVQUExQjtBQUNBN1gscUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFDLENBQUNPLFFBQUYsQ0FBV0csT0FBdkI7QUFDSDtBQUNKO0FBQ0o7O0FBQ0RzWCxxQkFBYSxDQUFDOVMsSUFBZCxDQUFtQjtBQUFDNFMsb0JBQVUsRUFBQztBQUFDSyxnQkFBSSxFQUFDSjtBQUFOLFdBQVo7QUFBZ0NLLHlCQUFlLEVBQUM7QUFBQ0QsZ0JBQUksRUFBQyxDQUFDLFFBQUQsRUFBVyxVQUFYLEVBQXVCLFNBQXZCO0FBQU47QUFBaEQsU0FBbkIsRUFDS3RNLE1BREwsQ0FDWTtBQUFDZCxjQUFJLEVBQUU7QUFBQywrQkFBbUI7QUFBcEI7QUFBUCxTQURaO0FBRUFpTixxQkFBYSxDQUFDM0osT0FBZDtBQUNIOztBQUNELGFBQU8sSUFBUDtBQUNILEtBMUNELENBMkNBLE9BQU9yTyxDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLEdBakRVO0FBa0RYLGtDQUFnQyxZQUFVO0FBQ3RDLFNBQUtLLE9BQUw7QUFDQSxRQUFJdVgsU0FBUyxHQUFHRCxTQUFTLENBQUN6UyxJQUFWLENBQWU7QUFBQyx5QkFBa0I7QUFBQ2lULFlBQUksRUFBQyxDQUFDLFFBQUQsRUFBVyxVQUFYLEVBQXVCLFNBQXZCO0FBQU47QUFBbkIsS0FBZixFQUE2RS9TLEtBQTdFLEVBQWhCOztBQUVBLFFBQUl3UyxTQUFTLElBQUtBLFNBQVMsQ0FBQ3pXLE1BQVYsR0FBbUIsQ0FBckMsRUFBd0M7QUFDcEMsV0FBSyxJQUFJMkIsQ0FBVCxJQUFjOFUsU0FBZCxFQUF3QjtBQUNwQixZQUFJNU4sUUFBUSxDQUFDNE4sU0FBUyxDQUFDOVUsQ0FBRCxDQUFULENBQWFnVixVQUFkLENBQVIsR0FBb0MsQ0FBeEMsRUFBMEM7QUFDdEMsY0FBRztBQUNDO0FBQ0EsZ0JBQUluWSxHQUFHLEdBQUdHLEdBQUcsR0FBRyxpQkFBTixHQUF3QjhYLFNBQVMsQ0FBQzlVLENBQUQsQ0FBVCxDQUFhZ1YsVUFBckMsR0FBZ0QsV0FBMUQ7QUFDQSxnQkFBSXZYLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjtBQUNBLGdCQUFJc1ksUUFBUSxHQUFHO0FBQUNILHdCQUFVLEVBQUVGLFNBQVMsQ0FBQzlVLENBQUQsQ0FBVCxDQUFhZ1Y7QUFBMUIsYUFBZjs7QUFDQSxnQkFBSXZYLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQixrQkFBSXNZLFFBQVEsR0FBRzdYLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE1QztBQUNBc1gsc0JBQVEsQ0FBQ0ksUUFBVCxHQUFvQkEsUUFBcEI7QUFDSDs7QUFFRDFZLGVBQUcsR0FBR0csR0FBRyxHQUFHLGlCQUFOLEdBQXdCOFgsU0FBUyxDQUFDOVUsQ0FBRCxDQUFULENBQWFnVixVQUFyQyxHQUFnRCxRQUF0RDtBQUNBdlgsb0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDs7QUFDQSxnQkFBSVksUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCLGtCQUFJMFEsS0FBSyxHQUFHalEsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQXpDO0FBQ0FzWCxzQkFBUSxDQUFDeEgsS0FBVCxHQUFpQjZILGFBQWEsQ0FBQzdILEtBQUQsQ0FBOUI7QUFDSDs7QUFFRDlRLGVBQUcsR0FBR0csR0FBRyxHQUFHLGlCQUFOLEdBQXdCOFgsU0FBUyxDQUFDOVUsQ0FBRCxDQUFULENBQWFnVixVQUFyQyxHQUFnRCxRQUF0RDtBQUNBdlgsb0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDs7QUFDQSxnQkFBSVksUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCLGtCQUFJd1ksS0FBSyxHQUFHL1gsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQXpDO0FBQ0FzWCxzQkFBUSxDQUFDTSxLQUFULEdBQWlCQSxLQUFqQjtBQUNIOztBQUVETixvQkFBUSxDQUFDTyxTQUFULEdBQXFCLElBQUloVyxJQUFKLEVBQXJCO0FBQ0FtVixxQkFBUyxDQUFDOUwsTUFBVixDQUFpQjtBQUFDaU0sd0JBQVUsRUFBRUYsU0FBUyxDQUFDOVUsQ0FBRCxDQUFULENBQWFnVjtBQUExQixhQUFqQixFQUF3RDtBQUFDL00sa0JBQUksRUFBQ2tOO0FBQU4sYUFBeEQ7QUFDSCxXQTFCRCxDQTJCQSxPQUFNalksQ0FBTixFQUFRLENBRVA7QUFDSjtBQUNKO0FBQ0o7O0FBQ0QsV0FBTyxJQUFQO0FBQ0g7QUEzRlUsQ0FBZjs7QUE4RkEsTUFBTXNZLGFBQWEsR0FBSTdILEtBQUQsSUFBVztBQUM3QixNQUFJLENBQUNBLEtBQUwsRUFBWTtBQUNSLFdBQU8sRUFBUDtBQUNIOztBQUVELE1BQUlnSSxNQUFNLEdBQUdoSSxLQUFLLENBQUNuTCxHQUFOLENBQVdvVCxJQUFELElBQVVBLElBQUksQ0FBQ0MsS0FBekIsQ0FBYjtBQUNBLE1BQUlDLGNBQWMsR0FBRyxFQUFyQjtBQUNBLE1BQUlDLG1CQUFtQixHQUFHLEVBQTFCO0FBQ0FwWixZQUFVLENBQUN5RixJQUFYLENBQWdCO0FBQUN0RCxxQkFBaUIsRUFBRTtBQUFDOEQsU0FBRyxFQUFFK1M7QUFBTjtBQUFwQixHQUFoQixFQUFvRHJXLE9BQXBELENBQTZEWixTQUFELElBQWU7QUFDdkVvWCxrQkFBYyxDQUFDcFgsU0FBUyxDQUFDSSxpQkFBWCxDQUFkLEdBQThDO0FBQzFDa1gsYUFBTyxFQUFFdFgsU0FBUyxDQUFDaUwsV0FBVixDQUFzQnFNLE9BRFc7QUFFMUMxWSxhQUFPLEVBQUVvQixTQUFTLENBQUNwQixPQUZ1QjtBQUcxQ3lNLFlBQU0sRUFBRTVLLFVBQVUsQ0FBQ1QsU0FBUyxDQUFDcUwsTUFBWCxDQUh3QjtBQUkxQ2tNLHFCQUFlLEVBQUU5VyxVQUFVLENBQUNULFNBQVMsQ0FBQ3NMLGdCQUFYLENBSmU7QUFLMUNrTSxvQkFBYyxFQUFFL1csVUFBVSxDQUFDVCxTQUFTLENBQUNzTCxnQkFBWDtBQUxnQixLQUE5QztBQU9BK0wsdUJBQW1CLENBQUNyWCxTQUFTLENBQUNHLGdCQUFYLENBQW5CLEdBQWtESCxTQUFTLENBQUNJLGlCQUE1RDtBQUNILEdBVEQ7QUFVQTZXLFFBQU0sQ0FBQ3JXLE9BQVAsQ0FBZ0J1VyxLQUFELElBQVc7QUFDdEIsUUFBSSxDQUFDQyxjQUFjLENBQUNELEtBQUQsQ0FBbkIsRUFBNEI7QUFDeEI7QUFDQSxVQUFJaFosR0FBRyxhQUFNRyxHQUFOLGlDQUFnQzZZLEtBQWhDLGlCQUFQO0FBQ0EsVUFBSXZYLFdBQUo7QUFDQSxVQUFJNlgsV0FBVyxHQUFHLENBQWxCOztBQUNBLFVBQUc7QUFDQyxZQUFJMVksUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmOztBQUNBLFlBQUlZLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQnFCLHFCQUFXLEdBQUdaLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUEzQzs7QUFDQSxjQUFJUyxXQUFXLElBQUlBLFdBQVcsQ0FBQ0QsTUFBWixHQUFxQixDQUF4QyxFQUEyQztBQUN2Q0MsdUJBQVcsQ0FBQ2dCLE9BQVosQ0FBcUJTLFVBQUQsSUFBZ0I7QUFDaEMsa0JBQUliLE1BQU0sR0FBR0MsVUFBVSxDQUFDWSxVQUFVLENBQUNiLE1BQVosQ0FBdkI7O0FBQ0Esa0JBQUk2VyxtQkFBbUIsQ0FBQ2hXLFVBQVUsQ0FBQ3dHLGlCQUFaLENBQXZCLEVBQXVEO0FBQ25EO0FBQ0Esb0JBQUk3SCxTQUFTLEdBQUdvWCxjQUFjLENBQUNDLG1CQUFtQixDQUFDaFcsVUFBVSxDQUFDd0csaUJBQVosQ0FBcEIsQ0FBOUI7QUFDQTdILHlCQUFTLENBQUN3WCxjQUFWLElBQTRCaFgsTUFBNUI7O0FBQ0Esb0JBQUlSLFNBQVMsQ0FBQ3NMLGdCQUFWLElBQThCLENBQWxDLEVBQW9DO0FBQUU7QUFDbENtTSw2QkFBVyxJQUFLalgsTUFBTSxHQUFDUixTQUFTLENBQUN1WCxlQUFsQixHQUFxQ3ZYLFNBQVMsQ0FBQ3FMLE1BQTlEO0FBQ0g7QUFFSixlQVJELE1BUU87QUFDSCxvQkFBSXJMLFNBQVMsR0FBRy9CLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQ0Usa0NBQWdCLEVBQUVrQixVQUFVLENBQUN3RztBQUE5QixpQkFBbkIsQ0FBaEI7O0FBQ0Esb0JBQUk3SCxTQUFTLElBQUlBLFNBQVMsQ0FBQ3NMLGdCQUFWLElBQThCLENBQS9DLEVBQWlEO0FBQUU7QUFDL0NtTSw2QkFBVyxJQUFLalgsTUFBTSxHQUFDQyxVQUFVLENBQUNULFNBQVMsQ0FBQ3NMLGdCQUFYLENBQWxCLEdBQWtEN0ssVUFBVSxDQUFDVCxTQUFTLENBQUNxTCxNQUFYLENBQTNFO0FBQ0g7QUFDSjtBQUNKLGFBaEJEO0FBaUJIO0FBQ0o7QUFDSixPQXhCRCxDQXlCQSxPQUFPN00sQ0FBUCxFQUFTO0FBQ0xDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBQ0Q0WSxvQkFBYyxDQUFDRCxLQUFELENBQWQsR0FBd0I7QUFBQ00sbUJBQVcsRUFBRUE7QUFBZCxPQUF4QjtBQUNIO0FBQ0osR0FwQ0Q7QUFxQ0EsU0FBT3hJLEtBQUssQ0FBQ25MLEdBQU4sQ0FBV29ULElBQUQsSUFBVTtBQUN2QixRQUFJQyxLQUFLLEdBQUdDLGNBQWMsQ0FBQ0YsSUFBSSxDQUFDQyxLQUFOLENBQTFCO0FBQ0EsUUFBSU0sV0FBVyxHQUFHTixLQUFLLENBQUNNLFdBQXhCOztBQUNBLFFBQUlBLFdBQVcsSUFBSWxMLFNBQW5CLEVBQThCO0FBQzFCO0FBQ0FrTCxpQkFBVyxHQUFHTixLQUFLLENBQUNJLGVBQU4sR0FBd0JKLEtBQUssQ0FBQ0ssY0FBTixHQUFxQkwsS0FBSyxDQUFDSSxlQUE1QixHQUErQ0osS0FBSyxDQUFDOUwsTUFBNUUsR0FBb0YsQ0FBbEc7QUFDSDs7QUFDRCw2QkFBVzZMLElBQVg7QUFBaUJPO0FBQWpCO0FBQ0gsR0FSTSxDQUFQO0FBU0gsQ0FoRUQsQzs7Ozs7Ozs7Ozs7QUNwR0EsSUFBSTdaLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSW9ZLFNBQUo7QUFBY3RZLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGlCQUFaLEVBQThCO0FBQUNxWSxXQUFTLENBQUNwWSxDQUFELEVBQUc7QUFBQ29ZLGFBQVMsR0FBQ3BZLENBQVY7QUFBWTs7QUFBMUIsQ0FBOUIsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSW1YLEtBQUo7QUFBVXJYLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ29YLE9BQUssQ0FBQ25YLENBQUQsRUFBRztBQUFDbVgsU0FBSyxHQUFDblgsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUlySkgsTUFBTSxDQUFDbVcsT0FBUCxDQUFlLGdCQUFmLEVBQWlDLFlBQVk7QUFDekMsU0FBT29DLFNBQVMsQ0FBQ3pTLElBQVYsQ0FBZSxFQUFmLEVBQW1CO0FBQUNpQyxRQUFJLEVBQUM7QUFBQzJRLGdCQUFVLEVBQUMsQ0FBQztBQUFiO0FBQU4sR0FBbkIsQ0FBUDtBQUNILENBRkQ7QUFJQTFZLE1BQU0sQ0FBQ21XLE9BQVAsQ0FBZSxlQUFmLEVBQWdDLFVBQVVpQixFQUFWLEVBQWE7QUFDekNFLE9BQUssQ0FBQ0YsRUFBRCxFQUFLRyxNQUFMLENBQUw7QUFDQSxTQUFPZ0IsU0FBUyxDQUFDelMsSUFBVixDQUFlO0FBQUM0UyxjQUFVLEVBQUN0QjtBQUFaLEdBQWYsQ0FBUDtBQUNILENBSEQsRTs7Ozs7Ozs7Ozs7QUNSQW5YLE1BQU0sQ0FBQ3NRLE1BQVAsQ0FBYztBQUFDZ0ksV0FBUyxFQUFDLE1BQUlBO0FBQWYsQ0FBZDtBQUF5QyxJQUFJL0gsS0FBSjtBQUFVdlEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDc1EsT0FBSyxDQUFDclEsQ0FBRCxFQUFHO0FBQUNxUSxTQUFLLEdBQUNyUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRTVDLE1BQU1vWSxTQUFTLEdBQUcsSUFBSS9ILEtBQUssQ0FBQ0MsVUFBVixDQUFxQixXQUFyQixDQUFsQixDOzs7Ozs7Ozs7OztBQ0ZQLElBQUl6USxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlxUSxLQUFKO0FBQVV2USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNzUSxPQUFLLENBQUNyUSxDQUFELEVBQUc7QUFBQ3FRLFNBQUssR0FBQ3JRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSWlFLGdCQUFKLEVBQXFCQyxTQUFyQixFQUErQnlWLFdBQS9CLEVBQTJDQyxvQkFBM0M7QUFBZ0U5WixNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNrRSxrQkFBZ0IsQ0FBQ2pFLENBQUQsRUFBRztBQUFDaUUsb0JBQWdCLEdBQUNqRSxDQUFqQjtBQUFtQixHQUF4Qzs7QUFBeUNrRSxXQUFTLENBQUNsRSxDQUFELEVBQUc7QUFBQ2tFLGFBQVMsR0FBQ2xFLENBQVY7QUFBWSxHQUFsRTs7QUFBbUUyWixhQUFXLENBQUMzWixDQUFELEVBQUc7QUFBQzJaLGVBQVcsR0FBQzNaLENBQVo7QUFBYyxHQUFoRzs7QUFBaUc0WixzQkFBb0IsQ0FBQzVaLENBQUQsRUFBRztBQUFDNFosd0JBQW9CLEdBQUM1WixDQUFyQjtBQUF1Qjs7QUFBaEosQ0FBNUIsRUFBOEssQ0FBOUs7QUFBaUwsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBN0MsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSWdFLGFBQUo7QUFBa0JsRSxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQ0FBWixFQUE0RDtBQUFDaUUsZUFBYSxDQUFDaEUsQ0FBRCxFQUFHO0FBQUNnRSxpQkFBYSxHQUFDaEUsQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBNUQsRUFBZ0csQ0FBaEc7QUFBbUcsSUFBSTZaLE1BQUo7QUFBVy9aLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdCQUFaLEVBQXFDO0FBQUM4WixRQUFNLENBQUM3WixDQUFELEVBQUc7QUFBQzZaLFVBQU0sR0FBQzdaLENBQVA7QUFBUzs7QUFBcEIsQ0FBckMsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSThaLGlCQUFKO0FBQXNCaGEsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDK1osbUJBQWlCLENBQUM5WixDQUFELEVBQUc7QUFBQzhaLHFCQUFpQixHQUFDOVosQ0FBbEI7QUFBb0I7O0FBQTFDLENBQTVCLEVBQXdFLENBQXhFO0FBQTJFLElBQUkrWixZQUFKO0FBQWlCamEsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDZ2EsY0FBWSxDQUFDL1osQ0FBRCxFQUFHO0FBQUMrWixnQkFBWSxHQUFDL1osQ0FBYjtBQUFlOztBQUFoQyxDQUE1QixFQUE4RCxDQUE5RDtBQUFpRSxJQUFJOEQsU0FBSjtBQUFjaEUsTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQytELFdBQVMsQ0FBQzlELENBQUQsRUFBRztBQUFDOEQsYUFBUyxHQUFDOUQsQ0FBVjtBQUFZOztBQUExQixDQUFyQyxFQUFpRSxDQUFqRTtBQUFvRSxJQUFJK0QsS0FBSjtBQUFVakUsTUFBTSxDQUFDQyxJQUFQLENBQVksc0JBQVosRUFBbUM7QUFBQ2dFLE9BQUssQ0FBQy9ELENBQUQsRUFBRztBQUFDK0QsU0FBSyxHQUFDL0QsQ0FBTjtBQUFROztBQUFsQixDQUFuQyxFQUF1RCxDQUF2RDs7QUFBMEQsSUFBSWdhLENBQUo7O0FBQU1sYSxNQUFNLENBQUNDLElBQVAsQ0FBWSxRQUFaLEVBQXFCO0FBQUN1WCxTQUFPLENBQUN0WCxDQUFELEVBQUc7QUFBQ2dhLEtBQUMsR0FBQ2hhLENBQUY7QUFBSTs7QUFBaEIsQ0FBckIsRUFBdUMsRUFBdkM7QUFXdjlCLE1BQU1pYSxpQkFBaUIsR0FBRyxJQUExQjs7QUFFQSxNQUFNQyxhQUFhLEdBQUcsQ0FBQ3BTLFdBQUQsRUFBY3FTLFlBQWQsS0FBK0I7QUFDakQsTUFBSUMsVUFBVSxHQUFHLEVBQWpCO0FBQ0EsUUFBTUMsSUFBSSxHQUFHO0FBQUNDLFFBQUksRUFBRSxDQUNoQjtBQUFFclUsWUFBTSxFQUFFO0FBQUVzVSxXQUFHLEVBQUV6UztBQUFQO0FBQVYsS0FEZ0IsRUFFaEI7QUFBRTdCLFlBQU0sRUFBRTtBQUFFdVUsWUFBSSxFQUFFTDtBQUFSO0FBQVYsS0FGZ0I7QUFBUCxHQUFiO0FBR0EsUUFBTU0sT0FBTyxHQUFHO0FBQUM3UyxRQUFJLEVBQUM7QUFBQzNCLFlBQU0sRUFBRTtBQUFUO0FBQU4sR0FBaEI7QUFDQW5DLFdBQVMsQ0FBQzZCLElBQVYsQ0FBZTBVLElBQWYsRUFBcUJJLE9BQXJCLEVBQThCNVgsT0FBOUIsQ0FBdUNtRCxLQUFELElBQVc7QUFDN0NvVSxjQUFVLENBQUNwVSxLQUFLLENBQUNDLE1BQVAsQ0FBVixHQUEyQjtBQUN2QkEsWUFBTSxFQUFFRCxLQUFLLENBQUNDLE1BRFM7QUFFdkJMLHFCQUFlLEVBQUVJLEtBQUssQ0FBQ0osZUFGQTtBQUd2QnlFLHFCQUFlLEVBQUVyRSxLQUFLLENBQUNxRSxlQUhBO0FBSXZCSyxxQkFBZSxFQUFFMUUsS0FBSyxDQUFDMEUsZUFKQTtBQUt2QjlGLGdCQUFVLEVBQUVvQixLQUFLLENBQUNwQixVQUxLO0FBTXZCNUIsVUFBSSxFQUFFZ0QsS0FBSyxDQUFDaEQ7QUFOVyxLQUEzQjtBQVFILEdBVEQ7QUFXQWtCLFdBQVMsQ0FBQ3lCLElBQVYsQ0FBZTBVLElBQWYsRUFBcUJJLE9BQXJCLEVBQThCNVgsT0FBOUIsQ0FBdUNtRCxLQUFELElBQVc7QUFDN0MsUUFBSSxDQUFDb1UsVUFBVSxDQUFDcFUsS0FBSyxDQUFDQyxNQUFQLENBQWYsRUFBK0I7QUFDM0JtVSxnQkFBVSxDQUFDcFUsS0FBSyxDQUFDQyxNQUFQLENBQVYsR0FBMkI7QUFBRUEsY0FBTSxFQUFFRCxLQUFLLENBQUNDO0FBQWhCLE9BQTNCO0FBQ0F2RixhQUFPLENBQUNDLEdBQVIsaUJBQXFCcUYsS0FBSyxDQUFDQyxNQUEzQjtBQUNIOztBQUNEK1QsS0FBQyxDQUFDVSxNQUFGLENBQVNOLFVBQVUsQ0FBQ3BVLEtBQUssQ0FBQ0MsTUFBUCxDQUFuQixFQUFtQztBQUMvQnlELGdCQUFVLEVBQUUxRCxLQUFLLENBQUMwRCxVQURhO0FBRS9CNkMsc0JBQWdCLEVBQUV2RyxLQUFLLENBQUN1RyxnQkFGTztBQUcvQmpHLGNBQVEsRUFBRU4sS0FBSyxDQUFDTSxRQUhlO0FBSS9CMkUsa0JBQVksRUFBRWpGLEtBQUssQ0FBQ2lGO0FBSlcsS0FBbkM7QUFNSCxHQVhEO0FBWUEsU0FBT21QLFVBQVA7QUFDSCxDQTlCRDs7QUFnQ0EsTUFBTU8saUJBQWlCLEdBQUcsQ0FBQ0MsWUFBRCxFQUFlaFYsZUFBZixLQUFtQztBQUN6RCxNQUFJaVYsY0FBYyxHQUFHZCxZQUFZLENBQUM3WCxPQUFiLENBQ2pCO0FBQUNrWCxTQUFLLEVBQUN3QixZQUFQO0FBQXFCcEssWUFBUSxFQUFDNUssZUFBOUI7QUFBK0NrVixlQUFXLEVBQUUsQ0FBQztBQUE3RCxHQURpQixDQUFyQjtBQUVBLE1BQUlDLGlCQUFpQixHQUFHbGIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCRCxXQUEvQztBQUNBLE1BQUlrVCxTQUFTLEdBQUcsRUFBaEI7O0FBQ0EsTUFBSUgsY0FBSixFQUFvQjtBQUNoQkcsYUFBUyxHQUFHaEIsQ0FBQyxDQUFDaUIsSUFBRixDQUFPSixjQUFQLEVBQXVCLENBQUMsV0FBRCxFQUFjLFlBQWQsQ0FBdkIsQ0FBWjtBQUNILEdBRkQsTUFFTztBQUNIRyxhQUFTLEdBQUc7QUFDUkUsZUFBUyxFQUFFLENBREg7QUFFUkMsZ0JBQVUsRUFBRTtBQUZKLEtBQVo7QUFJSDs7QUFDRCxTQUFPSCxTQUFQO0FBQ0gsQ0FkRDs7QUFnQkFuYixNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLDRDQUEwQyxZQUFVO0FBQ2hELFFBQUksQ0FBQ3dhLGlCQUFMLEVBQXVCO0FBQ25CLFVBQUk7QUFDQSxZQUFJQyxTQUFTLEdBQUdwWSxJQUFJLENBQUNtVCxHQUFMLEVBQWhCO0FBQ0FnRix5QkFBaUIsR0FBRyxJQUFwQjtBQUNBMWEsZUFBTyxDQUFDQyxHQUFSLENBQVksOEJBQVo7QUFDQSxhQUFLRyxPQUFMO0FBQ0EsWUFBSThELFVBQVUsR0FBRzFFLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0JFLEtBQXBCLEVBQWpCO0FBQ0EsWUFBSXNVLFlBQVksR0FBR3RhLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSx5QkFBWixDQUFuQjtBQUNBLFlBQUlvVCxjQUFjLEdBQUd6QixNQUFNLENBQUMzWCxPQUFQLENBQWU7QUFBQ3lKLGlCQUFPLEVBQUU5TCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjZFO0FBQWpDLFNBQWYsQ0FBckI7QUFDQSxZQUFJN0QsV0FBVyxHQUFJd1QsY0FBYyxJQUFFQSxjQUFjLENBQUNDLDhCQUFoQyxHQUFnRUQsY0FBYyxDQUFDQyw4QkFBL0UsR0FBOEcxYixNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUJELFdBQXZKO0FBQ0FxUyxvQkFBWSxHQUFHak8sSUFBSSxDQUFDc1AsR0FBTCxDQUFTMVQsV0FBVyxHQUFHbVMsaUJBQXZCLEVBQTBDRSxZQUExQyxDQUFmO0FBQ0EsY0FBTXNCLGVBQWUsR0FBRzFCLFlBQVksQ0FBQ3ZULGFBQWIsR0FBNkJrVix1QkFBN0IsRUFBeEI7QUFFQSxZQUFJQyxhQUFhLEdBQUcsRUFBcEI7QUFDQS9XLGtCQUFVLENBQUMvQixPQUFYLENBQW9CWixTQUFELElBQWUwWixhQUFhLENBQUMxWixTQUFTLENBQUNwQixPQUFYLENBQWIsR0FBbUNvQixTQUFyRSxFQWJBLENBZUE7O0FBQ0EsWUFBSW1ZLFVBQVUsR0FBR0YsYUFBYSxDQUFDcFMsV0FBRCxFQUFjcVMsWUFBZCxDQUE5QixDQWhCQSxDQWtCQTs7QUFDQSxZQUFJeUIsa0JBQWtCLEdBQUcsRUFBekI7O0FBRUE1QixTQUFDLENBQUNuWCxPQUFGLENBQVV1WCxVQUFWLEVBQXNCLENBQUNwVSxLQUFELEVBQVE4VSxXQUFSLEtBQXdCO0FBQzFDLGNBQUlsVixlQUFlLEdBQUdJLEtBQUssQ0FBQ0osZUFBNUI7QUFDQSxjQUFJaVcsZUFBZSxHQUFHLElBQUlqRixHQUFKLENBQVE1USxLQUFLLENBQUNwQixVQUFkLENBQXRCO0FBQ0EsY0FBSWtYLGFBQWEsR0FBRzlYLGFBQWEsQ0FBQzlCLE9BQWQsQ0FBc0I7QUFBQ3NJLHdCQUFZLEVBQUN4RSxLQUFLLENBQUNDO0FBQXBCLFdBQXRCLENBQXBCO0FBQ0EsY0FBSThWLGdCQUFnQixHQUFHLENBQXZCO0FBRUFELHVCQUFhLENBQUNsWCxVQUFkLENBQXlCL0IsT0FBekIsQ0FBa0NtWixlQUFELElBQXFCO0FBQ2xELGdCQUFJSCxlQUFlLENBQUMzRSxHQUFoQixDQUFvQjhFLGVBQWUsQ0FBQ25iLE9BQXBDLENBQUosRUFDSWtiLGdCQUFnQixJQUFJclosVUFBVSxDQUFDc1osZUFBZSxDQUFDL1EsWUFBakIsQ0FBOUI7QUFDUCxXQUhEO0FBS0E2USx1QkFBYSxDQUFDbFgsVUFBZCxDQUF5Qi9CLE9BQXpCLENBQWtDbVosZUFBRCxJQUFxQjtBQUNsRCxnQkFBSUMsZ0JBQWdCLEdBQUdELGVBQWUsQ0FBQ25iLE9BQXZDOztBQUNBLGdCQUFJLENBQUNtWixDQUFDLENBQUM5QyxHQUFGLENBQU0wRSxrQkFBTixFQUEwQixDQUFDaFcsZUFBRCxFQUFrQnFXLGdCQUFsQixDQUExQixDQUFMLEVBQXFFO0FBQ2pFLGtCQUFJakIsU0FBUyxHQUFHTCxpQkFBaUIsQ0FBQ3NCLGdCQUFELEVBQW1CclcsZUFBbkIsQ0FBakM7O0FBQ0FvVSxlQUFDLENBQUNrQyxHQUFGLENBQU1OLGtCQUFOLEVBQTBCLENBQUNoVyxlQUFELEVBQWtCcVcsZ0JBQWxCLENBQTFCLEVBQStEakIsU0FBL0Q7QUFDSDs7QUFFRGhCLGFBQUMsQ0FBQzFOLE1BQUYsQ0FBU3NQLGtCQUFULEVBQTZCLENBQUNoVyxlQUFELEVBQWtCcVcsZ0JBQWxCLEVBQW9DLFlBQXBDLENBQTdCLEVBQWlGRSxDQUFELElBQU9BLENBQUMsR0FBQyxDQUF6Rjs7QUFDQSxnQkFBSSxDQUFDTixlQUFlLENBQUMzRSxHQUFoQixDQUFvQitFLGdCQUFwQixDQUFMLEVBQTRDO0FBQ3hDakMsZUFBQyxDQUFDMU4sTUFBRixDQUFTc1Asa0JBQVQsRUFBNkIsQ0FBQ2hXLGVBQUQsRUFBa0JxVyxnQkFBbEIsRUFBb0MsV0FBcEMsQ0FBN0IsRUFBZ0ZFLENBQUQsSUFBT0EsQ0FBQyxHQUFDLENBQXhGOztBQUNBViw2QkFBZSxDQUFDclIsTUFBaEIsQ0FBdUI7QUFDbkJnUCxxQkFBSyxFQUFFNkMsZ0JBRFk7QUFFbkJuQiwyQkFBVyxFQUFFOVUsS0FBSyxDQUFDQyxNQUZBO0FBR25CdUssd0JBQVEsRUFBRTVLLGVBSFM7QUFJbkJ5RSwrQkFBZSxFQUFFckUsS0FBSyxDQUFDcUUsZUFKSjtBQUtuQkssK0JBQWUsRUFBRTFFLEtBQUssQ0FBQzBFLGVBTEo7QUFNbkIxSCxvQkFBSSxFQUFFZ0QsS0FBSyxDQUFDaEQsSUFOTztBQU9uQjBHLDBCQUFVLEVBQUUxRCxLQUFLLENBQUMwRCxVQVBDO0FBUW5CNkMsZ0NBQWdCLEVBQUV2RyxLQUFLLENBQUN1RyxnQkFSTDtBQVNuQmpHLHdCQUFRLEVBQUVOLEtBQUssQ0FBQ00sUUFURztBQVVuQm9ULDJCQUFXLEVBQUUxVCxLQUFLLENBQUNpRixZQVZBO0FBV25COFEsZ0NBWG1CO0FBWW5COUMseUJBQVMsRUFBRWtCLFlBWlE7QUFhbkJlLHlCQUFTLEVBQUVsQixDQUFDLENBQUMxWixHQUFGLENBQU1zYixrQkFBTixFQUEwQixDQUFDaFcsZUFBRCxFQUFrQnFXLGdCQUFsQixFQUFvQyxXQUFwQyxDQUExQixDQWJRO0FBY25CZCwwQkFBVSxFQUFFbkIsQ0FBQyxDQUFDMVosR0FBRixDQUFNc2Isa0JBQU4sRUFBMEIsQ0FBQ2hXLGVBQUQsRUFBa0JxVyxnQkFBbEIsRUFBb0MsWUFBcEMsQ0FBMUI7QUFkTyxlQUF2QjtBQWdCSDtBQUNKLFdBM0JEO0FBNEJILFNBdkNEOztBQXlDQWpDLFNBQUMsQ0FBQ25YLE9BQUYsQ0FBVStZLGtCQUFWLEVBQThCLENBQUMxQyxNQUFELEVBQVN0VCxlQUFULEtBQTZCO0FBQ3ZEb1UsV0FBQyxDQUFDblgsT0FBRixDQUFVcVcsTUFBVixFQUFrQixDQUFDa0QsS0FBRCxFQUFReEIsWUFBUixLQUF5QjtBQUN2Q2EsMkJBQWUsQ0FBQzlWLElBQWhCLENBQXFCO0FBQ2pCeVQsbUJBQUssRUFBRXdCLFlBRFU7QUFFakJwSyxzQkFBUSxFQUFFNUssZUFGTztBQUdqQmtWLHlCQUFXLEVBQUUsQ0FBQztBQUhHLGFBQXJCLEVBSUd4UCxNQUpILEdBSVlDLFNBSlosQ0FJc0I7QUFBQ0Msa0JBQUksRUFBRTtBQUN6QjROLHFCQUFLLEVBQUV3QixZQURrQjtBQUV6QnBLLHdCQUFRLEVBQUU1SyxlQUZlO0FBR3pCa1YsMkJBQVcsRUFBRSxDQUFDLENBSFc7QUFJekI3Qix5QkFBUyxFQUFFa0IsWUFKYztBQUt6QmUseUJBQVMsRUFBRWxCLENBQUMsQ0FBQzFaLEdBQUYsQ0FBTThiLEtBQU4sRUFBYSxXQUFiLENBTGM7QUFNekJqQiwwQkFBVSxFQUFFbkIsQ0FBQyxDQUFDMVosR0FBRixDQUFNOGIsS0FBTixFQUFhLFlBQWI7QUFOYTtBQUFQLGFBSnRCO0FBWUgsV0FiRDtBQWNILFNBZkQ7O0FBaUJBLFlBQUl2RSxPQUFPLEdBQUcsRUFBZDs7QUFDQSxZQUFJNEQsZUFBZSxDQUFDN1osTUFBaEIsR0FBeUIsQ0FBN0IsRUFBK0I7QUFDM0IsZ0JBQU15YSxNQUFNLEdBQUd0QyxZQUFZLENBQUN1QyxPQUFiLENBQXFCQyxLQUFyQixDQUEyQkYsTUFBMUMsQ0FEMkIsQ0FFM0I7QUFDQTtBQUNBOztBQUNBLGNBQUlHLFdBQVcsR0FBR2YsZUFBZSxDQUFDM00sT0FBaEIsQ0FBd0I7QUFBSTtBQUE1QixZQUE2QzJOLElBQTdDLENBQ2Q1YyxNQUFNLENBQUM2YyxlQUFQLENBQXVCLENBQUN0YixNQUFELEVBQVM4SSxHQUFULEtBQWlCO0FBQ3BDLGdCQUFJQSxHQUFKLEVBQVE7QUFDSmtSLCtCQUFpQixHQUFHLEtBQXBCLENBREksQ0FFSjs7QUFDQSxvQkFBTWxSLEdBQU47QUFDSDs7QUFDRCxnQkFBSTlJLE1BQUosRUFBVztBQUNQO0FBQ0F5VyxxQkFBTyxHQUFHLFdBQUl6VyxNQUFNLENBQUNBLE1BQVAsQ0FBY3ViLFNBQWxCLDZCQUNJdmIsTUFBTSxDQUFDQSxNQUFQLENBQWN3YixTQURsQiw2QkFFSXhiLE1BQU0sQ0FBQ0EsTUFBUCxDQUFjeWIsU0FGbEIsZUFBVjtBQUdIO0FBQ0osV0FaRCxDQURjLENBQWxCO0FBZUFoWixpQkFBTyxDQUFDdUQsS0FBUixDQUFjb1YsV0FBZDtBQUNIOztBQUVEcEIseUJBQWlCLEdBQUcsS0FBcEI7QUFDQXZCLGNBQU0sQ0FBQ3ZPLE1BQVAsQ0FBYztBQUFDSyxpQkFBTyxFQUFFOUwsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI2RTtBQUFqQyxTQUFkLEVBQXlEO0FBQUNILGNBQUksRUFBQztBQUFDK1AsMENBQThCLEVBQUNwQixZQUFoQztBQUE4QzJDLHdDQUE0QixFQUFFLElBQUk3WixJQUFKO0FBQTVFO0FBQU4sU0FBekQ7QUFDQSxpQ0FBa0JBLElBQUksQ0FBQ21ULEdBQUwsS0FBYWlGLFNBQS9CLGdCQUE4Q3hELE9BQTlDO0FBQ0gsT0ExR0QsQ0EwR0UsT0FBT3BYLENBQVAsRUFBVTtBQUNSMmEseUJBQWlCLEdBQUcsS0FBcEI7QUFDQSxjQUFNM2EsQ0FBTjtBQUNIO0FBQ0osS0EvR0QsTUFnSEk7QUFDQSxhQUFPLGFBQVA7QUFDSDtBQUNKLEdBckhVO0FBc0hYLGlEQUErQyxZQUFVO0FBQ3JEO0FBQ0E7QUFDQSxRQUFJLENBQUNzYyxzQkFBTCxFQUE0QjtBQUN4QkEsNEJBQXNCLEdBQUcsSUFBekI7QUFDQXJjLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDhCQUFaO0FBQ0EsV0FBS0csT0FBTDtBQUNBLFVBQUk4RCxVQUFVLEdBQUcxRSxVQUFVLENBQUN5RixJQUFYLENBQWdCLEVBQWhCLEVBQW9CRSxLQUFwQixFQUFqQjtBQUNBLFVBQUlzVSxZQUFZLEdBQUd0YSxNQUFNLENBQUNxSSxJQUFQLENBQVkseUJBQVosQ0FBbkI7QUFDQSxVQUFJb1QsY0FBYyxHQUFHekIsTUFBTSxDQUFDM1gsT0FBUCxDQUFlO0FBQUN5SixlQUFPLEVBQUU5TCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjZFO0FBQWpDLE9BQWYsQ0FBckI7QUFDQSxVQUFJN0QsV0FBVyxHQUFJd1QsY0FBYyxJQUFFQSxjQUFjLENBQUMwQixxQkFBaEMsR0FBdUQxQixjQUFjLENBQUMwQixxQkFBdEUsR0FBNEZuZCxNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUJELFdBQXJJLENBUHdCLENBUXhCO0FBQ0E7O0FBQ0EsWUFBTTJULGVBQWUsR0FBRzNCLGlCQUFpQixDQUFDdFQsYUFBbEIsR0FBa0NvQyx5QkFBbEMsRUFBeEI7O0FBQ0EsV0FBS3JGLENBQUwsSUFBVXFCLFVBQVYsRUFBcUI7QUFDakI7QUFDQSxZQUFJZ1csWUFBWSxHQUFHaFcsVUFBVSxDQUFDckIsQ0FBRCxDQUFWLENBQWMxQyxPQUFqQztBQUNBLFlBQUlvYyxhQUFhLEdBQUdoWixnQkFBZ0IsQ0FBQzBCLElBQWpCLENBQXNCO0FBQ3RDOUUsaUJBQU8sRUFBQytaLFlBRDhCO0FBRXRDNVAsZ0JBQU0sRUFBQyxLQUYrQjtBQUd0Q3NQLGNBQUksRUFBRSxDQUFFO0FBQUVyVSxrQkFBTSxFQUFFO0FBQUVzVSxpQkFBRyxFQUFFelM7QUFBUDtBQUFWLFdBQUYsRUFBb0M7QUFBRTdCLGtCQUFNLEVBQUU7QUFBRXVVLGtCQUFJLEVBQUVMO0FBQVI7QUFBVixXQUFwQztBQUhnQyxTQUF0QixFQUlqQnRVLEtBSmlCLEVBQXBCO0FBTUEsWUFBSXFYLE1BQU0sR0FBRyxFQUFiLENBVGlCLENBV2pCOztBQUNBLGFBQUs3VyxDQUFMLElBQVU0VyxhQUFWLEVBQXdCO0FBQ3BCLGNBQUlqWCxLQUFLLEdBQUdsQyxTQUFTLENBQUM1QixPQUFWLENBQWtCO0FBQUMrRCxrQkFBTSxFQUFDZ1gsYUFBYSxDQUFDNVcsQ0FBRCxDQUFiLENBQWlCSjtBQUF6QixXQUFsQixDQUFaO0FBQ0EsY0FBSWtYLGNBQWMsR0FBR3JELGlCQUFpQixDQUFDNVgsT0FBbEIsQ0FBMEI7QUFBQ2tYLGlCQUFLLEVBQUN3QixZQUFQO0FBQXFCcEssb0JBQVEsRUFBQ3hLLEtBQUssQ0FBQ0o7QUFBcEMsV0FBMUIsQ0FBckI7O0FBRUEsY0FBSSxPQUFPc1gsTUFBTSxDQUFDbFgsS0FBSyxDQUFDSixlQUFQLENBQWIsS0FBeUMsV0FBN0MsRUFBeUQ7QUFDckQsZ0JBQUl1WCxjQUFKLEVBQW1CO0FBQ2ZELG9CQUFNLENBQUNsWCxLQUFLLENBQUNKLGVBQVAsQ0FBTixHQUFnQ3VYLGNBQWMsQ0FBQ3ZaLEtBQWYsR0FBcUIsQ0FBckQ7QUFDSCxhQUZELE1BR0k7QUFDQXNaLG9CQUFNLENBQUNsWCxLQUFLLENBQUNKLGVBQVAsQ0FBTixHQUFnQyxDQUFoQztBQUNIO0FBQ0osV0FQRCxNQVFJO0FBQ0FzWCxrQkFBTSxDQUFDbFgsS0FBSyxDQUFDSixlQUFQLENBQU47QUFDSDtBQUNKOztBQUVELGFBQUsvRSxPQUFMLElBQWdCcWMsTUFBaEIsRUFBdUI7QUFDbkIsY0FBSTFhLElBQUksR0FBRztBQUNQNFcsaUJBQUssRUFBRXdCLFlBREE7QUFFUHBLLG9CQUFRLEVBQUMzUCxPQUZGO0FBR1ArQyxpQkFBSyxFQUFFc1osTUFBTSxDQUFDcmMsT0FBRDtBQUhOLFdBQVg7QUFNQTRhLHlCQUFlLENBQUM5VixJQUFoQixDQUFxQjtBQUFDeVQsaUJBQUssRUFBQ3dCLFlBQVA7QUFBcUJwSyxvQkFBUSxFQUFDM1A7QUFBOUIsV0FBckIsRUFBNkR5SyxNQUE3RCxHQUFzRUMsU0FBdEUsQ0FBZ0Y7QUFBQ0MsZ0JBQUksRUFBQ2hKO0FBQU4sV0FBaEY7QUFDSCxTQXJDZ0IsQ0FzQ2pCOztBQUVIOztBQUVELFVBQUlpWixlQUFlLENBQUM3WixNQUFoQixHQUF5QixDQUE3QixFQUErQjtBQUMzQjZaLHVCQUFlLENBQUMzTSxPQUFoQixDQUF3QmpQLE1BQU0sQ0FBQzZjLGVBQVAsQ0FBdUIsQ0FBQ3hTLEdBQUQsRUFBTTlJLE1BQU4sS0FBaUI7QUFDNUQsY0FBSThJLEdBQUosRUFBUTtBQUNKNlMsa0NBQXNCLEdBQUcsS0FBekI7QUFDQXJjLG1CQUFPLENBQUNDLEdBQVIsQ0FBWXVKLEdBQVo7QUFDSDs7QUFDRCxjQUFJOUksTUFBSixFQUFXO0FBQ1B5WSxrQkFBTSxDQUFDdk8sTUFBUCxDQUFjO0FBQUNLLHFCQUFPLEVBQUU5TCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjZFO0FBQWpDLGFBQWQsRUFBeUQ7QUFBQ0gsa0JBQUksRUFBQztBQUFDd1IscUNBQXFCLEVBQUM3QyxZQUF2QjtBQUFxQ2lELG1DQUFtQixFQUFFLElBQUluYSxJQUFKO0FBQTFEO0FBQU4sYUFBekQ7QUFDQThaLGtDQUFzQixHQUFHLEtBQXpCO0FBQ0FyYyxtQkFBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUNIO0FBQ0osU0FWdUIsQ0FBeEI7QUFXSCxPQVpELE1BYUk7QUFDQW9jLDhCQUFzQixHQUFHLEtBQXpCO0FBQ0g7O0FBRUQsYUFBTyxJQUFQO0FBQ0gsS0F2RUQsTUF3RUk7QUFDQSxhQUFPLGFBQVA7QUFDSDtBQUNKLEdBcE1VO0FBcU1YLGdEQUE4QyxVQUFTL1osSUFBVCxFQUFjO0FBQ3hELFNBQUtsQyxPQUFMO0FBQ0EsUUFBSXNWLEdBQUcsR0FBRyxJQUFJblQsSUFBSixFQUFWOztBQUVBLFFBQUlELElBQUksSUFBSSxHQUFaLEVBQWdCO0FBQ1osVUFBSXVKLGdCQUFnQixHQUFHLENBQXZCO0FBQ0EsVUFBSThRLGtCQUFrQixHQUFHLENBQXpCO0FBRUEsVUFBSUMsU0FBUyxHQUFHcFosU0FBUyxDQUFDeUIsSUFBVixDQUFlO0FBQUUsZ0JBQVE7QUFBRTRVLGFBQUcsRUFBRSxJQUFJdFgsSUFBSixDQUFTQSxJQUFJLENBQUNtVCxHQUFMLEtBQWEsS0FBSyxJQUEzQjtBQUFQO0FBQVYsT0FBZixFQUFzRXZRLEtBQXRFLEVBQWhCOztBQUNBLFVBQUl5WCxTQUFTLENBQUMxYixNQUFWLEdBQW1CLENBQXZCLEVBQXlCO0FBQ3JCLGFBQUsyQixDQUFMLElBQVUrWixTQUFWLEVBQW9CO0FBQ2hCL1EsMEJBQWdCLElBQUkrUSxTQUFTLENBQUMvWixDQUFELENBQVQsQ0FBYStDLFFBQWpDO0FBQ0ErVyw0QkFBa0IsSUFBSUMsU0FBUyxDQUFDL1osQ0FBRCxDQUFULENBQWEwSCxZQUFuQztBQUNIOztBQUNEc0Isd0JBQWdCLEdBQUdBLGdCQUFnQixHQUFHK1EsU0FBUyxDQUFDMWIsTUFBaEQ7QUFDQXliLDBCQUFrQixHQUFHQSxrQkFBa0IsR0FBR0MsU0FBUyxDQUFDMWIsTUFBcEQ7QUFFQW1DLGFBQUssQ0FBQ3VJLE1BQU4sQ0FBYTtBQUFDWCxpQkFBTyxFQUFDOUwsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI2RTtBQUFoQyxTQUFiLEVBQXNEO0FBQUNILGNBQUksRUFBQztBQUFDK1IsaUNBQXFCLEVBQUNGLGtCQUF2QjtBQUEyQ0csK0JBQW1CLEVBQUNqUjtBQUEvRDtBQUFOLFNBQXREO0FBQ0FvTixtQkFBVyxDQUFDdlAsTUFBWixDQUFtQjtBQUNmbUMsMEJBQWdCLEVBQUVBLGdCQURIO0FBRWY4USw0QkFBa0IsRUFBRUEsa0JBRkw7QUFHZi9iLGNBQUksRUFBRTBCLElBSFM7QUFJZndULG1CQUFTLEVBQUVKO0FBSkksU0FBbkI7QUFNSDtBQUNKOztBQUNELFFBQUlwVCxJQUFJLElBQUksR0FBWixFQUFnQjtBQUNaLFVBQUl1SixnQkFBZ0IsR0FBRyxDQUF2QjtBQUNBLFVBQUk4USxrQkFBa0IsR0FBRyxDQUF6QjtBQUNBLFVBQUlDLFNBQVMsR0FBR3BaLFNBQVMsQ0FBQ3lCLElBQVYsQ0FBZTtBQUFFLGdCQUFRO0FBQUU0VSxhQUFHLEVBQUUsSUFBSXRYLElBQUosQ0FBU0EsSUFBSSxDQUFDbVQsR0FBTCxLQUFhLEtBQUcsRUFBSCxHQUFRLElBQTlCO0FBQVA7QUFBVixPQUFmLEVBQXlFdlEsS0FBekUsRUFBaEI7O0FBQ0EsVUFBSXlYLFNBQVMsQ0FBQzFiLE1BQVYsR0FBbUIsQ0FBdkIsRUFBeUI7QUFDckIsYUFBSzJCLENBQUwsSUFBVStaLFNBQVYsRUFBb0I7QUFDaEIvUSwwQkFBZ0IsSUFBSStRLFNBQVMsQ0FBQy9aLENBQUQsQ0FBVCxDQUFhK0MsUUFBakM7QUFDQStXLDRCQUFrQixJQUFJQyxTQUFTLENBQUMvWixDQUFELENBQVQsQ0FBYTBILFlBQW5DO0FBQ0g7O0FBQ0RzQix3QkFBZ0IsR0FBR0EsZ0JBQWdCLEdBQUcrUSxTQUFTLENBQUMxYixNQUFoRDtBQUNBeWIsMEJBQWtCLEdBQUdBLGtCQUFrQixHQUFHQyxTQUFTLENBQUMxYixNQUFwRDtBQUVBbUMsYUFBSyxDQUFDdUksTUFBTixDQUFhO0FBQUNYLGlCQUFPLEVBQUM5TCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjZFO0FBQWhDLFNBQWIsRUFBc0Q7QUFBQ0gsY0FBSSxFQUFDO0FBQUNpUywrQkFBbUIsRUFBQ0osa0JBQXJCO0FBQXlDSyw2QkFBaUIsRUFBQ25SO0FBQTNEO0FBQU4sU0FBdEQ7QUFDQW9OLG1CQUFXLENBQUN2UCxNQUFaLENBQW1CO0FBQ2ZtQywwQkFBZ0IsRUFBRUEsZ0JBREg7QUFFZjhRLDRCQUFrQixFQUFFQSxrQkFGTDtBQUdmL2IsY0FBSSxFQUFFMEIsSUFIUztBQUlmd1QsbUJBQVMsRUFBRUo7QUFKSSxTQUFuQjtBQU1IO0FBQ0o7O0FBRUQsUUFBSXBULElBQUksSUFBSSxHQUFaLEVBQWdCO0FBQ1osVUFBSXVKLGdCQUFnQixHQUFHLENBQXZCO0FBQ0EsVUFBSThRLGtCQUFrQixHQUFHLENBQXpCO0FBQ0EsVUFBSUMsU0FBUyxHQUFHcFosU0FBUyxDQUFDeUIsSUFBVixDQUFlO0FBQUUsZ0JBQVE7QUFBRTRVLGFBQUcsRUFBRSxJQUFJdFgsSUFBSixDQUFTQSxJQUFJLENBQUNtVCxHQUFMLEtBQWEsS0FBRyxFQUFILEdBQU0sRUFBTixHQUFXLElBQWpDO0FBQVA7QUFBVixPQUFmLEVBQTRFdlEsS0FBNUUsRUFBaEI7O0FBQ0EsVUFBSXlYLFNBQVMsQ0FBQzFiLE1BQVYsR0FBbUIsQ0FBdkIsRUFBeUI7QUFDckIsYUFBSzJCLENBQUwsSUFBVStaLFNBQVYsRUFBb0I7QUFDaEIvUSwwQkFBZ0IsSUFBSStRLFNBQVMsQ0FBQy9aLENBQUQsQ0FBVCxDQUFhK0MsUUFBakM7QUFDQStXLDRCQUFrQixJQUFJQyxTQUFTLENBQUMvWixDQUFELENBQVQsQ0FBYTBILFlBQW5DO0FBQ0g7O0FBQ0RzQix3QkFBZ0IsR0FBR0EsZ0JBQWdCLEdBQUcrUSxTQUFTLENBQUMxYixNQUFoRDtBQUNBeWIsMEJBQWtCLEdBQUdBLGtCQUFrQixHQUFHQyxTQUFTLENBQUMxYixNQUFwRDtBQUVBbUMsYUFBSyxDQUFDdUksTUFBTixDQUFhO0FBQUNYLGlCQUFPLEVBQUM5TCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjZFO0FBQWhDLFNBQWIsRUFBc0Q7QUFBQ0gsY0FBSSxFQUFDO0FBQUNtUyw4QkFBa0IsRUFBQ04sa0JBQXBCO0FBQXdDTyw0QkFBZ0IsRUFBQ3JSO0FBQXpEO0FBQU4sU0FBdEQ7QUFDQW9OLG1CQUFXLENBQUN2UCxNQUFaLENBQW1CO0FBQ2ZtQywwQkFBZ0IsRUFBRUEsZ0JBREg7QUFFZjhRLDRCQUFrQixFQUFFQSxrQkFGTDtBQUdmL2IsY0FBSSxFQUFFMEIsSUFIUztBQUlmd1QsbUJBQVMsRUFBRUo7QUFKSSxTQUFuQjtBQU1IO0FBQ0osS0FwRXVELENBc0V4RDs7QUFDSCxHQTVRVTtBQTZRWCxnREFBOEMsWUFBVTtBQUNwRCxTQUFLdFYsT0FBTDtBQUNBLFFBQUk4RCxVQUFVLEdBQUcxRSxVQUFVLENBQUN5RixJQUFYLENBQWdCLEVBQWhCLEVBQW9CRSxLQUFwQixFQUFqQjtBQUNBLFFBQUl1USxHQUFHLEdBQUcsSUFBSW5ULElBQUosRUFBVjs7QUFDQSxTQUFLTSxDQUFMLElBQVVxQixVQUFWLEVBQXFCO0FBQ2pCLFVBQUkySCxnQkFBZ0IsR0FBRyxDQUF2QjtBQUVBLFVBQUk3RyxNQUFNLEdBQUc1QixTQUFTLENBQUM2QixJQUFWLENBQWU7QUFBQ0MsdUJBQWUsRUFBQ2hCLFVBQVUsQ0FBQ3JCLENBQUQsQ0FBVixDQUFjMUMsT0FBL0I7QUFBd0MsZ0JBQVE7QUFBRTBaLGFBQUcsRUFBRSxJQUFJdFgsSUFBSixDQUFTQSxJQUFJLENBQUNtVCxHQUFMLEtBQWEsS0FBRyxFQUFILEdBQU0sRUFBTixHQUFXLElBQWpDO0FBQVA7QUFBaEQsT0FBZixFQUFpSDtBQUFDOUgsY0FBTSxFQUFDO0FBQUNySSxnQkFBTSxFQUFDO0FBQVI7QUFBUixPQUFqSCxFQUFzSUosS0FBdEksRUFBYjs7QUFFQSxVQUFJSCxNQUFNLENBQUM5RCxNQUFQLEdBQWdCLENBQXBCLEVBQXNCO0FBQ2xCLFlBQUlpYyxZQUFZLEdBQUcsRUFBbkI7O0FBQ0EsYUFBS3hYLENBQUwsSUFBVVgsTUFBVixFQUFpQjtBQUNibVksc0JBQVksQ0FBQ2hVLElBQWIsQ0FBa0JuRSxNQUFNLENBQUNXLENBQUQsQ0FBTixDQUFVSixNQUE1QjtBQUNIOztBQUVELFlBQUlxWCxTQUFTLEdBQUdwWixTQUFTLENBQUN5QixJQUFWLENBQWU7QUFBQ00sZ0JBQU0sRUFBRTtBQUFDRSxlQUFHLEVBQUMwWDtBQUFMO0FBQVQsU0FBZixFQUE2QztBQUFDdlAsZ0JBQU0sRUFBQztBQUFDckksa0JBQU0sRUFBQyxDQUFSO0FBQVVLLG9CQUFRLEVBQUM7QUFBbkI7QUFBUixTQUE3QyxFQUE2RVQsS0FBN0UsRUFBaEI7O0FBR0EsYUFBS2lZLENBQUwsSUFBVVIsU0FBVixFQUFvQjtBQUNoQi9RLDBCQUFnQixJQUFJK1EsU0FBUyxDQUFDUSxDQUFELENBQVQsQ0FBYXhYLFFBQWpDO0FBQ0g7O0FBRURpRyx3QkFBZ0IsR0FBR0EsZ0JBQWdCLEdBQUcrUSxTQUFTLENBQUMxYixNQUFoRDtBQUNIOztBQUVEZ1ksMEJBQW9CLENBQUN4UCxNQUFyQixDQUE0QjtBQUN4QnhFLHVCQUFlLEVBQUVoQixVQUFVLENBQUNyQixDQUFELENBQVYsQ0FBYzFDLE9BRFA7QUFFeEIwTCx3QkFBZ0IsRUFBRUEsZ0JBRk07QUFHeEJqTCxZQUFJLEVBQUUsZ0NBSGtCO0FBSXhCa1YsaUJBQVMsRUFBRUo7QUFKYSxPQUE1QjtBQU1IOztBQUVELFdBQU8sSUFBUDtBQUNIO0FBL1NVLENBQWYsRTs7Ozs7Ozs7Ozs7QUM3REEsSUFBSXZXLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSWlFLGdCQUFKLEVBQXFCQyxTQUFyQixFQUErQjZWLFlBQS9CLEVBQTRDRCxpQkFBNUMsRUFBOEQzVixlQUE5RDtBQUE4RXJFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ2tFLGtCQUFnQixDQUFDakUsQ0FBRCxFQUFHO0FBQUNpRSxvQkFBZ0IsR0FBQ2pFLENBQWpCO0FBQW1CLEdBQXhDOztBQUF5Q2tFLFdBQVMsQ0FBQ2xFLENBQUQsRUFBRztBQUFDa0UsYUFBUyxHQUFDbEUsQ0FBVjtBQUFZLEdBQWxFOztBQUFtRStaLGNBQVksQ0FBQy9aLENBQUQsRUFBRztBQUFDK1osZ0JBQVksR0FBQy9aLENBQWI7QUFBZSxHQUFsRzs7QUFBbUc4WixtQkFBaUIsQ0FBQzlaLENBQUQsRUFBRztBQUFDOFoscUJBQWlCLEdBQUM5WixDQUFsQjtBQUFvQixHQUE1STs7QUFBNkltRSxpQkFBZSxDQUFDbkUsQ0FBRCxFQUFHO0FBQUNtRSxtQkFBZSxHQUFDbkUsQ0FBaEI7QUFBa0I7O0FBQWxMLENBQTVCLEVBQWdOLENBQWhOO0FBQW1OLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBSWhYSCxNQUFNLENBQUNtVyxPQUFQLENBQWUsdUJBQWYsRUFBd0MsWUFBWTtBQUNoRCxTQUFPL1IsZ0JBQWdCLENBQUMwQixJQUFqQixFQUFQO0FBQ0gsQ0FGRDtBQUlBOUYsTUFBTSxDQUFDbVcsT0FBUCxDQUFlLDBCQUFmLEVBQTJDLFVBQVNuVixPQUFULEVBQWtCa2QsR0FBbEIsRUFBc0I7QUFDN0QsU0FBTzlaLGdCQUFnQixDQUFDMEIsSUFBakIsQ0FBc0I7QUFBQzlFLFdBQU8sRUFBQ0E7QUFBVCxHQUF0QixFQUF3QztBQUFDZ0gsU0FBSyxFQUFDa1csR0FBUDtBQUFZblcsUUFBSSxFQUFDO0FBQUMzQixZQUFNLEVBQUMsQ0FBQztBQUFUO0FBQWpCLEdBQXhDLENBQVA7QUFDSCxDQUZEO0FBSUFwRyxNQUFNLENBQUNtVyxPQUFQLENBQWUsbUJBQWYsRUFBb0MsWUFBVTtBQUMxQyxTQUFPOVIsU0FBUyxDQUFDeUIsSUFBVixDQUFlLEVBQWYsRUFBa0I7QUFBQ2lDLFFBQUksRUFBQztBQUFDM0IsWUFBTSxFQUFDLENBQUM7QUFBVCxLQUFOO0FBQWtCNEIsU0FBSyxFQUFDO0FBQXhCLEdBQWxCLENBQVA7QUFDSCxDQUZEO0FBSUFoSSxNQUFNLENBQUNtVyxPQUFQLENBQWUsdUJBQWYsRUFBd0MsWUFBVTtBQUM5QyxTQUFPN1IsZUFBZSxDQUFDd0IsSUFBaEIsQ0FBcUIsRUFBckIsRUFBd0I7QUFBQ2lDLFFBQUksRUFBQztBQUFDM0IsWUFBTSxFQUFDLENBQUM7QUFBVCxLQUFOO0FBQW1CNEIsU0FBSyxFQUFDO0FBQXpCLEdBQXhCLENBQVA7QUFDSCxDQUZEO0FBSUFxSSxnQkFBZ0IsQ0FBQyx3QkFBRCxFQUEyQixVQUFTclAsT0FBVCxFQUFrQlMsSUFBbEIsRUFBdUI7QUFDOUQsTUFBSTBjLFVBQVUsR0FBRyxFQUFqQjs7QUFDQSxNQUFJMWMsSUFBSSxJQUFJLE9BQVosRUFBb0I7QUFDaEIwYyxjQUFVLEdBQUc7QUFDVDVFLFdBQUssRUFBRXZZO0FBREUsS0FBYjtBQUdILEdBSkQsTUFLSTtBQUNBbWQsY0FBVSxHQUFHO0FBQ1R4TixjQUFRLEVBQUUzUDtBQURELEtBQWI7QUFHSDs7QUFDRCxTQUFPO0FBQ0g4RSxRQUFJLEdBQUU7QUFDRixhQUFPbVUsaUJBQWlCLENBQUNuVSxJQUFsQixDQUF1QnFZLFVBQXZCLENBQVA7QUFDSCxLQUhFOztBQUlIN04sWUFBUSxFQUFFLENBQ047QUFDSXhLLFVBQUksQ0FBQ3lXLEtBQUQsRUFBTztBQUNQLGVBQU9sYyxVQUFVLENBQUN5RixJQUFYLENBQ0gsRUFERyxFQUVIO0FBQUMySSxnQkFBTSxFQUFDO0FBQUN6TixtQkFBTyxFQUFDLENBQVQ7QUFBWXFNLHVCQUFXLEVBQUMsQ0FBeEI7QUFBMkJDLHVCQUFXLEVBQUM7QUFBdkM7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNO0FBSlAsR0FBUDtBQWVILENBM0JlLENBQWhCO0FBNkJBK0MsZ0JBQWdCLENBQUMseUJBQUQsRUFBNEIsVUFBU3JQLE9BQVQsRUFBa0JTLElBQWxCLEVBQXVCO0FBQy9ELFNBQU87QUFDSHFFLFFBQUksR0FBRTtBQUNGLGFBQU9vVSxZQUFZLENBQUNwVSxJQUFiLENBQ0g7QUFBQyxTQUFDckUsSUFBRCxHQUFRVDtBQUFULE9BREcsRUFFSDtBQUFDK0csWUFBSSxFQUFFO0FBQUNxUixtQkFBUyxFQUFFLENBQUM7QUFBYjtBQUFQLE9BRkcsQ0FBUDtBQUlILEtBTkU7O0FBT0g5SSxZQUFRLEVBQUUsQ0FDTjtBQUNJeEssVUFBSSxHQUFFO0FBQ0YsZUFBT3pGLFVBQVUsQ0FBQ3lGLElBQVgsQ0FDSCxFQURHLEVBRUg7QUFBQzJJLGdCQUFNLEVBQUM7QUFBQ3pOLG1CQUFPLEVBQUMsQ0FBVDtBQUFZcU0sdUJBQVcsRUFBQyxDQUF4QjtBQUEyQjlLLDRCQUFnQixFQUFDO0FBQTVDO0FBQVIsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FETTtBQVBQLEdBQVA7QUFrQkgsQ0FuQmUsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUNqREF0QyxNQUFNLENBQUNzUSxNQUFQLENBQWM7QUFBQ25NLGtCQUFnQixFQUFDLE1BQUlBLGdCQUF0QjtBQUF1Q0MsV0FBUyxFQUFDLE1BQUlBLFNBQXJEO0FBQStENFYsbUJBQWlCLEVBQUMsTUFBSUEsaUJBQXJGO0FBQXVHQyxjQUFZLEVBQUMsTUFBSUEsWUFBeEg7QUFBcUk1VixpQkFBZSxFQUFDLE1BQUlBLGVBQXpKO0FBQXlLd1YsYUFBVyxFQUFDLE1BQUlBLFdBQXpMO0FBQXFNQyxzQkFBb0IsRUFBQyxNQUFJQTtBQUE5TixDQUFkO0FBQW1RLElBQUl2SixLQUFKO0FBQVV2USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNzUSxPQUFLLENBQUNyUSxDQUFELEVBQUc7QUFBQ3FRLFNBQUssR0FBQ3JRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBdkMsRUFBcUUsQ0FBckU7QUFHdlUsTUFBTWlFLGdCQUFnQixHQUFHLElBQUlvTSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsbUJBQXJCLENBQXpCO0FBQ0EsTUFBTXBNLFNBQVMsR0FBRyxJQUFJbU0sS0FBSyxDQUFDQyxVQUFWLENBQXFCLFdBQXJCLENBQWxCO0FBQ0EsTUFBTXdKLGlCQUFpQixHQUFHLElBQUl6SixLQUFLLENBQUNDLFVBQVYsQ0FBcUIscUJBQXJCLENBQTFCO0FBQ0EsTUFBTXlKLFlBQVksR0FBRyxJQUFLMUosS0FBSyxDQUFDQyxVQUFYLENBQXNCLGVBQXRCLENBQXJCO0FBQ0EsTUFBTW5NLGVBQWUsR0FBRyxJQUFJa00sS0FBSyxDQUFDQyxVQUFWLENBQXFCLDRCQUFyQixDQUF4QjtBQUNBLE1BQU1xSixXQUFXLEdBQUcsSUFBSXRKLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixjQUFyQixDQUFwQjtBQUNBLE1BQU1zSixvQkFBb0IsR0FBRyxJQUFJdkosS0FBSyxDQUFDQyxVQUFWLENBQXFCLHdCQUFyQixDQUE3QjtBQUVQd0osaUJBQWlCLENBQUN2SixPQUFsQixDQUEwQjtBQUN0QjBOLGlCQUFlLEdBQUU7QUFDYixRQUFJaGMsU0FBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDckIsYUFBTyxFQUFDLEtBQUsyUDtBQUFkLEtBQW5CLENBQWhCO0FBQ0EsV0FBUXZPLFNBQVMsQ0FBQ2lMLFdBQVgsR0FBd0JqTCxTQUFTLENBQUNpTCxXQUFWLENBQXNCcU0sT0FBOUMsR0FBc0QsS0FBSy9JLFFBQWxFO0FBQ0gsR0FKcUI7O0FBS3RCME4sY0FBWSxHQUFFO0FBQ1YsUUFBSWpjLFNBQVMsR0FBRy9CLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQ3JCLGFBQU8sRUFBQyxLQUFLdVk7QUFBZCxLQUFuQixDQUFoQjtBQUNBLFdBQVFuWCxTQUFTLENBQUNpTCxXQUFYLEdBQXdCakwsU0FBUyxDQUFDaUwsV0FBVixDQUFzQnFNLE9BQTlDLEdBQXNELEtBQUtILEtBQWxFO0FBQ0g7O0FBUnFCLENBQTFCLEU7Ozs7Ozs7Ozs7O0FDWEEsSUFBSXZaLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSTZaLE1BQUo7QUFBVy9aLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQzhaLFFBQU0sQ0FBQzdaLENBQUQsRUFBRztBQUFDNlosVUFBTSxHQUFDN1osQ0FBUDtBQUFTOztBQUFwQixDQUEzQixFQUFpRCxDQUFqRDtBQUFvRCxJQUFJbVgsS0FBSjtBQUFVclgsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDb1gsT0FBSyxDQUFDblgsQ0FBRCxFQUFHO0FBQUNtWCxTQUFLLEdBQUNuWCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBSXpJSCxNQUFNLENBQUNtVyxPQUFQLENBQWUsZUFBZixFQUFnQyxZQUFZO0FBQ3hDLFNBQU82RCxNQUFNLENBQUNsVSxJQUFQLENBQVk7QUFBQ2dHLFdBQU8sRUFBQzlMLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNkU7QUFBaEMsR0FBWixDQUFQO0FBQ0gsQ0FGRCxFOzs7Ozs7Ozs7OztBQ0pBN0wsTUFBTSxDQUFDc1EsTUFBUCxDQUFjO0FBQUN5SixRQUFNLEVBQUMsTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUl4SixLQUFKO0FBQVV2USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNzUSxPQUFLLENBQUNyUSxDQUFELEVBQUc7QUFBQ3FRLFNBQUssR0FBQ3JRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFdEMsTUFBTTZaLE1BQU0sR0FBRyxJQUFJeEosS0FBSyxDQUFDQyxVQUFWLENBQXFCLFFBQXJCLENBQWYsQzs7Ozs7Ozs7Ozs7QUNGUCxJQUFJelEsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUlxRSxZQUFKO0FBQWlCdkUsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ3NFLGNBQVksQ0FBQ3JFLENBQUQsRUFBRztBQUFDcUUsZ0JBQVksR0FBQ3JFLENBQWI7QUFBZTs7QUFBaEMsQ0FBakQsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBN0MsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSW9FLGtCQUFKO0FBQXVCdEUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0JBQVosRUFBNEM7QUFBQ3FFLG9CQUFrQixDQUFDcEUsQ0FBRCxFQUFHO0FBQUNvRSxzQkFBa0IsR0FBQ3BFLENBQW5CO0FBQXFCOztBQUE1QyxDQUE1QyxFQUEwRixDQUExRjtBQU1uVixNQUFNbWUsYUFBYSxHQUFHLEVBQXRCO0FBRUF0ZSxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLHdCQUFzQixVQUFTc0ksSUFBVCxFQUFlNEMsU0FBZixFQUF5QjtBQUMzQyxTQUFLaEwsT0FBTDtBQUNBb0ksUUFBSSxHQUFHQSxJQUFJLENBQUNrVixXQUFMLEVBQVA7QUFDQSxRQUFJaGUsR0FBRyxHQUFHRyxHQUFHLEdBQUUsT0FBTCxHQUFhMkksSUFBdkI7QUFDQSxRQUFJbEksUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsUUFBSWllLEVBQUUsR0FBR3BkLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQVQ7QUFFQVQsV0FBTyxDQUFDQyxHQUFSLENBQVl1SSxJQUFaO0FBRUFtVixNQUFFLENBQUNwWSxNQUFILEdBQVl3RSxRQUFRLENBQUM0VCxFQUFFLENBQUNwWSxNQUFKLENBQXBCLENBVDJDLENBVzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBR0EsUUFBSXFZLElBQUksR0FBR2phLFlBQVksQ0FBQytGLE1BQWIsQ0FBb0JpVSxFQUFwQixDQUFYOztBQUNBLFFBQUlDLElBQUosRUFBUztBQUNMLGFBQU9BLElBQVA7QUFDSCxLQUZELE1BR0ssT0FBTyxLQUFQO0FBQ1IsR0E5RFU7QUErRFgsaUNBQStCLFVBQVN6ZCxPQUFULEVBQWtCb0YsTUFBbEIsRUFBeUI7QUFDcEQ7QUFDQSxXQUFPNUIsWUFBWSxDQUFDc0IsSUFBYixDQUFrQjtBQUNyQnhELFNBQUcsRUFBRSxDQUFDO0FBQUNtWSxZQUFJLEVBQUUsQ0FDVDtBQUFDLHlCQUFlO0FBQWhCLFNBRFMsRUFFVDtBQUFDLG1DQUF5QjtBQUExQixTQUZTLEVBR1Q7QUFBQyxxQ0FBMkJ6WjtBQUE1QixTQUhTO0FBQVAsT0FBRCxFQUlEO0FBQUN5WixZQUFJLEVBQUMsQ0FDTjtBQUFDLG1DQUF5QjtBQUExQixTQURNLEVBRU47QUFBQyxxQ0FBMkI7QUFBNUIsU0FGTSxFQUdOO0FBQUMsbUNBQXlCO0FBQTFCLFNBSE0sRUFJTjtBQUFDLHFDQUEyQnpaO0FBQTVCLFNBSk07QUFBTixPQUpDLEVBU0Q7QUFBQ3laLFlBQUksRUFBQyxDQUNOO0FBQUMseUJBQWU7QUFBaEIsU0FETSxFQUVOO0FBQUMsbUNBQXlCO0FBQTFCLFNBRk0sRUFHTjtBQUFDLHFDQUEyQnpaO0FBQTVCLFNBSE07QUFBTixPQVRDLEVBYUQ7QUFBQ3laLFlBQUksRUFBQyxDQUNOO0FBQUMseUJBQWU7QUFBaEIsU0FETSxFQUVOO0FBQUMsbUNBQXlCO0FBQTFCLFNBRk0sRUFHTjtBQUFDLHFDQUEyQnpaO0FBQTVCLFNBSE07QUFBTixPQWJDLEVBaUJEO0FBQUN5WixZQUFJLEVBQUMsQ0FDTjtBQUFDLHlCQUFlO0FBQWhCLFNBRE0sRUFFTjtBQUFDLG1DQUF5QjtBQUExQixTQUZNLEVBR047QUFBQyxxQ0FBMkJ6WjtBQUE1QixTQUhNO0FBQU4sT0FqQkMsQ0FEZ0I7QUF1QnJCLGNBQVE7QUFBQ2lLLGVBQU8sRUFBRTtBQUFWLE9BdkJhO0FBd0JyQjdFLFlBQU0sRUFBQztBQUFDc1ksV0FBRyxFQUFDdFk7QUFBTDtBQXhCYyxLQUFsQixFQXlCUDtBQUFDMkIsVUFBSSxFQUFDO0FBQUMzQixjQUFNLEVBQUMsQ0FBQztBQUFULE9BQU47QUFDSTRCLFdBQUssRUFBRTtBQURYLEtBekJPLEVBMkJMaEMsS0EzQkssRUFBUDtBQTRCSCxHQTdGVTtBQThGWCwyQkFBeUIsVUFBU2hGLE9BQVQsRUFBOEI7QUFBQSxRQUFaeU4sTUFBWSx1RUFBTCxJQUFLO0FBQ25EO0FBQ0EsUUFBSXJNLFNBQUo7QUFDQSxRQUFJLENBQUNxTSxNQUFMLEVBQ0lBLE1BQU0sR0FBRztBQUFDek4sYUFBTyxFQUFDLENBQVQ7QUFBWXFNLGlCQUFXLEVBQUMsQ0FBeEI7QUFBMkI5SyxzQkFBZ0IsRUFBQyxDQUE1QztBQUErQ0MsdUJBQWlCLEVBQUM7QUFBakUsS0FBVDs7QUFDSixRQUFJeEIsT0FBTyxDQUFDMmQsUUFBUixDQUFpQjNlLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCMlgsbUJBQXhDLENBQUosRUFBaUU7QUFDN0Q7QUFDQXhjLGVBQVMsR0FBRy9CLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQ0Usd0JBQWdCLEVBQUN2QjtBQUFsQixPQUFuQixFQUErQztBQUFDeU47QUFBRCxPQUEvQyxDQUFaO0FBQ0gsS0FIRCxNQUlLLElBQUl6TixPQUFPLENBQUMyZCxRQUFSLENBQWlCM2UsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI0WCxtQkFBeEMsQ0FBSixFQUFpRTtBQUNsRTtBQUNBemMsZUFBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDRyx5QkFBaUIsRUFBQ3hCO0FBQW5CLE9BQW5CLEVBQWdEO0FBQUN5TjtBQUFELE9BQWhELENBQVo7QUFDSCxLQUhJLE1BSUEsSUFBSXpOLE9BQU8sQ0FBQ2UsTUFBUixLQUFtQnVjLGFBQXZCLEVBQXNDO0FBQ3ZDbGMsZUFBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDckIsZUFBTyxFQUFDQTtBQUFULE9BQW5CLEVBQXNDO0FBQUN5TjtBQUFELE9BQXRDLENBQVo7QUFDSDs7QUFDRCxRQUFJck0sU0FBSixFQUFjO0FBQ1YsYUFBT0EsU0FBUDtBQUNIOztBQUNELFdBQU8sS0FBUDtBQUVIO0FBbkhVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNSQSxJQUFJcEMsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJcUUsWUFBSjtBQUFpQnZFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9CQUFaLEVBQWlDO0FBQUNzRSxjQUFZLENBQUNyRSxDQUFELEVBQUc7QUFBQ3FFLGdCQUFZLEdBQUNyRSxDQUFiO0FBQWU7O0FBQWhDLENBQWpDLEVBQW1FLENBQW5FO0FBQXNFLElBQUk4RCxTQUFKO0FBQWNoRSxNQUFNLENBQUNDLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDK0QsV0FBUyxDQUFDOUQsQ0FBRCxFQUFHO0FBQUM4RCxhQUFTLEdBQUM5RCxDQUFWO0FBQVk7O0FBQTFCLENBQXJDLEVBQWlFLENBQWpFO0FBS3JLa1EsZ0JBQWdCLENBQUMsbUJBQUQsRUFBc0IsWUFBb0I7QUFBQSxNQUFYckksS0FBVyx1RUFBSCxFQUFHO0FBQ3RELFNBQU87QUFDSGxDLFFBQUksR0FBRTtBQUNGLGFBQU90QixZQUFZLENBQUNzQixJQUFiLENBQWtCLEVBQWxCLEVBQXFCO0FBQUNpQyxZQUFJLEVBQUM7QUFBQzNCLGdCQUFNLEVBQUMsQ0FBQztBQUFULFNBQU47QUFBbUI0QixhQUFLLEVBQUNBO0FBQXpCLE9BQXJCLENBQVA7QUFDSCxLQUhFOztBQUlIc0ksWUFBUSxFQUFFLENBQ047QUFDSXhLLFVBQUksQ0FBQzBZLEVBQUQsRUFBSTtBQUNKLGVBQU92YSxTQUFTLENBQUM2QixJQUFWLENBQ0g7QUFBQ00sZ0JBQU0sRUFBQ29ZLEVBQUUsQ0FBQ3BZO0FBQVgsU0FERyxFQUVIO0FBQUNxSSxnQkFBTSxFQUFDO0FBQUN0TCxnQkFBSSxFQUFDLENBQU47QUFBU2lELGtCQUFNLEVBQUM7QUFBaEI7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNO0FBSlAsR0FBUDtBQWVILENBaEJlLENBQWhCO0FBa0JBaUssZ0JBQWdCLENBQUMsd0JBQUQsRUFBMkIsVUFBU3lPLGdCQUFULEVBQTJCQyxnQkFBM0IsRUFBdUQ7QUFBQSxNQUFWL1csS0FBVSx1RUFBSixHQUFJO0FBQzlGLE1BQUlnWCxLQUFLLEdBQUcsRUFBWjs7QUFDQSxNQUFJRixnQkFBZ0IsSUFBSUMsZ0JBQXhCLEVBQXlDO0FBQ3JDQyxTQUFLLEdBQUc7QUFBQzFjLFNBQUcsRUFBQyxDQUFDO0FBQUMsbUNBQTBCd2M7QUFBM0IsT0FBRCxFQUErQztBQUFDLG1DQUEwQkM7QUFBM0IsT0FBL0M7QUFBTCxLQUFSO0FBQ0g7O0FBRUQsTUFBSSxDQUFDRCxnQkFBRCxJQUFxQkMsZ0JBQXpCLEVBQTBDO0FBQ3RDQyxTQUFLLEdBQUc7QUFBQyxpQ0FBMEJEO0FBQTNCLEtBQVI7QUFDSDs7QUFFRCxTQUFPO0FBQ0hqWixRQUFJLEdBQUU7QUFDRixhQUFPdEIsWUFBWSxDQUFDc0IsSUFBYixDQUFrQmtaLEtBQWxCLEVBQXlCO0FBQUNqWCxZQUFJLEVBQUM7QUFBQzNCLGdCQUFNLEVBQUMsQ0FBQztBQUFULFNBQU47QUFBbUI0QixhQUFLLEVBQUNBO0FBQXpCLE9BQXpCLENBQVA7QUFDSCxLQUhFOztBQUlIc0ksWUFBUSxFQUFDLENBQ0w7QUFDSXhLLFVBQUksQ0FBQzBZLEVBQUQsRUFBSTtBQUNKLGVBQU92YSxTQUFTLENBQUM2QixJQUFWLENBQ0g7QUFBQ00sZ0JBQU0sRUFBQ29ZLEVBQUUsQ0FBQ3BZO0FBQVgsU0FERyxFQUVIO0FBQUNxSSxnQkFBTSxFQUFDO0FBQUN0TCxnQkFBSSxFQUFDLENBQU47QUFBU2lELGtCQUFNLEVBQUM7QUFBaEI7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURLO0FBSk4sR0FBUDtBQWVILENBekJlLENBQWhCO0FBMkJBaUssZ0JBQWdCLENBQUMsc0JBQUQsRUFBeUIsVUFBU2hILElBQVQsRUFBYztBQUNuRCxTQUFPO0FBQ0h2RCxRQUFJLEdBQUU7QUFDRixhQUFPdEIsWUFBWSxDQUFDc0IsSUFBYixDQUFrQjtBQUFDbVMsY0FBTSxFQUFDNU87QUFBUixPQUFsQixDQUFQO0FBQ0gsS0FIRTs7QUFJSGlILFlBQVEsRUFBRSxDQUNOO0FBQ0l4SyxVQUFJLENBQUMwWSxFQUFELEVBQUk7QUFDSixlQUFPdmEsU0FBUyxDQUFDNkIsSUFBVixDQUNIO0FBQUNNLGdCQUFNLEVBQUNvWSxFQUFFLENBQUNwWTtBQUFYLFNBREcsRUFFSDtBQUFDcUksZ0JBQU0sRUFBQztBQUFDdEwsZ0JBQUksRUFBQyxDQUFOO0FBQVNpRCxrQkFBTSxFQUFDO0FBQWhCO0FBQVIsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FETTtBQUpQLEdBQVA7QUFlSCxDQWhCZSxDQUFoQjtBQWtCQWlLLGdCQUFnQixDQUFDLHFCQUFELEVBQXdCLFVBQVNqSyxNQUFULEVBQWdCO0FBQ3BELFNBQU87QUFDSE4sUUFBSSxHQUFFO0FBQ0YsYUFBT3RCLFlBQVksQ0FBQ3NCLElBQWIsQ0FBa0I7QUFBQ00sY0FBTSxFQUFDQTtBQUFSLE9BQWxCLENBQVA7QUFDSCxLQUhFOztBQUlIa0ssWUFBUSxFQUFFLENBQ047QUFDSXhLLFVBQUksQ0FBQzBZLEVBQUQsRUFBSTtBQUNKLGVBQU92YSxTQUFTLENBQUM2QixJQUFWLENBQ0g7QUFBQ00sZ0JBQU0sRUFBQ29ZLEVBQUUsQ0FBQ3BZO0FBQVgsU0FERyxFQUVIO0FBQUNxSSxnQkFBTSxFQUFDO0FBQUN0TCxnQkFBSSxFQUFDLENBQU47QUFBU2lELGtCQUFNLEVBQUM7QUFBaEI7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNO0FBSlAsR0FBUDtBQWVILENBaEJlLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDcEVBbkcsTUFBTSxDQUFDc1EsTUFBUCxDQUFjO0FBQUMvTCxjQUFZLEVBQUMsTUFBSUE7QUFBbEIsQ0FBZDtBQUErQyxJQUFJZ00sS0FBSjtBQUFVdlEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDc1EsT0FBSyxDQUFDclEsQ0FBRCxFQUFHO0FBQUNxUSxTQUFLLEdBQUNyUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUk4RCxTQUFKO0FBQWNoRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDK0QsV0FBUyxDQUFDOUQsQ0FBRCxFQUFHO0FBQUM4RCxhQUFTLEdBQUM5RCxDQUFWO0FBQVk7O0FBQTFCLENBQWxDLEVBQThELENBQTlEO0FBQWlFLElBQUk4ZSxNQUFKO0FBQVdoZixNQUFNLENBQUNDLElBQVAsQ0FBWSwrQkFBWixFQUE0QztBQUFDK2UsUUFBTSxDQUFDOWUsQ0FBRCxFQUFHO0FBQUM4ZSxVQUFNLEdBQUM5ZSxDQUFQO0FBQVM7O0FBQXBCLENBQTVDLEVBQWtFLENBQWxFO0FBSTlMLE1BQU1xRSxZQUFZLEdBQUcsSUFBSWdNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixjQUFyQixDQUFyQjtBQUVQak0sWUFBWSxDQUFDa00sT0FBYixDQUFxQjtBQUNqQnZLLE9BQUssR0FBRTtBQUNILFdBQU9sQyxTQUFTLENBQUM1QixPQUFWLENBQWtCO0FBQUMrRCxZQUFNLEVBQUMsS0FBS0E7QUFBYixLQUFsQixDQUFQO0FBQ0g7O0FBSGdCLENBQXJCLEU7Ozs7Ozs7Ozs7O0FDTkEsSUFBSXBHLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXFFLFlBQUo7QUFBaUJ2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDc0UsY0FBWSxDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxnQkFBWSxHQUFDckUsQ0FBYjtBQUFlOztBQUFoQyxDQUFqRCxFQUFtRixDQUFuRjtBQUFzRixJQUFJOEQsU0FBSjtBQUFjaEUsTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQytELFdBQVMsQ0FBQzlELENBQUQsRUFBRztBQUFDOEQsYUFBUyxHQUFDOUQsQ0FBVjtBQUFZOztBQUExQixDQUFyQyxFQUFpRSxDQUFqRTtBQUFvRSxJQUFJc1csV0FBSjtBQUFnQnhXLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtDQUFaLEVBQStDO0FBQUN1VyxhQUFXLENBQUN0VyxDQUFELEVBQUc7QUFBQ3NXLGVBQVcsR0FBQ3RXLENBQVo7QUFBYzs7QUFBOUIsQ0FBL0MsRUFBK0UsQ0FBL0U7QUFLelFILE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsd0NBQXNDLFVBQVNDLE9BQVQsRUFBaUI7QUFDbkQ7QUFDQSxRQUFJd2QsRUFBRSxHQUFHaGEsWUFBWSxDQUFDbkMsT0FBYixDQUFxQjtBQUFDb1ksVUFBSSxFQUFDLENBQ2hDO0FBQUMsZ0RBQXVDelo7QUFBeEMsT0FEZ0MsRUFFaEM7QUFBQyw2QkFBb0I7QUFBckIsT0FGZ0MsRUFHaEM7QUFBQzZXLFlBQUksRUFBQztBQUFDNU0saUJBQU8sRUFBQztBQUFUO0FBQU4sT0FIZ0M7QUFBTixLQUFyQixDQUFUOztBQU1BLFFBQUl1VCxFQUFKLEVBQU87QUFDSCxVQUFJclksS0FBSyxHQUFHbEMsU0FBUyxDQUFDNUIsT0FBVixDQUFrQjtBQUFDK0QsY0FBTSxFQUFDb1ksRUFBRSxDQUFDcFk7QUFBWCxPQUFsQixDQUFaOztBQUNBLFVBQUlELEtBQUosRUFBVTtBQUNOLGVBQU9BLEtBQUssQ0FBQ2hELElBQWI7QUFDSDtBQUNKLEtBTEQsTUFNSTtBQUNBO0FBQ0EsYUFBTyxLQUFQO0FBQ0g7QUFDSixHQW5CVTs7QUFvQlg7QUFDQSxpQ0FBK0JuQyxPQUEvQixFQUF1QztBQUNuQyxRQUFJVCxHQUFHLEdBQUdHLEdBQUcsR0FBRyxzQkFBTixHQUE2Qk0sT0FBN0IsR0FBcUMsY0FBL0M7O0FBRUEsUUFBRztBQUNDLFVBQUlnQixXQUFXLEdBQUc1QixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFsQjs7QUFDQSxVQUFJeUIsV0FBVyxDQUFDckIsVUFBWixJQUEwQixHQUE5QixFQUFrQztBQUM5QnFCLG1CQUFXLEdBQUdaLElBQUksQ0FBQ0MsS0FBTCxDQUFXVyxXQUFXLENBQUNWLE9BQXZCLEVBQWdDQyxNQUE5QztBQUNBUyxtQkFBVyxDQUFDZ0IsT0FBWixDQUFvQixDQUFDUyxVQUFELEVBQWFDLENBQWIsS0FBbUI7QUFDbkMsY0FBSTFCLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxJQUFrQjFCLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxDQUFlZCxNQUFyQyxFQUNJWixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBZixHQUF3QkMsVUFBVSxDQUFDYixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBaEIsQ0FBbEM7QUFDUCxTQUhEO0FBS0EsZUFBT1osV0FBUDtBQUNIOztBQUFBO0FBQ0osS0FYRCxDQVlBLE9BQU9wQixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKOztBQXZDVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTEEsSUFBSVosTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUEvQixFQUE2RCxDQUE3RDtBQUFnRSxJQUFJaUUsZ0JBQUo7QUFBcUJuRSxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDa0Usa0JBQWdCLENBQUNqRSxDQUFELEVBQUc7QUFBQ2lFLG9CQUFnQixHQUFDakUsQ0FBakI7QUFBbUI7O0FBQXhDLENBQXZDLEVBQWlGLENBQWpGO0FBQW9GLElBQUlvRSxrQkFBSjtBQUF1QnRFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtCQUFaLEVBQTRDO0FBQUNxRSxvQkFBa0IsQ0FBQ3BFLENBQUQsRUFBRztBQUFDb0Usc0JBQWtCLEdBQUNwRSxDQUFuQjtBQUFxQjs7QUFBNUMsQ0FBNUMsRUFBMEYsQ0FBMUY7QUFLL1FILE1BQU0sQ0FBQ21XLE9BQVAsQ0FBZSxnQkFBZixFQUFpQyxZQUFtRTtBQUFBLE1BQXpEcE8sSUFBeUQsdUVBQWxELHFCQUFrRDtBQUFBLE1BQTNCbVgsU0FBMkIsdUVBQWYsQ0FBQyxDQUFjO0FBQUEsTUFBWHpRLE1BQVcsdUVBQUosRUFBSTtBQUNoRyxTQUFPcE8sVUFBVSxDQUFDeUYsSUFBWCxDQUFnQixFQUFoQixFQUFvQjtBQUFDaUMsUUFBSSxFQUFFO0FBQUMsT0FBQ0EsSUFBRCxHQUFRbVg7QUFBVCxLQUFQO0FBQTRCelEsVUFBTSxFQUFFQTtBQUFwQyxHQUFwQixDQUFQO0FBQ0gsQ0FGRDtBQUlBNEIsZ0JBQWdCLENBQUMsc0JBQUQsRUFBd0I7QUFDcEN2SyxNQUFJLEdBQUc7QUFDSCxXQUFPekYsVUFBVSxDQUFDeUYsSUFBWCxDQUFnQixFQUFoQixDQUFQO0FBQ0gsR0FIbUM7O0FBSXBDd0ssVUFBUSxFQUFFLENBQ047QUFDSXhLLFFBQUksQ0FBQ3FaLEdBQUQsRUFBTTtBQUNOLGFBQU8vYSxnQkFBZ0IsQ0FBQzBCLElBQWpCLENBQ0g7QUFBRTlFLGVBQU8sRUFBRW1lLEdBQUcsQ0FBQ25lO0FBQWYsT0FERyxFQUVIO0FBQUUrRyxZQUFJLEVBQUU7QUFBQzNCLGdCQUFNLEVBQUU7QUFBVCxTQUFSO0FBQXFCNEIsYUFBSyxFQUFFO0FBQTVCLE9BRkcsQ0FBUDtBQUlIOztBQU5MLEdBRE07QUFKMEIsQ0FBeEIsQ0FBaEI7QUFnQkFoSSxNQUFNLENBQUNtVyxPQUFQLENBQWUseUJBQWYsRUFBMEMsWUFBVTtBQUNoRCxTQUFPOVYsVUFBVSxDQUFDeUYsSUFBWCxDQUFnQjtBQUNuQjZCLFVBQU0sRUFBRSxDQURXO0FBRW5CNEYsVUFBTSxFQUFDO0FBRlksR0FBaEIsRUFHTDtBQUNFeEYsUUFBSSxFQUFDO0FBQ0RxRCxrQkFBWSxFQUFDLENBQUM7QUFEYixLQURQO0FBSUVxRCxVQUFNLEVBQUM7QUFDSHpOLGFBQU8sRUFBRSxDQUROO0FBRUhxTSxpQkFBVyxFQUFDLENBRlQ7QUFHSGpDLGtCQUFZLEVBQUMsQ0FIVjtBQUlIa0MsaUJBQVcsRUFBQztBQUpUO0FBSlQsR0FISyxDQUFQO0FBZUgsQ0FoQkQ7QUFrQkErQyxnQkFBZ0IsQ0FBQyxtQkFBRCxFQUFzQixVQUFTclAsT0FBVCxFQUFpQjtBQUNuRCxNQUFJNFosT0FBTyxHQUFHO0FBQUM1WixXQUFPLEVBQUNBO0FBQVQsR0FBZDs7QUFDQSxNQUFJQSxPQUFPLENBQUN3RSxPQUFSLENBQWdCeEYsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUIyWCxtQkFBdkMsS0FBK0QsQ0FBQyxDQUFwRSxFQUFzRTtBQUNsRWhFLFdBQU8sR0FBRztBQUFDclksc0JBQWdCLEVBQUN2QjtBQUFsQixLQUFWO0FBQ0g7O0FBQ0QsU0FBTztBQUNIOEUsUUFBSSxHQUFFO0FBQ0YsYUFBT3pGLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0I4VSxPQUFoQixDQUFQO0FBQ0gsS0FIRTs7QUFJSHRLLFlBQVEsRUFBRSxDQUNOO0FBQ0l4SyxVQUFJLENBQUNxWixHQUFELEVBQUs7QUFDTCxlQUFPNWEsa0JBQWtCLENBQUN1QixJQUFuQixDQUNIO0FBQUM5RSxpQkFBTyxFQUFDbWUsR0FBRyxDQUFDbmU7QUFBYixTQURHLEVBRUg7QUFBQytHLGNBQUksRUFBQztBQUFDM0Isa0JBQU0sRUFBQyxDQUFDO0FBQVQsV0FBTjtBQUFtQjRCLGVBQUssRUFBQztBQUF6QixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNLEVBU047QUFDSWxDLFVBQUksQ0FBQ3FaLEdBQUQsRUFBTTtBQUNOLGVBQU8vYSxnQkFBZ0IsQ0FBQzBCLElBQWpCLENBQ0g7QUFBRTlFLGlCQUFPLEVBQUVtZSxHQUFHLENBQUNuZTtBQUFmLFNBREcsRUFFSDtBQUFFK0csY0FBSSxFQUFFO0FBQUMzQixrQkFBTSxFQUFFLENBQUM7QUFBVixXQUFSO0FBQXNCNEIsZUFBSyxFQUFFaEksTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJDO0FBQXBELFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBVE07QUFKUCxHQUFQO0FBdUJILENBNUJlLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDM0NBakgsTUFBTSxDQUFDc1EsTUFBUCxDQUFjO0FBQUNsUSxZQUFVLEVBQUMsTUFBSUE7QUFBaEIsQ0FBZDtBQUEyQyxJQUFJbVEsS0FBSjtBQUFVdlEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDc1EsT0FBSyxDQUFDclEsQ0FBRCxFQUFHO0FBQUNxUSxTQUFLLEdBQUNyUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlpRSxnQkFBSjtBQUFxQm5FLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVCQUFaLEVBQW9DO0FBQUNrRSxrQkFBZ0IsQ0FBQ2pFLENBQUQsRUFBRztBQUFDaUUsb0JBQWdCLEdBQUNqRSxDQUFqQjtBQUFtQjs7QUFBeEMsQ0FBcEMsRUFBOEUsQ0FBOUU7QUFBaUYsSUFBSW9FLGtCQUFKO0FBQXVCdEUsTUFBTSxDQUFDQyxJQUFQLENBQVksNEJBQVosRUFBeUM7QUFBQ3FFLG9CQUFrQixDQUFDcEUsQ0FBRCxFQUFHO0FBQUNvRSxzQkFBa0IsR0FBQ3BFLENBQW5CO0FBQXFCOztBQUE1QyxDQUF6QyxFQUF1RixDQUF2RjtBQUk3TixNQUFNRSxVQUFVLEdBQUcsSUFBSW1RLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixZQUFyQixDQUFuQjtBQUVQcFEsVUFBVSxDQUFDcVEsT0FBWCxDQUFtQjtBQUNmME8sV0FBUyxHQUFFO0FBQ1AsV0FBT2hiLGdCQUFnQixDQUFDL0IsT0FBakIsQ0FBeUI7QUFBQ3JCLGFBQU8sRUFBQyxLQUFLQTtBQUFkLEtBQXpCLENBQVA7QUFDSCxHQUhjOztBQUlmcWUsU0FBTyxHQUFFO0FBQ0wsV0FBTzlhLGtCQUFrQixDQUFDdUIsSUFBbkIsQ0FBd0I7QUFBQzlFLGFBQU8sRUFBQyxLQUFLQTtBQUFkLEtBQXhCLEVBQWdEO0FBQUMrRyxVQUFJLEVBQUM7QUFBQzNCLGNBQU0sRUFBQyxDQUFDO0FBQVQsT0FBTjtBQUFtQjRCLFdBQUssRUFBQztBQUF6QixLQUFoRCxFQUE4RWhDLEtBQTlFLEVBQVA7QUFDSDs7QUFOYyxDQUFuQixFLENBUUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzQkEvRixNQUFNLENBQUNzUSxNQUFQLENBQWM7QUFBQ2hNLG9CQUFrQixFQUFDLE1BQUlBO0FBQXhCLENBQWQ7QUFBMkQsSUFBSWlNLEtBQUo7QUFBVXZRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3NRLE9BQUssQ0FBQ3JRLENBQUQsRUFBRztBQUFDcVEsU0FBSyxHQUFDclEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUU5RCxNQUFNb0Usa0JBQWtCLEdBQUcsSUFBSWlNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixzQkFBckIsQ0FBM0IsQzs7Ozs7Ozs7Ozs7QUNGUHhRLE1BQU0sQ0FBQ3NRLE1BQVAsQ0FBYztBQUFDOUwsV0FBUyxFQUFDLE1BQUlBO0FBQWYsQ0FBZDtBQUF5QyxJQUFJK0wsS0FBSjtBQUFVdlEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDc1EsT0FBSyxDQUFDclEsQ0FBRCxFQUFHO0FBQUNxUSxTQUFLLEdBQUNyUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRTVDLE1BQU1zRSxTQUFTLEdBQUcsSUFBSStMLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixXQUFyQixDQUFsQixDOzs7Ozs7Ozs7OztBQ0ZQeFEsTUFBTSxDQUFDc1EsTUFBUCxDQUFjO0FBQUNwTSxlQUFhLEVBQUMsTUFBSUE7QUFBbkIsQ0FBZDtBQUFpRCxJQUFJcU0sS0FBSjtBQUFVdlEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDc1EsT0FBSyxDQUFDclEsQ0FBRCxFQUFHO0FBQUNxUSxTQUFLLEdBQUNyUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRXBELE1BQU1nRSxhQUFhLEdBQUcsSUFBSXFNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixnQkFBckIsQ0FBdEIsQzs7Ozs7Ozs7Ozs7QUNGUDtBQUNBLHdDOzs7Ozs7Ozs7OztBQ0RBLElBQUl4TSxTQUFKO0FBQWNoRSxNQUFNLENBQUNDLElBQVAsQ0FBWSw0QkFBWixFQUF5QztBQUFDK0QsV0FBUyxDQUFDOUQsQ0FBRCxFQUFHO0FBQUM4RCxhQUFTLEdBQUM5RCxDQUFWO0FBQVk7O0FBQTFCLENBQXpDLEVBQXFFLENBQXJFO0FBQXdFLElBQUlvWSxTQUFKO0FBQWN0WSxNQUFNLENBQUNDLElBQVAsQ0FBWSxrQ0FBWixFQUErQztBQUFDcVksV0FBUyxDQUFDcFksQ0FBRCxFQUFHO0FBQUNvWSxhQUFTLEdBQUNwWSxDQUFWO0FBQVk7O0FBQTFCLENBQS9DLEVBQTJFLENBQTNFO0FBQThFLElBQUlpRSxnQkFBSixFQUFxQkMsU0FBckIsRUFBK0I0VixpQkFBL0IsRUFBaURDLFlBQWpELEVBQThESixXQUE5RCxFQUEwRUMsb0JBQTFFO0FBQStGOVosTUFBTSxDQUFDQyxJQUFQLENBQVksOEJBQVosRUFBMkM7QUFBQ2tFLGtCQUFnQixDQUFDakUsQ0FBRCxFQUFHO0FBQUNpRSxvQkFBZ0IsR0FBQ2pFLENBQWpCO0FBQW1CLEdBQXhDOztBQUF5Q2tFLFdBQVMsQ0FBQ2xFLENBQUQsRUFBRztBQUFDa0UsYUFBUyxHQUFDbEUsQ0FBVjtBQUFZLEdBQWxFOztBQUFtRThaLG1CQUFpQixDQUFDOVosQ0FBRCxFQUFHO0FBQUM4WixxQkFBaUIsR0FBQzlaLENBQWxCO0FBQW9CLEdBQTVHOztBQUE2RytaLGNBQVksQ0FBQy9aLENBQUQsRUFBRztBQUFDK1osZ0JBQVksR0FBQy9aLENBQWI7QUFBZSxHQUE1STs7QUFBNkkyWixhQUFXLENBQUMzWixDQUFELEVBQUc7QUFBQzJaLGVBQVcsR0FBQzNaLENBQVo7QUFBYyxHQUExSzs7QUFBMks0WixzQkFBb0IsQ0FBQzVaLENBQUQsRUFBRztBQUFDNFosd0JBQW9CLEdBQUM1WixDQUFyQjtBQUF1Qjs7QUFBMU4sQ0FBM0MsRUFBdVEsQ0FBdlE7QUFBMFEsSUFBSXFFLFlBQUo7QUFBaUJ2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSx3Q0FBWixFQUFxRDtBQUFDc0UsY0FBWSxDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxnQkFBWSxHQUFDckUsQ0FBYjtBQUFlOztBQUFoQyxDQUFyRCxFQUF1RixDQUF2RjtBQUEwRixJQUFJZ0UsYUFBSjtBQUFrQmxFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDRDQUFaLEVBQXlEO0FBQUNpRSxlQUFhLENBQUNoRSxDQUFELEVBQUc7QUFBQ2dFLGlCQUFhLEdBQUNoRSxDQUFkO0FBQWdCOztBQUFsQyxDQUF6RCxFQUE2RixDQUE3RjtBQUFnRyxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUFqRCxFQUErRSxDQUEvRTtBQUFrRixJQUFJb0Usa0JBQUo7QUFBdUJ0RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQ0FBWixFQUFnRDtBQUFDcUUsb0JBQWtCLENBQUNwRSxDQUFELEVBQUc7QUFBQ29FLHNCQUFrQixHQUFDcEUsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQWhELEVBQThGLENBQTlGO0FBQWlHLElBQUlzRSxTQUFKO0FBQWN4RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxrQ0FBWixFQUErQztBQUFDdUUsV0FBUyxDQUFDdEUsQ0FBRCxFQUFHO0FBQUNzRSxhQUFTLEdBQUN0RSxDQUFWO0FBQVk7O0FBQTFCLENBQS9DLEVBQTJFLENBQTNFO0FBQThFLElBQUkrVixTQUFKO0FBQWNqVyxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDZ1csV0FBUyxDQUFDL1YsQ0FBRCxFQUFHO0FBQUMrVixhQUFTLEdBQUMvVixDQUFWO0FBQVk7O0FBQTFCLENBQWpELEVBQTZFLENBQTdFO0FBQWdGLElBQUl5USxXQUFKO0FBQWdCM1EsTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQzBRLGFBQVcsQ0FBQ3pRLENBQUQsRUFBRztBQUFDeVEsZUFBVyxHQUFDelEsQ0FBWjtBQUFjOztBQUE5QixDQUF2QyxFQUF1RSxDQUF2RTtBQVkzcEN5USxXQUFXLENBQUNqSyxhQUFaLEdBQTRCMlksV0FBNUIsQ0FBd0M7QUFBQ2xaLFFBQU0sRUFBRSxDQUFDO0FBQVYsQ0FBeEMsRUFBcUQ7QUFBQ21aLFFBQU0sRUFBQztBQUFSLENBQXJEO0FBRUF0YixTQUFTLENBQUMwQyxhQUFWLEdBQTBCMlksV0FBMUIsQ0FBc0M7QUFBQ2xaLFFBQU0sRUFBRSxDQUFDO0FBQVYsQ0FBdEMsRUFBbUQ7QUFBQ21aLFFBQU0sRUFBQztBQUFSLENBQW5EO0FBQ0F0YixTQUFTLENBQUMwQyxhQUFWLEdBQTBCMlksV0FBMUIsQ0FBc0M7QUFBQ3ZaLGlCQUFlLEVBQUM7QUFBakIsQ0FBdEM7QUFFQXRCLFNBQVMsQ0FBQ2tDLGFBQVYsR0FBMEIyWSxXQUExQixDQUFzQztBQUFDbFosUUFBTSxFQUFFLENBQUM7QUFBVixDQUF0QyxFLENBRUE7O0FBRUFoQyxnQkFBZ0IsQ0FBQ3VDLGFBQWpCLEdBQWlDMlksV0FBakMsQ0FBNkM7QUFBQ3RlLFNBQU8sRUFBQyxDQUFUO0FBQVdvRixRQUFNLEVBQUUsQ0FBQztBQUFwQixDQUE3QyxFQUFxRTtBQUFDbVosUUFBTSxFQUFDO0FBQVIsQ0FBckU7QUFDQW5iLGdCQUFnQixDQUFDdUMsYUFBakIsR0FBaUMyWSxXQUFqQyxDQUE2QztBQUFDdGUsU0FBTyxFQUFDLENBQVQ7QUFBV21LLFFBQU0sRUFBQyxDQUFsQjtBQUFxQi9FLFFBQU0sRUFBRSxDQUFDO0FBQTlCLENBQTdDO0FBRUEvQixTQUFTLENBQUNzQyxhQUFWLEdBQTBCMlksV0FBMUIsQ0FBc0M7QUFBQ2xaLFFBQU0sRUFBRSxDQUFDO0FBQVYsQ0FBdEMsRUFBb0Q7QUFBQ21aLFFBQU0sRUFBQztBQUFSLENBQXBEO0FBRUFyRixZQUFZLENBQUN2VCxhQUFiLEdBQTZCMlksV0FBN0IsQ0FBeUM7QUFBQzNPLFVBQVEsRUFBQyxDQUFWO0FBQWE0SSxPQUFLLEVBQUMsQ0FBbkI7QUFBc0JILFdBQVMsRUFBRSxDQUFDO0FBQWxDLENBQXpDO0FBQ0FjLFlBQVksQ0FBQ3ZULGFBQWIsR0FBNkIyWSxXQUE3QixDQUF5QztBQUFDM08sVUFBUSxFQUFDLENBQVY7QUFBYXNLLGFBQVcsRUFBQyxDQUFDO0FBQTFCLENBQXpDO0FBQ0FmLFlBQVksQ0FBQ3ZULGFBQWIsR0FBNkIyWSxXQUE3QixDQUF5QztBQUFDL0YsT0FBSyxFQUFDLENBQVA7QUFBVTBCLGFBQVcsRUFBQyxDQUFDO0FBQXZCLENBQXpDO0FBQ0FmLFlBQVksQ0FBQ3ZULGFBQWIsR0FBNkIyWSxXQUE3QixDQUF5QztBQUFDL0YsT0FBSyxFQUFDLENBQVA7QUFBVTVJLFVBQVEsRUFBQyxDQUFuQjtBQUFzQnNLLGFBQVcsRUFBQyxDQUFDO0FBQW5DLENBQXpDLEVBQWdGO0FBQUNzRSxRQUFNLEVBQUM7QUFBUixDQUFoRjtBQUVBdEYsaUJBQWlCLENBQUN0VCxhQUFsQixHQUFrQzJZLFdBQWxDLENBQThDO0FBQUMzTyxVQUFRLEVBQUM7QUFBVixDQUE5QztBQUNBc0osaUJBQWlCLENBQUN0VCxhQUFsQixHQUFrQzJZLFdBQWxDLENBQThDO0FBQUMvRixPQUFLLEVBQUM7QUFBUCxDQUE5QztBQUNBVSxpQkFBaUIsQ0FBQ3RULGFBQWxCLEdBQWtDMlksV0FBbEMsQ0FBOEM7QUFBQzNPLFVBQVEsRUFBQyxDQUFWO0FBQWE0SSxPQUFLLEVBQUM7QUFBbkIsQ0FBOUMsRUFBb0U7QUFBQ2dHLFFBQU0sRUFBQztBQUFSLENBQXBFO0FBRUF6RixXQUFXLENBQUNuVCxhQUFaLEdBQTRCMlksV0FBNUIsQ0FBd0M7QUFBQzdkLE1BQUksRUFBQyxDQUFOO0FBQVNrVixXQUFTLEVBQUMsQ0FBQztBQUFwQixDQUF4QyxFQUErRDtBQUFDNEksUUFBTSxFQUFDO0FBQVIsQ0FBL0Q7QUFDQXhGLG9CQUFvQixDQUFDcFQsYUFBckIsR0FBcUMyWSxXQUFyQyxDQUFpRDtBQUFDdlosaUJBQWUsRUFBQyxDQUFqQjtBQUFtQjRRLFdBQVMsRUFBQyxDQUFDO0FBQTlCLENBQWpELEVBQWtGO0FBQUM0SSxRQUFNLEVBQUM7QUFBUixDQUFsRixFLENBQ0E7O0FBRUEvYSxZQUFZLENBQUNtQyxhQUFiLEdBQTZCMlksV0FBN0IsQ0FBeUM7QUFBQ3JILFFBQU0sRUFBQztBQUFSLENBQXpDLEVBQW9EO0FBQUNzSCxRQUFNLEVBQUM7QUFBUixDQUFwRDtBQUNBL2EsWUFBWSxDQUFDbUMsYUFBYixHQUE2QjJZLFdBQTdCLENBQXlDO0FBQUNsWixRQUFNLEVBQUMsQ0FBQztBQUFULENBQXpDLEUsQ0FDQTs7QUFDQTVCLFlBQVksQ0FBQ21DLGFBQWIsR0FBNkIyWSxXQUE3QixDQUF5QztBQUFDLDJCQUF3QjtBQUF6QixDQUF6QztBQUNBOWEsWUFBWSxDQUFDbUMsYUFBYixHQUE2QjJZLFdBQTdCLENBQXlDO0FBQUMsNkJBQTBCO0FBQTNCLENBQXpDO0FBRUFuYixhQUFhLENBQUN3QyxhQUFkLEdBQThCMlksV0FBOUIsQ0FBMEM7QUFBQzNVLGNBQVksRUFBQyxDQUFDO0FBQWYsQ0FBMUM7QUFFQXRLLFVBQVUsQ0FBQ3NHLGFBQVgsR0FBMkIyWSxXQUEzQixDQUF1QztBQUFDdGUsU0FBTyxFQUFDO0FBQVQsQ0FBdkMsRUFBbUQ7QUFBQ3VlLFFBQU0sRUFBQyxJQUFSO0FBQWNDLHlCQUF1QixFQUFFO0FBQUV4ZSxXQUFPLEVBQUU7QUFBRWlLLGFBQU8sRUFBRTtBQUFYO0FBQVg7QUFBdkMsQ0FBbkQ7QUFDQTVLLFVBQVUsQ0FBQ3NHLGFBQVgsR0FBMkIyWSxXQUEzQixDQUF1QztBQUFDOVcsa0JBQWdCLEVBQUM7QUFBbEIsQ0FBdkMsRUFBNEQ7QUFBQytXLFFBQU0sRUFBQztBQUFSLENBQTVEO0FBQ0FsZixVQUFVLENBQUNzRyxhQUFYLEdBQTJCMlksV0FBM0IsQ0FBdUM7QUFBQyxtQkFBZ0I7QUFBakIsQ0FBdkMsRUFBMkQ7QUFBQ0MsUUFBTSxFQUFDLElBQVI7QUFBY0MseUJBQXVCLEVBQUU7QUFBRSxxQkFBaUI7QUFBRXZVLGFBQU8sRUFBRTtBQUFYO0FBQW5CO0FBQXZDLENBQTNEO0FBRUExRyxrQkFBa0IsQ0FBQ29DLGFBQW5CLEdBQW1DMlksV0FBbkMsQ0FBK0M7QUFBQ3RlLFNBQU8sRUFBQyxDQUFUO0FBQVdvRixRQUFNLEVBQUMsQ0FBQztBQUFuQixDQUEvQztBQUNBN0Isa0JBQWtCLENBQUNvQyxhQUFuQixHQUFtQzJZLFdBQW5DLENBQStDO0FBQUM3ZCxNQUFJLEVBQUM7QUFBTixDQUEvQztBQUVBeVUsU0FBUyxDQUFDdlAsYUFBVixHQUEwQjJZLFdBQTFCLENBQXNDO0FBQUNsSixpQkFBZSxFQUFDLENBQUM7QUFBbEIsQ0FBdEMsRUFBMkQ7QUFBQ21KLFFBQU0sRUFBQztBQUFSLENBQTNELEU7Ozs7Ozs7Ozs7O0FDdERBdGYsTUFBTSxDQUFDQyxJQUFQLENBQVksV0FBWjtBQUF5QkQsTUFBTSxDQUFDQyxJQUFQLENBQVksbUJBQVo7QUFBaUNELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHFCQUFaO0FBQW1DLElBQUl1ZixVQUFKO0FBQWV4ZixNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDdWYsWUFBVSxDQUFDdGYsQ0FBRCxFQUFHO0FBQUNzZixjQUFVLEdBQUN0ZixDQUFYO0FBQWE7O0FBQTVCLENBQW5DLEVBQWlFLENBQWpFO0FBQW9FLElBQUl1ZixNQUFKO0FBQVd6ZixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN3ZixRQUFNLENBQUN2ZixDQUFELEVBQUc7QUFBQ3VmLFVBQU0sR0FBQ3ZmLENBQVA7QUFBUzs7QUFBcEIsQ0FBM0IsRUFBaUQsQ0FBakQ7QUFjM0w7QUFFQXNmLFVBQVUsQ0FBQ0UsSUFBSSxJQUFJO0FBQ2Y7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBLFFBQU1DLE1BQU0sR0FBR0YsTUFBTSxDQUFDRyxZQUFQLEVBQWY7QUFDQUYsTUFBSSxDQUFDRyxZQUFMLENBQWtCRixNQUFNLENBQUNHLElBQVAsQ0FBWUMsUUFBWixFQUFsQjtBQUNBTCxNQUFJLENBQUNHLFlBQUwsQ0FBa0JGLE1BQU0sQ0FBQ0ssS0FBUCxDQUFhRCxRQUFiLEVBQWxCLEVBZGUsQ0FnQmY7QUFDSCxDQWpCUyxDQUFWLEM7Ozs7Ozs7Ozs7O0FDaEJBL2YsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVo7QUFBa0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG1DQUFaO0FBQWlERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx3Q0FBWjtBQUFzREQsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVo7QUFBa0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHlDQUFaO0FBQXVERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx3Q0FBWjtBQUFzREQsTUFBTSxDQUFDQyxJQUFQLENBQVksNkNBQVo7QUFBMkRELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHFDQUFaO0FBQW1ERCxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQ0FBWjtBQUF3REQsTUFBTSxDQUFDQyxJQUFQLENBQVksdUNBQVo7QUFBcURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDRDQUFaO0FBQTBERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx3Q0FBWjtBQUFzREQsTUFBTSxDQUFDQyxJQUFQLENBQVksNkNBQVo7QUFBMkRELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtDQUFaO0FBQTZERCxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQ0FBWjtBQUF3REQsTUFBTSxDQUFDQyxJQUFQLENBQVksK0NBQVo7QUFBNkRELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHlDQUFaO0FBQXVERCxNQUFNLENBQUNDLElBQVAsQ0FBWSw4Q0FBWjtBQUE0REQsTUFBTSxDQUFDQyxJQUFQLENBQVkseUNBQVo7QUFBdURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNDQUFaO0FBQW9ERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx3Q0FBWixFOzs7Ozs7Ozs7OztBQ0E5a0MsSUFBSWdnQixNQUFKO0FBQVdqZ0IsTUFBTSxDQUFDQyxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDdVgsU0FBTyxDQUFDdFgsQ0FBRCxFQUFHO0FBQUMrZixVQUFNLEdBQUMvZixDQUFQO0FBQVM7O0FBQXJCLENBQXJCLEVBQTRDLENBQTVDO0FBQStDLElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSXlFLE9BQUo7QUFBWTNFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFNBQVosRUFBc0I7QUFBQyxNQUFJQyxDQUFKLEVBQU07QUFBQ3lFLFdBQU8sR0FBQ3pFLENBQVI7QUFBVTs7QUFBbEIsQ0FBdEIsRUFBMEMsQ0FBMUM7O0FBSTlIO0FBQ0EsSUFBSWdnQixNQUFNLEdBQUdDLEdBQUcsQ0FBQ0MsT0FBSixDQUFZLGVBQVosQ0FBYixDLENBQ0E7OztBQUNBLElBQUlDLElBQUksR0FBR0YsR0FBRyxDQUFDQyxPQUFKLENBQVksZUFBWixFQUE2QkMsSUFBeEM7O0FBRUEsU0FBU0MsV0FBVCxDQUFxQkMsU0FBckIsRUFBZ0M7QUFDNUIsU0FBT0EsU0FBUyxDQUFDdGEsR0FBVixDQUFjLFVBQVN1YSxJQUFULEVBQWU7QUFDaEMsV0FBTyxDQUFDLE1BQU0sQ0FBQ0EsSUFBSSxHQUFHLElBQVIsRUFBY1QsUUFBZCxDQUF1QixFQUF2QixDQUFQLEVBQW1DVSxLQUFuQyxDQUF5QyxDQUFDLENBQTFDLENBQVA7QUFDSCxHQUZNLEVBRUpDLElBRkksQ0FFQyxFQUZELENBQVA7QUFHSDs7QUFFRDNnQixNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYNmYsZ0JBQWMsRUFBRSxVQUFTL0ssTUFBVCxFQUFpQmdMLE1BQWpCLEVBQXlCO0FBQ3JDO0FBQ0EsUUFBSUMsaUJBQWlCLEdBQUczVyxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQTBCLEtBQTFCLENBQXhCO0FBQ0EsUUFBSTJXLE1BQU0sR0FBRzVXLE1BQU0sQ0FBQzZXLEtBQVAsQ0FBYSxFQUFiLENBQWI7QUFDQUYscUJBQWlCLENBQUNHLElBQWxCLENBQXVCRixNQUF2QixFQUErQixDQUEvQjtBQUNBNVcsVUFBTSxDQUFDQyxJQUFQLENBQVl5TCxNQUFNLENBQUNuVSxLQUFuQixFQUEwQixRQUExQixFQUFvQ3VmLElBQXBDLENBQXlDRixNQUF6QyxFQUFpREQsaUJBQWlCLENBQUMvZSxNQUFuRTtBQUNBLFdBQU9tZSxNQUFNLENBQUNnQixNQUFQLENBQWNMLE1BQWQsRUFBc0JYLE1BQU0sQ0FBQ2lCLE9BQVAsQ0FBZUosTUFBZixDQUF0QixDQUFQO0FBQ0gsR0FSVTtBQVNYSyxnQkFBYyxFQUFFLFVBQVN2TCxNQUFULEVBQWlCO0FBQzdCO0FBQ0EsUUFBSWlMLGlCQUFpQixHQUFHM1csTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUEwQixLQUExQixDQUF4QjtBQUNBLFFBQUkyVyxNQUFNLEdBQUc1VyxNQUFNLENBQUNDLElBQVAsQ0FBWThWLE1BQU0sQ0FBQ21CLFNBQVAsQ0FBaUJuQixNQUFNLENBQUNvQixNQUFQLENBQWN6TCxNQUFkLEVBQXNCMEwsS0FBdkMsQ0FBWixDQUFiO0FBQ0EsV0FBT1IsTUFBTSxDQUFDTCxLQUFQLENBQWFJLGlCQUFpQixDQUFDL2UsTUFBL0IsRUFBdUNpZSxRQUF2QyxDQUFnRCxRQUFoRCxDQUFQO0FBQ0gsR0FkVTtBQWVYd0IsY0FBWSxFQUFFLFVBQVNDLFlBQVQsRUFBc0I7QUFDaEMsUUFBSXpnQixPQUFPLEdBQUdrZixNQUFNLENBQUNvQixNQUFQLENBQWNHLFlBQWQsQ0FBZDtBQUNBLFdBQU92QixNQUFNLENBQUNnQixNQUFQLENBQWNsaEIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI0WCxtQkFBckMsRUFBMEQ3ZCxPQUFPLENBQUN1Z0IsS0FBbEUsQ0FBUDtBQUNILEdBbEJVO0FBbUJYRyxtQkFBaUIsRUFBRSxVQUFTQyxVQUFULEVBQW9CO0FBQ25DLFFBQUlsYyxRQUFRLEdBQUdyRixJQUFJLENBQUNLLEdBQUwsQ0FBU2toQixVQUFULENBQWY7O0FBQ0EsUUFBSWxjLFFBQVEsQ0FBQzlFLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0IsVUFBSStFLElBQUksR0FBR2QsT0FBTyxDQUFDZSxJQUFSLENBQWFGLFFBQVEsQ0FBQ25FLE9BQXRCLENBQVg7QUFDQSxhQUFPb0UsSUFBSSxDQUFDLG1CQUFELENBQUosQ0FBMEJFLElBQTFCLENBQStCLEtBQS9CLENBQVA7QUFDSDtBQUNKO0FBekJVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNmQTNGLE1BQU0sQ0FBQ3NRLE1BQVAsQ0FBYztBQUFDcVIsYUFBVyxFQUFDLE1BQUlBLFdBQWpCO0FBQTZCQyxvQkFBa0IsRUFBQyxNQUFJQSxrQkFBcEQ7QUFBdUVDLFVBQVEsRUFBQyxNQUFJQSxRQUFwRjtBQUE2RjdDLFFBQU0sRUFBQyxNQUFJQSxNQUF4RztBQUErRzhDLFVBQVEsRUFBQyxNQUFJQTtBQUE1SCxDQUFkO0FBQXFKLElBQUlDLEtBQUo7QUFBVS9oQixNQUFNLENBQUNDLElBQVAsQ0FBWSxPQUFaLEVBQW9CO0FBQUN1WCxTQUFPLENBQUN0WCxDQUFELEVBQUc7QUFBQzZoQixTQUFLLEdBQUM3aEIsQ0FBTjtBQUFROztBQUFwQixDQUFwQixFQUEwQyxDQUExQztBQUE2QyxJQUFJOGhCLG1CQUFKO0FBQXdCaGlCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQytoQixxQkFBbUIsQ0FBQzloQixDQUFELEVBQUc7QUFBQzhoQix1QkFBbUIsR0FBQzloQixDQUFwQjtBQUFzQjs7QUFBOUMsQ0FBekIsRUFBeUUsQ0FBekU7O0FBRzdOLE1BQU15aEIsV0FBVyxHQUFJTSxLQUFELElBQVc7QUFDbEMsVUFBUUEsS0FBSyxDQUFDalAsS0FBZDtBQUNBLFNBQUssT0FBTDtBQUNJLGFBQU8sSUFBUDs7QUFDSjtBQUNJLGFBQU8sSUFBUDtBQUpKO0FBTUgsQ0FQTTs7QUFVQSxNQUFNNE8sa0JBQWtCLEdBQUlLLEtBQUQsSUFBVztBQUN6QyxVQUFRQSxLQUFLLENBQUN2YSxNQUFkO0FBQ0EsU0FBSyxRQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssVUFBTDtBQUNJLGFBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSixTQUFLLFNBQUw7QUFDSSxhQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxlQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssY0FBTDtBQUNJLGFBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSjtBQUNJLGFBQU8sOEJBQVA7QUFaSjtBQWNILENBZk07O0FBaUJBLE1BQU1tYSxRQUFRLEdBQUlJLEtBQUQsSUFBVztBQUMvQixVQUFRQSxLQUFLLENBQUM1SSxJQUFkO0FBQ0EsU0FBSyxLQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssSUFBTDtBQUNJLGFBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSixTQUFLLFNBQUw7QUFDSSxhQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxjQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKO0FBQ0ksYUFBTyw4QkFBUDtBQVZKO0FBWUgsQ0FiTTs7QUFlQSxNQUFNMkYsTUFBTSxHQUFJaUQsS0FBRCxJQUFXO0FBQzdCLE1BQUlBLEtBQUssQ0FBQ0MsS0FBVixFQUFnQjtBQUNaLFdBQU87QUFBTSxlQUFTLEVBQUM7QUFBaEIsT0FBMkM7QUFBRyxlQUFTLEVBQUM7QUFBYixNQUEzQyxDQUFQO0FBQ0gsR0FGRCxNQUdJO0FBQ0EsV0FBTztBQUFNLGVBQVMsRUFBQztBQUFoQixPQUEwQztBQUFHLGVBQVMsRUFBQztBQUFiLE1BQTFDLENBQVA7QUFDSDtBQUNKLENBUE07O0FBU0EsTUFBTUosUUFBTixTQUF1QkMsS0FBSyxDQUFDSSxTQUE3QixDQUF1QztBQUMxQ0MsYUFBVyxDQUFDSCxLQUFELEVBQVE7QUFDZixVQUFNQSxLQUFOO0FBQ0EsU0FBS0ksR0FBTCxHQUFXTixLQUFLLENBQUNPLFNBQU4sRUFBWDtBQUNIOztBQUVEQyxRQUFNLEdBQUc7QUFDTCxXQUFPLENBQ0g7QUFBRyxTQUFHLEVBQUMsTUFBUDtBQUFjLGVBQVMsRUFBQywwQkFBeEI7QUFBbUQsU0FBRyxFQUFFLEtBQUtGO0FBQTdELGNBREcsRUFFSCxvQkFBQyxtQkFBRDtBQUFxQixTQUFHLEVBQUMsU0FBekI7QUFBbUMsZUFBUyxFQUFDLE9BQTdDO0FBQXFELFlBQU0sRUFBRSxLQUFLQTtBQUFsRSxPQUNLLEtBQUtKLEtBQUwsQ0FBVzVSLFFBQVgsR0FBb0IsS0FBSzRSLEtBQUwsQ0FBVzVSLFFBQS9CLEdBQXdDLEtBQUs0UixLQUFMLENBQVdPLFdBRHhELENBRkcsQ0FBUDtBQU1IOztBQWJ5QyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3REOUN4aUIsTUFBTSxDQUFDc1EsTUFBUCxDQUFjO0FBQUNrSCxTQUFPLEVBQUMsTUFBSWlMO0FBQWIsQ0FBZDtBQUFrQyxJQUFJMWlCLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXdpQixNQUFKO0FBQVcxaUIsTUFBTSxDQUFDQyxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDdVgsU0FBTyxDQUFDdFgsQ0FBRCxFQUFHO0FBQUN3aUIsVUFBTSxHQUFDeGlCLENBQVA7QUFBUzs7QUFBckIsQ0FBckIsRUFBNEMsQ0FBNUM7O0FBRzdHeWlCLFVBQVUsR0FBSWxoQixLQUFELElBQVc7QUFDdkIsTUFBSW1oQixTQUFTLEdBQUcsVUFBaEI7QUFDQW5oQixPQUFLLEdBQUcySyxJQUFJLENBQUM2RSxLQUFMLENBQVd4UCxLQUFLLEdBQUcsSUFBbkIsSUFBMkIsSUFBbkM7QUFDQSxNQUFJMkssSUFBSSxDQUFDNkUsS0FBTCxDQUFXeFAsS0FBWCxNQUFzQkEsS0FBMUIsRUFDQ21oQixTQUFTLEdBQUcsS0FBWixDQURELEtBRUssSUFBSXhXLElBQUksQ0FBQzZFLEtBQUwsQ0FBV3hQLEtBQUssR0FBQyxFQUFqQixNQUF5QkEsS0FBSyxHQUFDLEVBQW5DLEVBQ0ptaEIsU0FBUyxHQUFHLE9BQVosQ0FESSxLQUVBLElBQUl4VyxJQUFJLENBQUM2RSxLQUFMLENBQVd4UCxLQUFLLEdBQUMsR0FBakIsTUFBMEJBLEtBQUssR0FBQyxHQUFwQyxFQUNKbWhCLFNBQVMsR0FBRyxRQUFaLENBREksS0FFQSxJQUFJeFcsSUFBSSxDQUFDNkUsS0FBTCxDQUFXeFAsS0FBSyxHQUFDLElBQWpCLE1BQTJCQSxLQUFLLEdBQUMsSUFBckMsRUFDSm1oQixTQUFTLEdBQUcsU0FBWjtBQUNELFNBQU9GLE1BQU0sQ0FBQ2poQixLQUFELENBQU4sQ0FBY29oQixNQUFkLENBQXFCRCxTQUFyQixDQUFQO0FBQ0EsQ0FaRDs7QUFjZSxNQUFNSCxJQUFOLENBQVc7QUFPekJMLGFBQVcsQ0FBQ3JQLE1BQUQsRUFBcUI7QUFBQSxRQUFaQyxLQUFZLHVFQUFOLElBQU07QUFDL0IsUUFBSSxPQUFPRCxNQUFQLEtBQWtCLFFBQXRCLEVBQ0MsQ0FBQztBQUFDQSxZQUFEO0FBQVNDO0FBQVQsUUFBa0JELE1BQW5COztBQUNELFFBQUksQ0FBQ0MsS0FBRCxJQUFVQSxLQUFLLENBQUM4UCxXQUFOLE9BQXdCTCxJQUFJLENBQUNNLFlBQUwsQ0FBa0JELFdBQWxCLEVBQXRDLEVBQXVFO0FBQ3RFLFdBQUtFLE9BQUwsR0FBZTFMLE1BQU0sQ0FBQ3ZFLE1BQUQsQ0FBckI7QUFDQSxLQUZELE1BRU8sSUFBSUMsS0FBSyxDQUFDOFAsV0FBTixPQUF3QkwsSUFBSSxDQUFDUSxZQUFMLENBQWtCSCxXQUFsQixFQUE1QixFQUE2RDtBQUNuRSxXQUFLRSxPQUFMLEdBQWUxTCxNQUFNLENBQUN2RSxNQUFELENBQU4sR0FBaUIwUCxJQUFJLENBQUNTLGVBQXJDO0FBQ0EsS0FGTSxNQUdGO0FBQ0osWUFBTXJMLEtBQUssNkJBQXNCN0UsS0FBdEIsRUFBWDtBQUNBO0FBQ0Q7O0FBRUQsTUFBSUQsTUFBSixHQUFjO0FBQ2IsV0FBTyxLQUFLaVEsT0FBWjtBQUNBOztBQUVELE1BQUlHLGFBQUosR0FBcUI7QUFDcEIsV0FBTyxLQUFLSCxPQUFMLEdBQWVQLElBQUksQ0FBQ1MsZUFBM0I7QUFDQTs7QUFFRG5ELFVBQVEsQ0FBRXFELFNBQUYsRUFBYTtBQUNwQjtBQUNBLFFBQUlDLFFBQVEsR0FBR1osSUFBSSxDQUFDUyxlQUFMLElBQXNCRSxTQUFTLEdBQUNoWCxJQUFJLENBQUNrWCxHQUFMLENBQVMsRUFBVCxFQUFhRixTQUFiLENBQUQsR0FBeUIsS0FBeEQsQ0FBZjs7QUFDQSxRQUFJLEtBQUtyUSxNQUFMLEdBQWNzUSxRQUFsQixFQUE0QjtBQUMzQix1QkFBVVgsTUFBTSxDQUFDLEtBQUszUCxNQUFOLENBQU4sQ0FBb0I4UCxNQUFwQixDQUEyQixLQUEzQixDQUFWLGNBQStDSixJQUFJLENBQUNNLFlBQXBEO0FBQ0EsS0FGRCxNQUVPO0FBQ04sdUJBQVVLLFNBQVMsR0FBQ1YsTUFBTSxDQUFDLEtBQUtTLGFBQU4sQ0FBTixDQUEyQk4sTUFBM0IsQ0FBa0MsU0FBUyxJQUFJVSxNQUFKLENBQVdILFNBQVgsQ0FBM0MsQ0FBRCxHQUFtRVQsVUFBVSxDQUFDLEtBQUtRLGFBQU4sQ0FBaEcsY0FBd0hWLElBQUksQ0FBQ1EsWUFBN0g7QUFDQTtBQUNEOztBQUVETyxZQUFVLENBQUVaLFNBQUYsRUFBYTtBQUN0QixRQUFJN1AsTUFBTSxHQUFHLEtBQUtBLE1BQWxCOztBQUNBLFFBQUk2UCxTQUFKLEVBQWU7QUFDZDdQLFlBQU0sR0FBRzJQLE1BQU0sQ0FBQzNQLE1BQUQsQ0FBTixDQUFlOFAsTUFBZixDQUFzQkQsU0FBdEIsQ0FBVDtBQUNBOztBQUNELHFCQUFVN1AsTUFBVixjQUFvQjBQLElBQUksQ0FBQ00sWUFBekI7QUFDQTs7QUFFRFUsYUFBVyxDQUFFYixTQUFGLEVBQWE7QUFDdkIsUUFBSTdQLE1BQU0sR0FBRyxLQUFLb1EsYUFBbEI7O0FBQ0EsUUFBSVAsU0FBSixFQUFlO0FBQ2Q3UCxZQUFNLEdBQUcyUCxNQUFNLENBQUMzUCxNQUFELENBQU4sQ0FBZThQLE1BQWYsQ0FBc0JELFNBQXRCLENBQVQ7QUFDQTs7QUFDRCxxQkFBVTdQLE1BQVYsY0FBb0IwUCxJQUFJLENBQUNRLFlBQXpCO0FBQ0E7O0FBcER3Qjs7QUFBTFIsSSxDQUNiUSxZLEdBQWVsakIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUIwYyxZO0FBRHpCakIsSSxDQUVia0Isa0IsR0FBcUI1akIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI0YyxrQkFBdkIsSUFBOENuQixJQUFJLENBQUNRLFlBQUwsR0FBb0IsRztBQUYxRVIsSSxDQUdiTSxZLEdBQWVoakIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUIwTCxZO0FBSHpCK1AsSSxDQUliUyxlLEdBQWtCNUwsTUFBTSxDQUFDdlgsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4TyxlQUF4QixDO0FBSlgyTSxJLENBS2JvQixRLEdBQVcsSUFBSXZNLE1BQU0sQ0FBQ3ZYLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOE8sZUFBeEIsQzs7Ozs7Ozs7Ozs7QUN0QjdCOVYsTUFBTSxDQUFDQyxJQUFQLENBQVkseUJBQVo7QUFBdUNELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVCQUFaO0FBSXZDO0FBQ0E7QUFFQWlJLE9BQU8sR0FBRyxLQUFWO0FBQ0FvVCxpQkFBaUIsR0FBRyxLQUFwQjtBQUNBMkIsc0JBQXNCLEdBQUcsS0FBekI7QUFDQXhWLEdBQUcsR0FBRzFILE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0IrYyxNQUFoQixDQUF1QkMsR0FBN0I7QUFDQXRqQixHQUFHLEdBQUdWLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0IrYyxNQUFoQixDQUF1QkUsR0FBN0I7QUFDQUMsV0FBVyxHQUFHLENBQWQ7QUFDQUMsVUFBVSxHQUFHLENBQWI7QUFDQUMsY0FBYyxHQUFHLENBQWpCO0FBQ0FDLGFBQWEsR0FBRyxDQUFoQjtBQUNBQyxxQkFBcUIsR0FBRyxDQUF4QjtBQUNBQyxnQkFBZ0IsR0FBRyxDQUFuQjtBQUNBQyxlQUFlLEdBQUcsQ0FBbEI7QUFDQUMsY0FBYyxHQUFHLENBQWpCO0FBRUEsTUFBTUMsZUFBZSxHQUFHLHdCQUF4Qjs7QUFFQUMsaUJBQWlCLEdBQUcsTUFBTTtBQUN0QjNrQixRQUFNLENBQUNxSSxJQUFQLENBQVksb0JBQVosRUFBa0MsQ0FBQ3VjLEtBQUQsRUFBUXJqQixNQUFSLEtBQW1CO0FBQ2pELFFBQUlxakIsS0FBSixFQUFVO0FBQ04vakIsYUFBTyxDQUFDQyxHQUFSLENBQVksbUJBQWlCOGpCLEtBQTdCO0FBQ0gsS0FGRCxNQUdJO0FBQ0EvakIsYUFBTyxDQUFDQyxHQUFSLENBQVksbUJBQWlCUyxNQUE3QjtBQUNIO0FBQ0osR0FQRDtBQVFILENBVEQ7O0FBV0FzakIsV0FBVyxHQUFHLE1BQU07QUFDaEI3a0IsUUFBTSxDQUFDcUksSUFBUCxDQUFZLHFCQUFaLEVBQW1DLENBQUN1YyxLQUFELEVBQVFyakIsTUFBUixLQUFtQjtBQUNsRCxRQUFJcWpCLEtBQUosRUFBVTtBQUNOL2pCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFpQjhqQixLQUE3QjtBQUNILEtBRkQsTUFHSTtBQUNBL2pCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFpQlMsTUFBN0I7QUFDSDtBQUNKLEdBUEQ7QUFRSCxDQVREOztBQVdBdWpCLGlCQUFpQixHQUFHLE1BQU07QUFDdEI5a0IsUUFBTSxDQUFDcUksSUFBUCxDQUFZLHlCQUFaLEVBQXVDLENBQUN1YyxLQUFELEVBQVFyakIsTUFBUixLQUFtQjtBQUN0RCxRQUFJcWpCLEtBQUosRUFBVTtBQUNOL2pCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLG9CQUFrQjhqQixLQUE5QjtBQUNIO0FBQ0osR0FKRDtBQUtILENBTkQ7O0FBUUFHLGlCQUFpQixHQUFHLE1BQU07QUFDdkIva0IsUUFBTSxDQUFDcUksSUFBUCxDQUFZLDhCQUFaLEVBQTRDLENBQUN1YyxLQUFELEVBQVFyakIsTUFBUixLQUFtQjtBQUMzRCxRQUFJcWpCLEtBQUosRUFBVTtBQUNOL2pCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGFBQVk4akIsS0FBeEI7QUFDSDs7QUFDRCxRQUFJcmpCLE1BQUosRUFBVztBQUNQVixhQUFPLENBQUNDLEdBQVIsQ0FBWSxhQUFXUyxNQUF2QjtBQUNIO0FBQ0osR0FQRDtBQVFGLENBVEQ7O0FBV0F5akIsWUFBWSxHQUFHLE1BQU07QUFDbEJobEIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLHdCQUFaLEVBQXNDLENBQUN1YyxLQUFELEVBQVFyakIsTUFBUixLQUFtQjtBQUNyRCxRQUFJcWpCLEtBQUosRUFBVTtBQUNOL2pCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFrQjhqQixLQUE5QjtBQUNIOztBQUNELFFBQUlyakIsTUFBSixFQUFXO0FBQ1BWLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFpQlMsTUFBN0I7QUFDSDtBQUNKLEdBUEQ7QUFRRixDQVREOztBQVdBMGpCLG1CQUFtQixHQUFHLE1BQU07QUFDekJqbEIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLDhCQUFaLEVBQTRDLENBQUN1YyxLQUFELEVBQVFyakIsTUFBUixLQUFtQjtBQUMzRCxRQUFJcWpCLEtBQUosRUFBVTtBQUNOL2pCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDJCQUF5QjhqQixLQUFyQztBQUNIOztBQUNELFFBQUlyakIsTUFBSixFQUFXO0FBQ1BWLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDJCQUF5QlMsTUFBckM7QUFDSDtBQUNKLEdBUEQ7QUFRRixDQVREOztBQVdBMmpCLGtCQUFrQixHQUFHLE1BQU07QUFDdkJsbEIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLHdDQUFaLEVBQXNELENBQUN1YyxLQUFELEVBQVFyakIsTUFBUixLQUFrQjtBQUNwRSxRQUFJcWpCLEtBQUosRUFBVTtBQUNOL2pCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDBCQUF5QjhqQixLQUFyQztBQUNIOztBQUNELFFBQUlyakIsTUFBSixFQUFXO0FBQ1BWLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFzQlMsTUFBbEM7QUFDSDtBQUNKLEdBUEQ7QUFRSjs7Ozs7Ozs7OztBQVVDLENBbkJEOztBQXFCQTRqQixjQUFjLEdBQUcsTUFBTTtBQUNuQm5sQixRQUFNLENBQUNxSSxJQUFQLENBQVksNEJBQVosRUFBMEMsQ0FBQ3VjLEtBQUQsRUFBUXJqQixNQUFSLEtBQW1CO0FBQ3pELFFBQUlxakIsS0FBSixFQUFVO0FBQ04vakIsYUFBTyxDQUFDQyxHQUFSLENBQVksNEJBQTJCOGpCLEtBQXZDO0FBQ0gsS0FGRCxNQUdJO0FBQ0EvakIsYUFBTyxDQUFDQyxHQUFSLENBQVkseUJBQXdCUyxNQUFwQztBQUNIO0FBQ0osR0FQRDtBQVFILENBVEQ7O0FBV0E2akIsaUJBQWlCLEdBQUcsTUFBSztBQUNyQjtBQUNBcGxCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSw0Q0FBWixFQUEwRCxHQUExRCxFQUErRCxDQUFDdWMsS0FBRCxFQUFRcmpCLE1BQVIsS0FBbUI7QUFDOUUsUUFBSXFqQixLQUFKLEVBQVU7QUFDTi9qQixhQUFPLENBQUNDLEdBQVIsQ0FBWSwwQ0FBd0M4akIsS0FBcEQ7QUFDSCxLQUZELE1BR0k7QUFDQS9qQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx1Q0FBcUNTLE1BQWpEO0FBQ0g7QUFDSixHQVBEO0FBU0F2QixRQUFNLENBQUNxSSxJQUFQLENBQVksd0JBQVosRUFBc0MsQ0FBQ3VjLEtBQUQsRUFBUXJqQixNQUFSLEtBQW1CO0FBQ3JELFFBQUlxakIsS0FBSixFQUFVO0FBQ04vakIsYUFBTyxDQUFDQyxHQUFSLENBQVksMkJBQXlCOGpCLEtBQXJDO0FBQ0gsS0FGRCxNQUdJO0FBQ0EvakIsYUFBTyxDQUFDQyxHQUFSLENBQVksd0JBQXNCUyxNQUFsQztBQUNIO0FBQ0osR0FQRDtBQVFILENBbkJEOztBQXFCQThqQixlQUFlLEdBQUcsTUFBSztBQUNuQjtBQUNBcmxCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSw0Q0FBWixFQUEwRCxHQUExRCxFQUErRCxDQUFDdWMsS0FBRCxFQUFRcmpCLE1BQVIsS0FBbUI7QUFDOUUsUUFBSXFqQixLQUFKLEVBQVU7QUFDTi9qQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx3Q0FBc0M4akIsS0FBbEQ7QUFDSCxLQUZELE1BR0k7QUFDQS9qQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxxQ0FBbUNTLE1BQS9DO0FBQ0g7QUFDSixHQVBEO0FBUUgsQ0FWRDs7QUFZQStqQixjQUFjLEdBQUcsTUFBSztBQUNsQjtBQUNBdGxCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSw0Q0FBWixFQUEwRCxHQUExRCxFQUErRCxDQUFDdWMsS0FBRCxFQUFRcmpCLE1BQVIsS0FBbUI7QUFDOUUsUUFBSXFqQixLQUFKLEVBQVU7QUFDTi9qQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx1Q0FBcUM4akIsS0FBakQ7QUFDSCxLQUZELE1BR0k7QUFDQS9qQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxvQ0FBa0NTLE1BQTlDO0FBQ0g7QUFDSixHQVBEO0FBU0F2QixRQUFNLENBQUNxSSxJQUFQLENBQVksNENBQVosRUFBMEQsQ0FBQ3VjLEtBQUQsRUFBUXJqQixNQUFSLEtBQW1CO0FBQ3pFLFFBQUlxakIsS0FBSixFQUFVO0FBQ04vakIsYUFBTyxDQUFDQyxHQUFSLENBQVksMkNBQTBDOGpCLEtBQXREO0FBQ0gsS0FGRCxNQUdLO0FBQ0QvakIsYUFBTyxDQUFDQyxHQUFSLENBQVksd0NBQXVDUyxNQUFuRDtBQUNIO0FBQ0osR0FQRDtBQVFILENBbkJEOztBQXVCQXZCLE1BQU0sQ0FBQ3VsQixPQUFQLENBQWUsWUFBVTtBQUNyQixNQUFJdmxCLE1BQU0sQ0FBQ3dsQixhQUFYLEVBQXlCO0FBL0s3QixRQUFJQyxtQkFBSjtBQUF3QnhsQixVQUFNLENBQUNDLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDdVgsYUFBTyxDQUFDdFgsQ0FBRCxFQUFHO0FBQUNzbEIsMkJBQW1CLEdBQUN0bEIsQ0FBcEI7QUFBc0I7O0FBQWxDLEtBQXZDLEVBQTJFLENBQTNFO0FBZ0xoQnVsQixXQUFPLENBQUNDLEdBQVIsQ0FBWUMsNEJBQVosR0FBMkMsQ0FBM0M7QUFFQWxkLFVBQU0sQ0FBQ0MsSUFBUCxDQUFZOGMsbUJBQVosRUFBaUN6aUIsT0FBakMsQ0FBMEM2aUIsR0FBRCxJQUFTO0FBQzlDLFVBQUk3bEIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQjZlLEdBQWhCLEtBQXdCbFgsU0FBNUIsRUFBdUM7QUFDbkM5TixlQUFPLENBQUNpbEIsSUFBUixnQ0FBcUNELEdBQXJDO0FBQ0E3bEIsY0FBTSxDQUFDZ0gsUUFBUCxDQUFnQjZlLEdBQWhCLElBQXVCLEVBQXZCO0FBQ0g7O0FBQ0RuZCxZQUFNLENBQUNDLElBQVAsQ0FBWThjLG1CQUFtQixDQUFDSSxHQUFELENBQS9CLEVBQXNDN2lCLE9BQXRDLENBQStDK2lCLEtBQUQsSUFBVztBQUNyRCxZQUFJL2xCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0I2ZSxHQUFoQixFQUFxQkUsS0FBckIsS0FBK0JwWCxTQUFuQyxFQUE2QztBQUN6QzlOLGlCQUFPLENBQUNpbEIsSUFBUixnQ0FBcUNELEdBQXJDLGNBQTRDRSxLQUE1QztBQUNBL2xCLGdCQUFNLENBQUNnSCxRQUFQLENBQWdCNmUsR0FBaEIsRUFBcUJFLEtBQXJCLElBQThCTixtQkFBbUIsQ0FBQ0ksR0FBRCxDQUFuQixDQUF5QkUsS0FBekIsQ0FBOUI7QUFDSDtBQUNKLE9BTEQ7QUFNSCxLQVhEO0FBWUg7O0FBRUQvbEIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLGVBQVosRUFBNkIsQ0FBQ2dDLEdBQUQsRUFBTTlJLE1BQU4sS0FBaUI7QUFDMUMsUUFBSThJLEdBQUosRUFBUTtBQUNKeEosYUFBTyxDQUFDQyxHQUFSLENBQVl1SixHQUFaO0FBQ0g7O0FBQ0QsUUFBSTlJLE1BQUosRUFBVztBQUNQLFVBQUl2QixNQUFNLENBQUNnSCxRQUFQLENBQWdCdU0sS0FBaEIsQ0FBc0J5UyxVQUExQixFQUFxQztBQUNqQzVCLHNCQUFjLEdBQUdwa0IsTUFBTSxDQUFDaW1CLFdBQVAsQ0FBbUIsWUFBVTtBQUMxQ25CLDJCQUFpQjtBQUNwQixTQUZnQixFQUVkOWtCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QmdlLGlCQUZULENBQWpCO0FBSUFoQyxtQkFBVyxHQUFHbGtCLE1BQU0sQ0FBQ2ltQixXQUFQLENBQW1CLFlBQVU7QUFDdkNwQixxQkFBVztBQUNkLFNBRmEsRUFFWDdrQixNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUJpZSxhQUZaLENBQWQ7QUFJQWhDLGtCQUFVLEdBQUdua0IsTUFBTSxDQUFDaW1CLFdBQVAsQ0FBbUIsWUFBVTtBQUN0Q3RCLDJCQUFpQjtBQUNwQixTQUZZLEVBRVYza0IsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCa2UsY0FGYixDQUFiO0FBSUFDLDBCQUFrQixHQUFHcm1CLE1BQU0sQ0FBQ2ltQixXQUFQLENBQW9CLFlBQVc7QUFDaERsQiwyQkFBaUI7QUFDcEIsU0FGb0IsRUFFbEIva0IsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCb2UsZ0JBRkwsQ0FBckI7QUFJRGpDLHFCQUFhLEdBQUdya0IsTUFBTSxDQUFDaW1CLFdBQVAsQ0FBbUIsWUFBVTtBQUN6Q2pCLHNCQUFZO0FBQ2YsU0FGZSxFQUViaGxCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1Qm9lLGdCQUZWLENBQWhCO0FBSUFoQyw2QkFBcUIsR0FBR3RrQixNQUFNLENBQUNpbUIsV0FBUCxDQUFtQixZQUFVO0FBQ2pEaEIsNkJBQW1CO0FBQ3RCLFNBRnVCLEVBRXJCamxCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1Qm9lLGdCQUZGLENBQXhCO0FBSUMvQix3QkFBZ0IsR0FBR3ZrQixNQUFNLENBQUNpbUIsV0FBUCxDQUFtQixZQUFVO0FBQzVDZiw0QkFBa0I7QUFDckIsU0FGa0IsRUFFaEJsbEIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCcWUsb0JBRlAsQ0FBbkI7QUFJQS9CLHVCQUFlLEdBQUd4a0IsTUFBTSxDQUFDaW1CLFdBQVAsQ0FBbUIsWUFBVTtBQUMzQ2Qsd0JBQWM7QUFDakIsU0FGaUIsRUFFZm5sQixNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUJzZSxrQkFGUixDQUFsQjtBQUlBL0Isc0JBQWMsR0FBR3prQixNQUFNLENBQUNpbUIsV0FBUCxDQUFtQixZQUFVO0FBQzFDLGNBQUkxUCxHQUFHLEdBQUcsSUFBSW5ULElBQUosRUFBVjs7QUFDQSxjQUFLbVQsR0FBRyxDQUFDa1EsYUFBSixNQUF1QixDQUE1QixFQUErQjtBQUMzQnJCLDZCQUFpQjtBQUNwQjs7QUFFRCxjQUFLN08sR0FBRyxDQUFDbVEsYUFBSixNQUF1QixDQUF4QixJQUErQm5RLEdBQUcsQ0FBQ2tRLGFBQUosTUFBdUIsQ0FBMUQsRUFBNkQ7QUFDekRwQiwyQkFBZTtBQUNsQjs7QUFFRCxjQUFLOU8sR0FBRyxDQUFDb1EsV0FBSixNQUFxQixDQUF0QixJQUE2QnBRLEdBQUcsQ0FBQ21RLGFBQUosTUFBdUIsQ0FBcEQsSUFBMkRuUSxHQUFHLENBQUNrUSxhQUFKLE1BQXVCLENBQXRGLEVBQXlGO0FBQ3JGbkIsMEJBQWM7QUFDakI7QUFDSixTQWJnQixFQWFkLElBYmMsQ0FBakI7QUFjSDtBQUNKO0FBQ0osR0F0REQ7QUF3REgsQ0ExRUQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuY29uc3QgZmV0Y2hGcm9tVXJsID0gKHVybCkgPT4ge1xuICAgIHRyeXtcbiAgICAgICAgbGV0IHJlcyA9IEhUVFAuZ2V0KExDRCArIHVybCk7XG4gICAgICAgIGlmIChyZXMuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgcmV0dXJuIHJlc1xuICAgICAgICB9O1xuICAgIH1cbiAgICBjYXRjaCAoZSl7XG4gICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgIH1cbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdhY2NvdW50cy5nZXRBY2NvdW50RGV0YWlsJzogZnVuY3Rpb24oYWRkcmVzcyl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgdXJsID0gTENEICsgJy9hdXRoL2FjY291bnRzLycrIGFkZHJlc3M7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCBhdmFpbGFibGUgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGF2YWlsYWJsZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSlNPTi5wYXJzZShhdmFpbGFibGUuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgIGxldCBhY2NvdW50O1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS50eXBlID09PSAnY29zbW9zLXNkay9BY2NvdW50JylcbiAgICAgICAgICAgICAgICAgICAgYWNjb3VudCA9IHJlc3BvbnNlLnZhbHVlO1xuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHJlc3BvbnNlLnR5cGUgPT09ICdjb3Ntb3Mtc2RrL0RlbGF5ZWRWZXN0aW5nQWNjb3VudCcgfHwgcmVzcG9uc2UudHlwZSA9PT0gJ2Nvc21vcy1zZGsvQ29udGludW91c1Zlc3RpbmdBY2NvdW50JylcbiAgICAgICAgICAgICAgICAgICAgYWNjb3VudCA9IHJlc3BvbnNlLnZhbHVlLkJhc2VWZXN0aW5nQWNjb3VudC5CYXNlQWNjb3VudFxuICAgICAgICAgICAgICAgIGlmIChhY2NvdW50ICYmIGFjY291bnQuYWNjb3VudF9udW1iZXIgIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFjY291bnRcbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbFxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgIH1cbiAgICB9LFxuICAgICdhY2NvdW50cy5nZXRCYWxhbmNlJzogZnVuY3Rpb24oYWRkcmVzcyl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgYmFsYW5jZSA9IHt9XG5cbiAgICAgICAgLy8gZ2V0IGF2YWlsYWJsZSBhdG9tc1xuICAgICAgICBsZXQgdXJsID0gTENEICsgJy9iYW5rL2JhbGFuY2VzLycrIGFkZHJlc3M7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCBhdmFpbGFibGUgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGF2YWlsYWJsZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coSlNPTi5wYXJzZShhdmFpbGFibGUuY29udGVudCkpXG4gICAgICAgICAgICAgICAgYmFsYW5jZS5hdmFpbGFibGUgPSBKU09OLnBhcnNlKGF2YWlsYWJsZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgaWYgKGJhbGFuY2UuYXZhaWxhYmxlICYmIGJhbGFuY2UuYXZhaWxhYmxlLmxlbmd0aCA+IDApXG4gICAgICAgICAgICAgICAgICAgIGJhbGFuY2UuYXZhaWxhYmxlID0gYmFsYW5jZS5hdmFpbGFibGVbMF07XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGdldCBkZWxlZ2F0ZWQgYW1ub3VudHNcbiAgICAgICAgdXJsID0gTENEICsgJy9zdGFraW5nL2RlbGVnYXRvcnMvJythZGRyZXNzKycvZGVsZWdhdGlvbnMnO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgZGVsZWdhdGlvbnMgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICBiYWxhbmNlLmRlbGVnYXRpb25zID0gSlNPTi5wYXJzZShkZWxlZ2F0aW9ucy5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gZ2V0IHVuYm9uZGluZ1xuICAgICAgICB1cmwgPSBMQ0QgKyAnL3N0YWtpbmcvZGVsZWdhdG9ycy8nK2FkZHJlc3MrJy91bmJvbmRpbmdfZGVsZWdhdGlvbnMnO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgdW5ib25kaW5nID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmICh1bmJvbmRpbmcuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIGJhbGFuY2UudW5ib25kaW5nID0gSlNPTi5wYXJzZSh1bmJvbmRpbmcuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gZ2V0IHJld2FyZHNcbiAgICAgICAgdXJsID0gTENEICsgJy9kaXN0cmlidXRpb24vZGVsZWdhdG9ycy8nK2FkZHJlc3MrJy9yZXdhcmRzJztcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IHJld2FyZHMgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKHJld2FyZHMuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIGJhbGFuY2UucmV3YXJkcyA9IEpTT04ucGFyc2UocmV3YXJkcy5jb250ZW50KS5yZXN1bHQudG90YWw7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBnZXQgY29tbWlzc2lvblxuICAgICAgICBsZXQgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKFxuICAgICAgICAgICAgeyRvcjogW3tvcGVyYXRvcl9hZGRyZXNzOmFkZHJlc3N9LCB7ZGVsZWdhdG9yX2FkZHJlc3M6YWRkcmVzc30sIHthZGRyZXNzOmFkZHJlc3N9XX0pXG4gICAgICAgIGlmICh2YWxpZGF0b3IpIHtcbiAgICAgICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL2Rpc3RyaWJ1dGlvbi92YWxpZGF0b3JzLycgKyB2YWxpZGF0b3Iub3BlcmF0b3JfYWRkcmVzcztcbiAgICAgICAgICAgIGJhbGFuY2Uub3BlcmF0b3JfYWRkcmVzcyA9IHZhbGlkYXRvci5vcGVyYXRvcl9hZGRyZXNzO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBsZXQgcmV3YXJkcyA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgaWYgKHJld2FyZHMuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICBsZXQgY29udGVudCA9IEpTT04ucGFyc2UocmV3YXJkcy5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb250ZW50LnZhbF9jb21taXNzaW9uICYmIGNvbnRlbnQudmFsX2NvbW1pc3Npb24ubGVuZ3RoID4gMClcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhbGFuY2UuY29tbWlzc2lvbiA9IGNvbnRlbnQudmFsX2NvbW1pc3Npb25bMF07XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBiYWxhbmNlO1xuICAgIH0sXG4gICAgJ2FjY291bnRzLmdldERlbGVnYXRpb24nKGFkZHJlc3MsIHZhbGlkYXRvcil7XG4gICAgICAgIGxldCB1cmwgPSBgL3N0YWtpbmcvZGVsZWdhdG9ycy8ke2FkZHJlc3N9L2RlbGVnYXRpb25zLyR7dmFsaWRhdG9yfWA7XG4gICAgICAgIGxldCBkZWxlZ2F0aW9ucyA9IGZldGNoRnJvbVVybCh1cmwpO1xuICAgICAgICBkZWxlZ2F0aW9ucyA9IGRlbGVnYXRpb25zICYmIGRlbGVnYXRpb25zLmRhdGEucmVzdWx0O1xuICAgICAgICBpZiAoZGVsZWdhdGlvbnMgJiYgZGVsZWdhdGlvbnMuc2hhcmVzKVxuICAgICAgICAgICAgZGVsZWdhdGlvbnMuc2hhcmVzID0gcGFyc2VGbG9hdChkZWxlZ2F0aW9ucy5zaGFyZXMpO1xuXG4gICAgICAgIHVybCA9IGAvc3Rha2luZy9yZWRlbGVnYXRpb25zP2RlbGVnYXRvcj0ke2FkZHJlc3N9JnZhbGlkYXRvcl90bz0ke3ZhbGlkYXRvcn1gO1xuICAgICAgICBsZXQgcmVsZWdhdGlvbnMgPSBmZXRjaEZyb21VcmwodXJsKTtcbiAgICAgICAgcmVsZWdhdGlvbnMgPSByZWxlZ2F0aW9ucyAmJiByZWxlZ2F0aW9ucy5kYXRhLnJlc3VsdDtcbiAgICAgICAgbGV0IGNvbXBsZXRpb25UaW1lO1xuICAgICAgICBpZiAocmVsZWdhdGlvbnMpIHtcbiAgICAgICAgICAgIHJlbGVnYXRpb25zLmZvckVhY2goKHJlbGVnYXRpb24pID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgZW50cmllcyA9IHJlbGVnYXRpb24uZW50cmllc1xuICAgICAgICAgICAgICAgIGxldCB0aW1lID0gbmV3IERhdGUoZW50cmllc1tlbnRyaWVzLmxlbmd0aC0xXS5jb21wbGV0aW9uX3RpbWUpXG4gICAgICAgICAgICAgICAgaWYgKCFjb21wbGV0aW9uVGltZSB8fCB0aW1lID4gY29tcGxldGlvblRpbWUpXG4gICAgICAgICAgICAgICAgICAgIGNvbXBsZXRpb25UaW1lID0gdGltZVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIGRlbGVnYXRpb25zLnJlZGVsZWdhdGlvbkNvbXBsZXRpb25UaW1lID0gY29tcGxldGlvblRpbWU7XG4gICAgICAgIH1cblxuICAgICAgICB1cmwgPSBgL3N0YWtpbmcvZGVsZWdhdG9ycy8ke2FkZHJlc3N9L3VuYm9uZGluZ19kZWxlZ2F0aW9ucy8ke3ZhbGlkYXRvcn1gO1xuICAgICAgICBsZXQgdW5kZWxlZ2F0aW9ucyA9IGZldGNoRnJvbVVybCh1cmwpO1xuICAgICAgICB1bmRlbGVnYXRpb25zID0gdW5kZWxlZ2F0aW9ucyAmJiB1bmRlbGVnYXRpb25zLmRhdGEucmVzdWx0O1xuICAgICAgICBpZiAodW5kZWxlZ2F0aW9ucykge1xuICAgICAgICAgICAgZGVsZWdhdGlvbnMudW5ib25kaW5nID0gdW5kZWxlZ2F0aW9ucy5lbnRyaWVzLmxlbmd0aDtcbiAgICAgICAgICAgIGRlbGVnYXRpb25zLnVuYm9uZGluZ0NvbXBsZXRpb25UaW1lID0gdW5kZWxlZ2F0aW9ucy5lbnRyaWVzWzBdLmNvbXBsZXRpb25fdGltZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZGVsZWdhdGlvbnM7XG4gICAgfSxcbiAgICAnYWNjb3VudHMuZ2V0QWxsRGVsZWdhdGlvbnMnKGFkZHJlc3Mpe1xuICAgICAgICBsZXQgdXJsID0gTENEICsgJy9zdGFraW5nL2RlbGVnYXRvcnMvJythZGRyZXNzKycvZGVsZWdhdGlvbnMnO1xuXG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCBkZWxlZ2F0aW9ucyA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBpZiAoZGVsZWdhdGlvbnMuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zID0gSlNPTi5wYXJzZShkZWxlZ2F0aW9ucy5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zICYmIGRlbGVnYXRpb25zLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICBkZWxlZ2F0aW9ucy5mb3JFYWNoKChkZWxlZ2F0aW9uLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZGVsZWdhdGlvbnNbaV0gJiYgZGVsZWdhdGlvbnNbaV0uc2hhcmVzKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zW2ldLnNoYXJlcyA9IHBhcnNlRmxvYXQoZGVsZWdhdGlvbnNbaV0uc2hhcmVzKTtcbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gZGVsZWdhdGlvbnM7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAnYWNjb3VudHMuZ2V0QWxsVW5ib25kaW5ncycoYWRkcmVzcyl7XG4gICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL3N0YWtpbmcvZGVsZWdhdG9ycy8nK2FkZHJlc3MrJy91bmJvbmRpbmdfZGVsZWdhdGlvbnMnO1xuXG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCB1bmJvbmRpbmdzID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmICh1bmJvbmRpbmdzLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICB1bmJvbmRpbmdzID0gSlNPTi5wYXJzZSh1bmJvbmRpbmdzLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICByZXR1cm4gdW5ib25kaW5ncztcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdhY2NvdW50cy5nZXRBbGxSZWRlbGVnYXRpb25zJyhhZGRyZXNzLCB2YWxpZGF0b3Ipe1xuICAgICAgICBsZXQgdXJsID0gYC9zdGFraW5nL3JlZGVsZWdhdGlvbnM/ZGVsZWdhdG9yPSR7YWRkcmVzc30mdmFsaWRhdG9yX2Zyb209JHt2YWxpZGF0b3J9YDtcbiAgICAgICAgbGV0IHJlc3VsdCA9IGZldGNoRnJvbVVybCh1cmwpO1xuICAgICAgICBpZiAocmVzdWx0ICYmIHJlc3VsdC5kYXRhKSB7XG4gICAgICAgICAgICBsZXQgcmVkZWxlZ2F0aW9ucyA9IHt9XG4gICAgICAgICAgICByZXN1bHQuZGF0YS5mb3JFYWNoKChyZWRlbGVnYXRpb24pID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgZW50cmllcyA9IHJlZGVsZWdhdGlvbi5lbnRyaWVzO1xuICAgICAgICAgICAgICAgIHJlZGVsZWdhdGlvbnNbcmVkZWxlZ2F0aW9uLnZhbGlkYXRvcl9kc3RfYWRkcmVzc10gPSB7XG4gICAgICAgICAgICAgICAgICAgIGNvdW50OiBlbnRyaWVzLmxlbmd0aCxcbiAgICAgICAgICAgICAgICAgICAgY29tcGxldGlvblRpbWU6IGVudHJpZXNbMF0uY29tcGxldGlvbl90aW1lXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIHJldHVybiByZWRlbGVnYXRpb25zXG4gICAgICAgIH1cbiAgICB9XG59KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IFByb21pc2UgfSBmcm9tIFwibWV0ZW9yL3Byb21pc2VcIjtcbmltcG9ydCB7IEJsb2Nrc2NvbiB9IGZyb20gJy9pbXBvcnRzL2FwaS9ibG9ja3MvYmxvY2tzLmpzJztcbmltcG9ydCB7IENoYWluIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2NoYWluL2NoYWluLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclNldHMgfSBmcm9tICcvaW1wb3J0cy9hcGkvdmFsaWRhdG9yLXNldHMvdmFsaWRhdG9yLXNldHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9yUmVjb3JkcywgQW5hbHl0aWNzLCBWUERpc3RyaWJ1dGlvbnN9IGZyb20gJy9pbXBvcnRzL2FwaS9yZWNvcmRzL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnL2ltcG9ydHMvYXBpL3ZvdGluZy1wb3dlci9oaXN0b3J5LmpzJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uLy4uL3RyYW5zYWN0aW9ucy90cmFuc2FjdGlvbnMuanMnO1xuaW1wb3J0IHsgRXZpZGVuY2VzIH0gZnJvbSAnLi4vLi4vZXZpZGVuY2VzL2V2aWRlbmNlcy5qcyc7XG5pbXBvcnQgeyBzaGEyNTYgfSBmcm9tICdqcy1zaGEyNTYnO1xuaW1wb3J0IHsgZ2V0QWRkcmVzcyB9IGZyb20gJ3RlbmRlcm1pbnQvbGliL3B1YmtleSc7XG5pbXBvcnQgKiBhcyBjaGVlcmlvIGZyb20gJ2NoZWVyaW8nO1xuXG4vLyBpbXBvcnQgQmxvY2sgZnJvbSAnLi4vLi4vLi4vdWkvY29tcG9uZW50cy9CbG9jayc7XG5cbi8vIGdldFZhbGlkYXRvclZvdGluZ1Bvd2VyID0gKHZhbGlkYXRvcnMsIGFkZHJlc3MpID0+IHtcbi8vICAgICBmb3IgKHYgaW4gdmFsaWRhdG9ycyl7XG4vLyAgICAgICAgIGlmICh2YWxpZGF0b3JzW3ZdLmFkZHJlc3MgPT0gYWRkcmVzcyl7XG4vLyAgICAgICAgICAgICByZXR1cm4gcGFyc2VJbnQodmFsaWRhdG9yc1t2XS52b3RpbmdfcG93ZXIpO1xuLy8gICAgICAgICB9XG4vLyAgICAgfVxuLy8gfVxuXG5nZXRSZW1vdmVkVmFsaWRhdG9ycyA9IChwcmV2VmFsaWRhdG9ycywgdmFsaWRhdG9ycykgPT4ge1xuICAgIC8vIGxldCByZW1vdmVWYWxpZGF0b3JzID0gW107XG4gICAgZm9yIChwIGluIHByZXZWYWxpZGF0b3JzKXtcbiAgICAgICAgZm9yICh2IGluIHZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgaWYgKHByZXZWYWxpZGF0b3JzW3BdLmFkZHJlc3MgPT0gdmFsaWRhdG9yc1t2XS5hZGRyZXNzKXtcbiAgICAgICAgICAgICAgICBwcmV2VmFsaWRhdG9ycy5zcGxpY2UocCwxKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBwcmV2VmFsaWRhdG9ycztcbn1cblxuZ2V0VmFsaWRhdG9yUHJvZmlsZVVybCA9IChpZGVudGl0eSkgPT4ge1xuICAgIGlmIChpZGVudGl0eS5sZW5ndGggPT0gMTYpe1xuICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldChgaHR0cHM6Ly9rZXliYXNlLmlvL18vYXBpLzEuMC91c2VyL2xvb2t1cC5qc29uP2tleV9zdWZmaXg9JHtpZGVudGl0eX0mZmllbGRzPXBpY3R1cmVzYClcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKSB7XG4gICAgICAgICAgICBsZXQgdGhlbSA9IHJlc3BvbnNlLmRhdGEudGhlbVxuICAgICAgICAgICAgcmV0dXJuIHRoZW0gJiYgdGhlbS5sZW5ndGggJiYgdGhlbVswXS5waWN0dXJlcyAmJiB0aGVtWzBdLnBpY3R1cmVzLnByaW1hcnkgJiYgdGhlbVswXS5waWN0dXJlcy5wcmltYXJ5LnVybDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHJlc3BvbnNlKSlcbiAgICAgICAgfVxuICAgIH0gZWxzZSBpZiAoaWRlbnRpdHkuaW5kZXhPZihcImtleWJhc2UuaW8vdGVhbS9cIik+MCl7XG4gICAgICAgIGxldCB0ZWFtUGFnZSA9IEhUVFAuZ2V0KGlkZW50aXR5KTtcbiAgICAgICAgaWYgKHRlYW1QYWdlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgIGxldCBwYWdlID0gY2hlZXJpby5sb2FkKHRlYW1QYWdlLmNvbnRlbnQpO1xuICAgICAgICAgICAgcmV0dXJuIHBhZ2UoXCIua2ItbWFpbi1jYXJkIGltZ1wiKS5hdHRyKCdzcmMnKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHRlYW1QYWdlKSlcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLy8gdmFyIGZpbHRlcmVkID0gWzEsIDIsIDMsIDQsIDVdLmZpbHRlcihub3RDb250YWluZWRJbihbMSwgMiwgMywgNV0pKTtcbi8vIGNvbnNvbGUubG9nKGZpbHRlcmVkKTsgLy8gWzRdXG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnYmxvY2tzLmF2ZXJhZ2VCbG9ja1RpbWUnKGFkZHJlc3Mpe1xuICAgICAgICBsZXQgYmxvY2tzID0gQmxvY2tzY29uLmZpbmQoe3Byb3Bvc2VyQWRkcmVzczphZGRyZXNzfSkuZmV0Y2goKTtcbiAgICAgICAgbGV0IGhlaWdodHMgPSBibG9ja3MubWFwKChibG9jaywgaSkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIGJsb2NrLmhlaWdodDtcbiAgICAgICAgfSk7XG4gICAgICAgIGxldCBibG9ja3NTdGF0cyA9IEFuYWx5dGljcy5maW5kKHtoZWlnaHQ6eyRpbjpoZWlnaHRzfX0pLmZldGNoKCk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGJsb2Nrc1N0YXRzKTtcblxuICAgICAgICBsZXQgdG90YWxCbG9ja0RpZmYgPSAwO1xuICAgICAgICBmb3IgKGIgaW4gYmxvY2tzU3RhdHMpe1xuICAgICAgICAgICAgdG90YWxCbG9ja0RpZmYgKz0gYmxvY2tzU3RhdHNbYl0udGltZURpZmY7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRvdGFsQmxvY2tEaWZmL2hlaWdodHMubGVuZ3RoO1xuICAgIH0sXG4gICAgJ2Jsb2Nrcy5maW5kVXBUaW1lJyhhZGRyZXNzKXtcbiAgICAgICAgbGV0IGNvbGxlY3Rpb24gPSBWYWxpZGF0b3JSZWNvcmRzLnJhd0NvbGxlY3Rpb24oKTtcbiAgICAgICAgLy8gbGV0IGFnZ3JlZ2F0ZVF1ZXJ5ID0gTWV0ZW9yLndyYXBBc3luYyhjb2xsZWN0aW9uLmFnZ3JlZ2F0ZSwgY29sbGVjdGlvbik7XG4gICAgICAgIHZhciBwaXBlbGluZSA9IFtcbiAgICAgICAgICAgIHskbWF0Y2g6e1wiYWRkcmVzc1wiOmFkZHJlc3N9fSxcbiAgICAgICAgICAgIC8vIHskcHJvamVjdDp7YWRkcmVzczoxLGhlaWdodDoxLGV4aXN0czoxfX0sXG4gICAgICAgICAgICB7JHNvcnQ6e1wiaGVpZ2h0XCI6LTF9fSxcbiAgICAgICAgICAgIHskbGltaXQ6KE1ldGVvci5zZXR0aW5ncy5wdWJsaWMudXB0aW1lV2luZG93LTEpfSxcbiAgICAgICAgICAgIHskdW53aW5kOiBcIiRfaWRcIn0sXG4gICAgICAgICAgICB7JGdyb3VwOntcbiAgICAgICAgICAgICAgICBcIl9pZFwiOiBcIiRhZGRyZXNzXCIsXG4gICAgICAgICAgICAgICAgXCJ1cHRpbWVcIjoge1xuICAgICAgICAgICAgICAgICAgICBcIiRzdW1cIjp7XG4gICAgICAgICAgICAgICAgICAgICAgICAkY29uZDogW3skZXE6IFsnJGV4aXN0cycsIHRydWVdfSwgMSwgMF1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1dO1xuICAgICAgICAvLyBsZXQgcmVzdWx0ID0gYWdncmVnYXRlUXVlcnkocGlwZWxpbmUsIHsgY3Vyc29yOiB7fSB9KTtcblxuICAgICAgICByZXR1cm4gUHJvbWlzZS5hd2FpdChjb2xsZWN0aW9uLmFnZ3JlZ2F0ZShwaXBlbGluZSkudG9BcnJheSgpKTtcbiAgICAgICAgLy8gcmV0dXJuIC5hZ2dyZWdhdGUoKVxuICAgIH0sXG4gICAgJ2Jsb2Nrcy5nZXRMYXRlc3RIZWlnaHQnOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB1cmwgPSBSUEMrJy9zdGF0dXMnO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgbGV0IHN0YXR1cyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICByZXR1cm4gKHN0YXR1cy5yZXN1bHQuc3luY19pbmZvLmxhdGVzdF9ibG9ja19oZWlnaHQpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAnYmxvY2tzLmdldEN1cnJlbnRIZWlnaHQnOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCBjdXJySGVpZ2h0ID0gQmxvY2tzY29uLmZpbmQoe30se3NvcnQ6e2hlaWdodDotMX0sbGltaXQ6MX0pLmZldGNoKCk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiY3VycmVudEhlaWdodDpcIitjdXJySGVpZ2h0KTtcbiAgICAgICAgbGV0IHN0YXJ0SGVpZ2h0ID0gTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGFydEhlaWdodDtcbiAgICAgICAgaWYgKGN1cnJIZWlnaHQgJiYgY3VyckhlaWdodC5sZW5ndGggPT0gMSkge1xuICAgICAgICAgICAgbGV0IGhlaWdodCA9IGN1cnJIZWlnaHRbMF0uaGVpZ2h0O1xuICAgICAgICAgICAgaWYgKGhlaWdodCA+IHN0YXJ0SGVpZ2h0KVxuICAgICAgICAgICAgICAgIHJldHVybiBoZWlnaHRcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc3RhcnRIZWlnaHRcbiAgICB9LFxuICAgICdibG9ja3MuYmxvY2tzVXBkYXRlJzogZnVuY3Rpb24oKSB7XG4gICAgICAgIGlmIChTWU5DSU5HKVxuICAgICAgICAgICAgcmV0dXJuIFwiU3luY2luZy4uLlwiO1xuICAgICAgICBlbHNlIGNvbnNvbGUubG9nKFwic3RhcnQgdG8gc3luY1wiKTtcbiAgICAgICAgLy8gTWV0ZW9yLmNsZWFySW50ZXJ2YWwoTWV0ZW9yLnRpbWVySGFuZGxlKTtcbiAgICAgICAgLy8gZ2V0IHRoZSBsYXRlc3QgaGVpZ2h0XG4gICAgICAgIGxldCB1bnRpbCA9IE1ldGVvci5jYWxsKCdibG9ja3MuZ2V0TGF0ZXN0SGVpZ2h0Jyk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHVudGlsKTtcbiAgICAgICAgLy8gZ2V0IHRoZSBjdXJyZW50IGhlaWdodCBpbiBkYlxuICAgICAgICBsZXQgY3VyciA9IE1ldGVvci5jYWxsKCdibG9ja3MuZ2V0Q3VycmVudEhlaWdodCcpO1xuICAgICAgICBjb25zb2xlLmxvZyhjdXJyKTtcbiAgICAgICAgLy8gbG9vcCBpZiB0aGVyZSdzIHVwZGF0ZSBpbiBkYlxuICAgICAgICBpZiAodW50aWwgPiBjdXJyKSB7XG4gICAgICAgICAgICBTWU5DSU5HID0gdHJ1ZTtcblxuICAgICAgICAgICAgbGV0IHZhbGlkYXRvclNldCA9IHt9XG4gICAgICAgICAgICAvLyBnZXQgbGF0ZXN0IHZhbGlkYXRvciBjYW5kaWRhdGUgaW5mb3JtYXRpb25cbiAgICAgICAgICAgIHVybCA9IExDRCsnL3N0YWtpbmcvdmFsaWRhdG9ycyc7XG5cbiAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQuZm9yRWFjaCgodmFsaWRhdG9yKSA9PiB2YWxpZGF0b3JTZXRbdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXldID0gdmFsaWRhdG9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB1cmwgPSBMQ0QrJy9zdGFraW5nL3ZhbGlkYXRvcnM/c3RhdHVzPXVuYm9uZGluZyc7XG5cbiAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQuZm9yRWFjaCgodmFsaWRhdG9yKSA9PiB2YWxpZGF0b3JTZXRbdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXldID0gdmFsaWRhdG9yKVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHVybCA9IExDRCsnL3N0YWtpbmcvdmFsaWRhdG9ycz9zdGF0dXM9dW5ib25kZWQnO1xuXG4gICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgIEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0LmZvckVhY2goKHZhbGlkYXRvcikgPT4gdmFsaWRhdG9yU2V0W3ZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5XSA9IHZhbGlkYXRvcilcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IHRvdGFsVmFsaWRhdG9ycyA9IE9iamVjdC5rZXlzKHZhbGlkYXRvclNldCkubGVuZ3RoO1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhbGwgdmFsaWRhdG9yczogXCIrIHRvdGFsVmFsaWRhdG9ycyk7XG4gICAgICAgICAgICBmb3IgKGxldCBoZWlnaHQgPSBjdXJyKzEgOyBoZWlnaHQgPD0gdW50aWwgOyBoZWlnaHQrKykge1xuICAgICAgICAgICAgICAgIGxldCBzdGFydEJsb2NrVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgLy8gYWRkIHRpbWVvdXQgaGVyZT8gYW5kIG91dHNpZGUgdGhpcyBsb29wIChmb3IgY2F0Y2hlZCB1cCBhbmQga2VlcCBmZXRjaGluZyk/XG4gICAgICAgICAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgICAgICAgICAgbGV0IHVybCA9IFJQQysnL2Jsb2NrP2hlaWdodD0nICsgaGVpZ2h0O1xuICAgICAgICAgICAgICAgIGxldCBhbmFseXRpY3NEYXRhID0ge307XG5cbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYnVsa1ZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLnJhd0NvbGxlY3Rpb24oKS5pbml0aWFsaXplVW5vcmRlcmVkQnVsa09wKCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtWYWxpZGF0b3JSZWNvcmRzID0gVmFsaWRhdG9yUmVjb3Jkcy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBidWxrVlBIaXN0b3J5ID0gVm90aW5nUG93ZXJIaXN0b3J5LnJhd0NvbGxlY3Rpb24oKS5pbml0aWFsaXplVW5vcmRlcmVkQnVsa09wKCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtUcmFuc2F0aW9ucyA9IFRyYW5zYWN0aW9ucy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuXG4gICAgICAgICAgICAgICAgICAgIGxldCBzdGFydEdldEhlaWdodFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJsb2NrID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrID0gYmxvY2sucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gc3RvcmUgaGVpZ2h0LCBoYXNoLCBudW10cmFuc2FjdGlvbiBhbmQgdGltZSBpbiBkYlxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJsb2NrRGF0YSA9IHt9O1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLmhlaWdodCA9IGhlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS5oYXNoID0gYmxvY2suYmxvY2tfaWQuaGFzaDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS50cmFuc051bSA9IChibG9jay5ibG9jay5kYXRhLnR4cyA9PT0gbnVsbCkgPyAwIDogYmxvY2suYmxvY2suZGF0YS50eHMubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLnRpbWUgPSBuZXcgRGF0ZShibG9jay5ibG9jay5oZWFkZXIudGltZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEubGFzdEJsb2NrSGFzaCA9IGJsb2NrLmJsb2NrLmhlYWRlci5sYXN0X2Jsb2NrX2lkLmhhc2g7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEucHJvcG9zZXJBZGRyZXNzID0gYmxvY2suYmxvY2suaGVhZGVyLnByb3Bvc2VyX2FkZHJlc3M7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEudmFsaWRhdG9ycyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByZWNvbW1pdHMgPSBibG9jay5ibG9jay5sYXN0X2NvbW1pdC5zaWduYXR1cmVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByZWNvbW1pdHMgIT0gbnVsbCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2cocHJlY29tbWl0cy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGk9MDsgaTxwcmVjb21taXRzLmxlbmd0aDsgaSsrKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByZWNvbW1pdHNbaV0gIT0gbnVsbCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEudmFsaWRhdG9ycy5wdXNoKHByZWNvbW1pdHNbaV0udmFsaWRhdG9yX2FkZHJlc3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS5wcmVjb21taXRzID0gcHJlY29tbWl0cy5sZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gcmVjb3JkIGZvciBhbmFseXRpY3NcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBQcmVjb21taXRSZWNvcmRzLmluc2VydCh7aGVpZ2h0OmhlaWdodCwgcHJlY29tbWl0czpwcmVjb21taXRzLmxlbmd0aH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzYXZlIHR4cyBpbiBkYXRhYmFzZVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGJsb2NrLmJsb2NrLmRhdGEudHhzICYmIGJsb2NrLmJsb2NrLmRhdGEudHhzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodCBpbiBibG9jay5ibG9jay5kYXRhLnR4cyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1ldGVvci5jYWxsKCdUcmFuc2FjdGlvbnMuaW5kZXgnLCBzaGEyNTYoQnVmZmVyLmZyb20oYmxvY2suYmxvY2suZGF0YS50eHNbdF0sICdiYXNlNjQnKSksIGJsb2NrRGF0YS50aW1lLCAoZXJyLCByZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gc2F2ZSBkb3VibGUgc2lnbiBldmlkZW5jZXNcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChibG9jay5ibG9jay5ldmlkZW5jZS5ldmlkZW5jZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRXZpZGVuY2VzLmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBldmlkZW5jZTogYmxvY2suYmxvY2suZXZpZGVuY2UuZXZpZGVuY2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLnByZWNvbW1pdHNDb3VudCA9IGJsb2NrRGF0YS52YWxpZGF0b3JzLmxlbmd0aDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS5oZWlnaHQgPSBoZWlnaHQ7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlbmRHZXRIZWlnaHRUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiR2V0IGhlaWdodCB0aW1lOiBcIisoKGVuZEdldEhlaWdodFRpbWUtc3RhcnRHZXRIZWlnaHRUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzdGFydEdldFZhbGlkYXRvcnNUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHVwZGF0ZSBjaGFpbiBzdGF0dXNcbiAgICAgICAgICAgICAgICAgICAgICAgIHVybCA9IFJQQysnL3ZhbGlkYXRvcnM/aGVpZ2h0PScraGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2codXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3JzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvcnMucmVzdWx0LmJsb2NrX2hlaWdodCA9IHBhcnNlSW50KHZhbGlkYXRvcnMucmVzdWx0LmJsb2NrX2hlaWdodCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBWYWxpZGF0b3JTZXRzLmluc2VydCh2YWxpZGF0b3JzLnJlc3VsdCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS52YWxpZGF0b3JzQ291bnQgPSB2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzdGFydEJsb2NrSW5zZXJ0VGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBCbG9ja3Njb24uaW5zZXJ0KGJsb2NrRGF0YSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZW5kQmxvY2tJbnNlcnRUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQmxvY2sgaW5zZXJ0IHRpbWU6IFwiKygoZW5kQmxvY2tJbnNlcnRUaW1lLXN0YXJ0QmxvY2tJbnNlcnRUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzdG9yZSB2YWxkaWF0b3JzIGV4aXN0IHJlY29yZHNcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBleGlzdGluZ1ZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe2FkZHJlc3M6eyRleGlzdHM6dHJ1ZX19KS5mZXRjaCgpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVpZ2h0ID4gMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gcmVjb3JkIHByZWNvbW1pdHMgYW5kIGNhbGN1bGF0ZSB1cHRpbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBvbmx5IHJlY29yZCBmcm9tIGJsb2NrIDJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGkgaW4gdmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBhZGRyZXNzID0gdmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9yc1tpXS5hZGRyZXNzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVjb3JkID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBoZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOiBhZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhpc3RzOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogcGFyc2VJbnQodmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9yc1tpXS52b3RpbmdfcG93ZXIpLy9nZXRWYWxpZGF0b3JWb3RpbmdQb3dlcihleGlzdGluZ1ZhbGlkYXRvcnMsIGFkZHJlc3MpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGogaW4gcHJlY29tbWl0cyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJlY29tbWl0c1tqXSAhPSBudWxsKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYWRkcmVzcyA9PSBwcmVjb21taXRzW2pdLnZhbGlkYXRvcl9hZGRyZXNzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVjb3JkLmV4aXN0cyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZWNvbW1pdHMuc3BsaWNlKGosMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNhbGN1bGF0ZSB0aGUgdXB0aW1lIGJhc2VkIG9uIHRoZSByZWNvcmRzIHN0b3JlZCBpbiBwcmV2aW91cyBibG9ja3NcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gb25seSBkbyB0aGlzIGV2ZXJ5IDE1IGJsb2NrcyB+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKChoZWlnaHQgJSAxNSkgPT0gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBsZXQgc3RhcnRBZ2dUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBudW1CbG9ja3MgPSBNZXRlb3IuY2FsbCgnYmxvY2tzLmZpbmRVcFRpbWUnLCBhZGRyZXNzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB1cHRpbWUgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGV0IGVuZEFnZ1RpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCJHZXQgYWdncmVnYXRlZCB1cHRpbWUgZm9yIFwiK2V4aXN0aW5nVmFsaWRhdG9yc1tpXS5hZGRyZXNzK1wiOiBcIisoKGVuZEFnZ1RpbWUtc3RhcnRBZ2dUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKChudW1CbG9ja3NbMF0gIT0gbnVsbCkgJiYgKG51bUJsb2Nrc1swXS51cHRpbWUgIT0gbnVsbCkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwdGltZSA9IG51bUJsb2Nrc1swXS51cHRpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBiYXNlID0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy51cHRpbWVXaW5kb3c7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVpZ2h0IDwgYmFzZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFzZSA9IGhlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlY29yZC5leGlzdHMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh1cHRpbWUgPCBiYXNlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXB0aW1lKys7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwdGltZSA9ICh1cHRpbWUgLyBiYXNlKSoxMDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7YWRkcmVzczphZGRyZXNzfSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0Ont1cHRpbWU6dXB0aW1lLCBsYXN0U2VlbjpibG9ja0RhdGEudGltZX19KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXB0aW1lID0gKHVwdGltZSAvIGJhc2UpKjEwMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHthZGRyZXNzOmFkZHJlc3N9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6e3VwdGltZTp1cHRpbWV9fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9yUmVjb3Jkcy5pbnNlcnQocmVjb3JkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gVmFsaWRhdG9yUmVjb3Jkcy51cGRhdGUoe2hlaWdodDpoZWlnaHQsYWRkcmVzczpyZWNvcmQuYWRkcmVzc30scmVjb3JkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjaGFpblN0YXR1cyA9IENoYWluLmZpbmRPbmUoe2NoYWluSWQ6YmxvY2suYmxvY2suaGVhZGVyLmNoYWluX2lkfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgbGFzdFN5bmNlZFRpbWUgPSBjaGFpblN0YXR1cz9jaGFpblN0YXR1cy5sYXN0U3luY2VkVGltZTowO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHRpbWVEaWZmO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJsb2NrVGltZSA9IE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuZGVmYXVsdEJsb2NrVGltZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChsYXN0U3luY2VkVGltZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGVMYXRlc3QgPSBibG9ja0RhdGEudGltZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgZGF0ZUxhc3QgPSBuZXcgRGF0ZShsYXN0U3luY2VkVGltZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZURpZmYgPSBNYXRoLmFicyhkYXRlTGF0ZXN0LmdldFRpbWUoKSAtIGRhdGVMYXN0LmdldFRpbWUoKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGlzcmVnYXJkIGZpcnN0IGNvdXBsZSBvZiBibG9ja3MgdG8gYXZvaWQgaGlnaCBhdmcgdGltZSBkdWUgdG8gZ2VuZXNpcyBkYXRlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYoYmxvY2tEYXRhLmhlaWdodCA+IDIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tUaW1lID0gKGNoYWluU3RhdHVzLmJsb2NrVGltZSAqIChibG9ja0RhdGEuaGVpZ2h0IC0gMSkgKyB0aW1lRGlmZikgLyBibG9ja0RhdGEuaGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGVuZEdldFZhbGlkYXRvcnNUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiR2V0IGhlaWdodCB2YWxpZGF0b3JzIHRpbWU6IFwiKygoZW5kR2V0VmFsaWRhdG9yc1RpbWUtc3RhcnRHZXRWYWxpZGF0b3JzVGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOmJsb2NrLmJsb2NrLmhlYWRlci5jaGFpbl9pZH0sIHskc2V0OntsYXN0U3luY2VkVGltZTpibG9ja0RhdGEudGltZSwgYmxvY2tUaW1lOmJsb2NrVGltZX19KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS5hdmVyYWdlQmxvY2tUaW1lID0gYmxvY2tUaW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS50aW1lRGlmZiA9IHRpbWVEaWZmO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLnRpbWUgPSBibG9ja0RhdGEudGltZTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gaW5pdGlhbGl6ZSB2YWxpZGF0b3IgZGF0YSBhdCBmaXJzdCBibG9ja1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gaWYgKGhlaWdodCA9PSAxKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICBWYWxpZGF0b3JzLnJlbW92ZSh7fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGFuYWx5dGljc0RhdGEudm90aW5nX3Bvd2VyID0gMDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0RmluZFZhbGlkYXRvcnNOYW1lVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9ycy5yZXN1bHQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvcnMgYXJlIGFsbCB0aGUgdmFsaWRhdG9ycyBpbiB0aGUgY3VycmVudCBoZWlnaHRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInZhbGlkYXRvclNldCBzaXplOiBcIit2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzLmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2IGluIHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBWYWxpZGF0b3JzLmluc2VydCh2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzW3ZdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvciA9IHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnNbdl07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci52b3RpbmdfcG93ZXIgPSBwYXJzZUludCh2YWxpZGF0b3Iudm90aW5nX3Bvd2VyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnByb3Bvc2VyX3ByaW9yaXR5ID0gcGFyc2VJbnQodmFsaWRhdG9yLnByb3Bvc2VyX3ByaW9yaXR5KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsRXhpc3QgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe1wicHViX2tleS52YWx1ZVwiOnZhbGlkYXRvci5wdWJfa2V5LnZhbHVlfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdmFsRXhpc3Qpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coYHZhbGlkYXRvciBwdWJfa2V5ICR7dmFsaWRhdG9yLmFkZHJlc3N9ICR7dmFsaWRhdG9yLnB1Yl9rZXkudmFsdWV9IG5vdCBpbiBkYmApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGV0IGNvbW1hbmQgPSBNZXRlb3Iuc2V0dGluZ3MuYmluLmdhaWFkZWJ1ZytcIiBwdWJrZXkgXCIrdmFsaWRhdG9yLnB1Yl9rZXkudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhjb21tYW5kKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGxldCB0ZW1wVmFsID0gdmFsaWRhdG9yO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYWRkcmVzcyA9IGdldEFkZHJlc3ModmFsaWRhdG9yLnB1Yl9rZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFjY3B1YiA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbGlkYXRvci5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY1B1Yik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsUHViKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5ID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4Q29uc1B1Yik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3JEYXRhID0gdmFsaWRhdG9yU2V0W3ZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5XVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvckRhdGEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JEYXRhLmRlc2NyaXB0aW9uLmlkZW50aXR5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHJvZmlsZV91cmwgPSAgZ2V0VmFsaWRhdG9yUHJvZmlsZVVybCh2YWxpZGF0b3JEYXRhLmRlc2NyaXB0aW9uLmlkZW50aXR5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5vcGVyYXRvcl9hZGRyZXNzID0gdmFsaWRhdG9yRGF0YS5vcGVyYXRvcl9hZGRyZXNzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZWxlZ2F0b3JfYWRkcmVzcyA9IE1ldGVvci5jYWxsKCdnZXREZWxlZ2F0b3InLCB2YWxpZGF0b3JEYXRhLm9wZXJhdG9yX2FkZHJlc3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5qYWlsZWQgPSB2YWxpZGF0b3JEYXRhLmphaWxlZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iuc3RhdHVzID0gdmFsaWRhdG9yRGF0YS5zdGF0dXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLm1pbl9zZWxmX2RlbGVnYXRpb24gPSB2YWxpZGF0b3JEYXRhLm1pbl9zZWxmX2RlbGVnYXRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnRva2VucyA9IHZhbGlkYXRvckRhdGEudG9rZW5zO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzID0gdmFsaWRhdG9yRGF0YS5kZWxlZ2F0b3Jfc2hhcmVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZXNjcmlwdGlvbiA9IHZhbGlkYXRvckRhdGEuZGVzY3JpcHRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmJvbmRfaGVpZ2h0ID0gdmFsaWRhdG9yRGF0YS5ib25kX2hlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYm9uZF9pbnRyYV90eF9jb3VudGVyID0gdmFsaWRhdG9yRGF0YS5ib25kX2ludHJhX3R4X2NvdW50ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnVuYm9uZGluZ19oZWlnaHQgPSB2YWxpZGF0b3JEYXRhLnVuYm9uZGluZ19oZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnVuYm9uZGluZ190aW1lID0gdmFsaWRhdG9yRGF0YS51bmJvbmRpbmdfdGltZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuY29tbWlzc2lvbiA9IHZhbGlkYXRvckRhdGEuY29tbWlzc2lvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iuc2VsZl9kZWxlZ2F0aW9uID0gdmFsaWRhdG9yLmRlbGVnYXRvcl9zaGFyZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLnJlbW92ZWQgPSBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IucmVtb3ZlZEF0ID0gMFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvclNldC5zcGxpY2UodmFsLCAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ25vIGNvbiBwdWIga2V5PycpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGJ1bGtWYWxpZGF0b3JzLmluc2VydCh2YWxpZGF0b3IpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7Y29uc2Vuc3VzX3B1YmtleTogdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXl9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6dmFsaWRhdG9yfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcInZhbGlkYXRvciBmaXJzdCBhcHBlYXJzOiBcIitidWxrVmFsaWRhdG9ycy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZQSGlzdG9yeS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IHZhbGlkYXRvci5hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZXZfdm90aW5nX3Bvd2VyOiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogdmFsaWRhdG9yLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnYWRkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGJsb2NrRGF0YS5oZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogYmxvY2tEYXRhLnRpbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBNZXRlb3IuY2FsbCgncnVuQ29kZScsIGNvbW1hbmQsIGZ1bmN0aW9uKGVycm9yLCByZXN1bHQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmFkZHJlc3MgPSByZXN1bHQubWF0Y2goL1xcc1swLTlBLUZdezQwfSQvaWdtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5hZGRyZXNzID0gdmFsaWRhdG9yLmFkZHJlc3NbMF0udHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmhleCA9IHJlc3VsdC5tYXRjaCgvXFxzWzAtOUEtRl17NjR9JC9pZ20pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmhleCA9IHZhbGlkYXRvci5oZXhbMF0udHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmNvc21vc2FjY3B1YiA9IHJlc3VsdC5tYXRjaCgvY29zbW9zcHViLiokL2lnbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuY29zbW9zYWNjcHViID0gdmFsaWRhdG9yLmNvc21vc2FjY3B1YlswXS50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gcmVzdWx0Lm1hdGNoKC9jb3Ntb3N2YWxvcGVycHViLiokL2lnbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gdmFsaWRhdG9yLm9wZXJhdG9yX3B1YmtleVswXS50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleSA9IHJlc3VsdC5tYXRjaCgvY29zbW9zdmFsY29uc3B1Yi4qJC9pZ20pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXkgPSB2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleVswXS50cmltKCk7XG5cblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNle1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvckRhdGEgPSB2YWxpZGF0b3JTZXRbdmFsRXhpc3QuY29uc2Vuc3VzX3B1YmtleV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JEYXRhKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yRGF0YS5kZXNjcmlwdGlvbiAmJiAoIXZhbEV4aXN0LmRlc2NyaXB0aW9uIHx8IHZhbGlkYXRvckRhdGEuZGVzY3JpcHRpb24uaWRlbnRpdHkgIT09IHZhbEV4aXN0LmRlc2NyaXB0aW9uLmlkZW50aXR5KSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnByb2ZpbGVfdXJsID0gIGdldFZhbGlkYXRvclByb2ZpbGVVcmwodmFsaWRhdG9yRGF0YS5kZXNjcmlwdGlvbi5pZGVudGl0eSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuamFpbGVkID0gdmFsaWRhdG9yRGF0YS5qYWlsZWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnN0YXR1cyA9IHZhbGlkYXRvckRhdGEuc3RhdHVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci50b2tlbnMgPSB2YWxpZGF0b3JEYXRhLnRva2VucztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuZGVsZWdhdG9yX3NoYXJlcyA9IHZhbGlkYXRvckRhdGEuZGVsZWdhdG9yX3NoYXJlcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuZGVzY3JpcHRpb24gPSB2YWxpZGF0b3JEYXRhLmRlc2NyaXB0aW9uO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5ib25kX2hlaWdodCA9IHZhbGlkYXRvckRhdGEuYm9uZF9oZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmJvbmRfaW50cmFfdHhfY291bnRlciA9IHZhbGlkYXRvckRhdGEuYm9uZF9pbnRyYV90eF9jb3VudGVyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci51bmJvbmRpbmdfaGVpZ2h0ID0gdmFsaWRhdG9yRGF0YS51bmJvbmRpbmdfaGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci51bmJvbmRpbmdfdGltZSA9IHZhbGlkYXRvckRhdGEudW5ib25kaW5nX3RpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmNvbW1pc3Npb24gPSB2YWxpZGF0b3JEYXRhLmNvbW1pc3Npb247XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjYWxjdWxhdGUgc2VsZiBkZWxlZ2F0aW9uIHBlcmNlbnRhZ2UgZXZlcnkgMzAgYmxvY2tzXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVpZ2h0ICUgMzAgPT0gMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KExDRCArICcvc3Rha2luZy9kZWxlZ2F0b3JzLycrdmFsRXhpc3QuZGVsZWdhdG9yX2FkZHJlc3MrJy9kZWxlZ2F0aW9ucy8nK3ZhbEV4aXN0Lm9wZXJhdG9yX2FkZHJlc3MpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzZWxmRGVsZWdhdGlvbiA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzZWxmRGVsZWdhdGlvbi5zaGFyZXMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iuc2VsZl9kZWxlZ2F0aW9uID0gcGFyc2VGbG9hdChzZWxmRGVsZWdhdGlvbi5zaGFyZXMpL3BhcnNlRmxvYXQodmFsaWRhdG9yLmRlbGVnYXRvcl9zaGFyZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7Y29uc2Vuc3VzX3B1YmtleTogdmFsRXhpc3QuY29uc2Vuc3VzX3B1YmtleX0pLnVwZGF0ZU9uZSh7JHNldDp2YWxpZGF0b3J9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcInZhbGlkYXRvciBleGlzaXRzOiBcIitidWxrVmFsaWRhdG9ycy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvclNldC5zcGxpY2UodmFsLCAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdubyBjb24gcHViIGtleT8nKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByZXZWb3RpbmdQb3dlciA9IFZvdGluZ1Bvd2VySGlzdG9yeS5maW5kT25lKHthZGRyZXNzOnZhbGlkYXRvci5hZGRyZXNzfSwge2hlaWdodDotMSwgbGltaXQ6MX0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJldlZvdGluZ1Bvd2VyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJldlZvdGluZ1Bvd2VyLnZvdGluZ19wb3dlciAhPSB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNoYW5nZVR5cGUgPSAocHJldlZvdGluZ1Bvd2VyLnZvdGluZ19wb3dlciA+IHZhbGlkYXRvci52b3RpbmdfcG93ZXIpPydkb3duJzondXAnO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgY2hhbmdlRGF0YSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IHZhbGlkYXRvci5hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IHByZXZWb3RpbmdQb3dlci52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IHZhbGlkYXRvci52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBjaGFuZ2VUeXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBibG9ja0RhdGEuaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogYmxvY2tEYXRhLnRpbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ3ZvdGluZyBwb3dlciBjaGFuZ2VkLicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhjaGFuZ2VEYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZQSGlzdG9yeS5pbnNlcnQoY2hhbmdlRGF0YSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHZhbGlkYXRvcik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS52b3RpbmdfcG93ZXIgKz0gdmFsaWRhdG9yLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBpZiB0aGVyZSBpcyB2YWxpZGF0b3IgcmVtb3ZlZFxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByZXZWYWxpZGF0b3JzID0gVmFsaWRhdG9yU2V0cy5maW5kT25lKHtibG9ja19oZWlnaHQ6aGVpZ2h0LTF9KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmV2VmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZW1vdmVkVmFsaWRhdG9ycyA9IGdldFJlbW92ZWRWYWxpZGF0b3JzKHByZXZWYWxpZGF0b3JzLnZhbGlkYXRvcnMsIHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnMpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAociBpbiByZW1vdmVkVmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVlBIaXN0b3J5Lmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogcmVtb3ZlZFZhbGlkYXRvcnNbcl0uYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmV2X3ZvdGluZ19wb3dlcjogcmVtb3ZlZFZhbGlkYXRvcnNbcl0udm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAncmVtb3ZlJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGJsb2NrRGF0YS5oZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogYmxvY2tEYXRhLnRpbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2hlY2sgaWYgdGhlcmUncyBhbnkgdmFsaWRhdG9yIG5vdCBpbiBkYiAxNDQwMCBibG9ja3MofjEgZGF5KVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGhlaWdodCAlIDE0NDAwID09IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdDaGVja2luZyBhbGwgdmFsaWRhdG9ycyBhZ2FpbnN0IGRiLi4uJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRiVmFsaWRhdG9ycyA9IHt9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZhbGlkYXRvcnMuZmluZCh7fSwge2ZpZWxkczoge2NvbnNlbnN1c19wdWJrZXk6IDEsIHN0YXR1czogMX19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLmZvckVhY2goKHYpID0+IGRiVmFsaWRhdG9yc1t2LmNvbnNlbnN1c19wdWJrZXldID0gdi5zdGF0dXMpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE9iamVjdC5rZXlzKHZhbGlkYXRvclNldCkuZm9yRWFjaCgoY29uUHViS2V5KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yRGF0YSA9IHZhbGlkYXRvclNldFtjb25QdWJLZXldO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQWN0aXZlIHZhbGlkYXRvcnMgc2hvdWxkIGhhdmUgYmVlbiB1cGRhdGVkIGluIHByZXZpb3VzIHN0ZXBzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yRGF0YS5zdGF0dXMgPT09IDIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkYlZhbGlkYXRvcnNbY29uUHViS2V5XSA9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgdmFsaWRhdG9yIHdpdGggY29uc2Vuc3VzX3B1YmtleSAke2NvblB1YktleX0gbm90IGluIGRiYCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JEYXRhLnB1Yl9rZXkgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwidHlwZVwiIDogXCJ0ZW5kZXJtaW50L1B1YktleUVkMjU1MTlcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ2YWx1ZVwiOiBNZXRlb3IuY2FsbCgnYmVjaDMyVG9QdWJrZXknLCBjb25QdWJLZXkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvckRhdGEuYWRkcmVzcyA9IGdldEFkZHJlc3ModmFsaWRhdG9yRGF0YS5wdWJfa2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JEYXRhLmRlbGVnYXRvcl9hZGRyZXNzID0gTWV0ZW9yLmNhbGwoJ2dldERlbGVnYXRvcicsIHZhbGlkYXRvckRhdGEub3BlcmF0b3JfYWRkcmVzcyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JEYXRhLmFjY3B1YiA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbGlkYXRvckRhdGEucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhBY2NQdWIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvckRhdGEub3BlcmF0b3JfcHVia2V5ID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yRGF0YS5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeFZhbFB1Yik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkodmFsaWRhdG9yRGF0YSkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7Y29uc2Vuc3VzX3B1YmtleTogY29uUHViS2V5fSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OnZhbGlkYXRvckRhdGF9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoZGJWYWxpZGF0b3JzW2NvblB1YktleV0gPT0gMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JzLmZpbmQoe2NvbnNlbnN1c19wdWJrZXk6IGNvblB1YktleX0pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDp2YWxpZGF0b3JEYXRhfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBmZXRjaGluZyBrZXliYXNlIGV2ZXJ5IDE0NDAwIGJsb2Nrcyh+MSBkYXkpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVpZ2h0ICUgMTQ0MDAgPT0gMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0ZldGNoaW5nIGtleWJhc2UuLi4nKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZhbGlkYXRvcnMuZmluZCh7fSkuZm9yRWFjaCgodmFsaWRhdG9yKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJvZmlsZVVybCA9ICBnZXRWYWxpZGF0b3JQcm9maWxlVXJsKHZhbGlkYXRvci5kZXNjcmlwdGlvbi5pZGVudGl0eSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcm9maWxlVXJsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7YWRkcmVzczogdmFsaWRhdG9yLmFkZHJlc3N9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OnsncHJvZmlsZV91cmwnOnByb2ZpbGVVcmx9fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZW5kRmluZFZhbGlkYXRvcnNOYW1lVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkdldCB2YWxpZGF0b3JzIG5hbWUgdGltZTogXCIrKChlbmRGaW5kVmFsaWRhdG9yc05hbWVUaW1lLXN0YXJ0RmluZFZhbGlkYXRvcnNOYW1lVGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gcmVjb3JkIGZvciBhbmFseXRpY3NcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzdGFydEFuYXl0aWNzSW5zZXJ0VGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBBbmFseXRpY3MuaW5zZXJ0KGFuYWx5dGljc0RhdGEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGVuZEFuYWx5dGljc0luc2VydFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJBbmFseXRpY3MgaW5zZXJ0IHRpbWU6IFwiKygoZW5kQW5hbHl0aWNzSW5zZXJ0VGltZS1zdGFydEFuYXl0aWNzSW5zZXJ0VGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0VlVwVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYnVsa1ZhbGlkYXRvcnMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coYnVsa1ZhbGlkYXRvcnMubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5leGVjdXRlKChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlbmRWVXBUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiVmFsaWRhdG9yIHVwZGF0ZSB0aW1lOiBcIisoKGVuZFZVcFRpbWUtc3RhcnRWVXBUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRWUlRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGJ1bGtWYWxpZGF0b3JSZWNvcmRzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JSZWNvcmRzLmV4ZWN1dGUoKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZW5kVlJUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiVmFsaWRhdG9yIHJlY29yZHMgdXBkYXRlIHRpbWU6IFwiKygoZW5kVlJUaW1lLXN0YXJ0VlJUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYnVsa1ZQSGlzdG9yeS5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVlBIaXN0b3J5LmV4ZWN1dGUoKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYnVsa1RyYW5zYXRpb25zLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtUcmFuc2F0aW9ucy5leGVjdXRlKChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2FsY3VsYXRlIHZvdGluZyBwb3dlciBkaXN0cmlidXRpb24gZXZlcnkgNjAgYmxvY2tzIH4gNW1pbnNcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGhlaWdodCAlIDYwID09IDEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiPT09PT0gY2FsY3VsYXRlIHZvdGluZyBwb3dlciBkaXN0cmlidXRpb24gPT09PT1cIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGFjdGl2ZVZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe3N0YXR1czoyLGphaWxlZDpmYWxzZX0se3NvcnQ6e3ZvdGluZ19wb3dlcjotMX19KS5mZXRjaCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBudW1Ub3BUd2VudHkgPSBNYXRoLmNlaWwoYWN0aXZlVmFsaWRhdG9ycy5sZW5ndGgqMC4yKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgbnVtQm90dG9tRWlnaHR5ID0gYWN0aXZlVmFsaWRhdG9ycy5sZW5ndGggLSBudW1Ub3BUd2VudHk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdG9wVHdlbnR5UG93ZXIgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBib3R0b21FaWdodHlQb3dlciA9IDA7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgbnVtVG9wVGhpcnR5Rm91ciA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG51bUJvdHRvbVNpeHR5U2l4ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdG9wVGhpcnR5Rm91clBlcmNlbnQgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBib3R0b21TaXh0eVNpeFBlcmNlbnQgPSAwO1xuXG5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodiBpbiBhY3RpdmVWYWxpZGF0b3JzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHYgPCBudW1Ub3BUd2VudHkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wVHdlbnR5UG93ZXIgKz0gYWN0aXZlVmFsaWRhdG9yc1t2XS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvdHRvbUVpZ2h0eVBvd2VyICs9IGFjdGl2ZVZhbGlkYXRvcnNbdl0udm90aW5nX3Bvd2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodG9wVGhpcnR5Rm91clBlcmNlbnQgPCAwLjM0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvcFRoaXJ0eUZvdXJQZXJjZW50ICs9IGFjdGl2ZVZhbGlkYXRvcnNbdl0udm90aW5nX3Bvd2VyIC8gYW5hbHl0aWNzRGF0YS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Ub3BUaGlydHlGb3VyKys7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3R0b21TaXh0eVNpeFBlcmNlbnQgPSAxIC0gdG9wVGhpcnR5Rm91clBlcmNlbnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVtQm90dG9tU2l4dHlTaXggPSBhY3RpdmVWYWxpZGF0b3JzLmxlbmd0aCAtIG51bVRvcFRoaXJ0eUZvdXI7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdnBEaXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVtVG9wVHdlbnR5OiBudW1Ub3BUd2VudHksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvcFR3ZW50eVBvd2VyOiB0b3BUd2VudHlQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVtQm90dG9tRWlnaHR5OiBudW1Cb3R0b21FaWdodHksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvdHRvbUVpZ2h0eVBvd2VyOiBib3R0b21FaWdodHlQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVtVG9wVGhpcnR5Rm91cjogbnVtVG9wVGhpcnR5Rm91cixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wVGhpcnR5Rm91clBlcmNlbnQ6IHRvcFRoaXJ0eUZvdXJQZXJjZW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Cb3R0b21TaXh0eVNpeDogbnVtQm90dG9tU2l4dHlTaXgsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvdHRvbVNpeHR5U2l4UGVyY2VudDogYm90dG9tU2l4dHlTaXhQZXJjZW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1WYWxpZGF0b3JzOiBhY3RpdmVWYWxpZGF0b3JzLmxlbmd0aCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWxWb3RpbmdQb3dlcjogYW5hbHl0aWNzRGF0YS52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrVGltZTogYmxvY2tEYXRhLnRpbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNyZWF0ZUF0OiBuZXcgRGF0ZSgpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2codnBEaXN0KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZQRGlzdHJpYnV0aW9ucy5pbnNlcnQodnBEaXN0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgICAgICBTWU5DSU5HID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcIlN0b3BwZWRcIjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgbGV0IGVuZEJsb2NrVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJUaGlzIGJsb2NrIHVzZWQ6IFwiKygoZW5kQmxvY2tUaW1lLXN0YXJ0QmxvY2tUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgU1lOQ0lORyA9IGZhbHNlO1xuICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0sIHskc2V0OntsYXN0QmxvY2tzU3luY2VkVGltZTpuZXcgRGF0ZSgpLCB0b3RhbFZhbGlkYXRvcnM6dG90YWxWYWxpZGF0b3JzfX0pO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHVudGlsO1xuICAgIH0sXG4gICAgJ2FkZExpbWl0JzogZnVuY3Rpb24obGltaXQpIHtcbiAgICAgICAgLy8gY29uc29sZS5sb2cobGltaXQrMTApXG4gICAgICAgIHJldHVybiAobGltaXQrMTApO1xuICAgIH0sXG4gICAgJ2hhc01vcmUnOiBmdW5jdGlvbihsaW1pdCkge1xuICAgICAgICBpZiAobGltaXQgPiBNZXRlb3IuY2FsbCgnZ2V0Q3VycmVudEhlaWdodCcpKSB7XG4gICAgICAgICAgICByZXR1cm4gKGZhbHNlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiAodHJ1ZSk7XG4gICAgICAgIH1cbiAgICB9XG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vYmxvY2tzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVHJhbnNhY3Rpb25zIH0gZnJvbSAnLi4vLi4vdHJhbnNhY3Rpb25zL3RyYW5zYWN0aW9ucy5qcyc7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ2Jsb2Nrcy5oZWlnaHQnLCBmdW5jdGlvbihsaW1pdCl7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKHt9LCB7bGltaXQ6IGxpbWl0LCBzb3J0OiB7aGVpZ2h0OiAtMX19KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQoYmxvY2spe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2FkZHJlc3M6YmxvY2sucHJvcG9zZXJBZGRyZXNzfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtsaW1pdDoxfVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ2Jsb2Nrcy5maW5kT25lJywgZnVuY3Rpb24oaGVpZ2h0KXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmQoe2hlaWdodDpoZWlnaHR9KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQoYmxvY2spe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7aGVpZ2h0OmJsb2NrLmhlaWdodH1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZChibG9jayl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWRkcmVzczpibG9jay5wcm9wb3NlckFkZHJlc3N9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2xpbWl0OjF9XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuXG5leHBvcnQgY29uc3QgQmxvY2tzY29uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2Jsb2NrcycpO1xuXG5CbG9ja3Njb24uaGVscGVycyh7XG4gICAgcHJvcG9zZXIoKXtcbiAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZE9uZSh7YWRkcmVzczp0aGlzLnByb3Bvc2VyQWRkcmVzc30pO1xuICAgIH1cbn0pO1xuXG4vLyBCbG9ja3Njb24uaGVscGVycyh7XG4vLyAgICAgc29ydGVkKGxpbWl0KSB7XG4vLyAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZCh7fSwge3NvcnQ6IHtoZWlnaHQ6LTF9LCBsaW1pdDogbGltaXR9KTtcbi8vICAgICB9XG4vLyB9KTtcblxuXG4vLyBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKSB7XG4vLyAgICAgTWV0ZW9yLmNhbGwoJ2Jsb2Nrc1VwZGF0ZScsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4vLyAgICAgICAgIGNvbnNvbGUubG9nKHJlc3VsdCk7XG4vLyAgICAgfSlcbi8vIH0sIDMwMDAwMDAwKTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5pbXBvcnQgeyBnZXRBZGRyZXNzIH0gZnJvbSAndGVuZGVybWludC9saWIvcHVia2V5LmpzJztcbmltcG9ydCB7IENoYWluLCBDaGFpblN0YXRlcyB9IGZyb20gJy4uL2NoYWluLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnLi4vLi4vdm90aW5nLXBvd2VyL2hpc3RvcnkuanMnO1xuXG5maW5kVm90aW5nUG93ZXIgPSAodmFsaWRhdG9yLCBnZW5WYWxpZGF0b3JzKSA9PiB7XG4gICAgZm9yIChsZXQgdiBpbiBnZW5WYWxpZGF0b3JzKXtcbiAgICAgICAgaWYgKHZhbGlkYXRvci5wdWJfa2V5LnZhbHVlID09IGdlblZhbGlkYXRvcnNbdl0ucHViX2tleS52YWx1ZSl7XG4gICAgICAgICAgICByZXR1cm4gcGFyc2VJbnQoZ2VuVmFsaWRhdG9yc1t2XS5wb3dlcik7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnY2hhaW4uZ2V0Q29uc2Vuc3VzU3RhdGUnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHVybCA9IFJQQysnL2R1bXBfY29uc2Vuc3VzX3N0YXRlJztcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGxldCBjb25zZW5zdXMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgY29uc2Vuc3VzID0gY29uc2Vuc3VzLnJlc3VsdDtcbiAgICAgICAgICAgIGxldCBoZWlnaHQgPSBjb25zZW5zdXMucm91bmRfc3RhdGUuaGVpZ2h0O1xuICAgICAgICAgICAgbGV0IHJvdW5kID0gY29uc2Vuc3VzLnJvdW5kX3N0YXRlLnJvdW5kO1xuICAgICAgICAgICAgbGV0IHN0ZXAgPSBjb25zZW5zdXMucm91bmRfc3RhdGUuc3RlcDtcbiAgICAgICAgICAgIGxldCB2b3RlZFBvd2VyID0gTWF0aC5yb3VuZChwYXJzZUZsb2F0KGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS52b3Rlc1tyb3VuZF0ucHJldm90ZXNfYml0X2FycmF5LnNwbGl0KFwiIFwiKVszXSkqMTAwKTtcblxuICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0sIHskc2V0OntcbiAgICAgICAgICAgICAgICB2b3RpbmdIZWlnaHQ6IGhlaWdodCxcbiAgICAgICAgICAgICAgICB2b3RpbmdSb3VuZDogcm91bmQsXG4gICAgICAgICAgICAgICAgdm90aW5nU3RlcDogc3RlcCxcbiAgICAgICAgICAgICAgICB2b3RlZFBvd2VyOiB2b3RlZFBvd2VyLFxuICAgICAgICAgICAgICAgIHByb3Bvc2VyQWRkcmVzczogY29uc2Vuc3VzLnJvdW5kX3N0YXRlLnZhbGlkYXRvcnMucHJvcG9zZXIuYWRkcmVzcyxcbiAgICAgICAgICAgICAgICBwcmV2b3RlczogY29uc2Vuc3VzLnJvdW5kX3N0YXRlLnZvdGVzW3JvdW5kXS5wcmV2b3RlcyxcbiAgICAgICAgICAgICAgICBwcmVjb21taXRzOiBjb25zZW5zdXMucm91bmRfc3RhdGUudm90ZXNbcm91bmRdLnByZWNvbW1pdHNcbiAgICAgICAgICAgIH19KTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAnY2hhaW4udXBkYXRlU3RhdHVzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB1cmwgPSBSUEMrJy9zdGF0dXMnO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgbGV0IHN0YXR1cyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICBzdGF0dXMgPSBzdGF0dXMucmVzdWx0O1xuICAgICAgICAgICAgbGV0IGNoYWluID0ge307XG4gICAgICAgICAgICBjaGFpbi5jaGFpbklkID0gc3RhdHVzLm5vZGVfaW5mby5uZXR3b3JrO1xuICAgICAgICAgICAgY2hhaW4ubGF0ZXN0QmxvY2tIZWlnaHQgPSBzdGF0dXMuc3luY19pbmZvLmxhdGVzdF9ibG9ja19oZWlnaHQ7XG4gICAgICAgICAgICBjaGFpbi5sYXRlc3RCbG9ja1RpbWUgPSBzdGF0dXMuc3luY19pbmZvLmxhdGVzdF9ibG9ja190aW1lO1xuXG4gICAgICAgICAgICBsZXQgbGF0ZXN0U3RhdGUgPSBDaGFpblN0YXRlcy5maW5kT25lKHt9LCB7c29ydDoge2hlaWdodDogLTF9fSlcbiAgICAgICAgICAgIGlmIChsYXRlc3RTdGF0ZSAmJiBsYXRlc3RTdGF0ZS5oZWlnaHQgPj0gY2hhaW4ubGF0ZXN0QmxvY2tIZWlnaHQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYG5vIHVwZGF0ZXMgKGdldHRpbmcgYmxvY2sgJHtjaGFpbi5sYXRlc3RCbG9ja0hlaWdodH0gYXQgYmxvY2sgJHtsYXRlc3RTdGF0ZS5oZWlnaHR9KWBcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdXJsID0gUlBDKycvdmFsaWRhdG9ycyc7XG4gICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBsZXQgdmFsaWRhdG9ycyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICB2YWxpZGF0b3JzID0gdmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9ycztcbiAgICAgICAgICAgIGNoYWluLnZhbGlkYXRvcnMgPSB2YWxpZGF0b3JzLmxlbmd0aDtcbiAgICAgICAgICAgIGxldCBhY3RpdmVWUCA9IDA7XG4gICAgICAgICAgICBmb3IgKHYgaW4gdmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgYWN0aXZlVlAgKz0gcGFyc2VJbnQodmFsaWRhdG9yc1t2XS52b3RpbmdfcG93ZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2hhaW4uYWN0aXZlVm90aW5nUG93ZXIgPSBhY3RpdmVWUDtcblxuXG4gICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6Y2hhaW4uY2hhaW5JZH0sIHskc2V0OmNoYWlufSwge3Vwc2VydDogdHJ1ZX0pO1xuICAgICAgICAgICAgLy8gR2V0IGNoYWluIHN0YXRlc1xuICAgICAgICAgICAgaWYgKHBhcnNlSW50KGNoYWluLmxhdGVzdEJsb2NrSGVpZ2h0KSA+IDApe1xuICAgICAgICAgICAgICAgIGxldCBjaGFpblN0YXRlcyA9IHt9O1xuICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLmhlaWdodCA9IHBhcnNlSW50KHN0YXR1cy5zeW5jX2luZm8ubGF0ZXN0X2Jsb2NrX2hlaWdodCk7XG4gICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMudGltZSA9IG5ldyBEYXRlKHN0YXR1cy5zeW5jX2luZm8ubGF0ZXN0X2Jsb2NrX3RpbWUpO1xuXG4gICAgICAgICAgICAgICAgdXJsID0gTENEICsgJy9zdGFraW5nL3Bvb2wnO1xuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgYm9uZGluZyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAvLyBjaGFpbi5ib25kZWRUb2tlbnMgPSBib25kaW5nLmJvbmRlZF90b2tlbnM7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNoYWluLm5vdEJvbmRlZFRva2VucyA9IGJvbmRpbmcubm90X2JvbmRlZF90b2tlbnM7XG4gICAgICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLmJvbmRlZFRva2VucyA9IHBhcnNlSW50KGJvbmRpbmcuYm9uZGVkX3Rva2Vucyk7XG4gICAgICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLm5vdEJvbmRlZFRva2VucyA9IHBhcnNlSW50KGJvbmRpbmcubm90X2JvbmRlZF90b2tlbnMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdXJsID0gTENEICsgJy9zdXBwbHkvdG90YWwvJytNZXRlb3Iuc2V0dGluZ3MucHVibGljLm1pbnRpbmdEZW5vbTtcbiAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHN1cHBseSA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy50b3RhbFN1cHBseSA9IHBhcnNlSW50KHN1cHBseSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB1cmwgPSBMQ0QgKyAnL2Rpc3RyaWJ1dGlvbi9jb21tdW5pdHlfcG9vbCc7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgcG9vbCA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICBpZiAocG9vbCAmJiBwb29sLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMuY29tbXVuaXR5UG9vbCA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9vbC5mb3JFYWNoKChhbW91bnQsIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5jb21tdW5pdHlQb29sLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZW5vbTogYW1vdW50LmRlbm9tLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IHBhcnNlRmxvYXQoYW1vdW50LmFtb3VudClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdXJsID0gTENEICsgJy9taW50aW5nL2luZmxhdGlvbic7XG4gICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBpbmZsYXRpb24gPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGluZmxhdGlvbil7XG4gICAgICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5pbmZsYXRpb24gPSBwYXJzZUZsb2F0KGluZmxhdGlvbilcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdXJsID0gTENEICsgJy9taW50aW5nL2FubnVhbC1wcm92aXNpb25zJztcbiAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHByb3Zpc2lvbnMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgICAgICBpZiAocHJvdmlzaW9ucyl7XG4gICAgICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5hbm51YWxQcm92aXNpb25zID0gcGFyc2VGbG9hdChwcm92aXNpb25zLnJlc3VsdClcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgQ2hhaW5TdGF0ZXMuaW5zZXJ0KGNoYWluU3RhdGVzKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gY2hhaW4udG90YWxWb3RpbmdQb3dlciA9IHRvdGFsVlA7XG5cbiAgICAgICAgICAgIC8vIHZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe30pLmZldGNoKCk7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyh2YWxpZGF0b3JzKTtcbiAgICAgICAgICAgIHJldHVybiBjaGFpbi5sYXRlc3RCbG9ja0hlaWdodDtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgIHJldHVybiBcIkVycm9yIGdldHRpbmcgY2hhaW4gc3RhdHVzLlwiO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAnY2hhaW4uZ2V0TGF0ZXN0U3RhdHVzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgQ2hhaW4uZmluZCgpLnNvcnQoe2NyZWF0ZWQ6LTF9KS5saW1pdCgxKTtcbiAgICB9LFxuICAgICdjaGFpbi5nZW5lc2lzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgbGV0IGNoYWluID0gQ2hhaW4uZmluZE9uZSh7Y2hhaW5JZDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSk7XG5cbiAgICAgICAgaWYgKGNoYWluICYmIGNoYWluLnJlYWRHZW5lc2lzKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdHZW5lc2lzIGZpbGUgaGFzIGJlZW4gcHJvY2Vzc2VkJyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoTWV0ZW9yLnNldHRpbmdzLmRlYnVnLnJlYWRHZW5lc2lzKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnPT09IFN0YXJ0IHByb2Nlc3NpbmcgZ2VuZXNpcyBmaWxlID09PScpO1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQoTWV0ZW9yLnNldHRpbmdzLmdlbmVzaXNGaWxlKTtcbiAgICAgICAgICAgIGxldCBnZW5lc2lzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgIGxldCBkaXN0ciA9IGdlbmVzaXMuYXBwX3N0YXRlLmRpc3RyIHx8IGdlbmVzaXMuYXBwX3N0YXRlLmRpc3RyaWJ1dGlvblxuICAgICAgICAgICAgbGV0IGNoYWluUGFyYW1zID0ge1xuICAgICAgICAgICAgICAgIGNoYWluSWQ6IGdlbmVzaXMuY2hhaW5faWQsXG4gICAgICAgICAgICAgICAgZ2VuZXNpc1RpbWU6IGdlbmVzaXMuZ2VuZXNpc190aW1lLFxuICAgICAgICAgICAgICAgIGNvbnNlbnN1c1BhcmFtczogZ2VuZXNpcy5jb25zZW5zdXNfcGFyYW1zLFxuICAgICAgICAgICAgICAgIGF1dGg6IGdlbmVzaXMuYXBwX3N0YXRlLmF1dGgsXG4gICAgICAgICAgICAgICAgYmFuazogZ2VuZXNpcy5hcHBfc3RhdGUuYmFuayxcbiAgICAgICAgICAgICAgICBzdGFraW5nOiB7XG4gICAgICAgICAgICAgICAgICAgIHBvb2w6IGdlbmVzaXMuYXBwX3N0YXRlLnN0YWtpbmcucG9vbCxcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1zOiBnZW5lc2lzLmFwcF9zdGF0ZS5zdGFraW5nLnBhcmFtc1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgbWludDogZ2VuZXNpcy5hcHBfc3RhdGUubWludCxcbiAgICAgICAgICAgICAgICBkaXN0cjoge1xuICAgICAgICAgICAgICAgICAgICBjb21tdW5pdHlUYXg6IGRpc3RyLmNvbW11bml0eV90YXgsXG4gICAgICAgICAgICAgICAgICAgIGJhc2VQcm9wb3NlclJld2FyZDogZGlzdHIuYmFzZV9wcm9wb3Nlcl9yZXdhcmQsXG4gICAgICAgICAgICAgICAgICAgIGJvbnVzUHJvcG9zZXJSZXdhcmQ6IGRpc3RyLmJvbnVzX3Byb3Bvc2VyX3Jld2FyZCxcbiAgICAgICAgICAgICAgICAgICAgd2l0aGRyYXdBZGRyRW5hYmxlZDogZGlzdHIud2l0aGRyYXdfYWRkcl9lbmFibGVkXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBnb3Y6IHtcbiAgICAgICAgICAgICAgICAgICAgc3RhcnRpbmdQcm9wb3NhbElkOiAwLFxuICAgICAgICAgICAgICAgICAgICBkZXBvc2l0UGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgICAgICAgdm90aW5nUGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgICAgICAgdGFsbHlQYXJhbXM6IHt9XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBzbGFzaGluZzp7XG4gICAgICAgICAgICAgICAgICAgIHBhcmFtczogZ2VuZXNpcy5hcHBfc3RhdGUuc2xhc2hpbmcucGFyYW1zXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBzdXBwbHk6IGdlbmVzaXMuYXBwX3N0YXRlLnN1cHBseSxcbiAgICAgICAgICAgICAgICBjcmlzaXM6IGdlbmVzaXMuYXBwX3N0YXRlLmNyaXNpc1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoZ2VuZXNpcy5hcHBfc3RhdGUuZ292KSB7XG4gICAgICAgICAgICAgICAgY2hhaW5QYXJhbXMuZ292ID0ge1xuICAgICAgICAgICAgICAgICAgICBzdGFydGluZ1Byb3Bvc2FsSWQ6IGdlbmVzaXMuYXBwX3N0YXRlLmdvdi5zdGFydGluZ19wcm9wb3NhbF9pZCxcbiAgICAgICAgICAgICAgICAgICAgZGVwb3NpdFBhcmFtczogZ2VuZXNpcy5hcHBfc3RhdGUuZ292LmRlcG9zaXRfcGFyYW1zLFxuICAgICAgICAgICAgICAgICAgICB2b3RpbmdQYXJhbXM6IGdlbmVzaXMuYXBwX3N0YXRlLmdvdi52b3RpbmdfcGFyYW1zLFxuICAgICAgICAgICAgICAgICAgICB0YWxseVBhcmFtczogZ2VuZXNpcy5hcHBfc3RhdGUuZ292LnRhbGx5X3BhcmFtc1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGxldCB0b3RhbFZvdGluZ1Bvd2VyID0gMDtcblxuICAgICAgICAgICAgLy8gcmVhZCBnZW50eFxuICAgICAgICAgICAgaWYgKGdlbmVzaXMuYXBwX3N0YXRlLmdlbnV0aWwgJiYgZ2VuZXNpcy5hcHBfc3RhdGUuZ2VudXRpbC5nZW50eHMgJiYgKGdlbmVzaXMuYXBwX3N0YXRlLmdlbnV0aWwuZ2VudHhzLmxlbmd0aCA+IDApKXtcbiAgICAgICAgICAgICAgICBmb3IgKGkgaW4gZ2VuZXNpcy5hcHBfc3RhdGUuZ2VudXRpbC5nZW50eHMpe1xuICAgICAgICAgICAgICAgICAgICBsZXQgbXNnID0gZ2VuZXNpcy5hcHBfc3RhdGUuZ2VudXRpbC5nZW50eHNbaV0udmFsdWUubXNnO1xuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhtc2cudHlwZSk7XG4gICAgICAgICAgICAgICAgICAgIGZvciAobSBpbiBtc2cpe1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1zZ1ttXS50eXBlID09IFwiY29zbW9zLXNkay9Nc2dDcmVhdGVWYWxpZGF0b3JcIil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cobXNnW21dLnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBsZXQgY29tbWFuZCA9IE1ldGVvci5zZXR0aW5ncy5iaW4uZ2FpYWRlYnVnK1wiIHB1YmtleSBcIittc2dbbV0udmFsdWUucHVia2V5O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3IgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNlbnN1c19wdWJrZXk6IG1zZ1ttXS52YWx1ZS5wdWJrZXksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBtc2dbbV0udmFsdWUuZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb246IG1zZ1ttXS52YWx1ZS5jb21taXNzaW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5fc2VsZl9kZWxlZ2F0aW9uOiBtc2dbbV0udmFsdWUubWluX3NlbGZfZGVsZWdhdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3BlcmF0b3JfYWRkcmVzczogbXNnW21dLnZhbHVlLnZhbGlkYXRvcl9hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxlZ2F0b3JfYWRkcmVzczogbXNnW21dLnZhbHVlLmRlbGVnYXRvcl9hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IE1hdGguZmxvb3IocGFyc2VJbnQobXNnW21dLnZhbHVlLnZhbHVlLmFtb3VudCkgLyBNZXRlb3Iuc2V0dGluZ3MucHVibGljLnN0YWtpbmdGcmFjdGlvbiksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGphaWxlZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogMlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsVm90aW5nUG93ZXIgKz0gdmFsaWRhdG9yLnZvdGluZ19wb3dlcjtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwdWJrZXlWYWx1ZSA9IE1ldGVvci5jYWxsKCdiZWNoMzJUb1B1YmtleScsIG1zZ1ttXS52YWx1ZS5wdWJrZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFZhbGlkYXRvcnMudXBzZXJ0KHtjb25zZW5zdXNfcHVia2V5Om1zZ1ttXS52YWx1ZS5wdWJrZXl9LHZhbGlkYXRvcik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHViX2tleSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6XCJ0ZW5kZXJtaW50L1B1YktleUVkMjU1MTlcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ2YWx1ZVwiOnB1YmtleVZhbHVlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFkZHJlc3MgPSBnZXRBZGRyZXNzKHZhbGlkYXRvci5wdWJfa2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYWNjcHViID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4QWNjUHViKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsUHViKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBWb3RpbmdQb3dlckhpc3RvcnkuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogdmFsaWRhdG9yLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZXZfdm90aW5nX3Bvd2VyOiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IHZhbGlkYXRvci52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdhZGQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrX3RpbWU6IGdlbmVzaXMuZ2VuZXNpc190aW1lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBWYWxpZGF0b3JzLmluc2VydCh2YWxpZGF0b3IpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyByZWFkIHZhbGlkYXRvcnMgZnJvbSBwcmV2aW91cyBjaGFpblxuICAgICAgICAgICAgY29uc29sZS5sb2coJ3JlYWQgdmFsaWRhdG9ycyBmcm9tIHByZXZpb3VzIGNoYWluJyk7XG4gICAgICAgICAgICBpZiAoZ2VuZXNpcy5hcHBfc3RhdGUuc3Rha2luZy52YWxpZGF0b3JzICYmIGdlbmVzaXMuYXBwX3N0YXRlLnN0YWtpbmcudmFsaWRhdG9ycy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhnZW5lc2lzLmFwcF9zdGF0ZS5zdGFraW5nLnZhbGlkYXRvcnMubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICBsZXQgZ2VuVmFsaWRhdG9yc1NldCA9IGdlbmVzaXMuYXBwX3N0YXRlLnN0YWtpbmcudmFsaWRhdG9ycztcbiAgICAgICAgICAgICAgICBsZXQgZ2VuVmFsaWRhdG9ycyA9IGdlbmVzaXMudmFsaWRhdG9ycztcbiAgICAgICAgICAgICAgICBmb3IgKGxldCB2IGluIGdlblZhbGlkYXRvcnNTZXQpe1xuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhnZW5WYWxpZGF0b3JzW3ZdKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvciA9IGdlblZhbGlkYXRvcnNTZXRbdl07XG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZWxlZ2F0b3JfYWRkcmVzcyA9IE1ldGVvci5jYWxsKCdnZXREZWxlZ2F0b3InLCBnZW5WYWxpZGF0b3JzU2V0W3ZdLm9wZXJhdG9yX2FkZHJlc3MpO1xuXG4gICAgICAgICAgICAgICAgICAgIGxldCBwdWJrZXlWYWx1ZSA9IE1ldGVvci5jYWxsKCdiZWNoMzJUb1B1YmtleScsIHZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5KTtcblxuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHViX2tleSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIFwidHlwZVwiOlwidGVuZGVybWludC9QdWJLZXlFZDI1NTE5XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBcInZhbHVlXCI6cHVia2V5VmFsdWVcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5hZGRyZXNzID0gZ2V0QWRkcmVzcyh2YWxpZGF0b3IucHViX2tleSk7XG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5wdWJfa2V5ID0gdmFsaWRhdG9yLnB1Yl9rZXk7XG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5hY2NwdWIgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3IucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhBY2NQdWIpO1xuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsUHViKTtcblxuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyID0gZmluZFZvdGluZ1Bvd2VyKHZhbGlkYXRvciwgZ2VuVmFsaWRhdG9ycyk7XG4gICAgICAgICAgICAgICAgICAgIHRvdGFsVm90aW5nUG93ZXIgKz0gdmFsaWRhdG9yLnZvdGluZ19wb3dlcjtcblxuICAgICAgICAgICAgICAgICAgICBWYWxpZGF0b3JzLnVwc2VydCh7Y29uc2Vuc3VzX3B1YmtleTp2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleX0sdmFsaWRhdG9yKTtcbiAgICAgICAgICAgICAgICAgICAgVm90aW5nUG93ZXJIaXN0b3J5Lmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOiB2YWxpZGF0b3IuYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByZXZfdm90aW5nX3Bvd2VyOiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2FkZCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja190aW1lOiBnZW5lc2lzLmdlbmVzaXNfdGltZVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNoYWluUGFyYW1zLnJlYWRHZW5lc2lzID0gdHJ1ZTtcbiAgICAgICAgICAgIGNoYWluUGFyYW1zLmFjdGl2ZVZvdGluZ1Bvd2VyID0gdG90YWxWb3RpbmdQb3dlcjtcbiAgICAgICAgICAgIGxldCByZXN1bHQgPSBDaGFpbi51cHNlcnQoe2NoYWluSWQ6Y2hhaW5QYXJhbXMuY2hhaW5JZH0sIHskc2V0OmNoYWluUGFyYW1zfSk7XG5cblxuICAgICAgICAgICAgY29uc29sZS5sb2coJz09PSBGaW5pc2hlZCBwcm9jZXNzaW5nIGdlbmVzaXMgZmlsZSA9PT0nKTtcblxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQ2hhaW4sIENoYWluU3RhdGVzIH0gZnJvbSAnLi4vY2hhaW4uanMnO1xuaW1wb3J0IHsgQ29pblN0YXRzIH0gZnJvbSAnLi4vLi4vY29pbi1zdGF0cy9jb2luLXN0YXRzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuXG5NZXRlb3IucHVibGlzaCgnY2hhaW5TdGF0ZXMubGF0ZXN0JywgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBbXG4gICAgICAgIENoYWluU3RhdGVzLmZpbmQoe30se3NvcnQ6e2hlaWdodDotMX0sbGltaXQ6MX0pLFxuICAgICAgICBDb2luU3RhdHMuZmluZCh7fSx7c29ydDp7bGFzdF91cGRhdGVkX2F0Oi0xfSxsaW1pdDoxfSlcbiAgICBdO1xufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ2NoYWluLnN0YXR1cycsIGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIENoYWluLmZpbmQoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSk7XG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZChjaGFpbil7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6MSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjoxLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wZXJhdG9yX2FkZHJlc3M6MSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6LTEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgamFpbGVkOjEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvZmlsZV91cmw6MVxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pOyIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuXG5leHBvcnQgY29uc3QgQ2hhaW4gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY2hhaW4nKTtcbmV4cG9ydCBjb25zdCBDaGFpblN0YXRlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjaGFpbl9zdGF0ZXMnKVxuXG5DaGFpbi5oZWxwZXJzKHtcbiAgICBwcm9wb3Nlcigpe1xuICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kT25lKHthZGRyZXNzOnRoaXMucHJvcG9zZXJBZGRyZXNzfSk7XG4gICAgfVxufSkiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IENvaW5TdGF0cyB9IGZyb20gJy4uL2NvaW4tc3RhdHMuanMnO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdjb2luU3RhdHMuZ2V0Q29pblN0YXRzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCBjb2luSWQgPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNvaW5nZWNrb0lkO1xuICAgICAgICBpZiAoY29pbklkKXtcbiAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICBsZXQgbm93ID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICBub3cuc2V0TWludXRlcygwKTtcbiAgICAgICAgICAgICAgICBsZXQgdXJsID0gXCJodHRwczovL2FwaS5jb2luZ2Vja28uY29tL2FwaS92My9zaW1wbGUvcHJpY2U/aWRzPVwiK2NvaW5JZCtcIiZ2c19jdXJyZW5jaWVzPXVzZCZpbmNsdWRlX21hcmtldF9jYXA9dHJ1ZSZpbmNsdWRlXzI0aHJfdm9sPXRydWUmaW5jbHVkZV8yNGhyX2NoYW5nZT10cnVlJmluY2x1ZGVfbGFzdF91cGRhdGVkX2F0PXRydWVcIjtcbiAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgZGF0YSA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICAgICAgICAgIGRhdGEgPSBkYXRhW2NvaW5JZF07XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGNvaW5TdGF0cyk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBDb2luU3RhdHMudXBzZXJ0KHtsYXN0X3VwZGF0ZWRfYXQ6ZGF0YS5sYXN0X3VwZGF0ZWRfYXR9LCB7JHNldDpkYXRhfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIHJldHVybiBcIk5vIGNvaW5nZWNrbyBJZCBwcm92aWRlZC5cIlxuICAgICAgICB9XG4gICAgfSxcbiAgICAnY29pblN0YXRzLmdldFN0YXRzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCBjb2luSWQgPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNvaW5nZWNrb0lkO1xuICAgICAgICBpZiAoY29pbklkKXtcbiAgICAgICAgICAgIHJldHVybiAoQ29pblN0YXRzLmZpbmRPbmUoe30se3NvcnQ6e2xhc3RfdXBkYXRlZF9hdDotMX19KSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIHJldHVybiBcIk5vIGNvaW5nZWNrbyBJZCBwcm92aWRlZC5cIjtcbiAgICAgICAgfVxuXG4gICAgfVxufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBDb2luU3RhdHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY29pbl9zdGF0cycpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBEZWxlZ2F0aW9ucyB9IGZyb20gJy4uL2RlbGVnYXRpb25zLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ2RlbGVnYXRpb25zLmdldERlbGVnYXRpb25zJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB2YWxpZGF0b3JzID0gVmFsaWRhdG9ycy5maW5kKHt9KS5mZXRjaCgpO1xuICAgICAgICBsZXQgZGVsZWdhdGlvbnMgPSBbXTtcbiAgICAgICAgY29uc29sZS5sb2coXCI9PT0gR2V0dGluZyBkZWxlZ2F0aW9ucyA9PT1cIik7XG4gICAgICAgIGZvciAodiBpbiB2YWxpZGF0b3JzKXtcbiAgICAgICAgICAgIGlmICh2YWxpZGF0b3JzW3ZdLm9wZXJhdG9yX2FkZHJlc3Mpe1xuICAgICAgICAgICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL3N0YWtpbmcvdmFsaWRhdG9ycy8nK3ZhbGlkYXRvcnNbdl0ub3BlcmF0b3JfYWRkcmVzcytcIi9kZWxlZ2F0aW9uc1wiO1xuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBkZWxlZ2F0aW9uID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhkZWxlZ2F0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zID0gZGVsZWdhdGlvbnMuY29uY2F0KGRlbGVnYXRpb24pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZS5zdGF0dXNDb2RlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgIH0gICAgXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBmb3IgKGkgaW4gZGVsZWdhdGlvbnMpe1xuICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zW2ldICYmIGRlbGVnYXRpb25zW2ldLnNoYXJlcylcbiAgICAgICAgICAgICAgICBkZWxlZ2F0aW9uc1tpXS5zaGFyZXMgPSBwYXJzZUZsb2F0KGRlbGVnYXRpb25zW2ldLnNoYXJlcyk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBjb25zb2xlLmxvZyhkZWxlZ2F0aW9ucyk7XG4gICAgICAgIGxldCBkYXRhID0ge1xuICAgICAgICAgICAgZGVsZWdhdGlvbnM6IGRlbGVnYXRpb25zLFxuICAgICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIERlbGVnYXRpb25zLmluc2VydChkYXRhKTtcbiAgICB9XG4gICAgLy8gJ2Jsb2Nrcy5hdmVyYWdlQmxvY2tUaW1lJyhhZGRyZXNzKXtcbiAgICAvLyAgICAgbGV0IGJsb2NrcyA9IEJsb2Nrc2Nvbi5maW5kKHtwcm9wb3NlckFkZHJlc3M6YWRkcmVzc30pLmZldGNoKCk7XG4gICAgLy8gICAgIGxldCBoZWlnaHRzID0gYmxvY2tzLm1hcCgoYmxvY2ssIGkpID0+IHtcbiAgICAvLyAgICAgICAgIHJldHVybiBibG9jay5oZWlnaHQ7XG4gICAgLy8gICAgIH0pO1xuICAgIC8vICAgICBsZXQgYmxvY2tzU3RhdHMgPSBBbmFseXRpY3MuZmluZCh7aGVpZ2h0OnskaW46aGVpZ2h0c319KS5mZXRjaCgpO1xuICAgIC8vICAgICAvLyBjb25zb2xlLmxvZyhibG9ja3NTdGF0cyk7XG5cbiAgICAvLyAgICAgbGV0IHRvdGFsQmxvY2tEaWZmID0gMDtcbiAgICAvLyAgICAgZm9yIChiIGluIGJsb2Nrc1N0YXRzKXtcbiAgICAvLyAgICAgICAgIHRvdGFsQmxvY2tEaWZmICs9IGJsb2Nrc1N0YXRzW2JdLnRpbWVEaWZmO1xuICAgIC8vICAgICB9XG4gICAgLy8gICAgIHJldHVybiB0b3RhbEJsb2NrRGlmZi9oZWlnaHRzLmxlbmd0aDtcbiAgICAvLyB9XG59KSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IERlbGVnYXRpb25zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2RlbGVnYXRpb25zJyk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5pbXBvcnQgeyBFbnRlcnByaXNlIH0gZnJvbSAnLi4vZW50ZXJwcmlzZS5qcyc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnZW50ZXJwcmlzZS5nZXRQdXJjaGFzZU9yZGVycyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgdXJsID0gTENEICsgJy9lbnRlcnByaXNlL3Bvcyc7XG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgbGV0IHB1cmNoYXNlT3JkZXJzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG5cbiAgICAgICAgICAgIGxldCBmaW5pc2hlZFB1cmNoYXNlT3JkZXJzID0gbmV3IFNldChFbnRlcnByaXNlLmZpbmQoXG4gICAgICAgICAgICAgICAge1wic3RhdHVzXCI6eyRpbjpbXCJyZWplY3RcIiwgXCJjb21wbGV0ZVwiXX19XG4gICAgICAgICAgICApLmZldGNoKCkubWFwKChwKT0+IHAucG9JZCkpO1xuXG4gICAgICAgICAgICBsZXQgcG9JZHMgPSBbXTtcblxuICAgICAgICAgICAgaWYgKHB1cmNoYXNlT3JkZXJzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICBjb25zdCBidWxrUG9zID0gRW50ZXJwcmlzZS5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgaW4gcHVyY2hhc2VPcmRlcnMpIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHBvID0gcHVyY2hhc2VPcmRlcnNbaV1cbiAgICAgICAgICAgICAgICAgICAgcG8ucG9JZCA9IHBhcnNlSW50KHBvLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBvLnBvSWQgPiAwICYmICFmaW5pc2hlZFB1cmNoYXNlT3JkZXJzLmhhcyhwby5wb0lkKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrUG9zLmZpbmQoe3BvSWQ6IHBvLnBvSWR9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6IHBvfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9JZHMucHVzaChwby5wb0lkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2goZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtQb3MuZmluZCh7cG9JZDogcG8ucG9JZH0pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDogcG99KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwb0lkcy5wdXNoKHBvLnBvSWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUucmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYocG9JZHMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICBidWxrUG9zLmV4ZWN1dGUoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG4gICAgfVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgRW50ZXJwcmlzZSB9IGZyb20gJy4uL2VudGVycHJpc2UuanMnO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snXG5cbk1ldGVvci5wdWJsaXNoKCdlbnRlcnByaXNlLmxpc3RfcG9zJywgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBFbnRlcnByaXNlLmZpbmQoe30sIHtzb3J0Ontwb0lkOi0xfX0pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKCdlbnRlcnByaXNlLm9uZV9wbycsIGZ1bmN0aW9uIChpZCl7XG4gICAgY2hlY2soaWQsIE51bWJlcik7XG4gICAgcmV0dXJuIEVudGVycHJpc2UuZmluZCh7cG9JZDppZH0pO1xufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBFbnRlcnByaXNlID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2VudGVycHJpc2UnKTtcbiIsImltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAndHJhbnNhY3Rpb24uc3VibWl0JzogZnVuY3Rpb24odHhJbmZvKSB7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke0xDRH0vdHhzYDtcbiAgICAgICAgZGF0YSA9IHtcbiAgICAgICAgICAgIFwidHhcIjogdHhJbmZvLnZhbHVlLFxuICAgICAgICAgICAgXCJtb2RlXCI6IFwic3luY1wiXG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdGltZXN0YW1wID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBzdWJtaXR0aW5nIHRyYW5zYWN0aW9uJHt0aW1lc3RhbXB9ICR7dXJsfSB3aXRoIGRhdGEgJHtKU09OLnN0cmluZ2lmeShkYXRhKX1gKVxuXG4gICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAucG9zdCh1cmwsIHtkYXRhfSk7XG4gICAgICAgIGNvbnNvbGUubG9nKGByZXNwb25zZSBmb3IgdHJhbnNhY3Rpb24ke3RpbWVzdGFtcH0gJHt1cmx9OiAke0pTT04uc3RyaW5naWZ5KHJlc3BvbnNlKX1gKVxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApIHtcbiAgICAgICAgICAgIGxldCBkYXRhID0gcmVzcG9uc2UuZGF0YVxuICAgICAgICAgICAgaWYgKGRhdGEuY29kZSlcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKGRhdGEuY29kZSwgSlNPTi5wYXJzZShkYXRhLnJhd19sb2cpLm1lc3NhZ2UpXG4gICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YS50eGhhc2g7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICd0cmFuc2FjdGlvbi5leGVjdXRlJzogZnVuY3Rpb24oYm9keSwgcGF0aCkge1xuICAgICAgICBjb25zdCB1cmwgPSBgJHtMQ0R9LyR7cGF0aH1gO1xuICAgICAgICBkYXRhID0ge1xuICAgICAgICAgICAgXCJiYXNlX3JlcVwiOiB7XG4gICAgICAgICAgICAgICAgLi4uYm9keSxcbiAgICAgICAgICAgICAgICBcImNoYWluX2lkXCI6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZCxcbiAgICAgICAgICAgICAgICBcInNpbXVsYXRlXCI6IGZhbHNlXG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAucG9zdCh1cmwsIHtkYXRhfSk7XG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCkge1xuICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICd0cmFuc2FjdGlvbi5zaW11bGF0ZSc6IGZ1bmN0aW9uKHR4TXNnLCBmcm9tLCBwYXRoLCBhZGp1c3RtZW50PScxLjInKSB7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke0xDRH0vJHtwYXRofWA7XG4gICAgICAgIGRhdGEgPSB7Li4udHhNc2csXG4gICAgICAgICAgICBcImJhc2VfcmVxXCI6IHtcbiAgICAgICAgICAgICAgICBcImZyb21cIjogZnJvbSxcbiAgICAgICAgICAgICAgICBcImNoYWluX2lkXCI6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZCxcbiAgICAgICAgICAgICAgICBcImdhc19hZGp1c3RtZW50XCI6IGFkanVzdG1lbnQsXG4gICAgICAgICAgICAgICAgXCJzaW11bGF0ZVwiOiB0cnVlXG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAucG9zdCh1cmwsIHtkYXRhfSk7XG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCkge1xuICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkuZ2FzX2VzdGltYXRlO1xuICAgICAgICB9XG4gICAgfSxcbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuaW1wb3J0IHsgUHJvcG9zYWxzIH0gZnJvbSAnLi4vcHJvcG9zYWxzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuLy8gaW1wb3J0IHsgUHJvbWlzZSB9IGZyb20gJ21ldGVvci9wcm9taXNlJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdwcm9wb3NhbHMuZ2V0UHJvcG9zYWxzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL2dvdi9wcm9wb3NhbHMnO1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGxldCBwcm9wb3NhbHMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHByb3Bvc2Fscyk7XG5cbiAgICAgICAgICAgIGxldCBmaW5pc2hlZFByb3Bvc2FsSWRzID0gbmV3IFNldChQcm9wb3NhbHMuZmluZChcbiAgICAgICAgICAgICAgICB7XCJwcm9wb3NhbF9zdGF0dXNcIjp7JGluOltcIlBhc3NlZFwiLCBcIlJlamVjdGVkXCIsIFwiUmVtb3ZlZFwiXX19XG4gICAgICAgICAgICApLmZldGNoKCkubWFwKChwKT0+IHAucHJvcG9zYWxJZCkpO1xuXG4gICAgICAgICAgICBsZXQgcHJvcG9zYWxJZHMgPSBbXTtcbiAgICAgICAgICAgIGlmIChwcm9wb3NhbHMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgLy8gUHJvcG9zYWxzLnVwc2VydCgpXG4gICAgICAgICAgICAgICAgY29uc3QgYnVsa1Byb3Bvc2FscyA9IFByb3Bvc2Fscy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgaW4gcHJvcG9zYWxzKXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHByb3Bvc2FsID0gcHJvcG9zYWxzW2ldO1xuICAgICAgICAgICAgICAgICAgICBwcm9wb3NhbC5wcm9wb3NhbElkID0gcGFyc2VJbnQocHJvcG9zYWwuaWQpO1xuICAgICAgICAgICAgICAgICAgICBpZiAocHJvcG9zYWwucHJvcG9zYWxJZCA+IDAgJiYgIWZpbmlzaGVkUHJvcG9zYWxJZHMuaGFzKHByb3Bvc2FsLnByb3Bvc2FsSWQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHVybCA9IExDRCArICcvZ292L3Byb3Bvc2Fscy8nK3Byb3Bvc2FsLnByb3Bvc2FsSWQrJy9wcm9wb3Nlcic7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJvcG9zZXIgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByb3Bvc2VyLnByb3Bvc2FsX2lkICYmIChwcm9wb3Nlci5wcm9wb3NhbF9pZCA9PSBwcm9wb3NhbC5pZCkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zYWwucHJvcG9zZXIgPSBwcm9wb3Nlci5wcm9wb3NlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrUHJvcG9zYWxzLmZpbmQoe3Byb3Bvc2FsSWQ6IHByb3Bvc2FsLnByb3Bvc2FsSWR9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6cHJvcG9zYWx9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wb3NhbElkcy5wdXNoKHByb3Bvc2FsLnByb3Bvc2FsSWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1Byb3Bvc2Fscy5maW5kKHtwcm9wb3NhbElkOiBwcm9wb3NhbC5wcm9wb3NhbElkfSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OnByb3Bvc2FsfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zYWxJZHMucHVzaChwcm9wb3NhbC5wcm9wb3NhbElkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlLnJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJ1bGtQcm9wb3NhbHMuZmluZCh7cHJvcG9zYWxJZDp7JG5pbjpwcm9wb3NhbElkc30sIHByb3Bvc2FsX3N0YXR1czp7JG5pbjpbXCJQYXNzZWRcIiwgXCJSZWplY3RlZFwiLCBcIlJlbW92ZWRcIl19fSlcbiAgICAgICAgICAgICAgICAgICAgLnVwZGF0ZSh7JHNldDoge1wicHJvcG9zYWxfc3RhdHVzXCI6IFwiUmVtb3ZlZFwifX0pO1xuICAgICAgICAgICAgICAgIGJ1bGtQcm9wb3NhbHMuZXhlY3V0ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ3Byb3Bvc2Fscy5nZXRQcm9wb3NhbFJlc3VsdHMnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHByb3Bvc2FscyA9IFByb3Bvc2Fscy5maW5kKHtcInByb3Bvc2FsX3N0YXR1c1wiOnskbmluOltcIlBhc3NlZFwiLCBcIlJlamVjdGVkXCIsIFwiUmVtb3ZlZFwiXX19KS5mZXRjaCgpO1xuXG4gICAgICAgIGlmIChwcm9wb3NhbHMgJiYgKHByb3Bvc2Fscy5sZW5ndGggPiAwKSl7XG4gICAgICAgICAgICBmb3IgKGxldCBpIGluIHByb3Bvc2Fscyl7XG4gICAgICAgICAgICAgICAgaWYgKHBhcnNlSW50KHByb3Bvc2Fsc1tpXS5wcm9wb3NhbElkKSA+IDApe1xuICAgICAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBnZXQgcHJvcG9zYWwgZGVwb3NpdHNcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL2dvdi9wcm9wb3NhbHMvJytwcm9wb3NhbHNbaV0ucHJvcG9zYWxJZCsnL2RlcG9zaXRzJztcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJvcG9zYWwgPSB7cHJvcG9zYWxJZDogcHJvcG9zYWxzW2ldLnByb3Bvc2FsSWR9O1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgZGVwb3NpdHMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wb3NhbC5kZXBvc2l0cyA9IGRlcG9zaXRzO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmwgPSBMQ0QgKyAnL2dvdi9wcm9wb3NhbHMvJytwcm9wb3NhbHNbaV0ucHJvcG9zYWxJZCsnL3ZvdGVzJztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZvdGVzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zYWwudm90ZXMgPSBnZXRWb3RlRGV0YWlsKHZvdGVzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsID0gTENEICsgJy9nb3YvcHJvcG9zYWxzLycrcHJvcG9zYWxzW2ldLnByb3Bvc2FsSWQrJy90YWxseSc7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB0YWxseSA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2FsLnRhbGx5ID0gdGFsbHk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2FsLnVwZGF0ZWRBdCA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBQcm9wb3NhbHMudXBkYXRlKHtwcm9wb3NhbElkOiBwcm9wb3NhbHNbaV0ucHJvcG9zYWxJZH0sIHskc2V0OnByb3Bvc2FsfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY2F0Y2goZSl7XG5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cbn0pXG5cbmNvbnN0IGdldFZvdGVEZXRhaWwgPSAodm90ZXMpID0+IHtcbiAgICBpZiAoIXZvdGVzKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG5cbiAgICBsZXQgdm90ZXJzID0gdm90ZXMubWFwKCh2b3RlKSA9PiB2b3RlLnZvdGVyKTtcbiAgICBsZXQgdm90aW5nUG93ZXJNYXAgPSB7fTtcbiAgICBsZXQgdmFsaWRhdG9yQWRkcmVzc01hcCA9IHt9O1xuICAgIFZhbGlkYXRvcnMuZmluZCh7ZGVsZWdhdG9yX2FkZHJlc3M6IHskaW46IHZvdGVyc319KS5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHtcbiAgICAgICAgdm90aW5nUG93ZXJNYXBbdmFsaWRhdG9yLmRlbGVnYXRvcl9hZGRyZXNzXSA9IHtcbiAgICAgICAgICAgIG1vbmlrZXI6IHZhbGlkYXRvci5kZXNjcmlwdGlvbi5tb25pa2VyLFxuICAgICAgICAgICAgYWRkcmVzczogdmFsaWRhdG9yLmFkZHJlc3MsXG4gICAgICAgICAgICB0b2tlbnM6IHBhcnNlRmxvYXQodmFsaWRhdG9yLnRva2VucyksXG4gICAgICAgICAgICBkZWxlZ2F0b3JTaGFyZXM6IHBhcnNlRmxvYXQodmFsaWRhdG9yLmRlbGVnYXRvcl9zaGFyZXMpLFxuICAgICAgICAgICAgZGVkdWN0ZWRTaGFyZXM6IHBhcnNlRmxvYXQodmFsaWRhdG9yLmRlbGVnYXRvcl9zaGFyZXMpXG4gICAgICAgIH1cbiAgICAgICAgdmFsaWRhdG9yQWRkcmVzc01hcFt2YWxpZGF0b3Iub3BlcmF0b3JfYWRkcmVzc10gPSB2YWxpZGF0b3IuZGVsZWdhdG9yX2FkZHJlc3M7XG4gICAgfSk7XG4gICAgdm90ZXJzLmZvckVhY2goKHZvdGVyKSA9PiB7XG4gICAgICAgIGlmICghdm90aW5nUG93ZXJNYXBbdm90ZXJdKSB7XG4gICAgICAgICAgICAvLyB2b3RlciBpcyBub3QgYSB2YWxpZGF0b3JcbiAgICAgICAgICAgIGxldCB1cmwgPSBgJHtMQ0R9L3N0YWtpbmcvZGVsZWdhdG9ycy8ke3ZvdGVyfS9kZWxlZ2F0aW9uc2A7XG4gICAgICAgICAgICBsZXQgZGVsZWdhdGlvbnM7XG4gICAgICAgICAgICBsZXQgdm90aW5nUG93ZXIgPSAwO1xuICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgZGVsZWdhdGlvbnMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zICYmIGRlbGVnYXRpb25zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zLmZvckVhY2goKGRlbGVnYXRpb24pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgc2hhcmVzID0gcGFyc2VGbG9hdChkZWxlZ2F0aW9uLnNoYXJlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvckFkZHJlc3NNYXBbZGVsZWdhdGlvbi52YWxpZGF0b3JfYWRkcmVzc10pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGVkdWN0IGRlbGVnYXRlZCBzaGFyZWRzIGZyb20gdmFsaWRhdG9yIGlmIGEgZGVsZWdhdG9yIHZvdGVzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3IgPSB2b3RpbmdQb3dlck1hcFt2YWxpZGF0b3JBZGRyZXNzTWFwW2RlbGVnYXRpb24udmFsaWRhdG9yX2FkZHJlc3NdXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmRlZHVjdGVkU2hhcmVzIC09IHNoYXJlcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzICE9IDApeyAvLyBhdm9pZGluZyBkaXZpc2lvbiBieSB6ZXJvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdQb3dlciArPSAoc2hhcmVzL3ZhbGlkYXRvci5kZWxlZ2F0b3JTaGFyZXMpICogdmFsaWRhdG9yLnRva2VucztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvciA9IFZhbGlkYXRvcnMuZmluZE9uZSh7b3BlcmF0b3JfYWRkcmVzczogZGVsZWdhdGlvbi52YWxpZGF0b3JfYWRkcmVzc30pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yICYmIHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzICE9IDApeyAvLyBhdm9pZGluZyBkaXZpc2lvbiBieSB6ZXJvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdQb3dlciArPSAoc2hhcmVzL3BhcnNlRmxvYXQodmFsaWRhdG9yLmRlbGVnYXRvcl9zaGFyZXMpKSAqIHBhcnNlRmxvYXQodmFsaWRhdG9yLnRva2Vucyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHZvdGluZ1Bvd2VyTWFwW3ZvdGVyXSA9IHt2b3RpbmdQb3dlcjogdm90aW5nUG93ZXJ9O1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIHZvdGVzLm1hcCgodm90ZSkgPT4ge1xuICAgICAgICBsZXQgdm90ZXIgPSB2b3RpbmdQb3dlck1hcFt2b3RlLnZvdGVyXTtcbiAgICAgICAgbGV0IHZvdGluZ1Bvd2VyID0gdm90ZXIudm90aW5nUG93ZXI7XG4gICAgICAgIGlmICh2b3RpbmdQb3dlciA9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIC8vIHZvdGVyIGlzIGEgdmFsaWRhdG9yXG4gICAgICAgICAgICB2b3RpbmdQb3dlciA9IHZvdGVyLmRlbGVnYXRvclNoYXJlcz8oKHZvdGVyLmRlZHVjdGVkU2hhcmVzL3ZvdGVyLmRlbGVnYXRvclNoYXJlcykgKiB2b3Rlci50b2tlbnMpOjA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHsuLi52b3RlLCB2b3RpbmdQb3dlcn07XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFByb3Bvc2FscyB9IGZyb20gJy4uL3Byb3Bvc2Fscy5qcyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjaydcblxuTWV0ZW9yLnB1Ymxpc2goJ3Byb3Bvc2Fscy5saXN0JywgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBQcm9wb3NhbHMuZmluZCh7fSwge3NvcnQ6e3Byb3Bvc2FsSWQ6LTF9fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ3Byb3Bvc2Fscy5vbmUnLCBmdW5jdGlvbiAoaWQpe1xuICAgIGNoZWNrKGlkLCBOdW1iZXIpO1xuICAgIHJldHVybiBQcm9wb3NhbHMuZmluZCh7cHJvcG9zYWxJZDppZH0pO1xufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBQcm9wb3NhbHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncHJvcG9zYWxzJyk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMsIEFuYWx5dGljcywgQXZlcmFnZURhdGEsIEF2ZXJhZ2VWYWxpZGF0b3JEYXRhIH0gZnJvbSAnLi4vcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclNldHMgfSBmcm9tICcvaW1wb3J0cy9hcGkvdmFsaWRhdG9yLXNldHMvdmFsaWRhdG9yLXNldHMuanMnO1xuaW1wb3J0IHsgU3RhdHVzIH0gZnJvbSAnLi4vLi4vc3RhdHVzL3N0YXR1cy5qcyc7XG5pbXBvcnQgeyBNaXNzZWRCbG9ja3NTdGF0cyB9IGZyb20gJy4uL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgTWlzc2VkQmxvY2tzIH0gZnJvbSAnLi4vcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBCbG9ja3Njb24gfSBmcm9tICcuLi8uLi9ibG9ja3MvYmxvY2tzLmpzJztcbmltcG9ydCB7IENoYWluIH0gZnJvbSAnLi4vLi4vY2hhaW4vY2hhaW4uanMnO1xuaW1wb3J0IF8gZnJvbSAnbG9kYXNoJztcbmNvbnN0IEJVTEtVUERBVEVNQVhTSVpFID0gMTAwMDtcblxuY29uc3QgZ2V0QmxvY2tTdGF0cyA9IChzdGFydEhlaWdodCwgbGF0ZXN0SGVpZ2h0KSA9PiB7XG4gICAgbGV0IGJsb2NrU3RhdHMgPSB7fTtcbiAgICBjb25zdCBjb25kID0geyRhbmQ6IFtcbiAgICAgICAgeyBoZWlnaHQ6IHsgJGd0OiBzdGFydEhlaWdodCB9IH0sXG4gICAgICAgIHsgaGVpZ2h0OiB7ICRsdGU6IGxhdGVzdEhlaWdodCB9IH0gXX07XG4gICAgY29uc3Qgb3B0aW9ucyA9IHtzb3J0OntoZWlnaHQ6IDF9fTtcbiAgICBCbG9ja3Njb24uZmluZChjb25kLCBvcHRpb25zKS5mb3JFYWNoKChibG9jaykgPT4ge1xuICAgICAgICBibG9ja1N0YXRzW2Jsb2NrLmhlaWdodF0gPSB7XG4gICAgICAgICAgICBoZWlnaHQ6IGJsb2NrLmhlaWdodCxcbiAgICAgICAgICAgIHByb3Bvc2VyQWRkcmVzczogYmxvY2sucHJvcG9zZXJBZGRyZXNzLFxuICAgICAgICAgICAgcHJlY29tbWl0c0NvdW50OiBibG9jay5wcmVjb21taXRzQ291bnQsXG4gICAgICAgICAgICB2YWxpZGF0b3JzQ291bnQ6IGJsb2NrLnZhbGlkYXRvcnNDb3VudCxcbiAgICAgICAgICAgIHZhbGlkYXRvcnM6IGJsb2NrLnZhbGlkYXRvcnMsXG4gICAgICAgICAgICB0aW1lOiBibG9jay50aW1lXG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIEFuYWx5dGljcy5maW5kKGNvbmQsIG9wdGlvbnMpLmZvckVhY2goKGJsb2NrKSA9PiB7XG4gICAgICAgIGlmICghYmxvY2tTdGF0c1tibG9jay5oZWlnaHRdKSB7XG4gICAgICAgICAgICBibG9ja1N0YXRzW2Jsb2NrLmhlaWdodF0gPSB7IGhlaWdodDogYmxvY2suaGVpZ2h0IH07XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgYmxvY2sgJHtibG9jay5oZWlnaHR9IGRvZXMgbm90IGhhdmUgYW4gZW50cnlgKTtcbiAgICAgICAgfVxuICAgICAgICBfLmFzc2lnbihibG9ja1N0YXRzW2Jsb2NrLmhlaWdodF0sIHtcbiAgICAgICAgICAgIHByZWNvbW1pdHM6IGJsb2NrLnByZWNvbW1pdHMsXG4gICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lOiBibG9jay5hdmVyYWdlQmxvY2tUaW1lLFxuICAgICAgICAgICAgdGltZURpZmY6IGJsb2NrLnRpbWVEaWZmLFxuICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiBibG9jay52b3RpbmdfcG93ZXJcbiAgICAgICAgfSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGJsb2NrU3RhdHM7XG59XG5cbmNvbnN0IGdldFByZXZpb3VzUmVjb3JkID0gKHZvdGVyQWRkcmVzcywgcHJvcG9zZXJBZGRyZXNzKSA9PiB7XG4gICAgbGV0IHByZXZpb3VzUmVjb3JkID0gTWlzc2VkQmxvY2tzLmZpbmRPbmUoXG4gICAgICAgIHt2b3Rlcjp2b3RlckFkZHJlc3MsIHByb3Bvc2VyOnByb3Bvc2VyQWRkcmVzcywgYmxvY2tIZWlnaHQ6IC0xfSk7XG4gICAgbGV0IGxhc3RVcGRhdGVkSGVpZ2h0ID0gTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGFydEhlaWdodDtcbiAgICBsZXQgcHJldlN0YXRzID0ge307XG4gICAgaWYgKHByZXZpb3VzUmVjb3JkKSB7XG4gICAgICAgIHByZXZTdGF0cyA9IF8ucGljayhwcmV2aW91c1JlY29yZCwgWydtaXNzQ291bnQnLCAndG90YWxDb3VudCddKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBwcmV2U3RhdHMgPSB7XG4gICAgICAgICAgICBtaXNzQ291bnQ6IDAsXG4gICAgICAgICAgICB0b3RhbENvdW50OiAwXG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHByZXZTdGF0cztcbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdWYWxpZGF0b3JSZWNvcmRzLmNhbGN1bGF0ZU1pc3NlZEJsb2Nrcyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIGlmICghQ09VTlRNSVNTRURCTE9DS1Mpe1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBsZXQgc3RhcnRUaW1lID0gRGF0ZS5ub3coKTtcbiAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLUyA9IHRydWU7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2NhbHVsYXRlIG1pc3NlZCBibG9ja3MgY291bnQnKTtcbiAgICAgICAgICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7fSkuZmV0Y2goKTtcbiAgICAgICAgICAgICAgICBsZXQgbGF0ZXN0SGVpZ2h0ID0gTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5nZXRDdXJyZW50SGVpZ2h0Jyk7XG4gICAgICAgICAgICAgICAgbGV0IGV4cGxvcmVyU3RhdHVzID0gU3RhdHVzLmZpbmRPbmUoe2NoYWluSWQ6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0pO1xuICAgICAgICAgICAgICAgIGxldCBzdGFydEhlaWdodCA9IChleHBsb3JlclN0YXR1cyYmZXhwbG9yZXJTdGF0dXMubGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrSGVpZ2h0KT9leHBsb3JlclN0YXR1cy5sYXN0UHJvY2Vzc2VkTWlzc2VkQmxvY2tIZWlnaHQ6TWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGFydEhlaWdodDtcbiAgICAgICAgICAgICAgICBsYXRlc3RIZWlnaHQgPSBNYXRoLm1pbihzdGFydEhlaWdodCArIEJVTEtVUERBVEVNQVhTSVpFLCBsYXRlc3RIZWlnaHQpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtNaXNzZWRTdGF0cyA9IE1pc3NlZEJsb2Nrcy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZU9yZGVyZWRCdWxrT3AoKTtcblxuICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3JzTWFwID0ge307XG4gICAgICAgICAgICAgICAgdmFsaWRhdG9ycy5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHZhbGlkYXRvcnNNYXBbdmFsaWRhdG9yLmFkZHJlc3NdID0gdmFsaWRhdG9yKTtcblxuICAgICAgICAgICAgICAgIC8vIGEgbWFwIG9mIGJsb2NrIGhlaWdodCB0byBibG9jayBzdGF0c1xuICAgICAgICAgICAgICAgIGxldCBibG9ja1N0YXRzID0gZ2V0QmxvY2tTdGF0cyhzdGFydEhlaWdodCwgbGF0ZXN0SGVpZ2h0KTtcblxuICAgICAgICAgICAgICAgIC8vIHByb3Bvc2VyVm90ZXJTdGF0cyBpcyBhIHByb3Bvc2VyLXZvdGVyIG1hcCBjb3VudGluZyBudW1iZXJzIG9mIHByb3Bvc2VkIGJsb2NrcyBvZiB3aGljaCB2b3RlciBpcyBhbiBhY3RpdmUgdmFsaWRhdG9yXG4gICAgICAgICAgICAgICAgbGV0IHByb3Bvc2VyVm90ZXJTdGF0cyA9IHt9XG5cbiAgICAgICAgICAgICAgICBfLmZvckVhY2goYmxvY2tTdGF0cywgKGJsb2NrLCBibG9ja0hlaWdodCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBsZXQgcHJvcG9zZXJBZGRyZXNzID0gYmxvY2sucHJvcG9zZXJBZGRyZXNzO1xuICAgICAgICAgICAgICAgICAgICBsZXQgdm90ZWRWYWxpZGF0b3JzID0gbmV3IFNldChibG9jay52YWxpZGF0b3JzKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvclNldHMgPSBWYWxpZGF0b3JTZXRzLmZpbmRPbmUoe2Jsb2NrX2hlaWdodDpibG9jay5oZWlnaHR9KTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHZvdGVkVm90aW5nUG93ZXIgPSAwO1xuXG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvclNldHMudmFsaWRhdG9ycy5mb3JFYWNoKChhY3RpdmVWYWxpZGF0b3IpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2b3RlZFZhbGlkYXRvcnMuaGFzKGFjdGl2ZVZhbGlkYXRvci5hZGRyZXNzKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RlZFZvdGluZ1Bvd2VyICs9IHBhcnNlRmxvYXQoYWN0aXZlVmFsaWRhdG9yLnZvdGluZ19wb3dlcilcbiAgICAgICAgICAgICAgICAgICAgfSlcblxuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JTZXRzLnZhbGlkYXRvcnMuZm9yRWFjaCgoYWN0aXZlVmFsaWRhdG9yKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY3VycmVudFZhbGlkYXRvciA9IGFjdGl2ZVZhbGlkYXRvci5hZGRyZXNzXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIV8uaGFzKHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvcl0pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByZXZTdGF0cyA9IGdldFByZXZpb3VzUmVjb3JkKGN1cnJlbnRWYWxpZGF0b3IsIHByb3Bvc2VyQWRkcmVzcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXy5zZXQocHJvcG9zZXJWb3RlclN0YXRzLCBbcHJvcG9zZXJBZGRyZXNzLCBjdXJyZW50VmFsaWRhdG9yXSwgcHJldlN0YXRzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgXy51cGRhdGUocHJvcG9zZXJWb3RlclN0YXRzLCBbcHJvcG9zZXJBZGRyZXNzLCBjdXJyZW50VmFsaWRhdG9yLCAndG90YWxDb3VudCddLCAobikgPT4gbisxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdm90ZWRWYWxpZGF0b3JzLmhhcyhjdXJyZW50VmFsaWRhdG9yKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF8udXBkYXRlKHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvciwgJ21pc3NDb3VudCddLCAobikgPT4gbisxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrTWlzc2VkU3RhdHMuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90ZXI6IGN1cnJlbnRWYWxpZGF0b3IsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrSGVpZ2h0OiBibG9jay5oZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2VyOiBwcm9wb3NlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZWNvbW1pdHNDb3VudDogYmxvY2sucHJlY29tbWl0c0NvdW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JzQ291bnQ6IGJsb2NrLnZhbGlkYXRvcnNDb3VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZTogYmxvY2sudGltZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJlY29tbWl0czogYmxvY2sucHJlY29tbWl0cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZTogYmxvY2suYXZlcmFnZUJsb2NrVGltZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZURpZmY6IGJsb2NrLnRpbWVEaWZmLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdQb3dlcjogYmxvY2sudm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RlZFZvdGluZ1Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkQXQ6IGxhdGVzdEhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWlzc0NvdW50OiBfLmdldChwcm9wb3NlclZvdGVyU3RhdHMsIFtwcm9wb3NlckFkZHJlc3MsIGN1cnJlbnRWYWxpZGF0b3IsICdtaXNzQ291bnQnXSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsQ291bnQ6IF8uZ2V0KHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvciwgJ3RvdGFsQ291bnQnXSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIF8uZm9yRWFjaChwcm9wb3NlclZvdGVyU3RhdHMsICh2b3RlcnMsIHByb3Bvc2VyQWRkcmVzcykgPT4ge1xuICAgICAgICAgICAgICAgICAgICBfLmZvckVhY2godm90ZXJzLCAoc3RhdHMsIHZvdGVyQWRkcmVzcykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgYnVsa01pc3NlZFN0YXRzLmZpbmQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGVyOiB2b3RlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zZXI6IHByb3Bvc2VyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja0hlaWdodDogLTFcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGVyOiB2b3RlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zZXI6IHByb3Bvc2VyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja0hlaWdodDogLTEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEF0OiBsYXRlc3RIZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWlzc0NvdW50OiBfLmdldChzdGF0cywgJ21pc3NDb3VudCcpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsQ291bnQ6IF8uZ2V0KHN0YXRzLCAndG90YWxDb3VudCcpXG4gICAgICAgICAgICAgICAgICAgICAgICB9fSk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgbGV0IG1lc3NhZ2UgPSAnJztcbiAgICAgICAgICAgICAgICBpZiAoYnVsa01pc3NlZFN0YXRzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjbGllbnQgPSBNaXNzZWRCbG9ja3MuX2RyaXZlci5tb25nby5jbGllbnQ7XG4gICAgICAgICAgICAgICAgICAgIC8vIFRPRE86IGFkZCB0cmFuc2FjdGlvbiBiYWNrIGFmdGVyIHJlcGxpY2Egc2V0KCMxNDYpIGlzIHNldCB1cFxuICAgICAgICAgICAgICAgICAgICAvLyBsZXQgc2Vzc2lvbiA9IGNsaWVudC5zdGFydFNlc3Npb24oKTtcbiAgICAgICAgICAgICAgICAgICAgLy8gc2Vzc2lvbi5zdGFydFRyYW5zYWN0aW9uKCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBidWxrUHJvbWlzZSA9IGJ1bGtNaXNzZWRTdGF0cy5leGVjdXRlKG51bGwvKiwge3Nlc3Npb259Ki8pLnRoZW4oXG4gICAgICAgICAgICAgICAgICAgICAgICBNZXRlb3IuYmluZEVudmlyb25tZW50KChyZXN1bHQsIGVycikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLUyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBQcm9taXNlLmF3YWl0KHNlc3Npb24uYWJvcnRUcmFuc2FjdGlvbigpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUHJvbWlzZS5hd2FpdChzZXNzaW9uLmNvbW1pdFRyYW5zYWN0aW9uKCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlID0gYCgke3Jlc3VsdC5yZXN1bHQubkluc2VydGVkfSBpbnNlcnRlZCwgYCArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYCR7cmVzdWx0LnJlc3VsdC5uVXBzZXJ0ZWR9IHVwc2VydGVkLCBgICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgJHtyZXN1bHQucmVzdWx0Lm5Nb2RpZmllZH0gbW9kaWZpZWQpYDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgICAgICAgICAgICAgUHJvbWlzZS5hd2FpdChidWxrUHJvbWlzZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1MgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBTdGF0dXMudXBzZXJ0KHtjaGFpbklkOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LCB7JHNldDp7bGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrSGVpZ2h0OmxhdGVzdEhlaWdodCwgbGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrVGltZTogbmV3IERhdGUoKX19KTtcbiAgICAgICAgICAgICAgICByZXR1cm4gYGRvbmUgaW4gJHtEYXRlLm5vdygpIC0gc3RhcnRUaW1lfW1zICR7bWVzc2FnZX1gO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgcmV0dXJuIFwidXBkYXRpbmcuLi5cIjtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ1ZhbGlkYXRvclJlY29yZHMuY2FsY3VsYXRlTWlzc2VkQmxvY2tzU3RhdHMnOiBmdW5jdGlvbigpe1xuICAgICAgICAvLyBUT0RPOiBkZXByZWNhdGUgdGhpcyBtZXRob2QgYW5kIE1pc3NlZEJsb2Nrc1N0YXRzIGNvbGxlY3Rpb25cbiAgICAgICAgLy8gY29uc29sZS5sb2coXCJWYWxpZGF0b3JSZWNvcmRzLmNhbGN1bGF0ZU1pc3NlZEJsb2NrczogXCIrQ09VTlRNSVNTRURCTE9DS1MpO1xuICAgICAgICBpZiAoIUNPVU5UTUlTU0VEQkxPQ0tTU1RBVFMpe1xuICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1NTVEFUUyA9IHRydWU7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnY2FsdWxhdGUgbWlzc2VkIGJsb2NrcyBzdGF0cycpO1xuICAgICAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgICAgICBsZXQgdmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7fSkuZmV0Y2goKTtcbiAgICAgICAgICAgIGxldCBsYXRlc3RIZWlnaHQgPSBNZXRlb3IuY2FsbCgnYmxvY2tzLmdldEN1cnJlbnRIZWlnaHQnKTtcbiAgICAgICAgICAgIGxldCBleHBsb3JlclN0YXR1cyA9IFN0YXR1cy5maW5kT25lKHtjaGFpbklkOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9KTtcbiAgICAgICAgICAgIGxldCBzdGFydEhlaWdodCA9IChleHBsb3JlclN0YXR1cyYmZXhwbG9yZXJTdGF0dXMubGFzdE1pc3NlZEJsb2NrSGVpZ2h0KT9leHBsb3JlclN0YXR1cy5sYXN0TWlzc2VkQmxvY2tIZWlnaHQ6TWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGFydEhlaWdodDtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGxhdGVzdEhlaWdodCk7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhzdGFydEhlaWdodCk7XG4gICAgICAgICAgICBjb25zdCBidWxrTWlzc2VkU3RhdHMgPSBNaXNzZWRCbG9ja3NTdGF0cy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgICAgICAgICAgZm9yIChpIGluIHZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgICAgIC8vIGlmICgodmFsaWRhdG9yc1tpXS5hZGRyZXNzID09IFwiQjg1NTJFQUMwRDEyM0E2QkY2MDkxMjMwNDdBNTE4MUQ0NUVFOTBCNVwiKSB8fCAodmFsaWRhdG9yc1tpXS5hZGRyZXNzID09IFwiNjlEOTlCMkM2NjA0M0FDQkVBQTg0NDc1MjVDMzU2QUZDNjQwOEUwQ1wiKSB8fCAodmFsaWRhdG9yc1tpXS5hZGRyZXNzID09IFwiMzVBRDdBMkNEMkZDNzE3MTFBNjc1ODMwRUMxMTU4MDgyMjczRDQ1N1wiKSl7XG4gICAgICAgICAgICAgICAgbGV0IHZvdGVyQWRkcmVzcyA9IHZhbGlkYXRvcnNbaV0uYWRkcmVzcztcbiAgICAgICAgICAgICAgICBsZXQgbWlzc2VkUmVjb3JkcyA9IFZhbGlkYXRvclJlY29yZHMuZmluZCh7XG4gICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6dm90ZXJBZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICBleGlzdHM6ZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICRhbmQ6IFsgeyBoZWlnaHQ6IHsgJGd0OiBzdGFydEhlaWdodCB9IH0sIHsgaGVpZ2h0OiB7ICRsdGU6IGxhdGVzdEhlaWdodCB9IH0gXVxuICAgICAgICAgICAgICAgIH0pLmZldGNoKCk7XG5cbiAgICAgICAgICAgICAgICBsZXQgY291bnRzID0ge307XG5cbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcIm1pc3NlZFJlY29yZHMgdG8gcHJvY2VzczogXCIrbWlzc2VkUmVjb3Jkcy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgIGZvciAoYiBpbiBtaXNzZWRSZWNvcmRzKXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGJsb2NrID0gQmxvY2tzY29uLmZpbmRPbmUoe2hlaWdodDptaXNzZWRSZWNvcmRzW2JdLmhlaWdodH0pO1xuICAgICAgICAgICAgICAgICAgICBsZXQgZXhpc3RpbmdSZWNvcmQgPSBNaXNzZWRCbG9ja3NTdGF0cy5maW5kT25lKHt2b3Rlcjp2b3RlckFkZHJlc3MsIHByb3Bvc2VyOmJsb2NrLnByb3Bvc2VyQWRkcmVzc30pO1xuXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY291bnRzW2Jsb2NrLnByb3Bvc2VyQWRkcmVzc10gPT09ICd1bmRlZmluZWQnKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChleGlzdGluZ1JlY29yZCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY291bnRzW2Jsb2NrLnByb3Bvc2VyQWRkcmVzc10gPSBleGlzdGluZ1JlY29yZC5jb3VudCsxO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb3VudHNbYmxvY2sucHJvcG9zZXJBZGRyZXNzXSA9IDE7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50c1tibG9jay5wcm9wb3NlckFkZHJlc3NdKys7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBmb3IgKGFkZHJlc3MgaW4gY291bnRzKXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGEgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2b3Rlcjogdm90ZXJBZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zZXI6YWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50OiBjb3VudHNbYWRkcmVzc11cbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGJ1bGtNaXNzZWRTdGF0cy5maW5kKHt2b3Rlcjp2b3RlckFkZHJlc3MsIHByb3Bvc2VyOmFkZHJlc3N9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6ZGF0YX0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyB9XG5cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKGJ1bGtNaXNzZWRTdGF0cy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICBidWxrTWlzc2VkU3RhdHMuZXhlY3V0ZShNZXRlb3IuYmluZEVudmlyb25tZW50KChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTU1RBVFMgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICBTdGF0dXMudXBzZXJ0KHtjaGFpbklkOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LCB7JHNldDp7bGFzdE1pc3NlZEJsb2NrSGVpZ2h0OmxhdGVzdEhlaWdodCwgbGFzdE1pc3NlZEJsb2NrVGltZTogbmV3IERhdGUoKX19KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTU1RBVFMgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZG9uZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1NTVEFUUyA9IGZhbHNlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgcmV0dXJuIFwidXBkYXRpbmcuLi5cIjtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ0FuYWx5dGljcy5hZ2dyZWdhdGVCbG9ja1RpbWVBbmRWb3RpbmdQb3dlcic6IGZ1bmN0aW9uKHRpbWUpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IG5vdyA9IG5ldyBEYXRlKCk7XG5cbiAgICAgICAgaWYgKHRpbWUgPT0gJ20nKXtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlQmxvY2tUaW1lID0gMDtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlVm90aW5nUG93ZXIgPSAwO1xuXG4gICAgICAgICAgICBsZXQgYW5hbHl0aWNzID0gQW5hbHl0aWNzLmZpbmQoeyBcInRpbWVcIjogeyAkZ3Q6IG5ldyBEYXRlKERhdGUubm93KCkgLSA2MCAqIDEwMDApIH0gfSkuZmV0Y2goKTtcbiAgICAgICAgICAgIGlmIChhbmFseXRpY3MubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgZm9yIChpIGluIGFuYWx5dGljcyl7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgKz0gYW5hbHl0aWNzW2ldLnRpbWVEaWZmO1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgKz0gYW5hbHl0aWNzW2ldLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSA9IGF2ZXJhZ2VCbG9ja1RpbWUgLyBhbmFseXRpY3MubGVuZ3RoO1xuICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlciA9IGF2ZXJhZ2VWb3RpbmdQb3dlciAvIGFuYWx5dGljcy5sZW5ndGg7XG5cbiAgICAgICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSx7JHNldDp7bGFzdE1pbnV0ZVZvdGluZ1Bvd2VyOmF2ZXJhZ2VWb3RpbmdQb3dlciwgbGFzdE1pbnV0ZUJsb2NrVGltZTphdmVyYWdlQmxvY2tUaW1lfX0pO1xuICAgICAgICAgICAgICAgIEF2ZXJhZ2VEYXRhLmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlcjogYXZlcmFnZVZvdGluZ1Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiB0aW1lLFxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5vd1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRpbWUgPT0gJ2gnKXtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlQmxvY2tUaW1lID0gMDtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlVm90aW5nUG93ZXIgPSAwO1xuICAgICAgICAgICAgbGV0IGFuYWx5dGljcyA9IEFuYWx5dGljcy5maW5kKHsgXCJ0aW1lXCI6IHsgJGd0OiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gNjAqNjAgKiAxMDAwKSB9IH0pLmZldGNoKCk7XG4gICAgICAgICAgICBpZiAoYW5hbHl0aWNzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgIGZvciAoaSBpbiBhbmFseXRpY3Mpe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lICs9IGFuYWx5dGljc1tpXS50aW1lRGlmZjtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyICs9IGFuYWx5dGljc1tpXS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgPSBhdmVyYWdlQmxvY2tUaW1lIC8gYW5hbHl0aWNzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgPSBhdmVyYWdlVm90aW5nUG93ZXIgLyBhbmFseXRpY3MubGVuZ3RoO1xuXG4gICAgICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0seyRzZXQ6e2xhc3RIb3VyVm90aW5nUG93ZXI6YXZlcmFnZVZvdGluZ1Bvd2VyLCBsYXN0SG91ckJsb2NrVGltZTphdmVyYWdlQmxvY2tUaW1lfX0pO1xuICAgICAgICAgICAgICAgIEF2ZXJhZ2VEYXRhLmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlcjogYXZlcmFnZVZvdGluZ1Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiB0aW1lLFxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5vd1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodGltZSA9PSAnZCcpe1xuICAgICAgICAgICAgbGV0IGF2ZXJhZ2VCbG9ja1RpbWUgPSAwO1xuICAgICAgICAgICAgbGV0IGF2ZXJhZ2VWb3RpbmdQb3dlciA9IDA7XG4gICAgICAgICAgICBsZXQgYW5hbHl0aWNzID0gQW5hbHl0aWNzLmZpbmQoeyBcInRpbWVcIjogeyAkZ3Q6IG5ldyBEYXRlKERhdGUubm93KCkgLSAyNCo2MCo2MCAqIDEwMDApIH0gfSkuZmV0Y2goKTtcbiAgICAgICAgICAgIGlmIChhbmFseXRpY3MubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgZm9yIChpIGluIGFuYWx5dGljcyl7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgKz0gYW5hbHl0aWNzW2ldLnRpbWVEaWZmO1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgKz0gYW5hbHl0aWNzW2ldLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSA9IGF2ZXJhZ2VCbG9ja1RpbWUgLyBhbmFseXRpY3MubGVuZ3RoO1xuICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlciA9IGF2ZXJhZ2VWb3RpbmdQb3dlciAvIGFuYWx5dGljcy5sZW5ndGg7XG5cbiAgICAgICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSx7JHNldDp7bGFzdERheVZvdGluZ1Bvd2VyOmF2ZXJhZ2VWb3RpbmdQb3dlciwgbGFzdERheUJsb2NrVGltZTphdmVyYWdlQmxvY2tUaW1lfX0pO1xuICAgICAgICAgICAgICAgIEF2ZXJhZ2VEYXRhLmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlcjogYXZlcmFnZVZvdGluZ1Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiB0aW1lLFxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5vd1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyByZXR1cm4gYW5hbHl0aWNzLmxlbmd0aDtcbiAgICB9LFxuICAgICdBbmFseXRpY3MuYWdncmVnYXRlVmFsaWRhdG9yRGFpbHlCbG9ja1RpbWUnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe30pLmZldGNoKCk7XG4gICAgICAgIGxldCBub3cgPSBuZXcgRGF0ZSgpO1xuICAgICAgICBmb3IgKGkgaW4gdmFsaWRhdG9ycyl7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZUJsb2NrVGltZSA9IDA7XG5cbiAgICAgICAgICAgIGxldCBibG9ja3MgPSBCbG9ja3Njb24uZmluZCh7cHJvcG9zZXJBZGRyZXNzOnZhbGlkYXRvcnNbaV0uYWRkcmVzcywgXCJ0aW1lXCI6IHsgJGd0OiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gMjQqNjAqNjAgKiAxMDAwKSB9fSwge2ZpZWxkczp7aGVpZ2h0OjF9fSkuZmV0Y2goKTtcblxuICAgICAgICAgICAgaWYgKGJsb2Nrcy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICBsZXQgYmxvY2tIZWlnaHRzID0gW107XG4gICAgICAgICAgICAgICAgZm9yIChiIGluIGJsb2Nrcyl7XG4gICAgICAgICAgICAgICAgICAgIGJsb2NrSGVpZ2h0cy5wdXNoKGJsb2Nrc1tiXS5oZWlnaHQpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGxldCBhbmFseXRpY3MgPSBBbmFseXRpY3MuZmluZCh7aGVpZ2h0OiB7JGluOmJsb2NrSGVpZ2h0c319LCB7ZmllbGRzOntoZWlnaHQ6MSx0aW1lRGlmZjoxfX0pLmZldGNoKCk7XG5cblxuICAgICAgICAgICAgICAgIGZvciAoYSBpbiBhbmFseXRpY3Mpe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lICs9IGFuYWx5dGljc1thXS50aW1lRGlmZjtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lID0gYXZlcmFnZUJsb2NrVGltZSAvIGFuYWx5dGljcy5sZW5ndGg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIEF2ZXJhZ2VWYWxpZGF0b3JEYXRhLmluc2VydCh7XG4gICAgICAgICAgICAgICAgcHJvcG9zZXJBZGRyZXNzOiB2YWxpZGF0b3JzW2ldLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZTogYXZlcmFnZUJsb2NrVGltZSxcbiAgICAgICAgICAgICAgICB0eXBlOiAnVmFsaWRhdG9yRGFpbHlBdmVyYWdlQmxvY2tUaW1lJyxcbiAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5vd1xuICAgICAgICAgICAgfSlcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMsIEFuYWx5dGljcywgTWlzc2VkQmxvY2tzLCBNaXNzZWRCbG9ja3NTdGF0cywgVlBEaXN0cmlidXRpb25zIH0gZnJvbSAnLi4vcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcblxuTWV0ZW9yLnB1Ymxpc2goJ3ZhbGlkYXRvcl9yZWNvcmRzLmFsbCcsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gVmFsaWRhdG9yUmVjb3Jkcy5maW5kKCk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ3ZhbGlkYXRvcl9yZWNvcmRzLnVwdGltZScsIGZ1bmN0aW9uKGFkZHJlc3MsIG51bSl7XG4gICAgcmV0dXJuIFZhbGlkYXRvclJlY29yZHMuZmluZCh7YWRkcmVzczphZGRyZXNzfSx7bGltaXQ6bnVtLCBzb3J0OntoZWlnaHQ6LTF9fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ2FuYWx5dGljcy5oaXN0b3J5JywgZnVuY3Rpb24oKXtcbiAgICByZXR1cm4gQW5hbHl0aWNzLmZpbmQoe30se3NvcnQ6e2hlaWdodDotMX0sbGltaXQ6NTB9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaCgndnBEaXN0cmlidXRpb24ubGF0ZXN0JywgZnVuY3Rpb24oKXtcbiAgICByZXR1cm4gVlBEaXN0cmlidXRpb25zLmZpbmQoe30se3NvcnQ6e2hlaWdodDotMX0sIGxpbWl0OjF9KTtcbn0pO1xuXG5wdWJsaXNoQ29tcG9zaXRlKCdtaXNzZWRibG9ja3MudmFsaWRhdG9yJywgZnVuY3Rpb24oYWRkcmVzcywgdHlwZSl7XG4gICAgbGV0IGNvbmRpdGlvbnMgPSB7fTtcbiAgICBpZiAodHlwZSA9PSAndm90ZXInKXtcbiAgICAgICAgY29uZGl0aW9ucyA9IHtcbiAgICAgICAgICAgIHZvdGVyOiBhZGRyZXNzXG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZXtcbiAgICAgICAgY29uZGl0aW9ucyA9IHtcbiAgICAgICAgICAgIHByb3Bvc2VyOiBhZGRyZXNzXG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIE1pc3NlZEJsb2Nrc1N0YXRzLmZpbmQoY29uZGl0aW9ucylcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHN0YXRzKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7YWRkcmVzczoxLCBkZXNjcmlwdGlvbjoxLCBwcm9maWxlX3VybDoxfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pO1xuXG5wdWJsaXNoQ29tcG9zaXRlKCdtaXNzZWRyZWNvcmRzLnZhbGlkYXRvcicsIGZ1bmN0aW9uKGFkZHJlc3MsIHR5cGUpe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBNaXNzZWRCbG9ja3MuZmluZChcbiAgICAgICAgICAgICAgICB7W3R5cGVdOiBhZGRyZXNzfSxcbiAgICAgICAgICAgICAgICB7c29ydDoge3VwZGF0ZWRBdDogLTF9fVxuICAgICAgICAgICAgKVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7YWRkcmVzczoxLCBkZXNjcmlwdGlvbjoxLCBvcGVyYXRvcl9hZGRyZXNzOjF9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzJztcblxuZXhwb3J0IGNvbnN0IFZhbGlkYXRvclJlY29yZHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndmFsaWRhdG9yX3JlY29yZHMnKTtcbmV4cG9ydCBjb25zdCBBbmFseXRpY3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignYW5hbHl0aWNzJyk7XG5leHBvcnQgY29uc3QgTWlzc2VkQmxvY2tzU3RhdHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignbWlzc2VkX2Jsb2Nrc19zdGF0cycpO1xuZXhwb3J0IGNvbnN0IE1pc3NlZEJsb2NrcyA9IG5ldyAgTW9uZ28uQ29sbGVjdGlvbignbWlzc2VkX2Jsb2NrcycpO1xuZXhwb3J0IGNvbnN0IFZQRGlzdHJpYnV0aW9ucyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd2b3RpbmdfcG93ZXJfZGlzdHJpYnV0aW9ucycpO1xuZXhwb3J0IGNvbnN0IEF2ZXJhZ2VEYXRhID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2F2ZXJhZ2VfZGF0YScpO1xuZXhwb3J0IGNvbnN0IEF2ZXJhZ2VWYWxpZGF0b3JEYXRhID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2F2ZXJhZ2VfdmFsaWRhdG9yX2RhdGEnKTtcblxuTWlzc2VkQmxvY2tzU3RhdHMuaGVscGVycyh7XG4gICAgcHJvcG9zZXJNb25pa2VyKCl7XG4gICAgICAgIGxldCB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe2FkZHJlc3M6dGhpcy5wcm9wb3Nlcn0pO1xuICAgICAgICByZXR1cm4gKHZhbGlkYXRvci5kZXNjcmlwdGlvbik/dmFsaWRhdG9yLmRlc2NyaXB0aW9uLm1vbmlrZXI6dGhpcy5wcm9wb3NlcjtcbiAgICB9LFxuICAgIHZvdGVyTW9uaWtlcigpe1xuICAgICAgICBsZXQgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKHthZGRyZXNzOnRoaXMudm90ZXJ9KTtcbiAgICAgICAgcmV0dXJuICh2YWxpZGF0b3IuZGVzY3JpcHRpb24pP3ZhbGlkYXRvci5kZXNjcmlwdGlvbi5tb25pa2VyOnRoaXMudm90ZXI7XG4gICAgfVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgU3RhdHVzIH0gZnJvbSAnLi4vc3RhdHVzLmpzJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJ1xuXG5NZXRlb3IucHVibGlzaCgnc3RhdHVzLnN0YXR1cycsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gU3RhdHVzLmZpbmQoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSk7XG59KTtcblxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgU3RhdHVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3N0YXR1cycpOyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uLy4uL3RyYW5zYWN0aW9ucy90cmFuc2FjdGlvbnMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBWb3RpbmdQb3dlckhpc3RvcnkgfSBmcm9tICcuLi8uLi92b3RpbmctcG93ZXIvaGlzdG9yeS5qcyc7XG5cbmNvbnN0IEFkZHJlc3NMZW5ndGggPSA0MDtcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdUcmFuc2FjdGlvbnMuaW5kZXgnOiBmdW5jdGlvbihoYXNoLCBibG9ja1RpbWUpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgaGFzaCA9IGhhc2gudG9VcHBlckNhc2UoKTtcbiAgICAgICAgbGV0IHVybCA9IExDRCsgJy90eHMvJytoYXNoO1xuICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICBsZXQgdHggPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGhhc2gpO1xuXG4gICAgICAgIHR4LmhlaWdodCA9IHBhcnNlSW50KHR4LmhlaWdodCk7XG5cbiAgICAgICAgLy8gaWYgKCF0eC5jb2RlKXtcbiAgICAgICAgLy8gICAgIGxldCBtc2cgPSB0eC50eC52YWx1ZS5tc2c7XG4gICAgICAgIC8vICAgICBmb3IgKGxldCBtIGluIG1zZyl7XG4gICAgICAgIC8vICAgICAgICAgaWYgKG1zZ1ttXS50eXBlID09IFwiY29zbW9zLXNkay9Nc2dDcmVhdGVWYWxpZGF0b3JcIil7XG4gICAgICAgIC8vICAgICAgICAgICAgIGNvbnNvbGUubG9nKG1zZ1ttXS52YWx1ZSk7XG4gICAgICAgIC8vICAgICAgICAgICAgIGxldCBjb21tYW5kID0gTWV0ZW9yLnNldHRpbmdzLmJpbi5nYWlhZGVidWcrXCIgcHVia2V5IFwiK21zZ1ttXS52YWx1ZS5wdWJrZXk7XG4gICAgICAgIC8vICAgICAgICAgICAgIGxldCB2YWxpZGF0b3IgPSB7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBjb25zZW5zdXNfcHVia2V5OiBtc2dbbV0udmFsdWUucHVia2V5LFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IG1zZ1ttXS52YWx1ZS5kZXNjcmlwdGlvbixcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIGNvbW1pc3Npb246IG1zZ1ttXS52YWx1ZS5jb21taXNzaW9uLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgbWluX3NlbGZfZGVsZWdhdGlvbjogbXNnW21dLnZhbHVlLm1pbl9zZWxmX2RlbGVnYXRpb24sXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBvcGVyYXRvcl9hZGRyZXNzOiBtc2dbbV0udmFsdWUudmFsaWRhdG9yX2FkZHJlc3MsXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBkZWxlZ2F0b3JfYWRkcmVzczogbXNnW21dLnZhbHVlLmRlbGVnYXRvcl9hZGRyZXNzLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiBNYXRoLmZsb29yKHBhcnNlSW50KG1zZ1ttXS52YWx1ZS52YWx1ZS5hbW91bnQpIC8gMTAwMDAwMClcbiAgICAgICAgLy8gICAgICAgICAgICAgfVxuXG4gICAgICAgIC8vICAgICAgICAgICAgIE1ldGVvci5jYWxsKCdydW5Db2RlJywgY29tbWFuZCwgZnVuY3Rpb24oZXJyb3IsIHJlc3VsdCl7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYWRkcmVzcyA9IHJlc3VsdC5tYXRjaCgvXFxzWzAtOUEtRl17NDB9JC9pZ20pO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFkZHJlc3MgPSB2YWxpZGF0b3IuYWRkcmVzc1swXS50cmltKCk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuaGV4ID0gcmVzdWx0Lm1hdGNoKC9cXHNbMC05QS1GXXs2NH0kL2lnbSk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuaGV4ID0gdmFsaWRhdG9yLmhleFswXS50cmltKCk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHViX2tleSA9IHJlc3VsdC5tYXRjaCgve1wiLipcIn0vaWdtKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHZhbGlkYXRvci5wdWJfa2V5ID0gSlNPTi5wYXJzZSh2YWxpZGF0b3IucHViX2tleVswXS50cmltKCkpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgbGV0IHJlID0gbmV3IFJlZ0V4cChNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY1B1YitcIi4qJFwiLFwiaWdtXCIpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmNvc21vc2FjY3B1YiA9IHJlc3VsdC5tYXRjaChyZSk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuY29zbW9zYWNjcHViID0gdmFsaWRhdG9yLmNvc21vc2FjY3B1YlswXS50cmltKCk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICByZSA9IG5ldyBSZWdFeHAoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhWYWxQdWIrXCIuKiRcIixcImlnbVwiKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXkgPSByZXN1bHQubWF0Y2gocmUpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLm9wZXJhdG9yX3B1YmtleSA9IHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXlbMF0udHJpbSgpO1xuXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBWYWxpZGF0b3JzLnVwc2VydCh7Y29uc2Vuc3VzX3B1YmtleTptc2dbbV0udmFsdWUucHVia2V5fSx2YWxpZGF0b3IpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgVm90aW5nUG93ZXJIaXN0b3J5Lmluc2VydCh7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogdmFsaWRhdG9yLmFkZHJlc3MsXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IDAsXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdhZGQnLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogdHguaGVpZ2h0KzIsXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogYmxvY2tUaW1lXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgLy8gICAgICAgICAgICAgfSlcbiAgICAgICAgLy8gICAgICAgICB9XG4gICAgICAgIC8vICAgICB9XG4gICAgICAgIC8vIH1cblxuXG4gICAgICAgIGxldCB0eElkID0gVHJhbnNhY3Rpb25zLmluc2VydCh0eCk7XG4gICAgICAgIGlmICh0eElkKXtcbiAgICAgICAgICAgIHJldHVybiB0eElkO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgJ1RyYW5zYWN0aW9ucy5maW5kRGVsZWdhdGlvbic6IGZ1bmN0aW9uKGFkZHJlc3MsIGhlaWdodCl7XG4gICAgICAgIC8vIGZvbGxvd2luZyBjb3Ntb3Mtc2RrL3gvc2xhc2hpbmcvc3BlYy8wNl9ldmVudHMubWQgYW5kIGNvc21vcy1zZGsveC9zdGFraW5nL3NwZWMvMDZfZXZlbnRzLm1kXG4gICAgICAgIHJldHVybiBUcmFuc2FjdGlvbnMuZmluZCh7XG4gICAgICAgICAgICAkb3I6IFt7JGFuZDogW1xuICAgICAgICAgICAgICAgIHtcImV2ZW50cy50eXBlXCI6IFwiZGVsZWdhdGVcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCI6IFwidmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6IGFkZHJlc3N9XG4gICAgICAgICAgICBdfSwgeyRhbmQ6W1xuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOiBcImFjdGlvblwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOiBcInVuamFpbFwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy5rZXlcIjogXCJzZW5kZXJcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjogYWRkcmVzc31cbiAgICAgICAgICAgIF19LCB7JGFuZDpbXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLnR5cGVcIjogXCJjcmVhdGVfdmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOiBcInZhbGlkYXRvclwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOiBhZGRyZXNzfVxuICAgICAgICAgICAgXX0sIHskYW5kOltcbiAgICAgICAgICAgICAgICB7XCJldmVudHMudHlwZVwiOiBcInVuYm9uZFwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy5rZXlcIjogXCJ2YWxpZGF0b3JcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjogYWRkcmVzc31cbiAgICAgICAgICAgIF19LCB7JGFuZDpbXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLnR5cGVcIjogXCJyZWRlbGVnYXRlXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOiBcImRlc3RpbmF0aW9uX3ZhbGlkYXRvclwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOiBhZGRyZXNzfVxuICAgICAgICAgICAgXX1dLFxuICAgICAgICAgICAgXCJjb2RlXCI6IHskZXhpc3RzOiBmYWxzZX0sXG4gICAgICAgICAgICBoZWlnaHQ6eyRsdDpoZWlnaHR9fSxcbiAgICAgICAge3NvcnQ6e2hlaWdodDotMX0sXG4gICAgICAgICAgICBsaW1pdDogMX1cbiAgICAgICAgKS5mZXRjaCgpO1xuICAgIH0sXG4gICAgJ1RyYW5zYWN0aW9ucy5maW5kVXNlcic6IGZ1bmN0aW9uKGFkZHJlc3MsIGZpZWxkcz1udWxsKXtcbiAgICAgICAgLy8gYWRkcmVzcyBpcyBlaXRoZXIgZGVsZWdhdG9yIGFkZHJlc3Mgb3IgdmFsaWRhdG9yIG9wZXJhdG9yIGFkZHJlc3NcbiAgICAgICAgbGV0IHZhbGlkYXRvcjtcbiAgICAgICAgaWYgKCFmaWVsZHMpXG4gICAgICAgICAgICBmaWVsZHMgPSB7YWRkcmVzczoxLCBkZXNjcmlwdGlvbjoxLCBvcGVyYXRvcl9hZGRyZXNzOjEsIGRlbGVnYXRvcl9hZGRyZXNzOjF9O1xuICAgICAgICBpZiAoYWRkcmVzcy5pbmNsdWRlcyhNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeFZhbEFkZHIpKXtcbiAgICAgICAgICAgIC8vIHZhbGlkYXRvciBvcGVyYXRvciBhZGRyZXNzXG4gICAgICAgICAgICB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe29wZXJhdG9yX2FkZHJlc3M6YWRkcmVzc30sIHtmaWVsZHN9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChhZGRyZXNzLmluY2x1ZGVzKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4QWNjQWRkcikpe1xuICAgICAgICAgICAgLy8gZGVsZWdhdG9yIGFkZHJlc3NcbiAgICAgICAgICAgIHZhbGlkYXRvciA9IFZhbGlkYXRvcnMuZmluZE9uZSh7ZGVsZWdhdG9yX2FkZHJlc3M6YWRkcmVzc30sIHtmaWVsZHN9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChhZGRyZXNzLmxlbmd0aCA9PT0gQWRkcmVzc0xlbmd0aCkge1xuICAgICAgICAgICAgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKHthZGRyZXNzOmFkZHJlc3N9LCB7ZmllbGRzfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHZhbGlkYXRvcil7XG4gICAgICAgICAgICByZXR1cm4gdmFsaWRhdG9yO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcblxuICAgIH1cbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi90cmFuc2FjdGlvbnMuanMnO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vLi4vYmxvY2tzL2Jsb2Nrcy5qcyc7XG5cblxucHVibGlzaENvbXBvc2l0ZSgndHJhbnNhY3Rpb25zLmxpc3QnLCBmdW5jdGlvbihsaW1pdCA9IDMwKXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQoe30se3NvcnQ6e2hlaWdodDotMX0sIGxpbWl0OmxpbWl0fSlcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHR4KXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2hlaWdodDp0eC5oZWlnaHR9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7dGltZToxLCBoZWlnaHQ6MX19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgndHJhbnNhY3Rpb25zLnZhbGlkYXRvcicsIGZ1bmN0aW9uKHZhbGlkYXRvckFkZHJlc3MsIGRlbGVnYXRvckFkZHJlc3MsIGxpbWl0PTEwMCl7XG4gICAgbGV0IHF1ZXJ5ID0ge307XG4gICAgaWYgKHZhbGlkYXRvckFkZHJlc3MgJiYgZGVsZWdhdG9yQWRkcmVzcyl7XG4gICAgICAgIHF1ZXJ5ID0geyRvcjpbe1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjp2YWxpZGF0b3JBZGRyZXNzfSwge1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjpkZWxlZ2F0b3JBZGRyZXNzfV19XG4gICAgfVxuXG4gICAgaWYgKCF2YWxpZGF0b3JBZGRyZXNzICYmIGRlbGVnYXRvckFkZHJlc3Mpe1xuICAgICAgICBxdWVyeSA9IHtcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6ZGVsZWdhdG9yQWRkcmVzc31cbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQocXVlcnksIHtzb3J0OntoZWlnaHQ6LTF9LCBsaW1pdDpsaW1pdH0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOltcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHR4KXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2hlaWdodDp0eC5oZWlnaHR9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7dGltZToxLCBoZWlnaHQ6MX19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KVxuXG5wdWJsaXNoQ29tcG9zaXRlKCd0cmFuc2FjdGlvbnMuZmluZE9uZScsIGZ1bmN0aW9uKGhhc2gpe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBUcmFuc2FjdGlvbnMuZmluZCh7dHhoYXNoOmhhc2h9KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQodHgpe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7aGVpZ2h0OnR4LmhlaWdodH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmllbGRzOnt0aW1lOjEsIGhlaWdodDoxfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pXG5cbnB1Ymxpc2hDb21wb3NpdGUoJ3RyYW5zYWN0aW9ucy5oZWlnaHQnLCBmdW5jdGlvbihoZWlnaHQpe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBUcmFuc2FjdGlvbnMuZmluZCh7aGVpZ2h0OmhlaWdodH0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZCh0eCl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHtoZWlnaHQ6dHguaGVpZ2h0fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e3RpbWU6MSwgaGVpZ2h0OjF9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBCbG9ja3Njb24gfSBmcm9tICcuLi9ibG9ja3MvYmxvY2tzLmpzJztcbmltcG9ydCB7IFR4SWNvbiB9IGZyb20gJy4uLy4uL3VpL2NvbXBvbmVudHMvSWNvbnMuanN4JztcblxuZXhwb3J0IGNvbnN0IFRyYW5zYWN0aW9ucyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd0cmFuc2FjdGlvbnMnKTtcblxuVHJhbnNhY3Rpb25zLmhlbHBlcnMoe1xuICAgIGJsb2NrKCl7XG4gICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZE9uZSh7aGVpZ2h0OnRoaXMuaGVpZ2h0fSk7XG4gICAgfVxufSkiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uLy4uL3RyYW5zYWN0aW9ucy90cmFuc2FjdGlvbnMuanMnO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vLi4vYmxvY2tzL2Jsb2Nrcy5qcyc7XG5pbXBvcnQgeyBEZWxlZ2F0aW9ucyB9IGZyb20gJy4uLy4uL2RlbGVnYXRpb25zL2RlbGVnYXRpb25zLmpzJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdWYWxpZGF0b3JzLmZpbmRDcmVhdGVWYWxpZGF0b3JUaW1lJzogZnVuY3Rpb24oYWRkcmVzcyl7XG4gICAgICAgIC8vIGxvb2sgdXAgdGhlIGNyZWF0ZSB2YWxpZGF0b3IgdGltZSB0byBjb25zaWRlciBpZiB0aGUgdmFsaWRhdG9yIGhhcyBuZXZlciB1cGRhdGVkIHRoZSBjb21taXNzaW9uXG4gICAgICAgIGxldCB0eCA9IFRyYW5zYWN0aW9ucy5maW5kT25lKHskYW5kOltcbiAgICAgICAgICAgIHtcInR4LnZhbHVlLm1zZy52YWx1ZS5kZWxlZ2F0b3JfYWRkcmVzc1wiOmFkZHJlc3N9LFxuICAgICAgICAgICAge1widHgudmFsdWUubXNnLnR5cGVcIjpcImNvc21vcy1zZGsvTXNnQ3JlYXRlVmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAge2NvZGU6eyRleGlzdHM6ZmFsc2V9fVxuICAgICAgICBdfSk7XG5cbiAgICAgICAgaWYgKHR4KXtcbiAgICAgICAgICAgIGxldCBibG9jayA9IEJsb2Nrc2Nvbi5maW5kT25lKHtoZWlnaHQ6dHguaGVpZ2h0fSk7XG4gICAgICAgICAgICBpZiAoYmxvY2spe1xuICAgICAgICAgICAgICAgIHJldHVybiBibG9jay50aW1lO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICAvLyBubyBzdWNoIGNyZWF0ZSB2YWxpZGF0b3IgdHhcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgLy8gYXN5bmMgJ1ZhbGlkYXRvcnMuZ2V0QWxsRGVsZWdhdGlvbnMnKGFkZHJlc3Mpe1xuICAgICdWYWxpZGF0b3JzLmdldEFsbERlbGVnYXRpb25zJyhhZGRyZXNzKXtcbiAgICAgICAgbGV0IHVybCA9IExDRCArICcvc3Rha2luZy92YWxpZGF0b3JzLycrYWRkcmVzcysnL2RlbGVnYXRpb25zJztcblxuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgZGVsZWdhdGlvbnMgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICBkZWxlZ2F0aW9ucyA9IEpTT04ucGFyc2UoZGVsZWdhdGlvbnMuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zLmZvckVhY2goKGRlbGVnYXRpb24sIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zW2ldICYmIGRlbGVnYXRpb25zW2ldLnNoYXJlcylcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zW2ldLnNoYXJlcyA9IHBhcnNlRmxvYXQoZGVsZWdhdGlvbnNbaV0uc2hhcmVzKTtcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHJldHVybiBkZWxlZ2F0aW9ucztcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICB9XG59KTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi92YWxpZGF0b3JzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMgfSBmcm9tICcuLi8uLi9yZWNvcmRzL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnLi4vLi4vdm90aW5nLXBvd2VyL2hpc3RvcnkuanMnO1xuXG5NZXRlb3IucHVibGlzaCgndmFsaWRhdG9ycy5hbGwnLCBmdW5jdGlvbiAoc29ydCA9IFwiZGVzY3JpcHRpb24ubW9uaWtlclwiLCBkaXJlY3Rpb24gPSAtMSwgZmllbGRzPXt9KSB7XG4gICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZCh7fSwge3NvcnQ6IHtbc29ydF06IGRpcmVjdGlvbn0sIGZpZWxkczogZmllbGRzfSk7XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgndmFsaWRhdG9ycy5maXJzdFNlZW4nLHtcbiAgICBmaW5kKCkge1xuICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKHt9KTtcbiAgICB9LFxuICAgIGNoaWxkcmVuOiBbXG4gICAgICAgIHtcbiAgICAgICAgICAgIGZpbmQodmFsKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvclJlY29yZHMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgeyBhZGRyZXNzOiB2YWwuYWRkcmVzcyB9LFxuICAgICAgICAgICAgICAgICAgICB7IHNvcnQ6IHtoZWlnaHQ6IDF9LCBsaW1pdDogMX1cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgXVxufSk7XG5cbk1ldGVvci5wdWJsaXNoKCd2YWxpZGF0b3JzLnZvdGluZ19wb3dlcicsIGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZCh7XG4gICAgICAgIHN0YXR1czogMixcbiAgICAgICAgamFpbGVkOmZhbHNlXG4gICAgfSx7XG4gICAgICAgIHNvcnQ6e1xuICAgICAgICAgICAgdm90aW5nX3Bvd2VyOi0xXG4gICAgICAgIH0sXG4gICAgICAgIGZpZWxkczp7XG4gICAgICAgICAgICBhZGRyZXNzOiAxLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246MSxcbiAgICAgICAgICAgIHZvdGluZ19wb3dlcjoxLFxuICAgICAgICAgICAgcHJvZmlsZV91cmw6MVxuICAgICAgICB9XG4gICAgfVxuICAgICk7XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgndmFsaWRhdG9yLmRldGFpbHMnLCBmdW5jdGlvbihhZGRyZXNzKXtcbiAgICBsZXQgb3B0aW9ucyA9IHthZGRyZXNzOmFkZHJlc3N9O1xuICAgIGlmIChhZGRyZXNzLmluZGV4T2YoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhWYWxBZGRyKSAhPSAtMSl7XG4gICAgICAgIG9wdGlvbnMgPSB7b3BlcmF0b3JfYWRkcmVzczphZGRyZXNzfVxuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKG9wdGlvbnMpXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZCh2YWwpe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVm90aW5nUG93ZXJIaXN0b3J5LmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWRkcmVzczp2YWwuYWRkcmVzc30sXG4gICAgICAgICAgICAgICAgICAgICAgICB7c29ydDp7aGVpZ2h0Oi0xfSwgbGltaXQ6NTB9XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQodmFsKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JSZWNvcmRzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGFkZHJlc3M6IHZhbC5hZGRyZXNzIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IHNvcnQ6IHtoZWlnaHQ6IC0xfSwgbGltaXQ6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMudXB0aW1lV2luZG93fVxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgVmFsaWRhdG9yUmVjb3JkcyB9IGZyb20gJy4uL3JlY29yZHMvcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBWb3RpbmdQb3dlckhpc3RvcnkgfSBmcm9tICcuLi92b3RpbmctcG93ZXIvaGlzdG9yeS5qcyc7XG5cbmV4cG9ydCBjb25zdCBWYWxpZGF0b3JzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3ZhbGlkYXRvcnMnKTtcblxuVmFsaWRhdG9ycy5oZWxwZXJzKHtcbiAgICBmaXJzdFNlZW4oKXtcbiAgICAgICAgcmV0dXJuIFZhbGlkYXRvclJlY29yZHMuZmluZE9uZSh7YWRkcmVzczp0aGlzLmFkZHJlc3N9KTtcbiAgICB9LFxuICAgIGhpc3RvcnkoKXtcbiAgICAgICAgcmV0dXJuIFZvdGluZ1Bvd2VySGlzdG9yeS5maW5kKHthZGRyZXNzOnRoaXMuYWRkcmVzc30sIHtzb3J0OntoZWlnaHQ6LTF9LCBsaW1pdDo1MH0pLmZldGNoKCk7XG4gICAgfVxufSlcbi8vIFZhbGlkYXRvcnMuaGVscGVycyh7XG4vLyAgICAgdXB0aW1lKCl7XG4vLyAgICAgICAgIC8vIGNvbnNvbGUubG9nKHRoaXMuYWRkcmVzcyk7XG4vLyAgICAgICAgIGxldCBsYXN0SHVuZHJlZCA9IFZhbGlkYXRvclJlY29yZHMuZmluZCh7YWRkcmVzczp0aGlzLmFkZHJlc3N9LCB7c29ydDp7aGVpZ2h0Oi0xfSwgbGltaXQ6MTAwfSkuZmV0Y2goKTtcbi8vICAgICAgICAgY29uc29sZS5sb2cobGFzdEh1bmRyZWQpO1xuLy8gICAgICAgICBsZXQgdXB0aW1lID0gMDtcbi8vICAgICAgICAgZm9yIChpIGluIGxhc3RIdW5kcmVkKXtcbi8vICAgICAgICAgICAgIGlmIChsYXN0SHVuZHJlZFtpXS5leGlzdHMpe1xuLy8gICAgICAgICAgICAgICAgIHVwdGltZSs9MTtcbi8vICAgICAgICAgICAgIH1cbi8vICAgICAgICAgfVxuLy8gICAgICAgICByZXR1cm4gdXB0aW1lO1xuLy8gICAgIH1cbi8vIH0pIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgVm90aW5nUG93ZXJIaXN0b3J5ID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3ZvdGluZ19wb3dlcl9oaXN0b3J5Jyk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBFdmlkZW5jZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZXZpZGVuY2VzJyk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBWYWxpZGF0b3JTZXRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3ZhbGlkYXRvcl9zZXRzJyk7XG4iLCIvLyBJbXBvcnQgbW9kdWxlcyB1c2VkIGJ5IGJvdGggY2xpZW50IGFuZCBzZXJ2ZXIgdGhyb3VnaCBhIHNpbmdsZSBpbmRleCBlbnRyeSBwb2ludFxuLy8gZS5nLiB1c2VyYWNjb3VudHMgY29uZmlndXJhdGlvbiBmaWxlLlxuIiwiaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vLi4vYXBpL2Jsb2Nrcy9ibG9ja3MuanMnO1xuaW1wb3J0IHsgUHJvcG9zYWxzIH0gZnJvbSAnLi4vLi4vYXBpL3Byb3Bvc2Fscy9wcm9wb3NhbHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9yUmVjb3JkcywgQW5hbHl0aWNzLCBNaXNzZWRCbG9ja3NTdGF0cywgTWlzc2VkQmxvY2tzLCBBdmVyYWdlRGF0YSwgQXZlcmFnZVZhbGlkYXRvckRhdGEgfSBmcm9tICcuLi8uLi9hcGkvcmVjb3Jkcy9yZWNvcmRzLmpzJztcbi8vIGltcG9ydCB7IFN0YXR1cyB9IGZyb20gJy4uLy4uL2FwaS9zdGF0dXMvc3RhdHVzLmpzJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uLy4uL2FwaS90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclNldHMgfSBmcm9tICcuLi8uLi9hcGkvdmFsaWRhdG9yLXNldHMvdmFsaWRhdG9yLXNldHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL2FwaS92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnLi4vLi4vYXBpL3ZvdGluZy1wb3dlci9oaXN0b3J5LmpzJztcbmltcG9ydCB7IEV2aWRlbmNlcyB9IGZyb20gJy4uLy4uL2FwaS9ldmlkZW5jZXMvZXZpZGVuY2VzLmpzJztcbmltcG9ydCB7IENvaW5TdGF0cyB9IGZyb20gJy4uLy4uL2FwaS9jb2luLXN0YXRzL2NvaW4tc3RhdHMuanMnO1xuaW1wb3J0IHsgQ2hhaW5TdGF0ZXMgfSBmcm9tICcuLi8uLi9hcGkvY2hhaW4vY2hhaW4uanMnO1xuXG5DaGFpblN0YXRlcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2hlaWdodDogLTF9LHt1bmlxdWU6dHJ1ZX0pO1xuXG5CbG9ja3Njb24ucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtoZWlnaHQ6IC0xfSx7dW5pcXVlOnRydWV9KTtcbkJsb2Nrc2Nvbi5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2VyQWRkcmVzczoxfSk7XG5cbkV2aWRlbmNlcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2hlaWdodDogLTF9KTtcblxuLy9Qcm9wb3NhbHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NhbElkOiAxfSwge3VuaXF1ZTp0cnVlfSk7XG5cblZhbGlkYXRvclJlY29yZHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHthZGRyZXNzOjEsaGVpZ2h0OiAtMX0sIHt1bmlxdWU6MX0pO1xuVmFsaWRhdG9yUmVjb3Jkcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2FkZHJlc3M6MSxleGlzdHM6MSwgaGVpZ2h0OiAtMX0pO1xuXG5BbmFseXRpY3MucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtoZWlnaHQ6IC0xfSwge3VuaXF1ZTp0cnVlfSlcblxuTWlzc2VkQmxvY2tzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7cHJvcG9zZXI6MSwgdm90ZXI6MSwgdXBkYXRlZEF0OiAtMX0pO1xuTWlzc2VkQmxvY2tzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7cHJvcG9zZXI6MSwgYmxvY2tIZWlnaHQ6LTF9KTtcbk1pc3NlZEJsb2Nrcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3ZvdGVyOjEsIGJsb2NrSGVpZ2h0Oi0xfSk7XG5NaXNzZWRCbG9ja3MucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHt2b3RlcjoxLCBwcm9wb3NlcjoxLCBibG9ja0hlaWdodDotMX0sIHt1bmlxdWU6dHJ1ZX0pO1xuXG5NaXNzZWRCbG9ja3NTdGF0cy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2VyOjF9KTtcbk1pc3NlZEJsb2Nrc1N0YXRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7dm90ZXI6MX0pO1xuTWlzc2VkQmxvY2tzU3RhdHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NlcjoxLCB2b3RlcjoxfSx7dW5pcXVlOnRydWV9KTtcblxuQXZlcmFnZURhdGEucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHt0eXBlOjEsIGNyZWF0ZWRBdDotMX0se3VuaXF1ZTp0cnVlfSk7XG5BdmVyYWdlVmFsaWRhdG9yRGF0YS5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2VyQWRkcmVzczoxLGNyZWF0ZWRBdDotMX0se3VuaXF1ZTp0cnVlfSk7XG4vLyBTdGF0dXMucmF3Q29sbGVjdGlvbi5jcmVhdGVJbmRleCh7fSlcblxuVHJhbnNhY3Rpb25zLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7dHhoYXNoOjF9LHt1bmlxdWU6dHJ1ZX0pO1xuVHJhbnNhY3Rpb25zLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7aGVpZ2h0Oi0xfSk7XG4vLyBUcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHthY3Rpb246MX0pO1xuVHJhbnNhY3Rpb25zLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7XCJldmVudHMuYXR0cmlidXRlcy5rZXlcIjoxfSk7XG5UcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6MX0pO1xuXG5WYWxpZGF0b3JTZXRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7YmxvY2tfaGVpZ2h0Oi0xfSk7XG5cblZhbGlkYXRvcnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHthZGRyZXNzOjF9LHt1bmlxdWU6dHJ1ZSwgcGFydGlhbEZpbHRlckV4cHJlc3Npb246IHsgYWRkcmVzczogeyAkZXhpc3RzOiB0cnVlIH0gfSB9KTtcblZhbGlkYXRvcnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtjb25zZW5zdXNfcHVia2V5OjF9LHt1bmlxdWU6dHJ1ZX0pO1xuVmFsaWRhdG9ycy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe1wicHViX2tleS52YWx1ZVwiOjF9LHt1bmlxdWU6dHJ1ZSwgcGFydGlhbEZpbHRlckV4cHJlc3Npb246IHsgXCJwdWJfa2V5LnZhbHVlXCI6IHsgJGV4aXN0czogdHJ1ZSB9IH19KTtcblxuVm90aW5nUG93ZXJIaXN0b3J5LnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7YWRkcmVzczoxLGhlaWdodDotMX0pO1xuVm90aW5nUG93ZXJIaXN0b3J5LnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7dHlwZToxfSk7XG5cbkNvaW5TdGF0cy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2xhc3RfdXBkYXRlZF9hdDotMX0se3VuaXF1ZTp0cnVlfSk7XG4iLCIvLyBJbXBvcnQgc2VydmVyIHN0YXJ0dXAgdGhyb3VnaCBhIHNpbmdsZSBpbmRleCBlbnRyeSBwb2ludFxuXG5pbXBvcnQgJy4vdXRpbC5qcyc7XG5pbXBvcnQgJy4vcmVnaXN0ZXItYXBpLmpzJztcbmltcG9ydCAnLi9jcmVhdGUtaW5kZXhlcy5qcyc7XG5cbi8vIGltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG4vLyBpbXBvcnQgeyByZW5kZXJUb05vZGVTdHJlYW0gfSBmcm9tICdyZWFjdC1kb20vc2VydmVyJztcbi8vIGltcG9ydCB7IHJlbmRlclRvU3RyaW5nIH0gZnJvbSBcInJlYWN0LWRvbS9zZXJ2ZXJcIjtcbmltcG9ydCB7IG9uUGFnZUxvYWQgfSBmcm9tICdtZXRlb3Ivc2VydmVyLXJlbmRlcic7XG4vLyBpbXBvcnQgeyBTdGF0aWNSb3V0ZXIgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbi8vIGltcG9ydCB7IFNlcnZlclN0eWxlU2hlZXQgfSBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIlxuaW1wb3J0IHsgSGVsbWV0IH0gZnJvbSAncmVhY3QtaGVsbWV0JztcblxuLy8gaW1wb3J0IEFwcCBmcm9tICcuLi8uLi91aS9BcHAuanN4Jztcblxub25QYWdlTG9hZChzaW5rID0+IHtcbiAgICAvLyBjb25zdCBjb250ZXh0ID0ge307XG4gICAgLy8gY29uc3Qgc2hlZXQgPSBuZXcgU2VydmVyU3R5bGVTaGVldCgpXG5cbiAgICAvLyBjb25zdCBodG1sID0gcmVuZGVyVG9TdHJpbmcoc2hlZXQuY29sbGVjdFN0eWxlcyhcbiAgICAvLyAgICAgPFN0YXRpY1JvdXRlciBsb2NhdGlvbj17c2luay5yZXF1ZXN0LnVybH0gY29udGV4dD17Y29udGV4dH0+XG4gICAgLy8gICAgICAgICA8QXBwIC8+XG4gICAgLy8gICAgIDwvU3RhdGljUm91dGVyPlxuICAgIC8vICAgKSk7XG5cbiAgICAvLyBzaW5rLnJlbmRlckludG9FbGVtZW50QnlJZCgnYXBwJywgaHRtbCk7XG5cbiAgICBjb25zdCBoZWxtZXQgPSBIZWxtZXQucmVuZGVyU3RhdGljKCk7XG4gICAgc2luay5hcHBlbmRUb0hlYWQoaGVsbWV0Lm1ldGEudG9TdHJpbmcoKSk7XG4gICAgc2luay5hcHBlbmRUb0hlYWQoaGVsbWV0LnRpdGxlLnRvU3RyaW5nKCkpO1xuXG4gICAgLy8gc2luay5hcHBlbmRUb0hlYWQoc2hlZXQuZ2V0U3R5bGVUYWdzKCkpO1xufSk7IiwiLy8gUmVnaXN0ZXIgeW91ciBhcGlzIGhlcmVcblxuaW1wb3J0ICcuLi8uLi9hcGkvbGVkZ2VyL3NlcnZlci9tZXRob2RzLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvY2hhaW4vc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvY2hhaW4vc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL2Jsb2Nrcy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9ibG9ja3Mvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL3ZhbGlkYXRvcnMvc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvdmFsaWRhdG9ycy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvcmVjb3Jkcy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9yZWNvcmRzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9wcm9wb3NhbHMvc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvcHJvcG9zYWxzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvZW50ZXJwcmlzZS9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9lbnRlcnByaXNlL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS92b3RpbmctcG93ZXIvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL3RyYW5zYWN0aW9ucy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS90cmFuc2FjdGlvbnMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL2RlbGVnYXRpb25zL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL2RlbGVnYXRpb25zL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9zdGF0dXMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL2FjY291bnRzL3NlcnZlci9tZXRob2RzLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvY29pbi1zdGF0cy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG4iLCJpbXBvcnQgYmVjaDMyIGZyb20gJ2JlY2gzMidcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5pbXBvcnQgKiBhcyBjaGVlcmlvIGZyb20gJ2NoZWVyaW8nO1xuXG4vLyBMb2FkIGZ1dHVyZSBmcm9tIGZpYmVyc1xudmFyIEZ1dHVyZSA9IE5wbS5yZXF1aXJlKFwiZmliZXJzL2Z1dHVyZVwiKTtcbi8vIExvYWQgZXhlY1xudmFyIGV4ZWMgPSBOcG0ucmVxdWlyZShcImNoaWxkX3Byb2Nlc3NcIikuZXhlYztcblxuZnVuY3Rpb24gdG9IZXhTdHJpbmcoYnl0ZUFycmF5KSB7XG4gICAgcmV0dXJuIGJ5dGVBcnJheS5tYXAoZnVuY3Rpb24oYnl0ZSkge1xuICAgICAgICByZXR1cm4gKCcwJyArIChieXRlICYgMHhGRikudG9TdHJpbmcoMTYpKS5zbGljZSgtMik7XG4gICAgfSkuam9pbignJylcbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgIHB1YmtleVRvQmVjaDMyOiBmdW5jdGlvbihwdWJrZXksIHByZWZpeCkge1xuICAgICAgICAvLyAnMTYyNERFNjQyMCcgaXMgZWQyNTUxOSBwdWJrZXkgcHJlZml4XG4gICAgICAgIGxldCBwdWJrZXlBbWlub1ByZWZpeCA9IEJ1ZmZlci5mcm9tKCcxNjI0REU2NDIwJywgJ2hleCcpXG4gICAgICAgIGxldCBidWZmZXIgPSBCdWZmZXIuYWxsb2MoMzcpXG4gICAgICAgIHB1YmtleUFtaW5vUHJlZml4LmNvcHkoYnVmZmVyLCAwKVxuICAgICAgICBCdWZmZXIuZnJvbShwdWJrZXkudmFsdWUsICdiYXNlNjQnKS5jb3B5KGJ1ZmZlciwgcHVia2V5QW1pbm9QcmVmaXgubGVuZ3RoKVxuICAgICAgICByZXR1cm4gYmVjaDMyLmVuY29kZShwcmVmaXgsIGJlY2gzMi50b1dvcmRzKGJ1ZmZlcikpXG4gICAgfSxcbiAgICBiZWNoMzJUb1B1YmtleTogZnVuY3Rpb24ocHVia2V5KSB7XG4gICAgICAgIC8vICcxNjI0REU2NDIwJyBpcyBlZDI1NTE5IHB1YmtleSBwcmVmaXhcbiAgICAgICAgbGV0IHB1YmtleUFtaW5vUHJlZml4ID0gQnVmZmVyLmZyb20oJzE2MjRERTY0MjAnLCAnaGV4JylcbiAgICAgICAgbGV0IGJ1ZmZlciA9IEJ1ZmZlci5mcm9tKGJlY2gzMi5mcm9tV29yZHMoYmVjaDMyLmRlY29kZShwdWJrZXkpLndvcmRzKSk7XG4gICAgICAgIHJldHVybiBidWZmZXIuc2xpY2UocHVia2V5QW1pbm9QcmVmaXgubGVuZ3RoKS50b1N0cmluZygnYmFzZTY0Jyk7XG4gICAgfSxcbiAgICBnZXREZWxlZ2F0b3I6IGZ1bmN0aW9uKG9wZXJhdG9yQWRkcil7XG4gICAgICAgIGxldCBhZGRyZXNzID0gYmVjaDMyLmRlY29kZShvcGVyYXRvckFkZHIpO1xuICAgICAgICByZXR1cm4gYmVjaDMyLmVuY29kZShNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY0FkZHIsIGFkZHJlc3Mud29yZHMpO1xuICAgIH0sXG4gICAgZ2V0S2V5YmFzZVRlYW1QaWM6IGZ1bmN0aW9uKGtleWJhc2VVcmwpe1xuICAgICAgICBsZXQgdGVhbVBhZ2UgPSBIVFRQLmdldChrZXliYXNlVXJsKTtcbiAgICAgICAgaWYgKHRlYW1QYWdlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgIGxldCBwYWdlID0gY2hlZXJpby5sb2FkKHRlYW1QYWdlLmNvbnRlbnQpO1xuICAgICAgICAgICAgcmV0dXJuIHBhZ2UoXCIua2ItbWFpbi1jYXJkIGltZ1wiKS5hdHRyKCdzcmMnKTtcbiAgICAgICAgfVxuICAgIH1cbn0pXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgVW5jb250cm9sbGVkVG9vbHRpcCB9IGZyb20gJ3JlYWN0c3RyYXAnO1xuXG5leHBvcnQgY29uc3QgRGVub21TeW1ib2wgPSAocHJvcHMpID0+IHtcbiAgICBzd2l0Y2ggKHByb3BzLmRlbm9tKXtcbiAgICBjYXNlIFwic3RlYWtcIjpcbiAgICAgICAgcmV0dXJuICfwn6WpJztcbiAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gJ/CfjYUnO1xuICAgIH1cbn1cblxuXG5leHBvcnQgY29uc3QgUHJvcG9zYWxTdGF0dXNJY29uID0gKHByb3BzKSA9PiB7XG4gICAgc3dpdGNoIChwcm9wcy5zdGF0dXMpe1xuICAgIGNhc2UgJ1Bhc3NlZCc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtY2hlY2stY2lyY2xlIHRleHQtc3VjY2Vzc1wiPjwvaT47XG4gICAgY2FzZSAnUmVqZWN0ZWQnOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLXRpbWVzLWNpcmNsZSB0ZXh0LWRhbmdlclwiPjwvaT47XG4gICAgY2FzZSAnUmVtb3ZlZCc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtdHJhc2gtYWx0IHRleHQtZGFya1wiPjwvaT5cbiAgICBjYXNlICdEZXBvc2l0UGVyaW9kJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1iYXR0ZXJ5LWhhbGYgdGV4dC13YXJuaW5nXCI+PC9pPjtcbiAgICBjYXNlICdWb3RpbmdQZXJpb2QnOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLWhhbmQtcGFwZXIgdGV4dC1pbmZvXCI+PC9pPjtcbiAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gPGk+PC9pPjtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCBWb3RlSWNvbiA9IChwcm9wcykgPT4ge1xuICAgIHN3aXRjaCAocHJvcHMudm90ZSl7XG4gICAgY2FzZSAneWVzJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1jaGVjayB0ZXh0LXN1Y2Nlc3NcIj48L2k+O1xuICAgIGNhc2UgJ25vJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS10aW1lcyB0ZXh0LWRhbmdlclwiPjwvaT47XG4gICAgY2FzZSAnYWJzdGFpbic6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtdXNlci1zbGFzaCB0ZXh0LXdhcm5pbmdcIj48L2k+O1xuICAgIGNhc2UgJ25vX3dpdGhfdmV0byc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtZXhjbGFtYXRpb24tdHJpYW5nbGUgdGV4dC1pbmZvXCI+PC9pPjtcbiAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gPGk+PC9pPjtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCBUeEljb24gPSAocHJvcHMpID0+IHtcbiAgICBpZiAocHJvcHMudmFsaWQpe1xuICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zdWNjZXNzIHRleHQtbm93cmFwXCI+PGkgY2xhc3NOYW1lPVwiZmFzIGZhLWNoZWNrLWNpcmNsZVwiPjwvaT48L3NwYW4+O1xuICAgIH1cbiAgICBlbHNle1xuICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1kYW5nZXIgdGV4dC1ub3dyYXBcIj48aSBjbGFzc05hbWU9XCJmYXMgZmEtdGltZXMtY2lyY2xlXCI+PC9pPjwvc3Bhbj47XG4gICAgfVxufVxuXG5leHBvcnQgY2xhc3MgSW5mb0ljb24gZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xuICAgIGNvbnN0cnVjdG9yKHByb3BzKSB7XG4gICAgICAgIHN1cGVyKHByb3BzKTtcbiAgICAgICAgdGhpcy5yZWYgPSBSZWFjdC5jcmVhdGVSZWYoKTtcbiAgICB9XG5cbiAgICByZW5kZXIoKSB7XG4gICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICA8aSBrZXk9J2ljb24nIGNsYXNzTmFtZT0nbWF0ZXJpYWwtaWNvbnMgaW5mby1pY29uJyByZWY9e3RoaXMucmVmfT5pbmZvPC9pPixcbiAgICAgICAgICAgIDxVbmNvbnRyb2xsZWRUb29sdGlwIGtleT0ndG9vbHRpcCcgcGxhY2VtZW50PSdyaWdodCcgdGFyZ2V0PXt0aGlzLnJlZn0+XG4gICAgICAgICAgICAgICAge3RoaXMucHJvcHMuY2hpbGRyZW4/dGhpcy5wcm9wcy5jaGlsZHJlbjp0aGlzLnByb3BzLnRvb2x0aXBUZXh0fVxuICAgICAgICAgICAgPC9VbmNvbnRyb2xsZWRUb29sdGlwPlxuICAgICAgICBdXG4gICAgfVxufSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IG51bWJybyBmcm9tICdudW1icm8nO1xuXG5hdXRvZm9ybWF0ID0gKHZhbHVlKSA9PiB7XG5cdGxldCBmb3JtYXR0ZXIgPSAnMCwwLjAwMDAnO1xuXHR2YWx1ZSA9IE1hdGgucm91bmQodmFsdWUgKiAxMDAwKSAvIDEwMDBcblx0aWYgKE1hdGgucm91bmQodmFsdWUpID09PSB2YWx1ZSlcblx0XHRmb3JtYXR0ZXIgPSAnMCwwJ1xuXHRlbHNlIGlmIChNYXRoLnJvdW5kKHZhbHVlKjEwKSA9PT0gdmFsdWUqMTApXG5cdFx0Zm9ybWF0dGVyID0gJzAsMC4wJ1xuXHRlbHNlIGlmIChNYXRoLnJvdW5kKHZhbHVlKjEwMCkgPT09IHZhbHVlKjEwMClcblx0XHRmb3JtYXR0ZXIgPSAnMCwwLjAwJ1xuXHRlbHNlIGlmIChNYXRoLnJvdW5kKHZhbHVlKjEwMDApID09PSB2YWx1ZSoxMDAwKVxuXHRcdGZvcm1hdHRlciA9ICcwLDAuMDAwJ1xuXHRyZXR1cm4gbnVtYnJvKHZhbHVlKS5mb3JtYXQoZm9ybWF0dGVyKVxufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBDb2luIHtcblx0c3RhdGljIFN0YWtpbmdEZW5vbSA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuc3Rha2luZ0Rlbm9tO1xuXHRzdGF0aWMgU3Rha2luZ0Rlbm9tUGx1cmFsID0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5zdGFraW5nRGVub21QbHVyYWwgfHwgKENvaW4uU3Rha2luZ0Rlbm9tICsgJ3MnKTtcblx0c3RhdGljIE1pbnRpbmdEZW5vbSA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMubWludGluZ0Rlbm9tO1xuXHRzdGF0aWMgU3Rha2luZ0ZyYWN0aW9uID0gTnVtYmVyKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuc3Rha2luZ0ZyYWN0aW9uKTtcblx0c3RhdGljIE1pblN0YWtlID0gMSAvIE51bWJlcihNZXRlb3Iuc2V0dGluZ3MucHVibGljLnN0YWtpbmdGcmFjdGlvbik7XG5cblx0Y29uc3RydWN0b3IoYW1vdW50LCBkZW5vbT1udWxsKSB7XG5cdFx0aWYgKHR5cGVvZiBhbW91bnQgPT09ICdvYmplY3QnKVxuXHRcdFx0KHthbW91bnQsIGRlbm9tfSA9IGFtb3VudClcblx0XHRpZiAoIWRlbm9tIHx8IGRlbm9tLnRvTG93ZXJDYXNlKCkgPT09IENvaW4uTWludGluZ0Rlbm9tLnRvTG93ZXJDYXNlKCkpIHtcblx0XHRcdHRoaXMuX2Ftb3VudCA9IE51bWJlcihhbW91bnQpO1xuXHRcdH0gZWxzZSBpZiAoZGVub20udG9Mb3dlckNhc2UoKSA9PT0gQ29pbi5TdGFraW5nRGVub20udG9Mb3dlckNhc2UoKSkge1xuXHRcdFx0dGhpcy5fYW1vdW50ID0gTnVtYmVyKGFtb3VudCkgKiBDb2luLlN0YWtpbmdGcmFjdGlvbjtcblx0XHR9XG5cdFx0ZWxzZSB7XG5cdFx0XHR0aHJvdyBFcnJvcihgdW5zdXBwb3J0ZWQgZGVub20gJHtkZW5vbX1gKTtcblx0XHR9XG5cdH1cblxuXHRnZXQgYW1vdW50ICgpIHtcblx0XHRyZXR1cm4gdGhpcy5fYW1vdW50O1xuXHR9XG5cblx0Z2V0IHN0YWtpbmdBbW91bnQgKCkge1xuXHRcdHJldHVybiB0aGlzLl9hbW91bnQgLyBDb2luLlN0YWtpbmdGcmFjdGlvbjtcblx0fVxuXG5cdHRvU3RyaW5nIChwcmVjaXNpb24pIHtcblx0XHQvLyBkZWZhdWx0IHRvIGRpc3BsYXkgaW4gbWludCBkZW5vbSBpZiBpdCBoYXMgbW9yZSB0aGFuIDQgZGVjaW1hbCBwbGFjZXNcblx0XHRsZXQgbWluU3Rha2UgPSBDb2luLlN0YWtpbmdGcmFjdGlvbi8ocHJlY2lzaW9uP01hdGgucG93KDEwLCBwcmVjaXNpb24pOjEwMDAwKVxuXHRcdGlmICh0aGlzLmFtb3VudCA8IG1pblN0YWtlKSB7XG5cdFx0XHRyZXR1cm4gYCR7bnVtYnJvKHRoaXMuYW1vdW50KS5mb3JtYXQoJzAsMCcpfSAke0NvaW4uTWludGluZ0Rlbm9tfWA7XG5cdFx0fSBlbHNlIHtcblx0XHRcdHJldHVybiBgJHtwcmVjaXNpb24/bnVtYnJvKHRoaXMuc3Rha2luZ0Ftb3VudCkuZm9ybWF0KCcwLDAuJyArICcwJy5yZXBlYXQocHJlY2lzaW9uKSk6YXV0b2Zvcm1hdCh0aGlzLnN0YWtpbmdBbW91bnQpfSAke0NvaW4uU3Rha2luZ0Rlbm9tfWBcblx0XHR9XG5cdH1cblxuXHRtaW50U3RyaW5nIChmb3JtYXR0ZXIpIHtcblx0XHRsZXQgYW1vdW50ID0gdGhpcy5hbW91bnRcblx0XHRpZiAoZm9ybWF0dGVyKSB7XG5cdFx0XHRhbW91bnQgPSBudW1icm8oYW1vdW50KS5mb3JtYXQoZm9ybWF0dGVyKVxuXHRcdH1cblx0XHRyZXR1cm4gYCR7YW1vdW50fSAke0NvaW4uTWludGluZ0Rlbm9tfWA7XG5cdH1cblxuXHRzdGFrZVN0cmluZyAoZm9ybWF0dGVyKSB7XG5cdFx0bGV0IGFtb3VudCA9IHRoaXMuc3Rha2luZ0Ftb3VudFxuXHRcdGlmIChmb3JtYXR0ZXIpIHtcblx0XHRcdGFtb3VudCA9IG51bWJybyhhbW91bnQpLmZvcm1hdChmb3JtYXR0ZXIpXG5cdFx0fVxuXHRcdHJldHVybiBgJHthbW91bnR9ICR7Q29pbi5TdGFraW5nRGVub219YDtcblx0fVxufSIsIi8vIFNlcnZlciBlbnRyeSBwb2ludCwgaW1wb3J0cyBhbGwgc2VydmVyIGNvZGVcblxuaW1wb3J0ICcvaW1wb3J0cy9zdGFydHVwL3NlcnZlcic7XG5pbXBvcnQgJy9pbXBvcnRzL3N0YXJ0dXAvYm90aCc7XG4vLyBpbXBvcnQgbW9tZW50IGZyb20gJ21vbWVudCc7XG4vLyBpbXBvcnQgJy9pbXBvcnRzL2FwaS9ibG9ja3MvYmxvY2tzLmpzJztcblxuU1lOQ0lORyA9IGZhbHNlO1xuQ09VTlRNSVNTRURCTE9DS1MgPSBmYWxzZTtcbkNPVU5UTUlTU0VEQkxPQ0tTU1RBVFMgPSBmYWxzZTtcblJQQyA9IE1ldGVvci5zZXR0aW5ncy5yZW1vdGUucnBjO1xuTENEID0gTWV0ZW9yLnNldHRpbmdzLnJlbW90ZS5sY2Q7XG50aW1lckJsb2NrcyA9IDA7XG50aW1lckNoYWluID0gMDtcbnRpbWVyQ29uc2Vuc3VzID0gMDtcbnRpbWVyUHJvcG9zYWwgPSAwO1xudGltZXJQcm9wb3NhbHNSZXN1bHRzID0gMDtcbnRpbWVyTWlzc2VkQmxvY2sgPSAwO1xudGltZXJEZWxlZ2F0aW9uID0gMDtcbnRpbWVyQWdncmVnYXRlID0gMDtcblxuY29uc3QgREVGQVVMVFNFVFRJTkdTID0gJy9kZWZhdWx0X3NldHRpbmdzLmpzb24nO1xuXG51cGRhdGVDaGFpblN0YXR1cyA9ICgpID0+IHtcbiAgICBNZXRlb3IuY2FsbCgnY2hhaW4udXBkYXRlU3RhdHVzJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidXBkYXRlU3RhdHVzOiBcIitlcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidXBkYXRlU3RhdHVzOiBcIityZXN1bHQpO1xuICAgICAgICB9XG4gICAgfSlcbn1cblxudXBkYXRlQmxvY2sgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5ibG9ja3NVcGRhdGUnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ1cGRhdGVCbG9ja3M6IFwiK2Vycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ1cGRhdGVCbG9ja3M6IFwiK3Jlc3VsdCk7XG4gICAgICAgIH1cbiAgICB9KVxufVxuXG5nZXRDb25zZW5zdXNTdGF0ZSA9ICgpID0+IHtcbiAgICBNZXRlb3IuY2FsbCgnY2hhaW4uZ2V0Q29uc2Vuc3VzU3RhdGUnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgY29uc2Vuc3VzOiBcIitlcnJvcilcbiAgICAgICAgfVxuICAgIH0pXG59XG5cbmdldFB1cmNoYXNlT3JkZXJzID0gKCkgPT4ge1xuICAgTWV0ZW9yLmNhbGwoJ2VudGVycHJpc2UuZ2V0UHVyY2hhc2VPcmRlcnMnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IHBvOiBcIisgZXJyb3IpO1xuICAgICAgIH1cbiAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgcG86IFwiK3Jlc3VsdCk7XG4gICAgICAgfVxuICAgfSk7XG59XG5cbmdldFByb3Bvc2FscyA9ICgpID0+IHtcbiAgIE1ldGVvci5jYWxsKCdwcm9wb3NhbHMuZ2V0UHJvcG9zYWxzJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBwcm9wb3NhbDogXCIrIGVycm9yKTtcbiAgICAgICB9XG4gICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IHByb3Bvc2FsOiBcIityZXN1bHQpO1xuICAgICAgIH1cbiAgIH0pO1xufVxuXG5nZXRQcm9wb3NhbHNSZXN1bHRzID0gKCkgPT4ge1xuICAgTWV0ZW9yLmNhbGwoJ3Byb3Bvc2Fscy5nZXRQcm9wb3NhbFJlc3VsdHMnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IHByb3Bvc2FscyByZXN1bHQ6IFwiK2Vycm9yKTtcbiAgICAgICB9XG4gICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IHByb3Bvc2FscyByZXN1bHQ6IFwiK3Jlc3VsdCk7XG4gICAgICAgfVxuICAgfSk7XG59XG5cbnVwZGF0ZU1pc3NlZEJsb2NrcyA9ICgpID0+IHtcbiAgICBNZXRlb3IuY2FsbCgnVmFsaWRhdG9yUmVjb3Jkcy5jYWxjdWxhdGVNaXNzZWRCbG9ja3MnLCAoZXJyb3IsIHJlc3VsdCkgPT57XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIm1pc3NlZCBibG9ja3MgZXJyb3I6IFwiKyBlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwibWlzc2VkIGJsb2NrcyBvazpcIiArIHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICB9KTtcbi8qXG4gICAgTWV0ZW9yLmNhbGwoJ1ZhbGlkYXRvclJlY29yZHMuY2FsY3VsYXRlTWlzc2VkQmxvY2tzU3RhdHMnLCAoZXJyb3IsIHJlc3VsdCkgPT57XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIm1pc3NlZCBibG9ja3Mgc3RhdHMgZXJyb3I6IFwiKyBlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwibWlzc2VkIGJsb2NrcyBzdGF0cyBvazpcIiArIHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICB9KTtcbiovXG59XG5cbmdldERlbGVnYXRpb25zID0gKCkgPT4ge1xuICAgIE1ldGVvci5jYWxsKCdkZWxlZ2F0aW9ucy5nZXREZWxlZ2F0aW9ucycsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBkZWxlZ2F0aW9ucyBlcnJvcjogXCIrIGVycm9yKVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBkZWxlZ2F0aW9ucyBvazogXCIrIHJlc3VsdClcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG5hZ2dyZWdhdGVNaW51dGVseSA9ICgpID0+e1xuICAgIC8vIGRvaW5nIHNvbWV0aGluZyBldmVyeSBtaW5cbiAgICBNZXRlb3IuY2FsbCgnQW5hbHl0aWNzLmFnZ3JlZ2F0ZUJsb2NrVGltZUFuZFZvdGluZ1Bvd2VyJywgXCJtXCIsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSBtaW51dGVseSBibG9jayB0aW1lIGVycm9yOiBcIitlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgbWludXRlbHkgYmxvY2sgdGltZSBvazogXCIrcmVzdWx0KVxuICAgICAgICB9XG4gICAgfSk7XG5cbiAgICBNZXRlb3IuY2FsbCgnY29pblN0YXRzLmdldENvaW5TdGF0cycsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBjb2luIHN0YXRzIGVycm9yOiBcIitlcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IGNvaW4gc3RhdHMgb2s6IFwiK3Jlc3VsdClcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG5hZ2dyZWdhdGVIb3VybHkgPSAoKSA9PntcbiAgICAvLyBkb2luZyBzb21ldGhpbmcgZXZlcnkgaG91clxuICAgIE1ldGVvci5jYWxsKCdBbmFseXRpY3MuYWdncmVnYXRlQmxvY2tUaW1lQW5kVm90aW5nUG93ZXInLCBcImhcIiwgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRlIGhvdXJseSBibG9jayB0aW1lIGVycm9yOiBcIitlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgaG91cmx5IGJsb2NrIHRpbWUgb2s6IFwiK3Jlc3VsdClcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG5hZ2dyZWdhdGVEYWlseSA9ICgpID0+e1xuICAgIC8vIGRvaW5nIHNvbXRoaW5nIGV2ZXJ5IGRheVxuICAgIE1ldGVvci5jYWxsKCdBbmFseXRpY3MuYWdncmVnYXRlQmxvY2tUaW1lQW5kVm90aW5nUG93ZXInLCBcImRcIiwgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRlIGRhaWx5IGJsb2NrIHRpbWUgZXJyb3I6IFwiK2Vycm9yKVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSBkYWlseSBibG9jayB0aW1lIG9rOiBcIityZXN1bHQpXG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIE1ldGVvci5jYWxsKCdBbmFseXRpY3MuYWdncmVnYXRlVmFsaWRhdG9yRGFpbHlCbG9ja1RpbWUnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgdmFsaWRhdG9ycyBibG9jayB0aW1lIGVycm9yOlwiKyBlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRlIHZhbGlkYXRvcnMgYmxvY2sgdGltZSBvazpcIisgcmVzdWx0KTtcbiAgICAgICAgfVxuICAgIH0pXG59XG5cblxuXG5NZXRlb3Iuc3RhcnR1cChmdW5jdGlvbigpe1xuICAgIGlmIChNZXRlb3IuaXNEZXZlbG9wbWVudCl7XG4gICAgICAgIHByb2Nlc3MuZW52Lk5PREVfVExTX1JFSkVDVF9VTkFVVEhPUklaRUQgPSAwO1xuICAgICAgICBpbXBvcnQgREVGQVVMVFNFVFRJTkdTSlNPTiBmcm9tICcuLi9kZWZhdWx0X3NldHRpbmdzLmpzb24nXG4gICAgICAgIE9iamVjdC5rZXlzKERFRkFVTFRTRVRUSU5HU0pTT04pLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgICAgICAgaWYgKE1ldGVvci5zZXR0aW5nc1trZXldID09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgQ0hFQ0sgU0VUVElOR1MgSlNPTjogJHtrZXl9IGlzIG1pc3NpbmcgZnJvbSBzZXR0aW5nc2ApXG4gICAgICAgICAgICAgICAgTWV0ZW9yLnNldHRpbmdzW2tleV0gPSB7fTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIE9iamVjdC5rZXlzKERFRkFVTFRTRVRUSU5HU0pTT05ba2V5XSkuZm9yRWFjaCgocGFyYW0pID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoTWV0ZW9yLnNldHRpbmdzW2tleV1bcGFyYW1dID09IHVuZGVmaW5lZCl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgQ0hFQ0sgU0VUVElOR1MgSlNPTjogJHtrZXl9LiR7cGFyYW19IGlzIG1pc3NpbmcgZnJvbSBzZXR0aW5nc2ApXG4gICAgICAgICAgICAgICAgICAgIE1ldGVvci5zZXR0aW5nc1trZXldW3BhcmFtXSA9IERFRkFVTFRTRVRUSU5HU0pTT05ba2V5XVtwYXJhbV1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuICAgICAgICB9KVxuICAgIH1cblxuICAgIE1ldGVvci5jYWxsKCdjaGFpbi5nZW5lc2lzJywgKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgIGlmIChNZXRlb3Iuc2V0dGluZ3MuZGVidWcuc3RhcnRUaW1lcil7XG4gICAgICAgICAgICAgICAgdGltZXJDb25zZW5zdXMgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAgICAgZ2V0Q29uc2Vuc3VzU3RhdGUoKTtcbiAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLmNvbnNlbnN1c0ludGVydmFsKTtcblxuICAgICAgICAgICAgICAgIHRpbWVyQmxvY2tzID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZUJsb2NrKCk7XG4gICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5ibG9ja0ludGVydmFsKTtcblxuICAgICAgICAgICAgICAgIHRpbWVyQ2hhaW4gPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlQ2hhaW5TdGF0dXMoKTtcbiAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLnN0YXR1c0ludGVydmFsKTtcblxuICAgICAgICAgICAgICAgIHRpbWVyUHVyY2hhc2VPcmRlciA9IE1ldGVvci5zZXRJbnRlcnZhbCggZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgIGdldFB1cmNoYXNlT3JkZXJzKCk7XG4gICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5wcm9wb3NhbEludGVydmFsKTtcblxuICAgICAgICAgICAgICAgdGltZXJQcm9wb3NhbCA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgICAgIGdldFByb3Bvc2FscygpO1xuICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5wcm9wb3NhbEludGVydmFsKTtcblxuICAgICAgICAgICAgICAgdGltZXJQcm9wb3NhbHNSZXN1bHRzID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgZ2V0UHJvcG9zYWxzUmVzdWx0cygpO1xuICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5wcm9wb3NhbEludGVydmFsKTtcblxuICAgICAgICAgICAgICAgIHRpbWVyTWlzc2VkQmxvY2sgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlTWlzc2VkQmxvY2tzKCk7XG4gICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5taXNzZWRCbG9ja3NJbnRlcnZhbCk7XG5cbiAgICAgICAgICAgICAgICB0aW1lckRlbGVnYXRpb24gPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAgICAgZ2V0RGVsZWdhdGlvbnMoKTtcbiAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLmRlbGVnYXRpb25JbnRlcnZhbCk7XG5cbiAgICAgICAgICAgICAgICB0aW1lckFnZ3JlZ2F0ZSA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgICAgICBsZXQgbm93ID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKChub3cuZ2V0VVRDU2Vjb25kcygpID09IDApKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFnZ3JlZ2F0ZU1pbnV0ZWx5KCk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBpZiAoKG5vdy5nZXRVVENNaW51dGVzKCkgPT0gMCkgJiYgKG5vdy5nZXRVVENTZWNvbmRzKCkgPT0gMCkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgYWdncmVnYXRlSG91cmx5KCk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBpZiAoKG5vdy5nZXRVVENIb3VycygpID09IDApICYmIChub3cuZ2V0VVRDTWludXRlcygpID09IDApICYmIChub3cuZ2V0VVRDU2Vjb25kcygpID09IDApKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFnZ3JlZ2F0ZURhaWx5KCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LCAxMDAwKVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSlcblxufSk7XG4iXX0=
