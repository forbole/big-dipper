var require = meteorInstall({"imports":{"api":{"accounts":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/accounts/server/methods.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Validators;
module.link("/imports/api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);

const fetchFromUrl = url => {
  try {
    let res = HTTP.get(LCD + url);

    if (res.statusCode == 200) {
      return res;
    }

    ;
  } catch (e) {
    console.log(e);
  }
};

Meteor.methods({
  'accounts.getAccountDetail': function (address) {
    this.unblock();
    let url = LCD + '/auth/accounts/' + address;

    try {
      let available = HTTP.get(url);

      if (available.statusCode == 200) {
        let response = JSON.parse(available.content).result;
        let account;
        if (response.type === 'cosmos-sdk/Account') account = response.value;else if (response.type === 'cosmos-sdk/DelayedVestingAccount' || response.type === 'cosmos-sdk/ContinuousVestingAccount') account = response.value.BaseVestingAccount.BaseAccount;
        if (account && account.account_number != null) return account;
        return null;
      }
    } catch (e) {
      console.log(e);
    }
  },
  'accounts.getBalance': function (address) {
    this.unblock();
    let balance = {}; // get available atoms

    let url = LCD + '/bank/balances/' + address;

    try {
      let available = HTTP.get(url);

      if (available.statusCode == 200) {
        // console.log(JSON.parse(available.content))
        balance.available = JSON.parse(available.content).result;
        if (balance.available && balance.available.length > 0) balance.available = balance.available[0];
      }
    } catch (e) {
      console.log(e);
    } // get delegated amnounts


    url = LCD + '/staking/delegators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        balance.delegations = JSON.parse(delegations.content).result;
      }
    } catch (e) {
      console.log(e);
    } // get unbonding


    url = LCD + '/staking/delegators/' + address + '/unbonding_delegations';

    try {
      let unbonding = HTTP.get(url);

      if (unbonding.statusCode == 200) {
        balance.unbonding = JSON.parse(unbonding.content).result;
      }
    } catch (e) {
      console.log(e);
    } // get rewards


    url = LCD + '/distribution/delegators/' + address + '/rewards';

    try {
      let rewards = HTTP.get(url);

      if (rewards.statusCode == 200) {
        balance.rewards = JSON.parse(rewards.content).result.total;
      }
    } catch (e) {
      console.log(e);
    } // get commission


    let validator = Validators.findOne({
      $or: [{
        operator_address: address
      }, {
        delegator_address: address
      }, {
        address: address
      }]
    });

    if (validator) {
      let url = LCD + '/distribution/validators/' + validator.operator_address;
      balance.operator_address = validator.operator_address;

      try {
        let rewards = HTTP.get(url);

        if (rewards.statusCode == 200) {
          let content = JSON.parse(rewards.content).result;
          if (content.val_commission && content.val_commission.length > 0) balance.commission = content.val_commission[0];
        }
      } catch (e) {
        console.log(e);
      }
    }

    return balance;
  },

  'accounts.getDelegation'(address, validator) {
    let url = "/staking/delegators/".concat(address, "/delegations/").concat(validator);
    let delegations = fetchFromUrl(url);
    delegations = delegations && delegations.data.result;
    if (delegations && delegations.shares) delegations.shares = parseFloat(delegations.shares);
    url = "/staking/redelegations?delegator=".concat(address, "&validator_to=").concat(validator);
    let relegations = fetchFromUrl(url);
    relegations = relegations && relegations.data.result;
    let completionTime;

    if (relegations) {
      relegations.forEach(relegation => {
        let entries = relegation.entries;
        let time = new Date(entries[entries.length - 1].completion_time);
        if (!completionTime || time > completionTime) completionTime = time;
      });
      delegations.redelegationCompletionTime = completionTime;
    }

    url = "/staking/delegators/".concat(address, "/unbonding_delegations/").concat(validator);
    let undelegations = fetchFromUrl(url);
    undelegations = undelegations && undelegations.data.result;

    if (undelegations) {
      delegations.unbonding = undelegations.entries.length;
      delegations.unbondingCompletionTime = undelegations.entries[0].completion_time;
    }

    return delegations;
  },

  'accounts.getAllDelegations'(address) {
    let url = LCD + '/staking/delegators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        delegations = JSON.parse(delegations.content).result;

        if (delegations && delegations.length > 0) {
          delegations.forEach((delegation, i) => {
            if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
          });
        }

        return delegations;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  },

  'accounts.getAllUnbondings'(address) {
    let url = LCD + '/staking/delegators/' + address + '/unbonding_delegations';

    try {
      let unbondings = HTTP.get(url);

      if (unbondings.statusCode == 200) {
        unbondings = JSON.parse(unbondings.content).result;
        return unbondings;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  },

  'accounts.getAllRedelegations'(address, validator) {
    let url = "/staking/redelegations?delegator=".concat(address, "&validator_from=").concat(validator);
    let result = fetchFromUrl(url);

    if (result && result.data) {
      let redelegations = {};
      result.data.forEach(redelegation => {
        let entries = redelegation.entries;
        redelegations[redelegation.validator_dst_address] = {
          count: entries.length,
          completionTime: entries[0].completion_time
        };
      });
      return redelegations;
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"blocks":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/server/methods.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Promise;
module.link("meteor/promise", {
  Promise(v) {
    Promise = v;
  }

}, 2);
let Blockscon;
module.link("/imports/api/blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 3);
let Chain;
module.link("/imports/api/chain/chain.js", {
  Chain(v) {
    Chain = v;
  }

}, 4);
let ValidatorSets;
module.link("/imports/api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 5);
let Validators;
module.link("/imports/api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 6);
let ValidatorRecords, Analytics, VPDistributions;
module.link("/imports/api/records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  VPDistributions(v) {
    VPDistributions = v;
  }

}, 7);
let VotingPowerHistory;
module.link("/imports/api/voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 8);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 9);
let Evidences;
module.link("../../evidences/evidences.js", {
  Evidences(v) {
    Evidences = v;
  }

}, 10);
let sha256;
module.link("js-sha256", {
  sha256(v) {
    sha256 = v;
  }

}, 11);
let getAddress;
module.link("tendermint/lib/pubkey", {
  getAddress(v) {
    getAddress = v;
  }

}, 12);
let cheerio;
module.link("cheerio", {
  "*"(v) {
    cheerio = v;
  }

}, 13);

// import Block from '../../../ui/components/Block';
// getValidatorVotingPower = (validators, address) => {
//     for (v in validators){
//         if (validators[v].address == address){
//             return parseInt(validators[v].voting_power);
//         }
//     }
// }
getRemovedValidators = (prevValidators, validators) => {
  // let removeValidators = [];
  for (p in prevValidators) {
    for (v in validators) {
      if (prevValidators[p].address == validators[v].address) {
        prevValidators.splice(p, 1);
      }
    }
  }

  return prevValidators;
};

getValidatorProfileUrl = identity => {
  if (identity.length == 16) {
    let response = HTTP.get("https://keybase.io/_/api/1.0/user/lookup.json?key_suffix=".concat(identity, "&fields=pictures"));

    if (response.statusCode == 200) {
      let them = response.data.them;
      return them && them.length && them[0].pictures && them[0].pictures.primary && them[0].pictures.primary.url;
    } else {
      console.log(JSON.stringify(response));
    }
  } else if (identity.indexOf("keybase.io/team/") > 0) {
    let teamPage = HTTP.get(identity);

    if (teamPage.statusCode == 200) {
      let page = cheerio.load(teamPage.content);
      return page(".kb-main-card img").attr('src');
    } else {
      console.log(JSON.stringify(teamPage));
    }
  }
}; // var filtered = [1, 2, 3, 4, 5].filter(notContainedIn([1, 2, 3, 5]));
// console.log(filtered); // [4]


Meteor.methods({
  'blocks.averageBlockTime'(address) {
    let blocks = Blockscon.find({
      proposerAddress: address
    }).fetch();
    let heights = blocks.map((block, i) => {
      return block.height;
    });
    let blocksStats = Analytics.find({
      height: {
        $in: heights
      }
    }).fetch(); // console.log(blocksStats);

    let totalBlockDiff = 0;

    for (b in blocksStats) {
      totalBlockDiff += blocksStats[b].timeDiff;
    }

    return totalBlockDiff / heights.length;
  },

  'blocks.findUpTime'(address) {
    let collection = ValidatorRecords.rawCollection(); // let aggregateQuery = Meteor.wrapAsync(collection.aggregate, collection);

    var pipeline = [{
      $match: {
        "address": address
      }
    }, // {$project:{address:1,height:1,exists:1}},
    {
      $sort: {
        "height": -1
      }
    }, {
      $limit: Meteor.settings.public.uptimeWindow - 1
    }, {
      $unwind: "$_id"
    }, {
      $group: {
        "_id": "$address",
        "uptime": {
          "$sum": {
            $cond: [{
              $eq: ['$exists', true]
            }, 1, 0]
          }
        }
      }
    }]; // let result = aggregateQuery(pipeline, { cursor: {} });

    return Promise.await(collection.aggregate(pipeline).toArray()); // return .aggregate()
  },

  'blocks.getLatestHeight': function () {
    this.unblock();
    let url = RPC + '/status';

    try {
      let response = HTTP.get(url);
      let status = JSON.parse(response.content);
      return status.result.sync_info.latest_block_height;
    } catch (e) {
      return 0;
    }
  },
  'blocks.getCurrentHeight': function () {
    this.unblock();
    let currHeight = Blockscon.find({}, {
      sort: {
        height: -1
      },
      limit: 1
    }).fetch(); // console.log("currentHeight:"+currHeight);

    let startHeight = Meteor.settings.params.startHeight;

    if (currHeight && currHeight.length == 1) {
      let height = currHeight[0].height;
      if (height > startHeight) return height;
    }

    return startHeight;
  },
  'blocks.blocksUpdate': function () {
    if (SYNCING) return "Syncing...";else console.log("start to sync"); // Meteor.clearInterval(Meteor.timerHandle);
    // get the latest height

    let until = Meteor.call('blocks.getLatestHeight'); // console.log(until);
    // get the current height in db

    let curr = Meteor.call('blocks.getCurrentHeight');
    console.log(curr); // loop if there's update in db

    if (until > curr) {
      SYNCING = true;
      let validatorSet = {}; // get latest validator candidate information

      url = LCD + '/staking/validators';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      url = LCD + '/staking/validators?status=unbonding';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      url = LCD + '/staking/validators?status=unbonded';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      let totalValidators = Object.keys(validatorSet).length;
      console.log("all validators: " + totalValidators);

      for (let height = curr + 1; height <= until; height++) {
        let startBlockTime = new Date(); // add timeout here? and outside this loop (for catched up and keep fetching)?

        this.unblock();
        let url = RPC + '/block?height=' + height;
        let analyticsData = {};
        console.log(url);

        try {
          const bulkValidators = Validators.rawCollection().initializeUnorderedBulkOp();
          const bulkValidatorRecords = ValidatorRecords.rawCollection().initializeUnorderedBulkOp();
          const bulkVPHistory = VotingPowerHistory.rawCollection().initializeUnorderedBulkOp();
          const bulkTransations = Transactions.rawCollection().initializeUnorderedBulkOp();
          let startGetHeightTime = new Date();
          let response = HTTP.get(url);

          if (response.statusCode == 200) {
            let block = JSON.parse(response.content);
            block = block.result; // store height, hash, numtransaction and time in db

            let blockData = {};
            blockData.height = height;
            blockData.hash = block.block_meta.block_id.hash;
            blockData.transNum = block.block_meta.header.num_txs;
            blockData.time = new Date(block.block.header.time);
            blockData.lastBlockHash = block.block.header.last_block_id.hash;
            blockData.proposerAddress = block.block.header.proposer_address;
            blockData.validators = [];
            let precommits = block.block.last_commit.precommits;

            if (precommits != null) {
              // console.log(precommits.length);
              for (let i = 0; i < precommits.length; i++) {
                if (precommits[i] != null) {
                  blockData.validators.push(precommits[i].validator_address);
                }
              }

              analyticsData.precommits = precommits.length; // record for analytics
              // PrecommitRecords.insert({height:height, precommits:precommits.length});
            } // save txs in database


            if (block.block.data.txs && block.block.data.txs.length > 0) {
              for (t in block.block.data.txs) {
                Meteor.call('Transactions.index', sha256(Buffer.from(block.block.data.txs[t], 'base64')), blockData.time, (err, result) => {
                  if (err) {
                    console.log(err);
                  }
                });
              }
            } // save double sign evidences


            if (block.block.evidence.evidence) {
              Evidences.insert({
                height: height,
                evidence: block.block.evidence.evidence
              });
            }

            blockData.precommitsCount = blockData.validators.length;
            analyticsData.height = height;
            let endGetHeightTime = new Date();
            console.log("Get height time: " + (endGetHeightTime - startGetHeightTime) / 1000 + "seconds.");
            let startGetValidatorsTime = new Date(); // update chain status

            url = RPC + '/validators?height=' + height;
            response = HTTP.get(url);
            console.log(url);
            let validators = JSON.parse(response.content);
            validators.result.block_height = parseInt(validators.result.block_height);
            ValidatorSets.insert(validators.result);
            blockData.validatorsCount = validators.result.validators.length;
            let startBlockInsertTime = new Date();
            Blockscon.insert(blockData);
            let endBlockInsertTime = new Date();
            console.log("Block insert time: " + (endBlockInsertTime - startBlockInsertTime) / 1000 + "seconds."); // store valdiators exist records

            let existingValidators = Validators.find({
              address: {
                $exists: true
              }
            }).fetch();

            if (height > 1) {
              // record precommits and calculate uptime
              // only record from block 2
              for (i in validators.result.validators) {
                let address = validators.result.validators[i].address;
                let record = {
                  height: height,
                  address: address,
                  exists: false,
                  voting_power: parseInt(validators.result.validators[i].voting_power) //getValidatorVotingPower(existingValidators, address)

                };

                for (j in precommits) {
                  if (precommits[j] != null) {
                    if (address == precommits[j].validator_address) {
                      record.exists = true;
                      precommits.splice(j, 1);
                      break;
                    }
                  }
                } // calculate the uptime based on the records stored in previous blocks
                // only do this every 15 blocks ~


                if (height % 15 == 0) {
                  // let startAggTime = new Date();
                  let numBlocks = Meteor.call('blocks.findUpTime', address);
                  let uptime = 0; // let endAggTime = new Date();
                  // console.log("Get aggregated uptime for "+existingValidators[i].address+": "+((endAggTime-startAggTime)/1000)+"seconds.");

                  if (numBlocks[0] != null && numBlocks[0].uptime != null) {
                    uptime = numBlocks[0].uptime;
                  }

                  let base = Meteor.settings.public.uptimeWindow;

                  if (height < base) {
                    base = height;
                  }

                  if (record.exists) {
                    if (uptime < base) {
                      uptime++;
                    }

                    uptime = uptime / base * 100;
                    bulkValidators.find({
                      address: address
                    }).upsert().updateOne({
                      $set: {
                        uptime: uptime,
                        lastSeen: blockData.time
                      }
                    });
                  } else {
                    uptime = uptime / base * 100;
                    bulkValidators.find({
                      address: address
                    }).upsert().updateOne({
                      $set: {
                        uptime: uptime
                      }
                    });
                  }
                }

                bulkValidatorRecords.insert(record); // ValidatorRecords.update({height:height,address:record.address},record);
              }
            }

            let chainStatus = Chain.findOne({
              chainId: block.block_meta.header.chain_id
            });
            let lastSyncedTime = chainStatus ? chainStatus.lastSyncedTime : 0;
            let timeDiff;
            let blockTime = Meteor.settings.params.defaultBlockTime;

            if (lastSyncedTime) {
              let dateLatest = blockData.time;
              let dateLast = new Date(lastSyncedTime);
              timeDiff = Math.abs(dateLatest.getTime() - dateLast.getTime());
              blockTime = (chainStatus.blockTime * (blockData.height - 1) + timeDiff) / blockData.height;
            }

            let endGetValidatorsTime = new Date();
            console.log("Get height validators time: " + (endGetValidatorsTime - startGetValidatorsTime) / 1000 + "seconds.");
            Chain.update({
              chainId: block.block_meta.header.chain_id
            }, {
              $set: {
                lastSyncedTime: blockData.time,
                blockTime: blockTime
              }
            });
            analyticsData.averageBlockTime = blockTime;
            analyticsData.timeDiff = timeDiff;
            analyticsData.time = blockData.time; // initialize validator data at first block
            // if (height == 1){
            //     Validators.remove({});
            // }

            analyticsData.voting_power = 0;
            let startFindValidatorsNameTime = new Date();

            if (validators.result) {
              // validators are all the validators in the current height
              console.log("validatorSet size: " + validators.result.validators.length);

              for (v in validators.result.validators) {
                // Validators.insert(validators.result.validators[v]);
                let validator = validators.result.validators[v];
                validator.voting_power = parseInt(validator.voting_power);
                validator.proposer_priority = parseInt(validator.proposer_priority);
                let valExist = Validators.findOne({
                  "pub_key.value": validator.pub_key.value
                });

                if (!valExist) {
                  console.log("validator pub_key ".concat(validator.address, " ").concat(validator.pub_key.value, " not in db")); // let command = Meteor.settings.bin.gaiadebug+" pubkey "+validator.pub_key.value;
                  // console.log(command);
                  // let tempVal = validator;

                  validator.address = getAddress(validator.pub_key);
                  validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
                  validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
                  validator.consensus_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixConsPub);
                  let validatorData = validatorSet[validator.consensus_pubkey];

                  if (validatorData) {
                    if (validatorData.description.identity) validator.profile_url = getValidatorProfileUrl(validatorData.description.identity);
                    validator.operator_address = validatorData.operator_address;
                    validator.delegator_address = Meteor.call('getDelegator', validatorData.operator_address);
                    validator.jailed = validatorData.jailed;
                    validator.status = validatorData.status;
                    validator.min_self_delegation = validatorData.min_self_delegation;
                    validator.tokens = validatorData.tokens;
                    validator.delegator_shares = validatorData.delegator_shares;
                    validator.description = validatorData.description;
                    validator.bond_height = validatorData.bond_height;
                    validator.bond_intra_tx_counter = validatorData.bond_intra_tx_counter;
                    validator.unbonding_height = validatorData.unbonding_height;
                    validator.unbonding_time = validatorData.unbonding_time;
                    validator.commission = validatorData.commission;
                    validator.self_delegation = validator.delegator_shares; // validator.removed = false,
                    // validator.removedAt = 0
                    // validatorSet.splice(val, 1);
                  } else {
                    console.log('no con pub key?');
                  } // bulkValidators.insert(validator);


                  bulkValidators.find({
                    consensus_pubkey: validator.consensus_pubkey
                  }).upsert().updateOne({
                    $set: validator
                  }); // console.log("validator first appears: "+bulkValidators.length);

                  bulkVPHistory.insert({
                    address: validator.address,
                    prev_voting_power: 0,
                    voting_power: validator.voting_power,
                    type: 'add',
                    height: blockData.height,
                    block_time: blockData.time
                  }); // Meteor.call('runCode', command, function(error, result){
                  // validator.address = result.match(/\s[0-9A-F]{40}$/igm);
                  // validator.address = validator.address[0].trim();
                  // validator.hex = result.match(/\s[0-9A-F]{64}$/igm);
                  // validator.hex = validator.hex[0].trim();
                  // validator.cosmosaccpub = result.match(/cosmospub.*$/igm);
                  // validator.cosmosaccpub = validator.cosmosaccpub[0].trim();
                  // validator.operator_pubkey = result.match(/cosmosvaloperpub.*$/igm);
                  // validator.operator_pubkey = validator.operator_pubkey[0].trim();
                  // validator.consensus_pubkey = result.match(/cosmosvalconspub.*$/igm);
                  // validator.consensus_pubkey = validator.consensus_pubkey[0].trim();
                  // });
                } else {
                  let validatorData = validatorSet[valExist.consensus_pubkey];

                  if (validatorData) {
                    if (validatorData.description && (!valExist.description || validatorData.description.identity !== valExist.description.identity)) validator.profile_url = getValidatorProfileUrl(validatorData.description.identity);
                    validator.jailed = validatorData.jailed;
                    validator.status = validatorData.status;
                    validator.tokens = validatorData.tokens;
                    validator.delegator_shares = validatorData.delegator_shares;
                    validator.description = validatorData.description;
                    validator.bond_height = validatorData.bond_height;
                    validator.bond_intra_tx_counter = validatorData.bond_intra_tx_counter;
                    validator.unbonding_height = validatorData.unbonding_height;
                    validator.unbonding_time = validatorData.unbonding_time;
                    validator.commission = validatorData.commission; // calculate self delegation percentage every 30 blocks

                    if (height % 30 == 1) {
                      try {
                        let response = HTTP.get(LCD + '/staking/delegators/' + valExist.delegator_address + '/delegations/' + valExist.operator_address);

                        if (response.statusCode == 200) {
                          let selfDelegation = JSON.parse(response.content).result;

                          if (selfDelegation.shares) {
                            validator.self_delegation = parseFloat(selfDelegation.shares) / parseFloat(validator.delegator_shares);
                          }
                        }
                      } catch (e) {// console.log(e);
                      }
                    }

                    bulkValidators.find({
                      consensus_pubkey: valExist.consensus_pubkey
                    }).updateOne({
                      $set: validator
                    }); // console.log("validator exisits: "+bulkValidators.length);
                    // validatorSet.splice(val, 1);
                  } else {
                    console.log('no con pub key?');
                  }

                  let prevVotingPower = VotingPowerHistory.findOne({
                    address: validator.address
                  }, {
                    height: -1,
                    limit: 1
                  });

                  if (prevVotingPower) {
                    if (prevVotingPower.voting_power != validator.voting_power) {
                      let changeType = prevVotingPower.voting_power > validator.voting_power ? 'down' : 'up';
                      let changeData = {
                        address: validator.address,
                        prev_voting_power: prevVotingPower.voting_power,
                        voting_power: validator.voting_power,
                        type: changeType,
                        height: blockData.height,
                        block_time: blockData.time
                      }; // console.log('voting power changed.');
                      // console.log(changeData);

                      bulkVPHistory.insert(changeData);
                    }
                  }
                } // console.log(validator);


                analyticsData.voting_power += validator.voting_power;
              } // if there is validator removed


              let prevValidators = ValidatorSets.findOne({
                block_height: height - 1
              });

              if (prevValidators) {
                let removedValidators = getRemovedValidators(prevValidators.validators, validators.result.validators);

                for (r in removedValidators) {
                  bulkVPHistory.insert({
                    address: removedValidators[r].address,
                    prev_voting_power: removedValidators[r].voting_power,
                    voting_power: 0,
                    type: 'remove',
                    height: blockData.height,
                    block_time: blockData.time
                  });
                }
              }
            } // check if there's any validator not in db 14400 blocks(~1 day)


            if (height % 14400 == 0) {
              try {
                console.log('Checking all validators against db...');
                let dbValidators = {};
                Validators.find({}, {
                  fields: {
                    consensus_pubkey: 1,
                    status: 1
                  }
                }).forEach(v => dbValidators[v.consensus_pubkey] = v.status);
                Object.keys(validatorSet).forEach(conPubKey => {
                  let validatorData = validatorSet[conPubKey]; // Active validators should have been updated in previous steps

                  if (validatorData.status === 2) return;

                  if (dbValidators[conPubKey] == undefined) {
                    console.log("validator with consensus_pubkey ".concat(conPubKey, " not in db"));
                    validatorData.pub_key = {
                      "type": "tendermint/PubKeyEd25519",
                      "value": Meteor.call('bech32ToPubkey', conPubKey)
                    };
                    validatorData.address = getAddress(validatorData.pub_key);
                    validatorData.delegator_address = Meteor.call('getDelegator', validatorData.operator_address);
                    validatorData.accpub = Meteor.call('pubkeyToBech32', validatorData.pub_key, Meteor.settings.public.bech32PrefixAccPub);
                    validatorData.operator_pubkey = Meteor.call('pubkeyToBech32', validatorData.pub_key, Meteor.settings.public.bech32PrefixValPub);
                    console.log(JSON.stringify(validatorData));
                    bulkValidators.find({
                      consensus_pubkey: conPubKey
                    }).upsert().updateOne({
                      $set: validatorData
                    });
                  } else if (dbValidators[conPubKey] == 2) {
                    bulkValidators.find({
                      consensus_pubkey: conPubKey
                    }).upsert().updateOne({
                      $set: validatorData
                    });
                  }
                });
              } catch (e) {
                console.log(e);
              }
            } // fetching keybase every 14400 blocks(~1 day)


            if (height % 14400 == 1) {
              console.log('Fetching keybase...');
              Validators.find({}).forEach(validator => {
                try {
                  let profileUrl = getValidatorProfileUrl(validator.description.identity);

                  if (profileUrl) {
                    bulkValidators.find({
                      address: validator.address
                    }).upsert().updateOne({
                      $set: {
                        'profile_url': profileUrl
                      }
                    });
                  }
                } catch (e) {
                  console.log(e);
                }
              });
            }

            let endFindValidatorsNameTime = new Date();
            console.log("Get validators name time: " + (endFindValidatorsNameTime - startFindValidatorsNameTime) / 1000 + "seconds."); // record for analytics

            let startAnayticsInsertTime = new Date();
            Analytics.insert(analyticsData);
            let endAnalyticsInsertTime = new Date();
            console.log("Analytics insert time: " + (endAnalyticsInsertTime - startAnayticsInsertTime) / 1000 + "seconds.");
            let startVUpTime = new Date();

            if (bulkValidators.length > 0) {
              // console.log(bulkValidators.length);
              bulkValidators.execute((err, result) => {
                if (err) {
                  console.log(err);
                }

                if (result) {// console.log(result);
                }
              });
            }

            let endVUpTime = new Date();
            console.log("Validator update time: " + (endVUpTime - startVUpTime) / 1000 + "seconds.");
            let startVRTime = new Date();

            if (bulkValidatorRecords.length > 0) {
              bulkValidatorRecords.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            }

            let endVRTime = new Date();
            console.log("Validator records update time: " + (endVRTime - startVRTime) / 1000 + "seconds.");

            if (bulkVPHistory.length > 0) {
              bulkVPHistory.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            }

            if (bulkTransations.length > 0) {
              bulkTransations.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            } // calculate voting power distribution every 60 blocks ~ 5mins


            if (height % 60 == 1) {
              console.log("===== calculate voting power distribution =====");
              let activeValidators = Validators.find({
                status: 2,
                jailed: false
              }, {
                sort: {
                  voting_power: -1
                }
              }).fetch();
              let numTopTwenty = Math.ceil(activeValidators.length * 0.2);
              let numBottomEighty = activeValidators.length - numTopTwenty;
              let topTwentyPower = 0;
              let bottomEightyPower = 0;
              let numTopThirtyFour = 0;
              let numBottomSixtySix = 0;
              let topThirtyFourPercent = 0;
              let bottomSixtySixPercent = 0;

              for (v in activeValidators) {
                if (v < numTopTwenty) {
                  topTwentyPower += activeValidators[v].voting_power;
                } else {
                  bottomEightyPower += activeValidators[v].voting_power;
                }

                if (topThirtyFourPercent < 0.34) {
                  topThirtyFourPercent += activeValidators[v].voting_power / analyticsData.voting_power;
                  numTopThirtyFour++;
                }
              }

              bottomSixtySixPercent = 1 - topThirtyFourPercent;
              numBottomSixtySix = activeValidators.length - numTopThirtyFour;
              let vpDist = {
                height: height,
                numTopTwenty: numTopTwenty,
                topTwentyPower: topTwentyPower,
                numBottomEighty: numBottomEighty,
                bottomEightyPower: bottomEightyPower,
                numTopThirtyFour: numTopThirtyFour,
                topThirtyFourPercent: topThirtyFourPercent,
                numBottomSixtySix: numBottomSixtySix,
                bottomSixtySixPercent: bottomSixtySixPercent,
                numValidators: activeValidators.length,
                totalVotingPower: analyticsData.voting_power,
                blockTime: blockData.time,
                createAt: new Date()
              };
              console.log(vpDist);
              VPDistributions.insert(vpDist);
            }
          }
        } catch (e) {
          console.log(e);
          SYNCING = false;
          return "Stopped";
        }

        let endBlockTime = new Date();
        console.log("This block used: " + (endBlockTime - startBlockTime) / 1000 + "seconds.");
      }

      SYNCING = false;
      Chain.update({
        chainId: Meteor.settings.public.chainId
      }, {
        $set: {
          lastBlocksSyncedTime: new Date(),
          totalValidators: totalValidators
        }
      });
    }

    return until;
  },
  'addLimit': function (limit) {
    // console.log(limit+10)
    return limit + 10;
  },
  'hasMore': function (limit) {
    if (limit > Meteor.call('getCurrentHeight')) {
      return false;
    } else {
      return true;
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/server/publications.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Blockscon;
module.link("../blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 3);
publishComposite('blocks.height', function (limit) {
  return {
    find() {
      return Blockscon.find({}, {
        limit: limit,
        sort: {
          height: -1
        }
      });
    },

    children: [{
      find(block) {
        return Validators.find({
          address: block.proposerAddress
        }, {
          limit: 1
        });
      }

    }]
  };
});
publishComposite('blocks.findOne', function (height) {
  return {
    find() {
      return Blockscon.find({
        height: height
      });
    },

    children: [{
      find(block) {
        return Transactions.find({
          height: block.height
        });
      }

    }, {
      find(block) {
        return Validators.find({
          address: block.proposerAddress
        }, {
          limit: 1
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"blocks.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/blocks.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Blockscon: () => Blockscon
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const Blockscon = new Mongo.Collection('blocks');
Blockscon.helpers({
  proposer() {
    return Validators.findOne({
      address: this.proposerAddress
    });
  }

}); // Blockscon.helpers({
//     sorted(limit) {
//         return Blockscon.find({}, {sort: {height:-1}, limit: limit});
//     }
// });
// Meteor.setInterval(function() {
//     Meteor.call('blocksUpdate', (error, result) => {
//         console.log(result);
//     })
// }, 30000000);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chain":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/server/methods.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let getAddress;
module.link("tendermint/lib/pubkey.js", {
  getAddress(v) {
    getAddress = v;
  }

}, 2);
let Chain, ChainStates;
module.link("../chain.js", {
  Chain(v) {
    Chain = v;
  },

  ChainStates(v) {
    ChainStates = v;
  }

}, 3);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 4);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 5);

findVotingPower = (validator, genValidators) => {
  for (let v in genValidators) {
    if (validator.pub_key.value == genValidators[v].pub_key.value) {
      return parseInt(genValidators[v].power);
    }
  }
};

Meteor.methods({
  'chain.getConsensusState': function () {
    this.unblock();
    let url = RPC + '/dump_consensus_state';

    try {
      let response = HTTP.get(url);
      let consensus = JSON.parse(response.content);
      consensus = consensus.result;
      let height = consensus.round_state.height;
      let round = consensus.round_state.round;
      let step = consensus.round_state.step;
      let votedPower = Math.round(parseFloat(consensus.round_state.votes[round].prevotes_bit_array.split(" ")[3]) * 100);
      Chain.update({
        chainId: Meteor.settings.public.chainId
      }, {
        $set: {
          votingHeight: height,
          votingRound: round,
          votingStep: step,
          votedPower: votedPower,
          proposerAddress: consensus.round_state.validators.proposer.address,
          prevotes: consensus.round_state.votes[round].prevotes,
          precommits: consensus.round_state.votes[round].precommits
        }
      });
    } catch (e) {
      console.log(e);
    }
  },
  'chain.updateStatus': function () {
    this.unblock();
    let url = RPC + '/status';

    try {
      let response = HTTP.get(url);
      let status = JSON.parse(response.content);
      status = status.result;
      let chain = {};
      chain.chainId = status.node_info.network;
      chain.latestBlockHeight = status.sync_info.latest_block_height;
      chain.latestBlockTime = status.sync_info.latest_block_time;
      let latestState = ChainStates.findOne({}, {
        sort: {
          height: -1
        }
      });

      if (latestState && latestState.height >= chain.latestBlockHeight) {
        return "no updates (getting block ".concat(chain.latestBlockHeight, " at block ").concat(latestState.height, ")");
      }

      url = RPC + '/validators';
      response = HTTP.get(url);
      let validators = JSON.parse(response.content);
      validators = validators.result.validators;
      chain.validators = validators.length;
      let activeVP = 0;

      for (v in validators) {
        activeVP += parseInt(validators[v].voting_power);
      }

      chain.activeVotingPower = activeVP;
      Chain.update({
        chainId: chain.chainId
      }, {
        $set: chain
      }, {
        upsert: true
      }); // Get chain states

      if (parseInt(chain.latestBlockHeight) > 0) {
        let chainStates = {};
        chainStates.height = parseInt(status.sync_info.latest_block_height);
        chainStates.time = new Date(status.sync_info.latest_block_time);
        url = LCD + '/staking/pool';

        try {
          response = HTTP.get(url);
          let bonding = JSON.parse(response.content).result; // chain.bondedTokens = bonding.bonded_tokens;
          // chain.notBondedTokens = bonding.not_bonded_tokens;

          chainStates.bondedTokens = parseInt(bonding.bonded_tokens);
          chainStates.notBondedTokens = parseInt(bonding.not_bonded_tokens);
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/supply/total/' + Meteor.settings.public.mintingDenom;

        try {
          response = HTTP.get(url);
          let supply = JSON.parse(response.content).result;
          chainStates.totalSupply = parseInt(supply);
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/distribution/community_pool';

        try {
          response = HTTP.get(url);
          let pool = JSON.parse(response.content).result;

          if (pool && pool.length > 0) {
            chainStates.communityPool = [];
            pool.forEach((amount, i) => {
              chainStates.communityPool.push({
                denom: amount.denom,
                amount: parseFloat(amount.amount)
              });
            });
          }
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/minting/inflation';

        try {
          response = HTTP.get(url);
          let inflation = JSON.parse(response.content).result;

          if (inflation) {
            chainStates.inflation = parseFloat(inflation);
          }
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/minting/annual-provisions';

        try {
          response = HTTP.get(url);
          let provisions = JSON.parse(response.content);

          if (provisions) {
            chainStates.annualProvisions = parseFloat(provisions.result);
          }
        } catch (e) {
          console.log(e);
        }

        ChainStates.insert(chainStates);
      } // chain.totalVotingPower = totalVP;
      // validators = Validators.find({}).fetch();
      // console.log(validators);


      return chain.latestBlockHeight;
    } catch (e) {
      console.log(e);
      return "Error getting chain status.";
    }
  },
  'chain.getLatestStatus': function () {
    Chain.find().sort({
      created: -1
    }).limit(1);
  },
  'chain.genesis': function () {
    let chain = Chain.findOne({
      chainId: Meteor.settings.public.chainId
    });

    if (chain && chain.readGenesis) {
      console.log('Genesis file has been processed');
    } else if (Meteor.settings.debug.readGenesis) {
      console.log('=== Start processing genesis file ===');
      let response = HTTP.get(Meteor.settings.genesisFile);
      let genesis = JSON.parse(response.content);
      let distr = genesis.app_state.distr || genesis.app_state.distribution;
      let chainParams = {
        chainId: genesis.chain_id,
        genesisTime: genesis.genesis_time,
        consensusParams: genesis.consensus_params,
        auth: genesis.app_state.auth,
        bank: genesis.app_state.bank,
        staking: {
          pool: genesis.app_state.staking.pool,
          params: genesis.app_state.staking.params
        },
        mint: genesis.app_state.mint,
        distr: {
          communityTax: distr.community_tax,
          baseProposerReward: distr.base_proposer_reward,
          bonusProposerReward: distr.bonus_proposer_reward,
          withdrawAddrEnabled: distr.withdraw_addr_enabled
        },
        gov: {
          startingProposalId: genesis.app_state.gov.starting_proposal_id,
          depositParams: genesis.app_state.gov.deposit_params,
          votingParams: genesis.app_state.gov.voting_params,
          tallyParams: genesis.app_state.gov.tally_params
        },
        slashing: {
          params: genesis.app_state.slashing.params
        },
        supply: genesis.app_state.supply,
        crisis: genesis.app_state.crisis
      };
      let totalVotingPower = 0; // read gentx

      if (genesis.app_state.genutil && genesis.app_state.genutil.gentxs && genesis.app_state.genutil.gentxs.length > 0) {
        for (i in genesis.app_state.genutil.gentxs) {
          let msg = genesis.app_state.genutil.gentxs[i].value.msg; // console.log(msg.type);

          for (m in msg) {
            if (msg[m].type == "cosmos-sdk/MsgCreateValidator") {
              console.log(msg[m].value); // let command = Meteor.settings.bin.gaiadebug+" pubkey "+msg[m].value.pubkey;

              let validator = {
                consensus_pubkey: msg[m].value.pubkey,
                description: msg[m].value.description,
                commission: msg[m].value.commission,
                min_self_delegation: msg[m].value.min_self_delegation,
                operator_address: msg[m].value.validator_address,
                delegator_address: msg[m].value.delegator_address,
                voting_power: Math.floor(parseInt(msg[m].value.value.amount) / Meteor.settings.public.stakingFraction),
                jailed: false,
                status: 2
              };
              totalVotingPower += validator.voting_power;
              let pubkeyValue = Meteor.call('bech32ToPubkey', msg[m].value.pubkey); // Validators.upsert({consensus_pubkey:msg[m].value.pubkey},validator);

              validator.pub_key = {
                "type": "tendermint/PubKeyEd25519",
                "value": pubkeyValue
              };
              validator.address = getAddress(validator.pub_key);
              validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
              validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
              VotingPowerHistory.insert({
                address: validator.address,
                prev_voting_power: 0,
                voting_power: validator.voting_power,
                type: 'add',
                height: 0,
                block_time: genesis.genesis_time
              });
              Validators.insert(validator);
            }
          }
        }
      } // read validators from previous chain


      console.log('read validators from previous chain');

      if (genesis.app_state.staking.validators && genesis.app_state.staking.validators.length > 0) {
        console.log(genesis.app_state.staking.validators.length);
        let genValidatorsSet = genesis.app_state.staking.validators;
        let genValidators = genesis.validators;

        for (let v in genValidatorsSet) {
          // console.log(genValidators[v]);
          let validator = genValidatorsSet[v];
          validator.delegator_address = Meteor.call('getDelegator', genValidatorsSet[v].operator_address);
          let pubkeyValue = Meteor.call('bech32ToPubkey', validator.consensus_pubkey);
          validator.pub_key = {
            "type": "tendermint/PubKeyEd25519",
            "value": pubkeyValue
          };
          validator.address = getAddress(validator.pub_key);
          validator.pub_key = validator.pub_key;
          validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
          validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
          validator.voting_power = findVotingPower(validator, genValidators);
          totalVotingPower += validator.voting_power;
          Validators.upsert({
            consensus_pubkey: validator.consensus_pubkey
          }, validator);
          VotingPowerHistory.insert({
            address: validator.address,
            prev_voting_power: 0,
            voting_power: validator.voting_power,
            type: 'add',
            height: 0,
            block_time: genesis.genesis_time
          });
        }
      }

      chainParams.readGenesis = true;
      chainParams.activeVotingPower = totalVotingPower;
      let result = Chain.upsert({
        chainId: chainParams.chainId
      }, {
        $set: chainParams
      });
      console.log('=== Finished processing genesis file ===');
    }

    return true;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/server/publications.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Chain, ChainStates;
module.link("../chain.js", {
  Chain(v) {
    Chain = v;
  },

  ChainStates(v) {
    ChainStates = v;
  }

}, 1);
let CoinStats;
module.link("../../coin-stats/coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
Meteor.publish('chainStates.latest', function () {
  return [ChainStates.find({}, {
    sort: {
      height: -1
    },
    limit: 1
  }), CoinStats.find({}, {
    sort: {
      last_updated_at: -1
    },
    limit: 1
  })];
});
publishComposite('chain.status', function () {
  return {
    find() {
      return Chain.find({
        chainId: Meteor.settings.public.chainId
      });
    },

    children: [{
      find(chain) {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            operator_address: 1,
            status: -1,
            jailed: 1,
            profile_url: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chain.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/chain.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Chain: () => Chain,
  ChainStates: () => ChainStates
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const Chain = new Mongo.Collection('chain');
const ChainStates = new Mongo.Collection('chain_states');
Chain.helpers({
  proposer() {
    return Validators.findOne({
      address: this.proposerAddress
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"coin-stats":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/coin-stats/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let CoinStats;
module.link("../coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 1);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 2);
Meteor.methods({
  'coinStats.getCoinStats': function () {
    this.unblock();
    let coinId = Meteor.settings.public.coingeckoId;

    if (coinId) {
      try {
        let now = new Date();
        now.setMinutes(0);
        let url = "https://api.coingecko.com/api/v3/simple/price?ids=" + coinId + "&vs_currencies=usd&include_market_cap=true&include_24hr_vol=true&include_24hr_change=true&include_last_updated_at=true";
        let response = HTTP.get(url);

        if (response.statusCode == 200) {
          // console.log(JSON.parse(response.content));
          let data = JSON.parse(response.content);
          data = data[coinId]; // console.log(coinStats);

          return CoinStats.upsert({
            last_updated_at: data.last_updated_at
          }, {
            $set: data
          });
        }
      } catch (e) {
        console.log(e);
      }
    } else {
      return "No coingecko Id provided.";
    }
  },
  'coinStats.getStats': function () {
    this.unblock();
    let coinId = Meteor.settings.public.coingeckoId;

    if (coinId) {
      return CoinStats.findOne({}, {
        sort: {
          last_updated_at: -1
        }
      });
    } else {
      return "No coingecko Id provided.";
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"coin-stats.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/coin-stats/coin-stats.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  CoinStats: () => CoinStats
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const CoinStats = new Mongo.Collection('coin_stats');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"delegations":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/server/methods.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Delegations;
module.link("../delegations.js", {
  Delegations(v) {
    Delegations = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
Meteor.methods({
  'delegations.getDelegations': function () {
    this.unblock();
    let validators = Validators.find({}).fetch();
    let delegations = [];
    console.log("=== Getting delegations ===");

    for (v in validators) {
      if (validators[v].operator_address) {
        let url = LCD + '/staking/validators/' + validators[v].operator_address + "/delegations";

        try {
          let response = HTTP.get(url);

          if (response.statusCode == 200) {
            let delegation = JSON.parse(response.content).result; // console.log(delegation);

            delegations = delegations.concat(delegation);
          } else {
            console.log(response.statusCode);
          }
        } catch (e) {
          console.log(e);
        }
      }
    }

    for (i in delegations) {
      if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
    } // console.log(delegations);


    let data = {
      delegations: delegations,
      createdAt: new Date()
    };
    return Delegations.insert(data);
  } // 'blocks.averageBlockTime'(address){
  //     let blocks = Blockscon.find({proposerAddress:address}).fetch();
  //     let heights = blocks.map((block, i) => {
  //         return block.height;
  //     });
  //     let blocksStats = Analytics.find({height:{$in:heights}}).fetch();
  //     // console.log(blocksStats);
  //     let totalBlockDiff = 0;
  //     for (b in blocksStats){
  //         totalBlockDiff += blocksStats[b].timeDiff;
  //     }
  //     return totalBlockDiff/heights.length;
  // }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/server/publications.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"delegations.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/delegations.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Delegations: () => Delegations
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Delegations = new Mongo.Collection('delegations');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"ledger":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/ledger/server/methods.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 0);
Meteor.methods({
  'transaction.submit': function (txInfo) {
    const url = "".concat(LCD, "/txs");
    data = {
      "tx": txInfo.value,
      "mode": "sync"
    };
    const timestamp = new Date().getTime();
    console.log("submitting transaction".concat(timestamp, " ").concat(url, " with data ").concat(JSON.stringify(data)));
    let response = HTTP.post(url, {
      data
    });
    console.log("response for transaction".concat(timestamp, " ").concat(url, ": ").concat(JSON.stringify(response)));

    if (response.statusCode == 200) {
      let data = response.data;
      if (data.code) throw new Meteor.Error(data.code, JSON.parse(data.raw_log).message);
      return response.data.txhash;
    }
  },
  'transaction.execute': function (body, path) {
    const url = "".concat(LCD, "/").concat(path);
    data = {
      "base_req": _objectSpread({}, body, {
        "chain_id": Meteor.settings.public.chainId,
        "simulate": false
      })
    };
    let response = HTTP.post(url, {
      data
    });

    if (response.statusCode == 200) {
      return JSON.parse(response.content);
    }
  },
  'transaction.simulate': function (txMsg, from, path) {
    let adjustment = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '1.2';
    const url = "".concat(LCD, "/").concat(path);
    data = _objectSpread({}, txMsg, {
      "base_req": {
        "from": from,
        "chain_id": Meteor.settings.public.chainId,
        "gas_adjustment": adjustment,
        "simulate": true
      }
    });
    let response = HTTP.post(url, {
      data
    });

    if (response.statusCode == 200) {
      return JSON.parse(response.content).gas_estimate;
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"proposals":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/proposals/server/methods.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Proposals;
module.link("../proposals.js", {
  Proposals(v) {
    Proposals = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
// import { Promise } from 'meteor/promise';
Meteor.methods({
  'proposals.getProposals': function () {
    this.unblock();

    try {
      let url = LCD + '/gov/proposals';
      let response = HTTP.get(url);
      let proposals = JSON.parse(response.content).result; // console.log(proposals);

      let finishedProposalIds = new Set(Proposals.find({
        "proposal_status": {
          $in: ["Passed", "Rejected", "Removed"]
        }
      }).fetch().map(p => p.proposalId));
      let proposalIds = [];

      if (proposals.length > 0) {
        // Proposals.upsert()
        const bulkProposals = Proposals.rawCollection().initializeUnorderedBulkOp();

        for (let i in proposals) {
          let proposal = proposals[i];
          proposal.proposalId = parseInt(proposal.id);

          if (proposal.proposalId > 0 && !finishedProposalIds.has(proposal.proposalId)) {
            try {
              let url = LCD + '/gov/proposals/' + proposal.proposalId + '/proposer';
              let response = HTTP.get(url);

              if (response.statusCode == 200) {
                let proposer = JSON.parse(response.content).result;

                if (proposer.proposal_id && proposer.proposal_id == proposal.id) {
                  proposal.proposer = proposer.proposer;
                }
              }

              bulkProposals.find({
                proposalId: proposal.proposalId
              }).upsert().updateOne({
                $set: proposal
              });
              proposalIds.push(proposal.proposalId);
            } catch (e) {
              bulkProposals.find({
                proposalId: proposal.proposalId
              }).upsert().updateOne({
                $set: proposal
              });
              proposalIds.push(proposal.proposalId);
              console.log(e.response.content);
            }
          }
        }

        bulkProposals.find({
          proposalId: {
            $nin: proposalIds
          },
          proposal_status: {
            $nin: ["Passed", "Rejected", "Removed"]
          }
        }).update({
          $set: {
            "proposal_status": "Removed"
          }
        });
        bulkProposals.execute();
      }

      return true;
    } catch (e) {
      console.log(e);
    }
  },
  'proposals.getProposalResults': function () {
    this.unblock();
    let proposals = Proposals.find({
      "proposal_status": {
        $nin: ["Passed", "Rejected", "Removed"]
      }
    }).fetch();

    if (proposals && proposals.length > 0) {
      for (let i in proposals) {
        if (parseInt(proposals[i].proposalId) > 0) {
          try {
            // get proposal deposits
            let url = LCD + '/gov/proposals/' + proposals[i].proposalId + '/deposits';
            let response = HTTP.get(url);
            let proposal = {
              proposalId: proposals[i].proposalId
            };

            if (response.statusCode == 200) {
              let deposits = JSON.parse(response.content).result;
              proposal.deposits = deposits;
            }

            url = LCD + '/gov/proposals/' + proposals[i].proposalId + '/votes';
            response = HTTP.get(url);

            if (response.statusCode == 200) {
              let votes = JSON.parse(response.content).result;
              proposal.votes = getVoteDetail(votes);
            }

            url = LCD + '/gov/proposals/' + proposals[i].proposalId + '/tally';
            response = HTTP.get(url);

            if (response.statusCode == 200) {
              let tally = JSON.parse(response.content).result;
              proposal.tally = tally;
            }

            proposal.updatedAt = new Date();
            Proposals.update({
              proposalId: proposals[i].proposalId
            }, {
              $set: proposal
            });
          } catch (e) {}
        }
      }
    }

    return true;
  }
});

const getVoteDetail = votes => {
  if (!votes) {
    return [];
  }

  let voters = votes.map(vote => vote.voter);
  let votingPowerMap = {};
  let validatorAddressMap = {};
  Validators.find({
    delegator_address: {
      $in: voters
    }
  }).forEach(validator => {
    votingPowerMap[validator.delegator_address] = {
      moniker: validator.description.moniker,
      address: validator.address,
      tokens: parseFloat(validator.tokens),
      delegatorShares: parseFloat(validator.delegator_shares),
      deductedShares: parseFloat(validator.delegator_shares)
    };
    validatorAddressMap[validator.operator_address] = validator.delegator_address;
  });
  voters.forEach(voter => {
    if (!votingPowerMap[voter]) {
      // voter is not a validator
      let url = "".concat(LCD, "/staking/delegators/").concat(voter, "/delegations");
      let delegations;
      let votingPower = 0;

      try {
        let response = HTTP.get(url);

        if (response.statusCode == 200) {
          delegations = JSON.parse(response.content).result;

          if (delegations && delegations.length > 0) {
            delegations.forEach(delegation => {
              let shares = parseFloat(delegation.shares);

              if (validatorAddressMap[delegation.validator_address]) {
                // deduct delegated shareds from validator if a delegator votes
                let validator = votingPowerMap[validatorAddressMap[delegation.validator_address]];
                validator.deductedShares -= shares;

                if (validator.delegator_shares != 0) {
                  // avoiding division by zero
                  votingPower += shares / validator.delegatorShares * validator.tokens;
                }
              } else {
                let validator = Validators.findOne({
                  operator_address: delegation.validator_address
                });

                if (validator && validator.delegator_shares != 0) {
                  // avoiding division by zero
                  votingPower += shares / parseFloat(validator.delegator_shares) * parseFloat(validator.tokens);
                }
              }
            });
          }
        }
      } catch (e) {
        console.log(e);
      }

      votingPowerMap[voter] = {
        votingPower: votingPower
      };
    }
  });
  return votes.map(vote => {
    let voter = votingPowerMap[vote.voter];
    let votingPower = voter.votingPower;

    if (votingPower == undefined) {
      // voter is a validator
      votingPower = voter.delegatorShares ? voter.deductedShares / voter.delegatorShares * voter.tokens : 0;
    }

    return _objectSpread({}, vote, {
      votingPower
    });
  });
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/proposals/server/publications.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Proposals;
module.link("../proposals.js", {
  Proposals(v) {
    Proposals = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
Meteor.publish('proposals.list', function () {
  return Proposals.find({}, {
    sort: {
      proposalId: -1
    }
  });
});
Meteor.publish('proposals.one', function (id) {
  check(id, Number);
  return Proposals.find({
    proposalId: id
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"proposals.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/proposals/proposals.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Proposals: () => Proposals
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Proposals = new Mongo.Collection('proposals');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"records":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/server/methods.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let ValidatorRecords, Analytics, AverageData, AverageValidatorData;
module.link("../records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  AverageData(v) {
    AverageData = v;
  },

  AverageValidatorData(v) {
    AverageValidatorData = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
let ValidatorSets;
module.link("/imports/api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 4);
let Status;
module.link("../../status/status.js", {
  Status(v) {
    Status = v;
  }

}, 5);
let MissedBlocksStats;
module.link("../records.js", {
  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  }

}, 6);
let MissedBlocks;
module.link("../records.js", {
  MissedBlocks(v) {
    MissedBlocks = v;
  }

}, 7);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 8);
let Chain;
module.link("../../chain/chain.js", {
  Chain(v) {
    Chain = v;
  }

}, 9);

let _;

module.link("lodash", {
  default(v) {
    _ = v;
  }

}, 10);
const BULKUPDATEMAXSIZE = 1000;

const getBlockStats = (startHeight, latestHeight) => {
  let blockStats = {};
  const cond = {
    $and: [{
      height: {
        $gt: startHeight
      }
    }, {
      height: {
        $lte: latestHeight
      }
    }]
  };
  const options = {
    sort: {
      height: 1
    }
  };
  Blockscon.find(cond, options).forEach(block => {
    blockStats[block.height] = {
      height: block.height,
      proposerAddress: block.proposerAddress,
      precommitsCount: block.precommitsCount,
      validatorsCount: block.validatorsCount,
      validators: block.validators,
      time: block.time
    };
  });
  Analytics.find(cond, options).forEach(block => {
    if (!blockStats[block.height]) {
      blockStats[block.height] = {
        height: block.height
      };
      console.log("block ".concat(block.height, " does not have an entry"));
    }

    _.assign(blockStats[block.height], {
      precommits: block.precommits,
      averageBlockTime: block.averageBlockTime,
      timeDiff: block.timeDiff,
      voting_power: block.voting_power
    });
  });
  return blockStats;
};

const getPreviousRecord = (voterAddress, proposerAddress) => {
  let previousRecord = MissedBlocks.findOne({
    voter: voterAddress,
    proposer: proposerAddress,
    blockHeight: -1
  });
  let lastUpdatedHeight = Meteor.settings.params.startHeight;
  let prevStats = {};

  if (previousRecord) {
    prevStats = _.pick(previousRecord, ['missCount', 'totalCount']);
  } else {
    prevStats = {
      missCount: 0,
      totalCount: 0
    };
  }

  return prevStats;
};

Meteor.methods({
  'ValidatorRecords.calculateMissedBlocks': function () {
    if (!COUNTMISSEDBLOCKS) {
      try {
        let startTime = Date.now();
        COUNTMISSEDBLOCKS = true;
        console.log('calulate missed blocks count');
        this.unblock();
        let validators = Validators.find({}).fetch();
        let latestHeight = Meteor.call('blocks.getCurrentHeight');
        let explorerStatus = Status.findOne({
          chainId: Meteor.settings.public.chainId
        });
        let startHeight = explorerStatus && explorerStatus.lastProcessedMissedBlockHeight ? explorerStatus.lastProcessedMissedBlockHeight : Meteor.settings.params.startHeight;
        latestHeight = Math.min(startHeight + BULKUPDATEMAXSIZE, latestHeight);
        const bulkMissedStats = MissedBlocks.rawCollection().initializeOrderedBulkOp();
        let validatorsMap = {};
        validators.forEach(validator => validatorsMap[validator.address] = validator); // a map of block height to block stats

        let blockStats = getBlockStats(startHeight, latestHeight); // proposerVoterStats is a proposer-voter map counting numbers of proposed blocks of which voter is an active validator

        let proposerVoterStats = {};

        _.forEach(blockStats, (block, blockHeight) => {
          let proposerAddress = block.proposerAddress;
          let votedValidators = new Set(block.validators);
          let validatorSets = ValidatorSets.findOne({
            block_height: block.height
          });
          let votedVotingPower = 0;
          validatorSets.validators.forEach(activeValidator => {
            if (votedValidators.has(activeValidator.address)) votedVotingPower += parseFloat(activeValidator.voting_power);
          });
          validatorSets.validators.forEach(activeValidator => {
            let currentValidator = activeValidator.address;

            if (!_.has(proposerVoterStats, [proposerAddress, currentValidator])) {
              let prevStats = getPreviousRecord(currentValidator, proposerAddress);

              _.set(proposerVoterStats, [proposerAddress, currentValidator], prevStats);
            }

            _.update(proposerVoterStats, [proposerAddress, currentValidator, 'totalCount'], n => n + 1);

            if (!votedValidators.has(currentValidator)) {
              _.update(proposerVoterStats, [proposerAddress, currentValidator, 'missCount'], n => n + 1);

              bulkMissedStats.insert({
                voter: currentValidator,
                blockHeight: block.height,
                proposer: proposerAddress,
                precommitsCount: block.precommitsCount,
                validatorsCount: block.validatorsCount,
                time: block.time,
                precommits: block.precommits,
                averageBlockTime: block.averageBlockTime,
                timeDiff: block.timeDiff,
                votingPower: block.voting_power,
                votedVotingPower,
                updatedAt: latestHeight,
                missCount: _.get(proposerVoterStats, [proposerAddress, currentValidator, 'missCount']),
                totalCount: _.get(proposerVoterStats, [proposerAddress, currentValidator, 'totalCount'])
              });
            }
          });
        });

        _.forEach(proposerVoterStats, (voters, proposerAddress) => {
          _.forEach(voters, (stats, voterAddress) => {
            bulkMissedStats.find({
              voter: voterAddress,
              proposer: proposerAddress,
              blockHeight: -1
            }).upsert().updateOne({
              $set: {
                voter: voterAddress,
                proposer: proposerAddress,
                blockHeight: -1,
                updatedAt: latestHeight,
                missCount: _.get(stats, 'missCount'),
                totalCount: _.get(stats, 'totalCount')
              }
            });
          });
        });

        let message = '';

        if (bulkMissedStats.length > 0) {
          const client = MissedBlocks._driver.mongo.client; // TODO: add transaction back after replica set(#146) is set up
          // let session = client.startSession();
          // session.startTransaction();

          let bulkPromise = bulkMissedStats.execute(null
          /*, {session}*/
          ).then(Meteor.bindEnvironment((result, err) => {
            if (err) {
              COUNTMISSEDBLOCKS = false; // Promise.await(session.abortTransaction());

              throw err;
            }

            if (result) {
              // Promise.await(session.commitTransaction());
              message = "(".concat(result.result.nInserted, " inserted, ") + "".concat(result.result.nUpserted, " upserted, ") + "".concat(result.result.nModified, " modified)");
            }
          }));
          Promise.await(bulkPromise);
        }

        COUNTMISSEDBLOCKS = false;
        Status.upsert({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastProcessedMissedBlockHeight: latestHeight,
            lastProcessedMissedBlockTime: new Date()
          }
        });
        return "done in ".concat(Date.now() - startTime, "ms ").concat(message);
      } catch (e) {
        COUNTMISSEDBLOCKS = false;
        throw e;
      }
    } else {
      return "updating...";
    }
  },
  'ValidatorRecords.calculateMissedBlocksStats': function () {
    // TODO: deprecate this method and MissedBlocksStats collection
    // console.log("ValidatorRecords.calculateMissedBlocks: "+COUNTMISSEDBLOCKS);
    if (!COUNTMISSEDBLOCKSSTATS) {
      COUNTMISSEDBLOCKSSTATS = true;
      console.log('calulate missed blocks stats');
      this.unblock();
      let validators = Validators.find({}).fetch();
      let latestHeight = Meteor.call('blocks.getCurrentHeight');
      let explorerStatus = Status.findOne({
        chainId: Meteor.settings.public.chainId
      });
      let startHeight = explorerStatus && explorerStatus.lastMissedBlockHeight ? explorerStatus.lastMissedBlockHeight : Meteor.settings.params.startHeight; // console.log(latestHeight);
      // console.log(startHeight);

      const bulkMissedStats = MissedBlocksStats.rawCollection().initializeUnorderedBulkOp();

      for (i in validators) {
        // if ((validators[i].address == "B8552EAC0D123A6BF609123047A5181D45EE90B5") || (validators[i].address == "69D99B2C66043ACBEAA8447525C356AFC6408E0C") || (validators[i].address == "35AD7A2CD2FC71711A675830EC1158082273D457")){
        let voterAddress = validators[i].address;
        let missedRecords = ValidatorRecords.find({
          address: voterAddress,
          exists: false,
          $and: [{
            height: {
              $gt: startHeight
            }
          }, {
            height: {
              $lte: latestHeight
            }
          }]
        }).fetch();
        let counts = {}; // console.log("missedRecords to process: "+missedRecords.length);

        for (b in missedRecords) {
          let block = Blockscon.findOne({
            height: missedRecords[b].height
          });
          let existingRecord = MissedBlocksStats.findOne({
            voter: voterAddress,
            proposer: block.proposerAddress
          });

          if (typeof counts[block.proposerAddress] === 'undefined') {
            if (existingRecord) {
              counts[block.proposerAddress] = existingRecord.count + 1;
            } else {
              counts[block.proposerAddress] = 1;
            }
          } else {
            counts[block.proposerAddress]++;
          }
        }

        for (address in counts) {
          let data = {
            voter: voterAddress,
            proposer: address,
            count: counts[address]
          };
          bulkMissedStats.find({
            voter: voterAddress,
            proposer: address
          }).upsert().updateOne({
            $set: data
          });
        } // }

      }

      if (bulkMissedStats.length > 0) {
        bulkMissedStats.execute(Meteor.bindEnvironment((err, result) => {
          if (err) {
            COUNTMISSEDBLOCKSSTATS = false;
            console.log(err);
          }

          if (result) {
            Status.upsert({
              chainId: Meteor.settings.public.chainId
            }, {
              $set: {
                lastMissedBlockHeight: latestHeight,
                lastMissedBlockTime: new Date()
              }
            });
            COUNTMISSEDBLOCKSSTATS = false;
            console.log("done");
          }
        }));
      } else {
        COUNTMISSEDBLOCKSSTATS = false;
      }

      return true;
    } else {
      return "updating...";
    }
  },
  'Analytics.aggregateBlockTimeAndVotingPower': function (time) {
    this.unblock();
    let now = new Date();

    if (time == 'm') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastMinuteVotingPower: averageVotingPower,
            lastMinuteBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    }

    if (time == 'h') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 60 * 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastHourVotingPower: averageVotingPower,
            lastHourBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    }

    if (time == 'd') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastDayVotingPower: averageVotingPower,
            lastDayBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    } // return analytics.length;

  },
  'Analytics.aggregateValidatorDailyBlockTime': function () {
    this.unblock();
    let validators = Validators.find({}).fetch();
    let now = new Date();

    for (i in validators) {
      let averageBlockTime = 0;
      let blocks = Blockscon.find({
        proposerAddress: validators[i].address,
        "time": {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }, {
        fields: {
          height: 1
        }
      }).fetch();

      if (blocks.length > 0) {
        let blockHeights = [];

        for (b in blocks) {
          blockHeights.push(blocks[b].height);
        }

        let analytics = Analytics.find({
          height: {
            $in: blockHeights
          }
        }, {
          fields: {
            height: 1,
            timeDiff: 1
          }
        }).fetch();

        for (a in analytics) {
          averageBlockTime += analytics[a].timeDiff;
        }

        averageBlockTime = averageBlockTime / analytics.length;
      }

      AverageValidatorData.insert({
        proposerAddress: validators[i].address,
        averageBlockTime: averageBlockTime,
        type: 'ValidatorDailyAverageBlockTime',
        createdAt: now
      });
    }

    return true;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/server/publications.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatorRecords, Analytics, MissedBlocks, MissedBlocksStats, VPDistributions;
module.link("../records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  MissedBlocks(v) {
    MissedBlocks = v;
  },

  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  },

  VPDistributions(v) {
    VPDistributions = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
Meteor.publish('validator_records.all', function () {
  return ValidatorRecords.find();
});
Meteor.publish('validator_records.uptime', function (address, num) {
  return ValidatorRecords.find({
    address: address
  }, {
    limit: num,
    sort: {
      height: -1
    }
  });
});
Meteor.publish('analytics.history', function () {
  return Analytics.find({}, {
    sort: {
      height: -1
    },
    limit: 50
  });
});
Meteor.publish('vpDistribution.latest', function () {
  return VPDistributions.find({}, {
    sort: {
      height: -1
    },
    limit: 1
  });
});
publishComposite('missedblocks.validator', function (address, type) {
  let conditions = {};

  if (type == 'voter') {
    conditions = {
      voter: address
    };
  } else {
    conditions = {
      proposer: address
    };
  }

  return {
    find() {
      return MissedBlocksStats.find(conditions);
    },

    children: [{
      find(stats) {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            profile_url: 1
          }
        });
      }

    }]
  };
});
publishComposite('missedrecords.validator', function (address, type) {
  return {
    find() {
      return MissedBlocks.find({
        [type]: address
      }, {
        sort: {
          updatedAt: -1
        }
      });
    },

    children: [{
      find() {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            operator_address: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"records.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/records.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  ValidatorRecords: () => ValidatorRecords,
  Analytics: () => Analytics,
  MissedBlocksStats: () => MissedBlocksStats,
  MissedBlocks: () => MissedBlocks,
  VPDistributions: () => VPDistributions,
  AverageData: () => AverageData,
  AverageValidatorData: () => AverageValidatorData
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const ValidatorRecords = new Mongo.Collection('validator_records');
const Analytics = new Mongo.Collection('analytics');
const MissedBlocksStats = new Mongo.Collection('missed_blocks_stats');
const MissedBlocks = new Mongo.Collection('missed_blocks');
const VPDistributions = new Mongo.Collection('voting_power_distributions');
const AverageData = new Mongo.Collection('average_data');
const AverageValidatorData = new Mongo.Collection('average_validator_data');
MissedBlocksStats.helpers({
  proposerMoniker() {
    let validator = Validators.findOne({
      address: this.proposer
    });
    return validator.description ? validator.description.moniker : this.proposer;
  },

  voterMoniker() {
    let validator = Validators.findOne({
      address: this.voter
    });
    return validator.description ? validator.description.moniker : this.voter;
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"status":{"server":{"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/status/server/publications.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Status;
module.link("../status.js", {
  Status(v) {
    Status = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
Meteor.publish('status.status', function () {
  return Status.find({
    chainId: Meteor.settings.public.chainId
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"status.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/status/status.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Status: () => Status
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Status = new Mongo.Collection('status');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactions":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/server/methods.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 4);
const AddressLength = 40;
Meteor.methods({
  'Transactions.index': function (hash, blockTime) {
    this.unblock();
    hash = hash.toUpperCase();
    let url = LCD + '/txs/' + hash;
    let response = HTTP.get(url);
    let tx = JSON.parse(response.content);
    console.log(hash);
    tx.height = parseInt(tx.height); // if (!tx.code){
    //     let msg = tx.tx.value.msg;
    //     for (let m in msg){
    //         if (msg[m].type == "cosmos-sdk/MsgCreateValidator"){
    //             console.log(msg[m].value);
    //             let command = Meteor.settings.bin.gaiadebug+" pubkey "+msg[m].value.pubkey;
    //             let validator = {
    //                 consensus_pubkey: msg[m].value.pubkey,
    //                 description: msg[m].value.description,
    //                 commission: msg[m].value.commission,
    //                 min_self_delegation: msg[m].value.min_self_delegation,
    //                 operator_address: msg[m].value.validator_address,
    //                 delegator_address: msg[m].value.delegator_address,
    //                 voting_power: Math.floor(parseInt(msg[m].value.value.amount) / 1000000)
    //             }
    //             Meteor.call('runCode', command, function(error, result){
    //                 validator.address = result.match(/\s[0-9A-F]{40}$/igm);
    //                 validator.address = validator.address[0].trim();
    //                 validator.hex = result.match(/\s[0-9A-F]{64}$/igm);
    //                 validator.hex = validator.hex[0].trim();
    //                 validator.pub_key = result.match(/{".*"}/igm);
    //                 validator.pub_key = JSON.parse(validator.pub_key[0].trim());
    //                 let re = new RegExp(Meteor.settings.public.bech32PrefixAccPub+".*$","igm");
    //                 validator.cosmosaccpub = result.match(re);
    //                 validator.cosmosaccpub = validator.cosmosaccpub[0].trim();
    //                 re = new RegExp(Meteor.settings.public.bech32PrefixValPub+".*$","igm");
    //                 validator.operator_pubkey = result.match(re);
    //                 validator.operator_pubkey = validator.operator_pubkey[0].trim();
    //                 Validators.upsert({consensus_pubkey:msg[m].value.pubkey},validator);
    //                 VotingPowerHistory.insert({
    //                     address: validator.address,
    //                     prev_voting_power: 0,
    //                     voting_power: validator.voting_power,
    //                     type: 'add',
    //                     height: tx.height+2,
    //                     block_time: blockTime
    //                 });
    //             })
    //         }
    //     }
    // }

    let txId = Transactions.insert(tx);

    if (txId) {
      return txId;
    } else return false;
  },
  'Transactions.findDelegation': function (address, height) {
    // following cosmos-sdk/x/slashing/spec/06_events.md and cosmos-sdk/x/staking/spec/06_events.md
    return Transactions.find({
      $or: [{
        $and: [{
          "events.type": "delegate"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.attributes.key": "action"
        }, {
          "events.attributes.value": "unjail"
        }, {
          "events.attributes.key": "sender"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "create_validator"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "unbond"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "redelegate"
        }, {
          "events.attributes.key": "destination_validator"
        }, {
          "events.attributes.value": address
        }]
      }],
      "code": {
        $exists: false
      },
      height: {
        $lt: height
      }
    }, {
      sort: {
        height: -1
      },
      limit: 1
    }).fetch();
  },
  'Transactions.findUser': function (address) {
    let fields = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    // address is either delegator address or validator operator address
    let validator;
    if (!fields) fields = {
      address: 1,
      description: 1,
      operator_address: 1,
      delegator_address: 1
    };

    if (address.includes(Meteor.settings.public.bech32PrefixValAddr)) {
      // validator operator address
      validator = Validators.findOne({
        operator_address: address
      }, {
        fields
      });
    } else if (address.includes(Meteor.settings.public.bech32PrefixAccAddr)) {
      // delegator address
      validator = Validators.findOne({
        delegator_address: address
      }, {
        fields
      });
    } else if (address.length === AddressLength) {
      validator = Validators.findOne({
        address: address
      }, {
        fields
      });
    }

    if (validator) {
      return validator;
    }

    return false;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/server/publications.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Transactions;
module.link("../transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 1);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 2);
publishComposite('transactions.list', function () {
  let limit = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 30;
  return {
    find() {
      return Transactions.find({}, {
        sort: {
          height: -1
        },
        limit: limit
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.validator', function (validatorAddress, delegatorAddress) {
  let limit = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 100;
  let query = {};

  if (validatorAddress && delegatorAddress) {
    query = {
      $or: [{
        "events.attributes.value": validatorAddress
      }, {
        "events.attributes.value": delegatorAddress
      }]
    };
  }

  if (!validatorAddress && delegatorAddress) {
    query = {
      "events.attributes.value": delegatorAddress
    };
  }

  return {
    find() {
      return Transactions.find(query, {
        sort: {
          height: -1
        },
        limit: limit
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.findOne', function (hash) {
  return {
    find() {
      return Transactions.find({
        txhash: hash
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.height', function (height) {
  return {
    find() {
      return Transactions.find({
        height: height
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactions.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/transactions.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Transactions: () => Transactions
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Blockscon;
module.link("../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 1);
let TxIcon;
module.link("../../ui/components/Icons.jsx", {
  TxIcon(v) {
    TxIcon = v;
  }

}, 2);
const Transactions = new Mongo.Collection('transactions');
Transactions.helpers({
  block() {
    return Blockscon.findOne({
      height: this.height
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validators":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 1);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 2);
let Delegations;
module.link("../../delegations/delegations.js", {
  Delegations(v) {
    Delegations = v;
  }

}, 3);
Meteor.methods({
  'Validators.findCreateValidatorTime': function (address) {
    // look up the create validator time to consider if the validator has never updated the commission
    let tx = Transactions.findOne({
      $and: [{
        "tx.value.msg.value.delegator_address": address
      }, {
        "tx.value.msg.type": "cosmos-sdk/MsgCreateValidator"
      }, {
        code: {
          $exists: false
        }
      }]
    });

    if (tx) {
      let block = Blockscon.findOne({
        height: tx.height
      });

      if (block) {
        return block.time;
      }
    } else {
      // no such create validator tx
      return false;
    }
  },

  // async 'Validators.getAllDelegations'(address){
  'Validators.getAllDelegations'(address) {
    let url = LCD + '/staking/validators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        delegations = JSON.parse(delegations.content).result;
        delegations.forEach((delegation, i) => {
          if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
        });
        return delegations;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/server/publications.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Validators;
module.link("../validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
let ValidatorRecords;
module.link("../../records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  }

}, 2);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 3);
Meteor.publish('validators.all', function () {
  let sort = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "description.moniker";
  let direction = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : -1;
  let fields = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return Validators.find({}, {
    sort: {
      [sort]: direction
    },
    fields: fields
  });
});
publishComposite('validators.firstSeen', {
  find() {
    return Validators.find({});
  },

  children: [{
    find(val) {
      return ValidatorRecords.find({
        address: val.address
      }, {
        sort: {
          height: 1
        },
        limit: 1
      });
    }

  }]
});
Meteor.publish('validators.voting_power', function () {
  return Validators.find({
    status: 2,
    jailed: false
  }, {
    sort: {
      voting_power: -1
    },
    fields: {
      address: 1,
      description: 1,
      voting_power: 1,
      profile_url: 1
    }
  });
});
publishComposite('validator.details', function (address) {
  let options = {
    address: address
  };

  if (address.indexOf(Meteor.settings.public.bech32PrefixValAddr) != -1) {
    options = {
      operator_address: address
    };
  }

  return {
    find() {
      return Validators.find(options);
    },

    children: [{
      find(val) {
        return VotingPowerHistory.find({
          address: val.address
        }, {
          sort: {
            height: -1
          },
          limit: 50
        });
      }

    }, {
      find(val) {
        return ValidatorRecords.find({
          address: val.address
        }, {
          sort: {
            height: -1
          },
          limit: Meteor.settings.public.uptimeWindow
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validators.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/validators.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Validators: () => Validators
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let ValidatorRecords;
module.link("../records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  }

}, 1);
let VotingPowerHistory;
module.link("../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 2);
const Validators = new Mongo.Collection('validators');
Validators.helpers({
  firstSeen() {
    return ValidatorRecords.findOne({
      address: this.address
    });
  },

  history() {
    return VotingPowerHistory.find({
      address: this.address
    }, {
      sort: {
        height: -1
      },
      limit: 50
    }).fetch();
  }

}); // Validators.helpers({
//     uptime(){
//         // console.log(this.address);
//         let lastHundred = ValidatorRecords.find({address:this.address}, {sort:{height:-1}, limit:100}).fetch();
//         console.log(lastHundred);
//         let uptime = 0;
//         for (i in lastHundred){
//             if (lastHundred[i].exists){
//                 uptime+=1;
//             }
//         }
//         return uptime;
//     }
// })
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"voting-power":{"server":{"publications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/voting-power/server/publications.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"history.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/voting-power/history.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  VotingPowerHistory: () => VotingPowerHistory
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const VotingPowerHistory = new Mongo.Collection('voting_power_history');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"evidences":{"evidences.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/evidences/evidences.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Evidences: () => Evidences
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Evidences = new Mongo.Collection('evidences');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validator-sets":{"validator-sets.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validator-sets/validator-sets.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  ValidatorSets: () => ValidatorSets
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const ValidatorSets = new Mongo.Collection('validator_sets');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"startup":{"both":{"index.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/both/index.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Import modules used by both client and server through a single index entry point
// e.g. useraccounts configuration file.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"create-indexes.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/create-indexes.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Blockscon;
module.link("../../api/blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 0);
let Proposals;
module.link("../../api/proposals/proposals.js", {
  Proposals(v) {
    Proposals = v;
  }

}, 1);
let ValidatorRecords, Analytics, MissedBlocksStats, MissedBlocks, AverageData, AverageValidatorData;
module.link("../../api/records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  },

  MissedBlocks(v) {
    MissedBlocks = v;
  },

  AverageData(v) {
    AverageData = v;
  },

  AverageValidatorData(v) {
    AverageValidatorData = v;
  }

}, 2);
let Transactions;
module.link("../../api/transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 3);
let ValidatorSets;
module.link("../../api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 4);
let Validators;
module.link("../../api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 5);
let VotingPowerHistory;
module.link("../../api/voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 6);
let Evidences;
module.link("../../api/evidences/evidences.js", {
  Evidences(v) {
    Evidences = v;
  }

}, 7);
let CoinStats;
module.link("../../api/coin-stats/coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 8);
let ChainStates;
module.link("../../api/chain/chain.js", {
  ChainStates(v) {
    ChainStates = v;
  }

}, 9);
ChainStates.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
Blockscon.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
Blockscon.rawCollection().createIndex({
  proposerAddress: 1
});
Evidences.rawCollection().createIndex({
  height: -1
});
Proposals.rawCollection().createIndex({
  proposalId: 1
}, {
  unique: true
});
ValidatorRecords.rawCollection().createIndex({
  address: 1,
  height: -1
}, {
  unique: 1
});
ValidatorRecords.rawCollection().createIndex({
  address: 1,
  exists: 1,
  height: -1
});
Analytics.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
MissedBlocks.rawCollection().createIndex({
  proposer: 1,
  voter: 1,
  updatedAt: -1
});
MissedBlocks.rawCollection().createIndex({
  proposer: 1,
  blockHeight: -1
});
MissedBlocks.rawCollection().createIndex({
  voter: 1,
  blockHeight: -1
});
MissedBlocks.rawCollection().createIndex({
  voter: 1,
  proposer: 1,
  blockHeight: -1
}, {
  unique: true
});
MissedBlocksStats.rawCollection().createIndex({
  proposer: 1
});
MissedBlocksStats.rawCollection().createIndex({
  voter: 1
});
MissedBlocksStats.rawCollection().createIndex({
  proposer: 1,
  voter: 1
}, {
  unique: true
});
AverageData.rawCollection().createIndex({
  type: 1,
  createdAt: -1
}, {
  unique: true
});
AverageValidatorData.rawCollection().createIndex({
  proposerAddress: 1,
  createdAt: -1
}, {
  unique: true
}); // Status.rawCollection.createIndex({})

Transactions.rawCollection().createIndex({
  txhash: 1
}, {
  unique: true
});
Transactions.rawCollection().createIndex({
  height: -1
}); // Transactions.rawCollection().createIndex({action:1});

Transactions.rawCollection().createIndex({
  "events.attributes.key": 1
});
Transactions.rawCollection().createIndex({
  "events.attributes.value": 1
});
ValidatorSets.rawCollection().createIndex({
  block_height: -1
});
Validators.rawCollection().createIndex({
  address: 1
}, {
  unique: true,
  partialFilterExpression: {
    address: {
      $exists: true
    }
  }
});
Validators.rawCollection().createIndex({
  consensus_pubkey: 1
}, {
  unique: true
});
Validators.rawCollection().createIndex({
  "pub_key.value": 1
}, {
  unique: true,
  partialFilterExpression: {
    "pub_key.value": {
      $exists: true
    }
  }
});
VotingPowerHistory.rawCollection().createIndex({
  address: 1,
  height: -1
});
VotingPowerHistory.rawCollection().createIndex({
  type: 1
});
CoinStats.rawCollection().createIndex({
  last_updated_at: -1
}, {
  unique: true
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/index.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("./util.js");
module.link("./register-api.js");
module.link("./create-indexes.js");
let onPageLoad;
module.link("meteor/server-render", {
  onPageLoad(v) {
    onPageLoad = v;
  }

}, 0);
let Helmet;
module.link("react-helmet", {
  Helmet(v) {
    Helmet = v;
  }

}, 1);
// import App from '../../ui/App.jsx';
onPageLoad(sink => {
  // const context = {};
  // const sheet = new ServerStyleSheet()
  // const html = renderToString(sheet.collectStyles(
  //     <StaticRouter location={sink.request.url} context={context}>
  //         <App />
  //     </StaticRouter>
  //   ));
  // sink.renderIntoElementById('app', html);
  const helmet = Helmet.renderStatic();
  sink.appendToHead(helmet.meta.toString());
  sink.appendToHead(helmet.title.toString()); // sink.appendToHead(sheet.getStyleTags());
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"register-api.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/register-api.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("../../api/ledger/server/methods.js");
module.link("../../api/chain/server/methods.js");
module.link("../../api/chain/server/publications.js");
module.link("../../api/blocks/server/methods.js");
module.link("../../api/blocks/server/publications.js");
module.link("../../api/validators/server/methods.js");
module.link("../../api/validators/server/publications.js");
module.link("../../api/records/server/methods.js");
module.link("../../api/records/server/publications.js");
module.link("../../api/proposals/server/methods.js");
module.link("../../api/proposals/server/publications.js");
module.link("../../api/voting-power/server/publications.js");
module.link("../../api/transactions/server/methods.js");
module.link("../../api/transactions/server/publications.js");
module.link("../../api/delegations/server/methods.js");
module.link("../../api/delegations/server/publications.js");
module.link("../../api/status/server/publications.js");
module.link("../../api/accounts/server/methods.js");
module.link("../../api/coin-stats/server/methods.js");
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"util.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/util.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let bech32;
module.link("bech32", {
  default(v) {
    bech32 = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let cheerio;
module.link("cheerio", {
  "*"(v) {
    cheerio = v;
  }

}, 2);

// Load future from fibers
var Future = Npm.require("fibers/future"); // Load exec


var exec = Npm.require("child_process").exec;

function toHexString(byteArray) {
  return byteArray.map(function (byte) {
    return ('0' + (byte & 0xFF).toString(16)).slice(-2);
  }).join('');
}

Meteor.methods({
  pubkeyToBech32: function (pubkey, prefix) {
    // '1624DE6420' is ed25519 pubkey prefix
    let pubkeyAminoPrefix = Buffer.from('1624DE6420', 'hex');
    let buffer = Buffer.alloc(37);
    pubkeyAminoPrefix.copy(buffer, 0);
    Buffer.from(pubkey.value, 'base64').copy(buffer, pubkeyAminoPrefix.length);
    return bech32.encode(prefix, bech32.toWords(buffer));
  },
  bech32ToPubkey: function (pubkey) {
    // '1624DE6420' is ed25519 pubkey prefix
    let pubkeyAminoPrefix = Buffer.from('1624DE6420', 'hex');
    let buffer = Buffer.from(bech32.fromWords(bech32.decode(pubkey).words));
    return buffer.slice(pubkeyAminoPrefix.length).toString('base64');
  },
  getDelegator: function (operatorAddr) {
    let address = bech32.decode(operatorAddr);
    return bech32.encode(Meteor.settings.public.bech32PrefixAccAddr, address.words);
  },
  getKeybaseTeamPic: function (keybaseUrl) {
    let teamPage = HTTP.get(keybaseUrl);

    if (teamPage.statusCode == 200) {
      let page = cheerio.load(teamPage.content);
      return page(".kb-main-card img").attr('src');
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"ui":{"components":{"Icons.jsx":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/ui/components/Icons.jsx                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  DenomSymbol: () => DenomSymbol,
  ProposalStatusIcon: () => ProposalStatusIcon,
  VoteIcon: () => VoteIcon,
  TxIcon: () => TxIcon,
  InfoIcon: () => InfoIcon
});
let React;
module.link("react", {
  default(v) {
    React = v;
  }

}, 0);
let UncontrolledTooltip;
module.link("reactstrap", {
  UncontrolledTooltip(v) {
    UncontrolledTooltip = v;
  }

}, 1);

const DenomSymbol = props => {
  switch (props.denom) {
    case "steak":
      return '🥩';

    default:
      return '🍅';
  }
};

const ProposalStatusIcon = props => {
  switch (props.status) {
    case 'Passed':
      return React.createElement("i", {
        className: "fas fa-check-circle text-success"
      });

    case 'Rejected':
      return React.createElement("i", {
        className: "fas fa-times-circle text-danger"
      });

    case 'Removed':
      return React.createElement("i", {
        className: "fas fa-trash-alt text-dark"
      });

    case 'DepositPeriod':
      return React.createElement("i", {
        className: "fas fa-battery-half text-warning"
      });

    case 'VotingPeriod':
      return React.createElement("i", {
        className: "fas fa-hand-paper text-info"
      });

    default:
      return React.createElement("i", null);
  }
};

const VoteIcon = props => {
  switch (props.vote) {
    case 'yes':
      return React.createElement("i", {
        className: "fas fa-check text-success"
      });

    case 'no':
      return React.createElement("i", {
        className: "fas fa-times text-danger"
      });

    case 'abstain':
      return React.createElement("i", {
        className: "fas fa-user-slash text-warning"
      });

    case 'no_with_veto':
      return React.createElement("i", {
        className: "fas fa-exclamation-triangle text-info"
      });

    default:
      return React.createElement("i", null);
  }
};

const TxIcon = props => {
  if (props.valid) {
    return React.createElement("span", {
      className: "text-success text-nowrap"
    }, React.createElement("i", {
      className: "fas fa-check-circle"
    }));
  } else {
    return React.createElement("span", {
      className: "text-danger text-nowrap"
    }, React.createElement("i", {
      className: "fas fa-times-circle"
    }));
  }
};

class InfoIcon extends React.Component {
  constructor(props) {
    super(props);
    this.ref = React.createRef();
  }

  render() {
    return [React.createElement("i", {
      key: "icon",
      className: "material-icons info-icon",
      ref: this.ref
    }, "info"), React.createElement(UncontrolledTooltip, {
      key: "tooltip",
      placement: "right",
      target: this.ref
    }, this.props.children ? this.props.children : this.props.tooltipText)];
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"both":{"i18n":{"en-us.i18n.yml.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/en-us.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('en-US','',{"common":{"height":"Height","voter":"Voter","votingPower":"Voting Power","addresses":"Addresses","amounts":"Amounts","delegators":"delegators","block":"block","blocks":"blocks","precommit":"precommit","precommits":"precommits","last":"last","backToList":"Back to List","information":"Information","time":"Time","hash":"Hash","more":"More","fullStop":".","searchPlaceholder":"Search with tx hash / block height / address","cancel":"Cancel","retry":"Retry"},"navbar":{"siteName":"The Big Dipper","version":"beta","validators":"Validators","blocks":"Blocks","transactions":"Transactions","proposals":"Proposals","votingPower":"Voting Power","lang":"ENG","english":"English","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"Fork me!"},"consensus":{"consensusState":"Consensus State","round":"Round","step":"Step"},"chainStates":{"price":"Price","marketCap":"Market Cap","inflation":"Inflation","communityPool":"Community Pool"},"chainStatus":{"startMessage":"The chain is going to start in","stopWarning":"The chain appears to be stopped for <em>{$time}</em>! Feed me with new blocks 😭!","latestHeight":"Latest Block Height","averageBlockTime":"Average Block Time","all":"All","now":"Now","allTime":"All Time","lastMinute":"Last Minute","lastHour":"Last Hour","lastDay":"Last Day","seconds":"seconds","activeValidators":"Active Validators","outOfValidators":"out of {$totalValidators} validators","onlineVotingPower":"Online Voting Power","fromTotalStakes":"{$percent} from {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"Block Time History","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"Random Validators","moniker":"Moniker","uptime":"Uptime","selfPercentage":"Self%","commission":"Commission","lastSeen":"Last Seen","status":"Status","jailed":"Jailed","navActive":"Active","navInactive":"Inactive","active":"Active Validators","inactive":"Inactive Validators","listOfActive":"Here is a list of active validators.","listOfInactive":"Here is a list of inactive validators.","validatorDetails":"Validator Details","lastNumBlocks":"Last {$numBlocks} blocks","validatorInfo":"Validator Info","operatorAddress":"Operator Address","selfDelegationAddress":"Self-Delegate Address","commissionRate":"Commission Rate","maxRate":"Max Rate","maxChangeRate":"Max Change Rate","selfDelegationRatio":"Self Delegation Ratio","proposerPriority":"Proposer Priority","delegatorShares":"Delegator Shares","userDelegateShares":"Shares Delegated by you","tokens":"Tokens","unbondingHeight":"Unbonding Height","unbondingTime":"Unbonding Time","powerChange":"Power Change","delegations":"Delegations","transactions":"Transactions","validatorNotExists":"Validator does not exist.","backToValidator":"Back to Validator","missedBlocks":"Missed Blocks","missedPrecommits":"Missed Precommits","missedBlocksTitle":"Missed blocks of {$moniker}","totalMissed":"Total missed","block":"Block","missedCount":"Miss Count","iDontMiss":"I do not miss ","lastSyncTime":"Last sync time","delegator":"Delegator","amount":"Amount"},"blocks":{"block":"Block","proposer":"Proposer","latestBlocks":"Latest blocks","noBlock":"No block.","numOfTxs":"No. of Txs","numOfTransactions":"No. of Transactions","notFound":"No such block found."},"transactions":{"transaction":"Transaction","transactions":"Transactions","notFound":"No transaction found.","activities":"Activities","txHash":"Tx Hash","valid":"Valid","fee":"Fee","gasUsedWanted":"Gas (used / wanted)","noTxFound":"No such transaction found.","noValidatorTxsFound":"No transaction related to this validator was found.","memo":"Memo","transfer":"Transfer","staking":"Staking","distribution":"Distribution","governance":"Governance","slashing":"Slashing"},"proposals":{"notFound":"No proposal found.","listOfProposals":"Here is a list of governance proposals.","proposer":"Proposer","proposal":"proposal","proposals":"Proposals","proposalID":"Proposal ID","title":"Title","status":"Status","submitTime":"Submit Time","depositEndTime":"Deposit End Time","votingStartTime":"Voting Start Time","votingEndTime":"End Voting Time","totalDeposit":"Total Deposit","description":"Description","proposalType":"Proposal Type","proposalStatus":"Proposal Status","notStarted":"not started","final":"final","deposit":"Deposit","tallyResult":"Tally Result","yes":"Yes","abstain":"Abstain","no":"No","noWithVeto":"No with Veto","percentageVoted":"<span class=\"text-info\">{$percent}</span> of online voting power has been voted.","validMessage":"This proposal is {$tentative}<strong>valid</strong>.","invalidMessage":"Less than {$quorum} of voting power is voted. This proposal is <strong>invalid</strong>.","moreVoteMessage":"It will be a valid proposal once <span class=\"text-info\">{$moreVotes}</span> more votes are casted."},"votingPower":{"distribution":"Voting Power Distribution","pareto":"Pareto Principle (20/80 rule)","minValidators34":"Min no. of validators hold 34%+ power"},"accounts":{"accountDetails":"Account Details","available":"Available","delegated":"Delegated","unbonding":"Unbonding","rewards":"Rewards","total":"Total","notFound":"This account does not exist. Are you looking for a wrong address?","validators":"Validators","shares":"Shares","mature":"Mature","no":"No ","delegation":"Delegation","plural":"s","signOut":"Sign out","signInText":"You are signed in as ","toLoginAs":"To log in as","signInWithLedger":"Sign In With Ledger","signInWarning":"Please make sure your Ledger device is connected and <strong class=\"text-primary\">Cosmos App 1.5.0 or above</strong> is opened.","pleaseAccept":"please accept in your Ledger device."},"activities":{"single":"A","happened":"happened.","senders":"The following sender(s)","sent":"sent","receivers":"to the following receipient(s)","received":"received","failedTo":"failed to ","to":"to","from":"from","operatingAt":"operating at","withMoniker":"with moniker","withTitle":"with title","withA":"with a"},"messageTypes":{"send":"Send","multiSend":"Multi Send","createValidator":"Create Validator","editValidator":"Edit Validator","delegate":"Delegate","undelegate":"Undelegate","redelegate":"Redelegate","submitProposal":"Submit Proposal","deposit":"Deposit","vote":"Vote","withdrawComission":"Withdraw Commission","withdrawReward":"Withdraw Reward","modifyWithdrawAddress":"Modify Withdraw Address","unjail":"Unjail","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"zh-hans.i18n.yml.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/zh-hans.i18n.yml.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('zh-Hans','',{"common":{"height":"高度","voter":"投票人","votingPower":"投票权","addresses":"地址","amounts":"数量","delegators":"委托人","block":"区块","blocks":"区块","precommit":"建块前保证","precommits":"建块前保证","last":"最后","backToList":"回到列表","information":"资讯","time":"时间","hash":"哈希","more":"更多","fullStop":"。","searchPlaceholder":"搜寻交易哈希 / 区块高度 / 地址","cancel":"取消","retry":"重试"},"navbar":{"siteName":"北斗","version":"beta","validators":"验证人","blocks":"区块","transactions":"交易","proposals":"治理提案","votingPower":"投票权分布","lang":"中文（简）","english":"English","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"Fork me!"},"consensus":{"consensusState":"共识状态","round":"轮数","step":"阶数"},"chainStates":{"price":"价格","marketCap":"市值","inflation":"通胀率","communityPool":"社区储备"},"chainStatus":{"startMessage":"这链将还有以下时间便会开始","stopWarning":"这链似乎已经停了 <em>{$time}</em>！ 请继续喂我吃新的区块 😭!","latestHeight":"最新区块高度","averageBlockTime":"平均区块时间","all":"全部","now":"现在","allTime":"全部","lastMinute":"前一分钟","lastHour":"前一小时","lastDay":"前一天","seconds":"秒","activeValidators":"有效验证人","outOfValidators":"来自总共 {$totalValidators} 个验证人","onlineVotingPower":"在线投票权","fromTotalStakes":"为 {$totalStakes} 颗 {$denom} 的 {$percent}"},"analytics":{"blockTimeHistory":"在线投票权","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"随机验证人","moniker":"验证人代号","uptime":"上线时间比重","selfPercentage":"自我委托%","commission":"佣金","lastSeen":"最后投票时间","status":"状态","jailed":"被禁制","navActive":"有效","navInactive":"无效","active":"有效验证人","inactive":"无效验证人","listOfActive":"这名单显示所有有效验证人","listOfInactive":"这名单显示所有无效验证人","validatorDetails":"验证人详情","lastNumBlocks":"最后 {$numBlocks} 个区块","validatorInfo":"验证人资讯","operatorAddress":"操作地址","selfDelegationAddress":"自我委托地址","commissionRate":"佣金","maxRate":"最大佣金限制","maxChangeRate":"每天最大佣金变化限制","selfDelegationRatio":"自我委托比例","proposerPriority":"建块优先权","delegatorShares":"委托股数","userDelegateShares":"你委托的股数","tokens":"代币数量","unbondingHeight":"解绑高度","unbondingTime":"解绑时间","powerChange":"投票权变更","delegations":"委托","transactions":"交易","validatorNotExists":"验证人不存在。","backToValidator":"回到验证人页面","missedBlocks":"错过了的区块","missedPrecommits":"遗留了的建块前保证","missedBlocksTitle":"错过了 {$moniker} 的区块","totalMissed":"一共错过了","block":"区块","missedCount":"错过数量","iDontMiss":"我不会错过任何一个","lastSyncTime":"上一次同步时间","delegator":"委托人","amount":"数量"},"blocks":{"proposer":"建块人","block":"区块","latestBlocks":"最近区块","noBlock":"没有区块。","numOfTxs":"交易数量","numOfTransactions":"交易数量","notFound":"没有这个区块。"},"transactions":{"transaction":"交易","transactions":"交易","notFound":"沒有交易。","activities":"活动","txHash":"交易哈希","valid":"有效","fee":"费用","gasUsedWanted":"瓦斯 (已用 / 要求)","noTxFound":"没有这笔交易。","noValidatorTxsFound":"没有跟这个验证人有关的交易","memo":"备忘录","transfer":"代币转移","staking":"委托","distribution":"收益分配","governance":"链上治理","slashing":"削减"},"proposals":{"notFound":"没有治理提案","listOfProposals":"这名单显示所有治理提案","proposer":"提案人","proposal":"治理提案","proposals":"治理提案","proposalID":"提案编号","title":"主题","status":"状态","submitTime":"提案时间","depositEndTime":"存入押金","votingStartTime":"投票开始时间","votingEndTime":"投票结束时间","totalDeposit":"押金总额","description":"详细内容","proposalType":"提案类型","proposalStatus":"提案状态","notStarted":"未开始","final":"最后结果","deposit":"押金","tallyResult":"投票结果","yes":"赞成","abstain":"弃权","no":"反对","noWithVeto":"强烈反对","percentageVoted":"现时在线投票权的投票率是 <span class=\"text-info\">{$percent}</span>。","validMessage":"这个提案 {$tentative} <strong>有效</strong>.","invalidMessage":"已投票的在线投票权少于 {$quorum}。这个提案 <strong>無效</strong>。","moreVoteMessage":"当再有多 <span class=\"text-info\">{$moreVotes}</span> 投票权投了票的话，这个提案将会有效。"},"votingPower":{"distribution":"投票权分布","pareto":"帕累托原则 (20/80 定率)","minValidators34":"最少合共有超过 34% 投票权的验证人"},"accounts":{"accountDetails":"帐户详情","available":"可用的","delegated":"委托中","unbonding":"解绑中","rewards":"未取回收益","total":"总共","notFound":"这个帐户不存在。你是否在查看一个错误的地址？","validators":"验证人","shares":"股数","mature":"成熟日期","no":"没有","delegation":"委托","plural":"","signOut":"登出","signInText":"你已登录以下帐户","toLoginAs":"登录以下帐户","signInWithLedger":"透过 Ledger 登录","signInWarning":"请确定你已经连接 Ledger 设备，并已开启 <strong class=\"text-primary\">Cosmos App 版本 1.5.0 或以上</strong>。","pleaseAccept":"请从你的 Ledger 设备确认。"},"activities":{"single":"一个","happened":"发生了","senders":"以下的帐户","sent":"发了","receivers":"到以下的帐户","received":"收到","failedTo":"未能","to":"到","from":"从","operatingAt":"操作地址为","withMoniker":"而验证人代号为","withTitle":"治理提案主题为","withA":"投了"},"messageTypes":{"send":"发送","multiSend":"多重发送","createValidator":"建立验证人","editValidator":"编辑验证人资料","delegate":"委托","undelegate":"解委托","redelegate":"转委托","submitProposal":"提交议案","deposit":"存入","vote":"投票","withdrawComission":"提取手续费","withdrawReward":"提取收益","modifyWithdrawAddress":"更改收益取回地址","unjail":"赦免","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"zh-hant.i18n.yml.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/zh-hant.i18n.yml.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('zh-Hant','',{"common":{"height":"高度","voter":"投票人","votingPower":"投票權","addresses":"地址","amounts":"數量","delegators":"委托人","block":"區塊","blocks":"區塊","precommit":"建塊前保證","precommits":"建塊前保證","last":"最後","backToList":"回到列表","information":"資訊","time":"時間","hash":"哈希","more":"更多","fullStop":"。","searchPlaceholder":"搜尋交易哈希 / 區塊高度 / 地址","cancel":"取消","retry":"重試"},"navbar":{"siteName":"北斗","version":"beta","validators":"驗證人","blocks":"區塊","transactions":"交易","proposals":"治理提案","votingPower":"投票權分佈","lang":"中文（繁）","english":"English","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"Fork me!"},"consensus":{"consensusState":"共識狀態","round":"輪數","step":"階數"},"chainStates":{"price":"價格","marketCap":"市值","inflation":"通漲率","communityPool":"社區儲備"},"chainStatus":{"startMessage":"這鏈將還有以下時間便會開始","stopWarning":"這鏈似乎已經停了 <em>{$time}</em>！ 請繼續餵我吃新的區塊 😭!","latestHeight":"最新區塊高度","averageBlockTime":"平均區塊時間","all":"全部","now":"現在","allTime":"全部","lastMinute":"前一分鐘","lastHour":"前一小時","lastDay":"前一天","seconds":"秒","activeValidators":"有效驗證人","outOfValidators":"來自總共 {$totalValidators} 個驗證人","onlineVotingPower":"在線投票權","fromTotalStakes":"為 {$totalStakes} 顆 {$denom} 的 {$percent}"},"analytics":{"blockTimeHistory":"在線投票權","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"隨機驗證人","moniker":"驗證人代號","uptime":"上線時間比重","selfPercentage":"自我委托%","commission":"佣金","lastSeen":"最後投票時間","status":"狀態","jailed":"被禁制","navActive":"有效","navInactive":"無效","active":"有效驗證人","inactive":"無效驗證人","listOfActive":"這名單顯示所有有效驗證人","listOfInactive":"這名單顯示所有無效驗證人","validatorDetails":"驗證人詳情","lastNumBlocks":"最後 {$numBlocks} 個區塊","validatorInfo":"驗證人資訊","operatorAddress":"操作地址","selfDelegationAddress":"自我委托地址","commissionRate":"佣金","maxRate":"最大佣金限制","maxChangeRate":"每天最大佣金變化限制","selfDelegationRatio":"自我委托比列","proposerPriority":"建塊優先權","delegatorShares":"委托股數","userDelegateShares":"你委托的股數","tokens":"代幣數量","unbondingHeight":"解綁高度","unbondingTime":"解綁時間","powerChange":"投票權變更","delegations":"委托","transactions":"交易","validatorNotExists":"驗證人不存在。","backToValidator":"回到驗證人頁面","missedBlocks":"錯過了的區塊","missedPrecommits":"遺留了的建塊前保證","missedBlocksTitle":"錯過了 {$moniker} 的區塊","totalMissed":"一共錯過了","block":"區塊","missedCount":"錯過數量","iDontMiss":"我不會錯過任何一個","lastSyncTime":"上一次同步時間","delegator":"委托人","amount":"數量"},"blocks":{"proposer":"建塊人","block":"區塊","latestBlocks":"最近區塊","noBlock":"沒有區塊。","numOfTxs":"交易數量","numOfTransactions":"交易數量","notFound":"沒有這個區塊。"},"transactions":{"transaction":"交易","transactions":"交易","notFound":"沒有交易。","activities":"活動","txHash":"交易哈希","valid":"有效","fee":"費用","gasUsedWanted":"瓦斯 (已用 / 要求)","noTxFound":"沒有這筆交易。","noValidatorTxsFound":"沒有跟這個驗證人有關的交易","memo":"備忘錄","transfer":"代幣轉移","staking":"委托","distribution":"收益分配","governance":"鏈上治理","slashing":"削減"},"proposals":{"notFound":"沒有治理提案","listOfProposals":"這名單顯示所有治理提案","proposer":"提案人","proposal":"治理提案","proposals":"治理提案","proposalID":"提案編號","title":"主題","status":"狀態","submitTime":"提案時間","depositEndTime":"存入押金","votingStartTime":"投票開始時間","votingEndTime":"投票結束時間","totalDeposit":"押金總額","description":"詳細內容","proposalType":"提案類型","proposalStatus":"提案狀態","notStarted":"未開始","final":"最後結果","deposit":"押金","tallyResult":"投票結果","yes":"贊成","abstain":"棄權","no":"反對","noWithVeto":"強烈反對","percentageVoted":"現時在線投票權的投票率是 <span class=\"text-info\">{$percent}</span>。","validMessage":"這個提案 {$tentative} <strong>有效</strong>.","invalidMessage":"已投票的在線投票權少於 {$quorum}。這個 <strong>無效</strong>。","moreVoteMessage":"當再有多 <span class=\"text-info\">{$moreVotes}</span> 投票權投了票的話，這個提案將會有效。"},"votingPower":{"distribution":"投票權分佈","pareto":"帕累托原則 (20/80 定率)","minValidators34":"最少合共有超過 34% 投票權的驗證人"},"accounts":{"accountDetails":"帳戶詳情","available":"可用的","delegated":"委托中","unbonding":"解綁中","rewards":"未取回收益","total":"總共","notFound":"這個帳戶不存在。你是否在查看一個錯誤的地址？","validators":"驗證人","shares":"股數","mature":"成熟日期","no":"沒有","delegation":"委托","plural":"","signOut":"登出","signInText":"你已登入以下帳戶","toLoginAs":"登入以下帳戶","signInWithLedger":"透過 Ledger 登入","signInWarning":"請確定你已經連接 Ledger 設備，並已開啓 <strong class=\"text-primary\">Cosmos App 版本 1.5.0 或以上</strong>。","pleaseAccept":"請從你的 Ledger 設備確認。"},"activities":{"single":"一個","happened":"發生了","senders":"以下的帳戶","sent":"發了","receivers":"到以下的帳戶","received":"收到","failedTo":"未能","to":"到","from":"從","operatingAt":"操作地止為","withMoniker":"而驗證人代號為","withTitle":"治理提案主題為","withA":"投了"},"messageTypes":{"send":"發送","multiSend":"多重發送","createValidator":"建立驗證人","editValidator":"編輯驗證人資料","delegate":"委托","undelegate":"解委托","redelegate":"轉委托","submitProposal":"提交議案","deposit":"存入","vote":"投票","withdrawComission":"提取手續費","withdrawReward":"提取收益","modifyWithdrawAddress":"更改收益取回地址","unjail":"赦免","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"utils":{"coins.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/utils/coins.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => Coin
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let numbro;
module.link("numbro", {
  default(v) {
    numbro = v;
  }

}, 1);

autoformat = value => {
  let formatter = '0,0.0000';
  value = Math.round(value * 1000) / 1000;
  if (Math.round(value) === value) formatter = '0,0';else if (Math.round(value * 10) === value * 10) formatter = '0,0.0';else if (Math.round(value * 100) === value * 100) formatter = '0,0.00';else if (Math.round(value * 1000) === value * 1000) formatter = '0,0.000';
  return numbro(value).format(formatter);
};

class Coin {
  constructor(amount) {
    let denom = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    if (typeof amount === 'object') ({
      amount,
      denom
    } = amount);

    if (!denom || denom.toLowerCase() === Coin.MintingDenom.toLowerCase()) {
      this._amount = Number(amount);
    } else if (denom.toLowerCase() === Coin.StakingDenom.toLowerCase()) {
      this._amount = Number(amount) * Coin.StakingFraction;
    } else {
      throw Error("unsupported denom ".concat(denom));
    }
  }

  get amount() {
    return this._amount;
  }

  get stakingAmount() {
    return this._amount / Coin.StakingFraction;
  }

  toString(precision) {
    // default to display in mint denom if it has more than 4 decimal places
    let minStake = Coin.StakingFraction / (precision ? Math.pow(10, precision) : 10000);

    if (this.amount < minStake) {
      return "".concat(numbro(this.amount).format('0,0'), " ").concat(Coin.MintingDenom);
    } else {
      return "".concat(precision ? numbro(this.stakingAmount).format('0,0.' + '0'.repeat(precision)) : autoformat(this.stakingAmount), " ").concat(Coin.StakingDenom);
    }
  }

  mintString(formatter) {
    let amount = this.amount;

    if (formatter) {
      amount = numbro(amount).format(formatter);
    }

    return "".concat(amount, " ").concat(Coin.MintingDenom);
  }

  stakeString(formatter) {
    let amount = this.stakingAmount;

    if (formatter) {
      amount = numbro(amount).format(formatter);
    }

    return "".concat(amount, " ").concat(Coin.StakingDenom);
  }

}

Coin.StakingDenom = Meteor.settings.public.stakingDenom;
Coin.StakingDenomPlural = Meteor.settings.public.stakingDenomPlural || Coin.StakingDenom + 's';
Coin.MintingDenom = Meteor.settings.public.mintingDenom;
Coin.StakingFraction = Number(Meteor.settings.public.stakingFraction);
Coin.MinStake = 1 / Number(Meteor.settings.public.stakingFraction);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("/imports/startup/server");
module.link("/imports/startup/both");
// import moment from 'moment';
// import '/imports/api/blocks/blocks.js';
SYNCING = false;
COUNTMISSEDBLOCKS = false;
COUNTMISSEDBLOCKSSTATS = false;
RPC = Meteor.settings.remote.rpc;
LCD = Meteor.settings.remote.lcd;
timerBlocks = 0;
timerChain = 0;
timerConsensus = 0;
timerProposal = 0;
timerProposalsResults = 0;
timerMissedBlock = 0;
timerDelegation = 0;
timerAggregate = 0;
const DEFAULTSETTINGS = '/default_settings.json';

updateChainStatus = () => {
  Meteor.call('chain.updateStatus', (error, result) => {
    if (error) {
      console.log("updateStatus: " + error);
    } else {
      console.log("updateStatus: " + result);
    }
  });
};

updateBlock = () => {
  Meteor.call('blocks.blocksUpdate', (error, result) => {
    if (error) {
      console.log("updateBlocks: " + error);
    } else {
      console.log("updateBlocks: " + result);
    }
  });
};

getConsensusState = () => {
  Meteor.call('chain.getConsensusState', (error, result) => {
    if (error) {
      console.log("get consensus: " + error);
    }
  });
};

getProposals = () => {
  Meteor.call('proposals.getProposals', (error, result) => {
    if (error) {
      console.log("get proposal: " + error);
    }

    if (result) {
      console.log("get proposal: " + result);
    }
  });
};

getProposalsResults = () => {
  Meteor.call('proposals.getProposalResults', (error, result) => {
    if (error) {
      console.log("get proposals result: " + error);
    }

    if (result) {
      console.log("get proposals result: " + result);
    }
  });
};

updateMissedBlocks = () => {
  Meteor.call('ValidatorRecords.calculateMissedBlocks', (error, result) => {
    if (error) {
      console.log("missed blocks error: " + error);
    }

    if (result) {
      console.log("missed blocks ok:" + result);
    }
  });
  /*
      Meteor.call('ValidatorRecords.calculateMissedBlocksStats', (error, result) =>{
          if (error){
              console.log("missed blocks stats error: "+ error)
          }
          if (result){
              console.log("missed blocks stats ok:" + result);
          }
      });
  */
};

getDelegations = () => {
  Meteor.call('delegations.getDelegations', (error, result) => {
    if (error) {
      console.log("get delegations error: " + error);
    } else {
      console.log("get delegations ok: " + result);
    }
  });
};

aggregateMinutely = () => {
  // doing something every min
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "m", (error, result) => {
    if (error) {
      console.log("aggregate minutely block time error: " + error);
    } else {
      console.log("aggregate minutely block time ok: " + result);
    }
  });
  Meteor.call('coinStats.getCoinStats', (error, result) => {
    if (error) {
      console.log("get coin stats error: " + error);
    } else {
      console.log("get coin stats ok: " + result);
    }
  });
};

aggregateHourly = () => {
  // doing something every hour
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "h", (error, result) => {
    if (error) {
      console.log("aggregate hourly block time error: " + error);
    } else {
      console.log("aggregate hourly block time ok: " + result);
    }
  });
};

aggregateDaily = () => {
  // doing somthing every day
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "d", (error, result) => {
    if (error) {
      console.log("aggregate daily block time error: " + error);
    } else {
      console.log("aggregate daily block time ok: " + result);
    }
  });
  Meteor.call('Analytics.aggregateValidatorDailyBlockTime', (error, result) => {
    if (error) {
      console.log("aggregate validators block time error:" + error);
    } else {
      console.log("aggregate validators block time ok:" + result);
    }
  });
};

Meteor.startup(function () {
  if (Meteor.isDevelopment) {
    let DEFAULTSETTINGSJSON;
    module.link("../default_settings.json", {
      default(v) {
        DEFAULTSETTINGSJSON = v;
      }

    }, 0);
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;
    Object.keys(DEFAULTSETTINGSJSON).forEach(key => {
      if (Meteor.settings[key] == undefined) {
        console.warn("CHECK SETTINGS JSON: ".concat(key, " is missing from settings"));
        Meteor.settings[key] = {};
      }

      Object.keys(DEFAULTSETTINGSJSON[key]).forEach(param => {
        if (Meteor.settings[key][param] == undefined) {
          console.warn("CHECK SETTINGS JSON: ".concat(key, ".").concat(param, " is missing from settings"));
          Meteor.settings[key][param] = DEFAULTSETTINGSJSON[key][param];
        }
      });
    });
  }

  Meteor.call('chain.genesis', (err, result) => {
    if (err) {
      console.log(err);
    }

    if (result) {
      if (Meteor.settings.debug.startTimer) {
        timerConsensus = Meteor.setInterval(function () {
          getConsensusState();
        }, Meteor.settings.params.consensusInterval);
        timerBlocks = Meteor.setInterval(function () {
          updateBlock();
        }, Meteor.settings.params.blockInterval);
        timerChain = Meteor.setInterval(function () {
          updateChainStatus();
        }, Meteor.settings.params.statusInterval);
        timerProposal = Meteor.setInterval(function () {
          getProposals();
        }, Meteor.settings.params.proposalInterval);
        timerProposalsResults = Meteor.setInterval(function () {
          getProposalsResults();
        }, Meteor.settings.params.proposalInterval);
        timerMissedBlock = Meteor.setInterval(function () {
          updateMissedBlocks();
        }, Meteor.settings.params.missedBlocksInterval);
        timerDelegation = Meteor.setInterval(function () {
          getDelegations();
        }, Meteor.settings.params.delegationInterval);
        timerAggregate = Meteor.setInterval(function () {
          let now = new Date();

          if (now.getUTCSeconds() == 0) {
            aggregateMinutely();
          }

          if (now.getUTCMinutes() == 0 && now.getUTCSeconds() == 0) {
            aggregateHourly();
          }

          if (now.getUTCHours() == 0 && now.getUTCMinutes() == 0 && now.getUTCSeconds() == 0) {
            aggregateDaily();
          }
        }, 1000);
      }
    }
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"default_settings.json":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// default_settings.json                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "public": {
    "chainName": "Cosmos Testnet",
    "chainId": "{Chain ID}",
    "gtm": "{Add your Google Tag Manager ID here}",
    "slashingWindow": 10000,
    "uptimeWindow": 250,
    "initialPageSize": 30,
    "bech32PrefixAccAddr": "cosmos",
    "bech32PrefixAccPub": "cosmospub",
    "bech32PrefixValAddr": "cosmosvaloper",
    "bech32PrefixValPub": "cosmosvaloperpub",
    "bech32PrefixConsAddr": "cosmosvalcons",
    "bech32PrefixConsPub": "cosmosvalconspub",
    "stakingDenom": "ATOM",
    "stakingDenomPlural": null,
    "mintingDenom": "uatom",
    "stakingFraction": 1000000,
    "powerReduction": null,
    "gasPrice": 0.02,
    "coingeckoId": "cosmos"
  },
  "genesisFile": "{Replace the address of the genesis file of the chain}",
  "remote": {
    "rpc": "https://gaia-seeds.interblock.io",
    "lcd": "https://gaia-seeds.interblock.io:1317"
  },
  "debug": {
    "startTimer": true,
    "readGenesis": true
  },
  "params": {
    "startHeight": 0,
    "defaultBlockTime": 5000,
    "blockInterval": 15000,
    "consensusInterval": 1000,
    "statusInterval": 7500,
    "signingInfoInterval": 1800000,
    "proposalInterval": 5000,
    "missedBlocksInterval": 60000,
    "delegationInterval": 900000
  }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx",
    ".mjs",
    ".i18n.yml"
  ]
});

require("/both/i18n/en-us.i18n.yml.js");
require("/both/i18n/zh-hans.i18n.yml.js");
require("/both/i18n/zh-hant.i18n.yml.js");
require("/both/utils/coins.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWNjb3VudHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jsb2Nrcy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYmxvY2tzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jsb2Nrcy9ibG9ja3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2NoYWluL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jaGFpbi9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jaGFpbi9jaGFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29pbi1zdGF0cy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29pbi1zdGF0cy9jb2luLXN0YXRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9kZWxlZ2F0aW9ucy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZGVsZWdhdGlvbnMvZGVsZWdhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2xlZGdlci9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcHJvcG9zYWxzL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9wcm9wb3NhbHMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcHJvcG9zYWxzL3Byb3Bvc2Fscy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcmVjb3Jkcy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcmVjb3Jkcy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9yZWNvcmRzL3JlY29yZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3N0YXR1cy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zdGF0dXMvc3RhdHVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90cmFuc2FjdGlvbnMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3RyYW5zYWN0aW9ucy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdm90aW5nLXBvd2VyL2hpc3RvcnkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2V2aWRlbmNlcy9ldmlkZW5jZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3ZhbGlkYXRvci1zZXRzL3ZhbGlkYXRvci1zZXRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvYm90aC9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9jcmVhdGUtaW5kZXhlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9yZWdpc3Rlci1hcGkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvdXRpbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91aS9jb21wb25lbnRzL0ljb25zLmpzeCIsIm1ldGVvcjovL/CfkrthcHAvYm90aC91dGlscy9jb2lucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiTWV0ZW9yIiwibW9kdWxlIiwibGluayIsInYiLCJIVFRQIiwiVmFsaWRhdG9ycyIsImZldGNoRnJvbVVybCIsInVybCIsInJlcyIsImdldCIsIkxDRCIsInN0YXR1c0NvZGUiLCJlIiwiY29uc29sZSIsImxvZyIsIm1ldGhvZHMiLCJhZGRyZXNzIiwidW5ibG9jayIsImF2YWlsYWJsZSIsInJlc3BvbnNlIiwiSlNPTiIsInBhcnNlIiwiY29udGVudCIsInJlc3VsdCIsImFjY291bnQiLCJ0eXBlIiwidmFsdWUiLCJCYXNlVmVzdGluZ0FjY291bnQiLCJCYXNlQWNjb3VudCIsImFjY291bnRfbnVtYmVyIiwiYmFsYW5jZSIsImxlbmd0aCIsImRlbGVnYXRpb25zIiwidW5ib25kaW5nIiwicmV3YXJkcyIsInRvdGFsIiwidmFsaWRhdG9yIiwiZmluZE9uZSIsIiRvciIsIm9wZXJhdG9yX2FkZHJlc3MiLCJkZWxlZ2F0b3JfYWRkcmVzcyIsInZhbF9jb21taXNzaW9uIiwiY29tbWlzc2lvbiIsImRhdGEiLCJzaGFyZXMiLCJwYXJzZUZsb2F0IiwicmVsZWdhdGlvbnMiLCJjb21wbGV0aW9uVGltZSIsImZvckVhY2giLCJyZWxlZ2F0aW9uIiwiZW50cmllcyIsInRpbWUiLCJEYXRlIiwiY29tcGxldGlvbl90aW1lIiwicmVkZWxlZ2F0aW9uQ29tcGxldGlvblRpbWUiLCJ1bmRlbGVnYXRpb25zIiwidW5ib25kaW5nQ29tcGxldGlvblRpbWUiLCJkZWxlZ2F0aW9uIiwiaSIsInVuYm9uZGluZ3MiLCJyZWRlbGVnYXRpb25zIiwicmVkZWxlZ2F0aW9uIiwidmFsaWRhdG9yX2RzdF9hZGRyZXNzIiwiY291bnQiLCJQcm9taXNlIiwiQmxvY2tzY29uIiwiQ2hhaW4iLCJWYWxpZGF0b3JTZXRzIiwiVmFsaWRhdG9yUmVjb3JkcyIsIkFuYWx5dGljcyIsIlZQRGlzdHJpYnV0aW9ucyIsIlZvdGluZ1Bvd2VySGlzdG9yeSIsIlRyYW5zYWN0aW9ucyIsIkV2aWRlbmNlcyIsInNoYTI1NiIsImdldEFkZHJlc3MiLCJjaGVlcmlvIiwiZ2V0UmVtb3ZlZFZhbGlkYXRvcnMiLCJwcmV2VmFsaWRhdG9ycyIsInZhbGlkYXRvcnMiLCJwIiwic3BsaWNlIiwiZ2V0VmFsaWRhdG9yUHJvZmlsZVVybCIsImlkZW50aXR5IiwidGhlbSIsInBpY3R1cmVzIiwicHJpbWFyeSIsInN0cmluZ2lmeSIsImluZGV4T2YiLCJ0ZWFtUGFnZSIsInBhZ2UiLCJsb2FkIiwiYXR0ciIsImJsb2NrcyIsImZpbmQiLCJwcm9wb3NlckFkZHJlc3MiLCJmZXRjaCIsImhlaWdodHMiLCJtYXAiLCJibG9jayIsImhlaWdodCIsImJsb2Nrc1N0YXRzIiwiJGluIiwidG90YWxCbG9ja0RpZmYiLCJiIiwidGltZURpZmYiLCJjb2xsZWN0aW9uIiwicmF3Q29sbGVjdGlvbiIsInBpcGVsaW5lIiwiJG1hdGNoIiwiJHNvcnQiLCIkbGltaXQiLCJzZXR0aW5ncyIsInB1YmxpYyIsInVwdGltZVdpbmRvdyIsIiR1bndpbmQiLCIkZ3JvdXAiLCIkY29uZCIsIiRlcSIsImF3YWl0IiwiYWdncmVnYXRlIiwidG9BcnJheSIsIlJQQyIsInN0YXR1cyIsInN5bmNfaW5mbyIsImxhdGVzdF9ibG9ja19oZWlnaHQiLCJjdXJySGVpZ2h0Iiwic29ydCIsImxpbWl0Iiwic3RhcnRIZWlnaHQiLCJwYXJhbXMiLCJTWU5DSU5HIiwidW50aWwiLCJjYWxsIiwiY3VyciIsInZhbGlkYXRvclNldCIsImNvbnNlbnN1c19wdWJrZXkiLCJ0b3RhbFZhbGlkYXRvcnMiLCJPYmplY3QiLCJrZXlzIiwic3RhcnRCbG9ja1RpbWUiLCJhbmFseXRpY3NEYXRhIiwiYnVsa1ZhbGlkYXRvcnMiLCJpbml0aWFsaXplVW5vcmRlcmVkQnVsa09wIiwiYnVsa1ZhbGlkYXRvclJlY29yZHMiLCJidWxrVlBIaXN0b3J5IiwiYnVsa1RyYW5zYXRpb25zIiwic3RhcnRHZXRIZWlnaHRUaW1lIiwiYmxvY2tEYXRhIiwiaGFzaCIsImJsb2NrX21ldGEiLCJibG9ja19pZCIsInRyYW5zTnVtIiwiaGVhZGVyIiwibnVtX3R4cyIsImxhc3RCbG9ja0hhc2giLCJsYXN0X2Jsb2NrX2lkIiwicHJvcG9zZXJfYWRkcmVzcyIsInByZWNvbW1pdHMiLCJsYXN0X2NvbW1pdCIsInB1c2giLCJ2YWxpZGF0b3JfYWRkcmVzcyIsInR4cyIsInQiLCJCdWZmZXIiLCJmcm9tIiwiZXJyIiwiZXZpZGVuY2UiLCJpbnNlcnQiLCJwcmVjb21taXRzQ291bnQiLCJlbmRHZXRIZWlnaHRUaW1lIiwic3RhcnRHZXRWYWxpZGF0b3JzVGltZSIsImJsb2NrX2hlaWdodCIsInBhcnNlSW50IiwidmFsaWRhdG9yc0NvdW50Iiwic3RhcnRCbG9ja0luc2VydFRpbWUiLCJlbmRCbG9ja0luc2VydFRpbWUiLCJleGlzdGluZ1ZhbGlkYXRvcnMiLCIkZXhpc3RzIiwicmVjb3JkIiwiZXhpc3RzIiwidm90aW5nX3Bvd2VyIiwiaiIsIm51bUJsb2NrcyIsInVwdGltZSIsImJhc2UiLCJ1cHNlcnQiLCJ1cGRhdGVPbmUiLCIkc2V0IiwibGFzdFNlZW4iLCJjaGFpblN0YXR1cyIsImNoYWluSWQiLCJjaGFpbl9pZCIsImxhc3RTeW5jZWRUaW1lIiwiYmxvY2tUaW1lIiwiZGVmYXVsdEJsb2NrVGltZSIsImRhdGVMYXRlc3QiLCJkYXRlTGFzdCIsIk1hdGgiLCJhYnMiLCJnZXRUaW1lIiwiZW5kR2V0VmFsaWRhdG9yc1RpbWUiLCJ1cGRhdGUiLCJhdmVyYWdlQmxvY2tUaW1lIiwic3RhcnRGaW5kVmFsaWRhdG9yc05hbWVUaW1lIiwicHJvcG9zZXJfcHJpb3JpdHkiLCJ2YWxFeGlzdCIsInB1Yl9rZXkiLCJhY2NwdWIiLCJiZWNoMzJQcmVmaXhBY2NQdWIiLCJvcGVyYXRvcl9wdWJrZXkiLCJiZWNoMzJQcmVmaXhWYWxQdWIiLCJiZWNoMzJQcmVmaXhDb25zUHViIiwidmFsaWRhdG9yRGF0YSIsImRlc2NyaXB0aW9uIiwicHJvZmlsZV91cmwiLCJqYWlsZWQiLCJtaW5fc2VsZl9kZWxlZ2F0aW9uIiwidG9rZW5zIiwiZGVsZWdhdG9yX3NoYXJlcyIsImJvbmRfaGVpZ2h0IiwiYm9uZF9pbnRyYV90eF9jb3VudGVyIiwidW5ib25kaW5nX2hlaWdodCIsInVuYm9uZGluZ190aW1lIiwic2VsZl9kZWxlZ2F0aW9uIiwicHJldl92b3RpbmdfcG93ZXIiLCJibG9ja190aW1lIiwic2VsZkRlbGVnYXRpb24iLCJwcmV2Vm90aW5nUG93ZXIiLCJjaGFuZ2VUeXBlIiwiY2hhbmdlRGF0YSIsInJlbW92ZWRWYWxpZGF0b3JzIiwiciIsImRiVmFsaWRhdG9ycyIsImZpZWxkcyIsImNvblB1YktleSIsInVuZGVmaW5lZCIsInByb2ZpbGVVcmwiLCJlbmRGaW5kVmFsaWRhdG9yc05hbWVUaW1lIiwic3RhcnRBbmF5dGljc0luc2VydFRpbWUiLCJlbmRBbmFseXRpY3NJbnNlcnRUaW1lIiwic3RhcnRWVXBUaW1lIiwiZXhlY3V0ZSIsImVuZFZVcFRpbWUiLCJzdGFydFZSVGltZSIsImVuZFZSVGltZSIsImFjdGl2ZVZhbGlkYXRvcnMiLCJudW1Ub3BUd2VudHkiLCJjZWlsIiwibnVtQm90dG9tRWlnaHR5IiwidG9wVHdlbnR5UG93ZXIiLCJib3R0b21FaWdodHlQb3dlciIsIm51bVRvcFRoaXJ0eUZvdXIiLCJudW1Cb3R0b21TaXh0eVNpeCIsInRvcFRoaXJ0eUZvdXJQZXJjZW50IiwiYm90dG9tU2l4dHlTaXhQZXJjZW50IiwidnBEaXN0IiwibnVtVmFsaWRhdG9ycyIsInRvdGFsVm90aW5nUG93ZXIiLCJjcmVhdGVBdCIsImVuZEJsb2NrVGltZSIsImxhc3RCbG9ja3NTeW5jZWRUaW1lIiwicHVibGlzaENvbXBvc2l0ZSIsImNoaWxkcmVuIiwiZXhwb3J0IiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwiaGVscGVycyIsInByb3Bvc2VyIiwiQ2hhaW5TdGF0ZXMiLCJmaW5kVm90aW5nUG93ZXIiLCJnZW5WYWxpZGF0b3JzIiwicG93ZXIiLCJjb25zZW5zdXMiLCJyb3VuZF9zdGF0ZSIsInJvdW5kIiwic3RlcCIsInZvdGVkUG93ZXIiLCJ2b3RlcyIsInByZXZvdGVzX2JpdF9hcnJheSIsInNwbGl0Iiwidm90aW5nSGVpZ2h0Iiwidm90aW5nUm91bmQiLCJ2b3RpbmdTdGVwIiwicHJldm90ZXMiLCJjaGFpbiIsIm5vZGVfaW5mbyIsIm5ldHdvcmsiLCJsYXRlc3RCbG9ja0hlaWdodCIsImxhdGVzdEJsb2NrVGltZSIsImxhdGVzdF9ibG9ja190aW1lIiwibGF0ZXN0U3RhdGUiLCJhY3RpdmVWUCIsImFjdGl2ZVZvdGluZ1Bvd2VyIiwiY2hhaW5TdGF0ZXMiLCJib25kaW5nIiwiYm9uZGVkVG9rZW5zIiwiYm9uZGVkX3Rva2VucyIsIm5vdEJvbmRlZFRva2VucyIsIm5vdF9ib25kZWRfdG9rZW5zIiwibWludGluZ0Rlbm9tIiwic3VwcGx5IiwidG90YWxTdXBwbHkiLCJwb29sIiwiY29tbXVuaXR5UG9vbCIsImFtb3VudCIsImRlbm9tIiwiaW5mbGF0aW9uIiwicHJvdmlzaW9ucyIsImFubnVhbFByb3Zpc2lvbnMiLCJjcmVhdGVkIiwicmVhZEdlbmVzaXMiLCJkZWJ1ZyIsImdlbmVzaXNGaWxlIiwiZ2VuZXNpcyIsImRpc3RyIiwiYXBwX3N0YXRlIiwiZGlzdHJpYnV0aW9uIiwiY2hhaW5QYXJhbXMiLCJnZW5lc2lzVGltZSIsImdlbmVzaXNfdGltZSIsImNvbnNlbnN1c1BhcmFtcyIsImNvbnNlbnN1c19wYXJhbXMiLCJhdXRoIiwiYmFuayIsInN0YWtpbmciLCJtaW50IiwiY29tbXVuaXR5VGF4IiwiY29tbXVuaXR5X3RheCIsImJhc2VQcm9wb3NlclJld2FyZCIsImJhc2VfcHJvcG9zZXJfcmV3YXJkIiwiYm9udXNQcm9wb3NlclJld2FyZCIsImJvbnVzX3Byb3Bvc2VyX3Jld2FyZCIsIndpdGhkcmF3QWRkckVuYWJsZWQiLCJ3aXRoZHJhd19hZGRyX2VuYWJsZWQiLCJnb3YiLCJzdGFydGluZ1Byb3Bvc2FsSWQiLCJzdGFydGluZ19wcm9wb3NhbF9pZCIsImRlcG9zaXRQYXJhbXMiLCJkZXBvc2l0X3BhcmFtcyIsInZvdGluZ1BhcmFtcyIsInZvdGluZ19wYXJhbXMiLCJ0YWxseVBhcmFtcyIsInRhbGx5X3BhcmFtcyIsInNsYXNoaW5nIiwiY3Jpc2lzIiwiZ2VudXRpbCIsImdlbnR4cyIsIm1zZyIsIm0iLCJwdWJrZXkiLCJmbG9vciIsInN0YWtpbmdGcmFjdGlvbiIsInB1YmtleVZhbHVlIiwiZ2VuVmFsaWRhdG9yc1NldCIsIkNvaW5TdGF0cyIsInB1Ymxpc2giLCJsYXN0X3VwZGF0ZWRfYXQiLCJjb2luSWQiLCJjb2luZ2Vja29JZCIsIm5vdyIsInNldE1pbnV0ZXMiLCJEZWxlZ2F0aW9ucyIsImNvbmNhdCIsImNyZWF0ZWRBdCIsIl9vYmplY3RTcHJlYWQiLCJkZWZhdWx0IiwidHhJbmZvIiwidGltZXN0YW1wIiwicG9zdCIsImNvZGUiLCJFcnJvciIsInJhd19sb2ciLCJtZXNzYWdlIiwidHhoYXNoIiwiYm9keSIsInBhdGgiLCJ0eE1zZyIsImFkanVzdG1lbnQiLCJnYXNfZXN0aW1hdGUiLCJQcm9wb3NhbHMiLCJwcm9wb3NhbHMiLCJmaW5pc2hlZFByb3Bvc2FsSWRzIiwiU2V0IiwicHJvcG9zYWxJZCIsInByb3Bvc2FsSWRzIiwiYnVsa1Byb3Bvc2FscyIsInByb3Bvc2FsIiwiaWQiLCJoYXMiLCJwcm9wb3NhbF9pZCIsIiRuaW4iLCJwcm9wb3NhbF9zdGF0dXMiLCJkZXBvc2l0cyIsImdldFZvdGVEZXRhaWwiLCJ0YWxseSIsInVwZGF0ZWRBdCIsInZvdGVycyIsInZvdGUiLCJ2b3RlciIsInZvdGluZ1Bvd2VyTWFwIiwidmFsaWRhdG9yQWRkcmVzc01hcCIsIm1vbmlrZXIiLCJkZWxlZ2F0b3JTaGFyZXMiLCJkZWR1Y3RlZFNoYXJlcyIsInZvdGluZ1Bvd2VyIiwiY2hlY2siLCJOdW1iZXIiLCJBdmVyYWdlRGF0YSIsIkF2ZXJhZ2VWYWxpZGF0b3JEYXRhIiwiU3RhdHVzIiwiTWlzc2VkQmxvY2tzU3RhdHMiLCJNaXNzZWRCbG9ja3MiLCJfIiwiQlVMS1VQREFURU1BWFNJWkUiLCJnZXRCbG9ja1N0YXRzIiwibGF0ZXN0SGVpZ2h0IiwiYmxvY2tTdGF0cyIsImNvbmQiLCIkYW5kIiwiJGd0IiwiJGx0ZSIsIm9wdGlvbnMiLCJhc3NpZ24iLCJnZXRQcmV2aW91c1JlY29yZCIsInZvdGVyQWRkcmVzcyIsInByZXZpb3VzUmVjb3JkIiwiYmxvY2tIZWlnaHQiLCJsYXN0VXBkYXRlZEhlaWdodCIsInByZXZTdGF0cyIsInBpY2siLCJtaXNzQ291bnQiLCJ0b3RhbENvdW50IiwiQ09VTlRNSVNTRURCTE9DS1MiLCJzdGFydFRpbWUiLCJleHBsb3JlclN0YXR1cyIsImxhc3RQcm9jZXNzZWRNaXNzZWRCbG9ja0hlaWdodCIsIm1pbiIsImJ1bGtNaXNzZWRTdGF0cyIsImluaXRpYWxpemVPcmRlcmVkQnVsa09wIiwidmFsaWRhdG9yc01hcCIsInByb3Bvc2VyVm90ZXJTdGF0cyIsInZvdGVkVmFsaWRhdG9ycyIsInZhbGlkYXRvclNldHMiLCJ2b3RlZFZvdGluZ1Bvd2VyIiwiYWN0aXZlVmFsaWRhdG9yIiwiY3VycmVudFZhbGlkYXRvciIsInNldCIsIm4iLCJzdGF0cyIsImNsaWVudCIsIl9kcml2ZXIiLCJtb25nbyIsImJ1bGtQcm9taXNlIiwidGhlbiIsImJpbmRFbnZpcm9ubWVudCIsIm5JbnNlcnRlZCIsIm5VcHNlcnRlZCIsIm5Nb2RpZmllZCIsImxhc3RQcm9jZXNzZWRNaXNzZWRCbG9ja1RpbWUiLCJDT1VOVE1JU1NFREJMT0NLU1NUQVRTIiwibGFzdE1pc3NlZEJsb2NrSGVpZ2h0IiwibWlzc2VkUmVjb3JkcyIsImNvdW50cyIsImV4aXN0aW5nUmVjb3JkIiwibGFzdE1pc3NlZEJsb2NrVGltZSIsImF2ZXJhZ2VWb3RpbmdQb3dlciIsImFuYWx5dGljcyIsImxhc3RNaW51dGVWb3RpbmdQb3dlciIsImxhc3RNaW51dGVCbG9ja1RpbWUiLCJsYXN0SG91clZvdGluZ1Bvd2VyIiwibGFzdEhvdXJCbG9ja1RpbWUiLCJsYXN0RGF5Vm90aW5nUG93ZXIiLCJsYXN0RGF5QmxvY2tUaW1lIiwiYmxvY2tIZWlnaHRzIiwiYSIsIm51bSIsImNvbmRpdGlvbnMiLCJwcm9wb3Nlck1vbmlrZXIiLCJ2b3Rlck1vbmlrZXIiLCJBZGRyZXNzTGVuZ3RoIiwidG9VcHBlckNhc2UiLCJ0eCIsInR4SWQiLCIkbHQiLCJpbmNsdWRlcyIsImJlY2gzMlByZWZpeFZhbEFkZHIiLCJiZWNoMzJQcmVmaXhBY2NBZGRyIiwidmFsaWRhdG9yQWRkcmVzcyIsImRlbGVnYXRvckFkZHJlc3MiLCJxdWVyeSIsIlR4SWNvbiIsImRpcmVjdGlvbiIsInZhbCIsImZpcnN0U2VlbiIsImhpc3RvcnkiLCJjcmVhdGVJbmRleCIsInVuaXF1ZSIsInBhcnRpYWxGaWx0ZXJFeHByZXNzaW9uIiwib25QYWdlTG9hZCIsIkhlbG1ldCIsInNpbmsiLCJoZWxtZXQiLCJyZW5kZXJTdGF0aWMiLCJhcHBlbmRUb0hlYWQiLCJtZXRhIiwidG9TdHJpbmciLCJ0aXRsZSIsImJlY2gzMiIsIkZ1dHVyZSIsIk5wbSIsInJlcXVpcmUiLCJleGVjIiwidG9IZXhTdHJpbmciLCJieXRlQXJyYXkiLCJieXRlIiwic2xpY2UiLCJqb2luIiwicHVia2V5VG9CZWNoMzIiLCJwcmVmaXgiLCJwdWJrZXlBbWlub1ByZWZpeCIsImJ1ZmZlciIsImFsbG9jIiwiY29weSIsImVuY29kZSIsInRvV29yZHMiLCJiZWNoMzJUb1B1YmtleSIsImZyb21Xb3JkcyIsImRlY29kZSIsIndvcmRzIiwiZ2V0RGVsZWdhdG9yIiwib3BlcmF0b3JBZGRyIiwiZ2V0S2V5YmFzZVRlYW1QaWMiLCJrZXliYXNlVXJsIiwiRGVub21TeW1ib2wiLCJQcm9wb3NhbFN0YXR1c0ljb24iLCJWb3RlSWNvbiIsIkluZm9JY29uIiwiUmVhY3QiLCJVbmNvbnRyb2xsZWRUb29sdGlwIiwicHJvcHMiLCJ2YWxpZCIsIkNvbXBvbmVudCIsImNvbnN0cnVjdG9yIiwicmVmIiwiY3JlYXRlUmVmIiwicmVuZGVyIiwidG9vbHRpcFRleHQiLCJDb2luIiwibnVtYnJvIiwiYXV0b2Zvcm1hdCIsImZvcm1hdHRlciIsImZvcm1hdCIsInRvTG93ZXJDYXNlIiwiTWludGluZ0Rlbm9tIiwiX2Ftb3VudCIsIlN0YWtpbmdEZW5vbSIsIlN0YWtpbmdGcmFjdGlvbiIsInN0YWtpbmdBbW91bnQiLCJwcmVjaXNpb24iLCJtaW5TdGFrZSIsInBvdyIsInJlcGVhdCIsIm1pbnRTdHJpbmciLCJzdGFrZVN0cmluZyIsInN0YWtpbmdEZW5vbSIsIlN0YWtpbmdEZW5vbVBsdXJhbCIsInN0YWtpbmdEZW5vbVBsdXJhbCIsIk1pblN0YWtlIiwicmVtb3RlIiwicnBjIiwibGNkIiwidGltZXJCbG9ja3MiLCJ0aW1lckNoYWluIiwidGltZXJDb25zZW5zdXMiLCJ0aW1lclByb3Bvc2FsIiwidGltZXJQcm9wb3NhbHNSZXN1bHRzIiwidGltZXJNaXNzZWRCbG9jayIsInRpbWVyRGVsZWdhdGlvbiIsInRpbWVyQWdncmVnYXRlIiwiREVGQVVMVFNFVFRJTkdTIiwidXBkYXRlQ2hhaW5TdGF0dXMiLCJlcnJvciIsInVwZGF0ZUJsb2NrIiwiZ2V0Q29uc2Vuc3VzU3RhdGUiLCJnZXRQcm9wb3NhbHMiLCJnZXRQcm9wb3NhbHNSZXN1bHRzIiwidXBkYXRlTWlzc2VkQmxvY2tzIiwiZ2V0RGVsZWdhdGlvbnMiLCJhZ2dyZWdhdGVNaW51dGVseSIsImFnZ3JlZ2F0ZUhvdXJseSIsImFnZ3JlZ2F0ZURhaWx5Iiwic3RhcnR1cCIsImlzRGV2ZWxvcG1lbnQiLCJERUZBVUxUU0VUVElOR1NKU09OIiwicHJvY2VzcyIsImVudiIsIk5PREVfVExTX1JFSkVDVF9VTkFVVEhPUklaRUQiLCJrZXkiLCJ3YXJuIiwicGFyYW0iLCJzdGFydFRpbWVyIiwic2V0SW50ZXJ2YWwiLCJjb25zZW5zdXNJbnRlcnZhbCIsImJsb2NrSW50ZXJ2YWwiLCJzdGF0dXNJbnRlcnZhbCIsInByb3Bvc2FsSW50ZXJ2YWwiLCJtaXNzZWRCbG9ja3NJbnRlcnZhbCIsImRlbGVnYXRpb25JbnRlcnZhbCIsImdldFVUQ1NlY29uZHMiLCJnZXRVVENNaW51dGVzIiwiZ2V0VVRDSG91cnMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksdUNBQVosRUFBb0Q7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQXBELEVBQWtGLENBQWxGOztBQUd2SSxNQUFNRyxZQUFZLEdBQUlDLEdBQUQsSUFBUztBQUMxQixNQUFHO0FBQ0MsUUFBSUMsR0FBRyxHQUFHSixJQUFJLENBQUNLLEdBQUwsQ0FBU0MsR0FBRyxHQUFHSCxHQUFmLENBQVY7O0FBQ0EsUUFBSUMsR0FBRyxDQUFDRyxVQUFKLElBQWtCLEdBQXRCLEVBQTBCO0FBQ3RCLGFBQU9ILEdBQVA7QUFDSDs7QUFBQTtBQUNKLEdBTEQsQ0FNQSxPQUFPSSxDQUFQLEVBQVM7QUFDTEMsV0FBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLENBVkQ7O0FBWUFaLE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsK0JBQTZCLFVBQVNDLE9BQVQsRUFBaUI7QUFDMUMsU0FBS0MsT0FBTDtBQUNBLFFBQUlWLEdBQUcsR0FBR0csR0FBRyxHQUFHLGlCQUFOLEdBQXlCTSxPQUFuQzs7QUFDQSxRQUFHO0FBQ0MsVUFBSUUsU0FBUyxHQUFHZCxJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFoQjs7QUFDQSxVQUFJVyxTQUFTLENBQUNQLFVBQVYsSUFBd0IsR0FBNUIsRUFBZ0M7QUFDNUIsWUFBSVEsUUFBUSxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0gsU0FBUyxDQUFDSSxPQUFyQixFQUE4QkMsTUFBN0M7QUFDQSxZQUFJQyxPQUFKO0FBQ0EsWUFBSUwsUUFBUSxDQUFDTSxJQUFULEtBQWtCLG9CQUF0QixFQUNJRCxPQUFPLEdBQUdMLFFBQVEsQ0FBQ08sS0FBbkIsQ0FESixLQUVLLElBQUlQLFFBQVEsQ0FBQ00sSUFBVCxLQUFrQixrQ0FBbEIsSUFBd0ROLFFBQVEsQ0FBQ00sSUFBVCxLQUFrQixxQ0FBOUUsRUFDREQsT0FBTyxHQUFHTCxRQUFRLENBQUNPLEtBQVQsQ0FBZUMsa0JBQWYsQ0FBa0NDLFdBQTVDO0FBQ0osWUFBSUosT0FBTyxJQUFJQSxPQUFPLENBQUNLLGNBQVIsSUFBMEIsSUFBekMsRUFDSSxPQUFPTCxPQUFQO0FBQ0osZUFBTyxJQUFQO0FBQ0g7QUFDSixLQWJELENBY0EsT0FBT1osQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixHQXJCVTtBQXNCWCx5QkFBdUIsVUFBU0ksT0FBVCxFQUFpQjtBQUNwQyxTQUFLQyxPQUFMO0FBQ0EsUUFBSWEsT0FBTyxHQUFHLEVBQWQsQ0FGb0MsQ0FJcEM7O0FBQ0EsUUFBSXZCLEdBQUcsR0FBR0csR0FBRyxHQUFHLGlCQUFOLEdBQXlCTSxPQUFuQzs7QUFDQSxRQUFHO0FBQ0MsVUFBSUUsU0FBUyxHQUFHZCxJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFoQjs7QUFDQSxVQUFJVyxTQUFTLENBQUNQLFVBQVYsSUFBd0IsR0FBNUIsRUFBZ0M7QUFDNUI7QUFDQW1CLGVBQU8sQ0FBQ1osU0FBUixHQUFvQkUsSUFBSSxDQUFDQyxLQUFMLENBQVdILFNBQVMsQ0FBQ0ksT0FBckIsRUFBOEJDLE1BQWxEO0FBQ0EsWUFBSU8sT0FBTyxDQUFDWixTQUFSLElBQXFCWSxPQUFPLENBQUNaLFNBQVIsQ0FBa0JhLE1BQWxCLEdBQTJCLENBQXBELEVBQ0lELE9BQU8sQ0FBQ1osU0FBUixHQUFvQlksT0FBTyxDQUFDWixTQUFSLENBQWtCLENBQWxCLENBQXBCO0FBQ1A7QUFDSixLQVJELENBU0EsT0FBT04sQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0gsS0FqQm1DLENBbUJwQzs7O0FBQ0FMLE9BQUcsR0FBR0csR0FBRyxHQUFHLHNCQUFOLEdBQTZCTSxPQUE3QixHQUFxQyxjQUEzQzs7QUFDQSxRQUFHO0FBQ0MsVUFBSWdCLFdBQVcsR0FBRzVCLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWxCOztBQUNBLFVBQUl5QixXQUFXLENBQUNyQixVQUFaLElBQTBCLEdBQTlCLEVBQWtDO0FBQzlCbUIsZUFBTyxDQUFDRSxXQUFSLEdBQXNCWixJQUFJLENBQUNDLEtBQUwsQ0FBV1csV0FBVyxDQUFDVixPQUF2QixFQUFnQ0MsTUFBdEQ7QUFDSDtBQUNKLEtBTEQsQ0FNQSxPQUFPWCxDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxLQTdCbUMsQ0E4QnBDOzs7QUFDQUwsT0FBRyxHQUFHRyxHQUFHLEdBQUcsc0JBQU4sR0FBNkJNLE9BQTdCLEdBQXFDLHdCQUEzQzs7QUFDQSxRQUFHO0FBQ0MsVUFBSWlCLFNBQVMsR0FBRzdCLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWhCOztBQUNBLFVBQUkwQixTQUFTLENBQUN0QixVQUFWLElBQXdCLEdBQTVCLEVBQWdDO0FBQzVCbUIsZUFBTyxDQUFDRyxTQUFSLEdBQW9CYixJQUFJLENBQUNDLEtBQUwsQ0FBV1ksU0FBUyxDQUFDWCxPQUFyQixFQUE4QkMsTUFBbEQ7QUFDSDtBQUNKLEtBTEQsQ0FNQSxPQUFPWCxDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxLQXhDbUMsQ0EwQ3BDOzs7QUFDQUwsT0FBRyxHQUFHRyxHQUFHLEdBQUcsMkJBQU4sR0FBa0NNLE9BQWxDLEdBQTBDLFVBQWhEOztBQUNBLFFBQUc7QUFDQyxVQUFJa0IsT0FBTyxHQUFHOUIsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZDs7QUFDQSxVQUFJMkIsT0FBTyxDQUFDdkIsVUFBUixJQUFzQixHQUExQixFQUE4QjtBQUMxQm1CLGVBQU8sQ0FBQ0ksT0FBUixHQUFrQmQsSUFBSSxDQUFDQyxLQUFMLENBQVdhLE9BQU8sQ0FBQ1osT0FBbkIsRUFBNEJDLE1BQTVCLENBQW1DWSxLQUFyRDtBQUNIO0FBQ0osS0FMRCxDQU1BLE9BQU92QixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxLQXBEbUMsQ0FzRHBDOzs7QUFDQSxRQUFJd0IsU0FBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUNaO0FBQUNDLFNBQUcsRUFBRSxDQUFDO0FBQUNDLHdCQUFnQixFQUFDdkI7QUFBbEIsT0FBRCxFQUE2QjtBQUFDd0IseUJBQWlCLEVBQUN4QjtBQUFuQixPQUE3QixFQUEwRDtBQUFDQSxlQUFPLEVBQUNBO0FBQVQsT0FBMUQ7QUFBTixLQURZLENBQWhCOztBQUVBLFFBQUlvQixTQUFKLEVBQWU7QUFDWCxVQUFJN0IsR0FBRyxHQUFHRyxHQUFHLEdBQUcsMkJBQU4sR0FBb0MwQixTQUFTLENBQUNHLGdCQUF4RDtBQUNBVCxhQUFPLENBQUNTLGdCQUFSLEdBQTJCSCxTQUFTLENBQUNHLGdCQUFyQzs7QUFDQSxVQUFJO0FBQ0EsWUFBSUwsT0FBTyxHQUFHOUIsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZDs7QUFDQSxZQUFJMkIsT0FBTyxDQUFDdkIsVUFBUixJQUFzQixHQUExQixFQUE4QjtBQUMxQixjQUFJVyxPQUFPLEdBQUdGLElBQUksQ0FBQ0MsS0FBTCxDQUFXYSxPQUFPLENBQUNaLE9BQW5CLEVBQTRCQyxNQUExQztBQUNBLGNBQUlELE9BQU8sQ0FBQ21CLGNBQVIsSUFBMEJuQixPQUFPLENBQUNtQixjQUFSLENBQXVCVixNQUF2QixHQUFnQyxDQUE5RCxFQUNJRCxPQUFPLENBQUNZLFVBQVIsR0FBcUJwQixPQUFPLENBQUNtQixjQUFSLENBQXVCLENBQXZCLENBQXJCO0FBQ1A7QUFFSixPQVJELENBU0EsT0FBTzdCLENBQVAsRUFBUztBQUNMQyxlQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0o7O0FBRUQsV0FBT2tCLE9BQVA7QUFDSCxHQWpHVTs7QUFrR1gsMkJBQXlCZCxPQUF6QixFQUFrQ29CLFNBQWxDLEVBQTRDO0FBQ3hDLFFBQUk3QixHQUFHLGlDQUEwQlMsT0FBMUIsMEJBQWlEb0IsU0FBakQsQ0FBUDtBQUNBLFFBQUlKLFdBQVcsR0FBRzFCLFlBQVksQ0FBQ0MsR0FBRCxDQUE5QjtBQUNBeUIsZUFBVyxHQUFHQSxXQUFXLElBQUlBLFdBQVcsQ0FBQ1csSUFBWixDQUFpQnBCLE1BQTlDO0FBQ0EsUUFBSVMsV0FBVyxJQUFJQSxXQUFXLENBQUNZLE1BQS9CLEVBQ0laLFdBQVcsQ0FBQ1ksTUFBWixHQUFxQkMsVUFBVSxDQUFDYixXQUFXLENBQUNZLE1BQWIsQ0FBL0I7QUFFSnJDLE9BQUcsOENBQXVDUyxPQUF2QywyQkFBK0RvQixTQUEvRCxDQUFIO0FBQ0EsUUFBSVUsV0FBVyxHQUFHeEMsWUFBWSxDQUFDQyxHQUFELENBQTlCO0FBQ0F1QyxlQUFXLEdBQUdBLFdBQVcsSUFBSUEsV0FBVyxDQUFDSCxJQUFaLENBQWlCcEIsTUFBOUM7QUFDQSxRQUFJd0IsY0FBSjs7QUFDQSxRQUFJRCxXQUFKLEVBQWlCO0FBQ2JBLGlCQUFXLENBQUNFLE9BQVosQ0FBcUJDLFVBQUQsSUFBZ0I7QUFDaEMsWUFBSUMsT0FBTyxHQUFHRCxVQUFVLENBQUNDLE9BQXpCO0FBQ0EsWUFBSUMsSUFBSSxHQUFHLElBQUlDLElBQUosQ0FBU0YsT0FBTyxDQUFDQSxPQUFPLENBQUNuQixNQUFSLEdBQWUsQ0FBaEIsQ0FBUCxDQUEwQnNCLGVBQW5DLENBQVg7QUFDQSxZQUFJLENBQUNOLGNBQUQsSUFBbUJJLElBQUksR0FBR0osY0FBOUIsRUFDSUEsY0FBYyxHQUFHSSxJQUFqQjtBQUNQLE9BTEQ7QUFNQW5CLGlCQUFXLENBQUNzQiwwQkFBWixHQUF5Q1AsY0FBekM7QUFDSDs7QUFFRHhDLE9BQUcsaUNBQTBCUyxPQUExQixvQ0FBMkRvQixTQUEzRCxDQUFIO0FBQ0EsUUFBSW1CLGFBQWEsR0FBR2pELFlBQVksQ0FBQ0MsR0FBRCxDQUFoQztBQUNBZ0QsaUJBQWEsR0FBR0EsYUFBYSxJQUFJQSxhQUFhLENBQUNaLElBQWQsQ0FBbUJwQixNQUFwRDs7QUFDQSxRQUFJZ0MsYUFBSixFQUFtQjtBQUNmdkIsaUJBQVcsQ0FBQ0MsU0FBWixHQUF3QnNCLGFBQWEsQ0FBQ0wsT0FBZCxDQUFzQm5CLE1BQTlDO0FBQ0FDLGlCQUFXLENBQUN3Qix1QkFBWixHQUFzQ0QsYUFBYSxDQUFDTCxPQUFkLENBQXNCLENBQXRCLEVBQXlCRyxlQUEvRDtBQUNIOztBQUNELFdBQU9yQixXQUFQO0FBQ0gsR0EvSFU7O0FBZ0lYLCtCQUE2QmhCLE9BQTdCLEVBQXFDO0FBQ2pDLFFBQUlULEdBQUcsR0FBR0csR0FBRyxHQUFHLHNCQUFOLEdBQTZCTSxPQUE3QixHQUFxQyxjQUEvQzs7QUFFQSxRQUFHO0FBQ0MsVUFBSWdCLFdBQVcsR0FBRzVCLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWxCOztBQUNBLFVBQUl5QixXQUFXLENBQUNyQixVQUFaLElBQTBCLEdBQTlCLEVBQWtDO0FBQzlCcUIsbUJBQVcsR0FBR1osSUFBSSxDQUFDQyxLQUFMLENBQVdXLFdBQVcsQ0FBQ1YsT0FBdkIsRUFBZ0NDLE1BQTlDOztBQUNBLFlBQUlTLFdBQVcsSUFBSUEsV0FBVyxDQUFDRCxNQUFaLEdBQXFCLENBQXhDLEVBQTBDO0FBQ3RDQyxxQkFBVyxDQUFDZ0IsT0FBWixDQUFvQixDQUFDUyxVQUFELEVBQWFDLENBQWIsS0FBbUI7QUFDbkMsZ0JBQUkxQixXQUFXLENBQUMwQixDQUFELENBQVgsSUFBa0IxQixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBckMsRUFDSVosV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLENBQWVkLE1BQWYsR0FBd0JDLFVBQVUsQ0FBQ2IsV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLENBQWVkLE1BQWhCLENBQWxDO0FBQ1AsV0FIRDtBQUlIOztBQUVELGVBQU9aLFdBQVA7QUFDSDs7QUFBQTtBQUNKLEtBYkQsQ0FjQSxPQUFPcEIsQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixHQXBKVTs7QUFxSlgsOEJBQTRCSSxPQUE1QixFQUFvQztBQUNoQyxRQUFJVCxHQUFHLEdBQUdHLEdBQUcsR0FBRyxzQkFBTixHQUE2Qk0sT0FBN0IsR0FBcUMsd0JBQS9DOztBQUVBLFFBQUc7QUFDQyxVQUFJMkMsVUFBVSxHQUFHdkQsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBakI7O0FBQ0EsVUFBSW9ELFVBQVUsQ0FBQ2hELFVBQVgsSUFBeUIsR0FBN0IsRUFBaUM7QUFDN0JnRCxrQkFBVSxHQUFHdkMsSUFBSSxDQUFDQyxLQUFMLENBQVdzQyxVQUFVLENBQUNyQyxPQUF0QixFQUErQkMsTUFBNUM7QUFDQSxlQUFPb0MsVUFBUDtBQUNIOztBQUFBO0FBQ0osS0FORCxDQU9BLE9BQU8vQyxDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLEdBbEtVOztBQW1LWCxpQ0FBK0JJLE9BQS9CLEVBQXdDb0IsU0FBeEMsRUFBa0Q7QUFDOUMsUUFBSTdCLEdBQUcsOENBQXVDUyxPQUF2Qyw2QkFBaUVvQixTQUFqRSxDQUFQO0FBQ0EsUUFBSWIsTUFBTSxHQUFHakIsWUFBWSxDQUFDQyxHQUFELENBQXpCOztBQUNBLFFBQUlnQixNQUFNLElBQUlBLE1BQU0sQ0FBQ29CLElBQXJCLEVBQTJCO0FBQ3ZCLFVBQUlpQixhQUFhLEdBQUcsRUFBcEI7QUFDQXJDLFlBQU0sQ0FBQ29CLElBQVAsQ0FBWUssT0FBWixDQUFxQmEsWUFBRCxJQUFrQjtBQUNsQyxZQUFJWCxPQUFPLEdBQUdXLFlBQVksQ0FBQ1gsT0FBM0I7QUFDQVUscUJBQWEsQ0FBQ0MsWUFBWSxDQUFDQyxxQkFBZCxDQUFiLEdBQW9EO0FBQ2hEQyxlQUFLLEVBQUViLE9BQU8sQ0FBQ25CLE1BRGlDO0FBRWhEZ0Isd0JBQWMsRUFBRUcsT0FBTyxDQUFDLENBQUQsQ0FBUCxDQUFXRztBQUZxQixTQUFwRDtBQUlILE9BTkQ7QUFPQSxhQUFPTyxhQUFQO0FBQ0g7QUFDSjs7QUFqTFUsQ0FBZixFOzs7Ozs7Ozs7OztBQ2ZBLElBQUk1RCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSTZELE9BQUo7QUFBWS9ELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUM4RCxTQUFPLENBQUM3RCxDQUFELEVBQUc7QUFBQzZELFdBQU8sR0FBQzdELENBQVI7QUFBVTs7QUFBdEIsQ0FBN0IsRUFBcUQsQ0FBckQ7QUFBd0QsSUFBSThELFNBQUo7QUFBY2hFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtCQUFaLEVBQTRDO0FBQUMrRCxXQUFTLENBQUM5RCxDQUFELEVBQUc7QUFBQzhELGFBQVMsR0FBQzlELENBQVY7QUFBWTs7QUFBMUIsQ0FBNUMsRUFBd0UsQ0FBeEU7QUFBMkUsSUFBSStELEtBQUo7QUFBVWpFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUNnRSxPQUFLLENBQUMvRCxDQUFELEVBQUc7QUFBQytELFNBQUssR0FBQy9ELENBQU47QUFBUTs7QUFBbEIsQ0FBMUMsRUFBOEQsQ0FBOUQ7QUFBaUUsSUFBSWdFLGFBQUo7QUFBa0JsRSxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQ0FBWixFQUE0RDtBQUFDaUUsZUFBYSxDQUFDaEUsQ0FBRCxFQUFHO0FBQUNnRSxpQkFBYSxHQUFDaEUsQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBNUQsRUFBZ0csQ0FBaEc7QUFBbUcsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSx1Q0FBWixFQUFvRDtBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBcEQsRUFBa0YsQ0FBbEY7QUFBcUYsSUFBSWlFLGdCQUFKLEVBQXFCQyxTQUFyQixFQUErQkMsZUFBL0I7QUFBK0NyRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxpQ0FBWixFQUE4QztBQUFDa0Usa0JBQWdCLENBQUNqRSxDQUFELEVBQUc7QUFBQ2lFLG9CQUFnQixHQUFDakUsQ0FBakI7QUFBbUIsR0FBeEM7O0FBQXlDa0UsV0FBUyxDQUFDbEUsQ0FBRCxFQUFHO0FBQUNrRSxhQUFTLEdBQUNsRSxDQUFWO0FBQVksR0FBbEU7O0FBQW1FbUUsaUJBQWUsQ0FBQ25FLENBQUQsRUFBRztBQUFDbUUsbUJBQWUsR0FBQ25FLENBQWhCO0FBQWtCOztBQUF4RyxDQUE5QyxFQUF3SixDQUF4SjtBQUEySixJQUFJb0Usa0JBQUo7QUFBdUJ0RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQ0FBWixFQUFtRDtBQUFDcUUsb0JBQWtCLENBQUNwRSxDQUFELEVBQUc7QUFBQ29FLHNCQUFrQixHQUFDcEUsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQW5ELEVBQWlHLENBQWpHO0FBQW9HLElBQUlxRSxZQUFKO0FBQWlCdkUsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ3NFLGNBQVksQ0FBQ3JFLENBQUQsRUFBRztBQUFDcUUsZ0JBQVksR0FBQ3JFLENBQWI7QUFBZTs7QUFBaEMsQ0FBakQsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSXNFLFNBQUo7QUFBY3hFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDhCQUFaLEVBQTJDO0FBQUN1RSxXQUFTLENBQUN0RSxDQUFELEVBQUc7QUFBQ3NFLGFBQVMsR0FBQ3RFLENBQVY7QUFBWTs7QUFBMUIsQ0FBM0MsRUFBdUUsRUFBdkU7QUFBMkUsSUFBSXVFLE1BQUo7QUFBV3pFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQ3dFLFFBQU0sQ0FBQ3ZFLENBQUQsRUFBRztBQUFDdUUsVUFBTSxHQUFDdkUsQ0FBUDtBQUFTOztBQUFwQixDQUF4QixFQUE4QyxFQUE5QztBQUFrRCxJQUFJd0UsVUFBSjtBQUFlMUUsTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQ3lFLFlBQVUsQ0FBQ3hFLENBQUQsRUFBRztBQUFDd0UsY0FBVSxHQUFDeEUsQ0FBWDtBQUFhOztBQUE1QixDQUFwQyxFQUFrRSxFQUFsRTtBQUFzRSxJQUFJeUUsT0FBSjtBQUFZM0UsTUFBTSxDQUFDQyxJQUFQLENBQVksU0FBWixFQUFzQjtBQUFDLE1BQUlDLENBQUosRUFBTTtBQUFDeUUsV0FBTyxHQUFDekUsQ0FBUjtBQUFVOztBQUFsQixDQUF0QixFQUEwQyxFQUExQzs7QUFlNXRDO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTBFLG9CQUFvQixHQUFHLENBQUNDLGNBQUQsRUFBaUJDLFVBQWpCLEtBQWdDO0FBQ25EO0FBQ0EsT0FBS0MsQ0FBTCxJQUFVRixjQUFWLEVBQXlCO0FBQ3JCLFNBQUszRSxDQUFMLElBQVU0RSxVQUFWLEVBQXFCO0FBQ2pCLFVBQUlELGNBQWMsQ0FBQ0UsQ0FBRCxDQUFkLENBQWtCaEUsT0FBbEIsSUFBNkIrRCxVQUFVLENBQUM1RSxDQUFELENBQVYsQ0FBY2EsT0FBL0MsRUFBdUQ7QUFDbkQ4RCxzQkFBYyxDQUFDRyxNQUFmLENBQXNCRCxDQUF0QixFQUF3QixDQUF4QjtBQUNIO0FBQ0o7QUFDSjs7QUFFRCxTQUFPRixjQUFQO0FBQ0gsQ0FYRDs7QUFhQUksc0JBQXNCLEdBQUlDLFFBQUQsSUFBYztBQUNuQyxNQUFJQSxRQUFRLENBQUNwRCxNQUFULElBQW1CLEVBQXZCLEVBQTBCO0FBQ3RCLFFBQUlaLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLG9FQUFxRTBFLFFBQXJFLHNCQUFmOztBQUNBLFFBQUloRSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBZ0M7QUFDNUIsVUFBSXlFLElBQUksR0FBR2pFLFFBQVEsQ0FBQ3dCLElBQVQsQ0FBY3lDLElBQXpCO0FBQ0EsYUFBT0EsSUFBSSxJQUFJQSxJQUFJLENBQUNyRCxNQUFiLElBQXVCcUQsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRQyxRQUEvQixJQUEyQ0QsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRQyxRQUFSLENBQWlCQyxPQUE1RCxJQUF1RUYsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRQyxRQUFSLENBQWlCQyxPQUFqQixDQUF5Qi9FLEdBQXZHO0FBQ0gsS0FIRCxNQUdPO0FBQ0hNLGFBQU8sQ0FBQ0MsR0FBUixDQUFZTSxJQUFJLENBQUNtRSxTQUFMLENBQWVwRSxRQUFmLENBQVo7QUFDSDtBQUNKLEdBUkQsTUFRTyxJQUFJZ0UsUUFBUSxDQUFDSyxPQUFULENBQWlCLGtCQUFqQixJQUFxQyxDQUF6QyxFQUEyQztBQUM5QyxRQUFJQyxRQUFRLEdBQUdyRixJQUFJLENBQUNLLEdBQUwsQ0FBUzBFLFFBQVQsQ0FBZjs7QUFDQSxRQUFJTSxRQUFRLENBQUM5RSxVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCLFVBQUkrRSxJQUFJLEdBQUdkLE9BQU8sQ0FBQ2UsSUFBUixDQUFhRixRQUFRLENBQUNuRSxPQUF0QixDQUFYO0FBQ0EsYUFBT29FLElBQUksQ0FBQyxtQkFBRCxDQUFKLENBQTBCRSxJQUExQixDQUErQixLQUEvQixDQUFQO0FBQ0gsS0FIRCxNQUdPO0FBQ0gvRSxhQUFPLENBQUNDLEdBQVIsQ0FBWU0sSUFBSSxDQUFDbUUsU0FBTCxDQUFlRSxRQUFmLENBQVo7QUFDSDtBQUNKO0FBQ0osQ0FsQkQsQyxDQW9CQTtBQUNBOzs7QUFFQXpGLE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsNEJBQTBCQyxPQUExQixFQUFrQztBQUM5QixRQUFJNkUsTUFBTSxHQUFHNUIsU0FBUyxDQUFDNkIsSUFBVixDQUFlO0FBQUNDLHFCQUFlLEVBQUMvRTtBQUFqQixLQUFmLEVBQTBDZ0YsS0FBMUMsRUFBYjtBQUNBLFFBQUlDLE9BQU8sR0FBR0osTUFBTSxDQUFDSyxHQUFQLENBQVcsQ0FBQ0MsS0FBRCxFQUFRekMsQ0FBUixLQUFjO0FBQ25DLGFBQU95QyxLQUFLLENBQUNDLE1BQWI7QUFDSCxLQUZhLENBQWQ7QUFHQSxRQUFJQyxXQUFXLEdBQUdoQyxTQUFTLENBQUN5QixJQUFWLENBQWU7QUFBQ00sWUFBTSxFQUFDO0FBQUNFLFdBQUcsRUFBQ0w7QUFBTDtBQUFSLEtBQWYsRUFBdUNELEtBQXZDLEVBQWxCLENBTDhCLENBTTlCOztBQUVBLFFBQUlPLGNBQWMsR0FBRyxDQUFyQjs7QUFDQSxTQUFLQyxDQUFMLElBQVVILFdBQVYsRUFBc0I7QUFDbEJFLG9CQUFjLElBQUlGLFdBQVcsQ0FBQ0csQ0FBRCxDQUFYLENBQWVDLFFBQWpDO0FBQ0g7O0FBQ0QsV0FBT0YsY0FBYyxHQUFDTixPQUFPLENBQUNsRSxNQUE5QjtBQUNILEdBZFU7O0FBZVgsc0JBQW9CZixPQUFwQixFQUE0QjtBQUN4QixRQUFJMEYsVUFBVSxHQUFHdEMsZ0JBQWdCLENBQUN1QyxhQUFqQixFQUFqQixDQUR3QixDQUV4Qjs7QUFDQSxRQUFJQyxRQUFRLEdBQUcsQ0FDWDtBQUFDQyxZQUFNLEVBQUM7QUFBQyxtQkFBVTdGO0FBQVg7QUFBUixLQURXLEVBRVg7QUFDQTtBQUFDOEYsV0FBSyxFQUFDO0FBQUMsa0JBQVMsQ0FBQztBQUFYO0FBQVAsS0FIVyxFQUlYO0FBQUNDLFlBQU0sRUFBRS9HLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCQyxZQUF2QixHQUFvQztBQUE3QyxLQUpXLEVBS1g7QUFBQ0MsYUFBTyxFQUFFO0FBQVYsS0FMVyxFQU1YO0FBQUNDLFlBQU0sRUFBQztBQUNKLGVBQU8sVUFESDtBQUVKLGtCQUFVO0FBQ04sa0JBQU87QUFDSEMsaUJBQUssRUFBRSxDQUFDO0FBQUNDLGlCQUFHLEVBQUUsQ0FBQyxTQUFELEVBQVksSUFBWjtBQUFOLGFBQUQsRUFBMkIsQ0FBM0IsRUFBOEIsQ0FBOUI7QUFESjtBQUREO0FBRk47QUFBUixLQU5XLENBQWYsQ0FId0IsQ0FrQnhCOztBQUVBLFdBQU90RCxPQUFPLENBQUN1RCxLQUFSLENBQWNiLFVBQVUsQ0FBQ2MsU0FBWCxDQUFxQlosUUFBckIsRUFBK0JhLE9BQS9CLEVBQWQsQ0FBUCxDQXBCd0IsQ0FxQnhCO0FBQ0gsR0FyQ1U7O0FBc0NYLDRCQUEwQixZQUFXO0FBQ2pDLFNBQUt4RyxPQUFMO0FBQ0EsUUFBSVYsR0FBRyxHQUFHbUgsR0FBRyxHQUFDLFNBQWQ7O0FBQ0EsUUFBRztBQUNDLFVBQUl2RyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxVQUFJb0gsTUFBTSxHQUFHdkcsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBYjtBQUNBLGFBQVFxRyxNQUFNLENBQUNwRyxNQUFQLENBQWNxRyxTQUFkLENBQXdCQyxtQkFBaEM7QUFDSCxLQUpELENBS0EsT0FBT2pILENBQVAsRUFBUztBQUNMLGFBQU8sQ0FBUDtBQUNIO0FBQ0osR0FqRFU7QUFrRFgsNkJBQTJCLFlBQVc7QUFDbEMsU0FBS0ssT0FBTDtBQUNBLFFBQUk2RyxVQUFVLEdBQUc3RCxTQUFTLENBQUM2QixJQUFWLENBQWUsRUFBZixFQUFrQjtBQUFDaUMsVUFBSSxFQUFDO0FBQUMzQixjQUFNLEVBQUMsQ0FBQztBQUFULE9BQU47QUFBa0I0QixXQUFLLEVBQUM7QUFBeEIsS0FBbEIsRUFBOENoQyxLQUE5QyxFQUFqQixDQUZrQyxDQUdsQzs7QUFDQSxRQUFJaUMsV0FBVyxHQUFHakksTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCRCxXQUF6Qzs7QUFDQSxRQUFJSCxVQUFVLElBQUlBLFVBQVUsQ0FBQy9GLE1BQVgsSUFBcUIsQ0FBdkMsRUFBMEM7QUFDdEMsVUFBSXFFLE1BQU0sR0FBRzBCLFVBQVUsQ0FBQyxDQUFELENBQVYsQ0FBYzFCLE1BQTNCO0FBQ0EsVUFBSUEsTUFBTSxHQUFHNkIsV0FBYixFQUNJLE9BQU83QixNQUFQO0FBQ1A7O0FBQ0QsV0FBTzZCLFdBQVA7QUFDSCxHQTdEVTtBQThEWCx5QkFBdUIsWUFBVztBQUM5QixRQUFJRSxPQUFKLEVBQ0ksT0FBTyxZQUFQLENBREosS0FFS3RILE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQVosRUFIeUIsQ0FJOUI7QUFDQTs7QUFDQSxRQUFJc0gsS0FBSyxHQUFHcEksTUFBTSxDQUFDcUksSUFBUCxDQUFZLHdCQUFaLENBQVosQ0FOOEIsQ0FPOUI7QUFDQTs7QUFDQSxRQUFJQyxJQUFJLEdBQUd0SSxNQUFNLENBQUNxSSxJQUFQLENBQVkseUJBQVosQ0FBWDtBQUNBeEgsV0FBTyxDQUFDQyxHQUFSLENBQVl3SCxJQUFaLEVBVjhCLENBVzlCOztBQUNBLFFBQUlGLEtBQUssR0FBR0UsSUFBWixFQUFrQjtBQUNkSCxhQUFPLEdBQUcsSUFBVjtBQUVBLFVBQUlJLFlBQVksR0FBRyxFQUFuQixDQUhjLENBSWQ7O0FBQ0FoSSxTQUFHLEdBQUdHLEdBQUcsR0FBQyxxQkFBVjs7QUFFQSxVQUFHO0FBQ0NTLGdCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQWEsWUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTdCLENBQW9DeUIsT0FBcEMsQ0FBNkNaLFNBQUQsSUFBZW1HLFlBQVksQ0FBQ25HLFNBQVMsQ0FBQ29HLGdCQUFYLENBQVosR0FBMkNwRyxTQUF0RztBQUNILE9BSEQsQ0FJQSxPQUFNeEIsQ0FBTixFQUFRO0FBQ0pDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBRURMLFNBQUcsR0FBR0csR0FBRyxHQUFDLHNDQUFWOztBQUVBLFVBQUc7QUFDQ1MsZ0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBYSxZQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBN0IsQ0FBb0N5QixPQUFwQyxDQUE2Q1osU0FBRCxJQUFlbUcsWUFBWSxDQUFDbkcsU0FBUyxDQUFDb0csZ0JBQVgsQ0FBWixHQUEyQ3BHLFNBQXRHO0FBQ0gsT0FIRCxDQUlBLE9BQU14QixDQUFOLEVBQVE7QUFDSkMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFFREwsU0FBRyxHQUFHRyxHQUFHLEdBQUMscUNBQVY7O0FBRUEsVUFBRztBQUNDUyxnQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0FhLFlBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE3QixDQUFvQ3lCLE9BQXBDLENBQTZDWixTQUFELElBQWVtRyxZQUFZLENBQUNuRyxTQUFTLENBQUNvRyxnQkFBWCxDQUFaLEdBQTJDcEcsU0FBdEc7QUFDSCxPQUhELENBSUEsT0FBTXhCLENBQU4sRUFBUTtBQUNKQyxlQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUNELFVBQUk2SCxlQUFlLEdBQUdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZSixZQUFaLEVBQTBCeEcsTUFBaEQ7QUFDQWxCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHFCQUFvQjJILGVBQWhDOztBQUNBLFdBQUssSUFBSXJDLE1BQU0sR0FBR2tDLElBQUksR0FBQyxDQUF2QixFQUEyQmxDLE1BQU0sSUFBSWdDLEtBQXJDLEVBQTZDaEMsTUFBTSxFQUFuRCxFQUF1RDtBQUNuRCxZQUFJd0MsY0FBYyxHQUFHLElBQUl4RixJQUFKLEVBQXJCLENBRG1ELENBRW5EOztBQUNBLGFBQUtuQyxPQUFMO0FBQ0EsWUFBSVYsR0FBRyxHQUFHbUgsR0FBRyxHQUFDLGdCQUFKLEdBQXVCdEIsTUFBakM7QUFDQSxZQUFJeUMsYUFBYSxHQUFHLEVBQXBCO0FBRUFoSSxlQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjs7QUFDQSxZQUFHO0FBQ0MsZ0JBQU11SSxjQUFjLEdBQUd6SSxVQUFVLENBQUNzRyxhQUFYLEdBQTJCb0MseUJBQTNCLEVBQXZCO0FBQ0EsZ0JBQU1DLG9CQUFvQixHQUFHNUUsZ0JBQWdCLENBQUN1QyxhQUFqQixHQUFpQ29DLHlCQUFqQyxFQUE3QjtBQUNBLGdCQUFNRSxhQUFhLEdBQUcxRSxrQkFBa0IsQ0FBQ29DLGFBQW5CLEdBQW1Db0MseUJBQW5DLEVBQXRCO0FBQ0EsZ0JBQU1HLGVBQWUsR0FBRzFFLFlBQVksQ0FBQ21DLGFBQWIsR0FBNkJvQyx5QkFBN0IsRUFBeEI7QUFFQSxjQUFJSSxrQkFBa0IsR0FBRyxJQUFJL0YsSUFBSixFQUF6QjtBQUNBLGNBQUlqQyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7O0FBQ0EsY0FBSVksUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCLGdCQUFJd0YsS0FBSyxHQUFHL0UsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBWjtBQUNBNkUsaUJBQUssR0FBR0EsS0FBSyxDQUFDNUUsTUFBZCxDQUYyQixDQUczQjs7QUFDQSxnQkFBSTZILFNBQVMsR0FBRyxFQUFoQjtBQUNBQSxxQkFBUyxDQUFDaEQsTUFBVixHQUFtQkEsTUFBbkI7QUFDQWdELHFCQUFTLENBQUNDLElBQVYsR0FBaUJsRCxLQUFLLENBQUNtRCxVQUFOLENBQWlCQyxRQUFqQixDQUEwQkYsSUFBM0M7QUFDQUQscUJBQVMsQ0FBQ0ksUUFBVixHQUFxQnJELEtBQUssQ0FBQ21ELFVBQU4sQ0FBaUJHLE1BQWpCLENBQXdCQyxPQUE3QztBQUNBTixxQkFBUyxDQUFDakcsSUFBVixHQUFpQixJQUFJQyxJQUFKLENBQVMrQyxLQUFLLENBQUNBLEtBQU4sQ0FBWXNELE1BQVosQ0FBbUJ0RyxJQUE1QixDQUFqQjtBQUNBaUcscUJBQVMsQ0FBQ08sYUFBVixHQUEwQnhELEtBQUssQ0FBQ0EsS0FBTixDQUFZc0QsTUFBWixDQUFtQkcsYUFBbkIsQ0FBaUNQLElBQTNEO0FBQ0FELHFCQUFTLENBQUNyRCxlQUFWLEdBQTRCSSxLQUFLLENBQUNBLEtBQU4sQ0FBWXNELE1BQVosQ0FBbUJJLGdCQUEvQztBQUNBVCxxQkFBUyxDQUFDckUsVUFBVixHQUF1QixFQUF2QjtBQUNBLGdCQUFJK0UsVUFBVSxHQUFHM0QsS0FBSyxDQUFDQSxLQUFOLENBQVk0RCxXQUFaLENBQXdCRCxVQUF6Qzs7QUFDQSxnQkFBSUEsVUFBVSxJQUFJLElBQWxCLEVBQXVCO0FBQ25CO0FBQ0EsbUJBQUssSUFBSXBHLENBQUMsR0FBQyxDQUFYLEVBQWNBLENBQUMsR0FBQ29HLFVBQVUsQ0FBQy9ILE1BQTNCLEVBQW1DMkIsQ0FBQyxFQUFwQyxFQUF1QztBQUNuQyxvQkFBSW9HLFVBQVUsQ0FBQ3BHLENBQUQsQ0FBVixJQUFpQixJQUFyQixFQUEwQjtBQUN0QjBGLDJCQUFTLENBQUNyRSxVQUFWLENBQXFCaUYsSUFBckIsQ0FBMEJGLFVBQVUsQ0FBQ3BHLENBQUQsQ0FBVixDQUFjdUcsaUJBQXhDO0FBQ0g7QUFDSjs7QUFFRHBCLDJCQUFhLENBQUNpQixVQUFkLEdBQTJCQSxVQUFVLENBQUMvSCxNQUF0QyxDQVJtQixDQVNuQjtBQUNBO0FBQ0gsYUF4QjBCLENBMEIzQjs7O0FBQ0EsZ0JBQUlvRSxLQUFLLENBQUNBLEtBQU4sQ0FBWXhELElBQVosQ0FBaUJ1SCxHQUFqQixJQUF3Qi9ELEtBQUssQ0FBQ0EsS0FBTixDQUFZeEQsSUFBWixDQUFpQnVILEdBQWpCLENBQXFCbkksTUFBckIsR0FBOEIsQ0FBMUQsRUFBNEQ7QUFDeEQsbUJBQUtvSSxDQUFMLElBQVVoRSxLQUFLLENBQUNBLEtBQU4sQ0FBWXhELElBQVosQ0FBaUJ1SCxHQUEzQixFQUErQjtBQUMzQmxLLHNCQUFNLENBQUNxSSxJQUFQLENBQVksb0JBQVosRUFBa0MzRCxNQUFNLENBQUMwRixNQUFNLENBQUNDLElBQVAsQ0FBWWxFLEtBQUssQ0FBQ0EsS0FBTixDQUFZeEQsSUFBWixDQUFpQnVILEdBQWpCLENBQXFCQyxDQUFyQixDQUFaLEVBQXFDLFFBQXJDLENBQUQsQ0FBeEMsRUFBMEZmLFNBQVMsQ0FBQ2pHLElBQXBHLEVBQTBHLENBQUNtSCxHQUFELEVBQU0vSSxNQUFOLEtBQWlCO0FBQ3ZILHNCQUFJK0ksR0FBSixFQUFRO0FBQ0p6SiwyQkFBTyxDQUFDQyxHQUFSLENBQVl3SixHQUFaO0FBQ0g7QUFDSixpQkFKRDtBQUtIO0FBQ0osYUFuQzBCLENBcUMzQjs7O0FBQ0EsZ0JBQUluRSxLQUFLLENBQUNBLEtBQU4sQ0FBWW9FLFFBQVosQ0FBcUJBLFFBQXpCLEVBQWtDO0FBQzlCOUYsdUJBQVMsQ0FBQytGLE1BQVYsQ0FBaUI7QUFDYnBFLHNCQUFNLEVBQUVBLE1BREs7QUFFYm1FLHdCQUFRLEVBQUVwRSxLQUFLLENBQUNBLEtBQU4sQ0FBWW9FLFFBQVosQ0FBcUJBO0FBRmxCLGVBQWpCO0FBSUg7O0FBRURuQixxQkFBUyxDQUFDcUIsZUFBVixHQUE0QnJCLFNBQVMsQ0FBQ3JFLFVBQVYsQ0FBcUJoRCxNQUFqRDtBQUVBOEcseUJBQWEsQ0FBQ3pDLE1BQWQsR0FBdUJBLE1BQXZCO0FBRUEsZ0JBQUlzRSxnQkFBZ0IsR0FBRyxJQUFJdEgsSUFBSixFQUF2QjtBQUNBdkMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFxQixDQUFDNEosZ0JBQWdCLEdBQUN2QixrQkFBbEIsSUFBc0MsSUFBM0QsR0FBaUUsVUFBN0U7QUFHQSxnQkFBSXdCLHNCQUFzQixHQUFHLElBQUl2SCxJQUFKLEVBQTdCLENBckQyQixDQXNEM0I7O0FBQ0E3QyxlQUFHLEdBQUdtSCxHQUFHLEdBQUMscUJBQUosR0FBMEJ0QixNQUFoQztBQUNBakYsb0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBTSxtQkFBTyxDQUFDQyxHQUFSLENBQVlQLEdBQVo7QUFDQSxnQkFBSXdFLFVBQVUsR0FBRzNELElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWpCO0FBQ0F5RCxzQkFBVSxDQUFDeEQsTUFBWCxDQUFrQnFKLFlBQWxCLEdBQWlDQyxRQUFRLENBQUM5RixVQUFVLENBQUN4RCxNQUFYLENBQWtCcUosWUFBbkIsQ0FBekM7QUFDQXpHLHlCQUFhLENBQUNxRyxNQUFkLENBQXFCekYsVUFBVSxDQUFDeEQsTUFBaEM7QUFFQTZILHFCQUFTLENBQUMwQixlQUFWLEdBQTRCL0YsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQWxCLENBQTZCaEQsTUFBekQ7QUFDQSxnQkFBSWdKLG9CQUFvQixHQUFHLElBQUkzSCxJQUFKLEVBQTNCO0FBQ0FhLHFCQUFTLENBQUN1RyxNQUFWLENBQWlCcEIsU0FBakI7QUFDQSxnQkFBSTRCLGtCQUFrQixHQUFHLElBQUk1SCxJQUFKLEVBQXpCO0FBQ0F2QyxtQkFBTyxDQUFDQyxHQUFSLENBQVksd0JBQXVCLENBQUNrSyxrQkFBa0IsR0FBQ0Qsb0JBQXBCLElBQTBDLElBQWpFLEdBQXVFLFVBQW5GLEVBbEUyQixDQW9FM0I7O0FBQ0EsZ0JBQUlFLGtCQUFrQixHQUFHNUssVUFBVSxDQUFDeUYsSUFBWCxDQUFnQjtBQUFDOUUscUJBQU8sRUFBQztBQUFDa0ssdUJBQU8sRUFBQztBQUFUO0FBQVQsYUFBaEIsRUFBMENsRixLQUExQyxFQUF6Qjs7QUFFQSxnQkFBSUksTUFBTSxHQUFHLENBQWIsRUFBZTtBQUNYO0FBQ0E7QUFDQSxtQkFBSzFDLENBQUwsSUFBVXFCLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0J3RCxVQUE1QixFQUF1QztBQUNuQyxvQkFBSS9ELE9BQU8sR0FBRytELFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0J3RCxVQUFsQixDQUE2QnJCLENBQTdCLEVBQWdDMUMsT0FBOUM7QUFDQSxvQkFBSW1LLE1BQU0sR0FBRztBQUNUL0Usd0JBQU0sRUFBRUEsTUFEQztBQUVUcEYseUJBQU8sRUFBRUEsT0FGQTtBQUdUb0ssd0JBQU0sRUFBRSxLQUhDO0FBSVRDLDhCQUFZLEVBQUVSLFFBQVEsQ0FBQzlGLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0J3RCxVQUFsQixDQUE2QnJCLENBQTdCLEVBQWdDMkgsWUFBakMsQ0FKYixDQUkyRDs7QUFKM0QsaUJBQWI7O0FBT0EscUJBQUtDLENBQUwsSUFBVXhCLFVBQVYsRUFBcUI7QUFDakIsc0JBQUlBLFVBQVUsQ0FBQ3dCLENBQUQsQ0FBVixJQUFpQixJQUFyQixFQUEwQjtBQUN0Qix3QkFBSXRLLE9BQU8sSUFBSThJLFVBQVUsQ0FBQ3dCLENBQUQsQ0FBVixDQUFjckIsaUJBQTdCLEVBQStDO0FBQzNDa0IsNEJBQU0sQ0FBQ0MsTUFBUCxHQUFnQixJQUFoQjtBQUNBdEIsZ0NBQVUsQ0FBQzdFLE1BQVgsQ0FBa0JxRyxDQUFsQixFQUFvQixDQUFwQjtBQUNBO0FBQ0g7QUFDSjtBQUNKLGlCQWpCa0MsQ0FtQm5DO0FBQ0E7OztBQUVBLG9CQUFLbEYsTUFBTSxHQUFHLEVBQVYsSUFBaUIsQ0FBckIsRUFBdUI7QUFDbkI7QUFDQSxzQkFBSW1GLFNBQVMsR0FBR3ZMLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxtQkFBWixFQUFpQ3JILE9BQWpDLENBQWhCO0FBQ0Esc0JBQUl3SyxNQUFNLEdBQUcsQ0FBYixDQUhtQixDQUluQjtBQUNBOztBQUNBLHNCQUFLRCxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLElBQWpCLElBQTJCQSxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWFDLE1BQWIsSUFBdUIsSUFBdEQsRUFBNEQ7QUFDeERBLDBCQUFNLEdBQUdELFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYUMsTUFBdEI7QUFDSDs7QUFFRCxzQkFBSUMsSUFBSSxHQUFHekwsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJDLFlBQWxDOztBQUNBLHNCQUFJZCxNQUFNLEdBQUdxRixJQUFiLEVBQWtCO0FBQ2RBLHdCQUFJLEdBQUdyRixNQUFQO0FBQ0g7O0FBRUQsc0JBQUkrRSxNQUFNLENBQUNDLE1BQVgsRUFBa0I7QUFDZCx3QkFBSUksTUFBTSxHQUFHQyxJQUFiLEVBQWtCO0FBQ2RELDRCQUFNO0FBQ1Q7O0FBQ0RBLDBCQUFNLEdBQUlBLE1BQU0sR0FBR0MsSUFBVixHQUFnQixHQUF6QjtBQUNBM0Msa0NBQWMsQ0FBQ2hELElBQWYsQ0FBb0I7QUFBQzlFLDZCQUFPLEVBQUNBO0FBQVQscUJBQXBCLEVBQXVDMEssTUFBdkMsR0FBZ0RDLFNBQWhELENBQTBEO0FBQUNDLDBCQUFJLEVBQUM7QUFBQ0osOEJBQU0sRUFBQ0EsTUFBUjtBQUFnQkssZ0NBQVEsRUFBQ3pDLFNBQVMsQ0FBQ2pHO0FBQW5DO0FBQU4scUJBQTFEO0FBQ0gsbUJBTkQsTUFPSTtBQUNBcUksMEJBQU0sR0FBSUEsTUFBTSxHQUFHQyxJQUFWLEdBQWdCLEdBQXpCO0FBQ0EzQyxrQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDOUUsNkJBQU8sRUFBQ0E7QUFBVCxxQkFBcEIsRUFBdUMwSyxNQUF2QyxHQUFnREMsU0FBaEQsQ0FBMEQ7QUFBQ0MsMEJBQUksRUFBQztBQUFDSiw4QkFBTSxFQUFDQTtBQUFSO0FBQU4scUJBQTFEO0FBQ0g7QUFDSjs7QUFFRHhDLG9DQUFvQixDQUFDd0IsTUFBckIsQ0FBNEJXLE1BQTVCLEVBbERtQyxDQW1EbkM7QUFDSDtBQUNKOztBQUVELGdCQUFJVyxXQUFXLEdBQUc1SCxLQUFLLENBQUM3QixPQUFOLENBQWM7QUFBQzBKLHFCQUFPLEVBQUM1RixLQUFLLENBQUNtRCxVQUFOLENBQWlCRyxNQUFqQixDQUF3QnVDO0FBQWpDLGFBQWQsQ0FBbEI7QUFDQSxnQkFBSUMsY0FBYyxHQUFHSCxXQUFXLEdBQUNBLFdBQVcsQ0FBQ0csY0FBYixHQUE0QixDQUE1RDtBQUNBLGdCQUFJeEYsUUFBSjtBQUNBLGdCQUFJeUYsU0FBUyxHQUFHbE0sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCaUUsZ0JBQXZDOztBQUNBLGdCQUFJRixjQUFKLEVBQW1CO0FBQ2Ysa0JBQUlHLFVBQVUsR0FBR2hELFNBQVMsQ0FBQ2pHLElBQTNCO0FBQ0Esa0JBQUlrSixRQUFRLEdBQUcsSUFBSWpKLElBQUosQ0FBUzZJLGNBQVQsQ0FBZjtBQUNBeEYsc0JBQVEsR0FBRzZGLElBQUksQ0FBQ0MsR0FBTCxDQUFTSCxVQUFVLENBQUNJLE9BQVgsS0FBdUJILFFBQVEsQ0FBQ0csT0FBVCxFQUFoQyxDQUFYO0FBQ0FOLHVCQUFTLEdBQUcsQ0FBQ0osV0FBVyxDQUFDSSxTQUFaLElBQXlCOUMsU0FBUyxDQUFDaEQsTUFBVixHQUFtQixDQUE1QyxJQUFpREssUUFBbEQsSUFBOEQyQyxTQUFTLENBQUNoRCxNQUFwRjtBQUNIOztBQUVELGdCQUFJcUcsb0JBQW9CLEdBQUcsSUFBSXJKLElBQUosRUFBM0I7QUFDQXZDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSxpQ0FBZ0MsQ0FBQzJMLG9CQUFvQixHQUFDOUIsc0JBQXRCLElBQThDLElBQTlFLEdBQW9GLFVBQWhHO0FBRUF6RyxpQkFBSyxDQUFDd0ksTUFBTixDQUFhO0FBQUNYLHFCQUFPLEVBQUM1RixLQUFLLENBQUNtRCxVQUFOLENBQWlCRyxNQUFqQixDQUF3QnVDO0FBQWpDLGFBQWIsRUFBeUQ7QUFBQ0osa0JBQUksRUFBQztBQUFDSyw4QkFBYyxFQUFDN0MsU0FBUyxDQUFDakcsSUFBMUI7QUFBZ0MrSSx5QkFBUyxFQUFDQTtBQUExQztBQUFOLGFBQXpEO0FBRUFyRCx5QkFBYSxDQUFDOEQsZ0JBQWQsR0FBaUNULFNBQWpDO0FBQ0FyRCx5QkFBYSxDQUFDcEMsUUFBZCxHQUF5QkEsUUFBekI7QUFFQW9DLHlCQUFhLENBQUMxRixJQUFkLEdBQXFCaUcsU0FBUyxDQUFDakcsSUFBL0IsQ0FwSjJCLENBc0ozQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTBGLHlCQUFhLENBQUN3QyxZQUFkLEdBQTZCLENBQTdCO0FBRUEsZ0JBQUl1QiwyQkFBMkIsR0FBRyxJQUFJeEosSUFBSixFQUFsQzs7QUFDQSxnQkFBSTJCLFVBQVUsQ0FBQ3hELE1BQWYsRUFBc0I7QUFDbEI7QUFDQVYscUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHdCQUFzQmlFLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0J3RCxVQUFsQixDQUE2QmhELE1BQS9EOztBQUNBLG1CQUFLNUIsQ0FBTCxJQUFVNEUsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQTVCLEVBQXVDO0FBQ25DO0FBQ0Esb0JBQUkzQyxTQUFTLEdBQUcyQyxVQUFVLENBQUN4RCxNQUFYLENBQWtCd0QsVUFBbEIsQ0FBNkI1RSxDQUE3QixDQUFoQjtBQUNBaUMseUJBQVMsQ0FBQ2lKLFlBQVYsR0FBeUJSLFFBQVEsQ0FBQ3pJLFNBQVMsQ0FBQ2lKLFlBQVgsQ0FBakM7QUFDQWpKLHlCQUFTLENBQUN5SyxpQkFBVixHQUE4QmhDLFFBQVEsQ0FBQ3pJLFNBQVMsQ0FBQ3lLLGlCQUFYLENBQXRDO0FBRUEsb0JBQUlDLFFBQVEsR0FBR3pNLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQyxtQ0FBZ0JELFNBQVMsQ0FBQzJLLE9BQVYsQ0FBa0JyTDtBQUFuQyxpQkFBbkIsQ0FBZjs7QUFDQSxvQkFBSSxDQUFDb0wsUUFBTCxFQUFjO0FBQ1ZqTSx5QkFBTyxDQUFDQyxHQUFSLDZCQUFpQ3NCLFNBQVMsQ0FBQ3BCLE9BQTNDLGNBQXNEb0IsU0FBUyxDQUFDMkssT0FBVixDQUFrQnJMLEtBQXhFLGlCQURVLENBRVY7QUFDQTtBQUNBOztBQUVBVSwyQkFBUyxDQUFDcEIsT0FBVixHQUFvQjJELFVBQVUsQ0FBQ3ZDLFNBQVMsQ0FBQzJLLE9BQVgsQ0FBOUI7QUFDQTNLLDJCQUFTLENBQUM0SyxNQUFWLEdBQW1CaE4sTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCakcsU0FBUyxDQUFDMkssT0FBeEMsRUFBaUQvTSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmdHLGtCQUF4RSxDQUFuQjtBQUNBN0ssMkJBQVMsQ0FBQzhLLGVBQVYsR0FBNEJsTixNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJqRyxTQUFTLENBQUMySyxPQUF4QyxFQUFpRC9NLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCa0csa0JBQXhFLENBQTVCO0FBQ0EvSywyQkFBUyxDQUFDb0csZ0JBQVYsR0FBNkJ4SSxNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJqRyxTQUFTLENBQUMySyxPQUF4QyxFQUFpRC9NLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCbUcsbUJBQXhFLENBQTdCO0FBRUEsc0JBQUlDLGFBQWEsR0FBRzlFLFlBQVksQ0FBQ25HLFNBQVMsQ0FBQ29HLGdCQUFYLENBQWhDOztBQUNBLHNCQUFJNkUsYUFBSixFQUFrQjtBQUNkLHdCQUFJQSxhQUFhLENBQUNDLFdBQWQsQ0FBMEJuSSxRQUE5QixFQUNJL0MsU0FBUyxDQUFDbUwsV0FBVixHQUF5QnJJLHNCQUFzQixDQUFDbUksYUFBYSxDQUFDQyxXQUFkLENBQTBCbkksUUFBM0IsQ0FBL0M7QUFDSi9DLDZCQUFTLENBQUNHLGdCQUFWLEdBQTZCOEssYUFBYSxDQUFDOUssZ0JBQTNDO0FBQ0FILDZCQUFTLENBQUNJLGlCQUFWLEdBQThCeEMsTUFBTSxDQUFDcUksSUFBUCxDQUFZLGNBQVosRUFBNEJnRixhQUFhLENBQUM5SyxnQkFBMUMsQ0FBOUI7QUFDQUgsNkJBQVMsQ0FBQ29MLE1BQVYsR0FBbUJILGFBQWEsQ0FBQ0csTUFBakM7QUFDQXBMLDZCQUFTLENBQUN1RixNQUFWLEdBQW1CMEYsYUFBYSxDQUFDMUYsTUFBakM7QUFDQXZGLDZCQUFTLENBQUNxTCxtQkFBVixHQUFnQ0osYUFBYSxDQUFDSSxtQkFBOUM7QUFDQXJMLDZCQUFTLENBQUNzTCxNQUFWLEdBQW1CTCxhQUFhLENBQUNLLE1BQWpDO0FBQ0F0TCw2QkFBUyxDQUFDdUwsZ0JBQVYsR0FBNkJOLGFBQWEsQ0FBQ00sZ0JBQTNDO0FBQ0F2TCw2QkFBUyxDQUFDa0wsV0FBVixHQUF3QkQsYUFBYSxDQUFDQyxXQUF0QztBQUNBbEwsNkJBQVMsQ0FBQ3dMLFdBQVYsR0FBd0JQLGFBQWEsQ0FBQ08sV0FBdEM7QUFDQXhMLDZCQUFTLENBQUN5TCxxQkFBVixHQUFrQ1IsYUFBYSxDQUFDUSxxQkFBaEQ7QUFDQXpMLDZCQUFTLENBQUMwTCxnQkFBVixHQUE2QlQsYUFBYSxDQUFDUyxnQkFBM0M7QUFDQTFMLDZCQUFTLENBQUMyTCxjQUFWLEdBQTJCVixhQUFhLENBQUNVLGNBQXpDO0FBQ0EzTCw2QkFBUyxDQUFDTSxVQUFWLEdBQXVCMkssYUFBYSxDQUFDM0ssVUFBckM7QUFDQU4sNkJBQVMsQ0FBQzRMLGVBQVYsR0FBNEI1TCxTQUFTLENBQUN1TCxnQkFBdEMsQ0FoQmMsQ0FpQmQ7QUFDQTtBQUNBO0FBQ0gsbUJBcEJELE1Bb0JPO0FBQ0g5TSwyQkFBTyxDQUFDQyxHQUFSLENBQVksaUJBQVo7QUFDSCxtQkFsQ1MsQ0FvQ1Y7OztBQUNBZ0ksZ0NBQWMsQ0FBQ2hELElBQWYsQ0FBb0I7QUFBQzBDLG9DQUFnQixFQUFFcEcsU0FBUyxDQUFDb0c7QUFBN0IsbUJBQXBCLEVBQW9Fa0QsTUFBcEUsR0FBNkVDLFNBQTdFLENBQXVGO0FBQUNDLHdCQUFJLEVBQUN4SjtBQUFOLG1CQUF2RixFQXJDVSxDQXNDVjs7QUFDQTZHLCtCQUFhLENBQUN1QixNQUFkLENBQXFCO0FBQ2pCeEosMkJBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCLE9BREY7QUFFakJpTixxQ0FBaUIsRUFBRSxDQUZGO0FBR2pCNUMsZ0NBQVksRUFBRWpKLFNBQVMsQ0FBQ2lKLFlBSFA7QUFJakI1Six3QkFBSSxFQUFFLEtBSlc7QUFLakIyRSwwQkFBTSxFQUFFZ0QsU0FBUyxDQUFDaEQsTUFMRDtBQU1qQjhILDhCQUFVLEVBQUU5RSxTQUFTLENBQUNqRztBQU5MLG1CQUFyQixFQXZDVSxDQWdEVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSUE7QUFDSCxpQkEvREQsTUFnRUk7QUFDQSxzQkFBSWtLLGFBQWEsR0FBRzlFLFlBQVksQ0FBQ3VFLFFBQVEsQ0FBQ3RFLGdCQUFWLENBQWhDOztBQUNBLHNCQUFJNkUsYUFBSixFQUFrQjtBQUNkLHdCQUFJQSxhQUFhLENBQUNDLFdBQWQsS0FBOEIsQ0FBQ1IsUUFBUSxDQUFDUSxXQUFWLElBQXlCRCxhQUFhLENBQUNDLFdBQWQsQ0FBMEJuSSxRQUExQixLQUF1QzJILFFBQVEsQ0FBQ1EsV0FBVCxDQUFxQm5JLFFBQW5ILENBQUosRUFDSS9DLFNBQVMsQ0FBQ21MLFdBQVYsR0FBeUJySSxzQkFBc0IsQ0FBQ21JLGFBQWEsQ0FBQ0MsV0FBZCxDQUEwQm5JLFFBQTNCLENBQS9DO0FBQ0ovQyw2QkFBUyxDQUFDb0wsTUFBVixHQUFtQkgsYUFBYSxDQUFDRyxNQUFqQztBQUNBcEwsNkJBQVMsQ0FBQ3VGLE1BQVYsR0FBbUIwRixhQUFhLENBQUMxRixNQUFqQztBQUNBdkYsNkJBQVMsQ0FBQ3NMLE1BQVYsR0FBbUJMLGFBQWEsQ0FBQ0ssTUFBakM7QUFDQXRMLDZCQUFTLENBQUN1TCxnQkFBVixHQUE2Qk4sYUFBYSxDQUFDTSxnQkFBM0M7QUFDQXZMLDZCQUFTLENBQUNrTCxXQUFWLEdBQXdCRCxhQUFhLENBQUNDLFdBQXRDO0FBQ0FsTCw2QkFBUyxDQUFDd0wsV0FBVixHQUF3QlAsYUFBYSxDQUFDTyxXQUF0QztBQUNBeEwsNkJBQVMsQ0FBQ3lMLHFCQUFWLEdBQWtDUixhQUFhLENBQUNRLHFCQUFoRDtBQUNBekwsNkJBQVMsQ0FBQzBMLGdCQUFWLEdBQTZCVCxhQUFhLENBQUNTLGdCQUEzQztBQUNBMUwsNkJBQVMsQ0FBQzJMLGNBQVYsR0FBMkJWLGFBQWEsQ0FBQ1UsY0FBekM7QUFDQTNMLDZCQUFTLENBQUNNLFVBQVYsR0FBdUIySyxhQUFhLENBQUMzSyxVQUFyQyxDQVpjLENBY2Q7O0FBRUEsd0JBQUkwRCxNQUFNLEdBQUcsRUFBVCxJQUFlLENBQW5CLEVBQXFCO0FBQ2pCLDBCQUFHO0FBQ0MsNEJBQUlqRixRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTQyxHQUFHLEdBQUcsc0JBQU4sR0FBNkJvTSxRQUFRLENBQUN0SyxpQkFBdEMsR0FBd0QsZUFBeEQsR0FBd0VzSyxRQUFRLENBQUN2SyxnQkFBMUYsQ0FBZjs7QUFFQSw0QkFBSXBCLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQiw4QkFBSXdOLGNBQWMsR0FBRy9NLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUFsRDs7QUFDQSw4QkFBSTRNLGNBQWMsQ0FBQ3ZMLE1BQW5CLEVBQTBCO0FBQ3RCUixxQ0FBUyxDQUFDNEwsZUFBVixHQUE0Qm5MLFVBQVUsQ0FBQ3NMLGNBQWMsQ0FBQ3ZMLE1BQWhCLENBQVYsR0FBa0NDLFVBQVUsQ0FBQ1QsU0FBUyxDQUFDdUwsZ0JBQVgsQ0FBeEU7QUFDSDtBQUNKO0FBQ0osdUJBVEQsQ0FVQSxPQUFNL00sQ0FBTixFQUFRLENBQ0o7QUFDSDtBQUNKOztBQUVEa0ksa0NBQWMsQ0FBQ2hELElBQWYsQ0FBb0I7QUFBQzBDLHNDQUFnQixFQUFFc0UsUUFBUSxDQUFDdEU7QUFBNUIscUJBQXBCLEVBQW1FbUQsU0FBbkUsQ0FBNkU7QUFBQ0MsMEJBQUksRUFBQ3hKO0FBQU4scUJBQTdFLEVBaENjLENBaUNkO0FBQ0E7QUFDSCxtQkFuQ0QsTUFtQ1E7QUFDSnZCLDJCQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWjtBQUNIOztBQUNELHNCQUFJc04sZUFBZSxHQUFHN0osa0JBQWtCLENBQUNsQyxPQUFuQixDQUEyQjtBQUFDckIsMkJBQU8sRUFBQ29CLFNBQVMsQ0FBQ3BCO0FBQW5CLG1CQUEzQixFQUF3RDtBQUFDb0YsMEJBQU0sRUFBQyxDQUFDLENBQVQ7QUFBWTRCLHlCQUFLLEVBQUM7QUFBbEIsbUJBQXhELENBQXRCOztBQUVBLHNCQUFJb0csZUFBSixFQUFvQjtBQUNoQix3QkFBSUEsZUFBZSxDQUFDL0MsWUFBaEIsSUFBZ0NqSixTQUFTLENBQUNpSixZQUE5QyxFQUEyRDtBQUN2RCwwQkFBSWdELFVBQVUsR0FBSUQsZUFBZSxDQUFDL0MsWUFBaEIsR0FBK0JqSixTQUFTLENBQUNpSixZQUExQyxHQUF3RCxNQUF4RCxHQUErRCxJQUFoRjtBQUNBLDBCQUFJaUQsVUFBVSxHQUFHO0FBQ2J0TiwrQkFBTyxFQUFFb0IsU0FBUyxDQUFDcEIsT0FETjtBQUViaU4seUNBQWlCLEVBQUVHLGVBQWUsQ0FBQy9DLFlBRnRCO0FBR2JBLG9DQUFZLEVBQUVqSixTQUFTLENBQUNpSixZQUhYO0FBSWI1Siw0QkFBSSxFQUFFNE0sVUFKTztBQUtiakksOEJBQU0sRUFBRWdELFNBQVMsQ0FBQ2hELE1BTEw7QUFNYjhILGtDQUFVLEVBQUU5RSxTQUFTLENBQUNqRztBQU5ULHVCQUFqQixDQUZ1RCxDQVV2RDtBQUNBOztBQUNBOEYsbUNBQWEsQ0FBQ3VCLE1BQWQsQ0FBcUI4RCxVQUFyQjtBQUNIO0FBQ0o7QUFFSixpQkFsSWtDLENBcUluQzs7O0FBRUF6Riw2QkFBYSxDQUFDd0MsWUFBZCxJQUE4QmpKLFNBQVMsQ0FBQ2lKLFlBQXhDO0FBQ0gsZUEzSWlCLENBNklsQjs7O0FBRUEsa0JBQUl2RyxjQUFjLEdBQUdYLGFBQWEsQ0FBQzlCLE9BQWQsQ0FBc0I7QUFBQ3VJLDRCQUFZLEVBQUN4RSxNQUFNLEdBQUM7QUFBckIsZUFBdEIsQ0FBckI7O0FBRUEsa0JBQUl0QixjQUFKLEVBQW1CO0FBQ2Ysb0JBQUl5SixpQkFBaUIsR0FBRzFKLG9CQUFvQixDQUFDQyxjQUFjLENBQUNDLFVBQWhCLEVBQTRCQSxVQUFVLENBQUN4RCxNQUFYLENBQWtCd0QsVUFBOUMsQ0FBNUM7O0FBRUEscUJBQUt5SixDQUFMLElBQVVELGlCQUFWLEVBQTRCO0FBQ3hCdEYsK0JBQWEsQ0FBQ3VCLE1BQWQsQ0FBcUI7QUFDakJ4SiwyQkFBTyxFQUFFdU4saUJBQWlCLENBQUNDLENBQUQsQ0FBakIsQ0FBcUJ4TixPQURiO0FBRWpCaU4scUNBQWlCLEVBQUVNLGlCQUFpQixDQUFDQyxDQUFELENBQWpCLENBQXFCbkQsWUFGdkI7QUFHakJBLGdDQUFZLEVBQUUsQ0FIRztBQUlqQjVKLHdCQUFJLEVBQUUsUUFKVztBQUtqQjJFLDBCQUFNLEVBQUVnRCxTQUFTLENBQUNoRCxNQUxEO0FBTWpCOEgsOEJBQVUsRUFBRTlFLFNBQVMsQ0FBQ2pHO0FBTkwsbUJBQXJCO0FBUUg7QUFDSjtBQUVKLGFBOVQwQixDQWlVM0I7OztBQUNBLGdCQUFJaUQsTUFBTSxHQUFHLEtBQVQsSUFBa0IsQ0FBdEIsRUFBd0I7QUFDcEIsa0JBQUk7QUFDQXZGLHVCQUFPLENBQUNDLEdBQVIsQ0FBWSx1Q0FBWjtBQUNBLG9CQUFJMk4sWUFBWSxHQUFHLEVBQW5CO0FBQ0FwTywwQkFBVSxDQUFDeUYsSUFBWCxDQUFnQixFQUFoQixFQUFvQjtBQUFDNEksd0JBQU0sRUFBRTtBQUFDbEcsb0NBQWdCLEVBQUUsQ0FBbkI7QUFBc0JiLDBCQUFNLEVBQUU7QUFBOUI7QUFBVCxpQkFBcEIsRUFDTTNFLE9BRE4sQ0FDZTdDLENBQUQsSUFBT3NPLFlBQVksQ0FBQ3RPLENBQUMsQ0FBQ3FJLGdCQUFILENBQVosR0FBbUNySSxDQUFDLENBQUN3SCxNQUQxRDtBQUVBZSxzQkFBTSxDQUFDQyxJQUFQLENBQVlKLFlBQVosRUFBMEJ2RixPQUExQixDQUFtQzJMLFNBQUQsSUFBZTtBQUM3QyxzQkFBSXRCLGFBQWEsR0FBRzlFLFlBQVksQ0FBQ29HLFNBQUQsQ0FBaEMsQ0FENkMsQ0FFN0M7O0FBQ0Esc0JBQUl0QixhQUFhLENBQUMxRixNQUFkLEtBQXlCLENBQTdCLEVBQ0k7O0FBRUosc0JBQUk4RyxZQUFZLENBQUNFLFNBQUQsQ0FBWixJQUEyQkMsU0FBL0IsRUFBMEM7QUFDdEMvTiwyQkFBTyxDQUFDQyxHQUFSLDJDQUErQzZOLFNBQS9DO0FBRUF0QixpQ0FBYSxDQUFDTixPQUFkLEdBQXdCO0FBQ3BCLDhCQUFTLDBCQURXO0FBRXBCLCtCQUFTL00sTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCc0csU0FBOUI7QUFGVyxxQkFBeEI7QUFJQXRCLGlDQUFhLENBQUNyTSxPQUFkLEdBQXdCMkQsVUFBVSxDQUFDMEksYUFBYSxDQUFDTixPQUFmLENBQWxDO0FBQ0FNLGlDQUFhLENBQUM3SyxpQkFBZCxHQUFrQ3hDLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxjQUFaLEVBQTRCZ0YsYUFBYSxDQUFDOUssZ0JBQTFDLENBQWxDO0FBRUE4SyxpQ0FBYSxDQUFDTCxNQUFkLEdBQXVCaE4sTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCZ0YsYUFBYSxDQUFDTixPQUE1QyxFQUFxRC9NLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCZ0csa0JBQTVFLENBQXZCO0FBQ0FJLGlDQUFhLENBQUNILGVBQWQsR0FBZ0NsTixNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJnRixhQUFhLENBQUNOLE9BQTVDLEVBQXFEL00sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJrRyxrQkFBNUUsQ0FBaEM7QUFDQXRNLDJCQUFPLENBQUNDLEdBQVIsQ0FBWU0sSUFBSSxDQUFDbUUsU0FBTCxDQUFlOEgsYUFBZixDQUFaO0FBQ0F2RSxrQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDMEMsc0NBQWdCLEVBQUVtRztBQUFuQixxQkFBcEIsRUFBbURqRCxNQUFuRCxHQUE0REMsU0FBNUQsQ0FBc0U7QUFBQ0MsMEJBQUksRUFBQ3lCO0FBQU4scUJBQXRFO0FBQ0gsbUJBZEQsTUFjTyxJQUFJb0IsWUFBWSxDQUFDRSxTQUFELENBQVosSUFBMkIsQ0FBL0IsRUFBa0M7QUFDckM3RixrQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDMEMsc0NBQWdCLEVBQUVtRztBQUFuQixxQkFBcEIsRUFBbURqRCxNQUFuRCxHQUE0REMsU0FBNUQsQ0FBc0U7QUFBQ0MsMEJBQUksRUFBQ3lCO0FBQU4scUJBQXRFO0FBQ0g7QUFDSixpQkF2QkQ7QUF3QkgsZUE3QkQsQ0E2QkUsT0FBT3pNLENBQVAsRUFBUztBQUNQQyx1QkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLGFBblcwQixDQXFXM0I7OztBQUNBLGdCQUFJd0YsTUFBTSxHQUFHLEtBQVQsSUFBa0IsQ0FBdEIsRUFBd0I7QUFDcEJ2RixxQkFBTyxDQUFDQyxHQUFSLENBQVkscUJBQVo7QUFDQVQsd0JBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0I5QyxPQUFwQixDQUE2QlosU0FBRCxJQUFlO0FBQ3ZDLG9CQUFJO0FBQ0Esc0JBQUl5TSxVQUFVLEdBQUkzSixzQkFBc0IsQ0FBQzlDLFNBQVMsQ0FBQ2tMLFdBQVYsQ0FBc0JuSSxRQUF2QixDQUF4Qzs7QUFDQSxzQkFBSTBKLFVBQUosRUFBZ0I7QUFDWi9GLGtDQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUM5RSw2QkFBTyxFQUFFb0IsU0FBUyxDQUFDcEI7QUFBcEIscUJBQXBCLEVBQ00wSyxNQUROLEdBQ2VDLFNBRGYsQ0FDeUI7QUFBQ0MsMEJBQUksRUFBQztBQUFDLHVDQUFjaUQ7QUFBZjtBQUFOLHFCQUR6QjtBQUVIO0FBQ0osaUJBTkQsQ0FNRSxPQUFPak8sQ0FBUCxFQUFVO0FBQ1JDLHlCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osZUFWRDtBQVdIOztBQUVELGdCQUFJa08seUJBQXlCLEdBQUcsSUFBSTFMLElBQUosRUFBaEM7QUFDQXZDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSwrQkFBOEIsQ0FBQ2dPLHlCQUF5QixHQUFDbEMsMkJBQTNCLElBQXdELElBQXRGLEdBQTRGLFVBQXhHLEVBdFgyQixDQXdYM0I7O0FBQ0EsZ0JBQUltQyx1QkFBdUIsR0FBRyxJQUFJM0wsSUFBSixFQUE5QjtBQUNBaUIscUJBQVMsQ0FBQ21HLE1BQVYsQ0FBaUIzQixhQUFqQjtBQUNBLGdCQUFJbUcsc0JBQXNCLEdBQUcsSUFBSTVMLElBQUosRUFBN0I7QUFDQXZDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSw0QkFBMkIsQ0FBQ2tPLHNCQUFzQixHQUFDRCx1QkFBeEIsSUFBaUQsSUFBNUUsR0FBa0YsVUFBOUY7QUFFQSxnQkFBSUUsWUFBWSxHQUFHLElBQUk3TCxJQUFKLEVBQW5COztBQUNBLGdCQUFJMEYsY0FBYyxDQUFDL0csTUFBZixHQUF3QixDQUE1QixFQUE4QjtBQUMxQjtBQUNBK0csNEJBQWMsQ0FBQ29HLE9BQWYsQ0FBdUIsQ0FBQzVFLEdBQUQsRUFBTS9JLE1BQU4sS0FBaUI7QUFDcEMsb0JBQUkrSSxHQUFKLEVBQVE7QUFDSnpKLHlCQUFPLENBQUNDLEdBQVIsQ0FBWXdKLEdBQVo7QUFDSDs7QUFDRCxvQkFBSS9JLE1BQUosRUFBVyxDQUNQO0FBQ0g7QUFDSixlQVBEO0FBUUg7O0FBRUQsZ0JBQUk0TixVQUFVLEdBQUcsSUFBSS9MLElBQUosRUFBakI7QUFDQXZDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSw0QkFBMkIsQ0FBQ3FPLFVBQVUsR0FBQ0YsWUFBWixJQUEwQixJQUFyRCxHQUEyRCxVQUF2RTtBQUVBLGdCQUFJRyxXQUFXLEdBQUcsSUFBSWhNLElBQUosRUFBbEI7O0FBQ0EsZ0JBQUk0RixvQkFBb0IsQ0FBQ2pILE1BQXJCLEdBQThCLENBQWxDLEVBQW9DO0FBQ2hDaUgsa0NBQW9CLENBQUNrRyxPQUFyQixDQUE2QixDQUFDNUUsR0FBRCxFQUFNL0ksTUFBTixLQUFpQjtBQUMxQyxvQkFBSStJLEdBQUosRUFBUTtBQUNKekoseUJBQU8sQ0FBQ0MsR0FBUixDQUFZd0osR0FBWjtBQUNIO0FBQ0osZUFKRDtBQUtIOztBQUVELGdCQUFJK0UsU0FBUyxHQUFHLElBQUlqTSxJQUFKLEVBQWhCO0FBQ0F2QyxtQkFBTyxDQUFDQyxHQUFSLENBQVksb0NBQW1DLENBQUN1TyxTQUFTLEdBQUNELFdBQVgsSUFBd0IsSUFBM0QsR0FBaUUsVUFBN0U7O0FBRUEsZ0JBQUluRyxhQUFhLENBQUNsSCxNQUFkLEdBQXVCLENBQTNCLEVBQTZCO0FBQ3pCa0gsMkJBQWEsQ0FBQ2lHLE9BQWQsQ0FBc0IsQ0FBQzVFLEdBQUQsRUFBTS9JLE1BQU4sS0FBaUI7QUFDbkMsb0JBQUkrSSxHQUFKLEVBQVE7QUFDSnpKLHlCQUFPLENBQUNDLEdBQVIsQ0FBWXdKLEdBQVo7QUFDSDtBQUNKLGVBSkQ7QUFLSDs7QUFFRCxnQkFBSXBCLGVBQWUsQ0FBQ25ILE1BQWhCLEdBQXlCLENBQTdCLEVBQStCO0FBQzNCbUgsNkJBQWUsQ0FBQ2dHLE9BQWhCLENBQXdCLENBQUM1RSxHQUFELEVBQU0vSSxNQUFOLEtBQWlCO0FBQ3JDLG9CQUFJK0ksR0FBSixFQUFRO0FBQ0p6Six5QkFBTyxDQUFDQyxHQUFSLENBQVl3SixHQUFaO0FBQ0g7QUFDSixlQUpEO0FBS0gsYUF4YTBCLENBMGEzQjs7O0FBRUEsZ0JBQUlsRSxNQUFNLEdBQUcsRUFBVCxJQUFlLENBQW5CLEVBQXFCO0FBQ2pCdkYscUJBQU8sQ0FBQ0MsR0FBUixDQUFZLGlEQUFaO0FBQ0Esa0JBQUl3TyxnQkFBZ0IsR0FBR2pQLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0I7QUFBQzZCLHNCQUFNLEVBQUMsQ0FBUjtBQUFVNkYsc0JBQU0sRUFBQztBQUFqQixlQUFoQixFQUF3QztBQUFDekYsb0JBQUksRUFBQztBQUFDc0QsOEJBQVksRUFBQyxDQUFDO0FBQWY7QUFBTixlQUF4QyxFQUFrRXJGLEtBQWxFLEVBQXZCO0FBQ0Esa0JBQUl1SixZQUFZLEdBQUdqRCxJQUFJLENBQUNrRCxJQUFMLENBQVVGLGdCQUFnQixDQUFDdk4sTUFBakIsR0FBd0IsR0FBbEMsQ0FBbkI7QUFDQSxrQkFBSTBOLGVBQWUsR0FBR0gsZ0JBQWdCLENBQUN2TixNQUFqQixHQUEwQndOLFlBQWhEO0FBRUEsa0JBQUlHLGNBQWMsR0FBRyxDQUFyQjtBQUNBLGtCQUFJQyxpQkFBaUIsR0FBRyxDQUF4QjtBQUVBLGtCQUFJQyxnQkFBZ0IsR0FBRyxDQUF2QjtBQUNBLGtCQUFJQyxpQkFBaUIsR0FBRyxDQUF4QjtBQUNBLGtCQUFJQyxvQkFBb0IsR0FBRyxDQUEzQjtBQUNBLGtCQUFJQyxxQkFBcUIsR0FBRyxDQUE1Qjs7QUFJQSxtQkFBSzVQLENBQUwsSUFBVW1QLGdCQUFWLEVBQTJCO0FBQ3ZCLG9CQUFJblAsQ0FBQyxHQUFHb1AsWUFBUixFQUFxQjtBQUNqQkcsZ0NBQWMsSUFBSUosZ0JBQWdCLENBQUNuUCxDQUFELENBQWhCLENBQW9Ca0wsWUFBdEM7QUFDSCxpQkFGRCxNQUdJO0FBQ0FzRSxtQ0FBaUIsSUFBSUwsZ0JBQWdCLENBQUNuUCxDQUFELENBQWhCLENBQW9Ca0wsWUFBekM7QUFDSDs7QUFHRCxvQkFBSXlFLG9CQUFvQixHQUFHLElBQTNCLEVBQWdDO0FBQzVCQSxzQ0FBb0IsSUFBSVIsZ0JBQWdCLENBQUNuUCxDQUFELENBQWhCLENBQW9Ca0wsWUFBcEIsR0FBbUN4QyxhQUFhLENBQUN3QyxZQUF6RTtBQUNBdUUsa0NBQWdCO0FBQ25CO0FBQ0o7O0FBRURHLG1DQUFxQixHQUFHLElBQUlELG9CQUE1QjtBQUNBRCwrQkFBaUIsR0FBR1AsZ0JBQWdCLENBQUN2TixNQUFqQixHQUEwQjZOLGdCQUE5QztBQUVBLGtCQUFJSSxNQUFNLEdBQUc7QUFDVDVKLHNCQUFNLEVBQUVBLE1BREM7QUFFVG1KLDRCQUFZLEVBQUVBLFlBRkw7QUFHVEcsOEJBQWMsRUFBRUEsY0FIUDtBQUlURCwrQkFBZSxFQUFFQSxlQUpSO0FBS1RFLGlDQUFpQixFQUFFQSxpQkFMVjtBQU1UQyxnQ0FBZ0IsRUFBRUEsZ0JBTlQ7QUFPVEUsb0NBQW9CLEVBQUVBLG9CQVBiO0FBUVRELGlDQUFpQixFQUFFQSxpQkFSVjtBQVNURSxxQ0FBcUIsRUFBRUEscUJBVGQ7QUFVVEUsNkJBQWEsRUFBRVgsZ0JBQWdCLENBQUN2TixNQVZ2QjtBQVdUbU8sZ0NBQWdCLEVBQUVySCxhQUFhLENBQUN3QyxZQVh2QjtBQVlUYSx5QkFBUyxFQUFFOUMsU0FBUyxDQUFDakcsSUFaWjtBQWFUZ04sd0JBQVEsRUFBRSxJQUFJL00sSUFBSjtBQWJELGVBQWI7QUFnQkF2QyxxQkFBTyxDQUFDQyxHQUFSLENBQVlrUCxNQUFaO0FBRUExTCw2QkFBZSxDQUFDa0csTUFBaEIsQ0FBdUJ3RixNQUF2QjtBQUNIO0FBQ0o7QUFDSixTQTNlRCxDQTRlQSxPQUFPcFAsQ0FBUCxFQUFTO0FBQ0xDLGlCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNBdUgsaUJBQU8sR0FBRyxLQUFWO0FBQ0EsaUJBQU8sU0FBUDtBQUNIOztBQUNELFlBQUlpSSxZQUFZLEdBQUcsSUFBSWhOLElBQUosRUFBbkI7QUFDQXZDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFxQixDQUFDc1AsWUFBWSxHQUFDeEgsY0FBZCxJQUE4QixJQUFuRCxHQUF5RCxVQUFyRTtBQUNIOztBQUNEVCxhQUFPLEdBQUcsS0FBVjtBQUNBakUsV0FBSyxDQUFDd0ksTUFBTixDQUFhO0FBQUNYLGVBQU8sRUFBQy9MLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEU7QUFBaEMsT0FBYixFQUF1RDtBQUFDSCxZQUFJLEVBQUM7QUFBQ3lFLDhCQUFvQixFQUFDLElBQUlqTixJQUFKLEVBQXRCO0FBQWtDcUYseUJBQWUsRUFBQ0E7QUFBbEQ7QUFBTixPQUF2RDtBQUNIOztBQUVELFdBQU9MLEtBQVA7QUFDSCxHQS9tQlU7QUFnbkJYLGNBQVksVUFBU0osS0FBVCxFQUFnQjtBQUN4QjtBQUNBLFdBQVFBLEtBQUssR0FBQyxFQUFkO0FBQ0gsR0FubkJVO0FBb25CWCxhQUFXLFVBQVNBLEtBQVQsRUFBZ0I7QUFDdkIsUUFBSUEsS0FBSyxHQUFHaEksTUFBTSxDQUFDcUksSUFBUCxDQUFZLGtCQUFaLENBQVosRUFBNkM7QUFDekMsYUFBUSxLQUFSO0FBQ0gsS0FGRCxNQUVPO0FBQ0gsYUFBUSxJQUFSO0FBQ0g7QUFDSjtBQTFuQlUsQ0FBZixFOzs7Ozs7Ozs7OztBQzdEQSxJQUFJckksTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJOEQsU0FBSjtBQUFjaEUsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDK0QsV0FBUyxDQUFDOUQsQ0FBRCxFQUFHO0FBQUM4RCxhQUFTLEdBQUM5RCxDQUFWO0FBQVk7O0FBQTFCLENBQTNCLEVBQXVELENBQXZEO0FBQTBELElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBQThFLElBQUlxRSxZQUFKO0FBQWlCdkUsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ3NFLGNBQVksQ0FBQ3JFLENBQUQsRUFBRztBQUFDcUUsZ0JBQVksR0FBQ3JFLENBQWI7QUFBZTs7QUFBaEMsQ0FBakQsRUFBbUYsQ0FBbkY7QUFLdFBtUSxnQkFBZ0IsQ0FBQyxlQUFELEVBQWtCLFVBQVN0SSxLQUFULEVBQWU7QUFDN0MsU0FBTztBQUNIbEMsUUFBSSxHQUFFO0FBQ0YsYUFBTzdCLFNBQVMsQ0FBQzZCLElBQVYsQ0FBZSxFQUFmLEVBQW1CO0FBQUNrQyxhQUFLLEVBQUVBLEtBQVI7QUFBZUQsWUFBSSxFQUFFO0FBQUMzQixnQkFBTSxFQUFFLENBQUM7QUFBVjtBQUFyQixPQUFuQixDQUFQO0FBQ0gsS0FIRTs7QUFJSG1LLFlBQVEsRUFBRSxDQUNOO0FBQ0l6SyxVQUFJLENBQUNLLEtBQUQsRUFBTztBQUNQLGVBQU85RixVQUFVLENBQUN5RixJQUFYLENBQ0g7QUFBQzlFLGlCQUFPLEVBQUNtRixLQUFLLENBQUNKO0FBQWYsU0FERyxFQUVIO0FBQUNpQyxlQUFLLEVBQUM7QUFBUCxTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNO0FBSlAsR0FBUDtBQWVILENBaEJlLENBQWhCO0FBa0JBc0ksZ0JBQWdCLENBQUMsZ0JBQUQsRUFBbUIsVUFBU2xLLE1BQVQsRUFBZ0I7QUFDL0MsU0FBTztBQUNITixRQUFJLEdBQUU7QUFDRixhQUFPN0IsU0FBUyxDQUFDNkIsSUFBVixDQUFlO0FBQUNNLGNBQU0sRUFBQ0E7QUFBUixPQUFmLENBQVA7QUFDSCxLQUhFOztBQUlIbUssWUFBUSxFQUFFLENBQ047QUFDSXpLLFVBQUksQ0FBQ0ssS0FBRCxFQUFPO0FBQ1AsZUFBTzNCLFlBQVksQ0FBQ3NCLElBQWIsQ0FDSDtBQUFDTSxnQkFBTSxFQUFDRCxLQUFLLENBQUNDO0FBQWQsU0FERyxDQUFQO0FBR0g7O0FBTEwsS0FETSxFQVFOO0FBQ0lOLFVBQUksQ0FBQ0ssS0FBRCxFQUFPO0FBQ1AsZUFBTzlGLFVBQVUsQ0FBQ3lGLElBQVgsQ0FDSDtBQUFDOUUsaUJBQU8sRUFBQ21GLEtBQUssQ0FBQ0o7QUFBZixTQURHLEVBRUg7QUFBQ2lDLGVBQUssRUFBQztBQUFQLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBUk07QUFKUCxHQUFQO0FBc0JILENBdkJlLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDdkJBL0gsTUFBTSxDQUFDdVEsTUFBUCxDQUFjO0FBQUN2TSxXQUFTLEVBQUMsTUFBSUE7QUFBZixDQUFkO0FBQXlDLElBQUl3TSxLQUFKO0FBQVV4USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN1USxPQUFLLENBQUN0USxDQUFELEVBQUc7QUFBQ3NRLFNBQUssR0FBQ3RRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBMUMsRUFBd0UsQ0FBeEU7QUFHN0csTUFBTThELFNBQVMsR0FBRyxJQUFJd00sS0FBSyxDQUFDQyxVQUFWLENBQXFCLFFBQXJCLENBQWxCO0FBRVB6TSxTQUFTLENBQUMwTSxPQUFWLENBQWtCO0FBQ2RDLFVBQVEsR0FBRTtBQUNOLFdBQU92USxVQUFVLENBQUNnQyxPQUFYLENBQW1CO0FBQUNyQixhQUFPLEVBQUMsS0FBSytFO0FBQWQsS0FBbkIsQ0FBUDtBQUNIOztBQUhhLENBQWxCLEUsQ0FNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQjs7Ozs7Ozs7Ozs7QUN0QkEsSUFBSS9GLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUErQyxJQUFJd0UsVUFBSjtBQUFlMUUsTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ3lFLFlBQVUsQ0FBQ3hFLENBQUQsRUFBRztBQUFDd0UsY0FBVSxHQUFDeEUsQ0FBWDtBQUFhOztBQUE1QixDQUF2QyxFQUFxRSxDQUFyRTtBQUF3RSxJQUFJK0QsS0FBSixFQUFVMk0sV0FBVjtBQUFzQjVRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ2dFLE9BQUssQ0FBQy9ELENBQUQsRUFBRztBQUFDK0QsU0FBSyxHQUFDL0QsQ0FBTjtBQUFRLEdBQWxCOztBQUFtQjBRLGFBQVcsQ0FBQzFRLENBQUQsRUFBRztBQUFDMFEsZUFBVyxHQUFDMVEsQ0FBWjtBQUFjOztBQUFoRCxDQUExQixFQUE0RSxDQUE1RTtBQUErRSxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJb0Usa0JBQUo7QUFBdUJ0RSxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQkFBWixFQUE0QztBQUFDcUUsb0JBQWtCLENBQUNwRSxDQUFELEVBQUc7QUFBQ29FLHNCQUFrQixHQUFDcEUsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQTVDLEVBQTBGLENBQTFGOztBQU94YTJRLGVBQWUsR0FBRyxDQUFDMU8sU0FBRCxFQUFZMk8sYUFBWixLQUE4QjtBQUM1QyxPQUFLLElBQUk1USxDQUFULElBQWM0USxhQUFkLEVBQTRCO0FBQ3hCLFFBQUkzTyxTQUFTLENBQUMySyxPQUFWLENBQWtCckwsS0FBbEIsSUFBMkJxUCxhQUFhLENBQUM1USxDQUFELENBQWIsQ0FBaUI0TSxPQUFqQixDQUF5QnJMLEtBQXhELEVBQThEO0FBQzFELGFBQU9tSixRQUFRLENBQUNrRyxhQUFhLENBQUM1USxDQUFELENBQWIsQ0FBaUI2USxLQUFsQixDQUFmO0FBQ0g7QUFDSjtBQUNKLENBTkQ7O0FBUUFoUixNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLDZCQUEyQixZQUFVO0FBQ2pDLFNBQUtFLE9BQUw7QUFDQSxRQUFJVixHQUFHLEdBQUdtSCxHQUFHLEdBQUMsdUJBQWQ7O0FBQ0EsUUFBRztBQUNDLFVBQUl2RyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxVQUFJMFEsU0FBUyxHQUFHN1AsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBaEI7QUFDQTJQLGVBQVMsR0FBR0EsU0FBUyxDQUFDMVAsTUFBdEI7QUFDQSxVQUFJNkUsTUFBTSxHQUFHNkssU0FBUyxDQUFDQyxXQUFWLENBQXNCOUssTUFBbkM7QUFDQSxVQUFJK0ssS0FBSyxHQUFHRixTQUFTLENBQUNDLFdBQVYsQ0FBc0JDLEtBQWxDO0FBQ0EsVUFBSUMsSUFBSSxHQUFHSCxTQUFTLENBQUNDLFdBQVYsQ0FBc0JFLElBQWpDO0FBQ0EsVUFBSUMsVUFBVSxHQUFHL0UsSUFBSSxDQUFDNkUsS0FBTCxDQUFXdE8sVUFBVSxDQUFDb08sU0FBUyxDQUFDQyxXQUFWLENBQXNCSSxLQUF0QixDQUE0QkgsS0FBNUIsRUFBbUNJLGtCQUFuQyxDQUFzREMsS0FBdEQsQ0FBNEQsR0FBNUQsRUFBaUUsQ0FBakUsQ0FBRCxDQUFWLEdBQWdGLEdBQTNGLENBQWpCO0FBRUF0TixXQUFLLENBQUN3SSxNQUFOLENBQWE7QUFBQ1gsZUFBTyxFQUFDL0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFoQyxPQUFiLEVBQXVEO0FBQUNILFlBQUksRUFBQztBQUN6RDZGLHNCQUFZLEVBQUVyTCxNQUQyQztBQUV6RHNMLHFCQUFXLEVBQUVQLEtBRjRDO0FBR3pEUSxvQkFBVSxFQUFFUCxJQUg2QztBQUl6REMsb0JBQVUsRUFBRUEsVUFKNkM7QUFLekR0TCx5QkFBZSxFQUFFa0wsU0FBUyxDQUFDQyxXQUFWLENBQXNCbk0sVUFBdEIsQ0FBaUM2TCxRQUFqQyxDQUEwQzVQLE9BTEY7QUFNekQ0USxrQkFBUSxFQUFFWCxTQUFTLENBQUNDLFdBQVYsQ0FBc0JJLEtBQXRCLENBQTRCSCxLQUE1QixFQUFtQ1MsUUFOWTtBQU96RDlILG9CQUFVLEVBQUVtSCxTQUFTLENBQUNDLFdBQVYsQ0FBc0JJLEtBQXRCLENBQTRCSCxLQUE1QixFQUFtQ3JIO0FBUFU7QUFBTixPQUF2RDtBQVNILEtBbEJELENBbUJBLE9BQU1sSixDQUFOLEVBQVE7QUFDSkMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLEdBMUJVO0FBMkJYLHdCQUFzQixZQUFVO0FBQzVCLFNBQUtLLE9BQUw7QUFDQSxRQUFJVixHQUFHLEdBQUdtSCxHQUFHLEdBQUMsU0FBZDs7QUFDQSxRQUFHO0FBQ0MsVUFBSXZHLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjtBQUNBLFVBQUlvSCxNQUFNLEdBQUd2RyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFiO0FBQ0FxRyxZQUFNLEdBQUdBLE1BQU0sQ0FBQ3BHLE1BQWhCO0FBQ0EsVUFBSXNRLEtBQUssR0FBRyxFQUFaO0FBQ0FBLFdBQUssQ0FBQzlGLE9BQU4sR0FBZ0JwRSxNQUFNLENBQUNtSyxTQUFQLENBQWlCQyxPQUFqQztBQUNBRixXQUFLLENBQUNHLGlCQUFOLEdBQTBCckssTUFBTSxDQUFDQyxTQUFQLENBQWlCQyxtQkFBM0M7QUFDQWdLLFdBQUssQ0FBQ0ksZUFBTixHQUF3QnRLLE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQnNLLGlCQUF6QztBQUVBLFVBQUlDLFdBQVcsR0FBR3RCLFdBQVcsQ0FBQ3hPLE9BQVosQ0FBb0IsRUFBcEIsRUFBd0I7QUFBQzBGLFlBQUksRUFBRTtBQUFDM0IsZ0JBQU0sRUFBRSxDQUFDO0FBQVY7QUFBUCxPQUF4QixDQUFsQjs7QUFDQSxVQUFJK0wsV0FBVyxJQUFJQSxXQUFXLENBQUMvTCxNQUFaLElBQXNCeUwsS0FBSyxDQUFDRyxpQkFBL0MsRUFBa0U7QUFDOUQsbURBQW9DSCxLQUFLLENBQUNHLGlCQUExQyx1QkFBd0VHLFdBQVcsQ0FBQy9MLE1BQXBGO0FBQ0g7O0FBRUQ3RixTQUFHLEdBQUdtSCxHQUFHLEdBQUMsYUFBVjtBQUNBdkcsY0FBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0EsVUFBSXdFLFVBQVUsR0FBRzNELElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWpCO0FBQ0F5RCxnQkFBVSxHQUFHQSxVQUFVLENBQUN4RCxNQUFYLENBQWtCd0QsVUFBL0I7QUFDQThNLFdBQUssQ0FBQzlNLFVBQU4sR0FBbUJBLFVBQVUsQ0FBQ2hELE1BQTlCO0FBQ0EsVUFBSXFRLFFBQVEsR0FBRyxDQUFmOztBQUNBLFdBQUtqUyxDQUFMLElBQVU0RSxVQUFWLEVBQXFCO0FBQ2pCcU4sZ0JBQVEsSUFBSXZILFFBQVEsQ0FBQzlGLFVBQVUsQ0FBQzVFLENBQUQsQ0FBVixDQUFja0wsWUFBZixDQUFwQjtBQUNIOztBQUNEd0csV0FBSyxDQUFDUSxpQkFBTixHQUEwQkQsUUFBMUI7QUFHQWxPLFdBQUssQ0FBQ3dJLE1BQU4sQ0FBYTtBQUFDWCxlQUFPLEVBQUM4RixLQUFLLENBQUM5RjtBQUFmLE9BQWIsRUFBc0M7QUFBQ0gsWUFBSSxFQUFDaUc7QUFBTixPQUF0QyxFQUFvRDtBQUFDbkcsY0FBTSxFQUFFO0FBQVQsT0FBcEQsRUExQkQsQ0EyQkM7O0FBQ0EsVUFBSWIsUUFBUSxDQUFDZ0gsS0FBSyxDQUFDRyxpQkFBUCxDQUFSLEdBQW9DLENBQXhDLEVBQTBDO0FBQ3RDLFlBQUlNLFdBQVcsR0FBRyxFQUFsQjtBQUNBQSxtQkFBVyxDQUFDbE0sTUFBWixHQUFxQnlFLFFBQVEsQ0FBQ2xELE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQkMsbUJBQWxCLENBQTdCO0FBQ0F5SyxtQkFBVyxDQUFDblAsSUFBWixHQUFtQixJQUFJQyxJQUFKLENBQVN1RSxNQUFNLENBQUNDLFNBQVAsQ0FBaUJzSyxpQkFBMUIsQ0FBbkI7QUFFQTNSLFdBQUcsR0FBR0csR0FBRyxHQUFHLGVBQVo7O0FBQ0EsWUFBRztBQUNDUyxrQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0EsY0FBSWdTLE9BQU8sR0FBR25SLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUEzQyxDQUZELENBR0M7QUFDQTs7QUFDQStRLHFCQUFXLENBQUNFLFlBQVosR0FBMkIzSCxRQUFRLENBQUMwSCxPQUFPLENBQUNFLGFBQVQsQ0FBbkM7QUFDQUgscUJBQVcsQ0FBQ0ksZUFBWixHQUE4QjdILFFBQVEsQ0FBQzBILE9BQU8sQ0FBQ0ksaUJBQVQsQ0FBdEM7QUFDSCxTQVBELENBUUEsT0FBTS9SLENBQU4sRUFBUTtBQUNKQyxpQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFFREwsV0FBRyxHQUFHRyxHQUFHLEdBQUcsZ0JBQU4sR0FBdUJWLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCMkwsWUFBcEQ7O0FBQ0EsWUFBRztBQUNDelIsa0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLGNBQUlzUyxNQUFNLEdBQUd6UixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBMUM7QUFDQStRLHFCQUFXLENBQUNRLFdBQVosR0FBMEJqSSxRQUFRLENBQUNnSSxNQUFELENBQWxDO0FBQ0gsU0FKRCxDQUtBLE9BQU1qUyxDQUFOLEVBQVE7QUFDSkMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBRURMLFdBQUcsR0FBR0csR0FBRyxHQUFHLDhCQUFaOztBQUNBLFlBQUk7QUFDQVMsa0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLGNBQUl3UyxJQUFJLEdBQUczUixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBeEM7O0FBQ0EsY0FBSXdSLElBQUksSUFBSUEsSUFBSSxDQUFDaFIsTUFBTCxHQUFjLENBQTFCLEVBQTRCO0FBQ3hCdVEsdUJBQVcsQ0FBQ1UsYUFBWixHQUE0QixFQUE1QjtBQUNBRCxnQkFBSSxDQUFDL1AsT0FBTCxDQUFhLENBQUNpUSxNQUFELEVBQVN2UCxDQUFULEtBQWU7QUFDeEI0Tyx5QkFBVyxDQUFDVSxhQUFaLENBQTBCaEosSUFBMUIsQ0FBK0I7QUFDM0JrSixxQkFBSyxFQUFFRCxNQUFNLENBQUNDLEtBRGE7QUFFM0JELHNCQUFNLEVBQUVwUSxVQUFVLENBQUNvUSxNQUFNLENBQUNBLE1BQVI7QUFGUyxlQUEvQjtBQUlILGFBTEQ7QUFNSDtBQUNKLFNBWkQsQ0FhQSxPQUFPclMsQ0FBUCxFQUFTO0FBQ0xDLGlCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUVETCxXQUFHLEdBQUdHLEdBQUcsR0FBRyxvQkFBWjs7QUFDQSxZQUFHO0FBQ0NTLGtCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQSxjQUFJNFMsU0FBUyxHQUFHL1IsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTdDOztBQUNBLGNBQUk0UixTQUFKLEVBQWM7QUFDVmIsdUJBQVcsQ0FBQ2EsU0FBWixHQUF3QnRRLFVBQVUsQ0FBQ3NRLFNBQUQsQ0FBbEM7QUFDSDtBQUNKLFNBTkQsQ0FPQSxPQUFNdlMsQ0FBTixFQUFRO0FBQ0pDLGlCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUVETCxXQUFHLEdBQUdHLEdBQUcsR0FBRyw0QkFBWjs7QUFDQSxZQUFHO0FBQ0NTLGtCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQSxjQUFJNlMsVUFBVSxHQUFHaFMsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBakI7O0FBQ0EsY0FBSThSLFVBQUosRUFBZTtBQUNYZCx1QkFBVyxDQUFDZSxnQkFBWixHQUErQnhRLFVBQVUsQ0FBQ3VRLFVBQVUsQ0FBQzdSLE1BQVosQ0FBekM7QUFDSDtBQUNKLFNBTkQsQ0FPQSxPQUFNWCxDQUFOLEVBQVE7QUFDSkMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBRURpUSxtQkFBVyxDQUFDckcsTUFBWixDQUFtQjhILFdBQW5CO0FBQ0gsT0FuR0YsQ0FxR0M7QUFFQTtBQUNBOzs7QUFDQSxhQUFPVCxLQUFLLENBQUNHLGlCQUFiO0FBQ0gsS0ExR0QsQ0EyR0EsT0FBT3BSLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNBLGFBQU8sNkJBQVA7QUFDSDtBQUNKLEdBN0lVO0FBOElYLDJCQUF5QixZQUFVO0FBQy9Cc0QsU0FBSyxDQUFDNEIsSUFBTixHQUFhaUMsSUFBYixDQUFrQjtBQUFDdUwsYUFBTyxFQUFDLENBQUM7QUFBVixLQUFsQixFQUFnQ3RMLEtBQWhDLENBQXNDLENBQXRDO0FBQ0gsR0FoSlU7QUFpSlgsbUJBQWlCLFlBQVU7QUFDdkIsUUFBSTZKLEtBQUssR0FBRzNOLEtBQUssQ0FBQzdCLE9BQU4sQ0FBYztBQUFDMEosYUFBTyxFQUFFL0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFqQyxLQUFkLENBQVo7O0FBRUEsUUFBSThGLEtBQUssSUFBSUEsS0FBSyxDQUFDMEIsV0FBbkIsRUFBK0I7QUFDM0IxUyxhQUFPLENBQUNDLEdBQVIsQ0FBWSxpQ0FBWjtBQUNILEtBRkQsTUFHSyxJQUFJZCxNQUFNLENBQUNnSCxRQUFQLENBQWdCd00sS0FBaEIsQ0FBc0JELFdBQTFCLEVBQXVDO0FBQ3hDMVMsYUFBTyxDQUFDQyxHQUFSLENBQVksdUNBQVo7QUFDQSxVQUFJSyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTVCxNQUFNLENBQUNnSCxRQUFQLENBQWdCeU0sV0FBekIsQ0FBZjtBQUNBLFVBQUlDLE9BQU8sR0FBR3RTLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWQ7QUFDQSxVQUFJcVMsS0FBSyxHQUFHRCxPQUFPLENBQUNFLFNBQVIsQ0FBa0JELEtBQWxCLElBQTJCRCxPQUFPLENBQUNFLFNBQVIsQ0FBa0JDLFlBQXpEO0FBQ0EsVUFBSUMsV0FBVyxHQUFHO0FBQ2QvSCxlQUFPLEVBQUUySCxPQUFPLENBQUMxSCxRQURIO0FBRWQrSCxtQkFBVyxFQUFFTCxPQUFPLENBQUNNLFlBRlA7QUFHZEMsdUJBQWUsRUFBRVAsT0FBTyxDQUFDUSxnQkFIWDtBQUlkQyxZQUFJLEVBQUVULE9BQU8sQ0FBQ0UsU0FBUixDQUFrQk8sSUFKVjtBQUtkQyxZQUFJLEVBQUVWLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlEsSUFMVjtBQU1kQyxlQUFPLEVBQUU7QUFDTHRCLGNBQUksRUFBRVcsT0FBTyxDQUFDRSxTQUFSLENBQWtCUyxPQUFsQixDQUEwQnRCLElBRDNCO0FBRUw3SyxnQkFBTSxFQUFFd0wsT0FBTyxDQUFDRSxTQUFSLENBQWtCUyxPQUFsQixDQUEwQm5NO0FBRjdCLFNBTks7QUFVZG9NLFlBQUksRUFBRVosT0FBTyxDQUFDRSxTQUFSLENBQWtCVSxJQVZWO0FBV2RYLGFBQUssRUFBRTtBQUNIWSxzQkFBWSxFQUFFWixLQUFLLENBQUNhLGFBRGpCO0FBRUhDLDRCQUFrQixFQUFFZCxLQUFLLENBQUNlLG9CQUZ2QjtBQUdIQyw2QkFBbUIsRUFBRWhCLEtBQUssQ0FBQ2lCLHFCQUh4QjtBQUlIQyw2QkFBbUIsRUFBRWxCLEtBQUssQ0FBQ21CO0FBSnhCLFNBWE87QUFpQmRDLFdBQUcsRUFBRTtBQUNEQyw0QkFBa0IsRUFBRXRCLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQm1CLEdBQWxCLENBQXNCRSxvQkFEekM7QUFFREMsdUJBQWEsRUFBRXhCLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQm1CLEdBQWxCLENBQXNCSSxjQUZwQztBQUdEQyxzQkFBWSxFQUFFMUIsT0FBTyxDQUFDRSxTQUFSLENBQWtCbUIsR0FBbEIsQ0FBc0JNLGFBSG5DO0FBSURDLHFCQUFXLEVBQUU1QixPQUFPLENBQUNFLFNBQVIsQ0FBa0JtQixHQUFsQixDQUFzQlE7QUFKbEMsU0FqQlM7QUF1QmRDLGdCQUFRLEVBQUM7QUFDTHROLGdCQUFNLEVBQUV3TCxPQUFPLENBQUNFLFNBQVIsQ0FBa0I0QixRQUFsQixDQUEyQnROO0FBRDlCLFNBdkJLO0FBMEJkMkssY0FBTSxFQUFFYSxPQUFPLENBQUNFLFNBQVIsQ0FBa0JmLE1BMUJaO0FBMkJkNEMsY0FBTSxFQUFFL0IsT0FBTyxDQUFDRSxTQUFSLENBQWtCNkI7QUEzQlosT0FBbEI7QUE4QkEsVUFBSXZGLGdCQUFnQixHQUFHLENBQXZCLENBbkN3QyxDQXFDeEM7O0FBQ0EsVUFBSXdELE9BQU8sQ0FBQ0UsU0FBUixDQUFrQjhCLE9BQWxCLElBQTZCaEMsT0FBTyxDQUFDRSxTQUFSLENBQWtCOEIsT0FBbEIsQ0FBMEJDLE1BQXZELElBQWtFakMsT0FBTyxDQUFDRSxTQUFSLENBQWtCOEIsT0FBbEIsQ0FBMEJDLE1BQTFCLENBQWlDNVQsTUFBakMsR0FBMEMsQ0FBaEgsRUFBbUg7QUFDL0csYUFBSzJCLENBQUwsSUFBVWdRLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQjhCLE9BQWxCLENBQTBCQyxNQUFwQyxFQUEyQztBQUN2QyxjQUFJQyxHQUFHLEdBQUdsQyxPQUFPLENBQUNFLFNBQVIsQ0FBa0I4QixPQUFsQixDQUEwQkMsTUFBMUIsQ0FBaUNqUyxDQUFqQyxFQUFvQ2hDLEtBQXBDLENBQTBDa1UsR0FBcEQsQ0FEdUMsQ0FFdkM7O0FBQ0EsZUFBS0MsQ0FBTCxJQUFVRCxHQUFWLEVBQWM7QUFDVixnQkFBSUEsR0FBRyxDQUFDQyxDQUFELENBQUgsQ0FBT3BVLElBQVAsSUFBZSwrQkFBbkIsRUFBbUQ7QUFDL0NaLHFCQUFPLENBQUNDLEdBQVIsQ0FBWThVLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU9uVSxLQUFuQixFQUQrQyxDQUUvQzs7QUFDQSxrQkFBSVUsU0FBUyxHQUFHO0FBQ1pvRyxnQ0FBZ0IsRUFBRW9OLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU9uVSxLQUFQLENBQWFvVSxNQURuQjtBQUVaeEksMkJBQVcsRUFBRXNJLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU9uVSxLQUFQLENBQWE0TCxXQUZkO0FBR1o1SywwQkFBVSxFQUFFa1QsR0FBRyxDQUFDQyxDQUFELENBQUgsQ0FBT25VLEtBQVAsQ0FBYWdCLFVBSGI7QUFJWitLLG1DQUFtQixFQUFFbUksR0FBRyxDQUFDQyxDQUFELENBQUgsQ0FBT25VLEtBQVAsQ0FBYStMLG1CQUp0QjtBQUtabEwsZ0NBQWdCLEVBQUVxVCxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPblUsS0FBUCxDQUFhdUksaUJBTG5CO0FBTVp6SCxpQ0FBaUIsRUFBRW9ULEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU9uVSxLQUFQLENBQWFjLGlCQU5wQjtBQU9aNkksNEJBQVksRUFBRWlCLElBQUksQ0FBQ3lKLEtBQUwsQ0FBV2xMLFFBQVEsQ0FBQytLLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU9uVSxLQUFQLENBQWFBLEtBQWIsQ0FBbUJ1UixNQUFwQixDQUFSLEdBQXNDalQsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUIrTyxlQUF4RSxDQVBGO0FBUVp4SSxzQkFBTSxFQUFFLEtBUkk7QUFTWjdGLHNCQUFNLEVBQUU7QUFUSSxlQUFoQjtBQVlBdUksOEJBQWdCLElBQUk5TixTQUFTLENBQUNpSixZQUE5QjtBQUVBLGtCQUFJNEssV0FBVyxHQUFHalcsTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCdU4sR0FBRyxDQUFDQyxDQUFELENBQUgsQ0FBT25VLEtBQVAsQ0FBYW9VLE1BQTNDLENBQWxCLENBakIrQyxDQWtCL0M7O0FBRUExVCx1QkFBUyxDQUFDMkssT0FBVixHQUFvQjtBQUNoQix3QkFBTywwQkFEUztBQUVoQix5QkFBUWtKO0FBRlEsZUFBcEI7QUFLQTdULHVCQUFTLENBQUNwQixPQUFWLEdBQW9CMkQsVUFBVSxDQUFDdkMsU0FBUyxDQUFDMkssT0FBWCxDQUE5QjtBQUNBM0ssdUJBQVMsQ0FBQzRLLE1BQVYsR0FBbUJoTixNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJqRyxTQUFTLENBQUMySyxPQUF4QyxFQUFpRC9NLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCZ0csa0JBQXhFLENBQW5CO0FBQ0E3Syx1QkFBUyxDQUFDOEssZUFBVixHQUE0QmxOLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmpHLFNBQVMsQ0FBQzJLLE9BQXhDLEVBQWlEL00sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJrRyxrQkFBeEUsQ0FBNUI7QUFDQTVJLGdDQUFrQixDQUFDaUcsTUFBbkIsQ0FBMEI7QUFDdEJ4Six1QkFBTyxFQUFFb0IsU0FBUyxDQUFDcEIsT0FERztBQUV0QmlOLGlDQUFpQixFQUFFLENBRkc7QUFHdEI1Qyw0QkFBWSxFQUFFakosU0FBUyxDQUFDaUosWUFIRjtBQUl0QjVKLG9CQUFJLEVBQUUsS0FKZ0I7QUFLdEIyRSxzQkFBTSxFQUFFLENBTGM7QUFNdEI4SCwwQkFBVSxFQUFFd0YsT0FBTyxDQUFDTTtBQU5FLGVBQTFCO0FBU0EzVCx3QkFBVSxDQUFDbUssTUFBWCxDQUFrQnBJLFNBQWxCO0FBQ0g7QUFDSjtBQUNKO0FBQ0osT0FwRnVDLENBc0Z4Qzs7O0FBQ0F2QixhQUFPLENBQUNDLEdBQVIsQ0FBWSxxQ0FBWjs7QUFDQSxVQUFJNFMsT0FBTyxDQUFDRSxTQUFSLENBQWtCUyxPQUFsQixDQUEwQnRQLFVBQTFCLElBQXdDMk8sT0FBTyxDQUFDRSxTQUFSLENBQWtCUyxPQUFsQixDQUEwQnRQLFVBQTFCLENBQXFDaEQsTUFBckMsR0FBOEMsQ0FBMUYsRUFBNEY7QUFDeEZsQixlQUFPLENBQUNDLEdBQVIsQ0FBWTRTLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEJ0UCxVQUExQixDQUFxQ2hELE1BQWpEO0FBQ0EsWUFBSW1VLGdCQUFnQixHQUFHeEMsT0FBTyxDQUFDRSxTQUFSLENBQWtCUyxPQUFsQixDQUEwQnRQLFVBQWpEO0FBQ0EsWUFBSWdNLGFBQWEsR0FBRzJDLE9BQU8sQ0FBQzNPLFVBQTVCOztBQUNBLGFBQUssSUFBSTVFLENBQVQsSUFBYytWLGdCQUFkLEVBQStCO0FBQzNCO0FBQ0EsY0FBSTlULFNBQVMsR0FBRzhULGdCQUFnQixDQUFDL1YsQ0FBRCxDQUFoQztBQUNBaUMsbUJBQVMsQ0FBQ0ksaUJBQVYsR0FBOEJ4QyxNQUFNLENBQUNxSSxJQUFQLENBQVksY0FBWixFQUE0QjZOLGdCQUFnQixDQUFDL1YsQ0FBRCxDQUFoQixDQUFvQm9DLGdCQUFoRCxDQUE5QjtBQUVBLGNBQUkwVCxXQUFXLEdBQUdqVyxNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJqRyxTQUFTLENBQUNvRyxnQkFBeEMsQ0FBbEI7QUFFQXBHLG1CQUFTLENBQUMySyxPQUFWLEdBQW9CO0FBQ2hCLG9CQUFPLDBCQURTO0FBRWhCLHFCQUFRa0o7QUFGUSxXQUFwQjtBQUtBN1QsbUJBQVMsQ0FBQ3BCLE9BQVYsR0FBb0IyRCxVQUFVLENBQUN2QyxTQUFTLENBQUMySyxPQUFYLENBQTlCO0FBQ0EzSyxtQkFBUyxDQUFDMkssT0FBVixHQUFvQjNLLFNBQVMsQ0FBQzJLLE9BQTlCO0FBQ0EzSyxtQkFBUyxDQUFDNEssTUFBVixHQUFtQmhOLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmpHLFNBQVMsQ0FBQzJLLE9BQXhDLEVBQWlEL00sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJnRyxrQkFBeEUsQ0FBbkI7QUFDQTdLLG1CQUFTLENBQUM4SyxlQUFWLEdBQTRCbE4sTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCakcsU0FBUyxDQUFDMkssT0FBeEMsRUFBaUQvTSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmtHLGtCQUF4RSxDQUE1QjtBQUVBL0ssbUJBQVMsQ0FBQ2lKLFlBQVYsR0FBeUJ5RixlQUFlLENBQUMxTyxTQUFELEVBQVkyTyxhQUFaLENBQXhDO0FBQ0FiLDBCQUFnQixJQUFJOU4sU0FBUyxDQUFDaUosWUFBOUI7QUFFQWhMLG9CQUFVLENBQUNxTCxNQUFYLENBQWtCO0FBQUNsRCw0QkFBZ0IsRUFBQ3BHLFNBQVMsQ0FBQ29HO0FBQTVCLFdBQWxCLEVBQWdFcEcsU0FBaEU7QUFDQW1DLDRCQUFrQixDQUFDaUcsTUFBbkIsQ0FBMEI7QUFDdEJ4SixtQkFBTyxFQUFFb0IsU0FBUyxDQUFDcEIsT0FERztBQUV0QmlOLDZCQUFpQixFQUFFLENBRkc7QUFHdEI1Qyx3QkFBWSxFQUFFakosU0FBUyxDQUFDaUosWUFIRjtBQUl0QjVKLGdCQUFJLEVBQUUsS0FKZ0I7QUFLdEIyRSxrQkFBTSxFQUFFLENBTGM7QUFNdEI4SCxzQkFBVSxFQUFFd0YsT0FBTyxDQUFDTTtBQU5FLFdBQTFCO0FBUUg7QUFDSjs7QUFFREYsaUJBQVcsQ0FBQ1AsV0FBWixHQUEwQixJQUExQjtBQUNBTyxpQkFBVyxDQUFDekIsaUJBQVosR0FBZ0NuQyxnQkFBaEM7QUFDQSxVQUFJM08sTUFBTSxHQUFHMkMsS0FBSyxDQUFDd0gsTUFBTixDQUFhO0FBQUNLLGVBQU8sRUFBQytILFdBQVcsQ0FBQy9IO0FBQXJCLE9BQWIsRUFBNEM7QUFBQ0gsWUFBSSxFQUFDa0k7QUFBTixPQUE1QyxDQUFiO0FBR0FqVCxhQUFPLENBQUNDLEdBQVIsQ0FBWSwwQ0FBWjtBQUVIOztBQUVELFdBQU8sSUFBUDtBQUNIO0FBN1JVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNmQSxJQUFJZCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUkrRCxLQUFKLEVBQVUyTSxXQUFWO0FBQXNCNVEsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDZ0UsT0FBSyxDQUFDL0QsQ0FBRCxFQUFHO0FBQUMrRCxTQUFLLEdBQUMvRCxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CMFEsYUFBVyxDQUFDMVEsQ0FBRCxFQUFHO0FBQUMwUSxlQUFXLEdBQUMxUSxDQUFaO0FBQWM7O0FBQWhELENBQTFCLEVBQTRFLENBQTVFO0FBQStFLElBQUlnVyxTQUFKO0FBQWNsVyxNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDaVcsV0FBUyxDQUFDaFcsQ0FBRCxFQUFHO0FBQUNnVyxhQUFTLEdBQUNoVyxDQUFWO0FBQVk7O0FBQTFCLENBQTdDLEVBQXlFLENBQXpFO0FBQTRFLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBSzlRSCxNQUFNLENBQUNvVyxPQUFQLENBQWUsb0JBQWYsRUFBcUMsWUFBWTtBQUM3QyxTQUFPLENBQ0h2RixXQUFXLENBQUMvSyxJQUFaLENBQWlCLEVBQWpCLEVBQW9CO0FBQUNpQyxRQUFJLEVBQUM7QUFBQzNCLFlBQU0sRUFBQyxDQUFDO0FBQVQsS0FBTjtBQUFrQjRCLFNBQUssRUFBQztBQUF4QixHQUFwQixDQURHLEVBRUhtTyxTQUFTLENBQUNyUSxJQUFWLENBQWUsRUFBZixFQUFrQjtBQUFDaUMsUUFBSSxFQUFDO0FBQUNzTyxxQkFBZSxFQUFDLENBQUM7QUFBbEIsS0FBTjtBQUEyQnJPLFNBQUssRUFBQztBQUFqQyxHQUFsQixDQUZHLENBQVA7QUFJSCxDQUxEO0FBT0FzSSxnQkFBZ0IsQ0FBQyxjQUFELEVBQWlCLFlBQVU7QUFDdkMsU0FBTztBQUNIeEssUUFBSSxHQUFFO0FBQ0YsYUFBTzVCLEtBQUssQ0FBQzRCLElBQU4sQ0FBVztBQUFDaUcsZUFBTyxFQUFDL0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFoQyxPQUFYLENBQVA7QUFDSCxLQUhFOztBQUlId0UsWUFBUSxFQUFFLENBQ047QUFDSXpLLFVBQUksQ0FBQytMLEtBQUQsRUFBTztBQUNQLGVBQU94UixVQUFVLENBQUN5RixJQUFYLENBQ0gsRUFERyxFQUVIO0FBQUM0SSxnQkFBTSxFQUFDO0FBQ0oxTixtQkFBTyxFQUFDLENBREo7QUFFSnNNLHVCQUFXLEVBQUMsQ0FGUjtBQUdKL0ssNEJBQWdCLEVBQUMsQ0FIYjtBQUlKb0Ysa0JBQU0sRUFBQyxDQUFDLENBSko7QUFLSjZGLGtCQUFNLEVBQUMsQ0FMSDtBQU1KRCx1QkFBVyxFQUFDO0FBTlI7QUFBUixTQUZHLENBQVA7QUFXSDs7QUFiTCxLQURNO0FBSlAsR0FBUDtBQXNCSCxDQXZCZSxDQUFoQixDOzs7Ozs7Ozs7OztBQ1pBdE4sTUFBTSxDQUFDdVEsTUFBUCxDQUFjO0FBQUN0TSxPQUFLLEVBQUMsTUFBSUEsS0FBWDtBQUFpQjJNLGFBQVcsRUFBQyxNQUFJQTtBQUFqQyxDQUFkO0FBQTZELElBQUlKLEtBQUo7QUFBVXhRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3VRLE9BQUssQ0FBQ3RRLENBQUQsRUFBRztBQUFDc1EsU0FBSyxHQUFDdFEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUExQyxFQUF3RSxDQUF4RTtBQUdqSSxNQUFNK0QsS0FBSyxHQUFHLElBQUl1TSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZDtBQUNBLE1BQU1HLFdBQVcsR0FBRyxJQUFJSixLQUFLLENBQUNDLFVBQVYsQ0FBcUIsY0FBckIsQ0FBcEI7QUFFUHhNLEtBQUssQ0FBQ3lNLE9BQU4sQ0FBYztBQUNWQyxVQUFRLEdBQUU7QUFDTixXQUFPdlEsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDckIsYUFBTyxFQUFDLEtBQUsrRTtBQUFkLEtBQW5CLENBQVA7QUFDSDs7QUFIUyxDQUFkLEU7Ozs7Ozs7Ozs7O0FDTkEsSUFBSS9GLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSWdXLFNBQUo7QUFBY2xXLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUNpVyxXQUFTLENBQUNoVyxDQUFELEVBQUc7QUFBQ2dXLGFBQVMsR0FBQ2hXLENBQVY7QUFBWTs7QUFBMUIsQ0FBL0IsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUlySkgsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCw0QkFBMEIsWUFBVTtBQUNoQyxTQUFLRSxPQUFMO0FBQ0EsUUFBSXFWLE1BQU0sR0FBR3RXLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCc1AsV0FBcEM7O0FBQ0EsUUFBSUQsTUFBSixFQUFXO0FBQ1AsVUFBRztBQUNDLFlBQUlFLEdBQUcsR0FBRyxJQUFJcFQsSUFBSixFQUFWO0FBQ0FvVCxXQUFHLENBQUNDLFVBQUosQ0FBZSxDQUFmO0FBQ0EsWUFBSWxXLEdBQUcsR0FBRyx1REFBcUQrVixNQUFyRCxHQUE0RCx3SEFBdEU7QUFDQSxZQUFJblYsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmOztBQUNBLFlBQUlZLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQjtBQUNBLGNBQUlnQyxJQUFJLEdBQUd2QixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFYO0FBQ0FxQixjQUFJLEdBQUdBLElBQUksQ0FBQzJULE1BQUQsQ0FBWCxDQUgyQixDQUkzQjs7QUFDQSxpQkFBT0gsU0FBUyxDQUFDekssTUFBVixDQUFpQjtBQUFDMkssMkJBQWUsRUFBQzFULElBQUksQ0FBQzBUO0FBQXRCLFdBQWpCLEVBQXlEO0FBQUN6SyxnQkFBSSxFQUFDako7QUFBTixXQUF6RCxDQUFQO0FBQ0g7QUFDSixPQVpELENBYUEsT0FBTS9CLENBQU4sRUFBUTtBQUNKQyxlQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osS0FqQkQsTUFrQkk7QUFDQSxhQUFPLDJCQUFQO0FBQ0g7QUFDSixHQXpCVTtBQTBCWCx3QkFBc0IsWUFBVTtBQUM1QixTQUFLSyxPQUFMO0FBQ0EsUUFBSXFWLE1BQU0sR0FBR3RXLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCc1AsV0FBcEM7O0FBQ0EsUUFBSUQsTUFBSixFQUFXO0FBQ1AsYUFBUUgsU0FBUyxDQUFDOVQsT0FBVixDQUFrQixFQUFsQixFQUFxQjtBQUFDMEYsWUFBSSxFQUFDO0FBQUNzTyx5QkFBZSxFQUFDLENBQUM7QUFBbEI7QUFBTixPQUFyQixDQUFSO0FBQ0gsS0FGRCxNQUdJO0FBQ0EsYUFBTywyQkFBUDtBQUNIO0FBRUo7QUFwQ1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ0pBcFcsTUFBTSxDQUFDdVEsTUFBUCxDQUFjO0FBQUMyRixXQUFTLEVBQUMsTUFBSUE7QUFBZixDQUFkO0FBQXlDLElBQUkxRixLQUFKO0FBQVV4USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN1USxPQUFLLENBQUN0USxDQUFELEVBQUc7QUFBQ3NRLFNBQUssR0FBQ3RRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFNUMsTUFBTWdXLFNBQVMsR0FBRyxJQUFJMUYsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFlBQXJCLENBQWxCLEM7Ozs7Ozs7Ozs7O0FDRlAsSUFBSTFRLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXVXLFdBQUo7QUFBZ0J6VyxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDd1csYUFBVyxDQUFDdlcsQ0FBRCxFQUFHO0FBQUN1VyxlQUFXLEdBQUN2VyxDQUFaO0FBQWM7O0FBQTlCLENBQWhDLEVBQWdFLENBQWhFO0FBQW1FLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBSWxLSCxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLGdDQUE4QixZQUFVO0FBQ3BDLFNBQUtFLE9BQUw7QUFDQSxRQUFJOEQsVUFBVSxHQUFHMUUsVUFBVSxDQUFDeUYsSUFBWCxDQUFnQixFQUFoQixFQUFvQkUsS0FBcEIsRUFBakI7QUFDQSxRQUFJaEUsV0FBVyxHQUFHLEVBQWxCO0FBQ0FuQixXQUFPLENBQUNDLEdBQVIsQ0FBWSw2QkFBWjs7QUFDQSxTQUFLWCxDQUFMLElBQVU0RSxVQUFWLEVBQXFCO0FBQ2pCLFVBQUlBLFVBQVUsQ0FBQzVFLENBQUQsQ0FBVixDQUFjb0MsZ0JBQWxCLEVBQW1DO0FBQy9CLFlBQUloQyxHQUFHLEdBQUdHLEdBQUcsR0FBRyxzQkFBTixHQUE2QnFFLFVBQVUsQ0FBQzVFLENBQUQsQ0FBVixDQUFjb0MsZ0JBQTNDLEdBQTRELGNBQXRFOztBQUNBLFlBQUc7QUFDQyxjQUFJcEIsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmOztBQUNBLGNBQUlZLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQixnQkFBSThDLFVBQVUsR0FBR3JDLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE5QyxDQUQyQixDQUUzQjs7QUFDQVMsdUJBQVcsR0FBR0EsV0FBVyxDQUFDMlUsTUFBWixDQUFtQmxULFVBQW5CLENBQWQ7QUFDSCxXQUpELE1BS0k7QUFDQTVDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWUssUUFBUSxDQUFDUixVQUFyQjtBQUNIO0FBQ0osU0FWRCxDQVdBLE9BQU9DLENBQVAsRUFBUztBQUNMQyxpQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKO0FBQ0o7O0FBRUQsU0FBSzhDLENBQUwsSUFBVTFCLFdBQVYsRUFBc0I7QUFDbEIsVUFBSUEsV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLElBQWtCMUIsV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLENBQWVkLE1BQXJDLEVBQ0laLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxDQUFlZCxNQUFmLEdBQXdCQyxVQUFVLENBQUNiLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxDQUFlZCxNQUFoQixDQUFsQztBQUNQLEtBNUJtQyxDQThCcEM7OztBQUNBLFFBQUlELElBQUksR0FBRztBQUNQWCxpQkFBVyxFQUFFQSxXQUROO0FBRVA0VSxlQUFTLEVBQUUsSUFBSXhULElBQUo7QUFGSixLQUFYO0FBS0EsV0FBT3NULFdBQVcsQ0FBQ2xNLE1BQVosQ0FBbUI3SCxJQUFuQixDQUFQO0FBQ0gsR0F0Q1UsQ0F1Q1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBcERXLENBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSkExQyxNQUFNLENBQUN1USxNQUFQLENBQWM7QUFBQ2tHLGFBQVcsRUFBQyxNQUFJQTtBQUFqQixDQUFkO0FBQTZDLElBQUlqRyxLQUFKO0FBQVV4USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN1USxPQUFLLENBQUN0USxDQUFELEVBQUc7QUFBQ3NRLFNBQUssR0FBQ3RRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFaEQsTUFBTXVXLFdBQVcsR0FBRyxJQUFJakcsS0FBSyxDQUFDQyxVQUFWLENBQXFCLGFBQXJCLENBQXBCLEM7Ozs7Ozs7Ozs7O0FDRlAsSUFBSW1HLGFBQUo7O0FBQWtCNVcsTUFBTSxDQUFDQyxJQUFQLENBQVksc0NBQVosRUFBbUQ7QUFBQzRXLFNBQU8sQ0FBQzNXLENBQUQsRUFBRztBQUFDMFcsaUJBQWEsR0FBQzFXLENBQWQ7QUFBZ0I7O0FBQTVCLENBQW5ELEVBQWlGLENBQWpGO0FBQWxCLElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFFVEgsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCx3QkFBc0IsVUFBU2dXLE1BQVQsRUFBaUI7QUFDbkMsVUFBTXhXLEdBQUcsYUFBTUcsR0FBTixTQUFUO0FBQ0FpQyxRQUFJLEdBQUc7QUFDSCxZQUFNb1UsTUFBTSxDQUFDclYsS0FEVjtBQUVILGNBQVE7QUFGTCxLQUFQO0FBSUEsVUFBTXNWLFNBQVMsR0FBRyxJQUFJNVQsSUFBSixHQUFXb0osT0FBWCxFQUFsQjtBQUNBM0wsV0FBTyxDQUFDQyxHQUFSLGlDQUFxQ2tXLFNBQXJDLGNBQWtEelcsR0FBbEQsd0JBQW1FYSxJQUFJLENBQUNtRSxTQUFMLENBQWU1QyxJQUFmLENBQW5FO0FBRUEsUUFBSXhCLFFBQVEsR0FBR2YsSUFBSSxDQUFDNlcsSUFBTCxDQUFVMVcsR0FBVixFQUFlO0FBQUNvQztBQUFELEtBQWYsQ0FBZjtBQUNBOUIsV0FBTyxDQUFDQyxHQUFSLG1DQUF1Q2tXLFNBQXZDLGNBQW9EelcsR0FBcEQsZUFBNERhLElBQUksQ0FBQ21FLFNBQUwsQ0FBZXBFLFFBQWYsQ0FBNUQ7O0FBQ0EsUUFBSUEsUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQWdDO0FBQzVCLFVBQUlnQyxJQUFJLEdBQUd4QixRQUFRLENBQUN3QixJQUFwQjtBQUNBLFVBQUlBLElBQUksQ0FBQ3VVLElBQVQsRUFDSSxNQUFNLElBQUlsWCxNQUFNLENBQUNtWCxLQUFYLENBQWlCeFUsSUFBSSxDQUFDdVUsSUFBdEIsRUFBNEI5VixJQUFJLENBQUNDLEtBQUwsQ0FBV3NCLElBQUksQ0FBQ3lVLE9BQWhCLEVBQXlCQyxPQUFyRCxDQUFOO0FBQ0osYUFBT2xXLFFBQVEsQ0FBQ3dCLElBQVQsQ0FBYzJVLE1BQXJCO0FBQ0g7QUFDSixHQWxCVTtBQW1CWCx5QkFBdUIsVUFBU0MsSUFBVCxFQUFlQyxJQUFmLEVBQXFCO0FBQ3hDLFVBQU1qWCxHQUFHLGFBQU1HLEdBQU4sY0FBYThXLElBQWIsQ0FBVDtBQUNBN1UsUUFBSSxHQUFHO0FBQ0gsb0NBQ080VSxJQURQO0FBRUksb0JBQVl2WCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjhFLE9BRnZDO0FBR0ksb0JBQVk7QUFIaEI7QUFERyxLQUFQO0FBT0EsUUFBSTVLLFFBQVEsR0FBR2YsSUFBSSxDQUFDNlcsSUFBTCxDQUFVMVcsR0FBVixFQUFlO0FBQUNvQztBQUFELEtBQWYsQ0FBZjs7QUFDQSxRQUFJeEIsUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQWdDO0FBQzVCLGFBQU9TLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQVA7QUFDSDtBQUNKLEdBaENVO0FBaUNYLDBCQUF3QixVQUFTbVcsS0FBVCxFQUFnQnBOLElBQWhCLEVBQXNCbU4sSUFBdEIsRUFBOEM7QUFBQSxRQUFsQkUsVUFBa0IsdUVBQVAsS0FBTztBQUNsRSxVQUFNblgsR0FBRyxhQUFNRyxHQUFOLGNBQWE4VyxJQUFiLENBQVQ7QUFDQTdVLFFBQUkscUJBQU84VSxLQUFQO0FBQ0Esa0JBQVk7QUFDUixnQkFBUXBOLElBREE7QUFFUixvQkFBWXJLLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEUsT0FGM0I7QUFHUiwwQkFBa0IyTCxVQUhWO0FBSVIsb0JBQVk7QUFKSjtBQURaLE1BQUo7QUFRQSxRQUFJdlcsUUFBUSxHQUFHZixJQUFJLENBQUM2VyxJQUFMLENBQVUxVyxHQUFWLEVBQWU7QUFBQ29DO0FBQUQsS0FBZixDQUFmOztBQUNBLFFBQUl4QixRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBZ0M7QUFDNUIsYUFBT1MsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJxVyxZQUFwQztBQUNIO0FBQ0o7QUEvQ1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ0ZBLElBQUlkLGFBQUo7O0FBQWtCNVcsTUFBTSxDQUFDQyxJQUFQLENBQVksc0NBQVosRUFBbUQ7QUFBQzRXLFNBQU8sQ0FBQzNXLENBQUQsRUFBRztBQUFDMFcsaUJBQWEsR0FBQzFXLENBQWQ7QUFBZ0I7O0FBQTVCLENBQW5ELEVBQWlGLENBQWpGO0FBQWxCLElBQUlILE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUErQyxJQUFJeVgsU0FBSjtBQUFjM1gsTUFBTSxDQUFDQyxJQUFQLENBQVksaUJBQVosRUFBOEI7QUFBQzBYLFdBQVMsQ0FBQ3pYLENBQUQsRUFBRztBQUFDeVgsYUFBUyxHQUFDelgsQ0FBVjtBQUFZOztBQUExQixDQUE5QixFQUEwRCxDQUExRDtBQUE2RCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUlsTjtBQUVBSCxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLDRCQUEwQixZQUFVO0FBQ2hDLFNBQUtFLE9BQUw7O0FBQ0EsUUFBRztBQUNDLFVBQUlWLEdBQUcsR0FBR0csR0FBRyxHQUFHLGdCQUFoQjtBQUNBLFVBQUlTLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjtBQUNBLFVBQUlzWCxTQUFTLEdBQUd6VyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBN0MsQ0FIRCxDQUlDOztBQUVBLFVBQUl1VyxtQkFBbUIsR0FBRyxJQUFJQyxHQUFKLENBQVFILFNBQVMsQ0FBQzlSLElBQVYsQ0FDOUI7QUFBQywyQkFBa0I7QUFBQ1EsYUFBRyxFQUFDLENBQUMsUUFBRCxFQUFXLFVBQVgsRUFBdUIsU0FBdkI7QUFBTDtBQUFuQixPQUQ4QixFQUVoQ04sS0FGZ0MsR0FFeEJFLEdBRndCLENBRW5CbEIsQ0FBRCxJQUFNQSxDQUFDLENBQUNnVCxVQUZZLENBQVIsQ0FBMUI7QUFJQSxVQUFJQyxXQUFXLEdBQUcsRUFBbEI7O0FBQ0EsVUFBSUosU0FBUyxDQUFDOVYsTUFBVixHQUFtQixDQUF2QixFQUF5QjtBQUNyQjtBQUNBLGNBQU1tVyxhQUFhLEdBQUdOLFNBQVMsQ0FBQ2pSLGFBQVYsR0FBMEJvQyx5QkFBMUIsRUFBdEI7O0FBQ0EsYUFBSyxJQUFJckYsQ0FBVCxJQUFjbVUsU0FBZCxFQUF3QjtBQUNwQixjQUFJTSxRQUFRLEdBQUdOLFNBQVMsQ0FBQ25VLENBQUQsQ0FBeEI7QUFDQXlVLGtCQUFRLENBQUNILFVBQVQsR0FBc0JuTixRQUFRLENBQUNzTixRQUFRLENBQUNDLEVBQVYsQ0FBOUI7O0FBQ0EsY0FBSUQsUUFBUSxDQUFDSCxVQUFULEdBQXNCLENBQXRCLElBQTJCLENBQUNGLG1CQUFtQixDQUFDTyxHQUFwQixDQUF3QkYsUUFBUSxDQUFDSCxVQUFqQyxDQUFoQyxFQUE4RTtBQUMxRSxnQkFBRztBQUNDLGtCQUFJelgsR0FBRyxHQUFHRyxHQUFHLEdBQUcsaUJBQU4sR0FBd0J5WCxRQUFRLENBQUNILFVBQWpDLEdBQTRDLFdBQXREO0FBQ0Esa0JBQUk3VyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7O0FBQ0Esa0JBQUlZLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQixvQkFBSWlRLFFBQVEsR0FBR3hQLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE1Qzs7QUFDQSxvQkFBSXFQLFFBQVEsQ0FBQzBILFdBQVQsSUFBeUIxSCxRQUFRLENBQUMwSCxXQUFULElBQXdCSCxRQUFRLENBQUNDLEVBQTlELEVBQWtFO0FBQzlERCwwQkFBUSxDQUFDdkgsUUFBVCxHQUFvQkEsUUFBUSxDQUFDQSxRQUE3QjtBQUNIO0FBQ0o7O0FBQ0RzSCwyQkFBYSxDQUFDcFMsSUFBZCxDQUFtQjtBQUFDa1MsMEJBQVUsRUFBRUcsUUFBUSxDQUFDSDtBQUF0QixlQUFuQixFQUFzRHRNLE1BQXRELEdBQStEQyxTQUEvRCxDQUF5RTtBQUFDQyxvQkFBSSxFQUFDdU07QUFBTixlQUF6RTtBQUNBRix5QkFBVyxDQUFDak8sSUFBWixDQUFpQm1PLFFBQVEsQ0FBQ0gsVUFBMUI7QUFDSCxhQVhELENBWUEsT0FBTXBYLENBQU4sRUFBUTtBQUNKc1gsMkJBQWEsQ0FBQ3BTLElBQWQsQ0FBbUI7QUFBQ2tTLDBCQUFVLEVBQUVHLFFBQVEsQ0FBQ0g7QUFBdEIsZUFBbkIsRUFBc0R0TSxNQUF0RCxHQUErREMsU0FBL0QsQ0FBeUU7QUFBQ0Msb0JBQUksRUFBQ3VNO0FBQU4sZUFBekU7QUFDQUYseUJBQVcsQ0FBQ2pPLElBQVosQ0FBaUJtTyxRQUFRLENBQUNILFVBQTFCO0FBQ0FuWCxxQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQUMsQ0FBQ08sUUFBRixDQUFXRyxPQUF2QjtBQUNIO0FBQ0o7QUFDSjs7QUFDRDRXLHFCQUFhLENBQUNwUyxJQUFkLENBQW1CO0FBQUNrUyxvQkFBVSxFQUFDO0FBQUNPLGdCQUFJLEVBQUNOO0FBQU4sV0FBWjtBQUFnQ08seUJBQWUsRUFBQztBQUFDRCxnQkFBSSxFQUFDLENBQUMsUUFBRCxFQUFXLFVBQVgsRUFBdUIsU0FBdkI7QUFBTjtBQUFoRCxTQUFuQixFQUNLN0wsTUFETCxDQUNZO0FBQUNkLGNBQUksRUFBRTtBQUFDLCtCQUFtQjtBQUFwQjtBQUFQLFNBRFo7QUFFQXNNLHFCQUFhLENBQUNoSixPQUFkO0FBQ0g7O0FBQ0QsYUFBTyxJQUFQO0FBQ0gsS0ExQ0QsQ0EyQ0EsT0FBT3RPLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osR0FqRFU7QUFrRFgsa0NBQWdDLFlBQVU7QUFDdEMsU0FBS0ssT0FBTDtBQUNBLFFBQUk0VyxTQUFTLEdBQUdELFNBQVMsQ0FBQzlSLElBQVYsQ0FBZTtBQUFDLHlCQUFrQjtBQUFDeVMsWUFBSSxFQUFDLENBQUMsUUFBRCxFQUFXLFVBQVgsRUFBdUIsU0FBdkI7QUFBTjtBQUFuQixLQUFmLEVBQTZFdlMsS0FBN0UsRUFBaEI7O0FBRUEsUUFBSTZSLFNBQVMsSUFBS0EsU0FBUyxDQUFDOVYsTUFBVixHQUFtQixDQUFyQyxFQUF3QztBQUNwQyxXQUFLLElBQUkyQixDQUFULElBQWNtVSxTQUFkLEVBQXdCO0FBQ3BCLFlBQUloTixRQUFRLENBQUNnTixTQUFTLENBQUNuVSxDQUFELENBQVQsQ0FBYXNVLFVBQWQsQ0FBUixHQUFvQyxDQUF4QyxFQUEwQztBQUN0QyxjQUFHO0FBQ0M7QUFDQSxnQkFBSXpYLEdBQUcsR0FBR0csR0FBRyxHQUFHLGlCQUFOLEdBQXdCbVgsU0FBUyxDQUFDblUsQ0FBRCxDQUFULENBQWFzVSxVQUFyQyxHQUFnRCxXQUExRDtBQUNBLGdCQUFJN1csUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsZ0JBQUk0WCxRQUFRLEdBQUc7QUFBQ0gsd0JBQVUsRUFBRUgsU0FBUyxDQUFDblUsQ0FBRCxDQUFULENBQWFzVTtBQUExQixhQUFmOztBQUNBLGdCQUFJN1csUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCLGtCQUFJOFgsUUFBUSxHQUFHclgsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTVDO0FBQ0E0VyxzQkFBUSxDQUFDTSxRQUFULEdBQW9CQSxRQUFwQjtBQUNIOztBQUVEbFksZUFBRyxHQUFHRyxHQUFHLEdBQUcsaUJBQU4sR0FBd0JtWCxTQUFTLENBQUNuVSxDQUFELENBQVQsQ0FBYXNVLFVBQXJDLEdBQWdELFFBQXREO0FBQ0E3VyxvQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYOztBQUNBLGdCQUFJWSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0Isa0JBQUkyUSxLQUFLLEdBQUdsUSxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBekM7QUFDQTRXLHNCQUFRLENBQUM3RyxLQUFULEdBQWlCb0gsYUFBYSxDQUFDcEgsS0FBRCxDQUE5QjtBQUNIOztBQUVEL1EsZUFBRyxHQUFHRyxHQUFHLEdBQUcsaUJBQU4sR0FBd0JtWCxTQUFTLENBQUNuVSxDQUFELENBQVQsQ0FBYXNVLFVBQXJDLEdBQWdELFFBQXREO0FBQ0E3VyxvQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYOztBQUNBLGdCQUFJWSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0Isa0JBQUlnWSxLQUFLLEdBQUd2WCxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBekM7QUFDQTRXLHNCQUFRLENBQUNRLEtBQVQsR0FBaUJBLEtBQWpCO0FBQ0g7O0FBRURSLG9CQUFRLENBQUNTLFNBQVQsR0FBcUIsSUFBSXhWLElBQUosRUFBckI7QUFDQXdVLHFCQUFTLENBQUNsTCxNQUFWLENBQWlCO0FBQUNzTCx3QkFBVSxFQUFFSCxTQUFTLENBQUNuVSxDQUFELENBQVQsQ0FBYXNVO0FBQTFCLGFBQWpCLEVBQXdEO0FBQUNwTSxrQkFBSSxFQUFDdU07QUFBTixhQUF4RDtBQUNILFdBMUJELENBMkJBLE9BQU12WCxDQUFOLEVBQVEsQ0FFUDtBQUNKO0FBQ0o7QUFDSjs7QUFDRCxXQUFPLElBQVA7QUFDSDtBQTNGVSxDQUFmOztBQThGQSxNQUFNOFgsYUFBYSxHQUFJcEgsS0FBRCxJQUFXO0FBQzdCLE1BQUksQ0FBQ0EsS0FBTCxFQUFZO0FBQ1IsV0FBTyxFQUFQO0FBQ0g7O0FBRUQsTUFBSXVILE1BQU0sR0FBR3ZILEtBQUssQ0FBQ3BMLEdBQU4sQ0FBVzRTLElBQUQsSUFBVUEsSUFBSSxDQUFDQyxLQUF6QixDQUFiO0FBQ0EsTUFBSUMsY0FBYyxHQUFHLEVBQXJCO0FBQ0EsTUFBSUMsbUJBQW1CLEdBQUcsRUFBMUI7QUFDQTVZLFlBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0I7QUFBQ3RELHFCQUFpQixFQUFFO0FBQUM4RCxTQUFHLEVBQUV1UztBQUFOO0FBQXBCLEdBQWhCLEVBQW9EN1YsT0FBcEQsQ0FBNkRaLFNBQUQsSUFBZTtBQUN2RTRXLGtCQUFjLENBQUM1VyxTQUFTLENBQUNJLGlCQUFYLENBQWQsR0FBOEM7QUFDMUMwVyxhQUFPLEVBQUU5VyxTQUFTLENBQUNrTCxXQUFWLENBQXNCNEwsT0FEVztBQUUxQ2xZLGFBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCLE9BRnVCO0FBRzFDME0sWUFBTSxFQUFFN0ssVUFBVSxDQUFDVCxTQUFTLENBQUNzTCxNQUFYLENBSHdCO0FBSTFDeUwscUJBQWUsRUFBRXRXLFVBQVUsQ0FBQ1QsU0FBUyxDQUFDdUwsZ0JBQVgsQ0FKZTtBQUsxQ3lMLG9CQUFjLEVBQUV2VyxVQUFVLENBQUNULFNBQVMsQ0FBQ3VMLGdCQUFYO0FBTGdCLEtBQTlDO0FBT0FzTCx1QkFBbUIsQ0FBQzdXLFNBQVMsQ0FBQ0csZ0JBQVgsQ0FBbkIsR0FBa0RILFNBQVMsQ0FBQ0ksaUJBQTVEO0FBQ0gsR0FURDtBQVVBcVcsUUFBTSxDQUFDN1YsT0FBUCxDQUFnQitWLEtBQUQsSUFBVztBQUN0QixRQUFJLENBQUNDLGNBQWMsQ0FBQ0QsS0FBRCxDQUFuQixFQUE0QjtBQUN4QjtBQUNBLFVBQUl4WSxHQUFHLGFBQU1HLEdBQU4saUNBQWdDcVksS0FBaEMsaUJBQVA7QUFDQSxVQUFJL1csV0FBSjtBQUNBLFVBQUlxWCxXQUFXLEdBQUcsQ0FBbEI7O0FBQ0EsVUFBRztBQUNDLFlBQUlsWSxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7O0FBQ0EsWUFBSVksUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCcUIscUJBQVcsR0FBR1osSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTNDOztBQUNBLGNBQUlTLFdBQVcsSUFBSUEsV0FBVyxDQUFDRCxNQUFaLEdBQXFCLENBQXhDLEVBQTJDO0FBQ3ZDQyx1QkFBVyxDQUFDZ0IsT0FBWixDQUFxQlMsVUFBRCxJQUFnQjtBQUNoQyxrQkFBSWIsTUFBTSxHQUFHQyxVQUFVLENBQUNZLFVBQVUsQ0FBQ2IsTUFBWixDQUF2Qjs7QUFDQSxrQkFBSXFXLG1CQUFtQixDQUFDeFYsVUFBVSxDQUFDd0csaUJBQVosQ0FBdkIsRUFBdUQ7QUFDbkQ7QUFDQSxvQkFBSTdILFNBQVMsR0FBRzRXLGNBQWMsQ0FBQ0MsbUJBQW1CLENBQUN4VixVQUFVLENBQUN3RyxpQkFBWixDQUFwQixDQUE5QjtBQUNBN0gseUJBQVMsQ0FBQ2dYLGNBQVYsSUFBNEJ4VyxNQUE1Qjs7QUFDQSxvQkFBSVIsU0FBUyxDQUFDdUwsZ0JBQVYsSUFBOEIsQ0FBbEMsRUFBb0M7QUFBRTtBQUNsQzBMLDZCQUFXLElBQUt6VyxNQUFNLEdBQUNSLFNBQVMsQ0FBQytXLGVBQWxCLEdBQXFDL1csU0FBUyxDQUFDc0wsTUFBOUQ7QUFDSDtBQUVKLGVBUkQsTUFRTztBQUNILG9CQUFJdEwsU0FBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDRSxrQ0FBZ0IsRUFBRWtCLFVBQVUsQ0FBQ3dHO0FBQTlCLGlCQUFuQixDQUFoQjs7QUFDQSxvQkFBSTdILFNBQVMsSUFBSUEsU0FBUyxDQUFDdUwsZ0JBQVYsSUFBOEIsQ0FBL0MsRUFBaUQ7QUFBRTtBQUMvQzBMLDZCQUFXLElBQUt6VyxNQUFNLEdBQUNDLFVBQVUsQ0FBQ1QsU0FBUyxDQUFDdUwsZ0JBQVgsQ0FBbEIsR0FBa0Q5SyxVQUFVLENBQUNULFNBQVMsQ0FBQ3NMLE1BQVgsQ0FBM0U7QUFDSDtBQUNKO0FBQ0osYUFoQkQ7QUFpQkg7QUFDSjtBQUNKLE9BeEJELENBeUJBLE9BQU85TSxDQUFQLEVBQVM7QUFDTEMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFDRG9ZLG9CQUFjLENBQUNELEtBQUQsQ0FBZCxHQUF3QjtBQUFDTSxtQkFBVyxFQUFFQTtBQUFkLE9BQXhCO0FBQ0g7QUFDSixHQXBDRDtBQXFDQSxTQUFPL0gsS0FBSyxDQUFDcEwsR0FBTixDQUFXNFMsSUFBRCxJQUFVO0FBQ3ZCLFFBQUlDLEtBQUssR0FBR0MsY0FBYyxDQUFDRixJQUFJLENBQUNDLEtBQU4sQ0FBMUI7QUFDQSxRQUFJTSxXQUFXLEdBQUdOLEtBQUssQ0FBQ00sV0FBeEI7O0FBQ0EsUUFBSUEsV0FBVyxJQUFJekssU0FBbkIsRUFBOEI7QUFDMUI7QUFDQXlLLGlCQUFXLEdBQUdOLEtBQUssQ0FBQ0ksZUFBTixHQUF3QkosS0FBSyxDQUFDSyxjQUFOLEdBQXFCTCxLQUFLLENBQUNJLGVBQTVCLEdBQStDSixLQUFLLENBQUNyTCxNQUE1RSxHQUFvRixDQUFsRztBQUNIOztBQUNELDZCQUFXb0wsSUFBWDtBQUFpQk87QUFBakI7QUFDSCxHQVJNLENBQVA7QUFTSCxDQWhFRCxDOzs7Ozs7Ozs7OztBQ3BHQSxJQUFJclosTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeVgsU0FBSjtBQUFjM1gsTUFBTSxDQUFDQyxJQUFQLENBQVksaUJBQVosRUFBOEI7QUFBQzBYLFdBQVMsQ0FBQ3pYLENBQUQsRUFBRztBQUFDeVgsYUFBUyxHQUFDelgsQ0FBVjtBQUFZOztBQUExQixDQUE5QixFQUEwRCxDQUExRDtBQUE2RCxJQUFJbVosS0FBSjtBQUFVclosTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDb1osT0FBSyxDQUFDblosQ0FBRCxFQUFHO0FBQUNtWixTQUFLLEdBQUNuWixDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBSXJKSCxNQUFNLENBQUNvVyxPQUFQLENBQWUsZ0JBQWYsRUFBaUMsWUFBWTtBQUN6QyxTQUFPd0IsU0FBUyxDQUFDOVIsSUFBVixDQUFlLEVBQWYsRUFBbUI7QUFBQ2lDLFFBQUksRUFBQztBQUFDaVEsZ0JBQVUsRUFBQyxDQUFDO0FBQWI7QUFBTixHQUFuQixDQUFQO0FBQ0gsQ0FGRDtBQUlBaFksTUFBTSxDQUFDb1csT0FBUCxDQUFlLGVBQWYsRUFBZ0MsVUFBVWdDLEVBQVYsRUFBYTtBQUN6Q2tCLE9BQUssQ0FBQ2xCLEVBQUQsRUFBS21CLE1BQUwsQ0FBTDtBQUNBLFNBQU8zQixTQUFTLENBQUM5UixJQUFWLENBQWU7QUFBQ2tTLGNBQVUsRUFBQ0k7QUFBWixHQUFmLENBQVA7QUFDSCxDQUhELEU7Ozs7Ozs7Ozs7O0FDUkFuWSxNQUFNLENBQUN1USxNQUFQLENBQWM7QUFBQ29ILFdBQVMsRUFBQyxNQUFJQTtBQUFmLENBQWQ7QUFBeUMsSUFBSW5ILEtBQUo7QUFBVXhRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3VRLE9BQUssQ0FBQ3RRLENBQUQsRUFBRztBQUFDc1EsU0FBSyxHQUFDdFEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUU1QyxNQUFNeVgsU0FBUyxHQUFHLElBQUluSCxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsV0FBckIsQ0FBbEIsQzs7Ozs7Ozs7Ozs7QUNGUCxJQUFJMVEsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJc1EsS0FBSjtBQUFVeFEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDdVEsT0FBSyxDQUFDdFEsQ0FBRCxFQUFHO0FBQUNzUSxTQUFLLEdBQUN0USxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlpRSxnQkFBSixFQUFxQkMsU0FBckIsRUFBK0JtVixXQUEvQixFQUEyQ0Msb0JBQTNDO0FBQWdFeFosTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDa0Usa0JBQWdCLENBQUNqRSxDQUFELEVBQUc7QUFBQ2lFLG9CQUFnQixHQUFDakUsQ0FBakI7QUFBbUIsR0FBeEM7O0FBQXlDa0UsV0FBUyxDQUFDbEUsQ0FBRCxFQUFHO0FBQUNrRSxhQUFTLEdBQUNsRSxDQUFWO0FBQVksR0FBbEU7O0FBQW1FcVosYUFBVyxDQUFDclosQ0FBRCxFQUFHO0FBQUNxWixlQUFXLEdBQUNyWixDQUFaO0FBQWMsR0FBaEc7O0FBQWlHc1osc0JBQW9CLENBQUN0WixDQUFELEVBQUc7QUFBQ3NaLHdCQUFvQixHQUFDdFosQ0FBckI7QUFBdUI7O0FBQWhKLENBQTVCLEVBQThLLENBQTlLO0FBQWlMLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBQThFLElBQUlnRSxhQUFKO0FBQWtCbEUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0NBQVosRUFBNEQ7QUFBQ2lFLGVBQWEsQ0FBQ2hFLENBQUQsRUFBRztBQUFDZ0UsaUJBQWEsR0FBQ2hFLENBQWQ7QUFBZ0I7O0FBQWxDLENBQTVELEVBQWdHLENBQWhHO0FBQW1HLElBQUl1WixNQUFKO0FBQVd6WixNQUFNLENBQUNDLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDd1osUUFBTSxDQUFDdlosQ0FBRCxFQUFHO0FBQUN1WixVQUFNLEdBQUN2WixDQUFQO0FBQVM7O0FBQXBCLENBQXJDLEVBQTJELENBQTNEO0FBQThELElBQUl3WixpQkFBSjtBQUFzQjFaLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ3laLG1CQUFpQixDQUFDeFosQ0FBRCxFQUFHO0FBQUN3WixxQkFBaUIsR0FBQ3haLENBQWxCO0FBQW9COztBQUExQyxDQUE1QixFQUF3RSxDQUF4RTtBQUEyRSxJQUFJeVosWUFBSjtBQUFpQjNaLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQzBaLGNBQVksQ0FBQ3paLENBQUQsRUFBRztBQUFDeVosZ0JBQVksR0FBQ3paLENBQWI7QUFBZTs7QUFBaEMsQ0FBNUIsRUFBOEQsQ0FBOUQ7QUFBaUUsSUFBSThELFNBQUo7QUFBY2hFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdCQUFaLEVBQXFDO0FBQUMrRCxXQUFTLENBQUM5RCxDQUFELEVBQUc7QUFBQzhELGFBQVMsR0FBQzlELENBQVY7QUFBWTs7QUFBMUIsQ0FBckMsRUFBaUUsQ0FBakU7QUFBb0UsSUFBSStELEtBQUo7QUFBVWpFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUNnRSxPQUFLLENBQUMvRCxDQUFELEVBQUc7QUFBQytELFNBQUssR0FBQy9ELENBQU47QUFBUTs7QUFBbEIsQ0FBbkMsRUFBdUQsQ0FBdkQ7O0FBQTBELElBQUkwWixDQUFKOztBQUFNNVosTUFBTSxDQUFDQyxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDNFcsU0FBTyxDQUFDM1csQ0FBRCxFQUFHO0FBQUMwWixLQUFDLEdBQUMxWixDQUFGO0FBQUk7O0FBQWhCLENBQXJCLEVBQXVDLEVBQXZDO0FBV3Y5QixNQUFNMlosaUJBQWlCLEdBQUcsSUFBMUI7O0FBRUEsTUFBTUMsYUFBYSxHQUFHLENBQUM5UixXQUFELEVBQWMrUixZQUFkLEtBQStCO0FBQ2pELE1BQUlDLFVBQVUsR0FBRyxFQUFqQjtBQUNBLFFBQU1DLElBQUksR0FBRztBQUFDQyxRQUFJLEVBQUUsQ0FDaEI7QUFBRS9ULFlBQU0sRUFBRTtBQUFFZ1UsV0FBRyxFQUFFblM7QUFBUDtBQUFWLEtBRGdCLEVBRWhCO0FBQUU3QixZQUFNLEVBQUU7QUFBRWlVLFlBQUksRUFBRUw7QUFBUjtBQUFWLEtBRmdCO0FBQVAsR0FBYjtBQUdBLFFBQU1NLE9BQU8sR0FBRztBQUFDdlMsUUFBSSxFQUFDO0FBQUMzQixZQUFNLEVBQUU7QUFBVDtBQUFOLEdBQWhCO0FBQ0FuQyxXQUFTLENBQUM2QixJQUFWLENBQWVvVSxJQUFmLEVBQXFCSSxPQUFyQixFQUE4QnRYLE9BQTlCLENBQXVDbUQsS0FBRCxJQUFXO0FBQzdDOFQsY0FBVSxDQUFDOVQsS0FBSyxDQUFDQyxNQUFQLENBQVYsR0FBMkI7QUFDdkJBLFlBQU0sRUFBRUQsS0FBSyxDQUFDQyxNQURTO0FBRXZCTCxxQkFBZSxFQUFFSSxLQUFLLENBQUNKLGVBRkE7QUFHdkIwRSxxQkFBZSxFQUFFdEUsS0FBSyxDQUFDc0UsZUFIQTtBQUl2QksscUJBQWUsRUFBRTNFLEtBQUssQ0FBQzJFLGVBSkE7QUFLdkIvRixnQkFBVSxFQUFFb0IsS0FBSyxDQUFDcEIsVUFMSztBQU12QjVCLFVBQUksRUFBRWdELEtBQUssQ0FBQ2hEO0FBTlcsS0FBM0I7QUFRSCxHQVREO0FBV0FrQixXQUFTLENBQUN5QixJQUFWLENBQWVvVSxJQUFmLEVBQXFCSSxPQUFyQixFQUE4QnRYLE9BQTlCLENBQXVDbUQsS0FBRCxJQUFXO0FBQzdDLFFBQUksQ0FBQzhULFVBQVUsQ0FBQzlULEtBQUssQ0FBQ0MsTUFBUCxDQUFmLEVBQStCO0FBQzNCNlQsZ0JBQVUsQ0FBQzlULEtBQUssQ0FBQ0MsTUFBUCxDQUFWLEdBQTJCO0FBQUVBLGNBQU0sRUFBRUQsS0FBSyxDQUFDQztBQUFoQixPQUEzQjtBQUNBdkYsYUFBTyxDQUFDQyxHQUFSLGlCQUFxQnFGLEtBQUssQ0FBQ0MsTUFBM0I7QUFDSDs7QUFDRHlULEtBQUMsQ0FBQ1UsTUFBRixDQUFTTixVQUFVLENBQUM5VCxLQUFLLENBQUNDLE1BQVAsQ0FBbkIsRUFBbUM7QUFDL0IwRCxnQkFBVSxFQUFFM0QsS0FBSyxDQUFDMkQsVUFEYTtBQUUvQjZDLHNCQUFnQixFQUFFeEcsS0FBSyxDQUFDd0csZ0JBRk87QUFHL0JsRyxjQUFRLEVBQUVOLEtBQUssQ0FBQ00sUUFIZTtBQUkvQjRFLGtCQUFZLEVBQUVsRixLQUFLLENBQUNrRjtBQUpXLEtBQW5DO0FBTUgsR0FYRDtBQVlBLFNBQU80TyxVQUFQO0FBQ0gsQ0E5QkQ7O0FBZ0NBLE1BQU1PLGlCQUFpQixHQUFHLENBQUNDLFlBQUQsRUFBZTFVLGVBQWYsS0FBbUM7QUFDekQsTUFBSTJVLGNBQWMsR0FBR2QsWUFBWSxDQUFDdlgsT0FBYixDQUNqQjtBQUFDMFcsU0FBSyxFQUFDMEIsWUFBUDtBQUFxQjdKLFlBQVEsRUFBQzdLLGVBQTlCO0FBQStDNFUsZUFBVyxFQUFFLENBQUM7QUFBN0QsR0FEaUIsQ0FBckI7QUFFQSxNQUFJQyxpQkFBaUIsR0FBRzVhLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QkQsV0FBL0M7QUFDQSxNQUFJNFMsU0FBUyxHQUFHLEVBQWhCOztBQUNBLE1BQUlILGNBQUosRUFBb0I7QUFDaEJHLGFBQVMsR0FBR2hCLENBQUMsQ0FBQ2lCLElBQUYsQ0FBT0osY0FBUCxFQUF1QixDQUFDLFdBQUQsRUFBYyxZQUFkLENBQXZCLENBQVo7QUFDSCxHQUZELE1BRU87QUFDSEcsYUFBUyxHQUFHO0FBQ1JFLGVBQVMsRUFBRSxDQURIO0FBRVJDLGdCQUFVLEVBQUU7QUFGSixLQUFaO0FBSUg7O0FBQ0QsU0FBT0gsU0FBUDtBQUNILENBZEQ7O0FBZ0JBN2EsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCw0Q0FBMEMsWUFBVTtBQUNoRCxRQUFJLENBQUNrYSxpQkFBTCxFQUF1QjtBQUNuQixVQUFJO0FBQ0EsWUFBSUMsU0FBUyxHQUFHOVgsSUFBSSxDQUFDb1QsR0FBTCxFQUFoQjtBQUNBeUUseUJBQWlCLEdBQUcsSUFBcEI7QUFDQXBhLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLDhCQUFaO0FBQ0EsYUFBS0csT0FBTDtBQUNBLFlBQUk4RCxVQUFVLEdBQUcxRSxVQUFVLENBQUN5RixJQUFYLENBQWdCLEVBQWhCLEVBQW9CRSxLQUFwQixFQUFqQjtBQUNBLFlBQUlnVSxZQUFZLEdBQUdoYSxNQUFNLENBQUNxSSxJQUFQLENBQVkseUJBQVosQ0FBbkI7QUFDQSxZQUFJOFMsY0FBYyxHQUFHekIsTUFBTSxDQUFDclgsT0FBUCxDQUFlO0FBQUMwSixpQkFBTyxFQUFFL0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFqQyxTQUFmLENBQXJCO0FBQ0EsWUFBSTlELFdBQVcsR0FBSWtULGNBQWMsSUFBRUEsY0FBYyxDQUFDQyw4QkFBaEMsR0FBZ0VELGNBQWMsQ0FBQ0MsOEJBQS9FLEdBQThHcGIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCRCxXQUF2SjtBQUNBK1Isb0JBQVksR0FBRzFOLElBQUksQ0FBQytPLEdBQUwsQ0FBU3BULFdBQVcsR0FBRzZSLGlCQUF2QixFQUEwQ0UsWUFBMUMsQ0FBZjtBQUNBLGNBQU1zQixlQUFlLEdBQUcxQixZQUFZLENBQUNqVCxhQUFiLEdBQTZCNFUsdUJBQTdCLEVBQXhCO0FBRUEsWUFBSUMsYUFBYSxHQUFHLEVBQXBCO0FBQ0F6VyxrQkFBVSxDQUFDL0IsT0FBWCxDQUFvQlosU0FBRCxJQUFlb1osYUFBYSxDQUFDcFosU0FBUyxDQUFDcEIsT0FBWCxDQUFiLEdBQW1Db0IsU0FBckUsRUFiQSxDQWVBOztBQUNBLFlBQUk2WCxVQUFVLEdBQUdGLGFBQWEsQ0FBQzlSLFdBQUQsRUFBYytSLFlBQWQsQ0FBOUIsQ0FoQkEsQ0FrQkE7O0FBQ0EsWUFBSXlCLGtCQUFrQixHQUFHLEVBQXpCOztBQUVBNUIsU0FBQyxDQUFDN1csT0FBRixDQUFVaVgsVUFBVixFQUFzQixDQUFDOVQsS0FBRCxFQUFRd1UsV0FBUixLQUF3QjtBQUMxQyxjQUFJNVUsZUFBZSxHQUFHSSxLQUFLLENBQUNKLGVBQTVCO0FBQ0EsY0FBSTJWLGVBQWUsR0FBRyxJQUFJM0QsR0FBSixDQUFRNVIsS0FBSyxDQUFDcEIsVUFBZCxDQUF0QjtBQUNBLGNBQUk0VyxhQUFhLEdBQUd4WCxhQUFhLENBQUM5QixPQUFkLENBQXNCO0FBQUN1SSx3QkFBWSxFQUFDekUsS0FBSyxDQUFDQztBQUFwQixXQUF0QixDQUFwQjtBQUNBLGNBQUl3VixnQkFBZ0IsR0FBRyxDQUF2QjtBQUVBRCx1QkFBYSxDQUFDNVcsVUFBZCxDQUF5Qi9CLE9BQXpCLENBQWtDNlksZUFBRCxJQUFxQjtBQUNsRCxnQkFBSUgsZUFBZSxDQUFDckQsR0FBaEIsQ0FBb0J3RCxlQUFlLENBQUM3YSxPQUFwQyxDQUFKLEVBQ0k0YSxnQkFBZ0IsSUFBSS9ZLFVBQVUsQ0FBQ2daLGVBQWUsQ0FBQ3hRLFlBQWpCLENBQTlCO0FBQ1AsV0FIRDtBQUtBc1EsdUJBQWEsQ0FBQzVXLFVBQWQsQ0FBeUIvQixPQUF6QixDQUFrQzZZLGVBQUQsSUFBcUI7QUFDbEQsZ0JBQUlDLGdCQUFnQixHQUFHRCxlQUFlLENBQUM3YSxPQUF2Qzs7QUFDQSxnQkFBSSxDQUFDNlksQ0FBQyxDQUFDeEIsR0FBRixDQUFNb0Qsa0JBQU4sRUFBMEIsQ0FBQzFWLGVBQUQsRUFBa0IrVixnQkFBbEIsQ0FBMUIsQ0FBTCxFQUFxRTtBQUNqRSxrQkFBSWpCLFNBQVMsR0FBR0wsaUJBQWlCLENBQUNzQixnQkFBRCxFQUFtQi9WLGVBQW5CLENBQWpDOztBQUNBOFQsZUFBQyxDQUFDa0MsR0FBRixDQUFNTixrQkFBTixFQUEwQixDQUFDMVYsZUFBRCxFQUFrQitWLGdCQUFsQixDQUExQixFQUErRGpCLFNBQS9EO0FBQ0g7O0FBRURoQixhQUFDLENBQUNuTixNQUFGLENBQVMrTyxrQkFBVCxFQUE2QixDQUFDMVYsZUFBRCxFQUFrQitWLGdCQUFsQixFQUFvQyxZQUFwQyxDQUE3QixFQUFpRkUsQ0FBRCxJQUFPQSxDQUFDLEdBQUMsQ0FBekY7O0FBQ0EsZ0JBQUksQ0FBQ04sZUFBZSxDQUFDckQsR0FBaEIsQ0FBb0J5RCxnQkFBcEIsQ0FBTCxFQUE0QztBQUN4Q2pDLGVBQUMsQ0FBQ25OLE1BQUYsQ0FBUytPLGtCQUFULEVBQTZCLENBQUMxVixlQUFELEVBQWtCK1YsZ0JBQWxCLEVBQW9DLFdBQXBDLENBQTdCLEVBQWdGRSxDQUFELElBQU9BLENBQUMsR0FBQyxDQUF4Rjs7QUFDQVYsNkJBQWUsQ0FBQzlRLE1BQWhCLENBQXVCO0FBQ25CdU8scUJBQUssRUFBRStDLGdCQURZO0FBRW5CbkIsMkJBQVcsRUFBRXhVLEtBQUssQ0FBQ0MsTUFGQTtBQUduQndLLHdCQUFRLEVBQUU3SyxlQUhTO0FBSW5CMEUsK0JBQWUsRUFBRXRFLEtBQUssQ0FBQ3NFLGVBSko7QUFLbkJLLCtCQUFlLEVBQUUzRSxLQUFLLENBQUMyRSxlQUxKO0FBTW5CM0gsb0JBQUksRUFBRWdELEtBQUssQ0FBQ2hELElBTk87QUFPbkIyRywwQkFBVSxFQUFFM0QsS0FBSyxDQUFDMkQsVUFQQztBQVFuQjZDLGdDQUFnQixFQUFFeEcsS0FBSyxDQUFDd0csZ0JBUkw7QUFTbkJsRyx3QkFBUSxFQUFFTixLQUFLLENBQUNNLFFBVEc7QUFVbkI0UywyQkFBVyxFQUFFbFQsS0FBSyxDQUFDa0YsWUFWQTtBQVduQnVRLGdDQVhtQjtBQVluQmhELHlCQUFTLEVBQUVvQixZQVpRO0FBYW5CZSx5QkFBUyxFQUFFbEIsQ0FBQyxDQUFDcFosR0FBRixDQUFNZ2Isa0JBQU4sRUFBMEIsQ0FBQzFWLGVBQUQsRUFBa0IrVixnQkFBbEIsRUFBb0MsV0FBcEMsQ0FBMUIsQ0FiUTtBQWNuQmQsMEJBQVUsRUFBRW5CLENBQUMsQ0FBQ3BaLEdBQUYsQ0FBTWdiLGtCQUFOLEVBQTBCLENBQUMxVixlQUFELEVBQWtCK1YsZ0JBQWxCLEVBQW9DLFlBQXBDLENBQTFCO0FBZE8sZUFBdkI7QUFnQkg7QUFDSixXQTNCRDtBQTRCSCxTQXZDRDs7QUF5Q0FqQyxTQUFDLENBQUM3VyxPQUFGLENBQVV5WSxrQkFBVixFQUE4QixDQUFDNUMsTUFBRCxFQUFTOVMsZUFBVCxLQUE2QjtBQUN2RDhULFdBQUMsQ0FBQzdXLE9BQUYsQ0FBVTZWLE1BQVYsRUFBa0IsQ0FBQ29ELEtBQUQsRUFBUXhCLFlBQVIsS0FBeUI7QUFDdkNhLDJCQUFlLENBQUN4VixJQUFoQixDQUFxQjtBQUNqQmlULG1CQUFLLEVBQUUwQixZQURVO0FBRWpCN0osc0JBQVEsRUFBRTdLLGVBRk87QUFHakI0VSx5QkFBVyxFQUFFLENBQUM7QUFIRyxhQUFyQixFQUlHalAsTUFKSCxHQUlZQyxTQUpaLENBSXNCO0FBQUNDLGtCQUFJLEVBQUU7QUFDekJtTixxQkFBSyxFQUFFMEIsWUFEa0I7QUFFekI3Six3QkFBUSxFQUFFN0ssZUFGZTtBQUd6QjRVLDJCQUFXLEVBQUUsQ0FBQyxDQUhXO0FBSXpCL0IseUJBQVMsRUFBRW9CLFlBSmM7QUFLekJlLHlCQUFTLEVBQUVsQixDQUFDLENBQUNwWixHQUFGLENBQU13YixLQUFOLEVBQWEsV0FBYixDQUxjO0FBTXpCakIsMEJBQVUsRUFBRW5CLENBQUMsQ0FBQ3BaLEdBQUYsQ0FBTXdiLEtBQU4sRUFBYSxZQUFiO0FBTmE7QUFBUCxhQUp0QjtBQVlILFdBYkQ7QUFjSCxTQWZEOztBQWlCQSxZQUFJNUUsT0FBTyxHQUFHLEVBQWQ7O0FBQ0EsWUFBSWlFLGVBQWUsQ0FBQ3ZaLE1BQWhCLEdBQXlCLENBQTdCLEVBQStCO0FBQzNCLGdCQUFNbWEsTUFBTSxHQUFHdEMsWUFBWSxDQUFDdUMsT0FBYixDQUFxQkMsS0FBckIsQ0FBMkJGLE1BQTFDLENBRDJCLENBRTNCO0FBQ0E7QUFDQTs7QUFDQSxjQUFJRyxXQUFXLEdBQUdmLGVBQWUsQ0FBQ3BNLE9BQWhCLENBQXdCO0FBQUk7QUFBNUIsWUFBNkNvTixJQUE3QyxDQUNkdGMsTUFBTSxDQUFDdWMsZUFBUCxDQUF1QixDQUFDaGIsTUFBRCxFQUFTK0ksR0FBVCxLQUFpQjtBQUNwQyxnQkFBSUEsR0FBSixFQUFRO0FBQ0oyUSwrQkFBaUIsR0FBRyxLQUFwQixDQURJLENBRUo7O0FBQ0Esb0JBQU0zUSxHQUFOO0FBQ0g7O0FBQ0QsZ0JBQUkvSSxNQUFKLEVBQVc7QUFDUDtBQUNBOFYscUJBQU8sR0FBRyxXQUFJOVYsTUFBTSxDQUFDQSxNQUFQLENBQWNpYixTQUFsQiw2QkFDSWpiLE1BQU0sQ0FBQ0EsTUFBUCxDQUFja2IsU0FEbEIsNkJBRUlsYixNQUFNLENBQUNBLE1BQVAsQ0FBY21iLFNBRmxCLGVBQVY7QUFHSDtBQUNKLFdBWkQsQ0FEYyxDQUFsQjtBQWVBMVksaUJBQU8sQ0FBQ3VELEtBQVIsQ0FBYzhVLFdBQWQ7QUFDSDs7QUFFRHBCLHlCQUFpQixHQUFHLEtBQXBCO0FBQ0F2QixjQUFNLENBQUNoTyxNQUFQLENBQWM7QUFBQ0ssaUJBQU8sRUFBRS9MLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEU7QUFBakMsU0FBZCxFQUF5RDtBQUFDSCxjQUFJLEVBQUM7QUFBQ3dQLDBDQUE4QixFQUFDcEIsWUFBaEM7QUFBOEMyQyx3Q0FBNEIsRUFBRSxJQUFJdlosSUFBSjtBQUE1RTtBQUFOLFNBQXpEO0FBQ0EsaUNBQWtCQSxJQUFJLENBQUNvVCxHQUFMLEtBQWEwRSxTQUEvQixnQkFBOEM3RCxPQUE5QztBQUNILE9BMUdELENBMEdFLE9BQU96VyxDQUFQLEVBQVU7QUFDUnFhLHlCQUFpQixHQUFHLEtBQXBCO0FBQ0EsY0FBTXJhLENBQU47QUFDSDtBQUNKLEtBL0dELE1BZ0hJO0FBQ0EsYUFBTyxhQUFQO0FBQ0g7QUFDSixHQXJIVTtBQXNIWCxpREFBK0MsWUFBVTtBQUNyRDtBQUNBO0FBQ0EsUUFBSSxDQUFDZ2Msc0JBQUwsRUFBNEI7QUFDeEJBLDRCQUFzQixHQUFHLElBQXpCO0FBQ0EvYixhQUFPLENBQUNDLEdBQVIsQ0FBWSw4QkFBWjtBQUNBLFdBQUtHLE9BQUw7QUFDQSxVQUFJOEQsVUFBVSxHQUFHMUUsVUFBVSxDQUFDeUYsSUFBWCxDQUFnQixFQUFoQixFQUFvQkUsS0FBcEIsRUFBakI7QUFDQSxVQUFJZ1UsWUFBWSxHQUFHaGEsTUFBTSxDQUFDcUksSUFBUCxDQUFZLHlCQUFaLENBQW5CO0FBQ0EsVUFBSThTLGNBQWMsR0FBR3pCLE1BQU0sQ0FBQ3JYLE9BQVAsQ0FBZTtBQUFDMEosZUFBTyxFQUFFL0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFqQyxPQUFmLENBQXJCO0FBQ0EsVUFBSTlELFdBQVcsR0FBSWtULGNBQWMsSUFBRUEsY0FBYyxDQUFDMEIscUJBQWhDLEdBQXVEMUIsY0FBYyxDQUFDMEIscUJBQXRFLEdBQTRGN2MsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCRCxXQUFySSxDQVB3QixDQVF4QjtBQUNBOztBQUNBLFlBQU1xVCxlQUFlLEdBQUczQixpQkFBaUIsQ0FBQ2hULGFBQWxCLEdBQWtDb0MseUJBQWxDLEVBQXhCOztBQUNBLFdBQUtyRixDQUFMLElBQVVxQixVQUFWLEVBQXFCO0FBQ2pCO0FBQ0EsWUFBSTBWLFlBQVksR0FBRzFWLFVBQVUsQ0FBQ3JCLENBQUQsQ0FBVixDQUFjMUMsT0FBakM7QUFDQSxZQUFJOGIsYUFBYSxHQUFHMVksZ0JBQWdCLENBQUMwQixJQUFqQixDQUFzQjtBQUN0QzlFLGlCQUFPLEVBQUN5WixZQUQ4QjtBQUV0Q3JQLGdCQUFNLEVBQUMsS0FGK0I7QUFHdEMrTyxjQUFJLEVBQUUsQ0FBRTtBQUFFL1Qsa0JBQU0sRUFBRTtBQUFFZ1UsaUJBQUcsRUFBRW5TO0FBQVA7QUFBVixXQUFGLEVBQW9DO0FBQUU3QixrQkFBTSxFQUFFO0FBQUVpVSxrQkFBSSxFQUFFTDtBQUFSO0FBQVYsV0FBcEM7QUFIZ0MsU0FBdEIsRUFJakJoVSxLQUppQixFQUFwQjtBQU1BLFlBQUkrVyxNQUFNLEdBQUcsRUFBYixDQVRpQixDQVdqQjs7QUFDQSxhQUFLdlcsQ0FBTCxJQUFVc1csYUFBVixFQUF3QjtBQUNwQixjQUFJM1csS0FBSyxHQUFHbEMsU0FBUyxDQUFDNUIsT0FBVixDQUFrQjtBQUFDK0Qsa0JBQU0sRUFBQzBXLGFBQWEsQ0FBQ3RXLENBQUQsQ0FBYixDQUFpQko7QUFBekIsV0FBbEIsQ0FBWjtBQUNBLGNBQUk0VyxjQUFjLEdBQUdyRCxpQkFBaUIsQ0FBQ3RYLE9BQWxCLENBQTBCO0FBQUMwVyxpQkFBSyxFQUFDMEIsWUFBUDtBQUFxQjdKLG9CQUFRLEVBQUN6SyxLQUFLLENBQUNKO0FBQXBDLFdBQTFCLENBQXJCOztBQUVBLGNBQUksT0FBT2dYLE1BQU0sQ0FBQzVXLEtBQUssQ0FBQ0osZUFBUCxDQUFiLEtBQXlDLFdBQTdDLEVBQXlEO0FBQ3JELGdCQUFJaVgsY0FBSixFQUFtQjtBQUNmRCxvQkFBTSxDQUFDNVcsS0FBSyxDQUFDSixlQUFQLENBQU4sR0FBZ0NpWCxjQUFjLENBQUNqWixLQUFmLEdBQXFCLENBQXJEO0FBQ0gsYUFGRCxNQUdJO0FBQ0FnWixvQkFBTSxDQUFDNVcsS0FBSyxDQUFDSixlQUFQLENBQU4sR0FBZ0MsQ0FBaEM7QUFDSDtBQUNKLFdBUEQsTUFRSTtBQUNBZ1gsa0JBQU0sQ0FBQzVXLEtBQUssQ0FBQ0osZUFBUCxDQUFOO0FBQ0g7QUFDSjs7QUFFRCxhQUFLL0UsT0FBTCxJQUFnQitiLE1BQWhCLEVBQXVCO0FBQ25CLGNBQUlwYSxJQUFJLEdBQUc7QUFDUG9XLGlCQUFLLEVBQUUwQixZQURBO0FBRVA3SixvQkFBUSxFQUFDNVAsT0FGRjtBQUdQK0MsaUJBQUssRUFBRWdaLE1BQU0sQ0FBQy9iLE9BQUQ7QUFITixXQUFYO0FBTUFzYSx5QkFBZSxDQUFDeFYsSUFBaEIsQ0FBcUI7QUFBQ2lULGlCQUFLLEVBQUMwQixZQUFQO0FBQXFCN0osb0JBQVEsRUFBQzVQO0FBQTlCLFdBQXJCLEVBQTZEMEssTUFBN0QsR0FBc0VDLFNBQXRFLENBQWdGO0FBQUNDLGdCQUFJLEVBQUNqSjtBQUFOLFdBQWhGO0FBQ0gsU0FyQ2dCLENBc0NqQjs7QUFFSDs7QUFFRCxVQUFJMlksZUFBZSxDQUFDdlosTUFBaEIsR0FBeUIsQ0FBN0IsRUFBK0I7QUFDM0J1Wix1QkFBZSxDQUFDcE0sT0FBaEIsQ0FBd0JsUCxNQUFNLENBQUN1YyxlQUFQLENBQXVCLENBQUNqUyxHQUFELEVBQU0vSSxNQUFOLEtBQWlCO0FBQzVELGNBQUkrSSxHQUFKLEVBQVE7QUFDSnNTLGtDQUFzQixHQUFHLEtBQXpCO0FBQ0EvYixtQkFBTyxDQUFDQyxHQUFSLENBQVl3SixHQUFaO0FBQ0g7O0FBQ0QsY0FBSS9JLE1BQUosRUFBVztBQUNQbVksa0JBQU0sQ0FBQ2hPLE1BQVAsQ0FBYztBQUFDSyxxQkFBTyxFQUFFL0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFqQyxhQUFkLEVBQXlEO0FBQUNILGtCQUFJLEVBQUM7QUFBQ2lSLHFDQUFxQixFQUFDN0MsWUFBdkI7QUFBcUNpRCxtQ0FBbUIsRUFBRSxJQUFJN1osSUFBSjtBQUExRDtBQUFOLGFBQXpEO0FBQ0F3WixrQ0FBc0IsR0FBRyxLQUF6QjtBQUNBL2IsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFDSDtBQUNKLFNBVnVCLENBQXhCO0FBV0gsT0FaRCxNQWFJO0FBQ0E4Yiw4QkFBc0IsR0FBRyxLQUF6QjtBQUNIOztBQUVELGFBQU8sSUFBUDtBQUNILEtBdkVELE1Bd0VJO0FBQ0EsYUFBTyxhQUFQO0FBQ0g7QUFDSixHQXBNVTtBQXFNWCxnREFBOEMsVUFBU3paLElBQVQsRUFBYztBQUN4RCxTQUFLbEMsT0FBTDtBQUNBLFFBQUl1VixHQUFHLEdBQUcsSUFBSXBULElBQUosRUFBVjs7QUFFQSxRQUFJRCxJQUFJLElBQUksR0FBWixFQUFnQjtBQUNaLFVBQUl3SixnQkFBZ0IsR0FBRyxDQUF2QjtBQUNBLFVBQUl1USxrQkFBa0IsR0FBRyxDQUF6QjtBQUVBLFVBQUlDLFNBQVMsR0FBRzlZLFNBQVMsQ0FBQ3lCLElBQVYsQ0FBZTtBQUFFLGdCQUFRO0FBQUVzVSxhQUFHLEVBQUUsSUFBSWhYLElBQUosQ0FBU0EsSUFBSSxDQUFDb1QsR0FBTCxLQUFhLEtBQUssSUFBM0I7QUFBUDtBQUFWLE9BQWYsRUFBc0V4USxLQUF0RSxFQUFoQjs7QUFDQSxVQUFJbVgsU0FBUyxDQUFDcGIsTUFBVixHQUFtQixDQUF2QixFQUF5QjtBQUNyQixhQUFLMkIsQ0FBTCxJQUFVeVosU0FBVixFQUFvQjtBQUNoQnhRLDBCQUFnQixJQUFJd1EsU0FBUyxDQUFDelosQ0FBRCxDQUFULENBQWErQyxRQUFqQztBQUNBeVcsNEJBQWtCLElBQUlDLFNBQVMsQ0FBQ3paLENBQUQsQ0FBVCxDQUFhMkgsWUFBbkM7QUFDSDs7QUFDRHNCLHdCQUFnQixHQUFHQSxnQkFBZ0IsR0FBR3dRLFNBQVMsQ0FBQ3BiLE1BQWhEO0FBQ0FtYiwwQkFBa0IsR0FBR0Esa0JBQWtCLEdBQUdDLFNBQVMsQ0FBQ3BiLE1BQXBEO0FBRUFtQyxhQUFLLENBQUN3SSxNQUFOLENBQWE7QUFBQ1gsaUJBQU8sRUFBQy9MLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEU7QUFBaEMsU0FBYixFQUFzRDtBQUFDSCxjQUFJLEVBQUM7QUFBQ3dSLGlDQUFxQixFQUFDRixrQkFBdkI7QUFBMkNHLCtCQUFtQixFQUFDMVE7QUFBL0Q7QUFBTixTQUF0RDtBQUNBNk0sbUJBQVcsQ0FBQ2hQLE1BQVosQ0FBbUI7QUFDZm1DLDBCQUFnQixFQUFFQSxnQkFESDtBQUVmdVEsNEJBQWtCLEVBQUVBLGtCQUZMO0FBR2Z6YixjQUFJLEVBQUUwQixJQUhTO0FBSWZ5VCxtQkFBUyxFQUFFSjtBQUpJLFNBQW5CO0FBTUg7QUFDSjs7QUFDRCxRQUFJclQsSUFBSSxJQUFJLEdBQVosRUFBZ0I7QUFDWixVQUFJd0osZ0JBQWdCLEdBQUcsQ0FBdkI7QUFDQSxVQUFJdVEsa0JBQWtCLEdBQUcsQ0FBekI7QUFDQSxVQUFJQyxTQUFTLEdBQUc5WSxTQUFTLENBQUN5QixJQUFWLENBQWU7QUFBRSxnQkFBUTtBQUFFc1UsYUFBRyxFQUFFLElBQUloWCxJQUFKLENBQVNBLElBQUksQ0FBQ29ULEdBQUwsS0FBYSxLQUFHLEVBQUgsR0FBUSxJQUE5QjtBQUFQO0FBQVYsT0FBZixFQUF5RXhRLEtBQXpFLEVBQWhCOztBQUNBLFVBQUltWCxTQUFTLENBQUNwYixNQUFWLEdBQW1CLENBQXZCLEVBQXlCO0FBQ3JCLGFBQUsyQixDQUFMLElBQVV5WixTQUFWLEVBQW9CO0FBQ2hCeFEsMEJBQWdCLElBQUl3USxTQUFTLENBQUN6WixDQUFELENBQVQsQ0FBYStDLFFBQWpDO0FBQ0F5Vyw0QkFBa0IsSUFBSUMsU0FBUyxDQUFDelosQ0FBRCxDQUFULENBQWEySCxZQUFuQztBQUNIOztBQUNEc0Isd0JBQWdCLEdBQUdBLGdCQUFnQixHQUFHd1EsU0FBUyxDQUFDcGIsTUFBaEQ7QUFDQW1iLDBCQUFrQixHQUFHQSxrQkFBa0IsR0FBR0MsU0FBUyxDQUFDcGIsTUFBcEQ7QUFFQW1DLGFBQUssQ0FBQ3dJLE1BQU4sQ0FBYTtBQUFDWCxpQkFBTyxFQUFDL0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFoQyxTQUFiLEVBQXNEO0FBQUNILGNBQUksRUFBQztBQUFDMFIsK0JBQW1CLEVBQUNKLGtCQUFyQjtBQUF5Q0ssNkJBQWlCLEVBQUM1UTtBQUEzRDtBQUFOLFNBQXREO0FBQ0E2TSxtQkFBVyxDQUFDaFAsTUFBWixDQUFtQjtBQUNmbUMsMEJBQWdCLEVBQUVBLGdCQURIO0FBRWZ1USw0QkFBa0IsRUFBRUEsa0JBRkw7QUFHZnpiLGNBQUksRUFBRTBCLElBSFM7QUFJZnlULG1CQUFTLEVBQUVKO0FBSkksU0FBbkI7QUFNSDtBQUNKOztBQUVELFFBQUlyVCxJQUFJLElBQUksR0FBWixFQUFnQjtBQUNaLFVBQUl3SixnQkFBZ0IsR0FBRyxDQUF2QjtBQUNBLFVBQUl1USxrQkFBa0IsR0FBRyxDQUF6QjtBQUNBLFVBQUlDLFNBQVMsR0FBRzlZLFNBQVMsQ0FBQ3lCLElBQVYsQ0FBZTtBQUFFLGdCQUFRO0FBQUVzVSxhQUFHLEVBQUUsSUFBSWhYLElBQUosQ0FBU0EsSUFBSSxDQUFDb1QsR0FBTCxLQUFhLEtBQUcsRUFBSCxHQUFNLEVBQU4sR0FBVyxJQUFqQztBQUFQO0FBQVYsT0FBZixFQUE0RXhRLEtBQTVFLEVBQWhCOztBQUNBLFVBQUltWCxTQUFTLENBQUNwYixNQUFWLEdBQW1CLENBQXZCLEVBQXlCO0FBQ3JCLGFBQUsyQixDQUFMLElBQVV5WixTQUFWLEVBQW9CO0FBQ2hCeFEsMEJBQWdCLElBQUl3USxTQUFTLENBQUN6WixDQUFELENBQVQsQ0FBYStDLFFBQWpDO0FBQ0F5Vyw0QkFBa0IsSUFBSUMsU0FBUyxDQUFDelosQ0FBRCxDQUFULENBQWEySCxZQUFuQztBQUNIOztBQUNEc0Isd0JBQWdCLEdBQUdBLGdCQUFnQixHQUFHd1EsU0FBUyxDQUFDcGIsTUFBaEQ7QUFDQW1iLDBCQUFrQixHQUFHQSxrQkFBa0IsR0FBR0MsU0FBUyxDQUFDcGIsTUFBcEQ7QUFFQW1DLGFBQUssQ0FBQ3dJLE1BQU4sQ0FBYTtBQUFDWCxpQkFBTyxFQUFDL0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFoQyxTQUFiLEVBQXNEO0FBQUNILGNBQUksRUFBQztBQUFDNFIsOEJBQWtCLEVBQUNOLGtCQUFwQjtBQUF3Q08sNEJBQWdCLEVBQUM5UTtBQUF6RDtBQUFOLFNBQXREO0FBQ0E2TSxtQkFBVyxDQUFDaFAsTUFBWixDQUFtQjtBQUNmbUMsMEJBQWdCLEVBQUVBLGdCQURIO0FBRWZ1USw0QkFBa0IsRUFBRUEsa0JBRkw7QUFHZnpiLGNBQUksRUFBRTBCLElBSFM7QUFJZnlULG1CQUFTLEVBQUVKO0FBSkksU0FBbkI7QUFNSDtBQUNKLEtBcEV1RCxDQXNFeEQ7O0FBQ0gsR0E1UVU7QUE2UVgsZ0RBQThDLFlBQVU7QUFDcEQsU0FBS3ZWLE9BQUw7QUFDQSxRQUFJOEQsVUFBVSxHQUFHMUUsVUFBVSxDQUFDeUYsSUFBWCxDQUFnQixFQUFoQixFQUFvQkUsS0FBcEIsRUFBakI7QUFDQSxRQUFJd1EsR0FBRyxHQUFHLElBQUlwVCxJQUFKLEVBQVY7O0FBQ0EsU0FBS00sQ0FBTCxJQUFVcUIsVUFBVixFQUFxQjtBQUNqQixVQUFJNEgsZ0JBQWdCLEdBQUcsQ0FBdkI7QUFFQSxVQUFJOUcsTUFBTSxHQUFHNUIsU0FBUyxDQUFDNkIsSUFBVixDQUFlO0FBQUNDLHVCQUFlLEVBQUNoQixVQUFVLENBQUNyQixDQUFELENBQVYsQ0FBYzFDLE9BQS9CO0FBQXdDLGdCQUFRO0FBQUVvWixhQUFHLEVBQUUsSUFBSWhYLElBQUosQ0FBU0EsSUFBSSxDQUFDb1QsR0FBTCxLQUFhLEtBQUcsRUFBSCxHQUFNLEVBQU4sR0FBVyxJQUFqQztBQUFQO0FBQWhELE9BQWYsRUFBaUg7QUFBQzlILGNBQU0sRUFBQztBQUFDdEksZ0JBQU0sRUFBQztBQUFSO0FBQVIsT0FBakgsRUFBc0lKLEtBQXRJLEVBQWI7O0FBRUEsVUFBSUgsTUFBTSxDQUFDOUQsTUFBUCxHQUFnQixDQUFwQixFQUFzQjtBQUNsQixZQUFJMmIsWUFBWSxHQUFHLEVBQW5COztBQUNBLGFBQUtsWCxDQUFMLElBQVVYLE1BQVYsRUFBaUI7QUFDYjZYLHNCQUFZLENBQUMxVCxJQUFiLENBQWtCbkUsTUFBTSxDQUFDVyxDQUFELENBQU4sQ0FBVUosTUFBNUI7QUFDSDs7QUFFRCxZQUFJK1csU0FBUyxHQUFHOVksU0FBUyxDQUFDeUIsSUFBVixDQUFlO0FBQUNNLGdCQUFNLEVBQUU7QUFBQ0UsZUFBRyxFQUFDb1g7QUFBTDtBQUFULFNBQWYsRUFBNkM7QUFBQ2hQLGdCQUFNLEVBQUM7QUFBQ3RJLGtCQUFNLEVBQUMsQ0FBUjtBQUFVSyxvQkFBUSxFQUFDO0FBQW5CO0FBQVIsU0FBN0MsRUFBNkVULEtBQTdFLEVBQWhCOztBQUdBLGFBQUsyWCxDQUFMLElBQVVSLFNBQVYsRUFBb0I7QUFDaEJ4USwwQkFBZ0IsSUFBSXdRLFNBQVMsQ0FBQ1EsQ0FBRCxDQUFULENBQWFsWCxRQUFqQztBQUNIOztBQUVEa0csd0JBQWdCLEdBQUdBLGdCQUFnQixHQUFHd1EsU0FBUyxDQUFDcGIsTUFBaEQ7QUFDSDs7QUFFRDBYLDBCQUFvQixDQUFDalAsTUFBckIsQ0FBNEI7QUFDeEJ6RSx1QkFBZSxFQUFFaEIsVUFBVSxDQUFDckIsQ0FBRCxDQUFWLENBQWMxQyxPQURQO0FBRXhCMkwsd0JBQWdCLEVBQUVBLGdCQUZNO0FBR3hCbEwsWUFBSSxFQUFFLGdDQUhrQjtBQUl4Qm1WLGlCQUFTLEVBQUVKO0FBSmEsT0FBNUI7QUFNSDs7QUFFRCxXQUFPLElBQVA7QUFDSDtBQS9TVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDN0RBLElBQUl4VyxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlpRSxnQkFBSixFQUFxQkMsU0FBckIsRUFBK0J1VixZQUEvQixFQUE0Q0QsaUJBQTVDLEVBQThEclYsZUFBOUQ7QUFBOEVyRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNrRSxrQkFBZ0IsQ0FBQ2pFLENBQUQsRUFBRztBQUFDaUUsb0JBQWdCLEdBQUNqRSxDQUFqQjtBQUFtQixHQUF4Qzs7QUFBeUNrRSxXQUFTLENBQUNsRSxDQUFELEVBQUc7QUFBQ2tFLGFBQVMsR0FBQ2xFLENBQVY7QUFBWSxHQUFsRTs7QUFBbUV5WixjQUFZLENBQUN6WixDQUFELEVBQUc7QUFBQ3laLGdCQUFZLEdBQUN6WixDQUFiO0FBQWUsR0FBbEc7O0FBQW1Hd1osbUJBQWlCLENBQUN4WixDQUFELEVBQUc7QUFBQ3daLHFCQUFpQixHQUFDeFosQ0FBbEI7QUFBb0IsR0FBNUk7O0FBQTZJbUUsaUJBQWUsQ0FBQ25FLENBQUQsRUFBRztBQUFDbUUsbUJBQWUsR0FBQ25FLENBQWhCO0FBQWtCOztBQUFsTCxDQUE1QixFQUFnTixDQUFoTjtBQUFtTixJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUloWEgsTUFBTSxDQUFDb1csT0FBUCxDQUFlLHVCQUFmLEVBQXdDLFlBQVk7QUFDaEQsU0FBT2hTLGdCQUFnQixDQUFDMEIsSUFBakIsRUFBUDtBQUNILENBRkQ7QUFJQTlGLE1BQU0sQ0FBQ29XLE9BQVAsQ0FBZSwwQkFBZixFQUEyQyxVQUFTcFYsT0FBVCxFQUFrQjRjLEdBQWxCLEVBQXNCO0FBQzdELFNBQU94WixnQkFBZ0IsQ0FBQzBCLElBQWpCLENBQXNCO0FBQUM5RSxXQUFPLEVBQUNBO0FBQVQsR0FBdEIsRUFBd0M7QUFBQ2dILFNBQUssRUFBQzRWLEdBQVA7QUFBWTdWLFFBQUksRUFBQztBQUFDM0IsWUFBTSxFQUFDLENBQUM7QUFBVDtBQUFqQixHQUF4QyxDQUFQO0FBQ0gsQ0FGRDtBQUlBcEcsTUFBTSxDQUFDb1csT0FBUCxDQUFlLG1CQUFmLEVBQW9DLFlBQVU7QUFDMUMsU0FBTy9SLFNBQVMsQ0FBQ3lCLElBQVYsQ0FBZSxFQUFmLEVBQWtCO0FBQUNpQyxRQUFJLEVBQUM7QUFBQzNCLFlBQU0sRUFBQyxDQUFDO0FBQVQsS0FBTjtBQUFrQjRCLFNBQUssRUFBQztBQUF4QixHQUFsQixDQUFQO0FBQ0gsQ0FGRDtBQUlBaEksTUFBTSxDQUFDb1csT0FBUCxDQUFlLHVCQUFmLEVBQXdDLFlBQVU7QUFDOUMsU0FBTzlSLGVBQWUsQ0FBQ3dCLElBQWhCLENBQXFCLEVBQXJCLEVBQXdCO0FBQUNpQyxRQUFJLEVBQUM7QUFBQzNCLFlBQU0sRUFBQyxDQUFDO0FBQVQsS0FBTjtBQUFtQjRCLFNBQUssRUFBQztBQUF6QixHQUF4QixDQUFQO0FBQ0gsQ0FGRDtBQUlBc0ksZ0JBQWdCLENBQUMsd0JBQUQsRUFBMkIsVUFBU3RQLE9BQVQsRUFBa0JTLElBQWxCLEVBQXVCO0FBQzlELE1BQUlvYyxVQUFVLEdBQUcsRUFBakI7O0FBQ0EsTUFBSXBjLElBQUksSUFBSSxPQUFaLEVBQW9CO0FBQ2hCb2MsY0FBVSxHQUFHO0FBQ1Q5RSxXQUFLLEVBQUUvWDtBQURFLEtBQWI7QUFHSCxHQUpELE1BS0k7QUFDQTZjLGNBQVUsR0FBRztBQUNUak4sY0FBUSxFQUFFNVA7QUFERCxLQUFiO0FBR0g7O0FBQ0QsU0FBTztBQUNIOEUsUUFBSSxHQUFFO0FBQ0YsYUFBTzZULGlCQUFpQixDQUFDN1QsSUFBbEIsQ0FBdUIrWCxVQUF2QixDQUFQO0FBQ0gsS0FIRTs7QUFJSHROLFlBQVEsRUFBRSxDQUNOO0FBQ0l6SyxVQUFJLENBQUNtVyxLQUFELEVBQU87QUFDUCxlQUFPNWIsVUFBVSxDQUFDeUYsSUFBWCxDQUNILEVBREcsRUFFSDtBQUFDNEksZ0JBQU0sRUFBQztBQUFDMU4sbUJBQU8sRUFBQyxDQUFUO0FBQVlzTSx1QkFBVyxFQUFDLENBQXhCO0FBQTJCQyx1QkFBVyxFQUFDO0FBQXZDO0FBQVIsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FETTtBQUpQLEdBQVA7QUFlSCxDQTNCZSxDQUFoQjtBQTZCQStDLGdCQUFnQixDQUFDLHlCQUFELEVBQTRCLFVBQVN0UCxPQUFULEVBQWtCUyxJQUFsQixFQUF1QjtBQUMvRCxTQUFPO0FBQ0hxRSxRQUFJLEdBQUU7QUFDRixhQUFPOFQsWUFBWSxDQUFDOVQsSUFBYixDQUNIO0FBQUMsU0FBQ3JFLElBQUQsR0FBUVQ7QUFBVCxPQURHLEVBRUg7QUFBQytHLFlBQUksRUFBRTtBQUFDNlEsbUJBQVMsRUFBRSxDQUFDO0FBQWI7QUFBUCxPQUZHLENBQVA7QUFJSCxLQU5FOztBQU9IckksWUFBUSxFQUFFLENBQ047QUFDSXpLLFVBQUksR0FBRTtBQUNGLGVBQU96RixVQUFVLENBQUN5RixJQUFYLENBQ0gsRUFERyxFQUVIO0FBQUM0SSxnQkFBTSxFQUFDO0FBQUMxTixtQkFBTyxFQUFDLENBQVQ7QUFBWXNNLHVCQUFXLEVBQUMsQ0FBeEI7QUFBMkIvSyw0QkFBZ0IsRUFBQztBQUE1QztBQUFSLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE07QUFQUCxHQUFQO0FBa0JILENBbkJlLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDakRBdEMsTUFBTSxDQUFDdVEsTUFBUCxDQUFjO0FBQUNwTSxrQkFBZ0IsRUFBQyxNQUFJQSxnQkFBdEI7QUFBdUNDLFdBQVMsRUFBQyxNQUFJQSxTQUFyRDtBQUErRHNWLG1CQUFpQixFQUFDLE1BQUlBLGlCQUFyRjtBQUF1R0MsY0FBWSxFQUFDLE1BQUlBLFlBQXhIO0FBQXFJdFYsaUJBQWUsRUFBQyxNQUFJQSxlQUF6SjtBQUF5S2tWLGFBQVcsRUFBQyxNQUFJQSxXQUF6TDtBQUFxTUMsc0JBQW9CLEVBQUMsTUFBSUE7QUFBOU4sQ0FBZDtBQUFtUSxJQUFJaEosS0FBSjtBQUFVeFEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDdVEsT0FBSyxDQUFDdFEsQ0FBRCxFQUFHO0FBQUNzUSxTQUFLLEdBQUN0USxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQXZDLEVBQXFFLENBQXJFO0FBR3ZVLE1BQU1pRSxnQkFBZ0IsR0FBRyxJQUFJcU0sS0FBSyxDQUFDQyxVQUFWLENBQXFCLG1CQUFyQixDQUF6QjtBQUNBLE1BQU1yTSxTQUFTLEdBQUcsSUFBSW9NLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixXQUFyQixDQUFsQjtBQUNBLE1BQU1pSixpQkFBaUIsR0FBRyxJQUFJbEosS0FBSyxDQUFDQyxVQUFWLENBQXFCLHFCQUFyQixDQUExQjtBQUNBLE1BQU1rSixZQUFZLEdBQUcsSUFBS25KLEtBQUssQ0FBQ0MsVUFBWCxDQUFzQixlQUF0QixDQUFyQjtBQUNBLE1BQU1wTSxlQUFlLEdBQUcsSUFBSW1NLEtBQUssQ0FBQ0MsVUFBVixDQUFxQiw0QkFBckIsQ0FBeEI7QUFDQSxNQUFNOEksV0FBVyxHQUFHLElBQUkvSSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsY0FBckIsQ0FBcEI7QUFDQSxNQUFNK0ksb0JBQW9CLEdBQUcsSUFBSWhKLEtBQUssQ0FBQ0MsVUFBVixDQUFxQix3QkFBckIsQ0FBN0I7QUFFUGlKLGlCQUFpQixDQUFDaEosT0FBbEIsQ0FBMEI7QUFDdEJtTixpQkFBZSxHQUFFO0FBQ2IsUUFBSTFiLFNBQVMsR0FBRy9CLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQ3JCLGFBQU8sRUFBQyxLQUFLNFA7QUFBZCxLQUFuQixDQUFoQjtBQUNBLFdBQVF4TyxTQUFTLENBQUNrTCxXQUFYLEdBQXdCbEwsU0FBUyxDQUFDa0wsV0FBVixDQUFzQjRMLE9BQTlDLEdBQXNELEtBQUt0SSxRQUFsRTtBQUNILEdBSnFCOztBQUt0Qm1OLGNBQVksR0FBRTtBQUNWLFFBQUkzYixTQUFTLEdBQUcvQixVQUFVLENBQUNnQyxPQUFYLENBQW1CO0FBQUNyQixhQUFPLEVBQUMsS0FBSytYO0FBQWQsS0FBbkIsQ0FBaEI7QUFDQSxXQUFRM1csU0FBUyxDQUFDa0wsV0FBWCxHQUF3QmxMLFNBQVMsQ0FBQ2tMLFdBQVYsQ0FBc0I0TCxPQUE5QyxHQUFzRCxLQUFLSCxLQUFsRTtBQUNIOztBQVJxQixDQUExQixFOzs7Ozs7Ozs7OztBQ1hBLElBQUkvWSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl1WixNQUFKO0FBQVd6WixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN3WixRQUFNLENBQUN2WixDQUFELEVBQUc7QUFBQ3VaLFVBQU0sR0FBQ3ZaLENBQVA7QUFBUzs7QUFBcEIsQ0FBM0IsRUFBaUQsQ0FBakQ7QUFBb0QsSUFBSW1aLEtBQUo7QUFBVXJaLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ29aLE9BQUssQ0FBQ25aLENBQUQsRUFBRztBQUFDbVosU0FBSyxHQUFDblosQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUl6SUgsTUFBTSxDQUFDb1csT0FBUCxDQUFlLGVBQWYsRUFBZ0MsWUFBWTtBQUN4QyxTQUFPc0QsTUFBTSxDQUFDNVQsSUFBUCxDQUFZO0FBQUNpRyxXQUFPLEVBQUMvTCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjhFO0FBQWhDLEdBQVosQ0FBUDtBQUNILENBRkQsRTs7Ozs7Ozs7Ozs7QUNKQTlMLE1BQU0sQ0FBQ3VRLE1BQVAsQ0FBYztBQUFDa0osUUFBTSxFQUFDLE1BQUlBO0FBQVosQ0FBZDtBQUFtQyxJQUFJakosS0FBSjtBQUFVeFEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDdVEsT0FBSyxDQUFDdFEsQ0FBRCxFQUFHO0FBQUNzUSxTQUFLLEdBQUN0USxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRXRDLE1BQU11WixNQUFNLEdBQUcsSUFBSWpKLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixRQUFyQixDQUFmLEM7Ozs7Ozs7Ozs7O0FDRlAsSUFBSTFRLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUErQyxJQUFJcUUsWUFBSjtBQUFpQnZFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUNzRSxjQUFZLENBQUNyRSxDQUFELEVBQUc7QUFBQ3FFLGdCQUFZLEdBQUNyRSxDQUFiO0FBQWU7O0FBQWhDLENBQWpELEVBQW1GLENBQW5GO0FBQXNGLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBQThFLElBQUlvRSxrQkFBSjtBQUF1QnRFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtCQUFaLEVBQTRDO0FBQUNxRSxvQkFBa0IsQ0FBQ3BFLENBQUQsRUFBRztBQUFDb0Usc0JBQWtCLEdBQUNwRSxDQUFuQjtBQUFxQjs7QUFBNUMsQ0FBNUMsRUFBMEYsQ0FBMUY7QUFNblYsTUFBTTZkLGFBQWEsR0FBRyxFQUF0QjtBQUVBaGUsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCx3QkFBc0IsVUFBU3NJLElBQVQsRUFBZTZDLFNBQWYsRUFBeUI7QUFDM0MsU0FBS2pMLE9BQUw7QUFDQW9JLFFBQUksR0FBR0EsSUFBSSxDQUFDNFUsV0FBTCxFQUFQO0FBQ0EsUUFBSTFkLEdBQUcsR0FBR0csR0FBRyxHQUFFLE9BQUwsR0FBYTJJLElBQXZCO0FBQ0EsUUFBSWxJLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjtBQUNBLFFBQUkyZCxFQUFFLEdBQUc5YyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFUO0FBRUFULFdBQU8sQ0FBQ0MsR0FBUixDQUFZdUksSUFBWjtBQUVBNlUsTUFBRSxDQUFDOVgsTUFBSCxHQUFZeUUsUUFBUSxDQUFDcVQsRUFBRSxDQUFDOVgsTUFBSixDQUFwQixDQVQyQyxDQVczQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBLFFBQUkrWCxJQUFJLEdBQUczWixZQUFZLENBQUNnRyxNQUFiLENBQW9CMFQsRUFBcEIsQ0FBWDs7QUFDQSxRQUFJQyxJQUFKLEVBQVM7QUFDTCxhQUFPQSxJQUFQO0FBQ0gsS0FGRCxNQUdLLE9BQU8sS0FBUDtBQUNSLEdBOURVO0FBK0RYLGlDQUErQixVQUFTbmQsT0FBVCxFQUFrQm9GLE1BQWxCLEVBQXlCO0FBQ3BEO0FBQ0EsV0FBTzVCLFlBQVksQ0FBQ3NCLElBQWIsQ0FBa0I7QUFDckJ4RCxTQUFHLEVBQUUsQ0FBQztBQUFDNlgsWUFBSSxFQUFFLENBQ1Q7QUFBQyx5QkFBZTtBQUFoQixTQURTLEVBRVQ7QUFBQyxtQ0FBeUI7QUFBMUIsU0FGUyxFQUdUO0FBQUMscUNBQTJCblo7QUFBNUIsU0FIUztBQUFQLE9BQUQsRUFJRDtBQUFDbVosWUFBSSxFQUFDLENBQ047QUFBQyxtQ0FBeUI7QUFBMUIsU0FETSxFQUVOO0FBQUMscUNBQTJCO0FBQTVCLFNBRk0sRUFHTjtBQUFDLG1DQUF5QjtBQUExQixTQUhNLEVBSU47QUFBQyxxQ0FBMkJuWjtBQUE1QixTQUpNO0FBQU4sT0FKQyxFQVNEO0FBQUNtWixZQUFJLEVBQUMsQ0FDTjtBQUFDLHlCQUFlO0FBQWhCLFNBRE0sRUFFTjtBQUFDLG1DQUF5QjtBQUExQixTQUZNLEVBR047QUFBQyxxQ0FBMkJuWjtBQUE1QixTQUhNO0FBQU4sT0FUQyxFQWFEO0FBQUNtWixZQUFJLEVBQUMsQ0FDTjtBQUFDLHlCQUFlO0FBQWhCLFNBRE0sRUFFTjtBQUFDLG1DQUF5QjtBQUExQixTQUZNLEVBR047QUFBQyxxQ0FBMkJuWjtBQUE1QixTQUhNO0FBQU4sT0FiQyxFQWlCRDtBQUFDbVosWUFBSSxFQUFDLENBQ047QUFBQyx5QkFBZTtBQUFoQixTQURNLEVBRU47QUFBQyxtQ0FBeUI7QUFBMUIsU0FGTSxFQUdOO0FBQUMscUNBQTJCblo7QUFBNUIsU0FITTtBQUFOLE9BakJDLENBRGdCO0FBdUJyQixjQUFRO0FBQUNrSyxlQUFPLEVBQUU7QUFBVixPQXZCYTtBQXdCckI5RSxZQUFNLEVBQUM7QUFBQ2dZLFdBQUcsRUFBQ2hZO0FBQUw7QUF4QmMsS0FBbEIsRUF5QlA7QUFBQzJCLFVBQUksRUFBQztBQUFDM0IsY0FBTSxFQUFDLENBQUM7QUFBVCxPQUFOO0FBQ0k0QixXQUFLLEVBQUU7QUFEWCxLQXpCTyxFQTJCTGhDLEtBM0JLLEVBQVA7QUE0QkgsR0E3RlU7QUE4RlgsMkJBQXlCLFVBQVNoRixPQUFULEVBQThCO0FBQUEsUUFBWjBOLE1BQVksdUVBQUwsSUFBSztBQUNuRDtBQUNBLFFBQUl0TSxTQUFKO0FBQ0EsUUFBSSxDQUFDc00sTUFBTCxFQUNJQSxNQUFNLEdBQUc7QUFBQzFOLGFBQU8sRUFBQyxDQUFUO0FBQVlzTSxpQkFBVyxFQUFDLENBQXhCO0FBQTJCL0ssc0JBQWdCLEVBQUMsQ0FBNUM7QUFBK0NDLHVCQUFpQixFQUFDO0FBQWpFLEtBQVQ7O0FBQ0osUUFBSXhCLE9BQU8sQ0FBQ3FkLFFBQVIsQ0FBaUJyZSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QnFYLG1CQUF4QyxDQUFKLEVBQWlFO0FBQzdEO0FBQ0FsYyxlQUFTLEdBQUcvQixVQUFVLENBQUNnQyxPQUFYLENBQW1CO0FBQUNFLHdCQUFnQixFQUFDdkI7QUFBbEIsT0FBbkIsRUFBK0M7QUFBQzBOO0FBQUQsT0FBL0MsQ0FBWjtBQUNILEtBSEQsTUFJSyxJQUFJMU4sT0FBTyxDQUFDcWQsUUFBUixDQUFpQnJlLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCc1gsbUJBQXhDLENBQUosRUFBaUU7QUFDbEU7QUFDQW5jLGVBQVMsR0FBRy9CLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQ0cseUJBQWlCLEVBQUN4QjtBQUFuQixPQUFuQixFQUFnRDtBQUFDME47QUFBRCxPQUFoRCxDQUFaO0FBQ0gsS0FISSxNQUlBLElBQUkxTixPQUFPLENBQUNlLE1BQVIsS0FBbUJpYyxhQUF2QixFQUFzQztBQUN2QzViLGVBQVMsR0FBRy9CLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQ3JCLGVBQU8sRUFBQ0E7QUFBVCxPQUFuQixFQUFzQztBQUFDME47QUFBRCxPQUF0QyxDQUFaO0FBQ0g7O0FBQ0QsUUFBSXRNLFNBQUosRUFBYztBQUNWLGFBQU9BLFNBQVA7QUFDSDs7QUFDRCxXQUFPLEtBQVA7QUFFSDtBQW5IVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDUkEsSUFBSXBDLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXFFLFlBQUo7QUFBaUJ2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQkFBWixFQUFpQztBQUFDc0UsY0FBWSxDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxnQkFBWSxHQUFDckUsQ0FBYjtBQUFlOztBQUFoQyxDQUFqQyxFQUFtRSxDQUFuRTtBQUFzRSxJQUFJOEQsU0FBSjtBQUFjaEUsTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQytELFdBQVMsQ0FBQzlELENBQUQsRUFBRztBQUFDOEQsYUFBUyxHQUFDOUQsQ0FBVjtBQUFZOztBQUExQixDQUFyQyxFQUFpRSxDQUFqRTtBQUtyS21RLGdCQUFnQixDQUFDLG1CQUFELEVBQXNCLFlBQW9CO0FBQUEsTUFBWHRJLEtBQVcsdUVBQUgsRUFBRztBQUN0RCxTQUFPO0FBQ0hsQyxRQUFJLEdBQUU7QUFDRixhQUFPdEIsWUFBWSxDQUFDc0IsSUFBYixDQUFrQixFQUFsQixFQUFxQjtBQUFDaUMsWUFBSSxFQUFDO0FBQUMzQixnQkFBTSxFQUFDLENBQUM7QUFBVCxTQUFOO0FBQW1CNEIsYUFBSyxFQUFDQTtBQUF6QixPQUFyQixDQUFQO0FBQ0gsS0FIRTs7QUFJSHVJLFlBQVEsRUFBRSxDQUNOO0FBQ0l6SyxVQUFJLENBQUNvWSxFQUFELEVBQUk7QUFDSixlQUFPamEsU0FBUyxDQUFDNkIsSUFBVixDQUNIO0FBQUNNLGdCQUFNLEVBQUM4WCxFQUFFLENBQUM5WDtBQUFYLFNBREcsRUFFSDtBQUFDc0ksZ0JBQU0sRUFBQztBQUFDdkwsZ0JBQUksRUFBQyxDQUFOO0FBQVNpRCxrQkFBTSxFQUFDO0FBQWhCO0FBQVIsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FETTtBQUpQLEdBQVA7QUFlSCxDQWhCZSxDQUFoQjtBQWtCQWtLLGdCQUFnQixDQUFDLHdCQUFELEVBQTJCLFVBQVNrTyxnQkFBVCxFQUEyQkMsZ0JBQTNCLEVBQXVEO0FBQUEsTUFBVnpXLEtBQVUsdUVBQUosR0FBSTtBQUM5RixNQUFJMFcsS0FBSyxHQUFHLEVBQVo7O0FBQ0EsTUFBSUYsZ0JBQWdCLElBQUlDLGdCQUF4QixFQUF5QztBQUNyQ0MsU0FBSyxHQUFHO0FBQUNwYyxTQUFHLEVBQUMsQ0FBQztBQUFDLG1DQUEwQmtjO0FBQTNCLE9BQUQsRUFBK0M7QUFBQyxtQ0FBMEJDO0FBQTNCLE9BQS9DO0FBQUwsS0FBUjtBQUNIOztBQUVELE1BQUksQ0FBQ0QsZ0JBQUQsSUFBcUJDLGdCQUF6QixFQUEwQztBQUN0Q0MsU0FBSyxHQUFHO0FBQUMsaUNBQTBCRDtBQUEzQixLQUFSO0FBQ0g7O0FBRUQsU0FBTztBQUNIM1ksUUFBSSxHQUFFO0FBQ0YsYUFBT3RCLFlBQVksQ0FBQ3NCLElBQWIsQ0FBa0I0WSxLQUFsQixFQUF5QjtBQUFDM1csWUFBSSxFQUFDO0FBQUMzQixnQkFBTSxFQUFDLENBQUM7QUFBVCxTQUFOO0FBQW1CNEIsYUFBSyxFQUFDQTtBQUF6QixPQUF6QixDQUFQO0FBQ0gsS0FIRTs7QUFJSHVJLFlBQVEsRUFBQyxDQUNMO0FBQ0l6SyxVQUFJLENBQUNvWSxFQUFELEVBQUk7QUFDSixlQUFPamEsU0FBUyxDQUFDNkIsSUFBVixDQUNIO0FBQUNNLGdCQUFNLEVBQUM4WCxFQUFFLENBQUM5WDtBQUFYLFNBREcsRUFFSDtBQUFDc0ksZ0JBQU0sRUFBQztBQUFDdkwsZ0JBQUksRUFBQyxDQUFOO0FBQVNpRCxrQkFBTSxFQUFDO0FBQWhCO0FBQVIsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FESztBQUpOLEdBQVA7QUFlSCxDQXpCZSxDQUFoQjtBQTJCQWtLLGdCQUFnQixDQUFDLHNCQUFELEVBQXlCLFVBQVNqSCxJQUFULEVBQWM7QUFDbkQsU0FBTztBQUNIdkQsUUFBSSxHQUFFO0FBQ0YsYUFBT3RCLFlBQVksQ0FBQ3NCLElBQWIsQ0FBa0I7QUFBQ3dSLGNBQU0sRUFBQ2pPO0FBQVIsT0FBbEIsQ0FBUDtBQUNILEtBSEU7O0FBSUhrSCxZQUFRLEVBQUUsQ0FDTjtBQUNJekssVUFBSSxDQUFDb1ksRUFBRCxFQUFJO0FBQ0osZUFBT2phLFNBQVMsQ0FBQzZCLElBQVYsQ0FDSDtBQUFDTSxnQkFBTSxFQUFDOFgsRUFBRSxDQUFDOVg7QUFBWCxTQURHLEVBRUg7QUFBQ3NJLGdCQUFNLEVBQUM7QUFBQ3ZMLGdCQUFJLEVBQUMsQ0FBTjtBQUFTaUQsa0JBQU0sRUFBQztBQUFoQjtBQUFSLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE07QUFKUCxHQUFQO0FBZUgsQ0FoQmUsQ0FBaEI7QUFrQkFrSyxnQkFBZ0IsQ0FBQyxxQkFBRCxFQUF3QixVQUFTbEssTUFBVCxFQUFnQjtBQUNwRCxTQUFPO0FBQ0hOLFFBQUksR0FBRTtBQUNGLGFBQU90QixZQUFZLENBQUNzQixJQUFiLENBQWtCO0FBQUNNLGNBQU0sRUFBQ0E7QUFBUixPQUFsQixDQUFQO0FBQ0gsS0FIRTs7QUFJSG1LLFlBQVEsRUFBRSxDQUNOO0FBQ0l6SyxVQUFJLENBQUNvWSxFQUFELEVBQUk7QUFDSixlQUFPamEsU0FBUyxDQUFDNkIsSUFBVixDQUNIO0FBQUNNLGdCQUFNLEVBQUM4WCxFQUFFLENBQUM5WDtBQUFYLFNBREcsRUFFSDtBQUFDc0ksZ0JBQU0sRUFBQztBQUFDdkwsZ0JBQUksRUFBQyxDQUFOO0FBQVNpRCxrQkFBTSxFQUFDO0FBQWhCO0FBQVIsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FETTtBQUpQLEdBQVA7QUFlSCxDQWhCZSxDQUFoQixDOzs7Ozs7Ozs7OztBQ3BFQW5HLE1BQU0sQ0FBQ3VRLE1BQVAsQ0FBYztBQUFDaE0sY0FBWSxFQUFDLE1BQUlBO0FBQWxCLENBQWQ7QUFBK0MsSUFBSWlNLEtBQUo7QUFBVXhRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3VRLE9BQUssQ0FBQ3RRLENBQUQsRUFBRztBQUFDc1EsU0FBSyxHQUFDdFEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJOEQsU0FBSjtBQUFjaEUsTUFBTSxDQUFDQyxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQytELFdBQVMsQ0FBQzlELENBQUQsRUFBRztBQUFDOEQsYUFBUyxHQUFDOUQsQ0FBVjtBQUFZOztBQUExQixDQUFsQyxFQUE4RCxDQUE5RDtBQUFpRSxJQUFJd2UsTUFBSjtBQUFXMWUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0JBQVosRUFBNEM7QUFBQ3llLFFBQU0sQ0FBQ3hlLENBQUQsRUFBRztBQUFDd2UsVUFBTSxHQUFDeGUsQ0FBUDtBQUFTOztBQUFwQixDQUE1QyxFQUFrRSxDQUFsRTtBQUk5TCxNQUFNcUUsWUFBWSxHQUFHLElBQUlpTSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsY0FBckIsQ0FBckI7QUFFUGxNLFlBQVksQ0FBQ21NLE9BQWIsQ0FBcUI7QUFDakJ4SyxPQUFLLEdBQUU7QUFDSCxXQUFPbEMsU0FBUyxDQUFDNUIsT0FBVixDQUFrQjtBQUFDK0QsWUFBTSxFQUFDLEtBQUtBO0FBQWIsS0FBbEIsQ0FBUDtBQUNIOztBQUhnQixDQUFyQixFOzs7Ozs7Ozs7OztBQ05BLElBQUlwRyxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlxRSxZQUFKO0FBQWlCdkUsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ3NFLGNBQVksQ0FBQ3JFLENBQUQsRUFBRztBQUFDcUUsZ0JBQVksR0FBQ3JFLENBQWI7QUFBZTs7QUFBaEMsQ0FBakQsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSThELFNBQUo7QUFBY2hFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdCQUFaLEVBQXFDO0FBQUMrRCxXQUFTLENBQUM5RCxDQUFELEVBQUc7QUFBQzhELGFBQVMsR0FBQzlELENBQVY7QUFBWTs7QUFBMUIsQ0FBckMsRUFBaUUsQ0FBakU7QUFBb0UsSUFBSXVXLFdBQUo7QUFBZ0J6VyxNQUFNLENBQUNDLElBQVAsQ0FBWSxrQ0FBWixFQUErQztBQUFDd1csYUFBVyxDQUFDdlcsQ0FBRCxFQUFHO0FBQUN1VyxlQUFXLEdBQUN2VyxDQUFaO0FBQWM7O0FBQTlCLENBQS9DLEVBQStFLENBQS9FO0FBS3pRSCxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLHdDQUFzQyxVQUFTQyxPQUFULEVBQWlCO0FBQ25EO0FBQ0EsUUFBSWtkLEVBQUUsR0FBRzFaLFlBQVksQ0FBQ25DLE9BQWIsQ0FBcUI7QUFBQzhYLFVBQUksRUFBQyxDQUNoQztBQUFDLGdEQUF1Q25aO0FBQXhDLE9BRGdDLEVBRWhDO0FBQUMsNkJBQW9CO0FBQXJCLE9BRmdDLEVBR2hDO0FBQUNrVyxZQUFJLEVBQUM7QUFBQ2hNLGlCQUFPLEVBQUM7QUFBVDtBQUFOLE9BSGdDO0FBQU4sS0FBckIsQ0FBVDs7QUFNQSxRQUFJZ1QsRUFBSixFQUFPO0FBQ0gsVUFBSS9YLEtBQUssR0FBR2xDLFNBQVMsQ0FBQzVCLE9BQVYsQ0FBa0I7QUFBQytELGNBQU0sRUFBQzhYLEVBQUUsQ0FBQzlYO0FBQVgsT0FBbEIsQ0FBWjs7QUFDQSxVQUFJRCxLQUFKLEVBQVU7QUFDTixlQUFPQSxLQUFLLENBQUNoRCxJQUFiO0FBQ0g7QUFDSixLQUxELE1BTUk7QUFDQTtBQUNBLGFBQU8sS0FBUDtBQUNIO0FBQ0osR0FuQlU7O0FBb0JYO0FBQ0EsaUNBQStCbkMsT0FBL0IsRUFBdUM7QUFDbkMsUUFBSVQsR0FBRyxHQUFHRyxHQUFHLEdBQUcsc0JBQU4sR0FBNkJNLE9BQTdCLEdBQXFDLGNBQS9DOztBQUVBLFFBQUc7QUFDQyxVQUFJZ0IsV0FBVyxHQUFHNUIsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBbEI7O0FBQ0EsVUFBSXlCLFdBQVcsQ0FBQ3JCLFVBQVosSUFBMEIsR0FBOUIsRUFBa0M7QUFDOUJxQixtQkFBVyxHQUFHWixJQUFJLENBQUNDLEtBQUwsQ0FBV1csV0FBVyxDQUFDVixPQUF2QixFQUFnQ0MsTUFBOUM7QUFDQVMsbUJBQVcsQ0FBQ2dCLE9BQVosQ0FBb0IsQ0FBQ1MsVUFBRCxFQUFhQyxDQUFiLEtBQW1CO0FBQ25DLGNBQUkxQixXQUFXLENBQUMwQixDQUFELENBQVgsSUFBa0IxQixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBckMsRUFDSVosV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLENBQWVkLE1BQWYsR0FBd0JDLFVBQVUsQ0FBQ2IsV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLENBQWVkLE1BQWhCLENBQWxDO0FBQ1AsU0FIRDtBQUtBLGVBQU9aLFdBQVA7QUFDSDs7QUFBQTtBQUNKLEtBWEQsQ0FZQSxPQUFPcEIsQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSjs7QUF2Q1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ0xBLElBQUlaLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBL0IsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSWlFLGdCQUFKO0FBQXFCbkUsTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ2tFLGtCQUFnQixDQUFDakUsQ0FBRCxFQUFHO0FBQUNpRSxvQkFBZ0IsR0FBQ2pFLENBQWpCO0FBQW1COztBQUF4QyxDQUF2QyxFQUFpRixDQUFqRjtBQUFvRixJQUFJb0Usa0JBQUo7QUFBdUJ0RSxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQkFBWixFQUE0QztBQUFDcUUsb0JBQWtCLENBQUNwRSxDQUFELEVBQUc7QUFBQ29FLHNCQUFrQixHQUFDcEUsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQTVDLEVBQTBGLENBQTFGO0FBSy9RSCxNQUFNLENBQUNvVyxPQUFQLENBQWUsZ0JBQWYsRUFBaUMsWUFBbUU7QUFBQSxNQUF6RHJPLElBQXlELHVFQUFsRCxxQkFBa0Q7QUFBQSxNQUEzQjZXLFNBQTJCLHVFQUFmLENBQUMsQ0FBYztBQUFBLE1BQVhsUSxNQUFXLHVFQUFKLEVBQUk7QUFDaEcsU0FBT3JPLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0I7QUFBQ2lDLFFBQUksRUFBRTtBQUFDLE9BQUNBLElBQUQsR0FBUTZXO0FBQVQsS0FBUDtBQUE0QmxRLFVBQU0sRUFBRUE7QUFBcEMsR0FBcEIsQ0FBUDtBQUNILENBRkQ7QUFJQTRCLGdCQUFnQixDQUFDLHNCQUFELEVBQXdCO0FBQ3BDeEssTUFBSSxHQUFHO0FBQ0gsV0FBT3pGLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0IsRUFBaEIsQ0FBUDtBQUNILEdBSG1DOztBQUlwQ3lLLFVBQVEsRUFBRSxDQUNOO0FBQ0l6SyxRQUFJLENBQUMrWSxHQUFELEVBQU07QUFDTixhQUFPemEsZ0JBQWdCLENBQUMwQixJQUFqQixDQUNIO0FBQUU5RSxlQUFPLEVBQUU2ZCxHQUFHLENBQUM3ZDtBQUFmLE9BREcsRUFFSDtBQUFFK0csWUFBSSxFQUFFO0FBQUMzQixnQkFBTSxFQUFFO0FBQVQsU0FBUjtBQUFxQjRCLGFBQUssRUFBRTtBQUE1QixPQUZHLENBQVA7QUFJSDs7QUFOTCxHQURNO0FBSjBCLENBQXhCLENBQWhCO0FBZ0JBaEksTUFBTSxDQUFDb1csT0FBUCxDQUFlLHlCQUFmLEVBQTBDLFlBQVU7QUFDaEQsU0FBTy9WLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0I7QUFDbkI2QixVQUFNLEVBQUUsQ0FEVztBQUVuQjZGLFVBQU0sRUFBQztBQUZZLEdBQWhCLEVBR0w7QUFDRXpGLFFBQUksRUFBQztBQUNEc0Qsa0JBQVksRUFBQyxDQUFDO0FBRGIsS0FEUDtBQUlFcUQsVUFBTSxFQUFDO0FBQ0gxTixhQUFPLEVBQUUsQ0FETjtBQUVIc00saUJBQVcsRUFBQyxDQUZUO0FBR0hqQyxrQkFBWSxFQUFDLENBSFY7QUFJSGtDLGlCQUFXLEVBQUM7QUFKVDtBQUpULEdBSEssQ0FBUDtBQWVILENBaEJEO0FBa0JBK0MsZ0JBQWdCLENBQUMsbUJBQUQsRUFBc0IsVUFBU3RQLE9BQVQsRUFBaUI7QUFDbkQsTUFBSXNaLE9BQU8sR0FBRztBQUFDdFosV0FBTyxFQUFDQTtBQUFULEdBQWQ7O0FBQ0EsTUFBSUEsT0FBTyxDQUFDd0UsT0FBUixDQUFnQnhGLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCcVgsbUJBQXZDLEtBQStELENBQUMsQ0FBcEUsRUFBc0U7QUFDbEVoRSxXQUFPLEdBQUc7QUFBQy9YLHNCQUFnQixFQUFDdkI7QUFBbEIsS0FBVjtBQUNIOztBQUNELFNBQU87QUFDSDhFLFFBQUksR0FBRTtBQUNGLGFBQU96RixVQUFVLENBQUN5RixJQUFYLENBQWdCd1UsT0FBaEIsQ0FBUDtBQUNILEtBSEU7O0FBSUgvSixZQUFRLEVBQUUsQ0FDTjtBQUNJekssVUFBSSxDQUFDK1ksR0FBRCxFQUFLO0FBQ0wsZUFBT3RhLGtCQUFrQixDQUFDdUIsSUFBbkIsQ0FDSDtBQUFDOUUsaUJBQU8sRUFBQzZkLEdBQUcsQ0FBQzdkO0FBQWIsU0FERyxFQUVIO0FBQUMrRyxjQUFJLEVBQUM7QUFBQzNCLGtCQUFNLEVBQUMsQ0FBQztBQUFULFdBQU47QUFBbUI0QixlQUFLLEVBQUM7QUFBekIsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FETSxFQVNOO0FBQ0lsQyxVQUFJLENBQUMrWSxHQUFELEVBQU07QUFDTixlQUFPemEsZ0JBQWdCLENBQUMwQixJQUFqQixDQUNIO0FBQUU5RSxpQkFBTyxFQUFFNmQsR0FBRyxDQUFDN2Q7QUFBZixTQURHLEVBRUg7QUFBRStHLGNBQUksRUFBRTtBQUFDM0Isa0JBQU0sRUFBRSxDQUFDO0FBQVYsV0FBUjtBQUFzQjRCLGVBQUssRUFBRWhJLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCQztBQUFwRCxTQUZHLENBQVA7QUFJSDs7QUFOTCxLQVRNO0FBSlAsR0FBUDtBQXVCSCxDQTVCZSxDQUFoQixDOzs7Ozs7Ozs7OztBQzNDQWpILE1BQU0sQ0FBQ3VRLE1BQVAsQ0FBYztBQUFDblEsWUFBVSxFQUFDLE1BQUlBO0FBQWhCLENBQWQ7QUFBMkMsSUFBSW9RLEtBQUo7QUFBVXhRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3VRLE9BQUssQ0FBQ3RRLENBQUQsRUFBRztBQUFDc1EsU0FBSyxHQUFDdFEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJaUUsZ0JBQUo7QUFBcUJuRSxNQUFNLENBQUNDLElBQVAsQ0FBWSx1QkFBWixFQUFvQztBQUFDa0Usa0JBQWdCLENBQUNqRSxDQUFELEVBQUc7QUFBQ2lFLG9CQUFnQixHQUFDakUsQ0FBakI7QUFBbUI7O0FBQXhDLENBQXBDLEVBQThFLENBQTlFO0FBQWlGLElBQUlvRSxrQkFBSjtBQUF1QnRFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDRCQUFaLEVBQXlDO0FBQUNxRSxvQkFBa0IsQ0FBQ3BFLENBQUQsRUFBRztBQUFDb0Usc0JBQWtCLEdBQUNwRSxDQUFuQjtBQUFxQjs7QUFBNUMsQ0FBekMsRUFBdUYsQ0FBdkY7QUFJN04sTUFBTUUsVUFBVSxHQUFHLElBQUlvUSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsWUFBckIsQ0FBbkI7QUFFUHJRLFVBQVUsQ0FBQ3NRLE9BQVgsQ0FBbUI7QUFDZm1PLFdBQVMsR0FBRTtBQUNQLFdBQU8xYSxnQkFBZ0IsQ0FBQy9CLE9BQWpCLENBQXlCO0FBQUNyQixhQUFPLEVBQUMsS0FBS0E7QUFBZCxLQUF6QixDQUFQO0FBQ0gsR0FIYzs7QUFJZitkLFNBQU8sR0FBRTtBQUNMLFdBQU94YSxrQkFBa0IsQ0FBQ3VCLElBQW5CLENBQXdCO0FBQUM5RSxhQUFPLEVBQUMsS0FBS0E7QUFBZCxLQUF4QixFQUFnRDtBQUFDK0csVUFBSSxFQUFDO0FBQUMzQixjQUFNLEVBQUMsQ0FBQztBQUFULE9BQU47QUFBbUI0QixXQUFLLEVBQUM7QUFBekIsS0FBaEQsRUFBOEVoQyxLQUE5RSxFQUFQO0FBQ0g7O0FBTmMsQ0FBbkIsRSxDQVFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0JBL0YsTUFBTSxDQUFDdVEsTUFBUCxDQUFjO0FBQUNqTSxvQkFBa0IsRUFBQyxNQUFJQTtBQUF4QixDQUFkO0FBQTJELElBQUlrTSxLQUFKO0FBQVV4USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN1USxPQUFLLENBQUN0USxDQUFELEVBQUc7QUFBQ3NRLFNBQUssR0FBQ3RRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFOUQsTUFBTW9FLGtCQUFrQixHQUFHLElBQUlrTSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsc0JBQXJCLENBQTNCLEM7Ozs7Ozs7Ozs7O0FDRlB6USxNQUFNLENBQUN1USxNQUFQLENBQWM7QUFBQy9MLFdBQVMsRUFBQyxNQUFJQTtBQUFmLENBQWQ7QUFBeUMsSUFBSWdNLEtBQUo7QUFBVXhRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3VRLE9BQUssQ0FBQ3RRLENBQUQsRUFBRztBQUFDc1EsU0FBSyxHQUFDdFEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUU1QyxNQUFNc0UsU0FBUyxHQUFHLElBQUlnTSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsV0FBckIsQ0FBbEIsQzs7Ozs7Ozs7Ozs7QUNGUHpRLE1BQU0sQ0FBQ3VRLE1BQVAsQ0FBYztBQUFDck0sZUFBYSxFQUFDLE1BQUlBO0FBQW5CLENBQWQ7QUFBaUQsSUFBSXNNLEtBQUo7QUFBVXhRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3VRLE9BQUssQ0FBQ3RRLENBQUQsRUFBRztBQUFDc1EsU0FBSyxHQUFDdFEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUVwRCxNQUFNZ0UsYUFBYSxHQUFHLElBQUlzTSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsZ0JBQXJCLENBQXRCLEM7Ozs7Ozs7Ozs7O0FDRlA7QUFDQSx3Qzs7Ozs7Ozs7Ozs7QUNEQSxJQUFJek0sU0FBSjtBQUFjaEUsTUFBTSxDQUFDQyxJQUFQLENBQVksNEJBQVosRUFBeUM7QUFBQytELFdBQVMsQ0FBQzlELENBQUQsRUFBRztBQUFDOEQsYUFBUyxHQUFDOUQsQ0FBVjtBQUFZOztBQUExQixDQUF6QyxFQUFxRSxDQUFyRTtBQUF3RSxJQUFJeVgsU0FBSjtBQUFjM1gsTUFBTSxDQUFDQyxJQUFQLENBQVksa0NBQVosRUFBK0M7QUFBQzBYLFdBQVMsQ0FBQ3pYLENBQUQsRUFBRztBQUFDeVgsYUFBUyxHQUFDelgsQ0FBVjtBQUFZOztBQUExQixDQUEvQyxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJaUUsZ0JBQUosRUFBcUJDLFNBQXJCLEVBQStCc1YsaUJBQS9CLEVBQWlEQyxZQUFqRCxFQUE4REosV0FBOUQsRUFBMEVDLG9CQUExRTtBQUErRnhaLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDhCQUFaLEVBQTJDO0FBQUNrRSxrQkFBZ0IsQ0FBQ2pFLENBQUQsRUFBRztBQUFDaUUsb0JBQWdCLEdBQUNqRSxDQUFqQjtBQUFtQixHQUF4Qzs7QUFBeUNrRSxXQUFTLENBQUNsRSxDQUFELEVBQUc7QUFBQ2tFLGFBQVMsR0FBQ2xFLENBQVY7QUFBWSxHQUFsRTs7QUFBbUV3WixtQkFBaUIsQ0FBQ3haLENBQUQsRUFBRztBQUFDd1oscUJBQWlCLEdBQUN4WixDQUFsQjtBQUFvQixHQUE1Rzs7QUFBNkd5WixjQUFZLENBQUN6WixDQUFELEVBQUc7QUFBQ3laLGdCQUFZLEdBQUN6WixDQUFiO0FBQWUsR0FBNUk7O0FBQTZJcVosYUFBVyxDQUFDclosQ0FBRCxFQUFHO0FBQUNxWixlQUFXLEdBQUNyWixDQUFaO0FBQWMsR0FBMUs7O0FBQTJLc1osc0JBQW9CLENBQUN0WixDQUFELEVBQUc7QUFBQ3NaLHdCQUFvQixHQUFDdFosQ0FBckI7QUFBdUI7O0FBQTFOLENBQTNDLEVBQXVRLENBQXZRO0FBQTBRLElBQUlxRSxZQUFKO0FBQWlCdkUsTUFBTSxDQUFDQyxJQUFQLENBQVksd0NBQVosRUFBcUQ7QUFBQ3NFLGNBQVksQ0FBQ3JFLENBQUQsRUFBRztBQUFDcUUsZ0JBQVksR0FBQ3JFLENBQWI7QUFBZTs7QUFBaEMsQ0FBckQsRUFBdUYsQ0FBdkY7QUFBMEYsSUFBSWdFLGFBQUo7QUFBa0JsRSxNQUFNLENBQUNDLElBQVAsQ0FBWSw0Q0FBWixFQUF5RDtBQUFDaUUsZUFBYSxDQUFDaEUsQ0FBRCxFQUFHO0FBQUNnRSxpQkFBYSxHQUFDaEUsQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBekQsRUFBNkYsQ0FBN0Y7QUFBZ0csSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBakQsRUFBK0UsQ0FBL0U7QUFBa0YsSUFBSW9FLGtCQUFKO0FBQXVCdEUsTUFBTSxDQUFDQyxJQUFQLENBQVksbUNBQVosRUFBZ0Q7QUFBQ3FFLG9CQUFrQixDQUFDcEUsQ0FBRCxFQUFHO0FBQUNvRSxzQkFBa0IsR0FBQ3BFLENBQW5CO0FBQXFCOztBQUE1QyxDQUFoRCxFQUE4RixDQUE5RjtBQUFpRyxJQUFJc0UsU0FBSjtBQUFjeEUsTUFBTSxDQUFDQyxJQUFQLENBQVksa0NBQVosRUFBK0M7QUFBQ3VFLFdBQVMsQ0FBQ3RFLENBQUQsRUFBRztBQUFDc0UsYUFBUyxHQUFDdEUsQ0FBVjtBQUFZOztBQUExQixDQUEvQyxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJZ1csU0FBSjtBQUFjbFcsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ2lXLFdBQVMsQ0FBQ2hXLENBQUQsRUFBRztBQUFDZ1csYUFBUyxHQUFDaFcsQ0FBVjtBQUFZOztBQUExQixDQUFqRCxFQUE2RSxDQUE3RTtBQUFnRixJQUFJMFEsV0FBSjtBQUFnQjVRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUMyUSxhQUFXLENBQUMxUSxDQUFELEVBQUc7QUFBQzBRLGVBQVcsR0FBQzFRLENBQVo7QUFBYzs7QUFBOUIsQ0FBdkMsRUFBdUUsQ0FBdkU7QUFZM3BDMFEsV0FBVyxDQUFDbEssYUFBWixHQUE0QnFZLFdBQTVCLENBQXdDO0FBQUM1WSxRQUFNLEVBQUUsQ0FBQztBQUFWLENBQXhDLEVBQXFEO0FBQUM2WSxRQUFNLEVBQUM7QUFBUixDQUFyRDtBQUVBaGIsU0FBUyxDQUFDMEMsYUFBVixHQUEwQnFZLFdBQTFCLENBQXNDO0FBQUM1WSxRQUFNLEVBQUUsQ0FBQztBQUFWLENBQXRDLEVBQW1EO0FBQUM2WSxRQUFNLEVBQUM7QUFBUixDQUFuRDtBQUNBaGIsU0FBUyxDQUFDMEMsYUFBVixHQUEwQnFZLFdBQTFCLENBQXNDO0FBQUNqWixpQkFBZSxFQUFDO0FBQWpCLENBQXRDO0FBRUF0QixTQUFTLENBQUNrQyxhQUFWLEdBQTBCcVksV0FBMUIsQ0FBc0M7QUFBQzVZLFFBQU0sRUFBRSxDQUFDO0FBQVYsQ0FBdEM7QUFFQXdSLFNBQVMsQ0FBQ2pSLGFBQVYsR0FBMEJxWSxXQUExQixDQUFzQztBQUFDaEgsWUFBVSxFQUFFO0FBQWIsQ0FBdEMsRUFBdUQ7QUFBQ2lILFFBQU0sRUFBQztBQUFSLENBQXZEO0FBRUE3YSxnQkFBZ0IsQ0FBQ3VDLGFBQWpCLEdBQWlDcVksV0FBakMsQ0FBNkM7QUFBQ2hlLFNBQU8sRUFBQyxDQUFUO0FBQVdvRixRQUFNLEVBQUUsQ0FBQztBQUFwQixDQUE3QyxFQUFxRTtBQUFDNlksUUFBTSxFQUFDO0FBQVIsQ0FBckU7QUFDQTdhLGdCQUFnQixDQUFDdUMsYUFBakIsR0FBaUNxWSxXQUFqQyxDQUE2QztBQUFDaGUsU0FBTyxFQUFDLENBQVQ7QUFBV29LLFFBQU0sRUFBQyxDQUFsQjtBQUFxQmhGLFFBQU0sRUFBRSxDQUFDO0FBQTlCLENBQTdDO0FBRUEvQixTQUFTLENBQUNzQyxhQUFWLEdBQTBCcVksV0FBMUIsQ0FBc0M7QUFBQzVZLFFBQU0sRUFBRSxDQUFDO0FBQVYsQ0FBdEMsRUFBb0Q7QUFBQzZZLFFBQU0sRUFBQztBQUFSLENBQXBEO0FBRUFyRixZQUFZLENBQUNqVCxhQUFiLEdBQTZCcVksV0FBN0IsQ0FBeUM7QUFBQ3BPLFVBQVEsRUFBQyxDQUFWO0FBQWFtSSxPQUFLLEVBQUMsQ0FBbkI7QUFBc0JILFdBQVMsRUFBRSxDQUFDO0FBQWxDLENBQXpDO0FBQ0FnQixZQUFZLENBQUNqVCxhQUFiLEdBQTZCcVksV0FBN0IsQ0FBeUM7QUFBQ3BPLFVBQVEsRUFBQyxDQUFWO0FBQWErSixhQUFXLEVBQUMsQ0FBQztBQUExQixDQUF6QztBQUNBZixZQUFZLENBQUNqVCxhQUFiLEdBQTZCcVksV0FBN0IsQ0FBeUM7QUFBQ2pHLE9BQUssRUFBQyxDQUFQO0FBQVU0QixhQUFXLEVBQUMsQ0FBQztBQUF2QixDQUF6QztBQUNBZixZQUFZLENBQUNqVCxhQUFiLEdBQTZCcVksV0FBN0IsQ0FBeUM7QUFBQ2pHLE9BQUssRUFBQyxDQUFQO0FBQVVuSSxVQUFRLEVBQUMsQ0FBbkI7QUFBc0IrSixhQUFXLEVBQUMsQ0FBQztBQUFuQyxDQUF6QyxFQUFnRjtBQUFDc0UsUUFBTSxFQUFDO0FBQVIsQ0FBaEY7QUFFQXRGLGlCQUFpQixDQUFDaFQsYUFBbEIsR0FBa0NxWSxXQUFsQyxDQUE4QztBQUFDcE8sVUFBUSxFQUFDO0FBQVYsQ0FBOUM7QUFDQStJLGlCQUFpQixDQUFDaFQsYUFBbEIsR0FBa0NxWSxXQUFsQyxDQUE4QztBQUFDakcsT0FBSyxFQUFDO0FBQVAsQ0FBOUM7QUFDQVksaUJBQWlCLENBQUNoVCxhQUFsQixHQUFrQ3FZLFdBQWxDLENBQThDO0FBQUNwTyxVQUFRLEVBQUMsQ0FBVjtBQUFhbUksT0FBSyxFQUFDO0FBQW5CLENBQTlDLEVBQW9FO0FBQUNrRyxRQUFNLEVBQUM7QUFBUixDQUFwRTtBQUVBekYsV0FBVyxDQUFDN1MsYUFBWixHQUE0QnFZLFdBQTVCLENBQXdDO0FBQUN2ZCxNQUFJLEVBQUMsQ0FBTjtBQUFTbVYsV0FBUyxFQUFDLENBQUM7QUFBcEIsQ0FBeEMsRUFBK0Q7QUFBQ3FJLFFBQU0sRUFBQztBQUFSLENBQS9EO0FBQ0F4RixvQkFBb0IsQ0FBQzlTLGFBQXJCLEdBQXFDcVksV0FBckMsQ0FBaUQ7QUFBQ2paLGlCQUFlLEVBQUMsQ0FBakI7QUFBbUI2USxXQUFTLEVBQUMsQ0FBQztBQUE5QixDQUFqRCxFQUFrRjtBQUFDcUksUUFBTSxFQUFDO0FBQVIsQ0FBbEYsRSxDQUNBOztBQUVBemEsWUFBWSxDQUFDbUMsYUFBYixHQUE2QnFZLFdBQTdCLENBQXlDO0FBQUMxSCxRQUFNLEVBQUM7QUFBUixDQUF6QyxFQUFvRDtBQUFDMkgsUUFBTSxFQUFDO0FBQVIsQ0FBcEQ7QUFDQXphLFlBQVksQ0FBQ21DLGFBQWIsR0FBNkJxWSxXQUE3QixDQUF5QztBQUFDNVksUUFBTSxFQUFDLENBQUM7QUFBVCxDQUF6QyxFLENBQ0E7O0FBQ0E1QixZQUFZLENBQUNtQyxhQUFiLEdBQTZCcVksV0FBN0IsQ0FBeUM7QUFBQywyQkFBd0I7QUFBekIsQ0FBekM7QUFDQXhhLFlBQVksQ0FBQ21DLGFBQWIsR0FBNkJxWSxXQUE3QixDQUF5QztBQUFDLDZCQUEwQjtBQUEzQixDQUF6QztBQUVBN2EsYUFBYSxDQUFDd0MsYUFBZCxHQUE4QnFZLFdBQTlCLENBQTBDO0FBQUNwVSxjQUFZLEVBQUMsQ0FBQztBQUFmLENBQTFDO0FBRUF2SyxVQUFVLENBQUNzRyxhQUFYLEdBQTJCcVksV0FBM0IsQ0FBdUM7QUFBQ2hlLFNBQU8sRUFBQztBQUFULENBQXZDLEVBQW1EO0FBQUNpZSxRQUFNLEVBQUMsSUFBUjtBQUFjQyx5QkFBdUIsRUFBRTtBQUFFbGUsV0FBTyxFQUFFO0FBQUVrSyxhQUFPLEVBQUU7QUFBWDtBQUFYO0FBQXZDLENBQW5EO0FBQ0E3SyxVQUFVLENBQUNzRyxhQUFYLEdBQTJCcVksV0FBM0IsQ0FBdUM7QUFBQ3hXLGtCQUFnQixFQUFDO0FBQWxCLENBQXZDLEVBQTREO0FBQUN5VyxRQUFNLEVBQUM7QUFBUixDQUE1RDtBQUNBNWUsVUFBVSxDQUFDc0csYUFBWCxHQUEyQnFZLFdBQTNCLENBQXVDO0FBQUMsbUJBQWdCO0FBQWpCLENBQXZDLEVBQTJEO0FBQUNDLFFBQU0sRUFBQyxJQUFSO0FBQWNDLHlCQUF1QixFQUFFO0FBQUUscUJBQWlCO0FBQUVoVSxhQUFPLEVBQUU7QUFBWDtBQUFuQjtBQUF2QyxDQUEzRDtBQUVBM0csa0JBQWtCLENBQUNvQyxhQUFuQixHQUFtQ3FZLFdBQW5DLENBQStDO0FBQUNoZSxTQUFPLEVBQUMsQ0FBVDtBQUFXb0YsUUFBTSxFQUFDLENBQUM7QUFBbkIsQ0FBL0M7QUFDQTdCLGtCQUFrQixDQUFDb0MsYUFBbkIsR0FBbUNxWSxXQUFuQyxDQUErQztBQUFDdmQsTUFBSSxFQUFDO0FBQU4sQ0FBL0M7QUFFQTBVLFNBQVMsQ0FBQ3hQLGFBQVYsR0FBMEJxWSxXQUExQixDQUFzQztBQUFDM0ksaUJBQWUsRUFBQyxDQUFDO0FBQWxCLENBQXRDLEVBQTJEO0FBQUM0SSxRQUFNLEVBQUM7QUFBUixDQUEzRCxFOzs7Ozs7Ozs7OztBQ3REQWhmLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVo7QUFBeUJELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG1CQUFaO0FBQWlDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQkFBWjtBQUFtQyxJQUFJaWYsVUFBSjtBQUFlbGYsTUFBTSxDQUFDQyxJQUFQLENBQVksc0JBQVosRUFBbUM7QUFBQ2lmLFlBQVUsQ0FBQ2hmLENBQUQsRUFBRztBQUFDZ2YsY0FBVSxHQUFDaGYsQ0FBWDtBQUFhOztBQUE1QixDQUFuQyxFQUFpRSxDQUFqRTtBQUFvRSxJQUFJaWYsTUFBSjtBQUFXbmYsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDa2YsUUFBTSxDQUFDamYsQ0FBRCxFQUFHO0FBQUNpZixVQUFNLEdBQUNqZixDQUFQO0FBQVM7O0FBQXBCLENBQTNCLEVBQWlELENBQWpEO0FBYzNMO0FBRUFnZixVQUFVLENBQUNFLElBQUksSUFBSTtBQUNmO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQSxRQUFNQyxNQUFNLEdBQUdGLE1BQU0sQ0FBQ0csWUFBUCxFQUFmO0FBQ0FGLE1BQUksQ0FBQ0csWUFBTCxDQUFrQkYsTUFBTSxDQUFDRyxJQUFQLENBQVlDLFFBQVosRUFBbEI7QUFDQUwsTUFBSSxDQUFDRyxZQUFMLENBQWtCRixNQUFNLENBQUNLLEtBQVAsQ0FBYUQsUUFBYixFQUFsQixFQWRlLENBZ0JmO0FBQ0gsQ0FqQlMsQ0FBVixDOzs7Ozs7Ozs7OztBQ2hCQXpmLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaO0FBQWtERCxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQ0FBWjtBQUFpREQsTUFBTSxDQUFDQyxJQUFQLENBQVksd0NBQVo7QUFBc0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaO0FBQWtERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx5Q0FBWjtBQUF1REQsTUFBTSxDQUFDQyxJQUFQLENBQVksd0NBQVo7QUFBc0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZDQUFaO0FBQTJERCxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQ0FBWjtBQUFtREQsTUFBTSxDQUFDQyxJQUFQLENBQVksMENBQVo7QUFBd0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVDQUFaO0FBQXFERCxNQUFNLENBQUNDLElBQVAsQ0FBWSw0Q0FBWjtBQUEwREQsTUFBTSxDQUFDQyxJQUFQLENBQVksK0NBQVo7QUFBNkRELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBDQUFaO0FBQXdERCxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQ0FBWjtBQUE2REQsTUFBTSxDQUFDQyxJQUFQLENBQVkseUNBQVo7QUFBdURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDhDQUFaO0FBQTRERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx5Q0FBWjtBQUF1REQsTUFBTSxDQUFDQyxJQUFQLENBQVksc0NBQVo7QUFBb0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdDQUFaLEU7Ozs7Ozs7Ozs7O0FDQTc5QixJQUFJMGYsTUFBSjtBQUFXM2YsTUFBTSxDQUFDQyxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDNFcsU0FBTyxDQUFDM1csQ0FBRCxFQUFHO0FBQUN5ZixVQUFNLEdBQUN6ZixDQUFQO0FBQVM7O0FBQXJCLENBQXJCLEVBQTRDLENBQTVDO0FBQStDLElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSXlFLE9BQUo7QUFBWTNFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFNBQVosRUFBc0I7QUFBQyxNQUFJQyxDQUFKLEVBQU07QUFBQ3lFLFdBQU8sR0FBQ3pFLENBQVI7QUFBVTs7QUFBbEIsQ0FBdEIsRUFBMEMsQ0FBMUM7O0FBSTlIO0FBQ0EsSUFBSTBmLE1BQU0sR0FBR0MsR0FBRyxDQUFDQyxPQUFKLENBQVksZUFBWixDQUFiLEMsQ0FDQTs7O0FBQ0EsSUFBSUMsSUFBSSxHQUFHRixHQUFHLENBQUNDLE9BQUosQ0FBWSxlQUFaLEVBQTZCQyxJQUF4Qzs7QUFFQSxTQUFTQyxXQUFULENBQXFCQyxTQUFyQixFQUFnQztBQUM1QixTQUFPQSxTQUFTLENBQUNoYSxHQUFWLENBQWMsVUFBU2lhLElBQVQsRUFBZTtBQUNoQyxXQUFPLENBQUMsTUFBTSxDQUFDQSxJQUFJLEdBQUcsSUFBUixFQUFjVCxRQUFkLENBQXVCLEVBQXZCLENBQVAsRUFBbUNVLEtBQW5DLENBQXlDLENBQUMsQ0FBMUMsQ0FBUDtBQUNILEdBRk0sRUFFSkMsSUFGSSxDQUVDLEVBRkQsQ0FBUDtBQUdIOztBQUVEcmdCLE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1h1ZixnQkFBYyxFQUFFLFVBQVN4SyxNQUFULEVBQWlCeUssTUFBakIsRUFBeUI7QUFDckM7QUFDQSxRQUFJQyxpQkFBaUIsR0FBR3BXLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBMEIsS0FBMUIsQ0FBeEI7QUFDQSxRQUFJb1csTUFBTSxHQUFHclcsTUFBTSxDQUFDc1csS0FBUCxDQUFhLEVBQWIsQ0FBYjtBQUNBRixxQkFBaUIsQ0FBQ0csSUFBbEIsQ0FBdUJGLE1BQXZCLEVBQStCLENBQS9CO0FBQ0FyVyxVQUFNLENBQUNDLElBQVAsQ0FBWXlMLE1BQU0sQ0FBQ3BVLEtBQW5CLEVBQTBCLFFBQTFCLEVBQW9DaWYsSUFBcEMsQ0FBeUNGLE1BQXpDLEVBQWlERCxpQkFBaUIsQ0FBQ3plLE1BQW5FO0FBQ0EsV0FBTzZkLE1BQU0sQ0FBQ2dCLE1BQVAsQ0FBY0wsTUFBZCxFQUFzQlgsTUFBTSxDQUFDaUIsT0FBUCxDQUFlSixNQUFmLENBQXRCLENBQVA7QUFDSCxHQVJVO0FBU1hLLGdCQUFjLEVBQUUsVUFBU2hMLE1BQVQsRUFBaUI7QUFDN0I7QUFDQSxRQUFJMEssaUJBQWlCLEdBQUdwVyxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQTBCLEtBQTFCLENBQXhCO0FBQ0EsUUFBSW9XLE1BQU0sR0FBR3JXLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZdVYsTUFBTSxDQUFDbUIsU0FBUCxDQUFpQm5CLE1BQU0sQ0FBQ29CLE1BQVAsQ0FBY2xMLE1BQWQsRUFBc0JtTCxLQUF2QyxDQUFaLENBQWI7QUFDQSxXQUFPUixNQUFNLENBQUNMLEtBQVAsQ0FBYUksaUJBQWlCLENBQUN6ZSxNQUEvQixFQUF1QzJkLFFBQXZDLENBQWdELFFBQWhELENBQVA7QUFDSCxHQWRVO0FBZVh3QixjQUFZLEVBQUUsVUFBU0MsWUFBVCxFQUFzQjtBQUNoQyxRQUFJbmdCLE9BQU8sR0FBRzRlLE1BQU0sQ0FBQ29CLE1BQVAsQ0FBY0csWUFBZCxDQUFkO0FBQ0EsV0FBT3ZCLE1BQU0sQ0FBQ2dCLE1BQVAsQ0FBYzVnQixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QnNYLG1CQUFyQyxFQUEwRHZkLE9BQU8sQ0FBQ2lnQixLQUFsRSxDQUFQO0FBQ0gsR0FsQlU7QUFtQlhHLG1CQUFpQixFQUFFLFVBQVNDLFVBQVQsRUFBb0I7QUFDbkMsUUFBSTViLFFBQVEsR0FBR3JGLElBQUksQ0FBQ0ssR0FBTCxDQUFTNGdCLFVBQVQsQ0FBZjs7QUFDQSxRQUFJNWIsUUFBUSxDQUFDOUUsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQixVQUFJK0UsSUFBSSxHQUFHZCxPQUFPLENBQUNlLElBQVIsQ0FBYUYsUUFBUSxDQUFDbkUsT0FBdEIsQ0FBWDtBQUNBLGFBQU9vRSxJQUFJLENBQUMsbUJBQUQsQ0FBSixDQUEwQkUsSUFBMUIsQ0FBK0IsS0FBL0IsQ0FBUDtBQUNIO0FBQ0o7QUF6QlUsQ0FBZixFOzs7Ozs7Ozs7OztBQ2ZBM0YsTUFBTSxDQUFDdVEsTUFBUCxDQUFjO0FBQUM4USxhQUFXLEVBQUMsTUFBSUEsV0FBakI7QUFBNkJDLG9CQUFrQixFQUFDLE1BQUlBLGtCQUFwRDtBQUF1RUMsVUFBUSxFQUFDLE1BQUlBLFFBQXBGO0FBQTZGN0MsUUFBTSxFQUFDLE1BQUlBLE1BQXhHO0FBQStHOEMsVUFBUSxFQUFDLE1BQUlBO0FBQTVILENBQWQ7QUFBcUosSUFBSUMsS0FBSjtBQUFVemhCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLE9BQVosRUFBb0I7QUFBQzRXLFNBQU8sQ0FBQzNXLENBQUQsRUFBRztBQUFDdWhCLFNBQUssR0FBQ3ZoQixDQUFOO0FBQVE7O0FBQXBCLENBQXBCLEVBQTBDLENBQTFDO0FBQTZDLElBQUl3aEIsbUJBQUo7QUFBd0IxaEIsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDeWhCLHFCQUFtQixDQUFDeGhCLENBQUQsRUFBRztBQUFDd2hCLHVCQUFtQixHQUFDeGhCLENBQXBCO0FBQXNCOztBQUE5QyxDQUF6QixFQUF5RSxDQUF6RTs7QUFHN04sTUFBTW1oQixXQUFXLEdBQUlNLEtBQUQsSUFBVztBQUNsQyxVQUFRQSxLQUFLLENBQUMxTyxLQUFkO0FBQ0EsU0FBSyxPQUFMO0FBQ0ksYUFBTyxJQUFQOztBQUNKO0FBQ0ksYUFBTyxJQUFQO0FBSko7QUFNSCxDQVBNOztBQVVBLE1BQU1xTyxrQkFBa0IsR0FBSUssS0FBRCxJQUFXO0FBQ3pDLFVBQVFBLEtBQUssQ0FBQ2phLE1BQWQ7QUFDQSxTQUFLLFFBQUw7QUFDSSxhQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxVQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssU0FBTDtBQUNJLGFBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSixTQUFLLGVBQUw7QUFDSSxhQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxjQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKO0FBQ0ksYUFBTyw4QkFBUDtBQVpKO0FBY0gsQ0FmTTs7QUFpQkEsTUFBTTZaLFFBQVEsR0FBSUksS0FBRCxJQUFXO0FBQy9CLFVBQVFBLEtBQUssQ0FBQzlJLElBQWQ7QUFDQSxTQUFLLEtBQUw7QUFDSSxhQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxJQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssU0FBTDtBQUNJLGFBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSixTQUFLLGNBQUw7QUFDSSxhQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0o7QUFDSSxhQUFPLDhCQUFQO0FBVko7QUFZSCxDQWJNOztBQWVBLE1BQU02RixNQUFNLEdBQUlpRCxLQUFELElBQVc7QUFDN0IsTUFBSUEsS0FBSyxDQUFDQyxLQUFWLEVBQWdCO0FBQ1osV0FBTztBQUFNLGVBQVMsRUFBQztBQUFoQixPQUEyQztBQUFHLGVBQVMsRUFBQztBQUFiLE1BQTNDLENBQVA7QUFDSCxHQUZELE1BR0k7QUFDQSxXQUFPO0FBQU0sZUFBUyxFQUFDO0FBQWhCLE9BQTBDO0FBQUcsZUFBUyxFQUFDO0FBQWIsTUFBMUMsQ0FBUDtBQUNIO0FBQ0osQ0FQTTs7QUFTQSxNQUFNSixRQUFOLFNBQXVCQyxLQUFLLENBQUNJLFNBQTdCLENBQXVDO0FBQzFDQyxhQUFXLENBQUNILEtBQUQsRUFBUTtBQUNmLFVBQU1BLEtBQU47QUFDQSxTQUFLSSxHQUFMLEdBQVdOLEtBQUssQ0FBQ08sU0FBTixFQUFYO0FBQ0g7O0FBRURDLFFBQU0sR0FBRztBQUNMLFdBQU8sQ0FDSDtBQUFHLFNBQUcsRUFBQyxNQUFQO0FBQWMsZUFBUyxFQUFDLDBCQUF4QjtBQUFtRCxTQUFHLEVBQUUsS0FBS0Y7QUFBN0QsY0FERyxFQUVILG9CQUFDLG1CQUFEO0FBQXFCLFNBQUcsRUFBQyxTQUF6QjtBQUFtQyxlQUFTLEVBQUMsT0FBN0M7QUFBcUQsWUFBTSxFQUFFLEtBQUtBO0FBQWxFLE9BQ0ssS0FBS0osS0FBTCxDQUFXclIsUUFBWCxHQUFvQixLQUFLcVIsS0FBTCxDQUFXclIsUUFBL0IsR0FBd0MsS0FBS3FSLEtBQUwsQ0FBV08sV0FEeEQsQ0FGRyxDQUFQO0FBTUg7O0FBYnlDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEQ5Q2xpQixNQUFNLENBQUN1USxNQUFQLENBQWM7QUFBQ3NHLFNBQU8sRUFBQyxNQUFJc0w7QUFBYixDQUFkO0FBQWtDLElBQUlwaUIsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJa2lCLE1BQUo7QUFBV3BpQixNQUFNLENBQUNDLElBQVAsQ0FBWSxRQUFaLEVBQXFCO0FBQUM0VyxTQUFPLENBQUMzVyxDQUFELEVBQUc7QUFBQ2tpQixVQUFNLEdBQUNsaUIsQ0FBUDtBQUFTOztBQUFyQixDQUFyQixFQUE0QyxDQUE1Qzs7QUFHN0dtaUIsVUFBVSxHQUFJNWdCLEtBQUQsSUFBVztBQUN2QixNQUFJNmdCLFNBQVMsR0FBRyxVQUFoQjtBQUNBN2dCLE9BQUssR0FBRzRLLElBQUksQ0FBQzZFLEtBQUwsQ0FBV3pQLEtBQUssR0FBRyxJQUFuQixJQUEyQixJQUFuQztBQUNBLE1BQUk0SyxJQUFJLENBQUM2RSxLQUFMLENBQVd6UCxLQUFYLE1BQXNCQSxLQUExQixFQUNDNmdCLFNBQVMsR0FBRyxLQUFaLENBREQsS0FFSyxJQUFJalcsSUFBSSxDQUFDNkUsS0FBTCxDQUFXelAsS0FBSyxHQUFDLEVBQWpCLE1BQXlCQSxLQUFLLEdBQUMsRUFBbkMsRUFDSjZnQixTQUFTLEdBQUcsT0FBWixDQURJLEtBRUEsSUFBSWpXLElBQUksQ0FBQzZFLEtBQUwsQ0FBV3pQLEtBQUssR0FBQyxHQUFqQixNQUEwQkEsS0FBSyxHQUFDLEdBQXBDLEVBQ0o2Z0IsU0FBUyxHQUFHLFFBQVosQ0FESSxLQUVBLElBQUlqVyxJQUFJLENBQUM2RSxLQUFMLENBQVd6UCxLQUFLLEdBQUMsSUFBakIsTUFBMkJBLEtBQUssR0FBQyxJQUFyQyxFQUNKNmdCLFNBQVMsR0FBRyxTQUFaO0FBQ0QsU0FBT0YsTUFBTSxDQUFDM2dCLEtBQUQsQ0FBTixDQUFjOGdCLE1BQWQsQ0FBcUJELFNBQXJCLENBQVA7QUFDQSxDQVpEOztBQWNlLE1BQU1ILElBQU4sQ0FBVztBQU96QkwsYUFBVyxDQUFDOU8sTUFBRCxFQUFxQjtBQUFBLFFBQVpDLEtBQVksdUVBQU4sSUFBTTtBQUMvQixRQUFJLE9BQU9ELE1BQVAsS0FBa0IsUUFBdEIsRUFDQyxDQUFDO0FBQUNBLFlBQUQ7QUFBU0M7QUFBVCxRQUFrQkQsTUFBbkI7O0FBQ0QsUUFBSSxDQUFDQyxLQUFELElBQVVBLEtBQUssQ0FBQ3VQLFdBQU4sT0FBd0JMLElBQUksQ0FBQ00sWUFBTCxDQUFrQkQsV0FBbEIsRUFBdEMsRUFBdUU7QUFDdEUsV0FBS0UsT0FBTCxHQUFlcEosTUFBTSxDQUFDdEcsTUFBRCxDQUFyQjtBQUNBLEtBRkQsTUFFTyxJQUFJQyxLQUFLLENBQUN1UCxXQUFOLE9BQXdCTCxJQUFJLENBQUNRLFlBQUwsQ0FBa0JILFdBQWxCLEVBQTVCLEVBQTZEO0FBQ25FLFdBQUtFLE9BQUwsR0FBZXBKLE1BQU0sQ0FBQ3RHLE1BQUQsQ0FBTixHQUFpQm1QLElBQUksQ0FBQ1MsZUFBckM7QUFDQSxLQUZNLE1BR0Y7QUFDSixZQUFNMUwsS0FBSyw2QkFBc0JqRSxLQUF0QixFQUFYO0FBQ0E7QUFDRDs7QUFFRCxNQUFJRCxNQUFKLEdBQWM7QUFDYixXQUFPLEtBQUswUCxPQUFaO0FBQ0E7O0FBRUQsTUFBSUcsYUFBSixHQUFxQjtBQUNwQixXQUFPLEtBQUtILE9BQUwsR0FBZVAsSUFBSSxDQUFDUyxlQUEzQjtBQUNBOztBQUVEbkQsVUFBUSxDQUFFcUQsU0FBRixFQUFhO0FBQ3BCO0FBQ0EsUUFBSUMsUUFBUSxHQUFHWixJQUFJLENBQUNTLGVBQUwsSUFBc0JFLFNBQVMsR0FBQ3pXLElBQUksQ0FBQzJXLEdBQUwsQ0FBUyxFQUFULEVBQWFGLFNBQWIsQ0FBRCxHQUF5QixLQUF4RCxDQUFmOztBQUNBLFFBQUksS0FBSzlQLE1BQUwsR0FBYytQLFFBQWxCLEVBQTRCO0FBQzNCLHVCQUFVWCxNQUFNLENBQUMsS0FBS3BQLE1BQU4sQ0FBTixDQUFvQnVQLE1BQXBCLENBQTJCLEtBQTNCLENBQVYsY0FBK0NKLElBQUksQ0FBQ00sWUFBcEQ7QUFDQSxLQUZELE1BRU87QUFDTix1QkFBVUssU0FBUyxHQUFDVixNQUFNLENBQUMsS0FBS1MsYUFBTixDQUFOLENBQTJCTixNQUEzQixDQUFrQyxTQUFTLElBQUlVLE1BQUosQ0FBV0gsU0FBWCxDQUEzQyxDQUFELEdBQW1FVCxVQUFVLENBQUMsS0FBS1EsYUFBTixDQUFoRyxjQUF3SFYsSUFBSSxDQUFDUSxZQUE3SDtBQUNBO0FBQ0Q7O0FBRURPLFlBQVUsQ0FBRVosU0FBRixFQUFhO0FBQ3RCLFFBQUl0UCxNQUFNLEdBQUcsS0FBS0EsTUFBbEI7O0FBQ0EsUUFBSXNQLFNBQUosRUFBZTtBQUNkdFAsWUFBTSxHQUFHb1AsTUFBTSxDQUFDcFAsTUFBRCxDQUFOLENBQWV1UCxNQUFmLENBQXNCRCxTQUF0QixDQUFUO0FBQ0E7O0FBQ0QscUJBQVV0UCxNQUFWLGNBQW9CbVAsSUFBSSxDQUFDTSxZQUF6QjtBQUNBOztBQUVEVSxhQUFXLENBQUViLFNBQUYsRUFBYTtBQUN2QixRQUFJdFAsTUFBTSxHQUFHLEtBQUs2UCxhQUFsQjs7QUFDQSxRQUFJUCxTQUFKLEVBQWU7QUFDZHRQLFlBQU0sR0FBR29QLE1BQU0sQ0FBQ3BQLE1BQUQsQ0FBTixDQUFldVAsTUFBZixDQUFzQkQsU0FBdEIsQ0FBVDtBQUNBOztBQUNELHFCQUFVdFAsTUFBVixjQUFvQm1QLElBQUksQ0FBQ1EsWUFBekI7QUFDQTs7QUFwRHdCOztBQUFMUixJLENBQ2JRLFksR0FBZTVpQixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1Qm9jLFk7QUFEekJqQixJLENBRWJrQixrQixHQUFxQnRqQixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QnNjLGtCQUF2QixJQUE4Q25CLElBQUksQ0FBQ1EsWUFBTCxHQUFvQixHO0FBRjFFUixJLENBR2JNLFksR0FBZTFpQixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjJMLFk7QUFIekJ3UCxJLENBSWJTLGUsR0FBa0J0SixNQUFNLENBQUN2WixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QitPLGVBQXhCLEM7QUFKWG9NLEksQ0FLYm9CLFEsR0FBVyxJQUFJakssTUFBTSxDQUFDdlosTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUIrTyxlQUF4QixDOzs7Ozs7Ozs7OztBQ3RCN0IvVixNQUFNLENBQUNDLElBQVAsQ0FBWSx5QkFBWjtBQUF1Q0QsTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVo7QUFJdkM7QUFDQTtBQUVBaUksT0FBTyxHQUFHLEtBQVY7QUFDQThTLGlCQUFpQixHQUFHLEtBQXBCO0FBQ0EyQixzQkFBc0IsR0FBRyxLQUF6QjtBQUNBbFYsR0FBRyxHQUFHMUgsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQnljLE1BQWhCLENBQXVCQyxHQUE3QjtBQUNBaGpCLEdBQUcsR0FBR1YsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQnljLE1BQWhCLENBQXVCRSxHQUE3QjtBQUNBQyxXQUFXLEdBQUcsQ0FBZDtBQUNBQyxVQUFVLEdBQUcsQ0FBYjtBQUNBQyxjQUFjLEdBQUcsQ0FBakI7QUFDQUMsYUFBYSxHQUFHLENBQWhCO0FBQ0FDLHFCQUFxQixHQUFHLENBQXhCO0FBQ0FDLGdCQUFnQixHQUFHLENBQW5CO0FBQ0FDLGVBQWUsR0FBRyxDQUFsQjtBQUNBQyxjQUFjLEdBQUcsQ0FBakI7QUFFQSxNQUFNQyxlQUFlLEdBQUcsd0JBQXhCOztBQUVBQyxpQkFBaUIsR0FBRyxNQUFNO0FBQ3RCcmtCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSxvQkFBWixFQUFrQyxDQUFDaWMsS0FBRCxFQUFRL2lCLE1BQVIsS0FBbUI7QUFDakQsUUFBSStpQixLQUFKLEVBQVU7QUFDTnpqQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxtQkFBaUJ3akIsS0FBN0I7QUFDSCxLQUZELE1BR0k7QUFDQXpqQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxtQkFBaUJTLE1BQTdCO0FBQ0g7QUFDSixHQVBEO0FBUUgsQ0FURDs7QUFXQWdqQixXQUFXLEdBQUcsTUFBTTtBQUNoQnZrQixRQUFNLENBQUNxSSxJQUFQLENBQVkscUJBQVosRUFBbUMsQ0FBQ2ljLEtBQUQsRUFBUS9pQixNQUFSLEtBQW1CO0FBQ2xELFFBQUkraUIsS0FBSixFQUFVO0FBQ056akIsYUFBTyxDQUFDQyxHQUFSLENBQVksbUJBQWlCd2pCLEtBQTdCO0FBQ0gsS0FGRCxNQUdJO0FBQ0F6akIsYUFBTyxDQUFDQyxHQUFSLENBQVksbUJBQWlCUyxNQUE3QjtBQUNIO0FBQ0osR0FQRDtBQVFILENBVEQ7O0FBV0FpakIsaUJBQWlCLEdBQUcsTUFBTTtBQUN0QnhrQixRQUFNLENBQUNxSSxJQUFQLENBQVkseUJBQVosRUFBdUMsQ0FBQ2ljLEtBQUQsRUFBUS9pQixNQUFSLEtBQW1CO0FBQ3RELFFBQUkraUIsS0FBSixFQUFVO0FBQ056akIsYUFBTyxDQUFDQyxHQUFSLENBQVksb0JBQWtCd2pCLEtBQTlCO0FBQ0g7QUFDSixHQUpEO0FBS0gsQ0FORDs7QUFRQUcsWUFBWSxHQUFHLE1BQU07QUFDakJ6a0IsUUFBTSxDQUFDcUksSUFBUCxDQUFZLHdCQUFaLEVBQXNDLENBQUNpYyxLQUFELEVBQVEvaUIsTUFBUixLQUFtQjtBQUNyRCxRQUFJK2lCLEtBQUosRUFBVTtBQUNOempCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFrQndqQixLQUE5QjtBQUNIOztBQUNELFFBQUkvaUIsTUFBSixFQUFXO0FBQ1BWLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFpQlMsTUFBN0I7QUFDSDtBQUNKLEdBUEQ7QUFRSCxDQVREOztBQVdBbWpCLG1CQUFtQixHQUFHLE1BQU07QUFDeEIxa0IsUUFBTSxDQUFDcUksSUFBUCxDQUFZLDhCQUFaLEVBQTRDLENBQUNpYyxLQUFELEVBQVEvaUIsTUFBUixLQUFtQjtBQUMzRCxRQUFJK2lCLEtBQUosRUFBVTtBQUNOempCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDJCQUF5QndqQixLQUFyQztBQUNIOztBQUNELFFBQUkvaUIsTUFBSixFQUFXO0FBQ1BWLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDJCQUF5QlMsTUFBckM7QUFDSDtBQUNKLEdBUEQ7QUFRSCxDQVREOztBQVdBb2pCLGtCQUFrQixHQUFHLE1BQU07QUFDdkIza0IsUUFBTSxDQUFDcUksSUFBUCxDQUFZLHdDQUFaLEVBQXNELENBQUNpYyxLQUFELEVBQVEvaUIsTUFBUixLQUFrQjtBQUNwRSxRQUFJK2lCLEtBQUosRUFBVTtBQUNOempCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDBCQUF5QndqQixLQUFyQztBQUNIOztBQUNELFFBQUkvaUIsTUFBSixFQUFXO0FBQ1BWLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFzQlMsTUFBbEM7QUFDSDtBQUNKLEdBUEQ7QUFRSjs7Ozs7Ozs7OztBQVVDLENBbkJEOztBQXFCQXFqQixjQUFjLEdBQUcsTUFBTTtBQUNuQjVrQixRQUFNLENBQUNxSSxJQUFQLENBQVksNEJBQVosRUFBMEMsQ0FBQ2ljLEtBQUQsRUFBUS9pQixNQUFSLEtBQW1CO0FBQ3pELFFBQUkraUIsS0FBSixFQUFVO0FBQ056akIsYUFBTyxDQUFDQyxHQUFSLENBQVksNEJBQTJCd2pCLEtBQXZDO0FBQ0gsS0FGRCxNQUdJO0FBQ0F6akIsYUFBTyxDQUFDQyxHQUFSLENBQVkseUJBQXdCUyxNQUFwQztBQUNIO0FBQ0osR0FQRDtBQVFILENBVEQ7O0FBV0FzakIsaUJBQWlCLEdBQUcsTUFBSztBQUNyQjtBQUNBN2tCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSw0Q0FBWixFQUEwRCxHQUExRCxFQUErRCxDQUFDaWMsS0FBRCxFQUFRL2lCLE1BQVIsS0FBbUI7QUFDOUUsUUFBSStpQixLQUFKLEVBQVU7QUFDTnpqQixhQUFPLENBQUNDLEdBQVIsQ0FBWSwwQ0FBd0N3akIsS0FBcEQ7QUFDSCxLQUZELE1BR0k7QUFDQXpqQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx1Q0FBcUNTLE1BQWpEO0FBQ0g7QUFDSixHQVBEO0FBU0F2QixRQUFNLENBQUNxSSxJQUFQLENBQVksd0JBQVosRUFBc0MsQ0FBQ2ljLEtBQUQsRUFBUS9pQixNQUFSLEtBQW1CO0FBQ3JELFFBQUkraUIsS0FBSixFQUFVO0FBQ056akIsYUFBTyxDQUFDQyxHQUFSLENBQVksMkJBQXlCd2pCLEtBQXJDO0FBQ0gsS0FGRCxNQUdJO0FBQ0F6akIsYUFBTyxDQUFDQyxHQUFSLENBQVksd0JBQXNCUyxNQUFsQztBQUNIO0FBQ0osR0FQRDtBQVFILENBbkJEOztBQXFCQXVqQixlQUFlLEdBQUcsTUFBSztBQUNuQjtBQUNBOWtCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSw0Q0FBWixFQUEwRCxHQUExRCxFQUErRCxDQUFDaWMsS0FBRCxFQUFRL2lCLE1BQVIsS0FBbUI7QUFDOUUsUUFBSStpQixLQUFKLEVBQVU7QUFDTnpqQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx3Q0FBc0N3akIsS0FBbEQ7QUFDSCxLQUZELE1BR0k7QUFDQXpqQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxxQ0FBbUNTLE1BQS9DO0FBQ0g7QUFDSixHQVBEO0FBUUgsQ0FWRDs7QUFZQXdqQixjQUFjLEdBQUcsTUFBSztBQUNsQjtBQUNBL2tCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSw0Q0FBWixFQUEwRCxHQUExRCxFQUErRCxDQUFDaWMsS0FBRCxFQUFRL2lCLE1BQVIsS0FBbUI7QUFDOUUsUUFBSStpQixLQUFKLEVBQVU7QUFDTnpqQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx1Q0FBcUN3akIsS0FBakQ7QUFDSCxLQUZELE1BR0k7QUFDQXpqQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxvQ0FBa0NTLE1BQTlDO0FBQ0g7QUFDSixHQVBEO0FBU0F2QixRQUFNLENBQUNxSSxJQUFQLENBQVksNENBQVosRUFBMEQsQ0FBQ2ljLEtBQUQsRUFBUS9pQixNQUFSLEtBQW1CO0FBQ3pFLFFBQUkraUIsS0FBSixFQUFVO0FBQ056akIsYUFBTyxDQUFDQyxHQUFSLENBQVksMkNBQTBDd2pCLEtBQXREO0FBQ0gsS0FGRCxNQUdLO0FBQ0R6akIsYUFBTyxDQUFDQyxHQUFSLENBQVksd0NBQXVDUyxNQUFuRDtBQUNIO0FBQ0osR0FQRDtBQVFILENBbkJEOztBQXVCQXZCLE1BQU0sQ0FBQ2dsQixPQUFQLENBQWUsWUFBVTtBQUNyQixNQUFJaGxCLE1BQU0sQ0FBQ2lsQixhQUFYLEVBQXlCO0FBcEs3QixRQUFJQyxtQkFBSjtBQUF3QmpsQixVQUFNLENBQUNDLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDNFcsYUFBTyxDQUFDM1csQ0FBRCxFQUFHO0FBQUMra0IsMkJBQW1CLEdBQUMva0IsQ0FBcEI7QUFBc0I7O0FBQWxDLEtBQXZDLEVBQTJFLENBQTNFO0FBcUtoQmdsQixXQUFPLENBQUNDLEdBQVIsQ0FBWUMsNEJBQVosR0FBMkMsQ0FBM0M7QUFFQTNjLFVBQU0sQ0FBQ0MsSUFBUCxDQUFZdWMsbUJBQVosRUFBaUNsaUIsT0FBakMsQ0FBMENzaUIsR0FBRCxJQUFTO0FBQzlDLFVBQUl0bEIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQnNlLEdBQWhCLEtBQXdCMVcsU0FBNUIsRUFBdUM7QUFDbkMvTixlQUFPLENBQUMwa0IsSUFBUixnQ0FBcUNELEdBQXJDO0FBQ0F0bEIsY0FBTSxDQUFDZ0gsUUFBUCxDQUFnQnNlLEdBQWhCLElBQXVCLEVBQXZCO0FBQ0g7O0FBQ0Q1YyxZQUFNLENBQUNDLElBQVAsQ0FBWXVjLG1CQUFtQixDQUFDSSxHQUFELENBQS9CLEVBQXNDdGlCLE9BQXRDLENBQStDd2lCLEtBQUQsSUFBVztBQUNyRCxZQUFJeGxCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JzZSxHQUFoQixFQUFxQkUsS0FBckIsS0FBK0I1VyxTQUFuQyxFQUE2QztBQUN6Qy9OLGlCQUFPLENBQUMwa0IsSUFBUixnQ0FBcUNELEdBQXJDLGNBQTRDRSxLQUE1QztBQUNBeGxCLGdCQUFNLENBQUNnSCxRQUFQLENBQWdCc2UsR0FBaEIsRUFBcUJFLEtBQXJCLElBQThCTixtQkFBbUIsQ0FBQ0ksR0FBRCxDQUFuQixDQUF5QkUsS0FBekIsQ0FBOUI7QUFDSDtBQUNKLE9BTEQ7QUFNSCxLQVhEO0FBWUg7O0FBRUR4bEIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLGVBQVosRUFBNkIsQ0FBQ2lDLEdBQUQsRUFBTS9JLE1BQU4sS0FBaUI7QUFDMUMsUUFBSStJLEdBQUosRUFBUTtBQUNKekosYUFBTyxDQUFDQyxHQUFSLENBQVl3SixHQUFaO0FBQ0g7O0FBQ0QsUUFBSS9JLE1BQUosRUFBVztBQUNQLFVBQUl2QixNQUFNLENBQUNnSCxRQUFQLENBQWdCd00sS0FBaEIsQ0FBc0JpUyxVQUExQixFQUFxQztBQUNqQzNCLHNCQUFjLEdBQUc5akIsTUFBTSxDQUFDMGxCLFdBQVAsQ0FBbUIsWUFBVTtBQUMxQ2xCLDJCQUFpQjtBQUNwQixTQUZnQixFQUVkeGtCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QnlkLGlCQUZULENBQWpCO0FBSUEvQixtQkFBVyxHQUFHNWpCLE1BQU0sQ0FBQzBsQixXQUFQLENBQW1CLFlBQVU7QUFDdkNuQixxQkFBVztBQUNkLFNBRmEsRUFFWHZrQixNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUIwZCxhQUZaLENBQWQ7QUFJQS9CLGtCQUFVLEdBQUc3akIsTUFBTSxDQUFDMGxCLFdBQVAsQ0FBbUIsWUFBVTtBQUN0Q3JCLDJCQUFpQjtBQUNwQixTQUZZLEVBRVZya0IsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCMmQsY0FGYixDQUFiO0FBSUE5QixxQkFBYSxHQUFHL2pCLE1BQU0sQ0FBQzBsQixXQUFQLENBQW1CLFlBQVU7QUFDekNqQixzQkFBWTtBQUNmLFNBRmUsRUFFYnprQixNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUI0ZCxnQkFGVixDQUFoQjtBQUlBOUIsNkJBQXFCLEdBQUdoa0IsTUFBTSxDQUFDMGxCLFdBQVAsQ0FBbUIsWUFBVTtBQUNqRGhCLDZCQUFtQjtBQUN0QixTQUZ1QixFQUVyQjFrQixNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUI0ZCxnQkFGRixDQUF4QjtBQUlBN0Isd0JBQWdCLEdBQUdqa0IsTUFBTSxDQUFDMGxCLFdBQVAsQ0FBbUIsWUFBVTtBQUM1Q2YsNEJBQWtCO0FBQ3JCLFNBRmtCLEVBRWhCM2tCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QjZkLG9CQUZQLENBQW5CO0FBSUE3Qix1QkFBZSxHQUFHbGtCLE1BQU0sQ0FBQzBsQixXQUFQLENBQW1CLFlBQVU7QUFDM0NkLHdCQUFjO0FBQ2pCLFNBRmlCLEVBRWY1a0IsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCOGQsa0JBRlIsQ0FBbEI7QUFJQTdCLHNCQUFjLEdBQUdua0IsTUFBTSxDQUFDMGxCLFdBQVAsQ0FBbUIsWUFBVTtBQUMxQyxjQUFJbFAsR0FBRyxHQUFHLElBQUlwVCxJQUFKLEVBQVY7O0FBQ0EsY0FBS29ULEdBQUcsQ0FBQ3lQLGFBQUosTUFBdUIsQ0FBNUIsRUFBK0I7QUFDM0JwQiw2QkFBaUI7QUFDcEI7O0FBRUQsY0FBS3JPLEdBQUcsQ0FBQzBQLGFBQUosTUFBdUIsQ0FBeEIsSUFBK0IxUCxHQUFHLENBQUN5UCxhQUFKLE1BQXVCLENBQTFELEVBQTZEO0FBQ3pEbkIsMkJBQWU7QUFDbEI7O0FBRUQsY0FBS3RPLEdBQUcsQ0FBQzJQLFdBQUosTUFBcUIsQ0FBdEIsSUFBNkIzUCxHQUFHLENBQUMwUCxhQUFKLE1BQXVCLENBQXBELElBQTJEMVAsR0FBRyxDQUFDeVAsYUFBSixNQUF1QixDQUF0RixFQUF5RjtBQUNyRmxCLDBCQUFjO0FBQ2pCO0FBQ0osU0FiZ0IsRUFhZCxJQWJjLENBQWpCO0FBY0g7QUFDSjtBQUNKLEdBbEREO0FBb0RILENBdEVELEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcvaW1wb3J0cy9hcGkvdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcbmNvbnN0IGZldGNoRnJvbVVybCA9ICh1cmwpID0+IHtcbiAgICB0cnl7XG4gICAgICAgIGxldCByZXMgPSBIVFRQLmdldChMQ0QgKyB1cmwpO1xuICAgICAgICBpZiAocmVzLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgIHJldHVybiByZXNcbiAgICAgICAgfTtcbiAgICB9XG4gICAgY2F0Y2ggKGUpe1xuICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICB9XG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnYWNjb3VudHMuZ2V0QWNjb3VudERldGFpbCc6IGZ1bmN0aW9uKGFkZHJlc3Mpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHVybCA9IExDRCArICcvYXV0aC9hY2NvdW50cy8nKyBhZGRyZXNzO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgYXZhaWxhYmxlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmIChhdmFpbGFibGUuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEpTT04ucGFyc2UoYXZhaWxhYmxlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICBsZXQgYWNjb3VudDtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UudHlwZSA9PT0gJ2Nvc21vcy1zZGsvQWNjb3VudCcpXG4gICAgICAgICAgICAgICAgICAgIGFjY291bnQgPSByZXNwb25zZS52YWx1ZTtcbiAgICAgICAgICAgICAgICBlbHNlIGlmIChyZXNwb25zZS50eXBlID09PSAnY29zbW9zLXNkay9EZWxheWVkVmVzdGluZ0FjY291bnQnIHx8IHJlc3BvbnNlLnR5cGUgPT09ICdjb3Ntb3Mtc2RrL0NvbnRpbnVvdXNWZXN0aW5nQWNjb3VudCcpXG4gICAgICAgICAgICAgICAgICAgIGFjY291bnQgPSByZXNwb25zZS52YWx1ZS5CYXNlVmVzdGluZ0FjY291bnQuQmFzZUFjY291bnRcbiAgICAgICAgICAgICAgICBpZiAoYWNjb3VudCAmJiBhY2NvdW50LmFjY291bnRfbnVtYmVyICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBhY2NvdW50XG4gICAgICAgICAgICAgICAgcmV0dXJuIG51bGxcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKVxuICAgICAgICB9XG4gICAgfSxcbiAgICAnYWNjb3VudHMuZ2V0QmFsYW5jZSc6IGZ1bmN0aW9uKGFkZHJlc3Mpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IGJhbGFuY2UgPSB7fVxuXG4gICAgICAgIC8vIGdldCBhdmFpbGFibGUgYXRvbXNcbiAgICAgICAgbGV0IHVybCA9IExDRCArICcvYmFuay9iYWxhbmNlcy8nKyBhZGRyZXNzO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgYXZhaWxhYmxlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmIChhdmFpbGFibGUuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKEpTT04ucGFyc2UoYXZhaWxhYmxlLmNvbnRlbnQpKVxuICAgICAgICAgICAgICAgIGJhbGFuY2UuYXZhaWxhYmxlID0gSlNPTi5wYXJzZShhdmFpbGFibGUuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgIGlmIChiYWxhbmNlLmF2YWlsYWJsZSAmJiBiYWxhbmNlLmF2YWlsYWJsZS5sZW5ndGggPiAwKVxuICAgICAgICAgICAgICAgICAgICBiYWxhbmNlLmF2YWlsYWJsZSA9IGJhbGFuY2UuYXZhaWxhYmxlWzBdO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgIH1cblxuICAgICAgICAvLyBnZXQgZGVsZWdhdGVkIGFtbm91bnRzXG4gICAgICAgIHVybCA9IExDRCArICcvc3Rha2luZy9kZWxlZ2F0b3JzLycrYWRkcmVzcysnL2RlbGVnYXRpb25zJztcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IGRlbGVnYXRpb25zID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmIChkZWxlZ2F0aW9ucy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgYmFsYW5jZS5kZWxlZ2F0aW9ucyA9IEpTT04ucGFyc2UoZGVsZWdhdGlvbnMuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG4gICAgICAgIC8vIGdldCB1bmJvbmRpbmdcbiAgICAgICAgdXJsID0gTENEICsgJy9zdGFraW5nL2RlbGVnYXRvcnMvJythZGRyZXNzKycvdW5ib25kaW5nX2RlbGVnYXRpb25zJztcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IHVuYm9uZGluZyA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBpZiAodW5ib25kaW5nLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICBiYWxhbmNlLnVuYm9uZGluZyA9IEpTT04ucGFyc2UodW5ib25kaW5nLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGdldCByZXdhcmRzXG4gICAgICAgIHVybCA9IExDRCArICcvZGlzdHJpYnV0aW9uL2RlbGVnYXRvcnMvJythZGRyZXNzKycvcmV3YXJkcyc7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCByZXdhcmRzID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmIChyZXdhcmRzLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICBiYWxhbmNlLnJld2FyZHMgPSBKU09OLnBhcnNlKHJld2FyZHMuY29udGVudCkucmVzdWx0LnRvdGFsO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gZ2V0IGNvbW1pc3Npb25cbiAgICAgICAgbGV0IHZhbGlkYXRvciA9IFZhbGlkYXRvcnMuZmluZE9uZShcbiAgICAgICAgICAgIHskb3I6IFt7b3BlcmF0b3JfYWRkcmVzczphZGRyZXNzfSwge2RlbGVnYXRvcl9hZGRyZXNzOmFkZHJlc3N9LCB7YWRkcmVzczphZGRyZXNzfV19KVxuICAgICAgICBpZiAodmFsaWRhdG9yKSB7XG4gICAgICAgICAgICBsZXQgdXJsID0gTENEICsgJy9kaXN0cmlidXRpb24vdmFsaWRhdG9ycy8nICsgdmFsaWRhdG9yLm9wZXJhdG9yX2FkZHJlc3M7XG4gICAgICAgICAgICBiYWxhbmNlLm9wZXJhdG9yX2FkZHJlc3MgPSB2YWxpZGF0b3Iub3BlcmF0b3JfYWRkcmVzcztcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgbGV0IHJld2FyZHMgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgIGlmIChyZXdhcmRzLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGNvbnRlbnQgPSBKU09OLnBhcnNlKHJld2FyZHMuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICBpZiAoY29udGVudC52YWxfY29tbWlzc2lvbiAmJiBjb250ZW50LnZhbF9jb21taXNzaW9uLmxlbmd0aCA+IDApXG4gICAgICAgICAgICAgICAgICAgICAgICBiYWxhbmNlLmNvbW1pc3Npb24gPSBjb250ZW50LnZhbF9jb21taXNzaW9uWzBdO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gYmFsYW5jZTtcbiAgICB9LFxuICAgICdhY2NvdW50cy5nZXREZWxlZ2F0aW9uJyhhZGRyZXNzLCB2YWxpZGF0b3Ipe1xuICAgICAgICBsZXQgdXJsID0gYC9zdGFraW5nL2RlbGVnYXRvcnMvJHthZGRyZXNzfS9kZWxlZ2F0aW9ucy8ke3ZhbGlkYXRvcn1gO1xuICAgICAgICBsZXQgZGVsZWdhdGlvbnMgPSBmZXRjaEZyb21VcmwodXJsKTtcbiAgICAgICAgZGVsZWdhdGlvbnMgPSBkZWxlZ2F0aW9ucyAmJiBkZWxlZ2F0aW9ucy5kYXRhLnJlc3VsdDtcbiAgICAgICAgaWYgKGRlbGVnYXRpb25zICYmIGRlbGVnYXRpb25zLnNoYXJlcylcbiAgICAgICAgICAgIGRlbGVnYXRpb25zLnNoYXJlcyA9IHBhcnNlRmxvYXQoZGVsZWdhdGlvbnMuc2hhcmVzKTtcblxuICAgICAgICB1cmwgPSBgL3N0YWtpbmcvcmVkZWxlZ2F0aW9ucz9kZWxlZ2F0b3I9JHthZGRyZXNzfSZ2YWxpZGF0b3JfdG89JHt2YWxpZGF0b3J9YDtcbiAgICAgICAgbGV0IHJlbGVnYXRpb25zID0gZmV0Y2hGcm9tVXJsKHVybCk7XG4gICAgICAgIHJlbGVnYXRpb25zID0gcmVsZWdhdGlvbnMgJiYgcmVsZWdhdGlvbnMuZGF0YS5yZXN1bHQ7XG4gICAgICAgIGxldCBjb21wbGV0aW9uVGltZTtcbiAgICAgICAgaWYgKHJlbGVnYXRpb25zKSB7XG4gICAgICAgICAgICByZWxlZ2F0aW9ucy5mb3JFYWNoKChyZWxlZ2F0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgbGV0IGVudHJpZXMgPSByZWxlZ2F0aW9uLmVudHJpZXNcbiAgICAgICAgICAgICAgICBsZXQgdGltZSA9IG5ldyBEYXRlKGVudHJpZXNbZW50cmllcy5sZW5ndGgtMV0uY29tcGxldGlvbl90aW1lKVxuICAgICAgICAgICAgICAgIGlmICghY29tcGxldGlvblRpbWUgfHwgdGltZSA+IGNvbXBsZXRpb25UaW1lKVxuICAgICAgICAgICAgICAgICAgICBjb21wbGV0aW9uVGltZSA9IHRpbWVcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICBkZWxlZ2F0aW9ucy5yZWRlbGVnYXRpb25Db21wbGV0aW9uVGltZSA9IGNvbXBsZXRpb25UaW1lO1xuICAgICAgICB9XG5cbiAgICAgICAgdXJsID0gYC9zdGFraW5nL2RlbGVnYXRvcnMvJHthZGRyZXNzfS91bmJvbmRpbmdfZGVsZWdhdGlvbnMvJHt2YWxpZGF0b3J9YDtcbiAgICAgICAgbGV0IHVuZGVsZWdhdGlvbnMgPSBmZXRjaEZyb21VcmwodXJsKTtcbiAgICAgICAgdW5kZWxlZ2F0aW9ucyA9IHVuZGVsZWdhdGlvbnMgJiYgdW5kZWxlZ2F0aW9ucy5kYXRhLnJlc3VsdDtcbiAgICAgICAgaWYgKHVuZGVsZWdhdGlvbnMpIHtcbiAgICAgICAgICAgIGRlbGVnYXRpb25zLnVuYm9uZGluZyA9IHVuZGVsZWdhdGlvbnMuZW50cmllcy5sZW5ndGg7XG4gICAgICAgICAgICBkZWxlZ2F0aW9ucy51bmJvbmRpbmdDb21wbGV0aW9uVGltZSA9IHVuZGVsZWdhdGlvbnMuZW50cmllc1swXS5jb21wbGV0aW9uX3RpbWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGRlbGVnYXRpb25zO1xuICAgIH0sXG4gICAgJ2FjY291bnRzLmdldEFsbERlbGVnYXRpb25zJyhhZGRyZXNzKXtcbiAgICAgICAgbGV0IHVybCA9IExDRCArICcvc3Rha2luZy9kZWxlZ2F0b3JzLycrYWRkcmVzcysnL2RlbGVnYXRpb25zJztcblxuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgZGVsZWdhdGlvbnMgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICBkZWxlZ2F0aW9ucyA9IEpTT04ucGFyc2UoZGVsZWdhdGlvbnMuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgIGlmIChkZWxlZ2F0aW9ucyAmJiBkZWxlZ2F0aW9ucy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgZGVsZWdhdGlvbnMuZm9yRWFjaCgoZGVsZWdhdGlvbiwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zW2ldICYmIGRlbGVnYXRpb25zW2ldLnNoYXJlcylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxlZ2F0aW9uc1tpXS5zaGFyZXMgPSBwYXJzZUZsb2F0KGRlbGVnYXRpb25zW2ldLnNoYXJlcyk7XG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgcmV0dXJuIGRlbGVnYXRpb25zO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ2FjY291bnRzLmdldEFsbFVuYm9uZGluZ3MnKGFkZHJlc3Mpe1xuICAgICAgICBsZXQgdXJsID0gTENEICsgJy9zdGFraW5nL2RlbGVnYXRvcnMvJythZGRyZXNzKycvdW5ib25kaW5nX2RlbGVnYXRpb25zJztcblxuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgdW5ib25kaW5ncyA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBpZiAodW5ib25kaW5ncy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgdW5ib25kaW5ncyA9IEpTT04ucGFyc2UodW5ib25kaW5ncy5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHVuYm9uZGluZ3M7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAnYWNjb3VudHMuZ2V0QWxsUmVkZWxlZ2F0aW9ucycoYWRkcmVzcywgdmFsaWRhdG9yKXtcbiAgICAgICAgbGV0IHVybCA9IGAvc3Rha2luZy9yZWRlbGVnYXRpb25zP2RlbGVnYXRvcj0ke2FkZHJlc3N9JnZhbGlkYXRvcl9mcm9tPSR7dmFsaWRhdG9yfWA7XG4gICAgICAgIGxldCByZXN1bHQgPSBmZXRjaEZyb21VcmwodXJsKTtcbiAgICAgICAgaWYgKHJlc3VsdCAmJiByZXN1bHQuZGF0YSkge1xuICAgICAgICAgICAgbGV0IHJlZGVsZWdhdGlvbnMgPSB7fVxuICAgICAgICAgICAgcmVzdWx0LmRhdGEuZm9yRWFjaCgocmVkZWxlZ2F0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgbGV0IGVudHJpZXMgPSByZWRlbGVnYXRpb24uZW50cmllcztcbiAgICAgICAgICAgICAgICByZWRlbGVnYXRpb25zW3JlZGVsZWdhdGlvbi52YWxpZGF0b3JfZHN0X2FkZHJlc3NdID0ge1xuICAgICAgICAgICAgICAgICAgICBjb3VudDogZW50cmllcy5sZW5ndGgsXG4gICAgICAgICAgICAgICAgICAgIGNvbXBsZXRpb25UaW1lOiBlbnRyaWVzWzBdLmNvbXBsZXRpb25fdGltZVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICByZXR1cm4gcmVkZWxlZ2F0aW9uc1xuICAgICAgICB9XG4gICAgfVxufSkiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5pbXBvcnQgeyBQcm9taXNlIH0gZnJvbSBcIm1ldGVvci9wcm9taXNlXCI7XG5pbXBvcnQgeyBCbG9ja3Njb24gfSBmcm9tICcvaW1wb3J0cy9hcGkvYmxvY2tzL2Jsb2Nrcy5qcyc7XG5pbXBvcnQgeyBDaGFpbiB9IGZyb20gJy9pbXBvcnRzL2FwaS9jaGFpbi9jaGFpbi5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JTZXRzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL3ZhbGlkYXRvci1zZXRzL3ZhbGlkYXRvci1zZXRzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcvaW1wb3J0cy9hcGkvdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMsIEFuYWx5dGljcywgVlBEaXN0cmlidXRpb25zfSBmcm9tICcvaW1wb3J0cy9hcGkvcmVjb3Jkcy9yZWNvcmRzLmpzJztcbmltcG9ydCB7IFZvdGluZ1Bvd2VySGlzdG9yeSB9IGZyb20gJy9pbXBvcnRzL2FwaS92b3RpbmctcG93ZXIvaGlzdG9yeS5qcyc7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi8uLi90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzJztcbmltcG9ydCB7IEV2aWRlbmNlcyB9IGZyb20gJy4uLy4uL2V2aWRlbmNlcy9ldmlkZW5jZXMuanMnO1xuaW1wb3J0IHsgc2hhMjU2IH0gZnJvbSAnanMtc2hhMjU2JztcbmltcG9ydCB7IGdldEFkZHJlc3MgfSBmcm9tICd0ZW5kZXJtaW50L2xpYi9wdWJrZXknO1xuaW1wb3J0ICogYXMgY2hlZXJpbyBmcm9tICdjaGVlcmlvJztcblxuLy8gaW1wb3J0IEJsb2NrIGZyb20gJy4uLy4uLy4uL3VpL2NvbXBvbmVudHMvQmxvY2snO1xuXG4vLyBnZXRWYWxpZGF0b3JWb3RpbmdQb3dlciA9ICh2YWxpZGF0b3JzLCBhZGRyZXNzKSA9PiB7XG4vLyAgICAgZm9yICh2IGluIHZhbGlkYXRvcnMpe1xuLy8gICAgICAgICBpZiAodmFsaWRhdG9yc1t2XS5hZGRyZXNzID09IGFkZHJlc3Mpe1xuLy8gICAgICAgICAgICAgcmV0dXJuIHBhcnNlSW50KHZhbGlkYXRvcnNbdl0udm90aW5nX3Bvd2VyKTtcbi8vICAgICAgICAgfVxuLy8gICAgIH1cbi8vIH1cblxuZ2V0UmVtb3ZlZFZhbGlkYXRvcnMgPSAocHJldlZhbGlkYXRvcnMsIHZhbGlkYXRvcnMpID0+IHtcbiAgICAvLyBsZXQgcmVtb3ZlVmFsaWRhdG9ycyA9IFtdO1xuICAgIGZvciAocCBpbiBwcmV2VmFsaWRhdG9ycyl7XG4gICAgICAgIGZvciAodiBpbiB2YWxpZGF0b3JzKXtcbiAgICAgICAgICAgIGlmIChwcmV2VmFsaWRhdG9yc1twXS5hZGRyZXNzID09IHZhbGlkYXRvcnNbdl0uYWRkcmVzcyl7XG4gICAgICAgICAgICAgICAgcHJldlZhbGlkYXRvcnMuc3BsaWNlKHAsMSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gcHJldlZhbGlkYXRvcnM7XG59XG5cbmdldFZhbGlkYXRvclByb2ZpbGVVcmwgPSAoaWRlbnRpdHkpID0+IHtcbiAgICBpZiAoaWRlbnRpdHkubGVuZ3RoID09IDE2KXtcbiAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQoYGh0dHBzOi8va2V5YmFzZS5pby9fL2FwaS8xLjAvdXNlci9sb29rdXAuanNvbj9rZXlfc3VmZml4PSR7aWRlbnRpdHl9JmZpZWxkcz1waWN0dXJlc2ApXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCkge1xuICAgICAgICAgICAgbGV0IHRoZW0gPSByZXNwb25zZS5kYXRhLnRoZW1cbiAgICAgICAgICAgIHJldHVybiB0aGVtICYmIHRoZW0ubGVuZ3RoICYmIHRoZW1bMF0ucGljdHVyZXMgJiYgdGhlbVswXS5waWN0dXJlcy5wcmltYXJ5ICYmIHRoZW1bMF0ucGljdHVyZXMucHJpbWFyeS51cmw7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeShyZXNwb25zZSkpXG4gICAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGlkZW50aXR5LmluZGV4T2YoXCJrZXliYXNlLmlvL3RlYW0vXCIpPjApe1xuICAgICAgICBsZXQgdGVhbVBhZ2UgPSBIVFRQLmdldChpZGVudGl0eSk7XG4gICAgICAgIGlmICh0ZWFtUGFnZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICBsZXQgcGFnZSA9IGNoZWVyaW8ubG9hZCh0ZWFtUGFnZS5jb250ZW50KTtcbiAgICAgICAgICAgIHJldHVybiBwYWdlKFwiLmtiLW1haW4tY2FyZCBpbWdcIikuYXR0cignc3JjJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeSh0ZWFtUGFnZSkpXG4gICAgICAgIH1cbiAgICB9XG59XG5cbi8vIHZhciBmaWx0ZXJlZCA9IFsxLCAyLCAzLCA0LCA1XS5maWx0ZXIobm90Q29udGFpbmVkSW4oWzEsIDIsIDMsIDVdKSk7XG4vLyBjb25zb2xlLmxvZyhmaWx0ZXJlZCk7IC8vIFs0XVxuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ2Jsb2Nrcy5hdmVyYWdlQmxvY2tUaW1lJyhhZGRyZXNzKXtcbiAgICAgICAgbGV0IGJsb2NrcyA9IEJsb2Nrc2Nvbi5maW5kKHtwcm9wb3NlckFkZHJlc3M6YWRkcmVzc30pLmZldGNoKCk7XG4gICAgICAgIGxldCBoZWlnaHRzID0gYmxvY2tzLm1hcCgoYmxvY2ssIGkpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBibG9jay5oZWlnaHQ7XG4gICAgICAgIH0pO1xuICAgICAgICBsZXQgYmxvY2tzU3RhdHMgPSBBbmFseXRpY3MuZmluZCh7aGVpZ2h0OnskaW46aGVpZ2h0c319KS5mZXRjaCgpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhibG9ja3NTdGF0cyk7XG5cbiAgICAgICAgbGV0IHRvdGFsQmxvY2tEaWZmID0gMDtcbiAgICAgICAgZm9yIChiIGluIGJsb2Nrc1N0YXRzKXtcbiAgICAgICAgICAgIHRvdGFsQmxvY2tEaWZmICs9IGJsb2Nrc1N0YXRzW2JdLnRpbWVEaWZmO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0b3RhbEJsb2NrRGlmZi9oZWlnaHRzLmxlbmd0aDtcbiAgICB9LFxuICAgICdibG9ja3MuZmluZFVwVGltZScoYWRkcmVzcyl7XG4gICAgICAgIGxldCBjb2xsZWN0aW9uID0gVmFsaWRhdG9yUmVjb3Jkcy5yYXdDb2xsZWN0aW9uKCk7XG4gICAgICAgIC8vIGxldCBhZ2dyZWdhdGVRdWVyeSA9IE1ldGVvci53cmFwQXN5bmMoY29sbGVjdGlvbi5hZ2dyZWdhdGUsIGNvbGxlY3Rpb24pO1xuICAgICAgICB2YXIgcGlwZWxpbmUgPSBbXG4gICAgICAgICAgICB7JG1hdGNoOntcImFkZHJlc3NcIjphZGRyZXNzfX0sXG4gICAgICAgICAgICAvLyB7JHByb2plY3Q6e2FkZHJlc3M6MSxoZWlnaHQ6MSxleGlzdHM6MX19LFxuICAgICAgICAgICAgeyRzb3J0OntcImhlaWdodFwiOi0xfX0sXG4gICAgICAgICAgICB7JGxpbWl0OihNZXRlb3Iuc2V0dGluZ3MucHVibGljLnVwdGltZVdpbmRvdy0xKX0sXG4gICAgICAgICAgICB7JHVud2luZDogXCIkX2lkXCJ9LFxuICAgICAgICAgICAgeyRncm91cDp7XG4gICAgICAgICAgICAgICAgXCJfaWRcIjogXCIkYWRkcmVzc1wiLFxuICAgICAgICAgICAgICAgIFwidXB0aW1lXCI6IHtcbiAgICAgICAgICAgICAgICAgICAgXCIkc3VtXCI6e1xuICAgICAgICAgICAgICAgICAgICAgICAgJGNvbmQ6IFt7JGVxOiBbJyRleGlzdHMnLCB0cnVlXX0sIDEsIDBdXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB9XTtcbiAgICAgICAgLy8gbGV0IHJlc3VsdCA9IGFnZ3JlZ2F0ZVF1ZXJ5KHBpcGVsaW5lLCB7IGN1cnNvcjoge30gfSk7XG5cbiAgICAgICAgcmV0dXJuIFByb21pc2UuYXdhaXQoY29sbGVjdGlvbi5hZ2dyZWdhdGUocGlwZWxpbmUpLnRvQXJyYXkoKSk7XG4gICAgICAgIC8vIHJldHVybiAuYWdncmVnYXRlKClcbiAgICB9LFxuICAgICdibG9ja3MuZ2V0TGF0ZXN0SGVpZ2h0JzogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgdXJsID0gUlBDKycvc3RhdHVzJztcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGxldCBzdGF0dXMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgcmV0dXJuIChzdGF0dXMucmVzdWx0LnN5bmNfaW5mby5sYXRlc3RfYmxvY2tfaGVpZ2h0KTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ2Jsb2Nrcy5nZXRDdXJyZW50SGVpZ2h0JzogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgY3VyckhlaWdodCA9IEJsb2Nrc2Nvbi5maW5kKHt9LHtzb3J0OntoZWlnaHQ6LTF9LGxpbWl0OjF9KS5mZXRjaCgpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhcImN1cnJlbnRIZWlnaHQ6XCIrY3VyckhlaWdodCk7XG4gICAgICAgIGxldCBzdGFydEhlaWdodCA9IE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuc3RhcnRIZWlnaHQ7XG4gICAgICAgIGlmIChjdXJySGVpZ2h0ICYmIGN1cnJIZWlnaHQubGVuZ3RoID09IDEpIHtcbiAgICAgICAgICAgIGxldCBoZWlnaHQgPSBjdXJySGVpZ2h0WzBdLmhlaWdodDtcbiAgICAgICAgICAgIGlmIChoZWlnaHQgPiBzdGFydEhlaWdodClcbiAgICAgICAgICAgICAgICByZXR1cm4gaGVpZ2h0XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN0YXJ0SGVpZ2h0XG4gICAgfSxcbiAgICAnYmxvY2tzLmJsb2Nrc1VwZGF0ZSc6IGZ1bmN0aW9uKCkge1xuICAgICAgICBpZiAoU1lOQ0lORylcbiAgICAgICAgICAgIHJldHVybiBcIlN5bmNpbmcuLi5cIjtcbiAgICAgICAgZWxzZSBjb25zb2xlLmxvZyhcInN0YXJ0IHRvIHN5bmNcIik7XG4gICAgICAgIC8vIE1ldGVvci5jbGVhckludGVydmFsKE1ldGVvci50aW1lckhhbmRsZSk7XG4gICAgICAgIC8vIGdldCB0aGUgbGF0ZXN0IGhlaWdodFxuICAgICAgICBsZXQgdW50aWwgPSBNZXRlb3IuY2FsbCgnYmxvY2tzLmdldExhdGVzdEhlaWdodCcpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyh1bnRpbCk7XG4gICAgICAgIC8vIGdldCB0aGUgY3VycmVudCBoZWlnaHQgaW4gZGJcbiAgICAgICAgbGV0IGN1cnIgPSBNZXRlb3IuY2FsbCgnYmxvY2tzLmdldEN1cnJlbnRIZWlnaHQnKTtcbiAgICAgICAgY29uc29sZS5sb2coY3Vycik7XG4gICAgICAgIC8vIGxvb3AgaWYgdGhlcmUncyB1cGRhdGUgaW4gZGJcbiAgICAgICAgaWYgKHVudGlsID4gY3Vycikge1xuICAgICAgICAgICAgU1lOQ0lORyA9IHRydWU7XG5cbiAgICAgICAgICAgIGxldCB2YWxpZGF0b3JTZXQgPSB7fVxuICAgICAgICAgICAgLy8gZ2V0IGxhdGVzdCB2YWxpZGF0b3IgY2FuZGlkYXRlIGluZm9ybWF0aW9uXG4gICAgICAgICAgICB1cmwgPSBMQ0QrJy9zdGFraW5nL3ZhbGlkYXRvcnMnO1xuXG4gICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgIEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0LmZvckVhY2goKHZhbGlkYXRvcikgPT4gdmFsaWRhdG9yU2V0W3ZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5XSA9IHZhbGlkYXRvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdXJsID0gTENEKycvc3Rha2luZy92YWxpZGF0b3JzP3N0YXR1cz11bmJvbmRpbmcnO1xuXG4gICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgIEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0LmZvckVhY2goKHZhbGlkYXRvcikgPT4gdmFsaWRhdG9yU2V0W3ZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5XSA9IHZhbGlkYXRvcilcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB1cmwgPSBMQ0QrJy9zdGFraW5nL3ZhbGlkYXRvcnM/c3RhdHVzPXVuYm9uZGVkJztcblxuICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdC5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHZhbGlkYXRvclNldFt2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleV0gPSB2YWxpZGF0b3IpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxldCB0b3RhbFZhbGlkYXRvcnMgPSBPYmplY3Qua2V5cyh2YWxpZGF0b3JTZXQpLmxlbmd0aDtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWxsIHZhbGlkYXRvcnM6IFwiKyB0b3RhbFZhbGlkYXRvcnMpO1xuICAgICAgICAgICAgZm9yIChsZXQgaGVpZ2h0ID0gY3VycisxIDsgaGVpZ2h0IDw9IHVudGlsIDsgaGVpZ2h0KyspIHtcbiAgICAgICAgICAgICAgICBsZXQgc3RhcnRCbG9ja1RpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgIC8vIGFkZCB0aW1lb3V0IGhlcmU/IGFuZCBvdXRzaWRlIHRoaXMgbG9vcCAoZm9yIGNhdGNoZWQgdXAgYW5kIGtlZXAgZmV0Y2hpbmcpP1xuICAgICAgICAgICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICAgICAgICAgIGxldCB1cmwgPSBSUEMrJy9ibG9jaz9oZWlnaHQ9JyArIGhlaWdodDtcbiAgICAgICAgICAgICAgICBsZXQgYW5hbHl0aWNzRGF0YSA9IHt9O1xuXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2codXJsKTtcbiAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtWYWxpZGF0b3JzID0gVmFsaWRhdG9ycy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBidWxrVmFsaWRhdG9yUmVjb3JkcyA9IFZhbGlkYXRvclJlY29yZHMucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AoKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYnVsa1ZQSGlzdG9yeSA9IFZvdGluZ1Bvd2VySGlzdG9yeS5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBidWxrVHJhbnNhdGlvbnMgPSBUcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AoKTtcblxuICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRHZXRIZWlnaHRUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBibG9jayA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9jayA9IGJsb2NrLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHN0b3JlIGhlaWdodCwgaGFzaCwgbnVtdHJhbnNhY3Rpb24gYW5kIHRpbWUgaW4gZGJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBibG9ja0RhdGEgPSB7fTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS5oZWlnaHQgPSBoZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEuaGFzaCA9IGJsb2NrLmJsb2NrX21ldGEuYmxvY2tfaWQuaGFzaDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS50cmFuc051bSA9IGJsb2NrLmJsb2NrX21ldGEuaGVhZGVyLm51bV90eHM7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEudGltZSA9IG5ldyBEYXRlKGJsb2NrLmJsb2NrLmhlYWRlci50aW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS5sYXN0QmxvY2tIYXNoID0gYmxvY2suYmxvY2suaGVhZGVyLmxhc3RfYmxvY2tfaWQuaGFzaDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS5wcm9wb3NlckFkZHJlc3MgPSBibG9jay5ibG9jay5oZWFkZXIucHJvcG9zZXJfYWRkcmVzcztcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS52YWxpZGF0b3JzID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJlY29tbWl0cyA9IGJsb2NrLmJsb2NrLmxhc3RfY29tbWl0LnByZWNvbW1pdHM7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJlY29tbWl0cyAhPSBudWxsKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhwcmVjb21taXRzLmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaT0wOyBpPHByZWNvbW1pdHMubGVuZ3RoOyBpKyspe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJlY29tbWl0c1tpXSAhPSBudWxsKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS52YWxpZGF0b3JzLnB1c2gocHJlY29tbWl0c1tpXS52YWxpZGF0b3JfYWRkcmVzcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLnByZWNvbW1pdHMgPSBwcmVjb21taXRzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyByZWNvcmQgZm9yIGFuYWx5dGljc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFByZWNvbW1pdFJlY29yZHMuaW5zZXJ0KHtoZWlnaHQ6aGVpZ2h0LCBwcmVjb21taXRzOnByZWNvbW1pdHMubGVuZ3RofSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHNhdmUgdHhzIGluIGRhdGFiYXNlXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYmxvY2suYmxvY2suZGF0YS50eHMgJiYgYmxvY2suYmxvY2suZGF0YS50eHMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh0IGluIGJsb2NrLmJsb2NrLmRhdGEudHhzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTWV0ZW9yLmNhbGwoJ1RyYW5zYWN0aW9ucy5pbmRleCcsIHNoYTI1NihCdWZmZXIuZnJvbShibG9jay5ibG9jay5kYXRhLnR4c1t0XSwgJ2Jhc2U2NCcpKSwgYmxvY2tEYXRhLnRpbWUsIChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzYXZlIGRvdWJsZSBzaWduIGV2aWRlbmNlc1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGJsb2NrLmJsb2NrLmV2aWRlbmNlLmV2aWRlbmNlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBFdmlkZW5jZXMuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBoZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV2aWRlbmNlOiBibG9jay5ibG9jay5ldmlkZW5jZS5ldmlkZW5jZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEucHJlY29tbWl0c0NvdW50ID0gYmxvY2tEYXRhLnZhbGlkYXRvcnMubGVuZ3RoO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLmhlaWdodCA9IGhlaWdodDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGVuZEdldEhlaWdodFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJHZXQgaGVpZ2h0IHRpbWU6IFwiKygoZW5kR2V0SGVpZ2h0VGltZS1zdGFydEdldEhlaWdodFRpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0R2V0VmFsaWRhdG9yc1RpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gdXBkYXRlIGNoYWluIHN0YXR1c1xuICAgICAgICAgICAgICAgICAgICAgICAgdXJsID0gUlBDKycvdmFsaWRhdG9ycz9oZWlnaHQ9JytoZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvcnMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9ycy5yZXN1bHQuYmxvY2tfaGVpZ2h0ID0gcGFyc2VJbnQodmFsaWRhdG9ycy5yZXN1bHQuYmxvY2tfaGVpZ2h0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIFZhbGlkYXRvclNldHMuaW5zZXJ0KHZhbGlkYXRvcnMucmVzdWx0KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLnZhbGlkYXRvcnNDb3VudCA9IHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnMubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0QmxvY2tJbnNlcnRUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIEJsb2Nrc2Nvbi5pbnNlcnQoYmxvY2tEYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlbmRCbG9ja0luc2VydFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJCbG9jayBpbnNlcnQgdGltZTogXCIrKChlbmRCbG9ja0luc2VydFRpbWUtc3RhcnRCbG9ja0luc2VydFRpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHN0b3JlIHZhbGRpYXRvcnMgZXhpc3QgcmVjb3Jkc1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGV4aXN0aW5nVmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7YWRkcmVzczp7JGV4aXN0czp0cnVlfX0pLmZldGNoKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChoZWlnaHQgPiAxKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyByZWNvcmQgcHJlY29tbWl0cyBhbmQgY2FsY3VsYXRlIHVwdGltZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIG9ubHkgcmVjb3JkIGZyb20gYmxvY2sgMlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoaSBpbiB2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGFkZHJlc3MgPSB2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzW2ldLmFkZHJlc3M7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZWNvcmQgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IGFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleGlzdHM6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiBwYXJzZUludCh2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzW2ldLnZvdGluZ19wb3dlcikvL2dldFZhbGlkYXRvclZvdGluZ1Bvd2VyKGV4aXN0aW5nVmFsaWRhdG9ycywgYWRkcmVzcylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoaiBpbiBwcmVjb21taXRzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmVjb21taXRzW2pdICE9IG51bGwpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhZGRyZXNzID09IHByZWNvbW1pdHNbal0udmFsaWRhdG9yX2FkZHJlc3Mpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWNvcmQuZXhpc3RzID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJlY29tbWl0cy5zcGxpY2UoaiwxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2FsY3VsYXRlIHRoZSB1cHRpbWUgYmFzZWQgb24gdGhlIHJlY29yZHMgc3RvcmVkIGluIHByZXZpb3VzIGJsb2Nrc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBvbmx5IGRvIHRoaXMgZXZlcnkgMTUgYmxvY2tzIH5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoKGhlaWdodCAlIDE1KSA9PSAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGxldCBzdGFydEFnZ1RpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG51bUJsb2NrcyA9IE1ldGVvci5jYWxsKCdibG9ja3MuZmluZFVwVGltZScsIGFkZHJlc3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHVwdGltZSA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBsZXQgZW5kQWdnVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcIkdldCBhZ2dyZWdhdGVkIHVwdGltZSBmb3IgXCIrZXhpc3RpbmdWYWxpZGF0b3JzW2ldLmFkZHJlc3MrXCI6IFwiKygoZW5kQWdnVGltZS1zdGFydEFnZ1RpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoKG51bUJsb2Nrc1swXSAhPSBudWxsKSAmJiAobnVtQmxvY2tzWzBdLnVwdGltZSAhPSBudWxsKSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXB0aW1lID0gbnVtQmxvY2tzWzBdLnVwdGltZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJhc2UgPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLnVwdGltZVdpbmRvdztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChoZWlnaHQgPCBiYXNlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYXNlID0gaGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVjb3JkLmV4aXN0cyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHVwdGltZSA8IGJhc2Upe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cHRpbWUrKztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXB0aW1lID0gKHVwdGltZSAvIGJhc2UpKjEwMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHthZGRyZXNzOmFkZHJlc3N9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6e3VwdGltZTp1cHRpbWUsIGxhc3RTZWVuOmJsb2NrRGF0YS50aW1lfX0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cHRpbWUgPSAodXB0aW1lIC8gYmFzZSkqMTAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JzLmZpbmQoe2FkZHJlc3M6YWRkcmVzc30pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDp7dXB0aW1lOnVwdGltZX19KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JSZWNvcmRzLmluc2VydChyZWNvcmQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBWYWxpZGF0b3JSZWNvcmRzLnVwZGF0ZSh7aGVpZ2h0OmhlaWdodCxhZGRyZXNzOnJlY29yZC5hZGRyZXNzfSxyZWNvcmQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNoYWluU3RhdHVzID0gQ2hhaW4uZmluZE9uZSh7Y2hhaW5JZDpibG9jay5ibG9ja19tZXRhLmhlYWRlci5jaGFpbl9pZH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGxhc3RTeW5jZWRUaW1lID0gY2hhaW5TdGF0dXM/Y2hhaW5TdGF0dXMubGFzdFN5bmNlZFRpbWU6MDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCB0aW1lRGlmZjtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBibG9ja1RpbWUgPSBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLmRlZmF1bHRCbG9ja1RpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobGFzdFN5bmNlZFRpbWUpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBkYXRlTGF0ZXN0ID0gYmxvY2tEYXRhLnRpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGVMYXN0ID0gbmV3IERhdGUobGFzdFN5bmNlZFRpbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpbWVEaWZmID0gTWF0aC5hYnMoZGF0ZUxhdGVzdC5nZXRUaW1lKCkgLSBkYXRlTGFzdC5nZXRUaW1lKCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrVGltZSA9IChjaGFpblN0YXR1cy5ibG9ja1RpbWUgKiAoYmxvY2tEYXRhLmhlaWdodCAtIDEpICsgdGltZURpZmYpIC8gYmxvY2tEYXRhLmhlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGVuZEdldFZhbGlkYXRvcnNUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiR2V0IGhlaWdodCB2YWxpZGF0b3JzIHRpbWU6IFwiKygoZW5kR2V0VmFsaWRhdG9yc1RpbWUtc3RhcnRHZXRWYWxpZGF0b3JzVGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOmJsb2NrLmJsb2NrX21ldGEuaGVhZGVyLmNoYWluX2lkfSwgeyRzZXQ6e2xhc3RTeW5jZWRUaW1lOmJsb2NrRGF0YS50aW1lLCBibG9ja1RpbWU6YmxvY2tUaW1lfX0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLmF2ZXJhZ2VCbG9ja1RpbWUgPSBibG9ja1RpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLnRpbWVEaWZmID0gdGltZURpZmY7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGFuYWx5dGljc0RhdGEudGltZSA9IGJsb2NrRGF0YS50aW1lO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBpbml0aWFsaXplIHZhbGlkYXRvciBkYXRhIGF0IGZpcnN0IGJsb2NrXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBpZiAoaGVpZ2h0ID09IDEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgIFZhbGlkYXRvcnMucmVtb3ZlKHt9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS52b3RpbmdfcG93ZXIgPSAwO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRGaW5kVmFsaWRhdG9yc05hbWVUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JzLnJlc3VsdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9ycyBhcmUgYWxsIHRoZSB2YWxpZGF0b3JzIGluIHRoZSBjdXJyZW50IGhlaWdodFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidmFsaWRhdG9yU2V0IHNpemU6IFwiK3ZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnMubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHYgaW4gdmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFZhbGlkYXRvcnMuaW5zZXJ0KHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnNbdl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yID0gdmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9yc1t2XTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnZvdGluZ19wb3dlciA9IHBhcnNlSW50KHZhbGlkYXRvci52b3RpbmdfcG93ZXIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHJvcG9zZXJfcHJpb3JpdHkgPSBwYXJzZUludCh2YWxpZGF0b3IucHJvcG9zZXJfcHJpb3JpdHkpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxFeGlzdCA9IFZhbGlkYXRvcnMuZmluZE9uZSh7XCJwdWJfa2V5LnZhbHVlXCI6dmFsaWRhdG9yLnB1Yl9rZXkudmFsdWV9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCF2YWxFeGlzdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgdmFsaWRhdG9yIHB1Yl9rZXkgJHt2YWxpZGF0b3IuYWRkcmVzc30gJHt2YWxpZGF0b3IucHViX2tleS52YWx1ZX0gbm90IGluIGRiYCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBsZXQgY29tbWFuZCA9IE1ldGVvci5zZXR0aW5ncy5iaW4uZ2FpYWRlYnVnK1wiIHB1YmtleSBcIit2YWxpZGF0b3IucHViX2tleS52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGNvbW1hbmQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGV0IHRlbXBWYWwgPSB2YWxpZGF0b3I7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5hZGRyZXNzID0gZ2V0QWRkcmVzcyh2YWxpZGF0b3IucHViX2tleSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYWNjcHViID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4QWNjUHViKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXkgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3IucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhWYWxQdWIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXkgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3IucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhDb25zUHViKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvckRhdGEgPSB2YWxpZGF0b3JTZXRbdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yRGF0YSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvckRhdGEuZGVzY3JpcHRpb24uaWRlbnRpdHkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5wcm9maWxlX3VybCA9ICBnZXRWYWxpZGF0b3JQcm9maWxlVXJsKHZhbGlkYXRvckRhdGEuZGVzY3JpcHRpb24uaWRlbnRpdHkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLm9wZXJhdG9yX2FkZHJlc3MgPSB2YWxpZGF0b3JEYXRhLm9wZXJhdG9yX2FkZHJlc3M7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmRlbGVnYXRvcl9hZGRyZXNzID0gTWV0ZW9yLmNhbGwoJ2dldERlbGVnYXRvcicsIHZhbGlkYXRvckRhdGEub3BlcmF0b3JfYWRkcmVzcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmphaWxlZCA9IHZhbGlkYXRvckRhdGEuamFpbGVkO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5zdGF0dXMgPSB2YWxpZGF0b3JEYXRhLnN0YXR1cztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IubWluX3NlbGZfZGVsZWdhdGlvbiA9IHZhbGlkYXRvckRhdGEubWluX3NlbGZfZGVsZWdhdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IudG9rZW5zID0gdmFsaWRhdG9yRGF0YS50b2tlbnM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmRlbGVnYXRvcl9zaGFyZXMgPSB2YWxpZGF0b3JEYXRhLmRlbGVnYXRvcl9zaGFyZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmRlc2NyaXB0aW9uID0gdmFsaWRhdG9yRGF0YS5kZXNjcmlwdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYm9uZF9oZWlnaHQgPSB2YWxpZGF0b3JEYXRhLmJvbmRfaGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5ib25kX2ludHJhX3R4X2NvdW50ZXIgPSB2YWxpZGF0b3JEYXRhLmJvbmRfaW50cmFfdHhfY291bnRlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IudW5ib25kaW5nX2hlaWdodCA9IHZhbGlkYXRvckRhdGEudW5ib25kaW5nX2hlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IudW5ib25kaW5nX3RpbWUgPSB2YWxpZGF0b3JEYXRhLnVuYm9uZGluZ190aW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5jb21taXNzaW9uID0gdmFsaWRhdG9yRGF0YS5jb21taXNzaW9uO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5zZWxmX2RlbGVnYXRpb24gPSB2YWxpZGF0b3IuZGVsZWdhdG9yX3NoYXJlcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IucmVtb3ZlZCA9IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5yZW1vdmVkQXQgPSAwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yU2V0LnNwbGljZSh2YWwsIDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnbm8gY29uIHB1YiBrZXk/JylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gYnVsa1ZhbGlkYXRvcnMuaW5zZXJ0KHZhbGlkYXRvcik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHtjb25zZW5zdXNfcHVia2V5OiB2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleX0pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDp2YWxpZGF0b3J9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwidmFsaWRhdG9yIGZpcnN0IGFwcGVhcnM6IFwiK2J1bGtWYWxpZGF0b3JzLmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVlBIaXN0b3J5Lmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogdmFsaWRhdG9yLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdhZGQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogYmxvY2tEYXRhLmhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja190aW1lOiBibG9ja0RhdGEudGltZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE1ldGVvci5jYWxsKCdydW5Db2RlJywgY29tbWFuZCwgZnVuY3Rpb24oZXJyb3IsIHJlc3VsdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuYWRkcmVzcyA9IHJlc3VsdC5tYXRjaCgvXFxzWzAtOUEtRl17NDB9JC9pZ20pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmFkZHJlc3MgPSB2YWxpZGF0b3IuYWRkcmVzc1swXS50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuaGV4ID0gcmVzdWx0Lm1hdGNoKC9cXHNbMC05QS1GXXs2NH0kL2lnbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuaGV4ID0gdmFsaWRhdG9yLmhleFswXS50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuY29zbW9zYWNjcHViID0gcmVzdWx0Lm1hdGNoKC9jb3Ntb3NwdWIuKiQvaWdtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5jb3Ntb3NhY2NwdWIgPSB2YWxpZGF0b3IuY29zbW9zYWNjcHViWzBdLnRyaW0oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXkgPSByZXN1bHQubWF0Y2goL2Nvc21vc3ZhbG9wZXJwdWIuKiQvaWdtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXkgPSB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5WzBdLnRyaW0oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5ID0gcmVzdWx0Lm1hdGNoKC9jb3Ntb3N2YWxjb25zcHViLiokL2lnbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleSA9IHZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5WzBdLnRyaW0oKTtcblxuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yRGF0YSA9IHZhbGlkYXRvclNldFt2YWxFeGlzdC5jb25zZW5zdXNfcHVia2V5XVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvckRhdGEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JEYXRhLmRlc2NyaXB0aW9uICYmICghdmFsRXhpc3QuZGVzY3JpcHRpb24gfHwgdmFsaWRhdG9yRGF0YS5kZXNjcmlwdGlvbi5pZGVudGl0eSAhPT0gdmFsRXhpc3QuZGVzY3JpcHRpb24uaWRlbnRpdHkpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHJvZmlsZV91cmwgPSAgZ2V0VmFsaWRhdG9yUHJvZmlsZVVybCh2YWxpZGF0b3JEYXRhLmRlc2NyaXB0aW9uLmlkZW50aXR5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5qYWlsZWQgPSB2YWxpZGF0b3JEYXRhLmphaWxlZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iuc3RhdHVzID0gdmFsaWRhdG9yRGF0YS5zdGF0dXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnRva2VucyA9IHZhbGlkYXRvckRhdGEudG9rZW5zO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzID0gdmFsaWRhdG9yRGF0YS5kZWxlZ2F0b3Jfc2hhcmVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZXNjcmlwdGlvbiA9IHZhbGlkYXRvckRhdGEuZGVzY3JpcHRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmJvbmRfaGVpZ2h0ID0gdmFsaWRhdG9yRGF0YS5ib25kX2hlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYm9uZF9pbnRyYV90eF9jb3VudGVyID0gdmFsaWRhdG9yRGF0YS5ib25kX2ludHJhX3R4X2NvdW50ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnVuYm9uZGluZ19oZWlnaHQgPSB2YWxpZGF0b3JEYXRhLnVuYm9uZGluZ19oZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnVuYm9uZGluZ190aW1lID0gdmFsaWRhdG9yRGF0YS51bmJvbmRpbmdfdGltZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuY29tbWlzc2lvbiA9IHZhbGlkYXRvckRhdGEuY29tbWlzc2lvbjtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNhbGN1bGF0ZSBzZWxmIGRlbGVnYXRpb24gcGVyY2VudGFnZSBldmVyeSAzMCBibG9ja3NcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChoZWlnaHQgJSAzMCA9PSAxKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQoTENEICsgJy9zdGFraW5nL2RlbGVnYXRvcnMvJyt2YWxFeGlzdC5kZWxlZ2F0b3JfYWRkcmVzcysnL2RlbGVnYXRpb25zLycrdmFsRXhpc3Qub3BlcmF0b3JfYWRkcmVzcyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHNlbGZEZWxlZ2F0aW9uID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNlbGZEZWxlZ2F0aW9uLnNoYXJlcyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5zZWxmX2RlbGVnYXRpb24gPSBwYXJzZUZsb2F0KHNlbGZEZWxlZ2F0aW9uLnNoYXJlcykvcGFyc2VGbG9hdCh2YWxpZGF0b3IuZGVsZWdhdG9yX3NoYXJlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHtjb25zZW5zdXNfcHVia2V5OiB2YWxFeGlzdC5jb25zZW5zdXNfcHVia2V5fSkudXBkYXRlT25lKHskc2V0OnZhbGlkYXRvcn0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwidmFsaWRhdG9yIGV4aXNpdHM6IFwiK2J1bGtWYWxpZGF0b3JzLmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yU2V0LnNwbGljZSh2YWwsIDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ25vIGNvbiBwdWIga2V5PycpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJldlZvdGluZ1Bvd2VyID0gVm90aW5nUG93ZXJIaXN0b3J5LmZpbmRPbmUoe2FkZHJlc3M6dmFsaWRhdG9yLmFkZHJlc3N9LCB7aGVpZ2h0Oi0xLCBsaW1pdDoxfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmV2Vm90aW5nUG93ZXIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmV2Vm90aW5nUG93ZXIudm90aW5nX3Bvd2VyICE9IHZhbGlkYXRvci52b3RpbmdfcG93ZXIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgY2hhbmdlVHlwZSA9IChwcmV2Vm90aW5nUG93ZXIudm90aW5nX3Bvd2VyID4gdmFsaWRhdG9yLnZvdGluZ19wb3dlcik/J2Rvd24nOid1cCc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjaGFuZ2VEYXRhID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogdmFsaWRhdG9yLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmV2X3ZvdGluZ19wb3dlcjogcHJldlZvdGluZ1Bvd2VyLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogdmFsaWRhdG9yLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IGNoYW5nZVR5cGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGJsb2NrRGF0YS5oZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja190aW1lOiBibG9ja0RhdGEudGltZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygndm90aW5nIHBvd2VyIGNoYW5nZWQuJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGNoYW5nZURhdGEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVlBIaXN0b3J5Lmluc2VydChjaGFuZ2VEYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2codmFsaWRhdG9yKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLnZvdGluZ19wb3dlciArPSB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGlmIHRoZXJlIGlzIHZhbGlkYXRvciByZW1vdmVkXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJldlZhbGlkYXRvcnMgPSBWYWxpZGF0b3JTZXRzLmZpbmRPbmUoe2Jsb2NrX2hlaWdodDpoZWlnaHQtMX0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByZXZWYWxpZGF0b3JzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlbW92ZWRWYWxpZGF0b3JzID0gZ2V0UmVtb3ZlZFZhbGlkYXRvcnMocHJldlZhbGlkYXRvcnMudmFsaWRhdG9ycywgdmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9ycyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChyIGluIHJlbW92ZWRWYWxpZGF0b3JzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWUEhpc3RvcnkuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOiByZW1vdmVkVmFsaWRhdG9yc1tyXS5hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZXZfdm90aW5nX3Bvd2VyOiByZW1vdmVkVmFsaWRhdG9yc1tyXS52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdyZW1vdmUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogYmxvY2tEYXRhLmhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja190aW1lOiBibG9ja0RhdGEudGltZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjaGVjayBpZiB0aGVyZSdzIGFueSB2YWxpZGF0b3Igbm90IGluIGRiIDE0NDAwIGJsb2Nrcyh+MSBkYXkpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVpZ2h0ICUgMTQ0MDAgPT0gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0NoZWNraW5nIGFsbCB2YWxpZGF0b3JzIGFnYWluc3QgZGIuLi4nKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgZGJWYWxpZGF0b3JzID0ge31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVmFsaWRhdG9ycy5maW5kKHt9LCB7ZmllbGRzOiB7Y29uc2Vuc3VzX3B1YmtleTogMSwgc3RhdHVzOiAxfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkuZm9yRWFjaCgodikgPT4gZGJWYWxpZGF0b3JzW3YuY29uc2Vuc3VzX3B1YmtleV0gPSB2LnN0YXR1cylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT2JqZWN0LmtleXModmFsaWRhdG9yU2V0KS5mb3JFYWNoKChjb25QdWJLZXkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3JEYXRhID0gdmFsaWRhdG9yU2V0W2NvblB1YktleV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBBY3RpdmUgdmFsaWRhdG9ycyBzaG91bGQgaGF2ZSBiZWVuIHVwZGF0ZWQgaW4gcHJldmlvdXMgc3RlcHNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JEYXRhLnN0YXR1cyA9PT0gMilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGRiVmFsaWRhdG9yc1tjb25QdWJLZXldID09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGB2YWxpZGF0b3Igd2l0aCBjb25zZW5zdXNfcHVia2V5ICR7Y29uUHViS2V5fSBub3QgaW4gZGJgKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvckRhdGEucHViX2tleSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCIgOiBcInRlbmRlcm1pbnQvUHViS2V5RWQyNTUxOVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInZhbHVlXCI6IE1ldGVvci5jYWxsKCdiZWNoMzJUb1B1YmtleScsIGNvblB1YktleSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yRGF0YS5hZGRyZXNzID0gZ2V0QWRkcmVzcyh2YWxpZGF0b3JEYXRhLnB1Yl9rZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvckRhdGEuZGVsZWdhdG9yX2FkZHJlc3MgPSBNZXRlb3IuY2FsbCgnZ2V0RGVsZWdhdG9yJywgdmFsaWRhdG9yRGF0YS5vcGVyYXRvcl9hZGRyZXNzKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvckRhdGEuYWNjcHViID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yRGF0YS5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY1B1Yik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yRGF0YS5vcGVyYXRvcl9wdWJrZXkgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3JEYXRhLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsUHViKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeSh2YWxpZGF0b3JEYXRhKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHtjb25zZW5zdXNfcHVia2V5OiBjb25QdWJLZXl9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6dmFsaWRhdG9yRGF0YX0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChkYlZhbGlkYXRvcnNbY29uUHViS2V5XSA9PSAyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7Y29uc2Vuc3VzX3B1YmtleTogY29uUHViS2V5fSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OnZhbGlkYXRvckRhdGF9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGZldGNoaW5nIGtleWJhc2UgZXZlcnkgMTQ0MDAgYmxvY2tzKH4xIGRheSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChoZWlnaHQgJSAxNDQwMCA9PSAxKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnRmV0Y2hpbmcga2V5YmFzZS4uLicpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVmFsaWRhdG9ycy5maW5kKHt9KS5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwcm9maWxlVXJsID0gIGdldFZhbGlkYXRvclByb2ZpbGVVcmwodmFsaWRhdG9yLmRlc2NyaXB0aW9uLmlkZW50aXR5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByb2ZpbGVVcmwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHthZGRyZXNzOiB2YWxpZGF0b3IuYWRkcmVzc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6eydwcm9maWxlX3VybCc6cHJvZmlsZVVybH19KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlbmRGaW5kVmFsaWRhdG9yc05hbWVUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiR2V0IHZhbGlkYXRvcnMgbmFtZSB0aW1lOiBcIisoKGVuZEZpbmRWYWxpZGF0b3JzTmFtZVRpbWUtc3RhcnRGaW5kVmFsaWRhdG9yc05hbWVUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyByZWNvcmQgZm9yIGFuYWx5dGljc1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0QW5heXRpY3NJbnNlcnRUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIEFuYWx5dGljcy5pbnNlcnQoYW5hbHl0aWNzRGF0YSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZW5kQW5hbHl0aWNzSW5zZXJ0VGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkFuYWx5dGljcyBpbnNlcnQgdGltZTogXCIrKChlbmRBbmFseXRpY3NJbnNlcnRUaW1lLXN0YXJ0QW5heXRpY3NJbnNlcnRUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRWVXBUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChidWxrVmFsaWRhdG9ycy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhidWxrVmFsaWRhdG9ycy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JzLmV4ZWN1dGUoKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGVuZFZVcFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJWYWxpZGF0b3IgdXBkYXRlIHRpbWU6IFwiKygoZW5kVlVwVGltZS1zdGFydFZVcFRpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzdGFydFZSVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYnVsa1ZhbGlkYXRvclJlY29yZHMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvclJlY29yZHMuZXhlY3V0ZSgoZXJyLCByZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlbmRWUlRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJWYWxpZGF0b3IgcmVjb3JkcyB1cGRhdGUgdGltZTogXCIrKChlbmRWUlRpbWUtc3RhcnRWUlRpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChidWxrVlBIaXN0b3J5Lmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWUEhpc3RvcnkuZXhlY3V0ZSgoZXJyLCByZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChidWxrVHJhbnNhdGlvbnMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1RyYW5zYXRpb25zLmV4ZWN1dGUoKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjYWxjdWxhdGUgdm90aW5nIHBvd2VyIGRpc3RyaWJ1dGlvbiBldmVyeSA2MCBibG9ja3MgfiA1bWluc1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVpZ2h0ICUgNjAgPT0gMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCI9PT09PSBjYWxjdWxhdGUgdm90aW5nIHBvd2VyIGRpc3RyaWJ1dGlvbiA9PT09PVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgYWN0aXZlVmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7c3RhdHVzOjIsamFpbGVkOmZhbHNlfSx7c29ydDp7dm90aW5nX3Bvd2VyOi0xfX0pLmZldGNoKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG51bVRvcFR3ZW50eSA9IE1hdGguY2VpbChhY3RpdmVWYWxpZGF0b3JzLmxlbmd0aCowLjIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBudW1Cb3R0b21FaWdodHkgPSBhY3RpdmVWYWxpZGF0b3JzLmxlbmd0aCAtIG51bVRvcFR3ZW50eTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB0b3BUd2VudHlQb3dlciA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJvdHRvbUVpZ2h0eVBvd2VyID0gMDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBudW1Ub3BUaGlydHlGb3VyID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgbnVtQm90dG9tU2l4dHlTaXggPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB0b3BUaGlydHlGb3VyUGVyY2VudCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJvdHRvbVNpeHR5U2l4UGVyY2VudCA9IDA7XG5cblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2IGluIGFjdGl2ZVZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodiA8IG51bVRvcFR3ZW50eSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3BUd2VudHlQb3dlciArPSBhY3RpdmVWYWxpZGF0b3JzW3ZdLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNle1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm90dG9tRWlnaHR5UG93ZXIgKz0gYWN0aXZlVmFsaWRhdG9yc1t2XS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0b3BUaGlydHlGb3VyUGVyY2VudCA8IDAuMzQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wVGhpcnR5Rm91clBlcmNlbnQgKz0gYWN0aXZlVmFsaWRhdG9yc1t2XS52b3RpbmdfcG93ZXIgLyBhbmFseXRpY3NEYXRhLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bVRvcFRoaXJ0eUZvdXIrKztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvdHRvbVNpeHR5U2l4UGVyY2VudCA9IDEgLSB0b3BUaGlydHlGb3VyUGVyY2VudDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Cb3R0b21TaXh0eVNpeCA9IGFjdGl2ZVZhbGlkYXRvcnMubGVuZ3RoIC0gbnVtVG9wVGhpcnR5Rm91cjtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2cERpc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Ub3BUd2VudHk6IG51bVRvcFR3ZW50eSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wVHdlbnR5UG93ZXI6IHRvcFR3ZW50eVBvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Cb3R0b21FaWdodHk6IG51bUJvdHRvbUVpZ2h0eSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm90dG9tRWlnaHR5UG93ZXI6IGJvdHRvbUVpZ2h0eVBvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Ub3BUaGlydHlGb3VyOiBudW1Ub3BUaGlydHlGb3VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3BUaGlydHlGb3VyUGVyY2VudDogdG9wVGhpcnR5Rm91clBlcmNlbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bUJvdHRvbVNpeHR5U2l4OiBudW1Cb3R0b21TaXh0eVNpeCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm90dG9tU2l4dHlTaXhQZXJjZW50OiBib3R0b21TaXh0eVNpeFBlcmNlbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bVZhbGlkYXRvcnM6IGFjdGl2ZVZhbGlkYXRvcnMubGVuZ3RoLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbFZvdGluZ1Bvd2VyOiBhbmFseXRpY3NEYXRhLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tUaW1lOiBibG9ja0RhdGEudGltZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3JlYXRlQXQ6IG5ldyBEYXRlKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh2cERpc3QpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVlBEaXN0cmlidXRpb25zLmluc2VydCh2cERpc3QpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgICAgIFNZTkNJTkcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiU3RvcHBlZFwiO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBsZXQgZW5kQmxvY2tUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlRoaXMgYmxvY2sgdXNlZDogXCIrKChlbmRCbG9ja1RpbWUtc3RhcnRCbG9ja1RpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBTWU5DSU5HID0gZmFsc2U7XG4gICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSwgeyRzZXQ6e2xhc3RCbG9ja3NTeW5jZWRUaW1lOm5ldyBEYXRlKCksIHRvdGFsVmFsaWRhdG9yczp0b3RhbFZhbGlkYXRvcnN9fSk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdW50aWw7XG4gICAgfSxcbiAgICAnYWRkTGltaXQnOiBmdW5jdGlvbihsaW1pdCkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhsaW1pdCsxMClcbiAgICAgICAgcmV0dXJuIChsaW1pdCsxMCk7XG4gICAgfSxcbiAgICAnaGFzTW9yZSc6IGZ1bmN0aW9uKGxpbWl0KSB7XG4gICAgICAgIGlmIChsaW1pdCA+IE1ldGVvci5jYWxsKCdnZXRDdXJyZW50SGVpZ2h0JykpIHtcbiAgICAgICAgICAgIHJldHVybiAoZmFsc2UpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuICh0cnVlKTtcbiAgICAgICAgfVxuICAgIH1cbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBCbG9ja3Njb24gfSBmcm9tICcuLi9ibG9ja3MuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi8uLi90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzJztcblxucHVibGlzaENvbXBvc2l0ZSgnYmxvY2tzLmhlaWdodCcsIGZ1bmN0aW9uKGxpbWl0KXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmQoe30sIHtsaW1pdDogbGltaXQsIHNvcnQ6IHtoZWlnaHQ6IC0xfX0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZChibG9jayl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWRkcmVzczpibG9jay5wcm9wb3NlckFkZHJlc3N9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2xpbWl0OjF9XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgnYmxvY2tzLmZpbmRPbmUnLCBmdW5jdGlvbihoZWlnaHQpe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZCh7aGVpZ2h0OmhlaWdodH0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZChibG9jayl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBUcmFuc2FjdGlvbnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHtoZWlnaHQ6YmxvY2suaGVpZ2h0fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKGJsb2NrKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHthZGRyZXNzOmJsb2NrLnByb3Bvc2VyQWRkcmVzc30sXG4gICAgICAgICAgICAgICAgICAgICAgICB7bGltaXQ6MX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5cbmV4cG9ydCBjb25zdCBCbG9ja3Njb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignYmxvY2tzJyk7XG5cbkJsb2Nrc2Nvbi5oZWxwZXJzKHtcbiAgICBwcm9wb3Nlcigpe1xuICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kT25lKHthZGRyZXNzOnRoaXMucHJvcG9zZXJBZGRyZXNzfSk7XG4gICAgfVxufSk7XG5cbi8vIEJsb2Nrc2Nvbi5oZWxwZXJzKHtcbi8vICAgICBzb3J0ZWQobGltaXQpIHtcbi8vICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKHt9LCB7c29ydDoge2hlaWdodDotMX0sIGxpbWl0OiBsaW1pdH0pO1xuLy8gICAgIH1cbi8vIH0pO1xuXG5cbi8vIE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpIHtcbi8vICAgICBNZXRlb3IuY2FsbCgnYmxvY2tzVXBkYXRlJywgKGVycm9yLCByZXN1bHQpID0+IHtcbi8vICAgICAgICAgY29uc29sZS5sb2cocmVzdWx0KTtcbi8vICAgICB9KVxuLy8gfSwgMzAwMDAwMDApOyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IGdldEFkZHJlc3MgfSBmcm9tICd0ZW5kZXJtaW50L2xpYi9wdWJrZXkuanMnO1xuaW1wb3J0IHsgQ2hhaW4sIENoYWluU3RhdGVzIH0gZnJvbSAnLi4vY2hhaW4uanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBWb3RpbmdQb3dlckhpc3RvcnkgfSBmcm9tICcuLi8uLi92b3RpbmctcG93ZXIvaGlzdG9yeS5qcyc7XG5cbmZpbmRWb3RpbmdQb3dlciA9ICh2YWxpZGF0b3IsIGdlblZhbGlkYXRvcnMpID0+IHtcbiAgICBmb3IgKGxldCB2IGluIGdlblZhbGlkYXRvcnMpe1xuICAgICAgICBpZiAodmFsaWRhdG9yLnB1Yl9rZXkudmFsdWUgPT0gZ2VuVmFsaWRhdG9yc1t2XS5wdWJfa2V5LnZhbHVlKXtcbiAgICAgICAgICAgIHJldHVybiBwYXJzZUludChnZW5WYWxpZGF0b3JzW3ZdLnBvd2VyKTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdjaGFpbi5nZXRDb25zZW5zdXNTdGF0ZSc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgdXJsID0gUlBDKycvZHVtcF9jb25zZW5zdXNfc3RhdGUnO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgbGV0IGNvbnNlbnN1cyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICBjb25zZW5zdXMgPSBjb25zZW5zdXMucmVzdWx0O1xuICAgICAgICAgICAgbGV0IGhlaWdodCA9IGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS5oZWlnaHQ7XG4gICAgICAgICAgICBsZXQgcm91bmQgPSBjb25zZW5zdXMucm91bmRfc3RhdGUucm91bmQ7XG4gICAgICAgICAgICBsZXQgc3RlcCA9IGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS5zdGVwO1xuICAgICAgICAgICAgbGV0IHZvdGVkUG93ZXIgPSBNYXRoLnJvdW5kKHBhcnNlRmxvYXQoY29uc2Vuc3VzLnJvdW5kX3N0YXRlLnZvdGVzW3JvdW5kXS5wcmV2b3Rlc19iaXRfYXJyYXkuc3BsaXQoXCIgXCIpWzNdKSoxMDApO1xuXG4gICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSwgeyRzZXQ6e1xuICAgICAgICAgICAgICAgIHZvdGluZ0hlaWdodDogaGVpZ2h0LFxuICAgICAgICAgICAgICAgIHZvdGluZ1JvdW5kOiByb3VuZCxcbiAgICAgICAgICAgICAgICB2b3RpbmdTdGVwOiBzdGVwLFxuICAgICAgICAgICAgICAgIHZvdGVkUG93ZXI6IHZvdGVkUG93ZXIsXG4gICAgICAgICAgICAgICAgcHJvcG9zZXJBZGRyZXNzOiBjb25zZW5zdXMucm91bmRfc3RhdGUudmFsaWRhdG9ycy5wcm9wb3Nlci5hZGRyZXNzLFxuICAgICAgICAgICAgICAgIHByZXZvdGVzOiBjb25zZW5zdXMucm91bmRfc3RhdGUudm90ZXNbcm91bmRdLnByZXZvdGVzLFxuICAgICAgICAgICAgICAgIHByZWNvbW1pdHM6IGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS52b3Rlc1tyb3VuZF0ucHJlY29tbWl0c1xuICAgICAgICAgICAgfX0pO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdjaGFpbi51cGRhdGVTdGF0dXMnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHVybCA9IFJQQysnL3N0YXR1cyc7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBsZXQgc3RhdHVzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgIHN0YXR1cyA9IHN0YXR1cy5yZXN1bHQ7XG4gICAgICAgICAgICBsZXQgY2hhaW4gPSB7fTtcbiAgICAgICAgICAgIGNoYWluLmNoYWluSWQgPSBzdGF0dXMubm9kZV9pbmZvLm5ldHdvcms7XG4gICAgICAgICAgICBjaGFpbi5sYXRlc3RCbG9ja0hlaWdodCA9IHN0YXR1cy5zeW5jX2luZm8ubGF0ZXN0X2Jsb2NrX2hlaWdodDtcbiAgICAgICAgICAgIGNoYWluLmxhdGVzdEJsb2NrVGltZSA9IHN0YXR1cy5zeW5jX2luZm8ubGF0ZXN0X2Jsb2NrX3RpbWU7XG5cbiAgICAgICAgICAgIGxldCBsYXRlc3RTdGF0ZSA9IENoYWluU3RhdGVzLmZpbmRPbmUoe30sIHtzb3J0OiB7aGVpZ2h0OiAtMX19KVxuICAgICAgICAgICAgaWYgKGxhdGVzdFN0YXRlICYmIGxhdGVzdFN0YXRlLmhlaWdodCA+PSBjaGFpbi5sYXRlc3RCbG9ja0hlaWdodCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBgbm8gdXBkYXRlcyAoZ2V0dGluZyBibG9jayAke2NoYWluLmxhdGVzdEJsb2NrSGVpZ2h0fSBhdCBibG9jayAke2xhdGVzdFN0YXRlLmhlaWdodH0pYFxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB1cmwgPSBSUEMrJy92YWxpZGF0b3JzJztcbiAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGxldCB2YWxpZGF0b3JzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgIHZhbGlkYXRvcnMgPSB2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzO1xuICAgICAgICAgICAgY2hhaW4udmFsaWRhdG9ycyA9IHZhbGlkYXRvcnMubGVuZ3RoO1xuICAgICAgICAgICAgbGV0IGFjdGl2ZVZQID0gMDtcbiAgICAgICAgICAgIGZvciAodiBpbiB2YWxpZGF0b3JzKXtcbiAgICAgICAgICAgICAgICBhY3RpdmVWUCArPSBwYXJzZUludCh2YWxpZGF0b3JzW3ZdLnZvdGluZ19wb3dlcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjaGFpbi5hY3RpdmVWb3RpbmdQb3dlciA9IGFjdGl2ZVZQO1xuXG5cbiAgICAgICAgICAgIENoYWluLnVwZGF0ZSh7Y2hhaW5JZDpjaGFpbi5jaGFpbklkfSwgeyRzZXQ6Y2hhaW59LCB7dXBzZXJ0OiB0cnVlfSk7XG4gICAgICAgICAgICAvLyBHZXQgY2hhaW4gc3RhdGVzXG4gICAgICAgICAgICBpZiAocGFyc2VJbnQoY2hhaW4ubGF0ZXN0QmxvY2tIZWlnaHQpID4gMCl7XG4gICAgICAgICAgICAgICAgbGV0IGNoYWluU3RhdGVzID0ge307XG4gICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMuaGVpZ2h0ID0gcGFyc2VJbnQoc3RhdHVzLnN5bmNfaW5mby5sYXRlc3RfYmxvY2tfaGVpZ2h0KTtcbiAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy50aW1lID0gbmV3IERhdGUoc3RhdHVzLnN5bmNfaW5mby5sYXRlc3RfYmxvY2tfdGltZSk7XG5cbiAgICAgICAgICAgICAgICB1cmwgPSBMQ0QgKyAnL3N0YWtpbmcvcG9vbCc7XG4gICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBib25kaW5nID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNoYWluLmJvbmRlZFRva2VucyA9IGJvbmRpbmcuYm9uZGVkX3Rva2VucztcbiAgICAgICAgICAgICAgICAgICAgLy8gY2hhaW4ubm90Qm9uZGVkVG9rZW5zID0gYm9uZGluZy5ub3RfYm9uZGVkX3Rva2VucztcbiAgICAgICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMuYm9uZGVkVG9rZW5zID0gcGFyc2VJbnQoYm9uZGluZy5ib25kZWRfdG9rZW5zKTtcbiAgICAgICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMubm90Qm9uZGVkVG9rZW5zID0gcGFyc2VJbnQoYm9uZGluZy5ub3RfYm9uZGVkX3Rva2Vucyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB1cmwgPSBMQ0QgKyAnL3N1cHBseS90b3RhbC8nK01ldGVvci5zZXR0aW5ncy5wdWJsaWMubWludGluZ0Rlbm9tO1xuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgc3VwcGx5ID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLnRvdGFsU3VwcGx5ID0gcGFyc2VJbnQoc3VwcGx5KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHVybCA9IExDRCArICcvZGlzdHJpYnV0aW9uL2NvbW11bml0eV9wb29sJztcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBwb29sID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwb29sICYmIHBvb2wubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5jb21tdW5pdHlQb29sID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICBwb29sLmZvckVhY2goKGFtb3VudCwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLmNvbW11bml0eVBvb2wucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbm9tOiBhbW91bnQuZGVub20sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFtb3VudDogcGFyc2VGbG9hdChhbW91bnQuYW1vdW50KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB1cmwgPSBMQ0QgKyAnL21pbnRpbmcvaW5mbGF0aW9uJztcbiAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGluZmxhdGlvbiA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICBpZiAoaW5mbGF0aW9uKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLmluZmxhdGlvbiA9IHBhcnNlRmxvYXQoaW5mbGF0aW9uKVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB1cmwgPSBMQ0QgKyAnL21pbnRpbmcvYW5udWFsLXByb3Zpc2lvbnMnO1xuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgcHJvdmlzaW9ucyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm92aXNpb25zKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLmFubnVhbFByb3Zpc2lvbnMgPSBwYXJzZUZsb2F0KHByb3Zpc2lvbnMucmVzdWx0KVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBDaGFpblN0YXRlcy5pbnNlcnQoY2hhaW5TdGF0ZXMpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBjaGFpbi50b3RhbFZvdGluZ1Bvd2VyID0gdG90YWxWUDtcblxuICAgICAgICAgICAgLy8gdmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7fSkuZmV0Y2goKTtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHZhbGlkYXRvcnMpO1xuICAgICAgICAgICAgcmV0dXJuIGNoYWluLmxhdGVzdEJsb2NrSGVpZ2h0O1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgcmV0dXJuIFwiRXJyb3IgZ2V0dGluZyBjaGFpbiBzdGF0dXMuXCI7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdjaGFpbi5nZXRMYXRlc3RTdGF0dXMnOiBmdW5jdGlvbigpe1xuICAgICAgICBDaGFpbi5maW5kKCkuc29ydCh7Y3JlYXRlZDotMX0pLmxpbWl0KDEpO1xuICAgIH0sXG4gICAgJ2NoYWluLmdlbmVzaXMnOiBmdW5jdGlvbigpe1xuICAgICAgICBsZXQgY2hhaW4gPSBDaGFpbi5maW5kT25lKHtjaGFpbklkOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9KTtcblxuICAgICAgICBpZiAoY2hhaW4gJiYgY2hhaW4ucmVhZEdlbmVzaXMpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ0dlbmVzaXMgZmlsZSBoYXMgYmVlbiBwcm9jZXNzZWQnKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChNZXRlb3Iuc2V0dGluZ3MuZGVidWcucmVhZEdlbmVzaXMpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCc9PT0gU3RhcnQgcHJvY2Vzc2luZyBnZW5lc2lzIGZpbGUgPT09Jyk7XG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldChNZXRlb3Iuc2V0dGluZ3MuZ2VuZXNpc0ZpbGUpO1xuICAgICAgICAgICAgbGV0IGdlbmVzaXMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgbGV0IGRpc3RyID0gZ2VuZXNpcy5hcHBfc3RhdGUuZGlzdHIgfHwgZ2VuZXNpcy5hcHBfc3RhdGUuZGlzdHJpYnV0aW9uXG4gICAgICAgICAgICBsZXQgY2hhaW5QYXJhbXMgPSB7XG4gICAgICAgICAgICAgICAgY2hhaW5JZDogZ2VuZXNpcy5jaGFpbl9pZCxcbiAgICAgICAgICAgICAgICBnZW5lc2lzVGltZTogZ2VuZXNpcy5nZW5lc2lzX3RpbWUsXG4gICAgICAgICAgICAgICAgY29uc2Vuc3VzUGFyYW1zOiBnZW5lc2lzLmNvbnNlbnN1c19wYXJhbXMsXG4gICAgICAgICAgICAgICAgYXV0aDogZ2VuZXNpcy5hcHBfc3RhdGUuYXV0aCxcbiAgICAgICAgICAgICAgICBiYW5rOiBnZW5lc2lzLmFwcF9zdGF0ZS5iYW5rLFxuICAgICAgICAgICAgICAgIHN0YWtpbmc6IHtcbiAgICAgICAgICAgICAgICAgICAgcG9vbDogZ2VuZXNpcy5hcHBfc3RhdGUuc3Rha2luZy5wb29sLFxuICAgICAgICAgICAgICAgICAgICBwYXJhbXM6IGdlbmVzaXMuYXBwX3N0YXRlLnN0YWtpbmcucGFyYW1zXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBtaW50OiBnZW5lc2lzLmFwcF9zdGF0ZS5taW50LFxuICAgICAgICAgICAgICAgIGRpc3RyOiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbW11bml0eVRheDogZGlzdHIuY29tbXVuaXR5X3RheCxcbiAgICAgICAgICAgICAgICAgICAgYmFzZVByb3Bvc2VyUmV3YXJkOiBkaXN0ci5iYXNlX3Byb3Bvc2VyX3Jld2FyZCxcbiAgICAgICAgICAgICAgICAgICAgYm9udXNQcm9wb3NlclJld2FyZDogZGlzdHIuYm9udXNfcHJvcG9zZXJfcmV3YXJkLFxuICAgICAgICAgICAgICAgICAgICB3aXRoZHJhd0FkZHJFbmFibGVkOiBkaXN0ci53aXRoZHJhd19hZGRyX2VuYWJsZWRcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGdvdjoge1xuICAgICAgICAgICAgICAgICAgICBzdGFydGluZ1Byb3Bvc2FsSWQ6IGdlbmVzaXMuYXBwX3N0YXRlLmdvdi5zdGFydGluZ19wcm9wb3NhbF9pZCxcbiAgICAgICAgICAgICAgICAgICAgZGVwb3NpdFBhcmFtczogZ2VuZXNpcy5hcHBfc3RhdGUuZ292LmRlcG9zaXRfcGFyYW1zLFxuICAgICAgICAgICAgICAgICAgICB2b3RpbmdQYXJhbXM6IGdlbmVzaXMuYXBwX3N0YXRlLmdvdi52b3RpbmdfcGFyYW1zLFxuICAgICAgICAgICAgICAgICAgICB0YWxseVBhcmFtczogZ2VuZXNpcy5hcHBfc3RhdGUuZ292LnRhbGx5X3BhcmFtc1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgc2xhc2hpbmc6e1xuICAgICAgICAgICAgICAgICAgICBwYXJhbXM6IGdlbmVzaXMuYXBwX3N0YXRlLnNsYXNoaW5nLnBhcmFtc1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgc3VwcGx5OiBnZW5lc2lzLmFwcF9zdGF0ZS5zdXBwbHksXG4gICAgICAgICAgICAgICAgY3Jpc2lzOiBnZW5lc2lzLmFwcF9zdGF0ZS5jcmlzaXNcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgbGV0IHRvdGFsVm90aW5nUG93ZXIgPSAwO1xuXG4gICAgICAgICAgICAvLyByZWFkIGdlbnR4XG4gICAgICAgICAgICBpZiAoZ2VuZXNpcy5hcHBfc3RhdGUuZ2VudXRpbCAmJiBnZW5lc2lzLmFwcF9zdGF0ZS5nZW51dGlsLmdlbnR4cyAmJiAoZ2VuZXNpcy5hcHBfc3RhdGUuZ2VudXRpbC5nZW50eHMubGVuZ3RoID4gMCkpe1xuICAgICAgICAgICAgICAgIGZvciAoaSBpbiBnZW5lc2lzLmFwcF9zdGF0ZS5nZW51dGlsLmdlbnR4cyl7XG4gICAgICAgICAgICAgICAgICAgIGxldCBtc2cgPSBnZW5lc2lzLmFwcF9zdGF0ZS5nZW51dGlsLmdlbnR4c1tpXS52YWx1ZS5tc2c7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKG1zZy50eXBlKTtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChtIGluIG1zZyl7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobXNnW21dLnR5cGUgPT0gXCJjb3Ntb3Mtc2RrL01zZ0NyZWF0ZVZhbGlkYXRvclwiKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhtc2dbbV0udmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGxldCBjb21tYW5kID0gTWV0ZW9yLnNldHRpbmdzLmJpbi5nYWlhZGVidWcrXCIgcHVia2V5IFwiK21zZ1ttXS52YWx1ZS5wdWJrZXk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvciA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc2Vuc3VzX3B1YmtleTogbXNnW21dLnZhbHVlLnB1YmtleSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IG1zZ1ttXS52YWx1ZS5kZXNjcmlwdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tbWlzc2lvbjogbXNnW21dLnZhbHVlLmNvbW1pc3Npb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbl9zZWxmX2RlbGVnYXRpb246IG1zZ1ttXS52YWx1ZS5taW5fc2VsZl9kZWxlZ2F0aW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcGVyYXRvcl9hZGRyZXNzOiBtc2dbbV0udmFsdWUudmFsaWRhdG9yX2FkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGVnYXRvcl9hZGRyZXNzOiBtc2dbbV0udmFsdWUuZGVsZWdhdG9yX2FkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogTWF0aC5mbG9vcihwYXJzZUludChtc2dbbV0udmFsdWUudmFsdWUuYW1vdW50KSAvIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuc3Rha2luZ0ZyYWN0aW9uKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgamFpbGVkOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiAyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWxWb3RpbmdQb3dlciArPSB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHB1YmtleVZhbHVlID0gTWV0ZW9yLmNhbGwoJ2JlY2gzMlRvUHVia2V5JywgbXNnW21dLnZhbHVlLnB1YmtleSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gVmFsaWRhdG9ycy51cHNlcnQoe2NvbnNlbnN1c19wdWJrZXk6bXNnW21dLnZhbHVlLnB1YmtleX0sdmFsaWRhdG9yKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5wdWJfa2V5ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInR5cGVcIjpcInRlbmRlcm1pbnQvUHViS2V5RWQyNTUxOVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInZhbHVlXCI6cHVia2V5VmFsdWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYWRkcmVzcyA9IGdldEFkZHJlc3ModmFsaWRhdG9yLnB1Yl9rZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5hY2NwdWIgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3IucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhBY2NQdWIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXkgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3IucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhWYWxQdWIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZvdGluZ1Bvd2VySGlzdG9yeS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOiB2YWxpZGF0b3IuYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogdmFsaWRhdG9yLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2FkZCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogZ2VuZXNpcy5nZW5lc2lzX3RpbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZhbGlkYXRvcnMuaW5zZXJ0KHZhbGlkYXRvcik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIHJlYWQgdmFsaWRhdG9ycyBmcm9tIHByZXZpb3VzIGNoYWluXG4gICAgICAgICAgICBjb25zb2xlLmxvZygncmVhZCB2YWxpZGF0b3JzIGZyb20gcHJldmlvdXMgY2hhaW4nKTtcbiAgICAgICAgICAgIGlmIChnZW5lc2lzLmFwcF9zdGF0ZS5zdGFraW5nLnZhbGlkYXRvcnMgJiYgZ2VuZXNpcy5hcHBfc3RhdGUuc3Rha2luZy52YWxpZGF0b3JzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGdlbmVzaXMuYXBwX3N0YXRlLnN0YWtpbmcudmFsaWRhdG9ycy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgIGxldCBnZW5WYWxpZGF0b3JzU2V0ID0gZ2VuZXNpcy5hcHBfc3RhdGUuc3Rha2luZy52YWxpZGF0b3JzO1xuICAgICAgICAgICAgICAgIGxldCBnZW5WYWxpZGF0b3JzID0gZ2VuZXNpcy52YWxpZGF0b3JzO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IHYgaW4gZ2VuVmFsaWRhdG9yc1NldCl7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGdlblZhbGlkYXRvcnNbdl0pO1xuICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yID0gZ2VuVmFsaWRhdG9yc1NldFt2XTtcbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmRlbGVnYXRvcl9hZGRyZXNzID0gTWV0ZW9yLmNhbGwoJ2dldERlbGVnYXRvcicsIGdlblZhbGlkYXRvcnNTZXRbdl0ub3BlcmF0b3JfYWRkcmVzcyk7XG5cbiAgICAgICAgICAgICAgICAgICAgbGV0IHB1YmtleVZhbHVlID0gTWV0ZW9yLmNhbGwoJ2JlY2gzMlRvUHVia2V5JywgdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXkpO1xuXG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5wdWJfa2V5ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6XCJ0ZW5kZXJtaW50L1B1YktleUVkMjU1MTlcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIFwidmFsdWVcIjpwdWJrZXlWYWx1ZVxuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFkZHJlc3MgPSBnZXRBZGRyZXNzKHZhbGlkYXRvci5wdWJfa2V5KTtcbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnB1Yl9rZXkgPSB2YWxpZGF0b3IucHViX2tleTtcbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFjY3B1YiA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbGlkYXRvci5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY1B1Yik7XG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXkgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3IucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhWYWxQdWIpO1xuXG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci52b3RpbmdfcG93ZXIgPSBmaW5kVm90aW5nUG93ZXIodmFsaWRhdG9yLCBnZW5WYWxpZGF0b3JzKTtcbiAgICAgICAgICAgICAgICAgICAgdG90YWxWb3RpbmdQb3dlciArPSB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyO1xuXG4gICAgICAgICAgICAgICAgICAgIFZhbGlkYXRvcnMudXBzZXJ0KHtjb25zZW5zdXNfcHVia2V5OnZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5fSx2YWxpZGF0b3IpO1xuICAgICAgICAgICAgICAgICAgICBWb3RpbmdQb3dlckhpc3RvcnkuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IHZhbGlkYXRvci5hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IHZhbGlkYXRvci52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnYWRkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrX3RpbWU6IGdlbmVzaXMuZ2VuZXNpc190aW1lXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY2hhaW5QYXJhbXMucmVhZEdlbmVzaXMgPSB0cnVlO1xuICAgICAgICAgICAgY2hhaW5QYXJhbXMuYWN0aXZlVm90aW5nUG93ZXIgPSB0b3RhbFZvdGluZ1Bvd2VyO1xuICAgICAgICAgICAgbGV0IHJlc3VsdCA9IENoYWluLnVwc2VydCh7Y2hhaW5JZDpjaGFpblBhcmFtcy5jaGFpbklkfSwgeyRzZXQ6Y2hhaW5QYXJhbXN9KTtcblxuXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnPT09IEZpbmlzaGVkIHByb2Nlc3NpbmcgZ2VuZXNpcyBmaWxlID09PScpO1xuXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBDaGFpbiwgQ2hhaW5TdGF0ZXMgfSBmcm9tICcuLi9jaGFpbi5qcyc7XG5pbXBvcnQgeyBDb2luU3RhdHMgfSBmcm9tICcuLi8uLi9jb2luLXN0YXRzL2NvaW4tc3RhdHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5cbk1ldGVvci5wdWJsaXNoKCdjaGFpblN0YXRlcy5sYXRlc3QnLCBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIFtcbiAgICAgICAgQ2hhaW5TdGF0ZXMuZmluZCh7fSx7c29ydDp7aGVpZ2h0Oi0xfSxsaW1pdDoxfSksXG4gICAgICAgIENvaW5TdGF0cy5maW5kKHt9LHtzb3J0OntsYXN0X3VwZGF0ZWRfYXQ6LTF9LGxpbWl0OjF9KVxuICAgIF07XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgnY2hhaW4uc3RhdHVzJywgZnVuY3Rpb24oKXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gQ2hhaW4uZmluZCh7Y2hhaW5JZDpNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9KTtcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKGNoYWluKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczoxLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOjEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3BlcmF0b3JfYWRkcmVzczoxLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czotMSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqYWlsZWQ6MSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9maWxlX3VybDoxXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSk7IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5cbmV4cG9ydCBjb25zdCBDaGFpbiA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjaGFpbicpO1xuZXhwb3J0IGNvbnN0IENoYWluU3RhdGVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NoYWluX3N0YXRlcycpXG5cbkNoYWluLmhlbHBlcnMoe1xuICAgIHByb3Bvc2VyKCl7XG4gICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmRPbmUoe2FkZHJlc3M6dGhpcy5wcm9wb3NlckFkZHJlc3N9KTtcbiAgICB9XG59KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQ29pblN0YXRzIH0gZnJvbSAnLi4vY29pbi1zdGF0cy5qcyc7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ2NvaW5TdGF0cy5nZXRDb2luU3RhdHMnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IGNvaW5JZCA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY29pbmdlY2tvSWQ7XG4gICAgICAgIGlmIChjb2luSWQpe1xuICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgIGxldCBub3cgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgIG5vdy5zZXRNaW51dGVzKDApO1xuICAgICAgICAgICAgICAgIGxldCB1cmwgPSBcImh0dHBzOi8vYXBpLmNvaW5nZWNrby5jb20vYXBpL3YzL3NpbXBsZS9wcmljZT9pZHM9XCIrY29pbklkK1wiJnZzX2N1cnJlbmNpZXM9dXNkJmluY2x1ZGVfbWFya2V0X2NhcD10cnVlJmluY2x1ZGVfMjRocl92b2w9dHJ1ZSZpbmNsdWRlXzI0aHJfY2hhbmdlPXRydWUmaW5jbHVkZV9sYXN0X3VwZGF0ZWRfYXQ9dHJ1ZVwiO1xuICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBkYXRhID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgZGF0YSA9IGRhdGFbY29pbklkXTtcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coY29pblN0YXRzKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIENvaW5TdGF0cy51cHNlcnQoe2xhc3RfdXBkYXRlZF9hdDpkYXRhLmxhc3RfdXBkYXRlZF9hdH0sIHskc2V0OmRhdGF9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgcmV0dXJuIFwiTm8gY29pbmdlY2tvIElkIHByb3ZpZGVkLlwiXG4gICAgICAgIH1cbiAgICB9LFxuICAgICdjb2luU3RhdHMuZ2V0U3RhdHMnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IGNvaW5JZCA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY29pbmdlY2tvSWQ7XG4gICAgICAgIGlmIChjb2luSWQpe1xuICAgICAgICAgICAgcmV0dXJuIChDb2luU3RhdHMuZmluZE9uZSh7fSx7c29ydDp7bGFzdF91cGRhdGVkX2F0Oi0xfX0pKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgcmV0dXJuIFwiTm8gY29pbmdlY2tvIElkIHByb3ZpZGVkLlwiO1xuICAgICAgICB9XG5cbiAgICB9XG59KSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IENvaW5TdGF0cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjb2luX3N0YXRzJyk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IERlbGVnYXRpb25zIH0gZnJvbSAnLi4vZGVsZWdhdGlvbnMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnZGVsZWdhdGlvbnMuZ2V0RGVsZWdhdGlvbnMnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe30pLmZldGNoKCk7XG4gICAgICAgIGxldCBkZWxlZ2F0aW9ucyA9IFtdO1xuICAgICAgICBjb25zb2xlLmxvZyhcIj09PSBHZXR0aW5nIGRlbGVnYXRpb25zID09PVwiKTtcbiAgICAgICAgZm9yICh2IGluIHZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgaWYgKHZhbGlkYXRvcnNbdl0ub3BlcmF0b3JfYWRkcmVzcyl7XG4gICAgICAgICAgICAgICAgbGV0IHVybCA9IExDRCArICcvc3Rha2luZy92YWxpZGF0b3JzLycrdmFsaWRhdG9yc1t2XS5vcGVyYXRvcl9hZGRyZXNzK1wiL2RlbGVnYXRpb25zXCI7XG4gICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRlbGVnYXRpb24gPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGRlbGVnYXRpb24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgZGVsZWdhdGlvbnMgPSBkZWxlZ2F0aW9ucy5jb25jYXQoZGVsZWdhdGlvbik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlLnN0YXR1c0NvZGUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgfSAgICBcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGZvciAoaSBpbiBkZWxlZ2F0aW9ucyl7XG4gICAgICAgICAgICBpZiAoZGVsZWdhdGlvbnNbaV0gJiYgZGVsZWdhdGlvbnNbaV0uc2hhcmVzKVxuICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zW2ldLnNoYXJlcyA9IHBhcnNlRmxvYXQoZGVsZWdhdGlvbnNbaV0uc2hhcmVzKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGRlbGVnYXRpb25zKTtcbiAgICAgICAgbGV0IGRhdGEgPSB7XG4gICAgICAgICAgICBkZWxlZ2F0aW9uczogZGVsZWdhdGlvbnMsXG4gICAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gRGVsZWdhdGlvbnMuaW5zZXJ0KGRhdGEpO1xuICAgIH1cbiAgICAvLyAnYmxvY2tzLmF2ZXJhZ2VCbG9ja1RpbWUnKGFkZHJlc3Mpe1xuICAgIC8vICAgICBsZXQgYmxvY2tzID0gQmxvY2tzY29uLmZpbmQoe3Byb3Bvc2VyQWRkcmVzczphZGRyZXNzfSkuZmV0Y2goKTtcbiAgICAvLyAgICAgbGV0IGhlaWdodHMgPSBibG9ja3MubWFwKChibG9jaywgaSkgPT4ge1xuICAgIC8vICAgICAgICAgcmV0dXJuIGJsb2NrLmhlaWdodDtcbiAgICAvLyAgICAgfSk7XG4gICAgLy8gICAgIGxldCBibG9ja3NTdGF0cyA9IEFuYWx5dGljcy5maW5kKHtoZWlnaHQ6eyRpbjpoZWlnaHRzfX0pLmZldGNoKCk7XG4gICAgLy8gICAgIC8vIGNvbnNvbGUubG9nKGJsb2Nrc1N0YXRzKTtcblxuICAgIC8vICAgICBsZXQgdG90YWxCbG9ja0RpZmYgPSAwO1xuICAgIC8vICAgICBmb3IgKGIgaW4gYmxvY2tzU3RhdHMpe1xuICAgIC8vICAgICAgICAgdG90YWxCbG9ja0RpZmYgKz0gYmxvY2tzU3RhdHNbYl0udGltZURpZmY7XG4gICAgLy8gICAgIH1cbiAgICAvLyAgICAgcmV0dXJuIHRvdGFsQmxvY2tEaWZmL2hlaWdodHMubGVuZ3RoO1xuICAgIC8vIH1cbn0pIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgRGVsZWdhdGlvbnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZGVsZWdhdGlvbnMnKTtcbiIsImltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAndHJhbnNhY3Rpb24uc3VibWl0JzogZnVuY3Rpb24odHhJbmZvKSB7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke0xDRH0vdHhzYDtcbiAgICAgICAgZGF0YSA9IHtcbiAgICAgICAgICAgIFwidHhcIjogdHhJbmZvLnZhbHVlLFxuICAgICAgICAgICAgXCJtb2RlXCI6IFwic3luY1wiXG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdGltZXN0YW1wID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBzdWJtaXR0aW5nIHRyYW5zYWN0aW9uJHt0aW1lc3RhbXB9ICR7dXJsfSB3aXRoIGRhdGEgJHtKU09OLnN0cmluZ2lmeShkYXRhKX1gKVxuXG4gICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAucG9zdCh1cmwsIHtkYXRhfSk7XG4gICAgICAgIGNvbnNvbGUubG9nKGByZXNwb25zZSBmb3IgdHJhbnNhY3Rpb24ke3RpbWVzdGFtcH0gJHt1cmx9OiAke0pTT04uc3RyaW5naWZ5KHJlc3BvbnNlKX1gKVxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApIHtcbiAgICAgICAgICAgIGxldCBkYXRhID0gcmVzcG9uc2UuZGF0YVxuICAgICAgICAgICAgaWYgKGRhdGEuY29kZSlcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKGRhdGEuY29kZSwgSlNPTi5wYXJzZShkYXRhLnJhd19sb2cpLm1lc3NhZ2UpXG4gICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YS50eGhhc2g7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICd0cmFuc2FjdGlvbi5leGVjdXRlJzogZnVuY3Rpb24oYm9keSwgcGF0aCkge1xuICAgICAgICBjb25zdCB1cmwgPSBgJHtMQ0R9LyR7cGF0aH1gO1xuICAgICAgICBkYXRhID0ge1xuICAgICAgICAgICAgXCJiYXNlX3JlcVwiOiB7XG4gICAgICAgICAgICAgICAgLi4uYm9keSxcbiAgICAgICAgICAgICAgICBcImNoYWluX2lkXCI6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZCxcbiAgICAgICAgICAgICAgICBcInNpbXVsYXRlXCI6IGZhbHNlXG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAucG9zdCh1cmwsIHtkYXRhfSk7XG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCkge1xuICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICd0cmFuc2FjdGlvbi5zaW11bGF0ZSc6IGZ1bmN0aW9uKHR4TXNnLCBmcm9tLCBwYXRoLCBhZGp1c3RtZW50PScxLjInKSB7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke0xDRH0vJHtwYXRofWA7XG4gICAgICAgIGRhdGEgPSB7Li4udHhNc2csXG4gICAgICAgICAgICBcImJhc2VfcmVxXCI6IHtcbiAgICAgICAgICAgICAgICBcImZyb21cIjogZnJvbSxcbiAgICAgICAgICAgICAgICBcImNoYWluX2lkXCI6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZCxcbiAgICAgICAgICAgICAgICBcImdhc19hZGp1c3RtZW50XCI6IGFkanVzdG1lbnQsXG4gICAgICAgICAgICAgICAgXCJzaW11bGF0ZVwiOiB0cnVlXG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAucG9zdCh1cmwsIHtkYXRhfSk7XG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCkge1xuICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkuZ2FzX2VzdGltYXRlO1xuICAgICAgICB9XG4gICAgfSxcbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuaW1wb3J0IHsgUHJvcG9zYWxzIH0gZnJvbSAnLi4vcHJvcG9zYWxzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuLy8gaW1wb3J0IHsgUHJvbWlzZSB9IGZyb20gJ21ldGVvci9wcm9taXNlJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdwcm9wb3NhbHMuZ2V0UHJvcG9zYWxzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL2dvdi9wcm9wb3NhbHMnO1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGxldCBwcm9wb3NhbHMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHByb3Bvc2Fscyk7XG5cbiAgICAgICAgICAgIGxldCBmaW5pc2hlZFByb3Bvc2FsSWRzID0gbmV3IFNldChQcm9wb3NhbHMuZmluZChcbiAgICAgICAgICAgICAgICB7XCJwcm9wb3NhbF9zdGF0dXNcIjp7JGluOltcIlBhc3NlZFwiLCBcIlJlamVjdGVkXCIsIFwiUmVtb3ZlZFwiXX19XG4gICAgICAgICAgICApLmZldGNoKCkubWFwKChwKT0+IHAucHJvcG9zYWxJZCkpO1xuXG4gICAgICAgICAgICBsZXQgcHJvcG9zYWxJZHMgPSBbXTtcbiAgICAgICAgICAgIGlmIChwcm9wb3NhbHMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgLy8gUHJvcG9zYWxzLnVwc2VydCgpXG4gICAgICAgICAgICAgICAgY29uc3QgYnVsa1Byb3Bvc2FscyA9IFByb3Bvc2Fscy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgaW4gcHJvcG9zYWxzKXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHByb3Bvc2FsID0gcHJvcG9zYWxzW2ldO1xuICAgICAgICAgICAgICAgICAgICBwcm9wb3NhbC5wcm9wb3NhbElkID0gcGFyc2VJbnQocHJvcG9zYWwuaWQpO1xuICAgICAgICAgICAgICAgICAgICBpZiAocHJvcG9zYWwucHJvcG9zYWxJZCA+IDAgJiYgIWZpbmlzaGVkUHJvcG9zYWxJZHMuaGFzKHByb3Bvc2FsLnByb3Bvc2FsSWQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHVybCA9IExDRCArICcvZ292L3Byb3Bvc2Fscy8nK3Byb3Bvc2FsLnByb3Bvc2FsSWQrJy9wcm9wb3Nlcic7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJvcG9zZXIgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByb3Bvc2VyLnByb3Bvc2FsX2lkICYmIChwcm9wb3Nlci5wcm9wb3NhbF9pZCA9PSBwcm9wb3NhbC5pZCkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zYWwucHJvcG9zZXIgPSBwcm9wb3Nlci5wcm9wb3NlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrUHJvcG9zYWxzLmZpbmQoe3Byb3Bvc2FsSWQ6IHByb3Bvc2FsLnByb3Bvc2FsSWR9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6cHJvcG9zYWx9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wb3NhbElkcy5wdXNoKHByb3Bvc2FsLnByb3Bvc2FsSWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1Byb3Bvc2Fscy5maW5kKHtwcm9wb3NhbElkOiBwcm9wb3NhbC5wcm9wb3NhbElkfSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OnByb3Bvc2FsfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zYWxJZHMucHVzaChwcm9wb3NhbC5wcm9wb3NhbElkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlLnJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJ1bGtQcm9wb3NhbHMuZmluZCh7cHJvcG9zYWxJZDp7JG5pbjpwcm9wb3NhbElkc30sIHByb3Bvc2FsX3N0YXR1czp7JG5pbjpbXCJQYXNzZWRcIiwgXCJSZWplY3RlZFwiLCBcIlJlbW92ZWRcIl19fSlcbiAgICAgICAgICAgICAgICAgICAgLnVwZGF0ZSh7JHNldDoge1wicHJvcG9zYWxfc3RhdHVzXCI6IFwiUmVtb3ZlZFwifX0pO1xuICAgICAgICAgICAgICAgIGJ1bGtQcm9wb3NhbHMuZXhlY3V0ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ3Byb3Bvc2Fscy5nZXRQcm9wb3NhbFJlc3VsdHMnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHByb3Bvc2FscyA9IFByb3Bvc2Fscy5maW5kKHtcInByb3Bvc2FsX3N0YXR1c1wiOnskbmluOltcIlBhc3NlZFwiLCBcIlJlamVjdGVkXCIsIFwiUmVtb3ZlZFwiXX19KS5mZXRjaCgpO1xuXG4gICAgICAgIGlmIChwcm9wb3NhbHMgJiYgKHByb3Bvc2Fscy5sZW5ndGggPiAwKSl7XG4gICAgICAgICAgICBmb3IgKGxldCBpIGluIHByb3Bvc2Fscyl7XG4gICAgICAgICAgICAgICAgaWYgKHBhcnNlSW50KHByb3Bvc2Fsc1tpXS5wcm9wb3NhbElkKSA+IDApe1xuICAgICAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBnZXQgcHJvcG9zYWwgZGVwb3NpdHNcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL2dvdi9wcm9wb3NhbHMvJytwcm9wb3NhbHNbaV0ucHJvcG9zYWxJZCsnL2RlcG9zaXRzJztcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJvcG9zYWwgPSB7cHJvcG9zYWxJZDogcHJvcG9zYWxzW2ldLnByb3Bvc2FsSWR9O1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgZGVwb3NpdHMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wb3NhbC5kZXBvc2l0cyA9IGRlcG9zaXRzO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmwgPSBMQ0QgKyAnL2dvdi9wcm9wb3NhbHMvJytwcm9wb3NhbHNbaV0ucHJvcG9zYWxJZCsnL3ZvdGVzJztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZvdGVzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zYWwudm90ZXMgPSBnZXRWb3RlRGV0YWlsKHZvdGVzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsID0gTENEICsgJy9nb3YvcHJvcG9zYWxzLycrcHJvcG9zYWxzW2ldLnByb3Bvc2FsSWQrJy90YWxseSc7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB0YWxseSA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2FsLnRhbGx5ID0gdGFsbHk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2FsLnVwZGF0ZWRBdCA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBQcm9wb3NhbHMudXBkYXRlKHtwcm9wb3NhbElkOiBwcm9wb3NhbHNbaV0ucHJvcG9zYWxJZH0sIHskc2V0OnByb3Bvc2FsfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY2F0Y2goZSl7XG5cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cbn0pXG5cbmNvbnN0IGdldFZvdGVEZXRhaWwgPSAodm90ZXMpID0+IHtcbiAgICBpZiAoIXZvdGVzKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG5cbiAgICBsZXQgdm90ZXJzID0gdm90ZXMubWFwKCh2b3RlKSA9PiB2b3RlLnZvdGVyKTtcbiAgICBsZXQgdm90aW5nUG93ZXJNYXAgPSB7fTtcbiAgICBsZXQgdmFsaWRhdG9yQWRkcmVzc01hcCA9IHt9O1xuICAgIFZhbGlkYXRvcnMuZmluZCh7ZGVsZWdhdG9yX2FkZHJlc3M6IHskaW46IHZvdGVyc319KS5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHtcbiAgICAgICAgdm90aW5nUG93ZXJNYXBbdmFsaWRhdG9yLmRlbGVnYXRvcl9hZGRyZXNzXSA9IHtcbiAgICAgICAgICAgIG1vbmlrZXI6IHZhbGlkYXRvci5kZXNjcmlwdGlvbi5tb25pa2VyLFxuICAgICAgICAgICAgYWRkcmVzczogdmFsaWRhdG9yLmFkZHJlc3MsXG4gICAgICAgICAgICB0b2tlbnM6IHBhcnNlRmxvYXQodmFsaWRhdG9yLnRva2VucyksXG4gICAgICAgICAgICBkZWxlZ2F0b3JTaGFyZXM6IHBhcnNlRmxvYXQodmFsaWRhdG9yLmRlbGVnYXRvcl9zaGFyZXMpLFxuICAgICAgICAgICAgZGVkdWN0ZWRTaGFyZXM6IHBhcnNlRmxvYXQodmFsaWRhdG9yLmRlbGVnYXRvcl9zaGFyZXMpXG4gICAgICAgIH1cbiAgICAgICAgdmFsaWRhdG9yQWRkcmVzc01hcFt2YWxpZGF0b3Iub3BlcmF0b3JfYWRkcmVzc10gPSB2YWxpZGF0b3IuZGVsZWdhdG9yX2FkZHJlc3M7XG4gICAgfSk7XG4gICAgdm90ZXJzLmZvckVhY2goKHZvdGVyKSA9PiB7XG4gICAgICAgIGlmICghdm90aW5nUG93ZXJNYXBbdm90ZXJdKSB7XG4gICAgICAgICAgICAvLyB2b3RlciBpcyBub3QgYSB2YWxpZGF0b3JcbiAgICAgICAgICAgIGxldCB1cmwgPSBgJHtMQ0R9L3N0YWtpbmcvZGVsZWdhdG9ycy8ke3ZvdGVyfS9kZWxlZ2F0aW9uc2A7XG4gICAgICAgICAgICBsZXQgZGVsZWdhdGlvbnM7XG4gICAgICAgICAgICBsZXQgdm90aW5nUG93ZXIgPSAwO1xuICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgZGVsZWdhdGlvbnMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zICYmIGRlbGVnYXRpb25zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zLmZvckVhY2goKGRlbGVnYXRpb24pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgc2hhcmVzID0gcGFyc2VGbG9hdChkZWxlZ2F0aW9uLnNoYXJlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvckFkZHJlc3NNYXBbZGVsZWdhdGlvbi52YWxpZGF0b3JfYWRkcmVzc10pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGVkdWN0IGRlbGVnYXRlZCBzaGFyZWRzIGZyb20gdmFsaWRhdG9yIGlmIGEgZGVsZWdhdG9yIHZvdGVzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3IgPSB2b3RpbmdQb3dlck1hcFt2YWxpZGF0b3JBZGRyZXNzTWFwW2RlbGVnYXRpb24udmFsaWRhdG9yX2FkZHJlc3NdXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmRlZHVjdGVkU2hhcmVzIC09IHNoYXJlcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzICE9IDApeyAvLyBhdm9pZGluZyBkaXZpc2lvbiBieSB6ZXJvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdQb3dlciArPSAoc2hhcmVzL3ZhbGlkYXRvci5kZWxlZ2F0b3JTaGFyZXMpICogdmFsaWRhdG9yLnRva2VucztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvciA9IFZhbGlkYXRvcnMuZmluZE9uZSh7b3BlcmF0b3JfYWRkcmVzczogZGVsZWdhdGlvbi52YWxpZGF0b3JfYWRkcmVzc30pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yICYmIHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzICE9IDApeyAvLyBhdm9pZGluZyBkaXZpc2lvbiBieSB6ZXJvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdQb3dlciArPSAoc2hhcmVzL3BhcnNlRmxvYXQodmFsaWRhdG9yLmRlbGVnYXRvcl9zaGFyZXMpKSAqIHBhcnNlRmxvYXQodmFsaWRhdG9yLnRva2Vucyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHZvdGluZ1Bvd2VyTWFwW3ZvdGVyXSA9IHt2b3RpbmdQb3dlcjogdm90aW5nUG93ZXJ9O1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIHZvdGVzLm1hcCgodm90ZSkgPT4ge1xuICAgICAgICBsZXQgdm90ZXIgPSB2b3RpbmdQb3dlck1hcFt2b3RlLnZvdGVyXTtcbiAgICAgICAgbGV0IHZvdGluZ1Bvd2VyID0gdm90ZXIudm90aW5nUG93ZXI7XG4gICAgICAgIGlmICh2b3RpbmdQb3dlciA9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIC8vIHZvdGVyIGlzIGEgdmFsaWRhdG9yXG4gICAgICAgICAgICB2b3RpbmdQb3dlciA9IHZvdGVyLmRlbGVnYXRvclNoYXJlcz8oKHZvdGVyLmRlZHVjdGVkU2hhcmVzL3ZvdGVyLmRlbGVnYXRvclNoYXJlcykgKiB2b3Rlci50b2tlbnMpOjA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHsuLi52b3RlLCB2b3RpbmdQb3dlcn07XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFByb3Bvc2FscyB9IGZyb20gJy4uL3Byb3Bvc2Fscy5qcyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjaydcblxuTWV0ZW9yLnB1Ymxpc2goJ3Byb3Bvc2Fscy5saXN0JywgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBQcm9wb3NhbHMuZmluZCh7fSwge3NvcnQ6e3Byb3Bvc2FsSWQ6LTF9fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ3Byb3Bvc2Fscy5vbmUnLCBmdW5jdGlvbiAoaWQpe1xuICAgIGNoZWNrKGlkLCBOdW1iZXIpO1xuICAgIHJldHVybiBQcm9wb3NhbHMuZmluZCh7cHJvcG9zYWxJZDppZH0pO1xufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBQcm9wb3NhbHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncHJvcG9zYWxzJyk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMsIEFuYWx5dGljcywgQXZlcmFnZURhdGEsIEF2ZXJhZ2VWYWxpZGF0b3JEYXRhIH0gZnJvbSAnLi4vcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclNldHMgfSBmcm9tICcvaW1wb3J0cy9hcGkvdmFsaWRhdG9yLXNldHMvdmFsaWRhdG9yLXNldHMuanMnO1xuaW1wb3J0IHsgU3RhdHVzIH0gZnJvbSAnLi4vLi4vc3RhdHVzL3N0YXR1cy5qcyc7XG5pbXBvcnQgeyBNaXNzZWRCbG9ja3NTdGF0cyB9IGZyb20gJy4uL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgTWlzc2VkQmxvY2tzIH0gZnJvbSAnLi4vcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBCbG9ja3Njb24gfSBmcm9tICcuLi8uLi9ibG9ja3MvYmxvY2tzLmpzJztcbmltcG9ydCB7IENoYWluIH0gZnJvbSAnLi4vLi4vY2hhaW4vY2hhaW4uanMnO1xuaW1wb3J0IF8gZnJvbSAnbG9kYXNoJztcbmNvbnN0IEJVTEtVUERBVEVNQVhTSVpFID0gMTAwMDtcblxuY29uc3QgZ2V0QmxvY2tTdGF0cyA9IChzdGFydEhlaWdodCwgbGF0ZXN0SGVpZ2h0KSA9PiB7XG4gICAgbGV0IGJsb2NrU3RhdHMgPSB7fTtcbiAgICBjb25zdCBjb25kID0geyRhbmQ6IFtcbiAgICAgICAgeyBoZWlnaHQ6IHsgJGd0OiBzdGFydEhlaWdodCB9IH0sXG4gICAgICAgIHsgaGVpZ2h0OiB7ICRsdGU6IGxhdGVzdEhlaWdodCB9IH0gXX07XG4gICAgY29uc3Qgb3B0aW9ucyA9IHtzb3J0OntoZWlnaHQ6IDF9fTtcbiAgICBCbG9ja3Njb24uZmluZChjb25kLCBvcHRpb25zKS5mb3JFYWNoKChibG9jaykgPT4ge1xuICAgICAgICBibG9ja1N0YXRzW2Jsb2NrLmhlaWdodF0gPSB7XG4gICAgICAgICAgICBoZWlnaHQ6IGJsb2NrLmhlaWdodCxcbiAgICAgICAgICAgIHByb3Bvc2VyQWRkcmVzczogYmxvY2sucHJvcG9zZXJBZGRyZXNzLFxuICAgICAgICAgICAgcHJlY29tbWl0c0NvdW50OiBibG9jay5wcmVjb21taXRzQ291bnQsXG4gICAgICAgICAgICB2YWxpZGF0b3JzQ291bnQ6IGJsb2NrLnZhbGlkYXRvcnNDb3VudCxcbiAgICAgICAgICAgIHZhbGlkYXRvcnM6IGJsb2NrLnZhbGlkYXRvcnMsXG4gICAgICAgICAgICB0aW1lOiBibG9jay50aW1lXG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIEFuYWx5dGljcy5maW5kKGNvbmQsIG9wdGlvbnMpLmZvckVhY2goKGJsb2NrKSA9PiB7XG4gICAgICAgIGlmICghYmxvY2tTdGF0c1tibG9jay5oZWlnaHRdKSB7XG4gICAgICAgICAgICBibG9ja1N0YXRzW2Jsb2NrLmhlaWdodF0gPSB7IGhlaWdodDogYmxvY2suaGVpZ2h0IH07XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgYmxvY2sgJHtibG9jay5oZWlnaHR9IGRvZXMgbm90IGhhdmUgYW4gZW50cnlgKTtcbiAgICAgICAgfVxuICAgICAgICBfLmFzc2lnbihibG9ja1N0YXRzW2Jsb2NrLmhlaWdodF0sIHtcbiAgICAgICAgICAgIHByZWNvbW1pdHM6IGJsb2NrLnByZWNvbW1pdHMsXG4gICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lOiBibG9jay5hdmVyYWdlQmxvY2tUaW1lLFxuICAgICAgICAgICAgdGltZURpZmY6IGJsb2NrLnRpbWVEaWZmLFxuICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiBibG9jay52b3RpbmdfcG93ZXJcbiAgICAgICAgfSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGJsb2NrU3RhdHM7XG59XG5cbmNvbnN0IGdldFByZXZpb3VzUmVjb3JkID0gKHZvdGVyQWRkcmVzcywgcHJvcG9zZXJBZGRyZXNzKSA9PiB7XG4gICAgbGV0IHByZXZpb3VzUmVjb3JkID0gTWlzc2VkQmxvY2tzLmZpbmRPbmUoXG4gICAgICAgIHt2b3Rlcjp2b3RlckFkZHJlc3MsIHByb3Bvc2VyOnByb3Bvc2VyQWRkcmVzcywgYmxvY2tIZWlnaHQ6IC0xfSk7XG4gICAgbGV0IGxhc3RVcGRhdGVkSGVpZ2h0ID0gTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGFydEhlaWdodDtcbiAgICBsZXQgcHJldlN0YXRzID0ge307XG4gICAgaWYgKHByZXZpb3VzUmVjb3JkKSB7XG4gICAgICAgIHByZXZTdGF0cyA9IF8ucGljayhwcmV2aW91c1JlY29yZCwgWydtaXNzQ291bnQnLCAndG90YWxDb3VudCddKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBwcmV2U3RhdHMgPSB7XG4gICAgICAgICAgICBtaXNzQ291bnQ6IDAsXG4gICAgICAgICAgICB0b3RhbENvdW50OiAwXG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHByZXZTdGF0cztcbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdWYWxpZGF0b3JSZWNvcmRzLmNhbGN1bGF0ZU1pc3NlZEJsb2Nrcyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIGlmICghQ09VTlRNSVNTRURCTE9DS1Mpe1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBsZXQgc3RhcnRUaW1lID0gRGF0ZS5ub3coKTtcbiAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLUyA9IHRydWU7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2NhbHVsYXRlIG1pc3NlZCBibG9ja3MgY291bnQnKTtcbiAgICAgICAgICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7fSkuZmV0Y2goKTtcbiAgICAgICAgICAgICAgICBsZXQgbGF0ZXN0SGVpZ2h0ID0gTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5nZXRDdXJyZW50SGVpZ2h0Jyk7XG4gICAgICAgICAgICAgICAgbGV0IGV4cGxvcmVyU3RhdHVzID0gU3RhdHVzLmZpbmRPbmUoe2NoYWluSWQ6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0pO1xuICAgICAgICAgICAgICAgIGxldCBzdGFydEhlaWdodCA9IChleHBsb3JlclN0YXR1cyYmZXhwbG9yZXJTdGF0dXMubGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrSGVpZ2h0KT9leHBsb3JlclN0YXR1cy5sYXN0UHJvY2Vzc2VkTWlzc2VkQmxvY2tIZWlnaHQ6TWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGFydEhlaWdodDtcbiAgICAgICAgICAgICAgICBsYXRlc3RIZWlnaHQgPSBNYXRoLm1pbihzdGFydEhlaWdodCArIEJVTEtVUERBVEVNQVhTSVpFLCBsYXRlc3RIZWlnaHQpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtNaXNzZWRTdGF0cyA9IE1pc3NlZEJsb2Nrcy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZU9yZGVyZWRCdWxrT3AoKTtcblxuICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3JzTWFwID0ge307XG4gICAgICAgICAgICAgICAgdmFsaWRhdG9ycy5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHZhbGlkYXRvcnNNYXBbdmFsaWRhdG9yLmFkZHJlc3NdID0gdmFsaWRhdG9yKTtcblxuICAgICAgICAgICAgICAgIC8vIGEgbWFwIG9mIGJsb2NrIGhlaWdodCB0byBibG9jayBzdGF0c1xuICAgICAgICAgICAgICAgIGxldCBibG9ja1N0YXRzID0gZ2V0QmxvY2tTdGF0cyhzdGFydEhlaWdodCwgbGF0ZXN0SGVpZ2h0KTtcblxuICAgICAgICAgICAgICAgIC8vIHByb3Bvc2VyVm90ZXJTdGF0cyBpcyBhIHByb3Bvc2VyLXZvdGVyIG1hcCBjb3VudGluZyBudW1iZXJzIG9mIHByb3Bvc2VkIGJsb2NrcyBvZiB3aGljaCB2b3RlciBpcyBhbiBhY3RpdmUgdmFsaWRhdG9yXG4gICAgICAgICAgICAgICAgbGV0IHByb3Bvc2VyVm90ZXJTdGF0cyA9IHt9XG5cbiAgICAgICAgICAgICAgICBfLmZvckVhY2goYmxvY2tTdGF0cywgKGJsb2NrLCBibG9ja0hlaWdodCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBsZXQgcHJvcG9zZXJBZGRyZXNzID0gYmxvY2sucHJvcG9zZXJBZGRyZXNzO1xuICAgICAgICAgICAgICAgICAgICBsZXQgdm90ZWRWYWxpZGF0b3JzID0gbmV3IFNldChibG9jay52YWxpZGF0b3JzKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvclNldHMgPSBWYWxpZGF0b3JTZXRzLmZpbmRPbmUoe2Jsb2NrX2hlaWdodDpibG9jay5oZWlnaHR9KTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHZvdGVkVm90aW5nUG93ZXIgPSAwO1xuXG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvclNldHMudmFsaWRhdG9ycy5mb3JFYWNoKChhY3RpdmVWYWxpZGF0b3IpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2b3RlZFZhbGlkYXRvcnMuaGFzKGFjdGl2ZVZhbGlkYXRvci5hZGRyZXNzKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RlZFZvdGluZ1Bvd2VyICs9IHBhcnNlRmxvYXQoYWN0aXZlVmFsaWRhdG9yLnZvdGluZ19wb3dlcilcbiAgICAgICAgICAgICAgICAgICAgfSlcblxuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JTZXRzLnZhbGlkYXRvcnMuZm9yRWFjaCgoYWN0aXZlVmFsaWRhdG9yKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY3VycmVudFZhbGlkYXRvciA9IGFjdGl2ZVZhbGlkYXRvci5hZGRyZXNzXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIV8uaGFzKHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvcl0pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByZXZTdGF0cyA9IGdldFByZXZpb3VzUmVjb3JkKGN1cnJlbnRWYWxpZGF0b3IsIHByb3Bvc2VyQWRkcmVzcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXy5zZXQocHJvcG9zZXJWb3RlclN0YXRzLCBbcHJvcG9zZXJBZGRyZXNzLCBjdXJyZW50VmFsaWRhdG9yXSwgcHJldlN0YXRzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgXy51cGRhdGUocHJvcG9zZXJWb3RlclN0YXRzLCBbcHJvcG9zZXJBZGRyZXNzLCBjdXJyZW50VmFsaWRhdG9yLCAndG90YWxDb3VudCddLCAobikgPT4gbisxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdm90ZWRWYWxpZGF0b3JzLmhhcyhjdXJyZW50VmFsaWRhdG9yKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF8udXBkYXRlKHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvciwgJ21pc3NDb3VudCddLCAobikgPT4gbisxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrTWlzc2VkU3RhdHMuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90ZXI6IGN1cnJlbnRWYWxpZGF0b3IsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrSGVpZ2h0OiBibG9jay5oZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2VyOiBwcm9wb3NlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZWNvbW1pdHNDb3VudDogYmxvY2sucHJlY29tbWl0c0NvdW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JzQ291bnQ6IGJsb2NrLnZhbGlkYXRvcnNDb3VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZTogYmxvY2sudGltZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJlY29tbWl0czogYmxvY2sucHJlY29tbWl0cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZTogYmxvY2suYXZlcmFnZUJsb2NrVGltZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZURpZmY6IGJsb2NrLnRpbWVEaWZmLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdQb3dlcjogYmxvY2sudm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RlZFZvdGluZ1Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkQXQ6IGxhdGVzdEhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWlzc0NvdW50OiBfLmdldChwcm9wb3NlclZvdGVyU3RhdHMsIFtwcm9wb3NlckFkZHJlc3MsIGN1cnJlbnRWYWxpZGF0b3IsICdtaXNzQ291bnQnXSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsQ291bnQ6IF8uZ2V0KHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvciwgJ3RvdGFsQ291bnQnXSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIF8uZm9yRWFjaChwcm9wb3NlclZvdGVyU3RhdHMsICh2b3RlcnMsIHByb3Bvc2VyQWRkcmVzcykgPT4ge1xuICAgICAgICAgICAgICAgICAgICBfLmZvckVhY2godm90ZXJzLCAoc3RhdHMsIHZvdGVyQWRkcmVzcykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgYnVsa01pc3NlZFN0YXRzLmZpbmQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGVyOiB2b3RlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zZXI6IHByb3Bvc2VyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja0hlaWdodDogLTFcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGVyOiB2b3RlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zZXI6IHByb3Bvc2VyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja0hlaWdodDogLTEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEF0OiBsYXRlc3RIZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWlzc0NvdW50OiBfLmdldChzdGF0cywgJ21pc3NDb3VudCcpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsQ291bnQ6IF8uZ2V0KHN0YXRzLCAndG90YWxDb3VudCcpXG4gICAgICAgICAgICAgICAgICAgICAgICB9fSk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgbGV0IG1lc3NhZ2UgPSAnJztcbiAgICAgICAgICAgICAgICBpZiAoYnVsa01pc3NlZFN0YXRzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjbGllbnQgPSBNaXNzZWRCbG9ja3MuX2RyaXZlci5tb25nby5jbGllbnQ7XG4gICAgICAgICAgICAgICAgICAgIC8vIFRPRE86IGFkZCB0cmFuc2FjdGlvbiBiYWNrIGFmdGVyIHJlcGxpY2Egc2V0KCMxNDYpIGlzIHNldCB1cFxuICAgICAgICAgICAgICAgICAgICAvLyBsZXQgc2Vzc2lvbiA9IGNsaWVudC5zdGFydFNlc3Npb24oKTtcbiAgICAgICAgICAgICAgICAgICAgLy8gc2Vzc2lvbi5zdGFydFRyYW5zYWN0aW9uKCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBidWxrUHJvbWlzZSA9IGJ1bGtNaXNzZWRTdGF0cy5leGVjdXRlKG51bGwvKiwge3Nlc3Npb259Ki8pLnRoZW4oXG4gICAgICAgICAgICAgICAgICAgICAgICBNZXRlb3IuYmluZEVudmlyb25tZW50KChyZXN1bHQsIGVycikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLUyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBQcm9taXNlLmF3YWl0KHNlc3Npb24uYWJvcnRUcmFuc2FjdGlvbigpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUHJvbWlzZS5hd2FpdChzZXNzaW9uLmNvbW1pdFRyYW5zYWN0aW9uKCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlID0gYCgke3Jlc3VsdC5yZXN1bHQubkluc2VydGVkfSBpbnNlcnRlZCwgYCArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYCR7cmVzdWx0LnJlc3VsdC5uVXBzZXJ0ZWR9IHVwc2VydGVkLCBgICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgJHtyZXN1bHQucmVzdWx0Lm5Nb2RpZmllZH0gbW9kaWZpZWQpYDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgICAgICAgICAgICAgUHJvbWlzZS5hd2FpdChidWxrUHJvbWlzZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1MgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBTdGF0dXMudXBzZXJ0KHtjaGFpbklkOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LCB7JHNldDp7bGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrSGVpZ2h0OmxhdGVzdEhlaWdodCwgbGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrVGltZTogbmV3IERhdGUoKX19KTtcbiAgICAgICAgICAgICAgICByZXR1cm4gYGRvbmUgaW4gJHtEYXRlLm5vdygpIC0gc3RhcnRUaW1lfW1zICR7bWVzc2FnZX1gO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgcmV0dXJuIFwidXBkYXRpbmcuLi5cIjtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ1ZhbGlkYXRvclJlY29yZHMuY2FsY3VsYXRlTWlzc2VkQmxvY2tzU3RhdHMnOiBmdW5jdGlvbigpe1xuICAgICAgICAvLyBUT0RPOiBkZXByZWNhdGUgdGhpcyBtZXRob2QgYW5kIE1pc3NlZEJsb2Nrc1N0YXRzIGNvbGxlY3Rpb25cbiAgICAgICAgLy8gY29uc29sZS5sb2coXCJWYWxpZGF0b3JSZWNvcmRzLmNhbGN1bGF0ZU1pc3NlZEJsb2NrczogXCIrQ09VTlRNSVNTRURCTE9DS1MpO1xuICAgICAgICBpZiAoIUNPVU5UTUlTU0VEQkxPQ0tTU1RBVFMpe1xuICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1NTVEFUUyA9IHRydWU7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnY2FsdWxhdGUgbWlzc2VkIGJsb2NrcyBzdGF0cycpO1xuICAgICAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgICAgICBsZXQgdmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7fSkuZmV0Y2goKTtcbiAgICAgICAgICAgIGxldCBsYXRlc3RIZWlnaHQgPSBNZXRlb3IuY2FsbCgnYmxvY2tzLmdldEN1cnJlbnRIZWlnaHQnKTtcbiAgICAgICAgICAgIGxldCBleHBsb3JlclN0YXR1cyA9IFN0YXR1cy5maW5kT25lKHtjaGFpbklkOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9KTtcbiAgICAgICAgICAgIGxldCBzdGFydEhlaWdodCA9IChleHBsb3JlclN0YXR1cyYmZXhwbG9yZXJTdGF0dXMubGFzdE1pc3NlZEJsb2NrSGVpZ2h0KT9leHBsb3JlclN0YXR1cy5sYXN0TWlzc2VkQmxvY2tIZWlnaHQ6TWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGFydEhlaWdodDtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGxhdGVzdEhlaWdodCk7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhzdGFydEhlaWdodCk7XG4gICAgICAgICAgICBjb25zdCBidWxrTWlzc2VkU3RhdHMgPSBNaXNzZWRCbG9ja3NTdGF0cy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgICAgICAgICAgZm9yIChpIGluIHZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgICAgIC8vIGlmICgodmFsaWRhdG9yc1tpXS5hZGRyZXNzID09IFwiQjg1NTJFQUMwRDEyM0E2QkY2MDkxMjMwNDdBNTE4MUQ0NUVFOTBCNVwiKSB8fCAodmFsaWRhdG9yc1tpXS5hZGRyZXNzID09IFwiNjlEOTlCMkM2NjA0M0FDQkVBQTg0NDc1MjVDMzU2QUZDNjQwOEUwQ1wiKSB8fCAodmFsaWRhdG9yc1tpXS5hZGRyZXNzID09IFwiMzVBRDdBMkNEMkZDNzE3MTFBNjc1ODMwRUMxMTU4MDgyMjczRDQ1N1wiKSl7XG4gICAgICAgICAgICAgICAgbGV0IHZvdGVyQWRkcmVzcyA9IHZhbGlkYXRvcnNbaV0uYWRkcmVzcztcbiAgICAgICAgICAgICAgICBsZXQgbWlzc2VkUmVjb3JkcyA9IFZhbGlkYXRvclJlY29yZHMuZmluZCh7XG4gICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6dm90ZXJBZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICBleGlzdHM6ZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICRhbmQ6IFsgeyBoZWlnaHQ6IHsgJGd0OiBzdGFydEhlaWdodCB9IH0sIHsgaGVpZ2h0OiB7ICRsdGU6IGxhdGVzdEhlaWdodCB9IH0gXVxuICAgICAgICAgICAgICAgIH0pLmZldGNoKCk7XG5cbiAgICAgICAgICAgICAgICBsZXQgY291bnRzID0ge307XG5cbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcIm1pc3NlZFJlY29yZHMgdG8gcHJvY2VzczogXCIrbWlzc2VkUmVjb3Jkcy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgIGZvciAoYiBpbiBtaXNzZWRSZWNvcmRzKXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGJsb2NrID0gQmxvY2tzY29uLmZpbmRPbmUoe2hlaWdodDptaXNzZWRSZWNvcmRzW2JdLmhlaWdodH0pO1xuICAgICAgICAgICAgICAgICAgICBsZXQgZXhpc3RpbmdSZWNvcmQgPSBNaXNzZWRCbG9ja3NTdGF0cy5maW5kT25lKHt2b3Rlcjp2b3RlckFkZHJlc3MsIHByb3Bvc2VyOmJsb2NrLnByb3Bvc2VyQWRkcmVzc30pO1xuXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY291bnRzW2Jsb2NrLnByb3Bvc2VyQWRkcmVzc10gPT09ICd1bmRlZmluZWQnKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChleGlzdGluZ1JlY29yZCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY291bnRzW2Jsb2NrLnByb3Bvc2VyQWRkcmVzc10gPSBleGlzdGluZ1JlY29yZC5jb3VudCsxO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb3VudHNbYmxvY2sucHJvcG9zZXJBZGRyZXNzXSA9IDE7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50c1tibG9jay5wcm9wb3NlckFkZHJlc3NdKys7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBmb3IgKGFkZHJlc3MgaW4gY291bnRzKXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGEgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2b3Rlcjogdm90ZXJBZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zZXI6YWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50OiBjb3VudHNbYWRkcmVzc11cbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGJ1bGtNaXNzZWRTdGF0cy5maW5kKHt2b3Rlcjp2b3RlckFkZHJlc3MsIHByb3Bvc2VyOmFkZHJlc3N9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6ZGF0YX0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyB9XG5cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKGJ1bGtNaXNzZWRTdGF0cy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICBidWxrTWlzc2VkU3RhdHMuZXhlY3V0ZShNZXRlb3IuYmluZEVudmlyb25tZW50KChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTU1RBVFMgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICBTdGF0dXMudXBzZXJ0KHtjaGFpbklkOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LCB7JHNldDp7bGFzdE1pc3NlZEJsb2NrSGVpZ2h0OmxhdGVzdEhlaWdodCwgbGFzdE1pc3NlZEJsb2NrVGltZTogbmV3IERhdGUoKX19KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTU1RBVFMgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZG9uZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1NTVEFUUyA9IGZhbHNlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgcmV0dXJuIFwidXBkYXRpbmcuLi5cIjtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ0FuYWx5dGljcy5hZ2dyZWdhdGVCbG9ja1RpbWVBbmRWb3RpbmdQb3dlcic6IGZ1bmN0aW9uKHRpbWUpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IG5vdyA9IG5ldyBEYXRlKCk7XG5cbiAgICAgICAgaWYgKHRpbWUgPT0gJ20nKXtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlQmxvY2tUaW1lID0gMDtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlVm90aW5nUG93ZXIgPSAwO1xuXG4gICAgICAgICAgICBsZXQgYW5hbHl0aWNzID0gQW5hbHl0aWNzLmZpbmQoeyBcInRpbWVcIjogeyAkZ3Q6IG5ldyBEYXRlKERhdGUubm93KCkgLSA2MCAqIDEwMDApIH0gfSkuZmV0Y2goKTtcbiAgICAgICAgICAgIGlmIChhbmFseXRpY3MubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgZm9yIChpIGluIGFuYWx5dGljcyl7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgKz0gYW5hbHl0aWNzW2ldLnRpbWVEaWZmO1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgKz0gYW5hbHl0aWNzW2ldLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSA9IGF2ZXJhZ2VCbG9ja1RpbWUgLyBhbmFseXRpY3MubGVuZ3RoO1xuICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlciA9IGF2ZXJhZ2VWb3RpbmdQb3dlciAvIGFuYWx5dGljcy5sZW5ndGg7XG5cbiAgICAgICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSx7JHNldDp7bGFzdE1pbnV0ZVZvdGluZ1Bvd2VyOmF2ZXJhZ2VWb3RpbmdQb3dlciwgbGFzdE1pbnV0ZUJsb2NrVGltZTphdmVyYWdlQmxvY2tUaW1lfX0pO1xuICAgICAgICAgICAgICAgIEF2ZXJhZ2VEYXRhLmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlcjogYXZlcmFnZVZvdGluZ1Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiB0aW1lLFxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5vd1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRpbWUgPT0gJ2gnKXtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlQmxvY2tUaW1lID0gMDtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlVm90aW5nUG93ZXIgPSAwO1xuICAgICAgICAgICAgbGV0IGFuYWx5dGljcyA9IEFuYWx5dGljcy5maW5kKHsgXCJ0aW1lXCI6IHsgJGd0OiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gNjAqNjAgKiAxMDAwKSB9IH0pLmZldGNoKCk7XG4gICAgICAgICAgICBpZiAoYW5hbHl0aWNzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgIGZvciAoaSBpbiBhbmFseXRpY3Mpe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lICs9IGFuYWx5dGljc1tpXS50aW1lRGlmZjtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyICs9IGFuYWx5dGljc1tpXS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgPSBhdmVyYWdlQmxvY2tUaW1lIC8gYW5hbHl0aWNzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgPSBhdmVyYWdlVm90aW5nUG93ZXIgLyBhbmFseXRpY3MubGVuZ3RoO1xuXG4gICAgICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0seyRzZXQ6e2xhc3RIb3VyVm90aW5nUG93ZXI6YXZlcmFnZVZvdGluZ1Bvd2VyLCBsYXN0SG91ckJsb2NrVGltZTphdmVyYWdlQmxvY2tUaW1lfX0pO1xuICAgICAgICAgICAgICAgIEF2ZXJhZ2VEYXRhLmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlcjogYXZlcmFnZVZvdGluZ1Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiB0aW1lLFxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5vd1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodGltZSA9PSAnZCcpe1xuICAgICAgICAgICAgbGV0IGF2ZXJhZ2VCbG9ja1RpbWUgPSAwO1xuICAgICAgICAgICAgbGV0IGF2ZXJhZ2VWb3RpbmdQb3dlciA9IDA7XG4gICAgICAgICAgICBsZXQgYW5hbHl0aWNzID0gQW5hbHl0aWNzLmZpbmQoeyBcInRpbWVcIjogeyAkZ3Q6IG5ldyBEYXRlKERhdGUubm93KCkgLSAyNCo2MCo2MCAqIDEwMDApIH0gfSkuZmV0Y2goKTtcbiAgICAgICAgICAgIGlmIChhbmFseXRpY3MubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgZm9yIChpIGluIGFuYWx5dGljcyl7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgKz0gYW5hbHl0aWNzW2ldLnRpbWVEaWZmO1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgKz0gYW5hbHl0aWNzW2ldLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSA9IGF2ZXJhZ2VCbG9ja1RpbWUgLyBhbmFseXRpY3MubGVuZ3RoO1xuICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlciA9IGF2ZXJhZ2VWb3RpbmdQb3dlciAvIGFuYWx5dGljcy5sZW5ndGg7XG5cbiAgICAgICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSx7JHNldDp7bGFzdERheVZvdGluZ1Bvd2VyOmF2ZXJhZ2VWb3RpbmdQb3dlciwgbGFzdERheUJsb2NrVGltZTphdmVyYWdlQmxvY2tUaW1lfX0pO1xuICAgICAgICAgICAgICAgIEF2ZXJhZ2VEYXRhLmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlcjogYXZlcmFnZVZvdGluZ1Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiB0aW1lLFxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5vd1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyByZXR1cm4gYW5hbHl0aWNzLmxlbmd0aDtcbiAgICB9LFxuICAgICdBbmFseXRpY3MuYWdncmVnYXRlVmFsaWRhdG9yRGFpbHlCbG9ja1RpbWUnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe30pLmZldGNoKCk7XG4gICAgICAgIGxldCBub3cgPSBuZXcgRGF0ZSgpO1xuICAgICAgICBmb3IgKGkgaW4gdmFsaWRhdG9ycyl7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZUJsb2NrVGltZSA9IDA7XG5cbiAgICAgICAgICAgIGxldCBibG9ja3MgPSBCbG9ja3Njb24uZmluZCh7cHJvcG9zZXJBZGRyZXNzOnZhbGlkYXRvcnNbaV0uYWRkcmVzcywgXCJ0aW1lXCI6IHsgJGd0OiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gMjQqNjAqNjAgKiAxMDAwKSB9fSwge2ZpZWxkczp7aGVpZ2h0OjF9fSkuZmV0Y2goKTtcblxuICAgICAgICAgICAgaWYgKGJsb2Nrcy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICBsZXQgYmxvY2tIZWlnaHRzID0gW107XG4gICAgICAgICAgICAgICAgZm9yIChiIGluIGJsb2Nrcyl7XG4gICAgICAgICAgICAgICAgICAgIGJsb2NrSGVpZ2h0cy5wdXNoKGJsb2Nrc1tiXS5oZWlnaHQpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGxldCBhbmFseXRpY3MgPSBBbmFseXRpY3MuZmluZCh7aGVpZ2h0OiB7JGluOmJsb2NrSGVpZ2h0c319LCB7ZmllbGRzOntoZWlnaHQ6MSx0aW1lRGlmZjoxfX0pLmZldGNoKCk7XG5cblxuICAgICAgICAgICAgICAgIGZvciAoYSBpbiBhbmFseXRpY3Mpe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lICs9IGFuYWx5dGljc1thXS50aW1lRGlmZjtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lID0gYXZlcmFnZUJsb2NrVGltZSAvIGFuYWx5dGljcy5sZW5ndGg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIEF2ZXJhZ2VWYWxpZGF0b3JEYXRhLmluc2VydCh7XG4gICAgICAgICAgICAgICAgcHJvcG9zZXJBZGRyZXNzOiB2YWxpZGF0b3JzW2ldLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZTogYXZlcmFnZUJsb2NrVGltZSxcbiAgICAgICAgICAgICAgICB0eXBlOiAnVmFsaWRhdG9yRGFpbHlBdmVyYWdlQmxvY2tUaW1lJyxcbiAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5vd1xuICAgICAgICAgICAgfSlcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMsIEFuYWx5dGljcywgTWlzc2VkQmxvY2tzLCBNaXNzZWRCbG9ja3NTdGF0cywgVlBEaXN0cmlidXRpb25zIH0gZnJvbSAnLi4vcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcblxuTWV0ZW9yLnB1Ymxpc2goJ3ZhbGlkYXRvcl9yZWNvcmRzLmFsbCcsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gVmFsaWRhdG9yUmVjb3Jkcy5maW5kKCk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ3ZhbGlkYXRvcl9yZWNvcmRzLnVwdGltZScsIGZ1bmN0aW9uKGFkZHJlc3MsIG51bSl7XG4gICAgcmV0dXJuIFZhbGlkYXRvclJlY29yZHMuZmluZCh7YWRkcmVzczphZGRyZXNzfSx7bGltaXQ6bnVtLCBzb3J0OntoZWlnaHQ6LTF9fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ2FuYWx5dGljcy5oaXN0b3J5JywgZnVuY3Rpb24oKXtcbiAgICByZXR1cm4gQW5hbHl0aWNzLmZpbmQoe30se3NvcnQ6e2hlaWdodDotMX0sbGltaXQ6NTB9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaCgndnBEaXN0cmlidXRpb24ubGF0ZXN0JywgZnVuY3Rpb24oKXtcbiAgICByZXR1cm4gVlBEaXN0cmlidXRpb25zLmZpbmQoe30se3NvcnQ6e2hlaWdodDotMX0sIGxpbWl0OjF9KTtcbn0pO1xuXG5wdWJsaXNoQ29tcG9zaXRlKCdtaXNzZWRibG9ja3MudmFsaWRhdG9yJywgZnVuY3Rpb24oYWRkcmVzcywgdHlwZSl7XG4gICAgbGV0IGNvbmRpdGlvbnMgPSB7fTtcbiAgICBpZiAodHlwZSA9PSAndm90ZXInKXtcbiAgICAgICAgY29uZGl0aW9ucyA9IHtcbiAgICAgICAgICAgIHZvdGVyOiBhZGRyZXNzXG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZXtcbiAgICAgICAgY29uZGl0aW9ucyA9IHtcbiAgICAgICAgICAgIHByb3Bvc2VyOiBhZGRyZXNzXG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIE1pc3NlZEJsb2Nrc1N0YXRzLmZpbmQoY29uZGl0aW9ucylcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHN0YXRzKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7YWRkcmVzczoxLCBkZXNjcmlwdGlvbjoxLCBwcm9maWxlX3VybDoxfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pO1xuXG5wdWJsaXNoQ29tcG9zaXRlKCdtaXNzZWRyZWNvcmRzLnZhbGlkYXRvcicsIGZ1bmN0aW9uKGFkZHJlc3MsIHR5cGUpe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBNaXNzZWRCbG9ja3MuZmluZChcbiAgICAgICAgICAgICAgICB7W3R5cGVdOiBhZGRyZXNzfSxcbiAgICAgICAgICAgICAgICB7c29ydDoge3VwZGF0ZWRBdDogLTF9fVxuICAgICAgICAgICAgKVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7YWRkcmVzczoxLCBkZXNjcmlwdGlvbjoxLCBvcGVyYXRvcl9hZGRyZXNzOjF9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzJztcblxuZXhwb3J0IGNvbnN0IFZhbGlkYXRvclJlY29yZHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndmFsaWRhdG9yX3JlY29yZHMnKTtcbmV4cG9ydCBjb25zdCBBbmFseXRpY3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignYW5hbHl0aWNzJyk7XG5leHBvcnQgY29uc3QgTWlzc2VkQmxvY2tzU3RhdHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignbWlzc2VkX2Jsb2Nrc19zdGF0cycpO1xuZXhwb3J0IGNvbnN0IE1pc3NlZEJsb2NrcyA9IG5ldyAgTW9uZ28uQ29sbGVjdGlvbignbWlzc2VkX2Jsb2NrcycpO1xuZXhwb3J0IGNvbnN0IFZQRGlzdHJpYnV0aW9ucyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd2b3RpbmdfcG93ZXJfZGlzdHJpYnV0aW9ucycpO1xuZXhwb3J0IGNvbnN0IEF2ZXJhZ2VEYXRhID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2F2ZXJhZ2VfZGF0YScpO1xuZXhwb3J0IGNvbnN0IEF2ZXJhZ2VWYWxpZGF0b3JEYXRhID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2F2ZXJhZ2VfdmFsaWRhdG9yX2RhdGEnKTtcblxuTWlzc2VkQmxvY2tzU3RhdHMuaGVscGVycyh7XG4gICAgcHJvcG9zZXJNb25pa2VyKCl7XG4gICAgICAgIGxldCB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe2FkZHJlc3M6dGhpcy5wcm9wb3Nlcn0pO1xuICAgICAgICByZXR1cm4gKHZhbGlkYXRvci5kZXNjcmlwdGlvbik/dmFsaWRhdG9yLmRlc2NyaXB0aW9uLm1vbmlrZXI6dGhpcy5wcm9wb3NlcjtcbiAgICB9LFxuICAgIHZvdGVyTW9uaWtlcigpe1xuICAgICAgICBsZXQgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKHthZGRyZXNzOnRoaXMudm90ZXJ9KTtcbiAgICAgICAgcmV0dXJuICh2YWxpZGF0b3IuZGVzY3JpcHRpb24pP3ZhbGlkYXRvci5kZXNjcmlwdGlvbi5tb25pa2VyOnRoaXMudm90ZXI7XG4gICAgfVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgU3RhdHVzIH0gZnJvbSAnLi4vc3RhdHVzLmpzJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJ1xuXG5NZXRlb3IucHVibGlzaCgnc3RhdHVzLnN0YXR1cycsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gU3RhdHVzLmZpbmQoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSk7XG59KTtcblxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgU3RhdHVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3N0YXR1cycpOyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uLy4uL3RyYW5zYWN0aW9ucy90cmFuc2FjdGlvbnMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBWb3RpbmdQb3dlckhpc3RvcnkgfSBmcm9tICcuLi8uLi92b3RpbmctcG93ZXIvaGlzdG9yeS5qcyc7XG5cbmNvbnN0IEFkZHJlc3NMZW5ndGggPSA0MDtcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdUcmFuc2FjdGlvbnMuaW5kZXgnOiBmdW5jdGlvbihoYXNoLCBibG9ja1RpbWUpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgaGFzaCA9IGhhc2gudG9VcHBlckNhc2UoKTtcbiAgICAgICAgbGV0IHVybCA9IExDRCsgJy90eHMvJytoYXNoO1xuICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICBsZXQgdHggPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGhhc2gpO1xuXG4gICAgICAgIHR4LmhlaWdodCA9IHBhcnNlSW50KHR4LmhlaWdodCk7XG5cbiAgICAgICAgLy8gaWYgKCF0eC5jb2RlKXtcbiAgICAgICAgLy8gICAgIGxldCBtc2cgPSB0eC50eC52YWx1ZS5tc2c7XG4gICAgICAgIC8vICAgICBmb3IgKGxldCBtIGluIG1zZyl7XG4gICAgICAgIC8vICAgICAgICAgaWYgKG1zZ1ttXS50eXBlID09IFwiY29zbW9zLXNkay9Nc2dDcmVhdGVWYWxpZGF0b3JcIil7XG4gICAgICAgIC8vICAgICAgICAgICAgIGNvbnNvbGUubG9nKG1zZ1ttXS52YWx1ZSk7XG4gICAgICAgIC8vICAgICAgICAgICAgIGxldCBjb21tYW5kID0gTWV0ZW9yLnNldHRpbmdzLmJpbi5nYWlhZGVidWcrXCIgcHVia2V5IFwiK21zZ1ttXS52YWx1ZS5wdWJrZXk7XG4gICAgICAgIC8vICAgICAgICAgICAgIGxldCB2YWxpZGF0b3IgPSB7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBjb25zZW5zdXNfcHVia2V5OiBtc2dbbV0udmFsdWUucHVia2V5LFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IG1zZ1ttXS52YWx1ZS5kZXNjcmlwdGlvbixcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIGNvbW1pc3Npb246IG1zZ1ttXS52YWx1ZS5jb21taXNzaW9uLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgbWluX3NlbGZfZGVsZWdhdGlvbjogbXNnW21dLnZhbHVlLm1pbl9zZWxmX2RlbGVnYXRpb24sXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBvcGVyYXRvcl9hZGRyZXNzOiBtc2dbbV0udmFsdWUudmFsaWRhdG9yX2FkZHJlc3MsXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBkZWxlZ2F0b3JfYWRkcmVzczogbXNnW21dLnZhbHVlLmRlbGVnYXRvcl9hZGRyZXNzLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiBNYXRoLmZsb29yKHBhcnNlSW50KG1zZ1ttXS52YWx1ZS52YWx1ZS5hbW91bnQpIC8gMTAwMDAwMClcbiAgICAgICAgLy8gICAgICAgICAgICAgfVxuXG4gICAgICAgIC8vICAgICAgICAgICAgIE1ldGVvci5jYWxsKCdydW5Db2RlJywgY29tbWFuZCwgZnVuY3Rpb24oZXJyb3IsIHJlc3VsdCl7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYWRkcmVzcyA9IHJlc3VsdC5tYXRjaCgvXFxzWzAtOUEtRl17NDB9JC9pZ20pO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFkZHJlc3MgPSB2YWxpZGF0b3IuYWRkcmVzc1swXS50cmltKCk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuaGV4ID0gcmVzdWx0Lm1hdGNoKC9cXHNbMC05QS1GXXs2NH0kL2lnbSk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuaGV4ID0gdmFsaWRhdG9yLmhleFswXS50cmltKCk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHViX2tleSA9IHJlc3VsdC5tYXRjaCgve1wiLipcIn0vaWdtKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHZhbGlkYXRvci5wdWJfa2V5ID0gSlNPTi5wYXJzZSh2YWxpZGF0b3IucHViX2tleVswXS50cmltKCkpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgbGV0IHJlID0gbmV3IFJlZ0V4cChNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY1B1YitcIi4qJFwiLFwiaWdtXCIpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmNvc21vc2FjY3B1YiA9IHJlc3VsdC5tYXRjaChyZSk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuY29zbW9zYWNjcHViID0gdmFsaWRhdG9yLmNvc21vc2FjY3B1YlswXS50cmltKCk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICByZSA9IG5ldyBSZWdFeHAoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhWYWxQdWIrXCIuKiRcIixcImlnbVwiKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXkgPSByZXN1bHQubWF0Y2gocmUpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLm9wZXJhdG9yX3B1YmtleSA9IHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXlbMF0udHJpbSgpO1xuXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBWYWxpZGF0b3JzLnVwc2VydCh7Y29uc2Vuc3VzX3B1YmtleTptc2dbbV0udmFsdWUucHVia2V5fSx2YWxpZGF0b3IpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgVm90aW5nUG93ZXJIaXN0b3J5Lmluc2VydCh7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogdmFsaWRhdG9yLmFkZHJlc3MsXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IDAsXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdhZGQnLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogdHguaGVpZ2h0KzIsXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogYmxvY2tUaW1lXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgLy8gICAgICAgICAgICAgfSlcbiAgICAgICAgLy8gICAgICAgICB9XG4gICAgICAgIC8vICAgICB9XG4gICAgICAgIC8vIH1cblxuXG4gICAgICAgIGxldCB0eElkID0gVHJhbnNhY3Rpb25zLmluc2VydCh0eCk7XG4gICAgICAgIGlmICh0eElkKXtcbiAgICAgICAgICAgIHJldHVybiB0eElkO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgJ1RyYW5zYWN0aW9ucy5maW5kRGVsZWdhdGlvbic6IGZ1bmN0aW9uKGFkZHJlc3MsIGhlaWdodCl7XG4gICAgICAgIC8vIGZvbGxvd2luZyBjb3Ntb3Mtc2RrL3gvc2xhc2hpbmcvc3BlYy8wNl9ldmVudHMubWQgYW5kIGNvc21vcy1zZGsveC9zdGFraW5nL3NwZWMvMDZfZXZlbnRzLm1kXG4gICAgICAgIHJldHVybiBUcmFuc2FjdGlvbnMuZmluZCh7XG4gICAgICAgICAgICAkb3I6IFt7JGFuZDogW1xuICAgICAgICAgICAgICAgIHtcImV2ZW50cy50eXBlXCI6IFwiZGVsZWdhdGVcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCI6IFwidmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6IGFkZHJlc3N9XG4gICAgICAgICAgICBdfSwgeyRhbmQ6W1xuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOiBcImFjdGlvblwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOiBcInVuamFpbFwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy5rZXlcIjogXCJzZW5kZXJcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjogYWRkcmVzc31cbiAgICAgICAgICAgIF19LCB7JGFuZDpbXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLnR5cGVcIjogXCJjcmVhdGVfdmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOiBcInZhbGlkYXRvclwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOiBhZGRyZXNzfVxuICAgICAgICAgICAgXX0sIHskYW5kOltcbiAgICAgICAgICAgICAgICB7XCJldmVudHMudHlwZVwiOiBcInVuYm9uZFwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy5rZXlcIjogXCJ2YWxpZGF0b3JcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjogYWRkcmVzc31cbiAgICAgICAgICAgIF19LCB7JGFuZDpbXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLnR5cGVcIjogXCJyZWRlbGVnYXRlXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOiBcImRlc3RpbmF0aW9uX3ZhbGlkYXRvclwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOiBhZGRyZXNzfVxuICAgICAgICAgICAgXX1dLFxuICAgICAgICAgICAgXCJjb2RlXCI6IHskZXhpc3RzOiBmYWxzZX0sXG4gICAgICAgICAgICBoZWlnaHQ6eyRsdDpoZWlnaHR9fSxcbiAgICAgICAge3NvcnQ6e2hlaWdodDotMX0sXG4gICAgICAgICAgICBsaW1pdDogMX1cbiAgICAgICAgKS5mZXRjaCgpO1xuICAgIH0sXG4gICAgJ1RyYW5zYWN0aW9ucy5maW5kVXNlcic6IGZ1bmN0aW9uKGFkZHJlc3MsIGZpZWxkcz1udWxsKXtcbiAgICAgICAgLy8gYWRkcmVzcyBpcyBlaXRoZXIgZGVsZWdhdG9yIGFkZHJlc3Mgb3IgdmFsaWRhdG9yIG9wZXJhdG9yIGFkZHJlc3NcbiAgICAgICAgbGV0IHZhbGlkYXRvcjtcbiAgICAgICAgaWYgKCFmaWVsZHMpXG4gICAgICAgICAgICBmaWVsZHMgPSB7YWRkcmVzczoxLCBkZXNjcmlwdGlvbjoxLCBvcGVyYXRvcl9hZGRyZXNzOjEsIGRlbGVnYXRvcl9hZGRyZXNzOjF9O1xuICAgICAgICBpZiAoYWRkcmVzcy5pbmNsdWRlcyhNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeFZhbEFkZHIpKXtcbiAgICAgICAgICAgIC8vIHZhbGlkYXRvciBvcGVyYXRvciBhZGRyZXNzXG4gICAgICAgICAgICB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe29wZXJhdG9yX2FkZHJlc3M6YWRkcmVzc30sIHtmaWVsZHN9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChhZGRyZXNzLmluY2x1ZGVzKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4QWNjQWRkcikpe1xuICAgICAgICAgICAgLy8gZGVsZWdhdG9yIGFkZHJlc3NcbiAgICAgICAgICAgIHZhbGlkYXRvciA9IFZhbGlkYXRvcnMuZmluZE9uZSh7ZGVsZWdhdG9yX2FkZHJlc3M6YWRkcmVzc30sIHtmaWVsZHN9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChhZGRyZXNzLmxlbmd0aCA9PT0gQWRkcmVzc0xlbmd0aCkge1xuICAgICAgICAgICAgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKHthZGRyZXNzOmFkZHJlc3N9LCB7ZmllbGRzfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHZhbGlkYXRvcil7XG4gICAgICAgICAgICByZXR1cm4gdmFsaWRhdG9yO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcblxuICAgIH1cbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi90cmFuc2FjdGlvbnMuanMnO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vLi4vYmxvY2tzL2Jsb2Nrcy5qcyc7XG5cblxucHVibGlzaENvbXBvc2l0ZSgndHJhbnNhY3Rpb25zLmxpc3QnLCBmdW5jdGlvbihsaW1pdCA9IDMwKXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQoe30se3NvcnQ6e2hlaWdodDotMX0sIGxpbWl0OmxpbWl0fSlcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHR4KXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2hlaWdodDp0eC5oZWlnaHR9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7dGltZToxLCBoZWlnaHQ6MX19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgndHJhbnNhY3Rpb25zLnZhbGlkYXRvcicsIGZ1bmN0aW9uKHZhbGlkYXRvckFkZHJlc3MsIGRlbGVnYXRvckFkZHJlc3MsIGxpbWl0PTEwMCl7XG4gICAgbGV0IHF1ZXJ5ID0ge307XG4gICAgaWYgKHZhbGlkYXRvckFkZHJlc3MgJiYgZGVsZWdhdG9yQWRkcmVzcyl7XG4gICAgICAgIHF1ZXJ5ID0geyRvcjpbe1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjp2YWxpZGF0b3JBZGRyZXNzfSwge1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjpkZWxlZ2F0b3JBZGRyZXNzfV19XG4gICAgfVxuXG4gICAgaWYgKCF2YWxpZGF0b3JBZGRyZXNzICYmIGRlbGVnYXRvckFkZHJlc3Mpe1xuICAgICAgICBxdWVyeSA9IHtcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6ZGVsZWdhdG9yQWRkcmVzc31cbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQocXVlcnksIHtzb3J0OntoZWlnaHQ6LTF9LCBsaW1pdDpsaW1pdH0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOltcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHR4KXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2hlaWdodDp0eC5oZWlnaHR9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7dGltZToxLCBoZWlnaHQ6MX19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KVxuXG5wdWJsaXNoQ29tcG9zaXRlKCd0cmFuc2FjdGlvbnMuZmluZE9uZScsIGZ1bmN0aW9uKGhhc2gpe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBUcmFuc2FjdGlvbnMuZmluZCh7dHhoYXNoOmhhc2h9KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQodHgpe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7aGVpZ2h0OnR4LmhlaWdodH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmllbGRzOnt0aW1lOjEsIGhlaWdodDoxfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pXG5cbnB1Ymxpc2hDb21wb3NpdGUoJ3RyYW5zYWN0aW9ucy5oZWlnaHQnLCBmdW5jdGlvbihoZWlnaHQpe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBUcmFuc2FjdGlvbnMuZmluZCh7aGVpZ2h0OmhlaWdodH0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZCh0eCl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHtoZWlnaHQ6dHguaGVpZ2h0fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e3RpbWU6MSwgaGVpZ2h0OjF9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBCbG9ja3Njb24gfSBmcm9tICcuLi9ibG9ja3MvYmxvY2tzLmpzJztcbmltcG9ydCB7IFR4SWNvbiB9IGZyb20gJy4uLy4uL3VpL2NvbXBvbmVudHMvSWNvbnMuanN4JztcblxuZXhwb3J0IGNvbnN0IFRyYW5zYWN0aW9ucyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd0cmFuc2FjdGlvbnMnKTtcblxuVHJhbnNhY3Rpb25zLmhlbHBlcnMoe1xuICAgIGJsb2NrKCl7XG4gICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZE9uZSh7aGVpZ2h0OnRoaXMuaGVpZ2h0fSk7XG4gICAgfVxufSkiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uLy4uL3RyYW5zYWN0aW9ucy90cmFuc2FjdGlvbnMuanMnO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vLi4vYmxvY2tzL2Jsb2Nrcy5qcyc7XG5pbXBvcnQgeyBEZWxlZ2F0aW9ucyB9IGZyb20gJy4uLy4uL2RlbGVnYXRpb25zL2RlbGVnYXRpb25zLmpzJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdWYWxpZGF0b3JzLmZpbmRDcmVhdGVWYWxpZGF0b3JUaW1lJzogZnVuY3Rpb24oYWRkcmVzcyl7XG4gICAgICAgIC8vIGxvb2sgdXAgdGhlIGNyZWF0ZSB2YWxpZGF0b3IgdGltZSB0byBjb25zaWRlciBpZiB0aGUgdmFsaWRhdG9yIGhhcyBuZXZlciB1cGRhdGVkIHRoZSBjb21taXNzaW9uXG4gICAgICAgIGxldCB0eCA9IFRyYW5zYWN0aW9ucy5maW5kT25lKHskYW5kOltcbiAgICAgICAgICAgIHtcInR4LnZhbHVlLm1zZy52YWx1ZS5kZWxlZ2F0b3JfYWRkcmVzc1wiOmFkZHJlc3N9LFxuICAgICAgICAgICAge1widHgudmFsdWUubXNnLnR5cGVcIjpcImNvc21vcy1zZGsvTXNnQ3JlYXRlVmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAge2NvZGU6eyRleGlzdHM6ZmFsc2V9fVxuICAgICAgICBdfSk7XG5cbiAgICAgICAgaWYgKHR4KXtcbiAgICAgICAgICAgIGxldCBibG9jayA9IEJsb2Nrc2Nvbi5maW5kT25lKHtoZWlnaHQ6dHguaGVpZ2h0fSk7XG4gICAgICAgICAgICBpZiAoYmxvY2spe1xuICAgICAgICAgICAgICAgIHJldHVybiBibG9jay50aW1lO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICAvLyBubyBzdWNoIGNyZWF0ZSB2YWxpZGF0b3IgdHhcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgLy8gYXN5bmMgJ1ZhbGlkYXRvcnMuZ2V0QWxsRGVsZWdhdGlvbnMnKGFkZHJlc3Mpe1xuICAgICdWYWxpZGF0b3JzLmdldEFsbERlbGVnYXRpb25zJyhhZGRyZXNzKXtcbiAgICAgICAgbGV0IHVybCA9IExDRCArICcvc3Rha2luZy92YWxpZGF0b3JzLycrYWRkcmVzcysnL2RlbGVnYXRpb25zJztcblxuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgZGVsZWdhdGlvbnMgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICBkZWxlZ2F0aW9ucyA9IEpTT04ucGFyc2UoZGVsZWdhdGlvbnMuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zLmZvckVhY2goKGRlbGVnYXRpb24sIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zW2ldICYmIGRlbGVnYXRpb25zW2ldLnNoYXJlcylcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zW2ldLnNoYXJlcyA9IHBhcnNlRmxvYXQoZGVsZWdhdGlvbnNbaV0uc2hhcmVzKTtcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHJldHVybiBkZWxlZ2F0aW9ucztcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICB9XG59KTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi92YWxpZGF0b3JzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMgfSBmcm9tICcuLi8uLi9yZWNvcmRzL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnLi4vLi4vdm90aW5nLXBvd2VyL2hpc3RvcnkuanMnO1xuXG5NZXRlb3IucHVibGlzaCgndmFsaWRhdG9ycy5hbGwnLCBmdW5jdGlvbiAoc29ydCA9IFwiZGVzY3JpcHRpb24ubW9uaWtlclwiLCBkaXJlY3Rpb24gPSAtMSwgZmllbGRzPXt9KSB7XG4gICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZCh7fSwge3NvcnQ6IHtbc29ydF06IGRpcmVjdGlvbn0sIGZpZWxkczogZmllbGRzfSk7XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgndmFsaWRhdG9ycy5maXJzdFNlZW4nLHtcbiAgICBmaW5kKCkge1xuICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKHt9KTtcbiAgICB9LFxuICAgIGNoaWxkcmVuOiBbXG4gICAgICAgIHtcbiAgICAgICAgICAgIGZpbmQodmFsKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvclJlY29yZHMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgeyBhZGRyZXNzOiB2YWwuYWRkcmVzcyB9LFxuICAgICAgICAgICAgICAgICAgICB7IHNvcnQ6IHtoZWlnaHQ6IDF9LCBsaW1pdDogMX1cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgXVxufSk7XG5cbk1ldGVvci5wdWJsaXNoKCd2YWxpZGF0b3JzLnZvdGluZ19wb3dlcicsIGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZCh7XG4gICAgICAgIHN0YXR1czogMixcbiAgICAgICAgamFpbGVkOmZhbHNlXG4gICAgfSx7XG4gICAgICAgIHNvcnQ6e1xuICAgICAgICAgICAgdm90aW5nX3Bvd2VyOi0xXG4gICAgICAgIH0sXG4gICAgICAgIGZpZWxkczp7XG4gICAgICAgICAgICBhZGRyZXNzOiAxLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246MSxcbiAgICAgICAgICAgIHZvdGluZ19wb3dlcjoxLFxuICAgICAgICAgICAgcHJvZmlsZV91cmw6MVxuICAgICAgICB9XG4gICAgfVxuICAgICk7XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgndmFsaWRhdG9yLmRldGFpbHMnLCBmdW5jdGlvbihhZGRyZXNzKXtcbiAgICBsZXQgb3B0aW9ucyA9IHthZGRyZXNzOmFkZHJlc3N9O1xuICAgIGlmIChhZGRyZXNzLmluZGV4T2YoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhWYWxBZGRyKSAhPSAtMSl7XG4gICAgICAgIG9wdGlvbnMgPSB7b3BlcmF0b3JfYWRkcmVzczphZGRyZXNzfVxuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKG9wdGlvbnMpXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZCh2YWwpe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVm90aW5nUG93ZXJIaXN0b3J5LmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWRkcmVzczp2YWwuYWRkcmVzc30sXG4gICAgICAgICAgICAgICAgICAgICAgICB7c29ydDp7aGVpZ2h0Oi0xfSwgbGltaXQ6NTB9XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQodmFsKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JSZWNvcmRzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGFkZHJlc3M6IHZhbC5hZGRyZXNzIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IHNvcnQ6IHtoZWlnaHQ6IC0xfSwgbGltaXQ6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMudXB0aW1lV2luZG93fVxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgVmFsaWRhdG9yUmVjb3JkcyB9IGZyb20gJy4uL3JlY29yZHMvcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBWb3RpbmdQb3dlckhpc3RvcnkgfSBmcm9tICcuLi92b3RpbmctcG93ZXIvaGlzdG9yeS5qcyc7XG5cbmV4cG9ydCBjb25zdCBWYWxpZGF0b3JzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3ZhbGlkYXRvcnMnKTtcblxuVmFsaWRhdG9ycy5oZWxwZXJzKHtcbiAgICBmaXJzdFNlZW4oKXtcbiAgICAgICAgcmV0dXJuIFZhbGlkYXRvclJlY29yZHMuZmluZE9uZSh7YWRkcmVzczp0aGlzLmFkZHJlc3N9KTtcbiAgICB9LFxuICAgIGhpc3RvcnkoKXtcbiAgICAgICAgcmV0dXJuIFZvdGluZ1Bvd2VySGlzdG9yeS5maW5kKHthZGRyZXNzOnRoaXMuYWRkcmVzc30sIHtzb3J0OntoZWlnaHQ6LTF9LCBsaW1pdDo1MH0pLmZldGNoKCk7XG4gICAgfVxufSlcbi8vIFZhbGlkYXRvcnMuaGVscGVycyh7XG4vLyAgICAgdXB0aW1lKCl7XG4vLyAgICAgICAgIC8vIGNvbnNvbGUubG9nKHRoaXMuYWRkcmVzcyk7XG4vLyAgICAgICAgIGxldCBsYXN0SHVuZHJlZCA9IFZhbGlkYXRvclJlY29yZHMuZmluZCh7YWRkcmVzczp0aGlzLmFkZHJlc3N9LCB7c29ydDp7aGVpZ2h0Oi0xfSwgbGltaXQ6MTAwfSkuZmV0Y2goKTtcbi8vICAgICAgICAgY29uc29sZS5sb2cobGFzdEh1bmRyZWQpO1xuLy8gICAgICAgICBsZXQgdXB0aW1lID0gMDtcbi8vICAgICAgICAgZm9yIChpIGluIGxhc3RIdW5kcmVkKXtcbi8vICAgICAgICAgICAgIGlmIChsYXN0SHVuZHJlZFtpXS5leGlzdHMpe1xuLy8gICAgICAgICAgICAgICAgIHVwdGltZSs9MTtcbi8vICAgICAgICAgICAgIH1cbi8vICAgICAgICAgfVxuLy8gICAgICAgICByZXR1cm4gdXB0aW1lO1xuLy8gICAgIH1cbi8vIH0pIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgVm90aW5nUG93ZXJIaXN0b3J5ID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3ZvdGluZ19wb3dlcl9oaXN0b3J5Jyk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBFdmlkZW5jZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZXZpZGVuY2VzJyk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBWYWxpZGF0b3JTZXRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3ZhbGlkYXRvcl9zZXRzJyk7XG4iLCIvLyBJbXBvcnQgbW9kdWxlcyB1c2VkIGJ5IGJvdGggY2xpZW50IGFuZCBzZXJ2ZXIgdGhyb3VnaCBhIHNpbmdsZSBpbmRleCBlbnRyeSBwb2ludFxuLy8gZS5nLiB1c2VyYWNjb3VudHMgY29uZmlndXJhdGlvbiBmaWxlLlxuIiwiaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vLi4vYXBpL2Jsb2Nrcy9ibG9ja3MuanMnO1xuaW1wb3J0IHsgUHJvcG9zYWxzIH0gZnJvbSAnLi4vLi4vYXBpL3Byb3Bvc2Fscy9wcm9wb3NhbHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9yUmVjb3JkcywgQW5hbHl0aWNzLCBNaXNzZWRCbG9ja3NTdGF0cywgTWlzc2VkQmxvY2tzLCBBdmVyYWdlRGF0YSwgQXZlcmFnZVZhbGlkYXRvckRhdGEgfSBmcm9tICcuLi8uLi9hcGkvcmVjb3Jkcy9yZWNvcmRzLmpzJztcbi8vIGltcG9ydCB7IFN0YXR1cyB9IGZyb20gJy4uLy4uL2FwaS9zdGF0dXMvc3RhdHVzLmpzJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uLy4uL2FwaS90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclNldHMgfSBmcm9tICcuLi8uLi9hcGkvdmFsaWRhdG9yLXNldHMvdmFsaWRhdG9yLXNldHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL2FwaS92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnLi4vLi4vYXBpL3ZvdGluZy1wb3dlci9oaXN0b3J5LmpzJztcbmltcG9ydCB7IEV2aWRlbmNlcyB9IGZyb20gJy4uLy4uL2FwaS9ldmlkZW5jZXMvZXZpZGVuY2VzLmpzJztcbmltcG9ydCB7IENvaW5TdGF0cyB9IGZyb20gJy4uLy4uL2FwaS9jb2luLXN0YXRzL2NvaW4tc3RhdHMuanMnO1xuaW1wb3J0IHsgQ2hhaW5TdGF0ZXMgfSBmcm9tICcuLi8uLi9hcGkvY2hhaW4vY2hhaW4uanMnO1xuXG5DaGFpblN0YXRlcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2hlaWdodDogLTF9LHt1bmlxdWU6dHJ1ZX0pO1xuXG5CbG9ja3Njb24ucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtoZWlnaHQ6IC0xfSx7dW5pcXVlOnRydWV9KTtcbkJsb2Nrc2Nvbi5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2VyQWRkcmVzczoxfSk7XG5cbkV2aWRlbmNlcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2hlaWdodDogLTF9KTtcblxuUHJvcG9zYWxzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7cHJvcG9zYWxJZDogMX0sIHt1bmlxdWU6dHJ1ZX0pO1xuXG5WYWxpZGF0b3JSZWNvcmRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7YWRkcmVzczoxLGhlaWdodDogLTF9LCB7dW5pcXVlOjF9KTtcblZhbGlkYXRvclJlY29yZHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHthZGRyZXNzOjEsZXhpc3RzOjEsIGhlaWdodDogLTF9KTtcblxuQW5hbHl0aWNzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7aGVpZ2h0OiAtMX0sIHt1bmlxdWU6dHJ1ZX0pXG5cbk1pc3NlZEJsb2Nrcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2VyOjEsIHZvdGVyOjEsIHVwZGF0ZWRBdDogLTF9KTtcbk1pc3NlZEJsb2Nrcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2VyOjEsIGJsb2NrSGVpZ2h0Oi0xfSk7XG5NaXNzZWRCbG9ja3MucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHt2b3RlcjoxLCBibG9ja0hlaWdodDotMX0pO1xuTWlzc2VkQmxvY2tzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7dm90ZXI6MSwgcHJvcG9zZXI6MSwgYmxvY2tIZWlnaHQ6LTF9LCB7dW5pcXVlOnRydWV9KTtcblxuTWlzc2VkQmxvY2tzU3RhdHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NlcjoxfSk7XG5NaXNzZWRCbG9ja3NTdGF0cy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3ZvdGVyOjF9KTtcbk1pc3NlZEJsb2Nrc1N0YXRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7cHJvcG9zZXI6MSwgdm90ZXI6MX0se3VuaXF1ZTp0cnVlfSk7XG5cbkF2ZXJhZ2VEYXRhLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7dHlwZToxLCBjcmVhdGVkQXQ6LTF9LHt1bmlxdWU6dHJ1ZX0pO1xuQXZlcmFnZVZhbGlkYXRvckRhdGEucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NlckFkZHJlc3M6MSxjcmVhdGVkQXQ6LTF9LHt1bmlxdWU6dHJ1ZX0pO1xuLy8gU3RhdHVzLnJhd0NvbGxlY3Rpb24uY3JlYXRlSW5kZXgoe30pXG5cblRyYW5zYWN0aW9ucy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3R4aGFzaDoxfSx7dW5pcXVlOnRydWV9KTtcblRyYW5zYWN0aW9ucy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2hlaWdodDotMX0pO1xuLy8gVHJhbnNhY3Rpb25zLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7YWN0aW9uOjF9KTtcblRyYW5zYWN0aW9ucy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe1wiZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCI6MX0pO1xuVHJhbnNhY3Rpb25zLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOjF9KTtcblxuVmFsaWRhdG9yU2V0cy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2Jsb2NrX2hlaWdodDotMX0pO1xuXG5WYWxpZGF0b3JzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7YWRkcmVzczoxfSx7dW5pcXVlOnRydWUsIHBhcnRpYWxGaWx0ZXJFeHByZXNzaW9uOiB7IGFkZHJlc3M6IHsgJGV4aXN0czogdHJ1ZSB9IH0gfSk7XG5WYWxpZGF0b3JzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7Y29uc2Vuc3VzX3B1YmtleToxfSx7dW5pcXVlOnRydWV9KTtcblZhbGlkYXRvcnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtcInB1Yl9rZXkudmFsdWVcIjoxfSx7dW5pcXVlOnRydWUsIHBhcnRpYWxGaWx0ZXJFeHByZXNzaW9uOiB7IFwicHViX2tleS52YWx1ZVwiOiB7ICRleGlzdHM6IHRydWUgfSB9fSk7XG5cblZvdGluZ1Bvd2VySGlzdG9yeS5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2FkZHJlc3M6MSxoZWlnaHQ6LTF9KTtcblZvdGluZ1Bvd2VySGlzdG9yeS5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3R5cGU6MX0pO1xuXG5Db2luU3RhdHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtsYXN0X3VwZGF0ZWRfYXQ6LTF9LHt1bmlxdWU6dHJ1ZX0pO1xuIiwiLy8gSW1wb3J0IHNlcnZlciBzdGFydHVwIHRocm91Z2ggYSBzaW5nbGUgaW5kZXggZW50cnkgcG9pbnRcblxuaW1wb3J0ICcuL3V0aWwuanMnO1xuaW1wb3J0ICcuL3JlZ2lzdGVyLWFwaS5qcyc7XG5pbXBvcnQgJy4vY3JlYXRlLWluZGV4ZXMuanMnO1xuXG4vLyBpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuLy8gaW1wb3J0IHsgcmVuZGVyVG9Ob2RlU3RyZWFtIH0gZnJvbSAncmVhY3QtZG9tL3NlcnZlcic7XG4vLyBpbXBvcnQgeyByZW5kZXJUb1N0cmluZyB9IGZyb20gXCJyZWFjdC1kb20vc2VydmVyXCI7XG5pbXBvcnQgeyBvblBhZ2VMb2FkIH0gZnJvbSAnbWV0ZW9yL3NlcnZlci1yZW5kZXInO1xuLy8gaW1wb3J0IHsgU3RhdGljUm91dGVyIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG4vLyBpbXBvcnQgeyBTZXJ2ZXJTdHlsZVNoZWV0IH0gZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCJcbmltcG9ydCB7IEhlbG1ldCB9IGZyb20gJ3JlYWN0LWhlbG1ldCc7XG5cbi8vIGltcG9ydCBBcHAgZnJvbSAnLi4vLi4vdWkvQXBwLmpzeCc7XG5cbm9uUGFnZUxvYWQoc2luayA9PiB7XG4gICAgLy8gY29uc3QgY29udGV4dCA9IHt9O1xuICAgIC8vIGNvbnN0IHNoZWV0ID0gbmV3IFNlcnZlclN0eWxlU2hlZXQoKVxuXG4gICAgLy8gY29uc3QgaHRtbCA9IHJlbmRlclRvU3RyaW5nKHNoZWV0LmNvbGxlY3RTdHlsZXMoXG4gICAgLy8gICAgIDxTdGF0aWNSb3V0ZXIgbG9jYXRpb249e3NpbmsucmVxdWVzdC51cmx9IGNvbnRleHQ9e2NvbnRleHR9PlxuICAgIC8vICAgICAgICAgPEFwcCAvPlxuICAgIC8vICAgICA8L1N0YXRpY1JvdXRlcj5cbiAgICAvLyAgICkpO1xuXG4gICAgLy8gc2luay5yZW5kZXJJbnRvRWxlbWVudEJ5SWQoJ2FwcCcsIGh0bWwpO1xuXG4gICAgY29uc3QgaGVsbWV0ID0gSGVsbWV0LnJlbmRlclN0YXRpYygpO1xuICAgIHNpbmsuYXBwZW5kVG9IZWFkKGhlbG1ldC5tZXRhLnRvU3RyaW5nKCkpO1xuICAgIHNpbmsuYXBwZW5kVG9IZWFkKGhlbG1ldC50aXRsZS50b1N0cmluZygpKTtcblxuICAgIC8vIHNpbmsuYXBwZW5kVG9IZWFkKHNoZWV0LmdldFN0eWxlVGFncygpKTtcbn0pOyIsIi8vIFJlZ2lzdGVyIHlvdXIgYXBpcyBoZXJlXG5cbmltcG9ydCAnLi4vLi4vYXBpL2xlZGdlci9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL2NoYWluL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL2NoYWluL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9ibG9ja3Mvc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvYmxvY2tzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS92YWxpZGF0b3JzL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL3ZhbGlkYXRvcnMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL3JlY29yZHMvc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvcmVjb3Jkcy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvcHJvcG9zYWxzL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL3Byb3Bvc2Fscy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvdm90aW5nLXBvd2VyL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS90cmFuc2FjdGlvbnMvc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvdHJhbnNhY3Rpb25zL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9kZWxlZ2F0aW9ucy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9kZWxlZ2F0aW9ucy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvc3RhdHVzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9hY2NvdW50cy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL2NvaW4tc3RhdHMvc2VydmVyL21ldGhvZHMuanMnO1xuIiwiaW1wb3J0IGJlY2gzMiBmcm9tICdiZWNoMzInXG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuaW1wb3J0ICogYXMgY2hlZXJpbyBmcm9tICdjaGVlcmlvJztcblxuLy8gTG9hZCBmdXR1cmUgZnJvbSBmaWJlcnNcbnZhciBGdXR1cmUgPSBOcG0ucmVxdWlyZShcImZpYmVycy9mdXR1cmVcIik7XG4vLyBMb2FkIGV4ZWNcbnZhciBleGVjID0gTnBtLnJlcXVpcmUoXCJjaGlsZF9wcm9jZXNzXCIpLmV4ZWM7XG5cbmZ1bmN0aW9uIHRvSGV4U3RyaW5nKGJ5dGVBcnJheSkge1xuICAgIHJldHVybiBieXRlQXJyYXkubWFwKGZ1bmN0aW9uKGJ5dGUpIHtcbiAgICAgICAgcmV0dXJuICgnMCcgKyAoYnl0ZSAmIDB4RkYpLnRvU3RyaW5nKDE2KSkuc2xpY2UoLTIpO1xuICAgIH0pLmpvaW4oJycpXG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICBwdWJrZXlUb0JlY2gzMjogZnVuY3Rpb24ocHVia2V5LCBwcmVmaXgpIHtcbiAgICAgICAgLy8gJzE2MjRERTY0MjAnIGlzIGVkMjU1MTkgcHVia2V5IHByZWZpeFxuICAgICAgICBsZXQgcHVia2V5QW1pbm9QcmVmaXggPSBCdWZmZXIuZnJvbSgnMTYyNERFNjQyMCcsICdoZXgnKVxuICAgICAgICBsZXQgYnVmZmVyID0gQnVmZmVyLmFsbG9jKDM3KVxuICAgICAgICBwdWJrZXlBbWlub1ByZWZpeC5jb3B5KGJ1ZmZlciwgMClcbiAgICAgICAgQnVmZmVyLmZyb20ocHVia2V5LnZhbHVlLCAnYmFzZTY0JykuY29weShidWZmZXIsIHB1YmtleUFtaW5vUHJlZml4Lmxlbmd0aClcbiAgICAgICAgcmV0dXJuIGJlY2gzMi5lbmNvZGUocHJlZml4LCBiZWNoMzIudG9Xb3JkcyhidWZmZXIpKVxuICAgIH0sXG4gICAgYmVjaDMyVG9QdWJrZXk6IGZ1bmN0aW9uKHB1YmtleSkge1xuICAgICAgICAvLyAnMTYyNERFNjQyMCcgaXMgZWQyNTUxOSBwdWJrZXkgcHJlZml4XG4gICAgICAgIGxldCBwdWJrZXlBbWlub1ByZWZpeCA9IEJ1ZmZlci5mcm9tKCcxNjI0REU2NDIwJywgJ2hleCcpXG4gICAgICAgIGxldCBidWZmZXIgPSBCdWZmZXIuZnJvbShiZWNoMzIuZnJvbVdvcmRzKGJlY2gzMi5kZWNvZGUocHVia2V5KS53b3JkcykpO1xuICAgICAgICByZXR1cm4gYnVmZmVyLnNsaWNlKHB1YmtleUFtaW5vUHJlZml4Lmxlbmd0aCkudG9TdHJpbmcoJ2Jhc2U2NCcpO1xuICAgIH0sXG4gICAgZ2V0RGVsZWdhdG9yOiBmdW5jdGlvbihvcGVyYXRvckFkZHIpe1xuICAgICAgICBsZXQgYWRkcmVzcyA9IGJlY2gzMi5kZWNvZGUob3BlcmF0b3JBZGRyKTtcbiAgICAgICAgcmV0dXJuIGJlY2gzMi5lbmNvZGUoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhBY2NBZGRyLCBhZGRyZXNzLndvcmRzKTtcbiAgICB9LFxuICAgIGdldEtleWJhc2VUZWFtUGljOiBmdW5jdGlvbihrZXliYXNlVXJsKXtcbiAgICAgICAgbGV0IHRlYW1QYWdlID0gSFRUUC5nZXQoa2V5YmFzZVVybCk7XG4gICAgICAgIGlmICh0ZWFtUGFnZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICBsZXQgcGFnZSA9IGNoZWVyaW8ubG9hZCh0ZWFtUGFnZS5jb250ZW50KTtcbiAgICAgICAgICAgIHJldHVybiBwYWdlKFwiLmtiLW1haW4tY2FyZCBpbWdcIikuYXR0cignc3JjJyk7XG4gICAgICAgIH1cbiAgICB9XG59KVxuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFVuY29udHJvbGxlZFRvb2x0aXAgfSBmcm9tICdyZWFjdHN0cmFwJztcblxuZXhwb3J0IGNvbnN0IERlbm9tU3ltYm9sID0gKHByb3BzKSA9PiB7XG4gICAgc3dpdGNoIChwcm9wcy5kZW5vbSl7XG4gICAgY2FzZSBcInN0ZWFrXCI6XG4gICAgICAgIHJldHVybiAn8J+lqSc7XG4gICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuICfwn42FJztcbiAgICB9XG59XG5cblxuZXhwb3J0IGNvbnN0IFByb3Bvc2FsU3RhdHVzSWNvbiA9IChwcm9wcykgPT4ge1xuICAgIHN3aXRjaCAocHJvcHMuc3RhdHVzKXtcbiAgICBjYXNlICdQYXNzZWQnOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLWNoZWNrLWNpcmNsZSB0ZXh0LXN1Y2Nlc3NcIj48L2k+O1xuICAgIGNhc2UgJ1JlamVjdGVkJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS10aW1lcy1jaXJjbGUgdGV4dC1kYW5nZXJcIj48L2k+O1xuICAgIGNhc2UgJ1JlbW92ZWQnOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLXRyYXNoLWFsdCB0ZXh0LWRhcmtcIj48L2k+XG4gICAgY2FzZSAnRGVwb3NpdFBlcmlvZCc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtYmF0dGVyeS1oYWxmIHRleHQtd2FybmluZ1wiPjwvaT47XG4gICAgY2FzZSAnVm90aW5nUGVyaW9kJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1oYW5kLXBhcGVyIHRleHQtaW5mb1wiPjwvaT47XG4gICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIDxpPjwvaT47XG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgVm90ZUljb24gPSAocHJvcHMpID0+IHtcbiAgICBzd2l0Y2ggKHByb3BzLnZvdGUpe1xuICAgIGNhc2UgJ3llcyc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtY2hlY2sgdGV4dC1zdWNjZXNzXCI+PC9pPjtcbiAgICBjYXNlICdubyc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtdGltZXMgdGV4dC1kYW5nZXJcIj48L2k+O1xuICAgIGNhc2UgJ2Fic3RhaW4nOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLXVzZXItc2xhc2ggdGV4dC13YXJuaW5nXCI+PC9pPjtcbiAgICBjYXNlICdub193aXRoX3ZldG8nOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLWV4Y2xhbWF0aW9uLXRyaWFuZ2xlIHRleHQtaW5mb1wiPjwvaT47XG4gICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIDxpPjwvaT47XG4gICAgfVxufVxuXG5leHBvcnQgY29uc3QgVHhJY29uID0gKHByb3BzKSA9PiB7XG4gICAgaWYgKHByb3BzLnZhbGlkKXtcbiAgICAgICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc3VjY2VzcyB0ZXh0LW5vd3JhcFwiPjxpIGNsYXNzTmFtZT1cImZhcyBmYS1jaGVjay1jaXJjbGVcIj48L2k+PC9zcGFuPjtcbiAgICB9XG4gICAgZWxzZXtcbiAgICAgICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZGFuZ2VyIHRleHQtbm93cmFwXCI+PGkgY2xhc3NOYW1lPVwiZmFzIGZhLXRpbWVzLWNpcmNsZVwiPjwvaT48L3NwYW4+O1xuICAgIH1cbn1cblxuZXhwb3J0IGNsYXNzIEluZm9JY29uIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50IHtcbiAgICBjb25zdHJ1Y3Rvcihwcm9wcykge1xuICAgICAgICBzdXBlcihwcm9wcyk7XG4gICAgICAgIHRoaXMucmVmID0gUmVhY3QuY3JlYXRlUmVmKCk7XG4gICAgfVxuXG4gICAgcmVuZGVyKCkge1xuICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgPGkga2V5PSdpY29uJyBjbGFzc05hbWU9J21hdGVyaWFsLWljb25zIGluZm8taWNvbicgcmVmPXt0aGlzLnJlZn0+aW5mbzwvaT4sXG4gICAgICAgICAgICA8VW5jb250cm9sbGVkVG9vbHRpcCBrZXk9J3Rvb2x0aXAnIHBsYWNlbWVudD0ncmlnaHQnIHRhcmdldD17dGhpcy5yZWZ9PlxuICAgICAgICAgICAgICAgIHt0aGlzLnByb3BzLmNoaWxkcmVuP3RoaXMucHJvcHMuY2hpbGRyZW46dGhpcy5wcm9wcy50b29sdGlwVGV4dH1cbiAgICAgICAgICAgIDwvVW5jb250cm9sbGVkVG9vbHRpcD5cbiAgICAgICAgXVxuICAgIH1cbn0iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCBudW1icm8gZnJvbSAnbnVtYnJvJztcblxuYXV0b2Zvcm1hdCA9ICh2YWx1ZSkgPT4ge1xuXHRsZXQgZm9ybWF0dGVyID0gJzAsMC4wMDAwJztcblx0dmFsdWUgPSBNYXRoLnJvdW5kKHZhbHVlICogMTAwMCkgLyAxMDAwXG5cdGlmIChNYXRoLnJvdW5kKHZhbHVlKSA9PT0gdmFsdWUpXG5cdFx0Zm9ybWF0dGVyID0gJzAsMCdcblx0ZWxzZSBpZiAoTWF0aC5yb3VuZCh2YWx1ZSoxMCkgPT09IHZhbHVlKjEwKVxuXHRcdGZvcm1hdHRlciA9ICcwLDAuMCdcblx0ZWxzZSBpZiAoTWF0aC5yb3VuZCh2YWx1ZSoxMDApID09PSB2YWx1ZSoxMDApXG5cdFx0Zm9ybWF0dGVyID0gJzAsMC4wMCdcblx0ZWxzZSBpZiAoTWF0aC5yb3VuZCh2YWx1ZSoxMDAwKSA9PT0gdmFsdWUqMTAwMClcblx0XHRmb3JtYXR0ZXIgPSAnMCwwLjAwMCdcblx0cmV0dXJuIG51bWJybyh2YWx1ZSkuZm9ybWF0KGZvcm1hdHRlcilcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ29pbiB7XG5cdHN0YXRpYyBTdGFraW5nRGVub20gPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLnN0YWtpbmdEZW5vbTtcblx0c3RhdGljIFN0YWtpbmdEZW5vbVBsdXJhbCA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuc3Rha2luZ0Rlbm9tUGx1cmFsIHx8IChDb2luLlN0YWtpbmdEZW5vbSArICdzJyk7XG5cdHN0YXRpYyBNaW50aW5nRGVub20gPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLm1pbnRpbmdEZW5vbTtcblx0c3RhdGljIFN0YWtpbmdGcmFjdGlvbiA9IE51bWJlcihNZXRlb3Iuc2V0dGluZ3MucHVibGljLnN0YWtpbmdGcmFjdGlvbik7XG5cdHN0YXRpYyBNaW5TdGFrZSA9IDEgLyBOdW1iZXIoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5zdGFraW5nRnJhY3Rpb24pO1xuXG5cdGNvbnN0cnVjdG9yKGFtb3VudCwgZGVub209bnVsbCkge1xuXHRcdGlmICh0eXBlb2YgYW1vdW50ID09PSAnb2JqZWN0Jylcblx0XHRcdCh7YW1vdW50LCBkZW5vbX0gPSBhbW91bnQpXG5cdFx0aWYgKCFkZW5vbSB8fCBkZW5vbS50b0xvd2VyQ2FzZSgpID09PSBDb2luLk1pbnRpbmdEZW5vbS50b0xvd2VyQ2FzZSgpKSB7XG5cdFx0XHR0aGlzLl9hbW91bnQgPSBOdW1iZXIoYW1vdW50KTtcblx0XHR9IGVsc2UgaWYgKGRlbm9tLnRvTG93ZXJDYXNlKCkgPT09IENvaW4uU3Rha2luZ0Rlbm9tLnRvTG93ZXJDYXNlKCkpIHtcblx0XHRcdHRoaXMuX2Ftb3VudCA9IE51bWJlcihhbW91bnQpICogQ29pbi5TdGFraW5nRnJhY3Rpb247XG5cdFx0fVxuXHRcdGVsc2Uge1xuXHRcdFx0dGhyb3cgRXJyb3IoYHVuc3VwcG9ydGVkIGRlbm9tICR7ZGVub219YCk7XG5cdFx0fVxuXHR9XG5cblx0Z2V0IGFtb3VudCAoKSB7XG5cdFx0cmV0dXJuIHRoaXMuX2Ftb3VudDtcblx0fVxuXG5cdGdldCBzdGFraW5nQW1vdW50ICgpIHtcblx0XHRyZXR1cm4gdGhpcy5fYW1vdW50IC8gQ29pbi5TdGFraW5nRnJhY3Rpb247XG5cdH1cblxuXHR0b1N0cmluZyAocHJlY2lzaW9uKSB7XG5cdFx0Ly8gZGVmYXVsdCB0byBkaXNwbGF5IGluIG1pbnQgZGVub20gaWYgaXQgaGFzIG1vcmUgdGhhbiA0IGRlY2ltYWwgcGxhY2VzXG5cdFx0bGV0IG1pblN0YWtlID0gQ29pbi5TdGFraW5nRnJhY3Rpb24vKHByZWNpc2lvbj9NYXRoLnBvdygxMCwgcHJlY2lzaW9uKToxMDAwMClcblx0XHRpZiAodGhpcy5hbW91bnQgPCBtaW5TdGFrZSkge1xuXHRcdFx0cmV0dXJuIGAke251bWJybyh0aGlzLmFtb3VudCkuZm9ybWF0KCcwLDAnKX0gJHtDb2luLk1pbnRpbmdEZW5vbX1gO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRyZXR1cm4gYCR7cHJlY2lzaW9uP251bWJybyh0aGlzLnN0YWtpbmdBbW91bnQpLmZvcm1hdCgnMCwwLicgKyAnMCcucmVwZWF0KHByZWNpc2lvbikpOmF1dG9mb3JtYXQodGhpcy5zdGFraW5nQW1vdW50KX0gJHtDb2luLlN0YWtpbmdEZW5vbX1gXG5cdFx0fVxuXHR9XG5cblx0bWludFN0cmluZyAoZm9ybWF0dGVyKSB7XG5cdFx0bGV0IGFtb3VudCA9IHRoaXMuYW1vdW50XG5cdFx0aWYgKGZvcm1hdHRlcikge1xuXHRcdFx0YW1vdW50ID0gbnVtYnJvKGFtb3VudCkuZm9ybWF0KGZvcm1hdHRlcilcblx0XHR9XG5cdFx0cmV0dXJuIGAke2Ftb3VudH0gJHtDb2luLk1pbnRpbmdEZW5vbX1gO1xuXHR9XG5cblx0c3Rha2VTdHJpbmcgKGZvcm1hdHRlcikge1xuXHRcdGxldCBhbW91bnQgPSB0aGlzLnN0YWtpbmdBbW91bnRcblx0XHRpZiAoZm9ybWF0dGVyKSB7XG5cdFx0XHRhbW91bnQgPSBudW1icm8oYW1vdW50KS5mb3JtYXQoZm9ybWF0dGVyKVxuXHRcdH1cblx0XHRyZXR1cm4gYCR7YW1vdW50fSAke0NvaW4uU3Rha2luZ0Rlbm9tfWA7XG5cdH1cbn0iLCIvLyBTZXJ2ZXIgZW50cnkgcG9pbnQsIGltcG9ydHMgYWxsIHNlcnZlciBjb2RlXG5cbmltcG9ydCAnL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXInO1xuaW1wb3J0ICcvaW1wb3J0cy9zdGFydHVwL2JvdGgnO1xuLy8gaW1wb3J0IG1vbWVudCBmcm9tICdtb21lbnQnO1xuLy8gaW1wb3J0ICcvaW1wb3J0cy9hcGkvYmxvY2tzL2Jsb2Nrcy5qcyc7XG5cblNZTkNJTkcgPSBmYWxzZTtcbkNPVU5UTUlTU0VEQkxPQ0tTID0gZmFsc2U7XG5DT1VOVE1JU1NFREJMT0NLU1NUQVRTID0gZmFsc2U7XG5SUEMgPSBNZXRlb3Iuc2V0dGluZ3MucmVtb3RlLnJwYztcbkxDRCA9IE1ldGVvci5zZXR0aW5ncy5yZW1vdGUubGNkO1xudGltZXJCbG9ja3MgPSAwO1xudGltZXJDaGFpbiA9IDA7XG50aW1lckNvbnNlbnN1cyA9IDA7XG50aW1lclByb3Bvc2FsID0gMDtcbnRpbWVyUHJvcG9zYWxzUmVzdWx0cyA9IDA7XG50aW1lck1pc3NlZEJsb2NrID0gMDtcbnRpbWVyRGVsZWdhdGlvbiA9IDA7XG50aW1lckFnZ3JlZ2F0ZSA9IDA7XG5cbmNvbnN0IERFRkFVTFRTRVRUSU5HUyA9ICcvZGVmYXVsdF9zZXR0aW5ncy5qc29uJztcblxudXBkYXRlQ2hhaW5TdGF0dXMgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ2NoYWluLnVwZGF0ZVN0YXR1cycsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInVwZGF0ZVN0YXR1czogXCIrZXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInVwZGF0ZVN0YXR1czogXCIrcmVzdWx0KTtcbiAgICAgICAgfVxuICAgIH0pXG59XG5cbnVwZGF0ZUJsb2NrID0gKCkgPT4ge1xuICAgIE1ldGVvci5jYWxsKCdibG9ja3MuYmxvY2tzVXBkYXRlJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidXBkYXRlQmxvY2tzOiBcIitlcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidXBkYXRlQmxvY2tzOiBcIityZXN1bHQpO1xuICAgICAgICB9XG4gICAgfSlcbn1cblxuZ2V0Q29uc2Vuc3VzU3RhdGUgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ2NoYWluLmdldENvbnNlbnN1c1N0YXRlJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IGNvbnNlbnN1czogXCIrZXJyb3IpXG4gICAgICAgIH1cbiAgICB9KVxufVxuXG5nZXRQcm9wb3NhbHMgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ3Byb3Bvc2Fscy5nZXRQcm9wb3NhbHMnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgcHJvcG9zYWw6IFwiKyBlcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBwcm9wb3NhbDogXCIrcmVzdWx0KTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG5nZXRQcm9wb3NhbHNSZXN1bHRzID0gKCkgPT4ge1xuICAgIE1ldGVvci5jYWxsKCdwcm9wb3NhbHMuZ2V0UHJvcG9zYWxSZXN1bHRzJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IHByb3Bvc2FscyByZXN1bHQ6IFwiK2Vycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IHByb3Bvc2FscyByZXN1bHQ6IFwiK3Jlc3VsdCk7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cblxudXBkYXRlTWlzc2VkQmxvY2tzID0gKCkgPT4ge1xuICAgIE1ldGVvci5jYWxsKCdWYWxpZGF0b3JSZWNvcmRzLmNhbGN1bGF0ZU1pc3NlZEJsb2NrcycsIChlcnJvciwgcmVzdWx0KSA9PntcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwibWlzc2VkIGJsb2NrcyBlcnJvcjogXCIrIGVycm9yKVxuICAgICAgICB9XG4gICAgICAgIGlmIChyZXN1bHQpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJtaXNzZWQgYmxvY2tzIG9rOlwiICsgcmVzdWx0KTtcbiAgICAgICAgfVxuICAgIH0pO1xuLypcbiAgICBNZXRlb3IuY2FsbCgnVmFsaWRhdG9yUmVjb3Jkcy5jYWxjdWxhdGVNaXNzZWRCbG9ja3NTdGF0cycsIChlcnJvciwgcmVzdWx0KSA9PntcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwibWlzc2VkIGJsb2NrcyBzdGF0cyBlcnJvcjogXCIrIGVycm9yKVxuICAgICAgICB9XG4gICAgICAgIGlmIChyZXN1bHQpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJtaXNzZWQgYmxvY2tzIHN0YXRzIG9rOlwiICsgcmVzdWx0KTtcbiAgICAgICAgfVxuICAgIH0pO1xuKi9cbn1cblxuZ2V0RGVsZWdhdGlvbnMgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ2RlbGVnYXRpb25zLmdldERlbGVnYXRpb25zJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IGRlbGVnYXRpb25zIGVycm9yOiBcIisgZXJyb3IpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IGRlbGVnYXRpb25zIG9rOiBcIisgcmVzdWx0KVxuICAgICAgICB9XG4gICAgfSk7XG59XG5cbmFnZ3JlZ2F0ZU1pbnV0ZWx5ID0gKCkgPT57XG4gICAgLy8gZG9pbmcgc29tZXRoaW5nIGV2ZXJ5IG1pblxuICAgIE1ldGVvci5jYWxsKCdBbmFseXRpY3MuYWdncmVnYXRlQmxvY2tUaW1lQW5kVm90aW5nUG93ZXInLCBcIm1cIiwgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRlIG1pbnV0ZWx5IGJsb2NrIHRpbWUgZXJyb3I6IFwiK2Vycm9yKVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSBtaW51dGVseSBibG9jayB0aW1lIG9rOiBcIityZXN1bHQpXG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIE1ldGVvci5jYWxsKCdjb2luU3RhdHMuZ2V0Q29pblN0YXRzJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IGNvaW4gc3RhdHMgZXJyb3I6IFwiK2Vycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgY29pbiBzdGF0cyBvazogXCIrcmVzdWx0KVxuICAgICAgICB9XG4gICAgfSk7XG59XG5cbmFnZ3JlZ2F0ZUhvdXJseSA9ICgpID0+e1xuICAgIC8vIGRvaW5nIHNvbWV0aGluZyBldmVyeSBob3VyXG4gICAgTWV0ZW9yLmNhbGwoJ0FuYWx5dGljcy5hZ2dyZWdhdGVCbG9ja1RpbWVBbmRWb3RpbmdQb3dlcicsIFwiaFwiLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgaG91cmx5IGJsb2NrIHRpbWUgZXJyb3I6IFwiK2Vycm9yKVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSBob3VybHkgYmxvY2sgdGltZSBvazogXCIrcmVzdWx0KVxuICAgICAgICB9XG4gICAgfSk7XG59XG5cbmFnZ3JlZ2F0ZURhaWx5ID0gKCkgPT57XG4gICAgLy8gZG9pbmcgc29tdGhpbmcgZXZlcnkgZGF5XG4gICAgTWV0ZW9yLmNhbGwoJ0FuYWx5dGljcy5hZ2dyZWdhdGVCbG9ja1RpbWVBbmRWb3RpbmdQb3dlcicsIFwiZFwiLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgZGFpbHkgYmxvY2sgdGltZSBlcnJvcjogXCIrZXJyb3IpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRlIGRhaWx5IGJsb2NrIHRpbWUgb2s6IFwiK3Jlc3VsdClcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgTWV0ZW9yLmNhbGwoJ0FuYWx5dGljcy5hZ2dyZWdhdGVWYWxpZGF0b3JEYWlseUJsb2NrVGltZScsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSB2YWxpZGF0b3JzIGJsb2NrIHRpbWUgZXJyb3I6XCIrIGVycm9yKVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgdmFsaWRhdG9ycyBibG9jayB0aW1lIG9rOlwiKyByZXN1bHQpO1xuICAgICAgICB9XG4gICAgfSlcbn1cblxuXG5cbk1ldGVvci5zdGFydHVwKGZ1bmN0aW9uKCl7XG4gICAgaWYgKE1ldGVvci5pc0RldmVsb3BtZW50KXtcbiAgICAgICAgcHJvY2Vzcy5lbnYuTk9ERV9UTFNfUkVKRUNUX1VOQVVUSE9SSVpFRCA9IDA7XG4gICAgICAgIGltcG9ydCBERUZBVUxUU0VUVElOR1NKU09OIGZyb20gJy4uL2RlZmF1bHRfc2V0dGluZ3MuanNvbidcbiAgICAgICAgT2JqZWN0LmtleXMoREVGQVVMVFNFVFRJTkdTSlNPTikuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICAgICAgICBpZiAoTWV0ZW9yLnNldHRpbmdzW2tleV0gPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKGBDSEVDSyBTRVRUSU5HUyBKU09OOiAke2tleX0gaXMgbWlzc2luZyBmcm9tIHNldHRpbmdzYClcbiAgICAgICAgICAgICAgICBNZXRlb3Iuc2V0dGluZ3Nba2V5XSA9IHt9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgT2JqZWN0LmtleXMoREVGQVVMVFNFVFRJTkdTSlNPTltrZXldKS5mb3JFYWNoKChwYXJhbSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChNZXRlb3Iuc2V0dGluZ3Nba2V5XVtwYXJhbV0gPT0gdW5kZWZpbmVkKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKGBDSEVDSyBTRVRUSU5HUyBKU09OOiAke2tleX0uJHtwYXJhbX0gaXMgbWlzc2luZyBmcm9tIHNldHRpbmdzYClcbiAgICAgICAgICAgICAgICAgICAgTWV0ZW9yLnNldHRpbmdzW2tleV1bcGFyYW1dID0gREVGQVVMVFNFVFRJTkdTSlNPTltrZXldW3BhcmFtXVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0pXG4gICAgfVxuXG4gICAgTWV0ZW9yLmNhbGwoJ2NoYWluLmdlbmVzaXMnLCAoZXJyLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZXN1bHQpe1xuICAgICAgICAgICAgaWYgKE1ldGVvci5zZXR0aW5ncy5kZWJ1Zy5zdGFydFRpbWVyKXtcbiAgICAgICAgICAgICAgICB0aW1lckNvbnNlbnN1cyA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgICAgICBnZXRDb25zZW5zdXNTdGF0ZSgpO1xuICAgICAgICAgICAgICAgIH0sIE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuY29uc2Vuc3VzSW50ZXJ2YWwpO1xuXG4gICAgICAgICAgICAgICAgdGltZXJCbG9ja3MgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlQmxvY2soKTtcbiAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLmJsb2NrSW50ZXJ2YWwpO1xuXG4gICAgICAgICAgICAgICAgdGltZXJDaGFpbiA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVDaGFpblN0YXR1cygpO1xuICAgICAgICAgICAgICAgIH0sIE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuc3RhdHVzSW50ZXJ2YWwpO1xuXG4gICAgICAgICAgICAgICAgdGltZXJQcm9wb3NhbCA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgICAgICBnZXRQcm9wb3NhbHMoKTtcbiAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLnByb3Bvc2FsSW50ZXJ2YWwpO1xuXG4gICAgICAgICAgICAgICAgdGltZXJQcm9wb3NhbHNSZXN1bHRzID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgIGdldFByb3Bvc2Fsc1Jlc3VsdHMoKTtcbiAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLnByb3Bvc2FsSW50ZXJ2YWwpO1xuXG4gICAgICAgICAgICAgICAgdGltZXJNaXNzZWRCbG9jayA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVNaXNzZWRCbG9ja3MoKTtcbiAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLm1pc3NlZEJsb2Nrc0ludGVydmFsKTtcblxuICAgICAgICAgICAgICAgIHRpbWVyRGVsZWdhdGlvbiA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgICAgICBnZXREZWxlZ2F0aW9ucygpO1xuICAgICAgICAgICAgICAgIH0sIE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuZGVsZWdhdGlvbkludGVydmFsKTtcblxuICAgICAgICAgICAgICAgIHRpbWVyQWdncmVnYXRlID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgIGxldCBub3cgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoKG5vdy5nZXRVVENTZWNvbmRzKCkgPT0gMCkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgYWdncmVnYXRlTWludXRlbHkoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGlmICgobm93LmdldFVUQ01pbnV0ZXMoKSA9PSAwKSAmJiAobm93LmdldFVUQ1NlY29uZHMoKSA9PSAwKSl7XG4gICAgICAgICAgICAgICAgICAgICAgICBhZ2dyZWdhdGVIb3VybHkoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGlmICgobm93LmdldFVUQ0hvdXJzKCkgPT0gMCkgJiYgKG5vdy5nZXRVVENNaW51dGVzKCkgPT0gMCkgJiYgKG5vdy5nZXRVVENTZWNvbmRzKCkgPT0gMCkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgYWdncmVnYXRlRGFpbHkoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0sIDEwMDApXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9KVxuXG59KTtcbiJdfQ==
