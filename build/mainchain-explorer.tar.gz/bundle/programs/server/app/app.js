var require = meteorInstall({"imports":{"api":{"accounts":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/accounts/server/methods.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Validators;
module.link("/imports/api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);

const fetchFromUrl = url => {
  try {
    let res = HTTP.get(LCD + url);

    if (res.statusCode == 200) {
      return res;
    }

    ;
  } catch (e) {
    console.log(e);
  }
};

Meteor.methods({
  'accounts.getAccountDetail': function (address) {
    this.unblock();
    let url = LCD + '/auth/accounts/' + address;

    try {
      let available = HTTP.get(url);

      if (available.statusCode == 200) {
        let response = JSON.parse(available.content).result;
        let account;
        if (response.type === 'cosmos-sdk/Account') account = response.value;else if (response.type === 'cosmos-sdk/DelayedVestingAccount' || response.type === 'cosmos-sdk/ContinuousVestingAccount') account = response.value.BaseVestingAccount.BaseAccount;
        if (account && account.account_number != null) return account;
        return null;
      }
    } catch (e) {
      console.log(e);
    }
  },
  'accounts.getBalance': function (address) {
    this.unblock();
    let balance = {}; // get available atoms

    let url = LCD + '/bank/balances/' + address;

    try {
      let available = HTTP.get(url);

      if (available.statusCode == 200) {
        // console.log(JSON.parse(available.content))
        balance.available = JSON.parse(available.content).result;
        if (balance.available && balance.available.length > 0) balance.available = balance.available[0];
      }
    } catch (e) {
      console.log(e);
    } // get delegated amnounts


    url = LCD + '/staking/delegators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        balance.delegations = JSON.parse(delegations.content).result;
      }
    } catch (e) {
      console.log(e);
    } // get unbonding


    url = LCD + '/staking/delegators/' + address + '/unbonding_delegations';

    try {
      let unbonding = HTTP.get(url);

      if (unbonding.statusCode == 200) {
        balance.unbonding = JSON.parse(unbonding.content).result;
      }
    } catch (e) {
      console.log(e);
    } // get rewards


    url = LCD + '/distribution/delegators/' + address + '/rewards';

    try {
      let rewards = HTTP.get(url);

      if (rewards.statusCode == 200) {
        balance.rewards = JSON.parse(rewards.content).result.total;
      }
    } catch (e) {
      console.log(e);
    } // get commission


    let validator = Validators.findOne({
      $or: [{
        operator_address: address
      }, {
        delegator_address: address
      }, {
        address: address
      }]
    });

    if (validator) {
      let url = LCD + '/distribution/validators/' + validator.operator_address;
      balance.operator_address = validator.operator_address;

      try {
        let rewards = HTTP.get(url);

        if (rewards.statusCode == 200) {
          let content = JSON.parse(rewards.content).result;
          if (content.val_commission && content.val_commission.length > 0) balance.commission = content.val_commission[0];
        }
      } catch (e) {
        console.log(e);
      }
    }

    return balance;
  },

  'accounts.getDelegation'(address, validator) {
    let url = "/staking/delegators/".concat(address, "/delegations/").concat(validator);
    let delegations = fetchFromUrl(url);
    delegations = delegations && delegations.data.result;
    if (delegations && delegations.shares) delegations.shares = parseFloat(delegations.shares);
    url = "/staking/redelegations?delegator=".concat(address, "&validator_to=").concat(validator);
    let relegations = fetchFromUrl(url);
    relegations = relegations && relegations.data.result;
    let completionTime;

    if (relegations) {
      relegations.forEach(relegation => {
        let entries = relegation.entries;
        let time = new Date(entries[entries.length - 1].completion_time);
        if (!completionTime || time > completionTime) completionTime = time;
      });
      delegations.redelegationCompletionTime = completionTime;
    }

    url = "/staking/delegators/".concat(address, "/unbonding_delegations/").concat(validator);
    let undelegations = fetchFromUrl(url);
    undelegations = undelegations && undelegations.data.result;

    if (undelegations) {
      delegations.unbonding = undelegations.entries.length;
      delegations.unbondingCompletionTime = undelegations.entries[0].completion_time;
    }

    return delegations;
  },

  'accounts.getAllDelegations'(address) {
    let url = LCD + '/staking/delegators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        delegations = JSON.parse(delegations.content).result;

        if (delegations && delegations.length > 0) {
          delegations.forEach((delegation, i) => {
            if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
          });
        }

        return delegations;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  },

  'accounts.getAllUnbondings'(address) {
    let url = LCD + '/staking/delegators/' + address + '/unbonding_delegations';

    try {
      let unbondings = HTTP.get(url);

      if (unbondings.statusCode == 200) {
        unbondings = JSON.parse(unbondings.content).result;
        return unbondings;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  },

  'accounts.getAllRedelegations'(address, validator) {
    let url = "/staking/redelegations?delegator=".concat(address, "&validator_from=").concat(validator);
    let result = fetchFromUrl(url);

    if (result && result.data) {
      let redelegations = {};
      result.data.forEach(redelegation => {
        let entries = redelegation.entries;
        redelegations[redelegation.validator_dst_address] = {
          count: entries.length,
          completionTime: entries[0].completion_time
        };
      });
      return redelegations;
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"blocks":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/server/methods.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Promise;
module.link("meteor/promise", {
  Promise(v) {
    Promise = v;
  }

}, 2);
let Blockscon;
module.link("/imports/api/blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 3);
let Chain;
module.link("/imports/api/chain/chain.js", {
  Chain(v) {
    Chain = v;
  }

}, 4);
let ValidatorSets;
module.link("/imports/api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 5);
let Validators;
module.link("/imports/api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 6);
let ValidatorRecords, Analytics, VPDistributions;
module.link("/imports/api/records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  VPDistributions(v) {
    VPDistributions = v;
  }

}, 7);
let VotingPowerHistory;
module.link("/imports/api/voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 8);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 9);
let Evidences;
module.link("../../evidences/evidences.js", {
  Evidences(v) {
    Evidences = v;
  }

}, 10);
let sha256;
module.link("js-sha256", {
  sha256(v) {
    sha256 = v;
  }

}, 11);
let getAddress;
module.link("tendermint/lib/pubkey", {
  getAddress(v) {
    getAddress = v;
  }

}, 12);
let cheerio;
module.link("cheerio", {
  "*"(v) {
    cheerio = v;
  }

}, 13);

// import Block from '../../../ui/components/Block';
// getValidatorVotingPower = (validators, address) => {
//     for (v in validators){
//         if (validators[v].address == address){
//             return parseInt(validators[v].voting_power);
//         }
//     }
// }
getRemovedValidators = (prevValidators, validators) => {
  // let removeValidators = [];
  for (p in prevValidators) {
    for (v in validators) {
      if (prevValidators[p].address == validators[v].address) {
        prevValidators.splice(p, 1);
      }
    }
  }

  return prevValidators;
};

getValidatorProfileUrl = identity => {
  if (identity.length == 16) {
    let response = HTTP.get("https://keybase.io/_/api/1.0/user/lookup.json?key_suffix=".concat(identity, "&fields=pictures"));

    if (response.statusCode == 200) {
      let them = response.data.them;
      return them && them.length && them[0].pictures && them[0].pictures.primary && them[0].pictures.primary.url;
    } else {
      console.log(JSON.stringify(response));
    }
  } else if (identity.indexOf("keybase.io/team/") > 0) {
    let teamPage = HTTP.get(identity);

    if (teamPage.statusCode == 200) {
      let page = cheerio.load(teamPage.content);
      return page(".kb-main-card img").attr('src');
    } else {
      console.log(JSON.stringify(teamPage));
    }
  }
}; // var filtered = [1, 2, 3, 4, 5].filter(notContainedIn([1, 2, 3, 5]));
// console.log(filtered); // [4]


Meteor.methods({
  'blocks.averageBlockTime'(address) {
    let blocks = Blockscon.find({
      proposerAddress: address
    }).fetch();
    let heights = blocks.map((block, i) => {
      return block.height;
    });
    let blocksStats = Analytics.find({
      height: {
        $in: heights
      }
    }).fetch(); // console.log(blocksStats);

    let totalBlockDiff = 0;

    for (b in blocksStats) {
      totalBlockDiff += blocksStats[b].timeDiff;
    }

    return totalBlockDiff / heights.length;
  },

  'blocks.findUpTime'(address) {
    let collection = ValidatorRecords.rawCollection(); // let aggregateQuery = Meteor.wrapAsync(collection.aggregate, collection);

    var pipeline = [{
      $match: {
        "address": address
      }
    }, // {$project:{address:1,height:1,exists:1}},
    {
      $sort: {
        "height": -1
      }
    }, {
      $limit: Meteor.settings.public.uptimeWindow - 1
    }, {
      $unwind: "$_id"
    }, {
      $group: {
        "_id": "$address",
        "uptime": {
          "$sum": {
            $cond: [{
              $eq: ['$exists', true]
            }, 1, 0]
          }
        }
      }
    }]; // let result = aggregateQuery(pipeline, { cursor: {} });

    return Promise.await(collection.aggregate(pipeline).toArray()); // return .aggregate()
  },

  'blocks.getLatestHeight': function () {
    this.unblock();
    let url = RPC + '/status';

    try {
      let response = HTTP.get(url);
      let status = JSON.parse(response.content);
      return status.result.sync_info.latest_block_height;
    } catch (e) {
      return 0;
    }
  },
  'blocks.getCurrentHeight': function () {
    this.unblock();
    let currHeight = Blockscon.find({}, {
      sort: {
        height: -1
      },
      limit: 1
    }).fetch(); // console.log("currentHeight:"+currHeight);

    let startHeight = Meteor.settings.params.startHeight;

    if (currHeight && currHeight.length == 1) {
      let height = currHeight[0].height;
      if (height > startHeight) return height;
    }

    return startHeight;
  },
  'blocks.blocksUpdate': function () {
    if (SYNCING) return "Syncing...";else console.log("start to sync"); // Meteor.clearInterval(Meteor.timerHandle);
    // get the latest height

    let until = Meteor.call('blocks.getLatestHeight'); // console.log(until);
    // get the current height in db

    let curr = Meteor.call('blocks.getCurrentHeight');
    console.log(curr); // loop if there's update in db

    if (until > curr) {
      SYNCING = true;
      let validatorSet = {}; // get latest validator candidate information

      url = LCD + '/staking/validators';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      url = LCD + '/staking/validators?status=unbonding';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      url = LCD + '/staking/validators?status=unbonded';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      let totalValidators = Object.keys(validatorSet).length;
      console.log("all validators: " + totalValidators);

      for (let height = curr + 1; height <= until; height++) {
        let startBlockTime = new Date(); // add timeout here? and outside this loop (for catched up and keep fetching)?

        this.unblock();
        let url = RPC + '/block?height=' + height;
        let analyticsData = {};
        console.log(url);

        try {
          const bulkValidators = Validators.rawCollection().initializeUnorderedBulkOp();
          const bulkValidatorRecords = ValidatorRecords.rawCollection().initializeUnorderedBulkOp();
          const bulkVPHistory = VotingPowerHistory.rawCollection().initializeUnorderedBulkOp();
          const bulkTransations = Transactions.rawCollection().initializeUnorderedBulkOp();
          let startGetHeightTime = new Date();
          let response = HTTP.get(url);

          if (response.statusCode == 200) {
            let block = JSON.parse(response.content);
            block = block.result; // store height, hash, numtransaction and time in db

            let blockData = {};
            blockData.height = height;
            blockData.hash = block.block_id.hash;
            blockData.transNum = block.block.data.length;
            blockData.time = new Date(block.block.header.time);
            blockData.lastBlockHash = block.block.header.last_block_id.hash;
            blockData.proposerAddress = block.block.header.proposer_address;
            blockData.validators = [];
            let precommits = block.block.last_commit.precommits;

            if (precommits != null) {
              // console.log(precommits.length);
              for (let i = 0; i < precommits.length; i++) {
                if (precommits[i] != null) {
                  blockData.validators.push(precommits[i].validator_address);
                }
              }

              analyticsData.precommits = precommits.length; // record for analytics
              // PrecommitRecords.insert({height:height, precommits:precommits.length});
            } // save txs in database


            if (block.block.data.txs && block.block.data.txs.length > 0) {
              for (t in block.block.data.txs) {
                Meteor.call('Transactions.index', sha256(Buffer.from(block.block.data.txs[t], 'base64')), blockData.time, (err, result) => {
                  if (err) {
                    console.log(err);
                  }
                });
              }
            } // save double sign evidences


            if (block.block.evidence.evidence) {
              Evidences.insert({
                height: height,
                evidence: block.block.evidence.evidence
              });
            }

            blockData.precommitsCount = blockData.validators.length;
            analyticsData.height = height;
            let endGetHeightTime = new Date();
            console.log("Get height time: " + (endGetHeightTime - startGetHeightTime) / 1000 + "seconds.");
            let startGetValidatorsTime = new Date(); // update chain status

            url = RPC + '/validators?height=' + height;
            response = HTTP.get(url);
            console.log(url);
            let validators = JSON.parse(response.content);
            validators.result.block_height = parseInt(validators.result.block_height);
            ValidatorSets.insert(validators.result);
            blockData.validatorsCount = validators.result.validators.length;
            let startBlockInsertTime = new Date();
            Blockscon.insert(blockData);
            let endBlockInsertTime = new Date();
            console.log("Block insert time: " + (endBlockInsertTime - startBlockInsertTime) / 1000 + "seconds."); // store valdiators exist records

            let existingValidators = Validators.find({
              address: {
                $exists: true
              }
            }).fetch();

            if (height > 1) {
              // record precommits and calculate uptime
              // only record from block 2
              for (i in validators.result.validators) {
                let address = validators.result.validators[i].address;
                let record = {
                  height: height,
                  address: address,
                  exists: false,
                  voting_power: parseInt(validators.result.validators[i].voting_power) //getValidatorVotingPower(existingValidators, address)

                };

                for (j in precommits) {
                  if (precommits[j] != null) {
                    if (address == precommits[j].validator_address) {
                      record.exists = true;
                      precommits.splice(j, 1);
                      break;
                    }
                  }
                } // calculate the uptime based on the records stored in previous blocks
                // only do this every 15 blocks ~


                if (height % 15 == 0) {
                  // let startAggTime = new Date();
                  let numBlocks = Meteor.call('blocks.findUpTime', address);
                  let uptime = 0; // let endAggTime = new Date();
                  // console.log("Get aggregated uptime for "+existingValidators[i].address+": "+((endAggTime-startAggTime)/1000)+"seconds.");

                  if (numBlocks[0] != null && numBlocks[0].uptime != null) {
                    uptime = numBlocks[0].uptime;
                  }

                  let base = Meteor.settings.public.uptimeWindow;

                  if (height < base) {
                    base = height;
                  }

                  if (record.exists) {
                    if (uptime < base) {
                      uptime++;
                    }

                    uptime = uptime / base * 100;
                    bulkValidators.find({
                      address: address
                    }).upsert().updateOne({
                      $set: {
                        uptime: uptime,
                        lastSeen: blockData.time
                      }
                    });
                  } else {
                    uptime = uptime / base * 100;
                    bulkValidators.find({
                      address: address
                    }).upsert().updateOne({
                      $set: {
                        uptime: uptime
                      }
                    });
                  }
                }

                bulkValidatorRecords.insert(record); // ValidatorRecords.update({height:height,address:record.address},record);
              }
            }

            let chainStatus = Chain.findOne({
              chainId: block.block.header.chain_id
            });
            let lastSyncedTime = chainStatus ? chainStatus.lastSyncedTime : 0;
            let timeDiff;
            let blockTime = Meteor.settings.params.defaultBlockTime;

            if (lastSyncedTime) {
              let dateLatest = blockData.time;
              let dateLast = new Date(lastSyncedTime);
              timeDiff = Math.abs(dateLatest.getTime() - dateLast.getTime());
              blockTime = (chainStatus.blockTime * (blockData.height - 1) + timeDiff) / blockData.height;
            }

            let endGetValidatorsTime = new Date();
            console.log("Get height validators time: " + (endGetValidatorsTime - startGetValidatorsTime) / 1000 + "seconds.");
            Chain.update({
              chainId: block.block.header.chain_id
            }, {
              $set: {
                lastSyncedTime: blockData.time,
                blockTime: blockTime
              }
            });
            analyticsData.averageBlockTime = blockTime;
            analyticsData.timeDiff = timeDiff;
            analyticsData.time = blockData.time; // initialize validator data at first block
            // if (height == 1){
            //     Validators.remove({});
            // }

            analyticsData.voting_power = 0;
            let startFindValidatorsNameTime = new Date();

            if (validators.result) {
              // validators are all the validators in the current height
              console.log("validatorSet size: " + validators.result.validators.length);

              for (v in validators.result.validators) {
                // Validators.insert(validators.result.validators[v]);
                let validator = validators.result.validators[v];
                validator.voting_power = parseInt(validator.voting_power);
                validator.proposer_priority = parseInt(validator.proposer_priority);
                let valExist = Validators.findOne({
                  "pub_key.value": validator.pub_key.value
                });

                if (!valExist) {
                  console.log("validator pub_key ".concat(validator.address, " ").concat(validator.pub_key.value, " not in db")); // let command = Meteor.settings.bin.gaiadebug+" pubkey "+validator.pub_key.value;
                  // console.log(command);
                  // let tempVal = validator;

                  validator.address = getAddress(validator.pub_key);
                  validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
                  validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
                  validator.consensus_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixConsPub);
                  let validatorData = validatorSet[validator.consensus_pubkey];

                  if (validatorData) {
                    if (validatorData.description.identity) validator.profile_url = getValidatorProfileUrl(validatorData.description.identity);
                    validator.operator_address = validatorData.operator_address;
                    validator.delegator_address = Meteor.call('getDelegator', validatorData.operator_address);
                    validator.jailed = validatorData.jailed;
                    validator.status = validatorData.status;
                    validator.min_self_delegation = validatorData.min_self_delegation;
                    validator.tokens = validatorData.tokens;
                    validator.delegator_shares = validatorData.delegator_shares;
                    validator.description = validatorData.description;
                    validator.bond_height = validatorData.bond_height;
                    validator.bond_intra_tx_counter = validatorData.bond_intra_tx_counter;
                    validator.unbonding_height = validatorData.unbonding_height;
                    validator.unbonding_time = validatorData.unbonding_time;
                    validator.commission = validatorData.commission;
                    validator.self_delegation = validator.delegator_shares; // validator.removed = false,
                    // validator.removedAt = 0
                    // validatorSet.splice(val, 1);
                  } else {
                    console.log('no con pub key?');
                  } // bulkValidators.insert(validator);


                  bulkValidators.find({
                    consensus_pubkey: validator.consensus_pubkey
                  }).upsert().updateOne({
                    $set: validator
                  }); // console.log("validator first appears: "+bulkValidators.length);

                  bulkVPHistory.insert({
                    address: validator.address,
                    prev_voting_power: 0,
                    voting_power: validator.voting_power,
                    type: 'add',
                    height: blockData.height,
                    block_time: blockData.time
                  }); // Meteor.call('runCode', command, function(error, result){
                  // validator.address = result.match(/\s[0-9A-F]{40}$/igm);
                  // validator.address = validator.address[0].trim();
                  // validator.hex = result.match(/\s[0-9A-F]{64}$/igm);
                  // validator.hex = validator.hex[0].trim();
                  // validator.cosmosaccpub = result.match(/cosmospub.*$/igm);
                  // validator.cosmosaccpub = validator.cosmosaccpub[0].trim();
                  // validator.operator_pubkey = result.match(/cosmosvaloperpub.*$/igm);
                  // validator.operator_pubkey = validator.operator_pubkey[0].trim();
                  // validator.consensus_pubkey = result.match(/cosmosvalconspub.*$/igm);
                  // validator.consensus_pubkey = validator.consensus_pubkey[0].trim();
                  // });
                } else {
                  let validatorData = validatorSet[valExist.consensus_pubkey];

                  if (validatorData) {
                    if (validatorData.description && (!valExist.description || validatorData.description.identity !== valExist.description.identity)) validator.profile_url = getValidatorProfileUrl(validatorData.description.identity);
                    validator.jailed = validatorData.jailed;
                    validator.status = validatorData.status;
                    validator.tokens = validatorData.tokens;
                    validator.delegator_shares = validatorData.delegator_shares;
                    validator.description = validatorData.description;
                    validator.bond_height = validatorData.bond_height;
                    validator.bond_intra_tx_counter = validatorData.bond_intra_tx_counter;
                    validator.unbonding_height = validatorData.unbonding_height;
                    validator.unbonding_time = validatorData.unbonding_time;
                    validator.commission = validatorData.commission; // calculate self delegation percentage every 30 blocks

                    if (height % 30 == 1) {
                      try {
                        let response = HTTP.get(LCD + '/staking/delegators/' + valExist.delegator_address + '/delegations/' + valExist.operator_address);

                        if (response.statusCode == 200) {
                          let selfDelegation = JSON.parse(response.content).result;

                          if (selfDelegation.shares) {
                            validator.self_delegation = parseFloat(selfDelegation.shares) / parseFloat(validator.delegator_shares);
                          }
                        }
                      } catch (e) {// console.log(e);
                      }
                    }

                    bulkValidators.find({
                      consensus_pubkey: valExist.consensus_pubkey
                    }).updateOne({
                      $set: validator
                    }); // console.log("validator exisits: "+bulkValidators.length);
                    // validatorSet.splice(val, 1);
                  } else {
                    console.log('no con pub key?');
                  }

                  let prevVotingPower = VotingPowerHistory.findOne({
                    address: validator.address
                  }, {
                    height: -1,
                    limit: 1
                  });

                  if (prevVotingPower) {
                    if (prevVotingPower.voting_power != validator.voting_power) {
                      let changeType = prevVotingPower.voting_power > validator.voting_power ? 'down' : 'up';
                      let changeData = {
                        address: validator.address,
                        prev_voting_power: prevVotingPower.voting_power,
                        voting_power: validator.voting_power,
                        type: changeType,
                        height: blockData.height,
                        block_time: blockData.time
                      }; // console.log('voting power changed.');
                      // console.log(changeData);

                      bulkVPHistory.insert(changeData);
                    }
                  }
                } // console.log(validator);


                analyticsData.voting_power += validator.voting_power;
              } // if there is validator removed


              let prevValidators = ValidatorSets.findOne({
                block_height: height - 1
              });

              if (prevValidators) {
                let removedValidators = getRemovedValidators(prevValidators.validators, validators.result.validators);

                for (r in removedValidators) {
                  bulkVPHistory.insert({
                    address: removedValidators[r].address,
                    prev_voting_power: removedValidators[r].voting_power,
                    voting_power: 0,
                    type: 'remove',
                    height: blockData.height,
                    block_time: blockData.time
                  });
                }
              }
            } // check if there's any validator not in db 14400 blocks(~1 day)


            if (height % 14400 == 0) {
              try {
                console.log('Checking all validators against db...');
                let dbValidators = {};
                Validators.find({}, {
                  fields: {
                    consensus_pubkey: 1,
                    status: 1
                  }
                }).forEach(v => dbValidators[v.consensus_pubkey] = v.status);
                Object.keys(validatorSet).forEach(conPubKey => {
                  let validatorData = validatorSet[conPubKey]; // Active validators should have been updated in previous steps

                  if (validatorData.status === 2) return;

                  if (dbValidators[conPubKey] == undefined) {
                    console.log("validator with consensus_pubkey ".concat(conPubKey, " not in db"));
                    validatorData.pub_key = {
                      "type": "tendermint/PubKeyEd25519",
                      "value": Meteor.call('bech32ToPubkey', conPubKey)
                    };
                    validatorData.address = getAddress(validatorData.pub_key);
                    validatorData.delegator_address = Meteor.call('getDelegator', validatorData.operator_address);
                    validatorData.accpub = Meteor.call('pubkeyToBech32', validatorData.pub_key, Meteor.settings.public.bech32PrefixAccPub);
                    validatorData.operator_pubkey = Meteor.call('pubkeyToBech32', validatorData.pub_key, Meteor.settings.public.bech32PrefixValPub);
                    console.log(JSON.stringify(validatorData));
                    bulkValidators.find({
                      consensus_pubkey: conPubKey
                    }).upsert().updateOne({
                      $set: validatorData
                    });
                  } else if (dbValidators[conPubKey] == 2) {
                    bulkValidators.find({
                      consensus_pubkey: conPubKey
                    }).upsert().updateOne({
                      $set: validatorData
                    });
                  }
                });
              } catch (e) {
                console.log(e);
              }
            } // fetching keybase every 14400 blocks(~1 day)


            if (height % 14400 == 1) {
              console.log('Fetching keybase...');
              Validators.find({}).forEach(validator => {
                try {
                  let profileUrl = getValidatorProfileUrl(validator.description.identity);

                  if (profileUrl) {
                    bulkValidators.find({
                      address: validator.address
                    }).upsert().updateOne({
                      $set: {
                        'profile_url': profileUrl
                      }
                    });
                  }
                } catch (e) {
                  console.log(e);
                }
              });
            }

            let endFindValidatorsNameTime = new Date();
            console.log("Get validators name time: " + (endFindValidatorsNameTime - startFindValidatorsNameTime) / 1000 + "seconds."); // record for analytics

            let startAnayticsInsertTime = new Date();
            Analytics.insert(analyticsData);
            let endAnalyticsInsertTime = new Date();
            console.log("Analytics insert time: " + (endAnalyticsInsertTime - startAnayticsInsertTime) / 1000 + "seconds.");
            let startVUpTime = new Date();

            if (bulkValidators.length > 0) {
              // console.log(bulkValidators.length);
              bulkValidators.execute((err, result) => {
                if (err) {
                  console.log(err);
                }

                if (result) {// console.log(result);
                }
              });
            }

            let endVUpTime = new Date();
            console.log("Validator update time: " + (endVUpTime - startVUpTime) / 1000 + "seconds.");
            let startVRTime = new Date();

            if (bulkValidatorRecords.length > 0) {
              bulkValidatorRecords.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            }

            let endVRTime = new Date();
            console.log("Validator records update time: " + (endVRTime - startVRTime) / 1000 + "seconds.");

            if (bulkVPHistory.length > 0) {
              bulkVPHistory.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            }

            if (bulkTransations.length > 0) {
              bulkTransations.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            } // calculate voting power distribution every 60 blocks ~ 5mins


            if (height % 60 == 1) {
              console.log("===== calculate voting power distribution =====");
              let activeValidators = Validators.find({
                status: 2,
                jailed: false
              }, {
                sort: {
                  voting_power: -1
                }
              }).fetch();
              let numTopTwenty = Math.ceil(activeValidators.length * 0.2);
              let numBottomEighty = activeValidators.length - numTopTwenty;
              let topTwentyPower = 0;
              let bottomEightyPower = 0;
              let numTopThirtyFour = 0;
              let numBottomSixtySix = 0;
              let topThirtyFourPercent = 0;
              let bottomSixtySixPercent = 0;

              for (v in activeValidators) {
                if (v < numTopTwenty) {
                  topTwentyPower += activeValidators[v].voting_power;
                } else {
                  bottomEightyPower += activeValidators[v].voting_power;
                }

                if (topThirtyFourPercent < 0.34) {
                  topThirtyFourPercent += activeValidators[v].voting_power / analyticsData.voting_power;
                  numTopThirtyFour++;
                }
              }

              bottomSixtySixPercent = 1 - topThirtyFourPercent;
              numBottomSixtySix = activeValidators.length - numTopThirtyFour;
              let vpDist = {
                height: height,
                numTopTwenty: numTopTwenty,
                topTwentyPower: topTwentyPower,
                numBottomEighty: numBottomEighty,
                bottomEightyPower: bottomEightyPower,
                numTopThirtyFour: numTopThirtyFour,
                topThirtyFourPercent: topThirtyFourPercent,
                numBottomSixtySix: numBottomSixtySix,
                bottomSixtySixPercent: bottomSixtySixPercent,
                numValidators: activeValidators.length,
                totalVotingPower: analyticsData.voting_power,
                blockTime: blockData.time,
                createAt: new Date()
              };
              console.log(vpDist);
              VPDistributions.insert(vpDist);
            }
          }
        } catch (e) {
          console.log(e);
          SYNCING = false;
          return "Stopped";
        }

        let endBlockTime = new Date();
        console.log("This block used: " + (endBlockTime - startBlockTime) / 1000 + "seconds.");
      }

      SYNCING = false;
      Chain.update({
        chainId: Meteor.settings.public.chainId
      }, {
        $set: {
          lastBlocksSyncedTime: new Date(),
          totalValidators: totalValidators
        }
      });
    }

    return until;
  },
  'addLimit': function (limit) {
    // console.log(limit+10)
    return limit + 10;
  },
  'hasMore': function (limit) {
    if (limit > Meteor.call('getCurrentHeight')) {
      return false;
    } else {
      return true;
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/server/publications.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Blockscon;
module.link("../blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 3);
publishComposite('blocks.height', function (limit) {
  return {
    find() {
      return Blockscon.find({}, {
        limit: limit,
        sort: {
          height: -1
        }
      });
    },

    children: [{
      find(block) {
        return Validators.find({
          address: block.proposerAddress
        }, {
          limit: 1
        });
      }

    }]
  };
});
publishComposite('blocks.findOne', function (height) {
  return {
    find() {
      return Blockscon.find({
        height: height
      });
    },

    children: [{
      find(block) {
        return Transactions.find({
          height: block.height
        });
      }

    }, {
      find(block) {
        return Validators.find({
          address: block.proposerAddress
        }, {
          limit: 1
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"blocks.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/blocks.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Blockscon: () => Blockscon
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const Blockscon = new Mongo.Collection('blocks');
Blockscon.helpers({
  proposer() {
    return Validators.findOne({
      address: this.proposerAddress
    });
  }

}); // Blockscon.helpers({
//     sorted(limit) {
//         return Blockscon.find({}, {sort: {height:-1}, limit: limit});
//     }
// });
// Meteor.setInterval(function() {
//     Meteor.call('blocksUpdate', (error, result) => {
//         console.log(result);
//     })
// }, 30000000);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chain":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/server/methods.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let getAddress;
module.link("tendermint/lib/pubkey.js", {
  getAddress(v) {
    getAddress = v;
  }

}, 2);
let Chain, ChainStates;
module.link("../chain.js", {
  Chain(v) {
    Chain = v;
  },

  ChainStates(v) {
    ChainStates = v;
  }

}, 3);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 4);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 5);

findVotingPower = (validator, genValidators) => {
  for (let v in genValidators) {
    if (validator.pub_key.value == genValidators[v].pub_key.value) {
      return parseInt(genValidators[v].power);
    }
  }
};

Meteor.methods({
  'chain.getConsensusState': function () {
    this.unblock();
    let url = RPC + '/dump_consensus_state';

    try {
      let response = HTTP.get(url);
      let consensus = JSON.parse(response.content);
      consensus = consensus.result;
      let height = consensus.round_state.height;
      let round = consensus.round_state.round;
      let step = consensus.round_state.step;
      let votedPower = Math.round(parseFloat(consensus.round_state.votes[round].prevotes_bit_array.split(" ")[3]) * 100);
      Chain.update({
        chainId: Meteor.settings.public.chainId
      }, {
        $set: {
          votingHeight: height,
          votingRound: round,
          votingStep: step,
          votedPower: votedPower,
          proposerAddress: consensus.round_state.validators.proposer.address,
          prevotes: consensus.round_state.votes[round].prevotes,
          precommits: consensus.round_state.votes[round].precommits
        }
      });
    } catch (e) {
      console.log(e);
    }
  },
  'chain.updateStatus': function () {
    this.unblock();
    let url = RPC + '/status';

    try {
      let response = HTTP.get(url);
      let status = JSON.parse(response.content);
      status = status.result;
      let chain = {};
      chain.chainId = status.node_info.network;
      chain.latestBlockHeight = status.sync_info.latest_block_height;
      chain.latestBlockTime = status.sync_info.latest_block_time;
      let latestState = ChainStates.findOne({}, {
        sort: {
          height: -1
        }
      });

      if (latestState && latestState.height >= chain.latestBlockHeight) {
        return "no updates (getting block ".concat(chain.latestBlockHeight, " at block ").concat(latestState.height, ")");
      }

      url = RPC + '/validators';
      response = HTTP.get(url);
      let validators = JSON.parse(response.content);
      validators = validators.result.validators;
      chain.validators = validators.length;
      let activeVP = 0;

      for (v in validators) {
        activeVP += parseInt(validators[v].voting_power);
      }

      chain.activeVotingPower = activeVP;
      Chain.update({
        chainId: chain.chainId
      }, {
        $set: chain
      }, {
        upsert: true
      }); // Get chain states

      if (parseInt(chain.latestBlockHeight) > 0) {
        let chainStates = {};
        chainStates.height = parseInt(status.sync_info.latest_block_height);
        chainStates.time = new Date(status.sync_info.latest_block_time);
        url = LCD + '/staking/pool';

        try {
          response = HTTP.get(url);
          let bonding = JSON.parse(response.content).result; // chain.bondedTokens = bonding.bonded_tokens;
          // chain.notBondedTokens = bonding.not_bonded_tokens;

          chainStates.bondedTokens = parseInt(bonding.bonded_tokens);
          chainStates.notBondedTokens = parseInt(bonding.not_bonded_tokens);
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/supply/total/' + Meteor.settings.public.mintingDenom;

        try {
          response = HTTP.get(url);
          let supply = JSON.parse(response.content).result;
          chainStates.totalSupply = parseInt(supply);
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/distribution/community_pool';

        try {
          response = HTTP.get(url);
          let pool = JSON.parse(response.content).result;

          if (pool && pool.length > 0) {
            chainStates.communityPool = [];
            pool.forEach((amount, i) => {
              chainStates.communityPool.push({
                denom: amount.denom,
                amount: parseFloat(amount.amount)
              });
            });
          }
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/minting/inflation';

        try {
          response = HTTP.get(url);
          let inflation = JSON.parse(response.content).result;

          if (inflation) {
            chainStates.inflation = parseFloat(inflation);
          }
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/minting/annual-provisions';

        try {
          response = HTTP.get(url);
          let provisions = JSON.parse(response.content);

          if (provisions) {
            chainStates.annualProvisions = parseFloat(provisions.result);
          }
        } catch (e) {
          console.log(e);
        }

        ChainStates.insert(chainStates);
      } // chain.totalVotingPower = totalVP;
      // validators = Validators.find({}).fetch();
      // console.log(validators);


      return chain.latestBlockHeight;
    } catch (e) {
      console.log(e);
      return "Error getting chain status.";
    }
  },
  'chain.getLatestStatus': function () {
    Chain.find().sort({
      created: -1
    }).limit(1);
  },
  'chain.genesis': function () {
    let chain = Chain.findOne({
      chainId: Meteor.settings.public.chainId
    });

    if (chain && chain.readGenesis) {
      console.log('Genesis file has been processed');
    } else if (Meteor.settings.debug.readGenesis) {
      console.log('=== Start processing genesis file ===');
      let response = HTTP.get(Meteor.settings.genesisFile);
      let genesis = JSON.parse(response.content);
      let distr = genesis.app_state.distr || genesis.app_state.distribution;
      let chainParams = {
        chainId: genesis.chain_id,
        genesisTime: genesis.genesis_time,
        consensusParams: genesis.consensus_params,
        auth: genesis.app_state.auth,
        bank: genesis.app_state.bank,
        staking: {
          pool: genesis.app_state.staking.pool,
          params: genesis.app_state.staking.params
        },
        mint: genesis.app_state.mint,
        distr: {
          communityTax: distr.community_tax,
          baseProposerReward: distr.base_proposer_reward,
          bonusProposerReward: distr.bonus_proposer_reward,
          withdrawAddrEnabled: distr.withdraw_addr_enabled
        },
        gov: null,
        slashing: {
          params: genesis.app_state.slashing.params
        },
        supply: genesis.app_state.supply,
        crisis: genesis.app_state.crisis
      };
      let totalVotingPower = 0; // read gentx

      if (genesis.app_state.genutil && genesis.app_state.genutil.gentxs && genesis.app_state.genutil.gentxs.length > 0) {
        for (i in genesis.app_state.genutil.gentxs) {
          let msg = genesis.app_state.genutil.gentxs[i].value.msg; // console.log(msg.type);

          for (m in msg) {
            if (msg[m].type == "cosmos-sdk/MsgCreateValidator") {
              console.log(msg[m].value); // let command = Meteor.settings.bin.gaiadebug+" pubkey "+msg[m].value.pubkey;

              let validator = {
                consensus_pubkey: msg[m].value.pubkey,
                description: msg[m].value.description,
                commission: msg[m].value.commission,
                min_self_delegation: msg[m].value.min_self_delegation,
                operator_address: msg[m].value.validator_address,
                delegator_address: msg[m].value.delegator_address,
                voting_power: Math.floor(parseInt(msg[m].value.value.amount) / Meteor.settings.public.stakingFraction),
                jailed: false,
                status: 2
              };
              totalVotingPower += validator.voting_power;
              let pubkeyValue = Meteor.call('bech32ToPubkey', msg[m].value.pubkey); // Validators.upsert({consensus_pubkey:msg[m].value.pubkey},validator);

              validator.pub_key = {
                "type": "tendermint/PubKeyEd25519",
                "value": pubkeyValue
              };
              validator.address = getAddress(validator.pub_key);
              validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
              validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
              VotingPowerHistory.insert({
                address: validator.address,
                prev_voting_power: 0,
                voting_power: validator.voting_power,
                type: 'add',
                height: 0,
                block_time: genesis.genesis_time
              });
              Validators.insert(validator);
            }
          }
        }
      } // read validators from previous chain


      console.log('read validators from previous chain');

      if (genesis.app_state.staking.validators && genesis.app_state.staking.validators.length > 0) {
        console.log(genesis.app_state.staking.validators.length);
        let genValidatorsSet = genesis.app_state.staking.validators;
        let genValidators = genesis.validators;

        for (let v in genValidatorsSet) {
          // console.log(genValidators[v]);
          let validator = genValidatorsSet[v];
          validator.delegator_address = Meteor.call('getDelegator', genValidatorsSet[v].operator_address);
          let pubkeyValue = Meteor.call('bech32ToPubkey', validator.consensus_pubkey);
          validator.pub_key = {
            "type": "tendermint/PubKeyEd25519",
            "value": pubkeyValue
          };
          validator.address = getAddress(validator.pub_key);
          validator.pub_key = validator.pub_key;
          validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
          validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
          validator.voting_power = findVotingPower(validator, genValidators);
          totalVotingPower += validator.voting_power;
          Validators.upsert({
            consensus_pubkey: validator.consensus_pubkey
          }, validator);
          VotingPowerHistory.insert({
            address: validator.address,
            prev_voting_power: 0,
            voting_power: validator.voting_power,
            type: 'add',
            height: 0,
            block_time: genesis.genesis_time
          });
        }
      }

      chainParams.readGenesis = true;
      chainParams.activeVotingPower = totalVotingPower;
      let result = Chain.upsert({
        chainId: chainParams.chainId
      }, {
        $set: chainParams
      });
      console.log('=== Finished processing genesis file ===');
    }

    return true;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/server/publications.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Chain, ChainStates;
module.link("../chain.js", {
  Chain(v) {
    Chain = v;
  },

  ChainStates(v) {
    ChainStates = v;
  }

}, 1);
let CoinStats;
module.link("../../coin-stats/coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
Meteor.publish('chainStates.latest', function () {
  return [ChainStates.find({}, {
    sort: {
      height: -1
    },
    limit: 1
  }), CoinStats.find({}, {
    sort: {
      last_updated_at: -1
    },
    limit: 1
  })];
});
publishComposite('chain.status', function () {
  return {
    find() {
      return Chain.find({
        chainId: Meteor.settings.public.chainId
      });
    },

    children: [{
      find(chain) {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            operator_address: 1,
            status: -1,
            jailed: 1,
            profile_url: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chain.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/chain.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Chain: () => Chain,
  ChainStates: () => ChainStates
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const Chain = new Mongo.Collection('chain');
const ChainStates = new Mongo.Collection('chain_states');
Chain.helpers({
  proposer() {
    return Validators.findOne({
      address: this.proposerAddress
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"coin-stats":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/coin-stats/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let CoinStats;
module.link("../coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 1);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 2);
Meteor.methods({
  'coinStats.getCoinStats': function () {
    this.unblock();
    let coinId = Meteor.settings.public.coingeckoId;

    if (coinId) {
      try {
        let now = new Date();
        now.setMinutes(0);
        let url = "https://api.coingecko.com/api/v3/simple/price?ids=" + coinId + "&vs_currencies=usd&include_market_cap=true&include_24hr_vol=true&include_24hr_change=true&include_last_updated_at=true";
        let response = HTTP.get(url);

        if (response.statusCode == 200) {
          // console.log(JSON.parse(response.content));
          let data = JSON.parse(response.content);
          data = data[coinId]; // console.log(coinStats);

          return CoinStats.upsert({
            last_updated_at: data.last_updated_at
          }, {
            $set: data
          });
        }
      } catch (e) {
        console.log(e);
      }
    } else {
      return "No coingecko Id provided.";
    }
  },
  'coinStats.getStats': function () {
    this.unblock();
    let coinId = Meteor.settings.public.coingeckoId;

    if (coinId) {
      return CoinStats.findOne({}, {
        sort: {
          last_updated_at: -1
        }
      });
    } else {
      return "No coingecko Id provided.";
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"coin-stats.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/coin-stats/coin-stats.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  CoinStats: () => CoinStats
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const CoinStats = new Mongo.Collection('coin_stats');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"delegations":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/server/methods.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Delegations;
module.link("../delegations.js", {
  Delegations(v) {
    Delegations = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
Meteor.methods({
  'delegations.getDelegations': function () {
    this.unblock();
    let validators = Validators.find({}).fetch();
    let delegations = [];
    console.log("=== Getting delegations ===");

    for (v in validators) {
      if (validators[v].operator_address) {
        let url = LCD + '/staking/validators/' + validators[v].operator_address + "/delegations";

        try {
          let response = HTTP.get(url);

          if (response.statusCode == 200) {
            let delegation = JSON.parse(response.content).result; // console.log(delegation);

            delegations = delegations.concat(delegation);
          } else {
            console.log(response.statusCode);
          }
        } catch (e) {
          console.log(e);
        }
      }
    }

    for (i in delegations) {
      if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
    } // console.log(delegations);


    let data = {
      delegations: delegations,
      createdAt: new Date()
    };
    return Delegations.insert(data);
  } // 'blocks.averageBlockTime'(address){
  //     let blocks = Blockscon.find({proposerAddress:address}).fetch();
  //     let heights = blocks.map((block, i) => {
  //         return block.height;
  //     });
  //     let blocksStats = Analytics.find({height:{$in:heights}}).fetch();
  //     // console.log(blocksStats);
  //     let totalBlockDiff = 0;
  //     for (b in blocksStats){
  //         totalBlockDiff += blocksStats[b].timeDiff;
  //     }
  //     return totalBlockDiff/heights.length;
  // }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/server/publications.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"delegations.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/delegations.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Delegations: () => Delegations
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Delegations = new Mongo.Collection('delegations');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"enterprise":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/enterprise/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Enterprise;
module.link("../enterprise.js", {
  Enterprise(v) {
    Enterprise = v;
  }

}, 2);
Meteor.methods({
  'enterprise.getPurchaseOrders': function () {
    this.unblock();

    try {
      let url = LCD + '/enterprise/pos';
      let response = HTTP.get(url);
      let purchaseOrders = JSON.parse(response.content).result;
      let finishedPurchaseOrders = new Set(Enterprise.find({
        "status": {
          $in: ["reject", "complete"]
        }
      }).fetch().map(p => p.poId));
      let poIds = [];

      if (purchaseOrders.length > 0) {
        const bulkPos = Enterprise.rawCollection().initializeUnorderedBulkOp();

        for (let i in purchaseOrders) {
          let po = purchaseOrders[i];
          po.poId = parseInt(po.id);

          if (po.poId > 0 && !finishedPurchaseOrders.has(po.poId)) {
            try {
              bulkPos.find({
                poId: po.poId
              }).upsert().updateOne({
                $set: po
              });
              poIds.push(po.poId);
            } catch (e) {
              bulkPos.find({
                poId: po.poId
              }).upsert().updateOne({
                $set: po
              });
              poIds.push(po.poId);
              console.log(e.response.content);
            }
          }
        }

        if (poIds.length > 0) {
          bulkPos.execute();
        }
      }

      return true;
    } catch (e) {
      console.log(e);
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/enterprise/server/publications.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Enterprise;
module.link("../enterprise.js", {
  Enterprise(v) {
    Enterprise = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
Meteor.publish('enterprise.list_pos', function () {
  return Enterprise.find({}, {
    sort: {
      poId: -1
    }
  });
});
Meteor.publish('enterprise.one_po', function (id) {
  check(id, Number);
  return Enterprise.find({
    poId: id
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"enterprise.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/enterprise/enterprise.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Enterprise: () => Enterprise
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Enterprise = new Mongo.Collection('enterprise');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"ledger":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/ledger/server/methods.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 0);
Meteor.methods({
  'transaction.submit': function (txInfo) {
    const url = "".concat(LCD, "/txs");
    data = {
      "tx": txInfo.value,
      "mode": "sync"
    };
    const timestamp = new Date().getTime();
    console.log("submitting transaction".concat(timestamp, " ").concat(url, " with data ").concat(JSON.stringify(data)));
    let response = HTTP.post(url, {
      data
    });
    console.log("response for transaction".concat(timestamp, " ").concat(url, ": ").concat(JSON.stringify(response)));

    if (response.statusCode == 200) {
      let data = response.data;
      if (data.code) throw new Meteor.Error(data.code, JSON.parse(data.raw_log).message);
      return response.data.txhash;
    }
  },
  'transaction.execute': function (body, path) {
    const url = "".concat(LCD, "/").concat(path);
    data = {
      "base_req": _objectSpread({}, body, {
        "chain_id": Meteor.settings.public.chainId,
        "simulate": false
      })
    };
    let response = HTTP.post(url, {
      data
    });

    if (response.statusCode == 200) {
      return JSON.parse(response.content);
    }
  },
  'transaction.simulate': function (txMsg, from, path) {
    let adjustment = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '1.2';
    const url = "".concat(LCD, "/").concat(path);
    data = _objectSpread({}, txMsg, {
      "base_req": {
        "from": from,
        "chain_id": Meteor.settings.public.chainId,
        "gas_adjustment": adjustment,
        "simulate": true
      }
    });
    let response = HTTP.post(url, {
      data
    });

    if (response.statusCode == 200) {
      return JSON.parse(response.content).gas_estimate;
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"records":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/server/methods.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let ValidatorRecords, Analytics, AverageData, AverageValidatorData;
module.link("../records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  AverageData(v) {
    AverageData = v;
  },

  AverageValidatorData(v) {
    AverageValidatorData = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
let ValidatorSets;
module.link("/imports/api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 4);
let Status;
module.link("../../status/status.js", {
  Status(v) {
    Status = v;
  }

}, 5);
let MissedBlocksStats;
module.link("../records.js", {
  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  }

}, 6);
let MissedBlocks;
module.link("../records.js", {
  MissedBlocks(v) {
    MissedBlocks = v;
  }

}, 7);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 8);
let Chain;
module.link("../../chain/chain.js", {
  Chain(v) {
    Chain = v;
  }

}, 9);

let _;

module.link("lodash", {
  default(v) {
    _ = v;
  }

}, 10);
const BULKUPDATEMAXSIZE = 1000;

const getBlockStats = (startHeight, latestHeight) => {
  let blockStats = {};
  const cond = {
    $and: [{
      height: {
        $gt: startHeight
      }
    }, {
      height: {
        $lte: latestHeight
      }
    }]
  };
  const options = {
    sort: {
      height: 1
    }
  };
  Blockscon.find(cond, options).forEach(block => {
    blockStats[block.height] = {
      height: block.height,
      proposerAddress: block.proposerAddress,
      precommitsCount: block.precommitsCount,
      validatorsCount: block.validatorsCount,
      validators: block.validators,
      time: block.time
    };
  });
  Analytics.find(cond, options).forEach(block => {
    if (!blockStats[block.height]) {
      blockStats[block.height] = {
        height: block.height
      };
      console.log("block ".concat(block.height, " does not have an entry"));
    }

    _.assign(blockStats[block.height], {
      precommits: block.precommits,
      averageBlockTime: block.averageBlockTime,
      timeDiff: block.timeDiff,
      voting_power: block.voting_power
    });
  });
  return blockStats;
};

const getPreviousRecord = (voterAddress, proposerAddress) => {
  let previousRecord = MissedBlocks.findOne({
    voter: voterAddress,
    proposer: proposerAddress,
    blockHeight: -1
  });
  let lastUpdatedHeight = Meteor.settings.params.startHeight;
  let prevStats = {};

  if (previousRecord) {
    prevStats = _.pick(previousRecord, ['missCount', 'totalCount']);
  } else {
    prevStats = {
      missCount: 0,
      totalCount: 0
    };
  }

  return prevStats;
};

Meteor.methods({
  'ValidatorRecords.calculateMissedBlocks': function () {
    if (!COUNTMISSEDBLOCKS) {
      try {
        let startTime = Date.now();
        COUNTMISSEDBLOCKS = true;
        console.log('calulate missed blocks count');
        this.unblock();
        let validators = Validators.find({}).fetch();
        let latestHeight = Meteor.call('blocks.getCurrentHeight');
        let explorerStatus = Status.findOne({
          chainId: Meteor.settings.public.chainId
        });
        let startHeight = explorerStatus && explorerStatus.lastProcessedMissedBlockHeight ? explorerStatus.lastProcessedMissedBlockHeight : Meteor.settings.params.startHeight;
        latestHeight = Math.min(startHeight + BULKUPDATEMAXSIZE, latestHeight);
        const bulkMissedStats = MissedBlocks.rawCollection().initializeOrderedBulkOp();
        let validatorsMap = {};
        validators.forEach(validator => validatorsMap[validator.address] = validator); // a map of block height to block stats

        let blockStats = getBlockStats(startHeight, latestHeight); // proposerVoterStats is a proposer-voter map counting numbers of proposed blocks of which voter is an active validator

        let proposerVoterStats = {};

        _.forEach(blockStats, (block, blockHeight) => {
          let proposerAddress = block.proposerAddress;
          let votedValidators = new Set(block.validators);
          let validatorSets = ValidatorSets.findOne({
            block_height: block.height
          });
          let votedVotingPower = 0;
          validatorSets.validators.forEach(activeValidator => {
            if (votedValidators.has(activeValidator.address)) votedVotingPower += parseFloat(activeValidator.voting_power);
          });
          validatorSets.validators.forEach(activeValidator => {
            let currentValidator = activeValidator.address;

            if (!_.has(proposerVoterStats, [proposerAddress, currentValidator])) {
              let prevStats = getPreviousRecord(currentValidator, proposerAddress);

              _.set(proposerVoterStats, [proposerAddress, currentValidator], prevStats);
            }

            _.update(proposerVoterStats, [proposerAddress, currentValidator, 'totalCount'], n => n + 1);

            if (!votedValidators.has(currentValidator)) {
              _.update(proposerVoterStats, [proposerAddress, currentValidator, 'missCount'], n => n + 1);

              bulkMissedStats.insert({
                voter: currentValidator,
                blockHeight: block.height,
                proposer: proposerAddress,
                precommitsCount: block.precommitsCount,
                validatorsCount: block.validatorsCount,
                time: block.time,
                precommits: block.precommits,
                averageBlockTime: block.averageBlockTime,
                timeDiff: block.timeDiff,
                votingPower: block.voting_power,
                votedVotingPower,
                updatedAt: latestHeight,
                missCount: _.get(proposerVoterStats, [proposerAddress, currentValidator, 'missCount']),
                totalCount: _.get(proposerVoterStats, [proposerAddress, currentValidator, 'totalCount'])
              });
            }
          });
        });

        _.forEach(proposerVoterStats, (voters, proposerAddress) => {
          _.forEach(voters, (stats, voterAddress) => {
            bulkMissedStats.find({
              voter: voterAddress,
              proposer: proposerAddress,
              blockHeight: -1
            }).upsert().updateOne({
              $set: {
                voter: voterAddress,
                proposer: proposerAddress,
                blockHeight: -1,
                updatedAt: latestHeight,
                missCount: _.get(stats, 'missCount'),
                totalCount: _.get(stats, 'totalCount')
              }
            });
          });
        });

        let message = '';

        if (bulkMissedStats.length > 0) {
          const client = MissedBlocks._driver.mongo.client; // TODO: add transaction back after replica set(#146) is set up
          // let session = client.startSession();
          // session.startTransaction();

          let bulkPromise = bulkMissedStats.execute(null
          /*, {session}*/
          ).then(Meteor.bindEnvironment((result, err) => {
            if (err) {
              COUNTMISSEDBLOCKS = false; // Promise.await(session.abortTransaction());

              throw err;
            }

            if (result) {
              // Promise.await(session.commitTransaction());
              message = "(".concat(result.result.nInserted, " inserted, ") + "".concat(result.result.nUpserted, " upserted, ") + "".concat(result.result.nModified, " modified)");
            }
          }));
          Promise.await(bulkPromise);
        }

        COUNTMISSEDBLOCKS = false;
        Status.upsert({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastProcessedMissedBlockHeight: latestHeight,
            lastProcessedMissedBlockTime: new Date()
          }
        });
        return "done in ".concat(Date.now() - startTime, "ms ").concat(message);
      } catch (e) {
        COUNTMISSEDBLOCKS = false;
        throw e;
      }
    } else {
      return "updating...";
    }
  },
  'ValidatorRecords.calculateMissedBlocksStats': function () {
    // TODO: deprecate this method and MissedBlocksStats collection
    // console.log("ValidatorRecords.calculateMissedBlocks: "+COUNTMISSEDBLOCKS);
    if (!COUNTMISSEDBLOCKSSTATS) {
      COUNTMISSEDBLOCKSSTATS = true;
      console.log('calulate missed blocks stats');
      this.unblock();
      let validators = Validators.find({}).fetch();
      let latestHeight = Meteor.call('blocks.getCurrentHeight');
      let explorerStatus = Status.findOne({
        chainId: Meteor.settings.public.chainId
      });
      let startHeight = explorerStatus && explorerStatus.lastMissedBlockHeight ? explorerStatus.lastMissedBlockHeight : Meteor.settings.params.startHeight; // console.log(latestHeight);
      // console.log(startHeight);

      const bulkMissedStats = MissedBlocksStats.rawCollection().initializeUnorderedBulkOp();

      for (i in validators) {
        // if ((validators[i].address == "B8552EAC0D123A6BF609123047A5181D45EE90B5") || (validators[i].address == "69D99B2C66043ACBEAA8447525C356AFC6408E0C") || (validators[i].address == "35AD7A2CD2FC71711A675830EC1158082273D457")){
        let voterAddress = validators[i].address;
        let missedRecords = ValidatorRecords.find({
          address: voterAddress,
          exists: false,
          $and: [{
            height: {
              $gt: startHeight
            }
          }, {
            height: {
              $lte: latestHeight
            }
          }]
        }).fetch();
        let counts = {}; // console.log("missedRecords to process: "+missedRecords.length);

        for (b in missedRecords) {
          let block = Blockscon.findOne({
            height: missedRecords[b].height
          });
          let existingRecord = MissedBlocksStats.findOne({
            voter: voterAddress,
            proposer: block.proposerAddress
          });

          if (typeof counts[block.proposerAddress] === 'undefined') {
            if (existingRecord) {
              counts[block.proposerAddress] = existingRecord.count + 1;
            } else {
              counts[block.proposerAddress] = 1;
            }
          } else {
            counts[block.proposerAddress]++;
          }
        }

        for (address in counts) {
          let data = {
            voter: voterAddress,
            proposer: address,
            count: counts[address]
          };
          bulkMissedStats.find({
            voter: voterAddress,
            proposer: address
          }).upsert().updateOne({
            $set: data
          });
        } // }

      }

      if (bulkMissedStats.length > 0) {
        bulkMissedStats.execute(Meteor.bindEnvironment((err, result) => {
          if (err) {
            COUNTMISSEDBLOCKSSTATS = false;
            console.log(err);
          }

          if (result) {
            Status.upsert({
              chainId: Meteor.settings.public.chainId
            }, {
              $set: {
                lastMissedBlockHeight: latestHeight,
                lastMissedBlockTime: new Date()
              }
            });
            COUNTMISSEDBLOCKSSTATS = false;
            console.log("done");
          }
        }));
      } else {
        COUNTMISSEDBLOCKSSTATS = false;
      }

      return true;
    } else {
      return "updating...";
    }
  },
  'Analytics.aggregateBlockTimeAndVotingPower': function (time) {
    this.unblock();
    let now = new Date();

    if (time == 'm') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastMinuteVotingPower: averageVotingPower,
            lastMinuteBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    }

    if (time == 'h') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 60 * 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastHourVotingPower: averageVotingPower,
            lastHourBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    }

    if (time == 'd') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastDayVotingPower: averageVotingPower,
            lastDayBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    } // return analytics.length;

  },
  'Analytics.aggregateValidatorDailyBlockTime': function () {
    this.unblock();
    let validators = Validators.find({}).fetch();
    let now = new Date();

    for (i in validators) {
      let averageBlockTime = 0;
      let blocks = Blockscon.find({
        proposerAddress: validators[i].address,
        "time": {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }, {
        fields: {
          height: 1
        }
      }).fetch();

      if (blocks.length > 0) {
        let blockHeights = [];

        for (b in blocks) {
          blockHeights.push(blocks[b].height);
        }

        let analytics = Analytics.find({
          height: {
            $in: blockHeights
          }
        }, {
          fields: {
            height: 1,
            timeDiff: 1
          }
        }).fetch();

        for (a in analytics) {
          averageBlockTime += analytics[a].timeDiff;
        }

        averageBlockTime = averageBlockTime / analytics.length;
      }

      AverageValidatorData.insert({
        proposerAddress: validators[i].address,
        averageBlockTime: averageBlockTime,
        type: 'ValidatorDailyAverageBlockTime',
        createdAt: now
      });
    }

    return true;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/server/publications.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatorRecords, Analytics, MissedBlocks, MissedBlocksStats, VPDistributions;
module.link("../records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  MissedBlocks(v) {
    MissedBlocks = v;
  },

  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  },

  VPDistributions(v) {
    VPDistributions = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
Meteor.publish('validator_records.all', function () {
  return ValidatorRecords.find();
});
Meteor.publish('validator_records.uptime', function (address, num) {
  return ValidatorRecords.find({
    address: address
  }, {
    limit: num,
    sort: {
      height: -1
    }
  });
});
Meteor.publish('analytics.history', function () {
  return Analytics.find({}, {
    sort: {
      height: -1
    },
    limit: 50
  });
});
Meteor.publish('vpDistribution.latest', function () {
  return VPDistributions.find({}, {
    sort: {
      height: -1
    },
    limit: 1
  });
});
publishComposite('missedblocks.validator', function (address, type) {
  let conditions = {};

  if (type == 'voter') {
    conditions = {
      voter: address
    };
  } else {
    conditions = {
      proposer: address
    };
  }

  return {
    find() {
      return MissedBlocksStats.find(conditions);
    },

    children: [{
      find(stats) {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            profile_url: 1
          }
        });
      }

    }]
  };
});
publishComposite('missedrecords.validator', function (address, type) {
  return {
    find() {
      return MissedBlocks.find({
        [type]: address
      }, {
        sort: {
          updatedAt: -1
        }
      });
    },

    children: [{
      find() {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            operator_address: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"records.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/records.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  ValidatorRecords: () => ValidatorRecords,
  Analytics: () => Analytics,
  MissedBlocksStats: () => MissedBlocksStats,
  MissedBlocks: () => MissedBlocks,
  VPDistributions: () => VPDistributions,
  AverageData: () => AverageData,
  AverageValidatorData: () => AverageValidatorData
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const ValidatorRecords = new Mongo.Collection('validator_records');
const Analytics = new Mongo.Collection('analytics');
const MissedBlocksStats = new Mongo.Collection('missed_blocks_stats');
const MissedBlocks = new Mongo.Collection('missed_blocks');
const VPDistributions = new Mongo.Collection('voting_power_distributions');
const AverageData = new Mongo.Collection('average_data');
const AverageValidatorData = new Mongo.Collection('average_validator_data');
MissedBlocksStats.helpers({
  proposerMoniker() {
    let validator = Validators.findOne({
      address: this.proposer
    });
    return validator.description ? validator.description.moniker : this.proposer;
  },

  voterMoniker() {
    let validator = Validators.findOne({
      address: this.voter
    });
    return validator.description ? validator.description.moniker : this.voter;
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"status":{"server":{"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/status/server/publications.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Status;
module.link("../status.js", {
  Status(v) {
    Status = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
Meteor.publish('status.status', function () {
  return Status.find({
    chainId: Meteor.settings.public.chainId
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"status.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/status/status.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Status: () => Status
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Status = new Mongo.Collection('status');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactions":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/server/methods.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 4);
const AddressLength = 40;
Meteor.methods({
  'Transactions.index': function (hash, blockTime) {
    this.unblock();
    hash = hash.toUpperCase();
    let url = LCD + '/txs/' + hash;
    let response = HTTP.get(url);
    let tx = JSON.parse(response.content);
    console.log(hash);
    tx.height = parseInt(tx.height); // if (!tx.code){
    //     let msg = tx.tx.value.msg;
    //     for (let m in msg){
    //         if (msg[m].type == "cosmos-sdk/MsgCreateValidator"){
    //             console.log(msg[m].value);
    //             let command = Meteor.settings.bin.gaiadebug+" pubkey "+msg[m].value.pubkey;
    //             let validator = {
    //                 consensus_pubkey: msg[m].value.pubkey,
    //                 description: msg[m].value.description,
    //                 commission: msg[m].value.commission,
    //                 min_self_delegation: msg[m].value.min_self_delegation,
    //                 operator_address: msg[m].value.validator_address,
    //                 delegator_address: msg[m].value.delegator_address,
    //                 voting_power: Math.floor(parseInt(msg[m].value.value.amount) / 1000000)
    //             }
    //             Meteor.call('runCode', command, function(error, result){
    //                 validator.address = result.match(/\s[0-9A-F]{40}$/igm);
    //                 validator.address = validator.address[0].trim();
    //                 validator.hex = result.match(/\s[0-9A-F]{64}$/igm);
    //                 validator.hex = validator.hex[0].trim();
    //                 validator.pub_key = result.match(/{".*"}/igm);
    //                 validator.pub_key = JSON.parse(validator.pub_key[0].trim());
    //                 let re = new RegExp(Meteor.settings.public.bech32PrefixAccPub+".*$","igm");
    //                 validator.cosmosaccpub = result.match(re);
    //                 validator.cosmosaccpub = validator.cosmosaccpub[0].trim();
    //                 re = new RegExp(Meteor.settings.public.bech32PrefixValPub+".*$","igm");
    //                 validator.operator_pubkey = result.match(re);
    //                 validator.operator_pubkey = validator.operator_pubkey[0].trim();
    //                 Validators.upsert({consensus_pubkey:msg[m].value.pubkey},validator);
    //                 VotingPowerHistory.insert({
    //                     address: validator.address,
    //                     prev_voting_power: 0,
    //                     voting_power: validator.voting_power,
    //                     type: 'add',
    //                     height: tx.height+2,
    //                     block_time: blockTime
    //                 });
    //             })
    //         }
    //     }
    // }

    let txId = Transactions.insert(tx);

    if (txId) {
      return txId;
    } else return false;
  },
  'Transactions.findDelegation': function (address, height) {
    // following cosmos-sdk/x/slashing/spec/06_events.md and cosmos-sdk/x/staking/spec/06_events.md
    return Transactions.find({
      $or: [{
        $and: [{
          "events.type": "delegate"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.attributes.key": "action"
        }, {
          "events.attributes.value": "unjail"
        }, {
          "events.attributes.key": "sender"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "create_validator"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "unbond"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "redelegate"
        }, {
          "events.attributes.key": "destination_validator"
        }, {
          "events.attributes.value": address
        }]
      }],
      "code": {
        $exists: false
      },
      height: {
        $lt: height
      }
    }, {
      sort: {
        height: -1
      },
      limit: 1
    }).fetch();
  },
  'Transactions.findUser': function (address) {
    let fields = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    // address is either delegator address or validator operator address
    let validator;
    if (!fields) fields = {
      address: 1,
      description: 1,
      operator_address: 1,
      delegator_address: 1
    };

    if (address.includes(Meteor.settings.public.bech32PrefixValAddr)) {
      // validator operator address
      validator = Validators.findOne({
        operator_address: address
      }, {
        fields
      });
    } else if (address.includes(Meteor.settings.public.bech32PrefixAccAddr)) {
      // delegator address
      validator = Validators.findOne({
        delegator_address: address
      }, {
        fields
      });
    } else if (address.length === AddressLength) {
      validator = Validators.findOne({
        address: address
      }, {
        fields
      });
    }

    if (validator) {
      return validator;
    }

    return false;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/server/publications.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Transactions;
module.link("../transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 1);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 2);
publishComposite('transactions.list', function () {
  let limit = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 30;
  return {
    find() {
      return Transactions.find({}, {
        sort: {
          height: -1
        },
        limit: limit
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.validator', function (validatorAddress, delegatorAddress) {
  let limit = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 100;
  let query = {};

  if (validatorAddress && delegatorAddress) {
    query = {
      $or: [{
        "events.attributes.value": validatorAddress
      }, {
        "events.attributes.value": delegatorAddress
      }]
    };
  }

  if (!validatorAddress && delegatorAddress) {
    query = {
      "events.attributes.value": delegatorAddress
    };
  }

  return {
    find() {
      return Transactions.find(query, {
        sort: {
          height: -1
        },
        limit: limit
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.findOne', function (hash) {
  return {
    find() {
      return Transactions.find({
        txhash: hash
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.height', function (height) {
  return {
    find() {
      return Transactions.find({
        height: height
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactions.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/transactions.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Transactions: () => Transactions
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Blockscon;
module.link("../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 1);
let TxIcon;
module.link("../../ui/components/Icons.jsx", {
  TxIcon(v) {
    TxIcon = v;
  }

}, 2);
const Transactions = new Mongo.Collection('transactions');
Transactions.helpers({
  block() {
    return Blockscon.findOne({
      height: this.height
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validators":{"server":{"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 1);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 2);
let Delegations;
module.link("../../delegations/delegations.js", {
  Delegations(v) {
    Delegations = v;
  }

}, 3);
Meteor.methods({
  'Validators.findCreateValidatorTime': function (address) {
    // look up the create validator time to consider if the validator has never updated the commission
    let tx = Transactions.findOne({
      $and: [{
        "tx.value.msg.value.delegator_address": address
      }, {
        "tx.value.msg.type": "cosmos-sdk/MsgCreateValidator"
      }, {
        code: {
          $exists: false
        }
      }]
    });

    if (tx) {
      let block = Blockscon.findOne({
        height: tx.height
      });

      if (block) {
        return block.time;
      }
    } else {
      // no such create validator tx
      return false;
    }
  },

  // async 'Validators.getAllDelegations'(address){
  'Validators.getAllDelegations'(address) {
    let url = LCD + '/staking/validators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        delegations = JSON.parse(delegations.content).result;
        delegations.forEach((delegation, i) => {
          if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
        });
        return delegations;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/server/publications.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Validators;
module.link("../validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
let ValidatorRecords;
module.link("../../records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  }

}, 2);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 3);
Meteor.publish('validators.all', function () {
  let sort = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "description.moniker";
  let direction = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : -1;
  let fields = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return Validators.find({}, {
    sort: {
      [sort]: direction
    },
    fields: fields
  });
});
publishComposite('validators.firstSeen', {
  find() {
    return Validators.find({});
  },

  children: [{
    find(val) {
      return ValidatorRecords.find({
        address: val.address
      }, {
        sort: {
          height: 1
        },
        limit: 1
      });
    }

  }]
});
Meteor.publish('validators.voting_power', function () {
  return Validators.find({
    status: 2,
    jailed: false
  }, {
    sort: {
      voting_power: -1
    },
    fields: {
      address: 1,
      description: 1,
      voting_power: 1,
      profile_url: 1
    }
  });
});
publishComposite('validator.details', function (address) {
  let options = {
    address: address
  };

  if (address.indexOf(Meteor.settings.public.bech32PrefixValAddr) != -1) {
    options = {
      operator_address: address
    };
  }

  return {
    find() {
      return Validators.find(options);
    },

    children: [{
      find(val) {
        return VotingPowerHistory.find({
          address: val.address
        }, {
          sort: {
            height: -1
          },
          limit: 50
        });
      }

    }, {
      find(val) {
        return ValidatorRecords.find({
          address: val.address
        }, {
          sort: {
            height: -1
          },
          limit: Meteor.settings.public.uptimeWindow
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validators.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/validators.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Validators: () => Validators
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let ValidatorRecords;
module.link("../records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  }

}, 1);
let VotingPowerHistory;
module.link("../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 2);
const Validators = new Mongo.Collection('validators');
Validators.helpers({
  firstSeen() {
    return ValidatorRecords.findOne({
      address: this.address
    });
  },

  history() {
    return VotingPowerHistory.find({
      address: this.address
    }, {
      sort: {
        height: -1
      },
      limit: 50
    }).fetch();
  }

}); // Validators.helpers({
//     uptime(){
//         // console.log(this.address);
//         let lastHundred = ValidatorRecords.find({address:this.address}, {sort:{height:-1}, limit:100}).fetch();
//         console.log(lastHundred);
//         let uptime = 0;
//         for (i in lastHundred){
//             if (lastHundred[i].exists){
//                 uptime+=1;
//             }
//         }
//         return uptime;
//     }
// })
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"voting-power":{"server":{"publications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/voting-power/server/publications.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"history.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/voting-power/history.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  VotingPowerHistory: () => VotingPowerHistory
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const VotingPowerHistory = new Mongo.Collection('voting_power_history');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"evidences":{"evidences.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/evidences/evidences.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Evidences: () => Evidences
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Evidences = new Mongo.Collection('evidences');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validator-sets":{"validator-sets.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validator-sets/validator-sets.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  ValidatorSets: () => ValidatorSets
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const ValidatorSets = new Mongo.Collection('validator_sets');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"startup":{"both":{"index.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/both/index.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Import modules used by both client and server through a single index entry point
// e.g. useraccounts configuration file.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"create-indexes.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/create-indexes.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Blockscon;
module.link("../../api/blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 0);
let ValidatorRecords, Analytics, MissedBlocksStats, MissedBlocks, AverageData, AverageValidatorData;
module.link("../../api/records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  },

  MissedBlocks(v) {
    MissedBlocks = v;
  },

  AverageData(v) {
    AverageData = v;
  },

  AverageValidatorData(v) {
    AverageValidatorData = v;
  }

}, 1);
let Transactions;
module.link("../../api/transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 2);
let ValidatorSets;
module.link("../../api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 3);
let Validators;
module.link("../../api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 4);
let VotingPowerHistory;
module.link("../../api/voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 5);
let Evidences;
module.link("../../api/evidences/evidences.js", {
  Evidences(v) {
    Evidences = v;
  }

}, 6);
let CoinStats;
module.link("../../api/coin-stats/coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 7);
let ChainStates;
module.link("../../api/chain/chain.js", {
  ChainStates(v) {
    ChainStates = v;
  }

}, 8);
ChainStates.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
Blockscon.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
Blockscon.rawCollection().createIndex({
  proposerAddress: 1
});
Evidences.rawCollection().createIndex({
  height: -1
}); //Proposals.rawCollection().createIndex({proposalId: 1}, {unique:true});

ValidatorRecords.rawCollection().createIndex({
  address: 1,
  height: -1
}, {
  unique: 1
});
ValidatorRecords.rawCollection().createIndex({
  address: 1,
  exists: 1,
  height: -1
});
Analytics.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
MissedBlocks.rawCollection().createIndex({
  proposer: 1,
  voter: 1,
  updatedAt: -1
});
MissedBlocks.rawCollection().createIndex({
  proposer: 1,
  blockHeight: -1
});
MissedBlocks.rawCollection().createIndex({
  voter: 1,
  blockHeight: -1
});
MissedBlocks.rawCollection().createIndex({
  voter: 1,
  proposer: 1,
  blockHeight: -1
}, {
  unique: true
});
MissedBlocksStats.rawCollection().createIndex({
  proposer: 1
});
MissedBlocksStats.rawCollection().createIndex({
  voter: 1
});
MissedBlocksStats.rawCollection().createIndex({
  proposer: 1,
  voter: 1
}, {
  unique: true
});
AverageData.rawCollection().createIndex({
  type: 1,
  createdAt: -1
}, {
  unique: true
});
AverageValidatorData.rawCollection().createIndex({
  proposerAddress: 1,
  createdAt: -1
}, {
  unique: true
}); // Status.rawCollection.createIndex({})

Transactions.rawCollection().createIndex({
  txhash: 1
}, {
  unique: true
});
Transactions.rawCollection().createIndex({
  height: -1
}); // Transactions.rawCollection().createIndex({action:1});

Transactions.rawCollection().createIndex({
  "events.attributes.key": 1
});
Transactions.rawCollection().createIndex({
  "events.attributes.value": 1
});
ValidatorSets.rawCollection().createIndex({
  block_height: -1
});
Validators.rawCollection().createIndex({
  address: 1
}, {
  unique: true,
  partialFilterExpression: {
    address: {
      $exists: true
    }
  }
});
Validators.rawCollection().createIndex({
  consensus_pubkey: 1
}, {
  unique: true
});
Validators.rawCollection().createIndex({
  "pub_key.value": 1
}, {
  unique: true,
  partialFilterExpression: {
    "pub_key.value": {
      $exists: true
    }
  }
});
VotingPowerHistory.rawCollection().createIndex({
  address: 1,
  height: -1
});
VotingPowerHistory.rawCollection().createIndex({
  type: 1
});
CoinStats.rawCollection().createIndex({
  last_updated_at: -1
}, {
  unique: true
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/index.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("./util.js");
module.link("./register-api.js");
module.link("./create-indexes.js");
let onPageLoad;
module.link("meteor/server-render", {
  onPageLoad(v) {
    onPageLoad = v;
  }

}, 0);
let Helmet;
module.link("react-helmet", {
  Helmet(v) {
    Helmet = v;
  }

}, 1);
// import App from '../../ui/App.jsx';
onPageLoad(sink => {
  // const context = {};
  // const sheet = new ServerStyleSheet()
  // const html = renderToString(sheet.collectStyles(
  //     <StaticRouter location={sink.request.url} context={context}>
  //         <App />
  //     </StaticRouter>
  //   ));
  // sink.renderIntoElementById('app', html);
  const helmet = Helmet.renderStatic();
  sink.appendToHead(helmet.meta.toString());
  sink.appendToHead(helmet.title.toString()); // sink.appendToHead(sheet.getStyleTags());
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"register-api.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/register-api.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("../../api/ledger/server/methods.js");
module.link("../../api/chain/server/methods.js");
module.link("../../api/chain/server/publications.js");
module.link("../../api/blocks/server/methods.js");
module.link("../../api/blocks/server/publications.js");
module.link("../../api/validators/server/methods.js");
module.link("../../api/validators/server/publications.js");
module.link("../../api/records/server/methods.js");
module.link("../../api/records/server/publications.js");
module.link("../../api/enterprise/server/methods.js");
module.link("../../api/enterprise/server/publications.js");
module.link("../../api/voting-power/server/publications.js");
module.link("../../api/transactions/server/methods.js");
module.link("../../api/transactions/server/publications.js");
module.link("../../api/delegations/server/methods.js");
module.link("../../api/delegations/server/publications.js");
module.link("../../api/status/server/publications.js");
module.link("../../api/accounts/server/methods.js");
module.link("../../api/coin-stats/server/methods.js");
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"util.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/util.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let bech32;
module.link("bech32", {
  default(v) {
    bech32 = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let cheerio;
module.link("cheerio", {
  "*"(v) {
    cheerio = v;
  }

}, 2);

// Load future from fibers
var Future = Npm.require("fibers/future"); // Load exec


var exec = Npm.require("child_process").exec;

function toHexString(byteArray) {
  return byteArray.map(function (byte) {
    return ('0' + (byte & 0xFF).toString(16)).slice(-2);
  }).join('');
}

Meteor.methods({
  pubkeyToBech32: function (pubkey, prefix) {
    // '1624DE6420' is ed25519 pubkey prefix
    let pubkeyAminoPrefix = Buffer.from('1624DE6420', 'hex');
    let buffer = Buffer.alloc(37);
    pubkeyAminoPrefix.copy(buffer, 0);
    Buffer.from(pubkey.value, 'base64').copy(buffer, pubkeyAminoPrefix.length);
    return bech32.encode(prefix, bech32.toWords(buffer));
  },
  bech32ToPubkey: function (pubkey) {
    // '1624DE6420' is ed25519 pubkey prefix
    let pubkeyAminoPrefix = Buffer.from('1624DE6420', 'hex');
    let buffer = Buffer.from(bech32.fromWords(bech32.decode(pubkey).words));
    return buffer.slice(pubkeyAminoPrefix.length).toString('base64');
  },
  getDelegator: function (operatorAddr) {
    let address = bech32.decode(operatorAddr);
    return bech32.encode(Meteor.settings.public.bech32PrefixAccAddr, address.words);
  },
  getKeybaseTeamPic: function (keybaseUrl) {
    let teamPage = HTTP.get(keybaseUrl);

    if (teamPage.statusCode == 200) {
      let page = cheerio.load(teamPage.content);
      return page(".kb-main-card img").attr('src');
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"ui":{"components":{"Icons.jsx":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/ui/components/Icons.jsx                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  DenomSymbol: () => DenomSymbol,
  ProposalStatusIcon: () => ProposalStatusIcon,
  VoteIcon: () => VoteIcon,
  TxIcon: () => TxIcon,
  InfoIcon: () => InfoIcon
});
let React;
module.link("react", {
  default(v) {
    React = v;
  }

}, 0);
let UncontrolledTooltip;
module.link("reactstrap", {
  UncontrolledTooltip(v) {
    UncontrolledTooltip = v;
  }

}, 1);

const DenomSymbol = props => {
  switch (props.denom) {
    case "steak":
      return '🥩';

    default:
      return '🍅';
  }
};

const ProposalStatusIcon = props => {
  switch (props.status) {
    case 'Passed':
      return React.createElement("i", {
        className: "fas fa-check-circle text-success"
      });

    case 'Rejected':
      return React.createElement("i", {
        className: "fas fa-times-circle text-danger"
      });

    case 'Removed':
      return React.createElement("i", {
        className: "fas fa-trash-alt text-dark"
      });

    case 'DepositPeriod':
      return React.createElement("i", {
        className: "fas fa-battery-half text-warning"
      });

    case 'VotingPeriod':
      return React.createElement("i", {
        className: "fas fa-hand-paper text-info"
      });

    default:
      return React.createElement("i", null);
  }
};

const VoteIcon = props => {
  switch (props.vote) {
    case 'yes':
      return React.createElement("i", {
        className: "fas fa-check text-success"
      });

    case 'no':
      return React.createElement("i", {
        className: "fas fa-times text-danger"
      });

    case 'abstain':
      return React.createElement("i", {
        className: "fas fa-user-slash text-warning"
      });

    case 'no_with_veto':
      return React.createElement("i", {
        className: "fas fa-exclamation-triangle text-info"
      });

    default:
      return React.createElement("i", null);
  }
};

const TxIcon = props => {
  if (props.valid) {
    return React.createElement("span", {
      className: "text-success text-nowrap"
    }, React.createElement("i", {
      className: "fas fa-check-circle"
    }));
  } else {
    return React.createElement("span", {
      className: "text-danger text-nowrap"
    }, React.createElement("i", {
      className: "fas fa-times-circle"
    }));
  }
};

class InfoIcon extends React.Component {
  constructor(props) {
    super(props);
    this.ref = React.createRef();
  }

  render() {
    return [React.createElement("i", {
      key: "icon",
      className: "material-icons info-icon",
      ref: this.ref
    }, "info"), React.createElement(UncontrolledTooltip, {
      key: "tooltip",
      placement: "right",
      target: this.ref
    }, this.props.children ? this.props.children : this.props.tooltipText)];
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"both":{"i18n":{"en-us.i18n.yml.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/en-us.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('en-US','',{"common":{"height":"Height","voter":"Voter","votingPower":"Voting Power","addresses":"Addresses","amounts":"Amounts","delegators":"delegators","block":"block","blocks":"blocks","precommit":"precommit","precommits":"precommits","last":"last","backToList":"Back to List","information":"Information","time":"Time","hash":"Hash","more":"More","fullStop":".","searchPlaceholder":"Search with tx hash / block height / address","cancel":"Cancel","retry":"Retry"},"navbar":{"siteName":"Unification Mainchain","version":"beta","validators":"Validators","blocks":"Blocks","transactions":"Transactions","proposals":"Proposals","votingPower":"Voting Power","lang":"ENG","english":"English","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"Fork me!"},"consensus":{"consensusState":"Consensus State","round":"Round","step":"Step"},"chainStates":{"price":"Price","marketCap":"Market Cap","inflation":"Inflation","communityPool":"Community Pool"},"chainStatus":{"startMessage":"The chain is going to start in","stopWarning":"The chain appears to be stopped for <em>{$time}</em>! Feed me with new blocks 😭!","latestHeight":"Latest Block Height","averageBlockTime":"Average Block Time","all":"All","now":"Now","allTime":"All Time","lastMinute":"Last Minute","lastHour":"Last Hour","lastDay":"Last Day","seconds":"seconds","activeValidators":"Active Validators","outOfValidators":"out of {$totalValidators} validators","onlineVotingPower":"Online Voting Power","fromTotalStakes":"{$percent} from {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"Block Time History","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"Random Validators","moniker":"Moniker","uptime":"Uptime","selfPercentage":"Self%","commission":"Commission","lastSeen":"Last Seen","status":"Status","jailed":"Jailed","navActive":"Active","navInactive":"Inactive","active":"Active Validators","inactive":"Inactive Validators","listOfActive":"Here is a list of active validators.","listOfInactive":"Here is a list of inactive validators.","validatorDetails":"Validator Details","lastNumBlocks":"Last {$numBlocks} blocks","validatorInfo":"Validator Info","operatorAddress":"Operator Address","selfDelegationAddress":"Self-Delegate Address","commissionRate":"Commission Rate","maxRate":"Max Rate","maxChangeRate":"Max Change Rate","selfDelegationRatio":"Self Delegation Ratio","proposerPriority":"Proposer Priority","delegatorShares":"Delegator Shares","userDelegateShares":"Shares Delegated by you","tokens":"Tokens","unbondingHeight":"Unbonding Height","unbondingTime":"Unbonding Time","powerChange":"Power Change","delegations":"Delegations","transactions":"Transactions","validatorNotExists":"Validator does not exist.","backToValidator":"Back to Validator","missedBlocks":"Missed Blocks","missedPrecommits":"Missed Precommits","missedBlocksTitle":"Missed blocks of {$moniker}","totalMissed":"Total missed","block":"Block","missedCount":"Miss Count","iDontMiss":"I do not miss ","lastSyncTime":"Last sync time","delegator":"Delegator","amount":"Amount"},"blocks":{"block":"Block","proposer":"Proposer","latestBlocks":"Latest blocks","noBlock":"No block.","numOfTxs":"No. of Txs","numOfTransactions":"No. of Transactions","notFound":"No such block found."},"transactions":{"transaction":"Transaction","transactions":"Transactions","notFound":"No transaction found.","activities":"Activities","txHash":"Tx Hash","valid":"Valid","fee":"Fee","gasUsedWanted":"Gas (used / wanted)","noTxFound":"No such transaction found.","noValidatorTxsFound":"No transaction related to this validator was found.","memo":"Memo","transfer":"Transfer","staking":"Staking","distribution":"Distribution","governance":"Governance","slashing":"Slashing","enterprise":"Enterprise","wrkchain":"WRKChain","beacon":"BEACON"},"proposals":{"notFound":"No proposal found.","listOfProposals":"Here is a list of governance proposals.","proposer":"Proposer","proposal":"proposal","proposals":"Proposals","proposalID":"Proposal ID","title":"Title","status":"Status","submitTime":"Submit Time","depositEndTime":"Deposit End Time","votingStartTime":"Voting Start Time","votingEndTime":"End Voting Time","totalDeposit":"Total Deposit","description":"Description","proposalType":"Proposal Type","proposalStatus":"Proposal Status","notStarted":"not started","final":"final","deposit":"Deposit","tallyResult":"Tally Result","yes":"Yes","abstain":"Abstain","no":"No","noWithVeto":"No with Veto","percentageVoted":"<span class=\"text-info\">{$percent}</span> of online voting power has been voted.","validMessage":"This proposal is {$tentative}<strong>valid</strong>.","invalidMessage":"Less than {$quorum} of voting power is voted. This proposal is <strong>invalid</strong>.","moreVoteMessage":"It will be a valid proposal once <span class=\"text-info\">{$moreVotes}</span> more votes are casted."},"votingPower":{"distribution":"Voting Power Distribution","pareto":"Pareto Principle (20/80 rule)","minValidators34":"Min no. of validators hold 34%+ power"},"accounts":{"accountDetails":"Account Details","available":"Available","delegated":"Delegated","unbonding":"Unbonding","rewards":"Rewards","total":"Total","notFound":"This account does not exist. Are you looking for a wrong address?","validators":"Validators","shares":"Shares","mature":"Mature","no":"No ","delegation":"Delegation","plural":"s","signOut":"Sign out","signInText":"You are signed in as ","toLoginAs":"To log in as","signInWithLedger":"Sign In With Ledger","signInWarning":"Please make sure your Ledger device is connected and <strong class=\"text-primary\">Cosmos App 1.5.0 or above</strong> is opened.","pleaseAccept":"please accept in your Ledger device."},"activities":{"single":"A","happened":"happened.","senders":"The following sender(s)","sent":"sent","receivers":"to the following receipient(s)","received":"received","failedTo":"failed to ","to":"to","from":"from","operatingAt":"operating at","withMoniker":"with moniker","withTitle":"with title","withA":"with a","purchased":"purchased","decision":"decision"},"messageTypes":{"send":"Send","multiSend":"Multi Send","createValidator":"Create Validator","editValidator":"Edit Validator","delegate":"Delegate","undelegate":"Undelegate","redelegate":"Redelegate","submitProposal":"Submit Proposal","deposit":"Deposit","vote":"Vote","withdrawComission":"Withdraw Commission","withdrawReward":"Withdraw Reward","modifyWithdrawAddress":"Modify Withdraw Address","unjail":"Unjail","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive","enterprisePurchase":"Purchase Enterprise UND","enterpriseProcess":"Process Enterprise Purchase Order","wrkchainRegister":"Register WRKChain","wrkchainRecord":"Record WRKChain Hashes","beaconRegister":"Register BEACON","beaconRecord":"Record BEACON Timestamp"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"zh-hans.i18n.yml.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/zh-hans.i18n.yml.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('zh-Hans','',{"common":{"height":"高度","voter":"投票人","votingPower":"投票权","addresses":"地址","amounts":"数量","delegators":"委托人","block":"区块","blocks":"区块","precommit":"建块前保证","precommits":"建块前保证","last":"最后","backToList":"回到列表","information":"资讯","time":"时间","hash":"哈希","more":"更多","fullStop":"。","searchPlaceholder":"搜寻交易哈希 / 区块高度 / 地址","cancel":"取消","retry":"重试"},"navbar":{"siteName":"北斗","version":"beta","validators":"验证人","blocks":"区块","transactions":"交易","proposals":"治理提案","votingPower":"投票权分布","lang":"中文（简）","english":"English","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"Fork me!"},"consensus":{"consensusState":"共识状态","round":"轮数","step":"阶数"},"chainStates":{"price":"价格","marketCap":"市值","inflation":"通胀率","communityPool":"社区储备"},"chainStatus":{"startMessage":"这链将还有以下时间便会开始","stopWarning":"这链似乎已经停了 <em>{$time}</em>！ 请继续喂我吃新的区块 😭!","latestHeight":"最新区块高度","averageBlockTime":"平均区块时间","all":"全部","now":"现在","allTime":"全部","lastMinute":"前一分钟","lastHour":"前一小时","lastDay":"前一天","seconds":"秒","activeValidators":"有效验证人","outOfValidators":"来自总共 {$totalValidators} 个验证人","onlineVotingPower":"在线投票权","fromTotalStakes":"为 {$totalStakes} 颗 {$denom} 的 {$percent}"},"analytics":{"blockTimeHistory":"在线投票权","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"随机验证人","moniker":"验证人代号","uptime":"上线时间比重","selfPercentage":"自我委托%","commission":"佣金","lastSeen":"最后投票时间","status":"状态","jailed":"被禁制","navActive":"有效","navInactive":"无效","active":"有效验证人","inactive":"无效验证人","listOfActive":"这名单显示所有有效验证人","listOfInactive":"这名单显示所有无效验证人","validatorDetails":"验证人详情","lastNumBlocks":"最后 {$numBlocks} 个区块","validatorInfo":"验证人资讯","operatorAddress":"操作地址","selfDelegationAddress":"自我委托地址","commissionRate":"佣金","maxRate":"最大佣金限制","maxChangeRate":"每天最大佣金变化限制","selfDelegationRatio":"自我委托比例","proposerPriority":"建块优先权","delegatorShares":"委托股数","userDelegateShares":"你委托的股数","tokens":"代币数量","unbondingHeight":"解绑高度","unbondingTime":"解绑时间","powerChange":"投票权变更","delegations":"委托","transactions":"交易","validatorNotExists":"验证人不存在。","backToValidator":"回到验证人页面","missedBlocks":"错过了的区块","missedPrecommits":"遗留了的建块前保证","missedBlocksTitle":"错过了 {$moniker} 的区块","totalMissed":"一共错过了","block":"区块","missedCount":"错过数量","iDontMiss":"我不会错过任何一个","lastSyncTime":"上一次同步时间","delegator":"委托人","amount":"数量"},"blocks":{"proposer":"建块人","block":"区块","latestBlocks":"最近区块","noBlock":"没有区块。","numOfTxs":"交易数量","numOfTransactions":"交易数量","notFound":"没有这个区块。"},"transactions":{"transaction":"交易","transactions":"交易","notFound":"沒有交易。","activities":"活动","txHash":"交易哈希","valid":"有效","fee":"费用","gasUsedWanted":"瓦斯 (已用 / 要求)","noTxFound":"没有这笔交易。","noValidatorTxsFound":"没有跟这个验证人有关的交易","memo":"备忘录","transfer":"代币转移","staking":"委托","distribution":"收益分配","governance":"链上治理","slashing":"削减","enterprise":"企业","wrkchain":"WRKChain","beacon":"BEACON"},"proposals":{"notFound":"没有治理提案","listOfProposals":"这名单显示所有治理提案","proposer":"提案人","proposal":"治理提案","proposals":"治理提案","proposalID":"提案编号","title":"主题","status":"状态","submitTime":"提案时间","depositEndTime":"存入押金","votingStartTime":"投票开始时间","votingEndTime":"投票结束时间","totalDeposit":"押金总额","description":"详细内容","proposalType":"提案类型","proposalStatus":"提案状态","notStarted":"未开始","final":"最后结果","deposit":"押金","tallyResult":"投票结果","yes":"赞成","abstain":"弃权","no":"反对","noWithVeto":"强烈反对","percentageVoted":"现时在线投票权的投票率是 <span class=\"text-info\">{$percent}</span>。","validMessage":"这个提案 {$tentative} <strong>有效</strong>.","invalidMessage":"已投票的在线投票权少于 {$quorum}。这个提案 <strong>無效</strong>。","moreVoteMessage":"当再有多 <span class=\"text-info\">{$moreVotes}</span> 投票权投了票的话，这个提案将会有效。"},"votingPower":{"distribution":"投票权分布","pareto":"帕累托原则 (20/80 定率)","minValidators34":"最少合共有超过 34% 投票权的验证人"},"accounts":{"accountDetails":"帐户详情","available":"可用的","delegated":"委托中","unbonding":"解绑中","rewards":"未取回收益","total":"总共","notFound":"这个帐户不存在。你是否在查看一个错误的地址？","validators":"验证人","shares":"股数","mature":"成熟日期","no":"没有","delegation":"委托","plural":"","signOut":"登出","signInText":"你已登录以下帐户","toLoginAs":"登录以下帐户","signInWithLedger":"透过 Ledger 登录","signInWarning":"请确定你已经连接 Ledger 设备，并已开启 <strong class=\"text-primary\">Cosmos App 版本 1.5.0 或以上</strong>。","pleaseAccept":"请从你的 Ledger 设备确认。"},"activities":{"single":"一个","happened":"发生了","senders":"以下的帐户","sent":"发了","receivers":"到以下的帐户","received":"收到","failedTo":"未能","to":"到","from":"从","operatingAt":"操作地址为","withMoniker":"而验证人代号为","withTitle":"治理提案主题为","withA":"投了","purchased":"已购买","decision":"决定"},"messageTypes":{"send":"发送","multiSend":"多重发送","createValidator":"建立验证人","editValidator":"编辑验证人资料","delegate":"委托","undelegate":"解委托","redelegate":"转委托","submitProposal":"提交议案","deposit":"存入","vote":"投票","withdrawComission":"提取手续费","withdrawReward":"提取收益","modifyWithdrawAddress":"更改收益取回地址","unjail":"赦免","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive","enterprisePurchase":"Purchase Enterprise UND","enterpriseProcess":"Process Enterprise Purchase Order","wrkchainRegister":"Register WRKChain","wrkchainRecord":"Record WRKChain Hashes","beaconRegister":"Register BEACON","beaconRecord":"Record BEACON Timestamp"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"zh-hant.i18n.yml.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/zh-hant.i18n.yml.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('zh-Hant','',{"common":{"height":"高度","voter":"投票人","votingPower":"投票權","addresses":"地址","amounts":"數量","delegators":"委托人","block":"區塊","blocks":"區塊","precommit":"建塊前保證","precommits":"建塊前保證","last":"最後","backToList":"回到列表","information":"資訊","time":"時間","hash":"哈希","more":"更多","fullStop":"。","searchPlaceholder":"搜尋交易哈希 / 區塊高度 / 地址","cancel":"取消","retry":"重試"},"navbar":{"siteName":"北斗","version":"beta","validators":"驗證人","blocks":"區塊","transactions":"交易","proposals":"治理提案","votingPower":"投票權分佈","lang":"中文（繁）","english":"English","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"Fork me!"},"consensus":{"consensusState":"共識狀態","round":"輪數","step":"階數"},"chainStates":{"price":"價格","marketCap":"市值","inflation":"通漲率","communityPool":"社區儲備"},"chainStatus":{"startMessage":"這鏈將還有以下時間便會開始","stopWarning":"這鏈似乎已經停了 <em>{$time}</em>！ 請繼續餵我吃新的區塊 😭!","latestHeight":"最新區塊高度","averageBlockTime":"平均區塊時間","all":"全部","now":"現在","allTime":"全部","lastMinute":"前一分鐘","lastHour":"前一小時","lastDay":"前一天","seconds":"秒","activeValidators":"有效驗證人","outOfValidators":"來自總共 {$totalValidators} 個驗證人","onlineVotingPower":"在線投票權","fromTotalStakes":"為 {$totalStakes} 顆 {$denom} 的 {$percent}"},"analytics":{"blockTimeHistory":"在線投票權","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"隨機驗證人","moniker":"驗證人代號","uptime":"上線時間比重","selfPercentage":"自我委托%","commission":"佣金","lastSeen":"最後投票時間","status":"狀態","jailed":"被禁制","navActive":"有效","navInactive":"無效","active":"有效驗證人","inactive":"無效驗證人","listOfActive":"這名單顯示所有有效驗證人","listOfInactive":"這名單顯示所有無效驗證人","validatorDetails":"驗證人詳情","lastNumBlocks":"最後 {$numBlocks} 個區塊","validatorInfo":"驗證人資訊","operatorAddress":"操作地址","selfDelegationAddress":"自我委托地址","commissionRate":"佣金","maxRate":"最大佣金限制","maxChangeRate":"每天最大佣金變化限制","selfDelegationRatio":"自我委托比列","proposerPriority":"建塊優先權","delegatorShares":"委托股數","userDelegateShares":"你委托的股數","tokens":"代幣數量","unbondingHeight":"解綁高度","unbondingTime":"解綁時間","powerChange":"投票權變更","delegations":"委托","transactions":"交易","validatorNotExists":"驗證人不存在。","backToValidator":"回到驗證人頁面","missedBlocks":"錯過了的區塊","missedPrecommits":"遺留了的建塊前保證","missedBlocksTitle":"錯過了 {$moniker} 的區塊","totalMissed":"一共錯過了","block":"區塊","missedCount":"錯過數量","iDontMiss":"我不會錯過任何一個","lastSyncTime":"上一次同步時間","delegator":"委托人","amount":"數量"},"blocks":{"proposer":"建塊人","block":"區塊","latestBlocks":"最近區塊","noBlock":"沒有區塊。","numOfTxs":"交易數量","numOfTransactions":"交易數量","notFound":"沒有這個區塊。"},"transactions":{"transaction":"交易","transactions":"交易","notFound":"沒有交易。","activities":"活動","txHash":"交易哈希","valid":"有效","fee":"費用","gasUsedWanted":"瓦斯 (已用 / 要求)","noTxFound":"沒有這筆交易。","noValidatorTxsFound":"沒有跟這個驗證人有關的交易","memo":"備忘錄","transfer":"代幣轉移","staking":"委托","distribution":"收益分配","governance":"鏈上治理","slashing":"削減","enterprise":"企業","wrkchain":"WRKChain","beacon":"BEACON"},"proposals":{"notFound":"沒有治理提案","listOfProposals":"這名單顯示所有治理提案","proposer":"提案人","proposal":"治理提案","proposals":"治理提案","proposalID":"提案編號","title":"主題","status":"狀態","submitTime":"提案時間","depositEndTime":"存入押金","votingStartTime":"投票開始時間","votingEndTime":"投票結束時間","totalDeposit":"押金總額","description":"詳細內容","proposalType":"提案類型","proposalStatus":"提案狀態","notStarted":"未開始","final":"最後結果","deposit":"押金","tallyResult":"投票結果","yes":"贊成","abstain":"棄權","no":"反對","noWithVeto":"強烈反對","percentageVoted":"現時在線投票權的投票率是 <span class=\"text-info\">{$percent}</span>。","validMessage":"這個提案 {$tentative} <strong>有效</strong>.","invalidMessage":"已投票的在線投票權少於 {$quorum}。這個 <strong>無效</strong>。","moreVoteMessage":"當再有多 <span class=\"text-info\">{$moreVotes}</span> 投票權投了票的話，這個提案將會有效。"},"votingPower":{"distribution":"投票權分佈","pareto":"帕累托原則 (20/80 定率)","minValidators34":"最少合共有超過 34% 投票權的驗證人"},"accounts":{"accountDetails":"帳戶詳情","available":"可用的","delegated":"委托中","unbonding":"解綁中","rewards":"未取回收益","total":"總共","notFound":"這個帳戶不存在。你是否在查看一個錯誤的地址？","validators":"驗證人","shares":"股數","mature":"成熟日期","no":"沒有","delegation":"委托","plural":"","signOut":"登出","signInText":"你已登入以下帳戶","toLoginAs":"登入以下帳戶","signInWithLedger":"透過 Ledger 登入","signInWarning":"請確定你已經連接 Ledger 設備，並已開啓 <strong class=\"text-primary\">Cosmos App 版本 1.5.0 或以上</strong>。","pleaseAccept":"請從你的 Ledger 設備確認。"},"activities":{"single":"一個","happened":"發生了","senders":"以下的帳戶","sent":"發了","receivers":"到以下的帳戶","received":"收到","failedTo":"未能","to":"到","from":"從","operatingAt":"操作地止為","withMoniker":"而驗證人代號為","withTitle":"治理提案主題為","withA":"投了","purchased":"已購買","decision":"決定"},"messageTypes":{"send":"發送","multiSend":"多重發送","createValidator":"建立驗證人","editValidator":"編輯驗證人資料","delegate":"委托","undelegate":"解委托","redelegate":"轉委托","submitProposal":"提交議案","deposit":"存入","vote":"投票","withdrawComission":"提取手續費","withdrawReward":"提取收益","modifyWithdrawAddress":"更改收益取回地址","unjail":"赦免","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive","enterprisePurchase":"Purchase Enterprise UND","enterpriseProcess":"Process Enterprise Purchase Order","wrkchainRegister":"Register WRKChain","wrkchainRecord":"Record WRKChain Hashes","beaconRegister":"Register BEACON","beaconRecord":"Record BEACON Timestamp"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"utils":{"coins.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/utils/coins.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => Coin
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let numbro;
module.link("numbro", {
  default(v) {
    numbro = v;
  }

}, 1);

autoformat = value => {
  let formatter = '0,0.0000';
  value = Math.round(value * 1000) / 1000;
  if (Math.round(value) === value) formatter = '0,0';else if (Math.round(value * 10) === value * 10) formatter = '0,0.0';else if (Math.round(value * 100) === value * 100) formatter = '0,0.00';else if (Math.round(value * 1000) === value * 1000) formatter = '0,0.000';
  return numbro(value).format(formatter);
};

class Coin {
  constructor(amount) {
    let denom = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    if (typeof amount === 'object') ({
      amount,
      denom
    } = amount);

    if (!denom || denom.toLowerCase() === Coin.MintingDenom.toLowerCase()) {
      this._amount = Number(amount);
    } else if (denom.toLowerCase() === Coin.StakingDenom.toLowerCase()) {
      this._amount = Number(amount) * Coin.StakingFraction;
    } else {
      throw Error("unsupported denom ".concat(denom));
    }
  }

  get amount() {
    return this._amount;
  }

  get stakingAmount() {
    return this._amount / Coin.StakingFraction;
  }

  toString(precision) {
    // default to display in mint denom if it has more than 4 decimal places
    let minStake = Coin.StakingFraction / (precision ? Math.pow(10, precision) : 10000);

    if (this.amount < minStake) {
      return "".concat(numbro(this.amount).format('0,0'), " ").concat(Coin.MintingDenom);
    } else {
      return "".concat(precision ? numbro(this.stakingAmount).format('0,0.' + '0'.repeat(precision)) : autoformat(this.stakingAmount), " ").concat(Coin.StakingDenom);
    }
  }

  mintString(formatter) {
    let amount = this.amount;

    if (formatter) {
      amount = numbro(amount).format(formatter);
    }

    return "".concat(amount, " ").concat(Coin.MintingDenom);
  }

  stakeString(formatter) {
    let amount = this.stakingAmount;

    if (formatter) {
      amount = numbro(amount).format(formatter);
    }

    return "".concat(amount, " ").concat(Coin.StakingDenom);
  }

}

Coin.StakingDenom = Meteor.settings.public.stakingDenom;
Coin.StakingDenomPlural = Meteor.settings.public.stakingDenomPlural || Coin.StakingDenom + 's';
Coin.MintingDenom = Meteor.settings.public.mintingDenom;
Coin.StakingFraction = Number(Meteor.settings.public.stakingFraction);
Coin.MinStake = 1 / Number(Meteor.settings.public.stakingFraction);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("/imports/startup/server");
module.link("/imports/startup/both");
// import moment from 'moment';
// import '/imports/api/blocks/blocks.js';
SYNCING = false;
COUNTMISSEDBLOCKS = false;
COUNTMISSEDBLOCKSSTATS = false;
RPC = Meteor.settings.remote.rpc;
LCD = Meteor.settings.remote.lcd;
timerBlocks = 0;
timerChain = 0;
timerConsensus = 0;
timerProposal = 0;
timerProposalsResults = 0;
timerMissedBlock = 0;
timerDelegation = 0;
timerAggregate = 0;
const DEFAULTSETTINGS = '/default_settings.json';

updateChainStatus = () => {
  Meteor.call('chain.updateStatus', (error, result) => {
    if (error) {
      console.log("updateStatus: " + error);
    } else {
      console.log("updateStatus: " + result);
    }
  });
};

updateBlock = () => {
  Meteor.call('blocks.blocksUpdate', (error, result) => {
    if (error) {
      console.log("updateBlocks: " + error);
    } else {
      console.log("updateBlocks: " + result);
    }
  });
};

getConsensusState = () => {
  Meteor.call('chain.getConsensusState', (error, result) => {
    if (error) {
      console.log("get consensus: " + error);
    }
  });
};

getPurchaseOrders = () => {
  Meteor.call('enterprise.getPurchaseOrders', (error, result) => {
    if (error) {
      console.log("get po: " + error);
    }

    if (result) {
      console.log("get po: " + result);
    }
  });
}; //getProposals = () => {
//    Meteor.call('proposals.getProposals', (error, result) => {
//        if (error){
//            console.log("get proposal: "+ error);
//        }
//        if (result){
//            console.log("get proposal: "+result);
//        }
//    });
//}
//
//getProposalsResults = () => {
//    Meteor.call('proposals.getProposalResults', (error, result) => {
//        if (error){
//            console.log("get proposals result: "+error);
//        }
//        if (result){
//            console.log("get proposals result: "+result);
//        }
//    });
//}


updateMissedBlocks = () => {
  Meteor.call('ValidatorRecords.calculateMissedBlocks', (error, result) => {
    if (error) {
      console.log("missed blocks error: " + error);
    }

    if (result) {
      console.log("missed blocks ok:" + result);
    }
  });
  /*
      Meteor.call('ValidatorRecords.calculateMissedBlocksStats', (error, result) =>{
          if (error){
              console.log("missed blocks stats error: "+ error)
          }
          if (result){
              console.log("missed blocks stats ok:" + result);
          }
      });
  */
};

getDelegations = () => {
  Meteor.call('delegations.getDelegations', (error, result) => {
    if (error) {
      console.log("get delegations error: " + error);
    } else {
      console.log("get delegations ok: " + result);
    }
  });
};

aggregateMinutely = () => {
  // doing something every min
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "m", (error, result) => {
    if (error) {
      console.log("aggregate minutely block time error: " + error);
    } else {
      console.log("aggregate minutely block time ok: " + result);
    }
  });
  Meteor.call('coinStats.getCoinStats', (error, result) => {
    if (error) {
      console.log("get coin stats error: " + error);
    } else {
      console.log("get coin stats ok: " + result);
    }
  });
};

aggregateHourly = () => {
  // doing something every hour
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "h", (error, result) => {
    if (error) {
      console.log("aggregate hourly block time error: " + error);
    } else {
      console.log("aggregate hourly block time ok: " + result);
    }
  });
};

aggregateDaily = () => {
  // doing somthing every day
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "d", (error, result) => {
    if (error) {
      console.log("aggregate daily block time error: " + error);
    } else {
      console.log("aggregate daily block time ok: " + result);
    }
  });
  Meteor.call('Analytics.aggregateValidatorDailyBlockTime', (error, result) => {
    if (error) {
      console.log("aggregate validators block time error:" + error);
    } else {
      console.log("aggregate validators block time ok:" + result);
    }
  });
};

Meteor.startup(function () {
  if (Meteor.isDevelopment) {
    let DEFAULTSETTINGSJSON;
    module.link("../default_settings.json", {
      default(v) {
        DEFAULTSETTINGSJSON = v;
      }

    }, 0);
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;
    Object.keys(DEFAULTSETTINGSJSON).forEach(key => {
      if (Meteor.settings[key] == undefined) {
        console.warn("CHECK SETTINGS JSON: ".concat(key, " is missing from settings"));
        Meteor.settings[key] = {};
      }

      Object.keys(DEFAULTSETTINGSJSON[key]).forEach(param => {
        if (Meteor.settings[key][param] == undefined) {
          console.warn("CHECK SETTINGS JSON: ".concat(key, ".").concat(param, " is missing from settings"));
          Meteor.settings[key][param] = DEFAULTSETTINGSJSON[key][param];
        }
      });
    });
  }

  Meteor.call('chain.genesis', (err, result) => {
    if (err) {
      console.log(err);
    }

    if (result) {
      if (Meteor.settings.debug.startTimer) {
        timerConsensus = Meteor.setInterval(function () {
          getConsensusState();
        }, Meteor.settings.params.consensusInterval);
        timerBlocks = Meteor.setInterval(function () {
          updateBlock();
        }, Meteor.settings.params.blockInterval);
        timerChain = Meteor.setInterval(function () {
          updateChainStatus();
        }, Meteor.settings.params.statusInterval);
        timerPurchaseOrder = Meteor.setInterval(function () {
          getPurchaseOrders();
        }, Meteor.settings.params.proposalInterval); //                timerProposal = Meteor.setInterval(function(){
        //                    getProposals();
        //                }, Meteor.settings.params.proposalInterval);
        //
        //                timerProposalsResults = Meteor.setInterval(function(){
        //                    getProposalsResults();
        //                }, Meteor.settings.params.proposalInterval);

        timerMissedBlock = Meteor.setInterval(function () {
          updateMissedBlocks();
        }, Meteor.settings.params.missedBlocksInterval);
        timerDelegation = Meteor.setInterval(function () {
          getDelegations();
        }, Meteor.settings.params.delegationInterval);
        timerAggregate = Meteor.setInterval(function () {
          let now = new Date();

          if (now.getUTCSeconds() == 0) {
            aggregateMinutely();
          }

          if (now.getUTCMinutes() == 0 && now.getUTCSeconds() == 0) {
            aggregateHourly();
          }

          if (now.getUTCHours() == 0 && now.getUTCMinutes() == 0 && now.getUTCSeconds() == 0) {
            aggregateDaily();
          }
        }, 1000);
      }
    }
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"default_settings.json":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// default_settings.json                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "public": {
    "chainName": "Cosmos Testnet",
    "chainId": "{Chain ID}",
    "gtm": "{Add your Google Tag Manager ID here}",
    "slashingWindow": 10000,
    "uptimeWindow": 250,
    "initialPageSize": 30,
    "bech32PrefixAccAddr": "cosmos",
    "bech32PrefixAccPub": "cosmospub",
    "bech32PrefixValAddr": "cosmosvaloper",
    "bech32PrefixValPub": "cosmosvaloperpub",
    "bech32PrefixConsAddr": "cosmosvalcons",
    "bech32PrefixConsPub": "cosmosvalconspub",
    "stakingDenom": "ATOM",
    "stakingDenomPlural": null,
    "mintingDenom": "uatom",
    "stakingFraction": 1000000,
    "powerReduction": null,
    "gasPrice": 0.02,
    "coingeckoId": "cosmos"
  },
  "genesisFile": "{Replace the address of the genesis file of the chain}",
  "remote": {
    "rpc": "https://gaia-seeds.interblock.io",
    "lcd": "https://gaia-seeds.interblock.io:1317"
  },
  "debug": {
    "startTimer": true,
    "readGenesis": true
  },
  "params": {
    "startHeight": 0,
    "defaultBlockTime": 5000,
    "blockInterval": 15000,
    "consensusInterval": 1000,
    "statusInterval": 7500,
    "signingInfoInterval": 1800000,
    "proposalInterval": 5000,
    "missedBlocksInterval": 60000,
    "delegationInterval": 900000
  }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx",
    ".mjs",
    ".i18n.yml"
  ]
});

require("/both/i18n/en-us.i18n.yml.js");
require("/both/i18n/zh-hans.i18n.yml.js");
require("/both/i18n/zh-hant.i18n.yml.js");
require("/both/utils/coins.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWNjb3VudHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jsb2Nrcy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYmxvY2tzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jsb2Nrcy9ibG9ja3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2NoYWluL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jaGFpbi9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jaGFpbi9jaGFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29pbi1zdGF0cy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29pbi1zdGF0cy9jb2luLXN0YXRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9kZWxlZ2F0aW9ucy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZGVsZWdhdGlvbnMvZGVsZWdhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2VudGVycHJpc2Uvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2VudGVycHJpc2Uvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZW50ZXJwcmlzZS9lbnRlcnByaXNlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9sZWRnZXIvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3JlY29yZHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3JlY29yZHMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcmVjb3Jkcy9yZWNvcmRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zdGF0dXMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc3RhdHVzL3N0YXR1cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdHJhbnNhY3Rpb25zL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90cmFuc2FjdGlvbnMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdHJhbnNhY3Rpb25zL3RyYW5zYWN0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdmFsaWRhdG9ycy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdmFsaWRhdG9ycy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3ZvdGluZy1wb3dlci9oaXN0b3J5LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9ldmlkZW5jZXMvZXZpZGVuY2VzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS92YWxpZGF0b3Itc2V0cy92YWxpZGF0b3Itc2V0cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL2JvdGgvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvY3JlYXRlLWluZGV4ZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvcmVnaXN0ZXItYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL3V0aWwuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdWkvY29tcG9uZW50cy9JY29ucy5qc3giLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvdXRpbHMvY29pbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIk1ldGVvciIsIm1vZHVsZSIsImxpbmsiLCJ2IiwiSFRUUCIsIlZhbGlkYXRvcnMiLCJmZXRjaEZyb21VcmwiLCJ1cmwiLCJyZXMiLCJnZXQiLCJMQ0QiLCJzdGF0dXNDb2RlIiwiZSIsImNvbnNvbGUiLCJsb2ciLCJtZXRob2RzIiwiYWRkcmVzcyIsInVuYmxvY2siLCJhdmFpbGFibGUiLCJyZXNwb25zZSIsIkpTT04iLCJwYXJzZSIsImNvbnRlbnQiLCJyZXN1bHQiLCJhY2NvdW50IiwidHlwZSIsInZhbHVlIiwiQmFzZVZlc3RpbmdBY2NvdW50IiwiQmFzZUFjY291bnQiLCJhY2NvdW50X251bWJlciIsImJhbGFuY2UiLCJsZW5ndGgiLCJkZWxlZ2F0aW9ucyIsInVuYm9uZGluZyIsInJld2FyZHMiLCJ0b3RhbCIsInZhbGlkYXRvciIsImZpbmRPbmUiLCIkb3IiLCJvcGVyYXRvcl9hZGRyZXNzIiwiZGVsZWdhdG9yX2FkZHJlc3MiLCJ2YWxfY29tbWlzc2lvbiIsImNvbW1pc3Npb24iLCJkYXRhIiwic2hhcmVzIiwicGFyc2VGbG9hdCIsInJlbGVnYXRpb25zIiwiY29tcGxldGlvblRpbWUiLCJmb3JFYWNoIiwicmVsZWdhdGlvbiIsImVudHJpZXMiLCJ0aW1lIiwiRGF0ZSIsImNvbXBsZXRpb25fdGltZSIsInJlZGVsZWdhdGlvbkNvbXBsZXRpb25UaW1lIiwidW5kZWxlZ2F0aW9ucyIsInVuYm9uZGluZ0NvbXBsZXRpb25UaW1lIiwiZGVsZWdhdGlvbiIsImkiLCJ1bmJvbmRpbmdzIiwicmVkZWxlZ2F0aW9ucyIsInJlZGVsZWdhdGlvbiIsInZhbGlkYXRvcl9kc3RfYWRkcmVzcyIsImNvdW50IiwiUHJvbWlzZSIsIkJsb2Nrc2NvbiIsIkNoYWluIiwiVmFsaWRhdG9yU2V0cyIsIlZhbGlkYXRvclJlY29yZHMiLCJBbmFseXRpY3MiLCJWUERpc3RyaWJ1dGlvbnMiLCJWb3RpbmdQb3dlckhpc3RvcnkiLCJUcmFuc2FjdGlvbnMiLCJFdmlkZW5jZXMiLCJzaGEyNTYiLCJnZXRBZGRyZXNzIiwiY2hlZXJpbyIsImdldFJlbW92ZWRWYWxpZGF0b3JzIiwicHJldlZhbGlkYXRvcnMiLCJ2YWxpZGF0b3JzIiwicCIsInNwbGljZSIsImdldFZhbGlkYXRvclByb2ZpbGVVcmwiLCJpZGVudGl0eSIsInRoZW0iLCJwaWN0dXJlcyIsInByaW1hcnkiLCJzdHJpbmdpZnkiLCJpbmRleE9mIiwidGVhbVBhZ2UiLCJwYWdlIiwibG9hZCIsImF0dHIiLCJibG9ja3MiLCJmaW5kIiwicHJvcG9zZXJBZGRyZXNzIiwiZmV0Y2giLCJoZWlnaHRzIiwibWFwIiwiYmxvY2siLCJoZWlnaHQiLCJibG9ja3NTdGF0cyIsIiRpbiIsInRvdGFsQmxvY2tEaWZmIiwiYiIsInRpbWVEaWZmIiwiY29sbGVjdGlvbiIsInJhd0NvbGxlY3Rpb24iLCJwaXBlbGluZSIsIiRtYXRjaCIsIiRzb3J0IiwiJGxpbWl0Iiwic2V0dGluZ3MiLCJwdWJsaWMiLCJ1cHRpbWVXaW5kb3ciLCIkdW53aW5kIiwiJGdyb3VwIiwiJGNvbmQiLCIkZXEiLCJhd2FpdCIsImFnZ3JlZ2F0ZSIsInRvQXJyYXkiLCJSUEMiLCJzdGF0dXMiLCJzeW5jX2luZm8iLCJsYXRlc3RfYmxvY2tfaGVpZ2h0IiwiY3VyckhlaWdodCIsInNvcnQiLCJsaW1pdCIsInN0YXJ0SGVpZ2h0IiwicGFyYW1zIiwiU1lOQ0lORyIsInVudGlsIiwiY2FsbCIsImN1cnIiLCJ2YWxpZGF0b3JTZXQiLCJjb25zZW5zdXNfcHVia2V5IiwidG90YWxWYWxpZGF0b3JzIiwiT2JqZWN0Iiwia2V5cyIsInN0YXJ0QmxvY2tUaW1lIiwiYW5hbHl0aWNzRGF0YSIsImJ1bGtWYWxpZGF0b3JzIiwiaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCIsImJ1bGtWYWxpZGF0b3JSZWNvcmRzIiwiYnVsa1ZQSGlzdG9yeSIsImJ1bGtUcmFuc2F0aW9ucyIsInN0YXJ0R2V0SGVpZ2h0VGltZSIsImJsb2NrRGF0YSIsImhhc2giLCJibG9ja19pZCIsInRyYW5zTnVtIiwiaGVhZGVyIiwibGFzdEJsb2NrSGFzaCIsImxhc3RfYmxvY2tfaWQiLCJwcm9wb3Nlcl9hZGRyZXNzIiwicHJlY29tbWl0cyIsImxhc3RfY29tbWl0IiwicHVzaCIsInZhbGlkYXRvcl9hZGRyZXNzIiwidHhzIiwidCIsIkJ1ZmZlciIsImZyb20iLCJlcnIiLCJldmlkZW5jZSIsImluc2VydCIsInByZWNvbW1pdHNDb3VudCIsImVuZEdldEhlaWdodFRpbWUiLCJzdGFydEdldFZhbGlkYXRvcnNUaW1lIiwiYmxvY2tfaGVpZ2h0IiwicGFyc2VJbnQiLCJ2YWxpZGF0b3JzQ291bnQiLCJzdGFydEJsb2NrSW5zZXJ0VGltZSIsImVuZEJsb2NrSW5zZXJ0VGltZSIsImV4aXN0aW5nVmFsaWRhdG9ycyIsIiRleGlzdHMiLCJyZWNvcmQiLCJleGlzdHMiLCJ2b3RpbmdfcG93ZXIiLCJqIiwibnVtQmxvY2tzIiwidXB0aW1lIiwiYmFzZSIsInVwc2VydCIsInVwZGF0ZU9uZSIsIiRzZXQiLCJsYXN0U2VlbiIsImNoYWluU3RhdHVzIiwiY2hhaW5JZCIsImNoYWluX2lkIiwibGFzdFN5bmNlZFRpbWUiLCJibG9ja1RpbWUiLCJkZWZhdWx0QmxvY2tUaW1lIiwiZGF0ZUxhdGVzdCIsImRhdGVMYXN0IiwiTWF0aCIsImFicyIsImdldFRpbWUiLCJlbmRHZXRWYWxpZGF0b3JzVGltZSIsInVwZGF0ZSIsImF2ZXJhZ2VCbG9ja1RpbWUiLCJzdGFydEZpbmRWYWxpZGF0b3JzTmFtZVRpbWUiLCJwcm9wb3Nlcl9wcmlvcml0eSIsInZhbEV4aXN0IiwicHViX2tleSIsImFjY3B1YiIsImJlY2gzMlByZWZpeEFjY1B1YiIsIm9wZXJhdG9yX3B1YmtleSIsImJlY2gzMlByZWZpeFZhbFB1YiIsImJlY2gzMlByZWZpeENvbnNQdWIiLCJ2YWxpZGF0b3JEYXRhIiwiZGVzY3JpcHRpb24iLCJwcm9maWxlX3VybCIsImphaWxlZCIsIm1pbl9zZWxmX2RlbGVnYXRpb24iLCJ0b2tlbnMiLCJkZWxlZ2F0b3Jfc2hhcmVzIiwiYm9uZF9oZWlnaHQiLCJib25kX2ludHJhX3R4X2NvdW50ZXIiLCJ1bmJvbmRpbmdfaGVpZ2h0IiwidW5ib25kaW5nX3RpbWUiLCJzZWxmX2RlbGVnYXRpb24iLCJwcmV2X3ZvdGluZ19wb3dlciIsImJsb2NrX3RpbWUiLCJzZWxmRGVsZWdhdGlvbiIsInByZXZWb3RpbmdQb3dlciIsImNoYW5nZVR5cGUiLCJjaGFuZ2VEYXRhIiwicmVtb3ZlZFZhbGlkYXRvcnMiLCJyIiwiZGJWYWxpZGF0b3JzIiwiZmllbGRzIiwiY29uUHViS2V5IiwidW5kZWZpbmVkIiwicHJvZmlsZVVybCIsImVuZEZpbmRWYWxpZGF0b3JzTmFtZVRpbWUiLCJzdGFydEFuYXl0aWNzSW5zZXJ0VGltZSIsImVuZEFuYWx5dGljc0luc2VydFRpbWUiLCJzdGFydFZVcFRpbWUiLCJleGVjdXRlIiwiZW5kVlVwVGltZSIsInN0YXJ0VlJUaW1lIiwiZW5kVlJUaW1lIiwiYWN0aXZlVmFsaWRhdG9ycyIsIm51bVRvcFR3ZW50eSIsImNlaWwiLCJudW1Cb3R0b21FaWdodHkiLCJ0b3BUd2VudHlQb3dlciIsImJvdHRvbUVpZ2h0eVBvd2VyIiwibnVtVG9wVGhpcnR5Rm91ciIsIm51bUJvdHRvbVNpeHR5U2l4IiwidG9wVGhpcnR5Rm91clBlcmNlbnQiLCJib3R0b21TaXh0eVNpeFBlcmNlbnQiLCJ2cERpc3QiLCJudW1WYWxpZGF0b3JzIiwidG90YWxWb3RpbmdQb3dlciIsImNyZWF0ZUF0IiwiZW5kQmxvY2tUaW1lIiwibGFzdEJsb2Nrc1N5bmNlZFRpbWUiLCJwdWJsaXNoQ29tcG9zaXRlIiwiY2hpbGRyZW4iLCJleHBvcnQiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJoZWxwZXJzIiwicHJvcG9zZXIiLCJDaGFpblN0YXRlcyIsImZpbmRWb3RpbmdQb3dlciIsImdlblZhbGlkYXRvcnMiLCJwb3dlciIsImNvbnNlbnN1cyIsInJvdW5kX3N0YXRlIiwicm91bmQiLCJzdGVwIiwidm90ZWRQb3dlciIsInZvdGVzIiwicHJldm90ZXNfYml0X2FycmF5Iiwic3BsaXQiLCJ2b3RpbmdIZWlnaHQiLCJ2b3RpbmdSb3VuZCIsInZvdGluZ1N0ZXAiLCJwcmV2b3RlcyIsImNoYWluIiwibm9kZV9pbmZvIiwibmV0d29yayIsImxhdGVzdEJsb2NrSGVpZ2h0IiwibGF0ZXN0QmxvY2tUaW1lIiwibGF0ZXN0X2Jsb2NrX3RpbWUiLCJsYXRlc3RTdGF0ZSIsImFjdGl2ZVZQIiwiYWN0aXZlVm90aW5nUG93ZXIiLCJjaGFpblN0YXRlcyIsImJvbmRpbmciLCJib25kZWRUb2tlbnMiLCJib25kZWRfdG9rZW5zIiwibm90Qm9uZGVkVG9rZW5zIiwibm90X2JvbmRlZF90b2tlbnMiLCJtaW50aW5nRGVub20iLCJzdXBwbHkiLCJ0b3RhbFN1cHBseSIsInBvb2wiLCJjb21tdW5pdHlQb29sIiwiYW1vdW50IiwiZGVub20iLCJpbmZsYXRpb24iLCJwcm92aXNpb25zIiwiYW5udWFsUHJvdmlzaW9ucyIsImNyZWF0ZWQiLCJyZWFkR2VuZXNpcyIsImRlYnVnIiwiZ2VuZXNpc0ZpbGUiLCJnZW5lc2lzIiwiZGlzdHIiLCJhcHBfc3RhdGUiLCJkaXN0cmlidXRpb24iLCJjaGFpblBhcmFtcyIsImdlbmVzaXNUaW1lIiwiZ2VuZXNpc190aW1lIiwiY29uc2Vuc3VzUGFyYW1zIiwiY29uc2Vuc3VzX3BhcmFtcyIsImF1dGgiLCJiYW5rIiwic3Rha2luZyIsIm1pbnQiLCJjb21tdW5pdHlUYXgiLCJjb21tdW5pdHlfdGF4IiwiYmFzZVByb3Bvc2VyUmV3YXJkIiwiYmFzZV9wcm9wb3Nlcl9yZXdhcmQiLCJib251c1Byb3Bvc2VyUmV3YXJkIiwiYm9udXNfcHJvcG9zZXJfcmV3YXJkIiwid2l0aGRyYXdBZGRyRW5hYmxlZCIsIndpdGhkcmF3X2FkZHJfZW5hYmxlZCIsImdvdiIsInNsYXNoaW5nIiwiY3Jpc2lzIiwiZ2VudXRpbCIsImdlbnR4cyIsIm1zZyIsIm0iLCJwdWJrZXkiLCJmbG9vciIsInN0YWtpbmdGcmFjdGlvbiIsInB1YmtleVZhbHVlIiwiZ2VuVmFsaWRhdG9yc1NldCIsIkNvaW5TdGF0cyIsInB1Ymxpc2giLCJsYXN0X3VwZGF0ZWRfYXQiLCJjb2luSWQiLCJjb2luZ2Vja29JZCIsIm5vdyIsInNldE1pbnV0ZXMiLCJEZWxlZ2F0aW9ucyIsImNvbmNhdCIsImNyZWF0ZWRBdCIsIkVudGVycHJpc2UiLCJwdXJjaGFzZU9yZGVycyIsImZpbmlzaGVkUHVyY2hhc2VPcmRlcnMiLCJTZXQiLCJwb0lkIiwicG9JZHMiLCJidWxrUG9zIiwicG8iLCJpZCIsImhhcyIsImNoZWNrIiwiTnVtYmVyIiwiX29iamVjdFNwcmVhZCIsImRlZmF1bHQiLCJ0eEluZm8iLCJ0aW1lc3RhbXAiLCJwb3N0IiwiY29kZSIsIkVycm9yIiwicmF3X2xvZyIsIm1lc3NhZ2UiLCJ0eGhhc2giLCJib2R5IiwicGF0aCIsInR4TXNnIiwiYWRqdXN0bWVudCIsImdhc19lc3RpbWF0ZSIsIkF2ZXJhZ2VEYXRhIiwiQXZlcmFnZVZhbGlkYXRvckRhdGEiLCJTdGF0dXMiLCJNaXNzZWRCbG9ja3NTdGF0cyIsIk1pc3NlZEJsb2NrcyIsIl8iLCJCVUxLVVBEQVRFTUFYU0laRSIsImdldEJsb2NrU3RhdHMiLCJsYXRlc3RIZWlnaHQiLCJibG9ja1N0YXRzIiwiY29uZCIsIiRhbmQiLCIkZ3QiLCIkbHRlIiwib3B0aW9ucyIsImFzc2lnbiIsImdldFByZXZpb3VzUmVjb3JkIiwidm90ZXJBZGRyZXNzIiwicHJldmlvdXNSZWNvcmQiLCJ2b3RlciIsImJsb2NrSGVpZ2h0IiwibGFzdFVwZGF0ZWRIZWlnaHQiLCJwcmV2U3RhdHMiLCJwaWNrIiwibWlzc0NvdW50IiwidG90YWxDb3VudCIsIkNPVU5UTUlTU0VEQkxPQ0tTIiwic3RhcnRUaW1lIiwiZXhwbG9yZXJTdGF0dXMiLCJsYXN0UHJvY2Vzc2VkTWlzc2VkQmxvY2tIZWlnaHQiLCJtaW4iLCJidWxrTWlzc2VkU3RhdHMiLCJpbml0aWFsaXplT3JkZXJlZEJ1bGtPcCIsInZhbGlkYXRvcnNNYXAiLCJwcm9wb3NlclZvdGVyU3RhdHMiLCJ2b3RlZFZhbGlkYXRvcnMiLCJ2YWxpZGF0b3JTZXRzIiwidm90ZWRWb3RpbmdQb3dlciIsImFjdGl2ZVZhbGlkYXRvciIsImN1cnJlbnRWYWxpZGF0b3IiLCJzZXQiLCJuIiwidm90aW5nUG93ZXIiLCJ1cGRhdGVkQXQiLCJ2b3RlcnMiLCJzdGF0cyIsImNsaWVudCIsIl9kcml2ZXIiLCJtb25nbyIsImJ1bGtQcm9taXNlIiwidGhlbiIsImJpbmRFbnZpcm9ubWVudCIsIm5JbnNlcnRlZCIsIm5VcHNlcnRlZCIsIm5Nb2RpZmllZCIsImxhc3RQcm9jZXNzZWRNaXNzZWRCbG9ja1RpbWUiLCJDT1VOVE1JU1NFREJMT0NLU1NUQVRTIiwibGFzdE1pc3NlZEJsb2NrSGVpZ2h0IiwibWlzc2VkUmVjb3JkcyIsImNvdW50cyIsImV4aXN0aW5nUmVjb3JkIiwibGFzdE1pc3NlZEJsb2NrVGltZSIsImF2ZXJhZ2VWb3RpbmdQb3dlciIsImFuYWx5dGljcyIsImxhc3RNaW51dGVWb3RpbmdQb3dlciIsImxhc3RNaW51dGVCbG9ja1RpbWUiLCJsYXN0SG91clZvdGluZ1Bvd2VyIiwibGFzdEhvdXJCbG9ja1RpbWUiLCJsYXN0RGF5Vm90aW5nUG93ZXIiLCJsYXN0RGF5QmxvY2tUaW1lIiwiYmxvY2tIZWlnaHRzIiwiYSIsIm51bSIsImNvbmRpdGlvbnMiLCJwcm9wb3Nlck1vbmlrZXIiLCJtb25pa2VyIiwidm90ZXJNb25pa2VyIiwiQWRkcmVzc0xlbmd0aCIsInRvVXBwZXJDYXNlIiwidHgiLCJ0eElkIiwiJGx0IiwiaW5jbHVkZXMiLCJiZWNoMzJQcmVmaXhWYWxBZGRyIiwiYmVjaDMyUHJlZml4QWNjQWRkciIsInZhbGlkYXRvckFkZHJlc3MiLCJkZWxlZ2F0b3JBZGRyZXNzIiwicXVlcnkiLCJUeEljb24iLCJkaXJlY3Rpb24iLCJ2YWwiLCJmaXJzdFNlZW4iLCJoaXN0b3J5IiwiY3JlYXRlSW5kZXgiLCJ1bmlxdWUiLCJwYXJ0aWFsRmlsdGVyRXhwcmVzc2lvbiIsIm9uUGFnZUxvYWQiLCJIZWxtZXQiLCJzaW5rIiwiaGVsbWV0IiwicmVuZGVyU3RhdGljIiwiYXBwZW5kVG9IZWFkIiwibWV0YSIsInRvU3RyaW5nIiwidGl0bGUiLCJiZWNoMzIiLCJGdXR1cmUiLCJOcG0iLCJyZXF1aXJlIiwiZXhlYyIsInRvSGV4U3RyaW5nIiwiYnl0ZUFycmF5IiwiYnl0ZSIsInNsaWNlIiwiam9pbiIsInB1YmtleVRvQmVjaDMyIiwicHJlZml4IiwicHVia2V5QW1pbm9QcmVmaXgiLCJidWZmZXIiLCJhbGxvYyIsImNvcHkiLCJlbmNvZGUiLCJ0b1dvcmRzIiwiYmVjaDMyVG9QdWJrZXkiLCJmcm9tV29yZHMiLCJkZWNvZGUiLCJ3b3JkcyIsImdldERlbGVnYXRvciIsIm9wZXJhdG9yQWRkciIsImdldEtleWJhc2VUZWFtUGljIiwia2V5YmFzZVVybCIsIkRlbm9tU3ltYm9sIiwiUHJvcG9zYWxTdGF0dXNJY29uIiwiVm90ZUljb24iLCJJbmZvSWNvbiIsIlJlYWN0IiwiVW5jb250cm9sbGVkVG9vbHRpcCIsInByb3BzIiwidm90ZSIsInZhbGlkIiwiQ29tcG9uZW50IiwiY29uc3RydWN0b3IiLCJyZWYiLCJjcmVhdGVSZWYiLCJyZW5kZXIiLCJ0b29sdGlwVGV4dCIsIkNvaW4iLCJudW1icm8iLCJhdXRvZm9ybWF0IiwiZm9ybWF0dGVyIiwiZm9ybWF0IiwidG9Mb3dlckNhc2UiLCJNaW50aW5nRGVub20iLCJfYW1vdW50IiwiU3Rha2luZ0Rlbm9tIiwiU3Rha2luZ0ZyYWN0aW9uIiwic3Rha2luZ0Ftb3VudCIsInByZWNpc2lvbiIsIm1pblN0YWtlIiwicG93IiwicmVwZWF0IiwibWludFN0cmluZyIsInN0YWtlU3RyaW5nIiwic3Rha2luZ0Rlbm9tIiwiU3Rha2luZ0Rlbm9tUGx1cmFsIiwic3Rha2luZ0Rlbm9tUGx1cmFsIiwiTWluU3Rha2UiLCJyZW1vdGUiLCJycGMiLCJsY2QiLCJ0aW1lckJsb2NrcyIsInRpbWVyQ2hhaW4iLCJ0aW1lckNvbnNlbnN1cyIsInRpbWVyUHJvcG9zYWwiLCJ0aW1lclByb3Bvc2Fsc1Jlc3VsdHMiLCJ0aW1lck1pc3NlZEJsb2NrIiwidGltZXJEZWxlZ2F0aW9uIiwidGltZXJBZ2dyZWdhdGUiLCJERUZBVUxUU0VUVElOR1MiLCJ1cGRhdGVDaGFpblN0YXR1cyIsImVycm9yIiwidXBkYXRlQmxvY2siLCJnZXRDb25zZW5zdXNTdGF0ZSIsImdldFB1cmNoYXNlT3JkZXJzIiwidXBkYXRlTWlzc2VkQmxvY2tzIiwiZ2V0RGVsZWdhdGlvbnMiLCJhZ2dyZWdhdGVNaW51dGVseSIsImFnZ3JlZ2F0ZUhvdXJseSIsImFnZ3JlZ2F0ZURhaWx5Iiwic3RhcnR1cCIsImlzRGV2ZWxvcG1lbnQiLCJERUZBVUxUU0VUVElOR1NKU09OIiwicHJvY2VzcyIsImVudiIsIk5PREVfVExTX1JFSkVDVF9VTkFVVEhPUklaRUQiLCJrZXkiLCJ3YXJuIiwicGFyYW0iLCJzdGFydFRpbWVyIiwic2V0SW50ZXJ2YWwiLCJjb25zZW5zdXNJbnRlcnZhbCIsImJsb2NrSW50ZXJ2YWwiLCJzdGF0dXNJbnRlcnZhbCIsInRpbWVyUHVyY2hhc2VPcmRlciIsInByb3Bvc2FsSW50ZXJ2YWwiLCJtaXNzZWRCbG9ja3NJbnRlcnZhbCIsImRlbGVnYXRpb25JbnRlcnZhbCIsImdldFVUQ1NlY29uZHMiLCJnZXRVVENNaW51dGVzIiwiZ2V0VVRDSG91cnMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksdUNBQVosRUFBb0Q7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQXBELEVBQWtGLENBQWxGOztBQUd2SSxNQUFNRyxZQUFZLEdBQUlDLEdBQUQsSUFBUztBQUMxQixNQUFHO0FBQ0MsUUFBSUMsR0FBRyxHQUFHSixJQUFJLENBQUNLLEdBQUwsQ0FBU0MsR0FBRyxHQUFHSCxHQUFmLENBQVY7O0FBQ0EsUUFBSUMsR0FBRyxDQUFDRyxVQUFKLElBQWtCLEdBQXRCLEVBQTBCO0FBQ3RCLGFBQU9ILEdBQVA7QUFDSDs7QUFBQTtBQUNKLEdBTEQsQ0FNQSxPQUFPSSxDQUFQLEVBQVM7QUFDTEMsV0FBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLENBVkQ7O0FBWUFaLE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsK0JBQTZCLFVBQVNDLE9BQVQsRUFBaUI7QUFDMUMsU0FBS0MsT0FBTDtBQUNBLFFBQUlWLEdBQUcsR0FBR0csR0FBRyxHQUFHLGlCQUFOLEdBQXlCTSxPQUFuQzs7QUFDQSxRQUFHO0FBQ0MsVUFBSUUsU0FBUyxHQUFHZCxJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFoQjs7QUFDQSxVQUFJVyxTQUFTLENBQUNQLFVBQVYsSUFBd0IsR0FBNUIsRUFBZ0M7QUFDNUIsWUFBSVEsUUFBUSxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0gsU0FBUyxDQUFDSSxPQUFyQixFQUE4QkMsTUFBN0M7QUFDQSxZQUFJQyxPQUFKO0FBQ0EsWUFBSUwsUUFBUSxDQUFDTSxJQUFULEtBQWtCLG9CQUF0QixFQUNJRCxPQUFPLEdBQUdMLFFBQVEsQ0FBQ08sS0FBbkIsQ0FESixLQUVLLElBQUlQLFFBQVEsQ0FBQ00sSUFBVCxLQUFrQixrQ0FBbEIsSUFBd0ROLFFBQVEsQ0FBQ00sSUFBVCxLQUFrQixxQ0FBOUUsRUFDREQsT0FBTyxHQUFHTCxRQUFRLENBQUNPLEtBQVQsQ0FBZUMsa0JBQWYsQ0FBa0NDLFdBQTVDO0FBQ0osWUFBSUosT0FBTyxJQUFJQSxPQUFPLENBQUNLLGNBQVIsSUFBMEIsSUFBekMsRUFDSSxPQUFPTCxPQUFQO0FBQ0osZUFBTyxJQUFQO0FBQ0g7QUFDSixLQWJELENBY0EsT0FBT1osQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixHQXJCVTtBQXNCWCx5QkFBdUIsVUFBU0ksT0FBVCxFQUFpQjtBQUNwQyxTQUFLQyxPQUFMO0FBQ0EsUUFBSWEsT0FBTyxHQUFHLEVBQWQsQ0FGb0MsQ0FJcEM7O0FBQ0EsUUFBSXZCLEdBQUcsR0FBR0csR0FBRyxHQUFHLGlCQUFOLEdBQXlCTSxPQUFuQzs7QUFDQSxRQUFHO0FBQ0MsVUFBSUUsU0FBUyxHQUFHZCxJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFoQjs7QUFDQSxVQUFJVyxTQUFTLENBQUNQLFVBQVYsSUFBd0IsR0FBNUIsRUFBZ0M7QUFDNUI7QUFDQW1CLGVBQU8sQ0FBQ1osU0FBUixHQUFvQkUsSUFBSSxDQUFDQyxLQUFMLENBQVdILFNBQVMsQ0FBQ0ksT0FBckIsRUFBOEJDLE1BQWxEO0FBQ0EsWUFBSU8sT0FBTyxDQUFDWixTQUFSLElBQXFCWSxPQUFPLENBQUNaLFNBQVIsQ0FBa0JhLE1BQWxCLEdBQTJCLENBQXBELEVBQ0lELE9BQU8sQ0FBQ1osU0FBUixHQUFvQlksT0FBTyxDQUFDWixTQUFSLENBQWtCLENBQWxCLENBQXBCO0FBQ1A7QUFDSixLQVJELENBU0EsT0FBT04sQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0gsS0FqQm1DLENBbUJwQzs7O0FBQ0FMLE9BQUcsR0FBR0csR0FBRyxHQUFHLHNCQUFOLEdBQTZCTSxPQUE3QixHQUFxQyxjQUEzQzs7QUFDQSxRQUFHO0FBQ0MsVUFBSWdCLFdBQVcsR0FBRzVCLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWxCOztBQUNBLFVBQUl5QixXQUFXLENBQUNyQixVQUFaLElBQTBCLEdBQTlCLEVBQWtDO0FBQzlCbUIsZUFBTyxDQUFDRSxXQUFSLEdBQXNCWixJQUFJLENBQUNDLEtBQUwsQ0FBV1csV0FBVyxDQUFDVixPQUF2QixFQUFnQ0MsTUFBdEQ7QUFDSDtBQUNKLEtBTEQsQ0FNQSxPQUFPWCxDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxLQTdCbUMsQ0E4QnBDOzs7QUFDQUwsT0FBRyxHQUFHRyxHQUFHLEdBQUcsc0JBQU4sR0FBNkJNLE9BQTdCLEdBQXFDLHdCQUEzQzs7QUFDQSxRQUFHO0FBQ0MsVUFBSWlCLFNBQVMsR0FBRzdCLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWhCOztBQUNBLFVBQUkwQixTQUFTLENBQUN0QixVQUFWLElBQXdCLEdBQTVCLEVBQWdDO0FBQzVCbUIsZUFBTyxDQUFDRyxTQUFSLEdBQW9CYixJQUFJLENBQUNDLEtBQUwsQ0FBV1ksU0FBUyxDQUFDWCxPQUFyQixFQUE4QkMsTUFBbEQ7QUFDSDtBQUNKLEtBTEQsQ0FNQSxPQUFPWCxDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxLQXhDbUMsQ0EwQ3BDOzs7QUFDQUwsT0FBRyxHQUFHRyxHQUFHLEdBQUcsMkJBQU4sR0FBa0NNLE9BQWxDLEdBQTBDLFVBQWhEOztBQUNBLFFBQUc7QUFDQyxVQUFJa0IsT0FBTyxHQUFHOUIsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZDs7QUFDQSxVQUFJMkIsT0FBTyxDQUFDdkIsVUFBUixJQUFzQixHQUExQixFQUE4QjtBQUMxQm1CLGVBQU8sQ0FBQ0ksT0FBUixHQUFrQmQsSUFBSSxDQUFDQyxLQUFMLENBQVdhLE9BQU8sQ0FBQ1osT0FBbkIsRUFBNEJDLE1BQTVCLENBQW1DWSxLQUFyRDtBQUNIO0FBQ0osS0FMRCxDQU1BLE9BQU92QixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxLQXBEbUMsQ0FzRHBDOzs7QUFDQSxRQUFJd0IsU0FBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUNaO0FBQUNDLFNBQUcsRUFBRSxDQUFDO0FBQUNDLHdCQUFnQixFQUFDdkI7QUFBbEIsT0FBRCxFQUE2QjtBQUFDd0IseUJBQWlCLEVBQUN4QjtBQUFuQixPQUE3QixFQUEwRDtBQUFDQSxlQUFPLEVBQUNBO0FBQVQsT0FBMUQ7QUFBTixLQURZLENBQWhCOztBQUVBLFFBQUlvQixTQUFKLEVBQWU7QUFDWCxVQUFJN0IsR0FBRyxHQUFHRyxHQUFHLEdBQUcsMkJBQU4sR0FBb0MwQixTQUFTLENBQUNHLGdCQUF4RDtBQUNBVCxhQUFPLENBQUNTLGdCQUFSLEdBQTJCSCxTQUFTLENBQUNHLGdCQUFyQzs7QUFDQSxVQUFJO0FBQ0EsWUFBSUwsT0FBTyxHQUFHOUIsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZDs7QUFDQSxZQUFJMkIsT0FBTyxDQUFDdkIsVUFBUixJQUFzQixHQUExQixFQUE4QjtBQUMxQixjQUFJVyxPQUFPLEdBQUdGLElBQUksQ0FBQ0MsS0FBTCxDQUFXYSxPQUFPLENBQUNaLE9BQW5CLEVBQTRCQyxNQUExQztBQUNBLGNBQUlELE9BQU8sQ0FBQ21CLGNBQVIsSUFBMEJuQixPQUFPLENBQUNtQixjQUFSLENBQXVCVixNQUF2QixHQUFnQyxDQUE5RCxFQUNJRCxPQUFPLENBQUNZLFVBQVIsR0FBcUJwQixPQUFPLENBQUNtQixjQUFSLENBQXVCLENBQXZCLENBQXJCO0FBQ1A7QUFFSixPQVJELENBU0EsT0FBTzdCLENBQVAsRUFBUztBQUNMQyxlQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0o7O0FBRUQsV0FBT2tCLE9BQVA7QUFDSCxHQWpHVTs7QUFrR1gsMkJBQXlCZCxPQUF6QixFQUFrQ29CLFNBQWxDLEVBQTRDO0FBQ3hDLFFBQUk3QixHQUFHLGlDQUEwQlMsT0FBMUIsMEJBQWlEb0IsU0FBakQsQ0FBUDtBQUNBLFFBQUlKLFdBQVcsR0FBRzFCLFlBQVksQ0FBQ0MsR0FBRCxDQUE5QjtBQUNBeUIsZUFBVyxHQUFHQSxXQUFXLElBQUlBLFdBQVcsQ0FBQ1csSUFBWixDQUFpQnBCLE1BQTlDO0FBQ0EsUUFBSVMsV0FBVyxJQUFJQSxXQUFXLENBQUNZLE1BQS9CLEVBQ0laLFdBQVcsQ0FBQ1ksTUFBWixHQUFxQkMsVUFBVSxDQUFDYixXQUFXLENBQUNZLE1BQWIsQ0FBL0I7QUFFSnJDLE9BQUcsOENBQXVDUyxPQUF2QywyQkFBK0RvQixTQUEvRCxDQUFIO0FBQ0EsUUFBSVUsV0FBVyxHQUFHeEMsWUFBWSxDQUFDQyxHQUFELENBQTlCO0FBQ0F1QyxlQUFXLEdBQUdBLFdBQVcsSUFBSUEsV0FBVyxDQUFDSCxJQUFaLENBQWlCcEIsTUFBOUM7QUFDQSxRQUFJd0IsY0FBSjs7QUFDQSxRQUFJRCxXQUFKLEVBQWlCO0FBQ2JBLGlCQUFXLENBQUNFLE9BQVosQ0FBcUJDLFVBQUQsSUFBZ0I7QUFDaEMsWUFBSUMsT0FBTyxHQUFHRCxVQUFVLENBQUNDLE9BQXpCO0FBQ0EsWUFBSUMsSUFBSSxHQUFHLElBQUlDLElBQUosQ0FBU0YsT0FBTyxDQUFDQSxPQUFPLENBQUNuQixNQUFSLEdBQWUsQ0FBaEIsQ0FBUCxDQUEwQnNCLGVBQW5DLENBQVg7QUFDQSxZQUFJLENBQUNOLGNBQUQsSUFBbUJJLElBQUksR0FBR0osY0FBOUIsRUFDSUEsY0FBYyxHQUFHSSxJQUFqQjtBQUNQLE9BTEQ7QUFNQW5CLGlCQUFXLENBQUNzQiwwQkFBWixHQUF5Q1AsY0FBekM7QUFDSDs7QUFFRHhDLE9BQUcsaUNBQTBCUyxPQUExQixvQ0FBMkRvQixTQUEzRCxDQUFIO0FBQ0EsUUFBSW1CLGFBQWEsR0FBR2pELFlBQVksQ0FBQ0MsR0FBRCxDQUFoQztBQUNBZ0QsaUJBQWEsR0FBR0EsYUFBYSxJQUFJQSxhQUFhLENBQUNaLElBQWQsQ0FBbUJwQixNQUFwRDs7QUFDQSxRQUFJZ0MsYUFBSixFQUFtQjtBQUNmdkIsaUJBQVcsQ0FBQ0MsU0FBWixHQUF3QnNCLGFBQWEsQ0FBQ0wsT0FBZCxDQUFzQm5CLE1BQTlDO0FBQ0FDLGlCQUFXLENBQUN3Qix1QkFBWixHQUFzQ0QsYUFBYSxDQUFDTCxPQUFkLENBQXNCLENBQXRCLEVBQXlCRyxlQUEvRDtBQUNIOztBQUNELFdBQU9yQixXQUFQO0FBQ0gsR0EvSFU7O0FBZ0lYLCtCQUE2QmhCLE9BQTdCLEVBQXFDO0FBQ2pDLFFBQUlULEdBQUcsR0FBR0csR0FBRyxHQUFHLHNCQUFOLEdBQTZCTSxPQUE3QixHQUFxQyxjQUEvQzs7QUFFQSxRQUFHO0FBQ0MsVUFBSWdCLFdBQVcsR0FBRzVCLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWxCOztBQUNBLFVBQUl5QixXQUFXLENBQUNyQixVQUFaLElBQTBCLEdBQTlCLEVBQWtDO0FBQzlCcUIsbUJBQVcsR0FBR1osSUFBSSxDQUFDQyxLQUFMLENBQVdXLFdBQVcsQ0FBQ1YsT0FBdkIsRUFBZ0NDLE1BQTlDOztBQUNBLFlBQUlTLFdBQVcsSUFBSUEsV0FBVyxDQUFDRCxNQUFaLEdBQXFCLENBQXhDLEVBQTBDO0FBQ3RDQyxxQkFBVyxDQUFDZ0IsT0FBWixDQUFvQixDQUFDUyxVQUFELEVBQWFDLENBQWIsS0FBbUI7QUFDbkMsZ0JBQUkxQixXQUFXLENBQUMwQixDQUFELENBQVgsSUFBa0IxQixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBckMsRUFDSVosV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLENBQWVkLE1BQWYsR0FBd0JDLFVBQVUsQ0FBQ2IsV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLENBQWVkLE1BQWhCLENBQWxDO0FBQ1AsV0FIRDtBQUlIOztBQUVELGVBQU9aLFdBQVA7QUFDSDs7QUFBQTtBQUNKLEtBYkQsQ0FjQSxPQUFPcEIsQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixHQXBKVTs7QUFxSlgsOEJBQTRCSSxPQUE1QixFQUFvQztBQUNoQyxRQUFJVCxHQUFHLEdBQUdHLEdBQUcsR0FBRyxzQkFBTixHQUE2Qk0sT0FBN0IsR0FBcUMsd0JBQS9DOztBQUVBLFFBQUc7QUFDQyxVQUFJMkMsVUFBVSxHQUFHdkQsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBakI7O0FBQ0EsVUFBSW9ELFVBQVUsQ0FBQ2hELFVBQVgsSUFBeUIsR0FBN0IsRUFBaUM7QUFDN0JnRCxrQkFBVSxHQUFHdkMsSUFBSSxDQUFDQyxLQUFMLENBQVdzQyxVQUFVLENBQUNyQyxPQUF0QixFQUErQkMsTUFBNUM7QUFDQSxlQUFPb0MsVUFBUDtBQUNIOztBQUFBO0FBQ0osS0FORCxDQU9BLE9BQU8vQyxDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLEdBbEtVOztBQW1LWCxpQ0FBK0JJLE9BQS9CLEVBQXdDb0IsU0FBeEMsRUFBa0Q7QUFDOUMsUUFBSTdCLEdBQUcsOENBQXVDUyxPQUF2Qyw2QkFBaUVvQixTQUFqRSxDQUFQO0FBQ0EsUUFBSWIsTUFBTSxHQUFHakIsWUFBWSxDQUFDQyxHQUFELENBQXpCOztBQUNBLFFBQUlnQixNQUFNLElBQUlBLE1BQU0sQ0FBQ29CLElBQXJCLEVBQTJCO0FBQ3ZCLFVBQUlpQixhQUFhLEdBQUcsRUFBcEI7QUFDQXJDLFlBQU0sQ0FBQ29CLElBQVAsQ0FBWUssT0FBWixDQUFxQmEsWUFBRCxJQUFrQjtBQUNsQyxZQUFJWCxPQUFPLEdBQUdXLFlBQVksQ0FBQ1gsT0FBM0I7QUFDQVUscUJBQWEsQ0FBQ0MsWUFBWSxDQUFDQyxxQkFBZCxDQUFiLEdBQW9EO0FBQ2hEQyxlQUFLLEVBQUViLE9BQU8sQ0FBQ25CLE1BRGlDO0FBRWhEZ0Isd0JBQWMsRUFBRUcsT0FBTyxDQUFDLENBQUQsQ0FBUCxDQUFXRztBQUZxQixTQUFwRDtBQUlILE9BTkQ7QUFPQSxhQUFPTyxhQUFQO0FBQ0g7QUFDSjs7QUFqTFUsQ0FBZixFOzs7Ozs7Ozs7OztBQ2ZBLElBQUk1RCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSTZELE9BQUo7QUFBWS9ELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUM4RCxTQUFPLENBQUM3RCxDQUFELEVBQUc7QUFBQzZELFdBQU8sR0FBQzdELENBQVI7QUFBVTs7QUFBdEIsQ0FBN0IsRUFBcUQsQ0FBckQ7QUFBd0QsSUFBSThELFNBQUo7QUFBY2hFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtCQUFaLEVBQTRDO0FBQUMrRCxXQUFTLENBQUM5RCxDQUFELEVBQUc7QUFBQzhELGFBQVMsR0FBQzlELENBQVY7QUFBWTs7QUFBMUIsQ0FBNUMsRUFBd0UsQ0FBeEU7QUFBMkUsSUFBSStELEtBQUo7QUFBVWpFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUNnRSxPQUFLLENBQUMvRCxDQUFELEVBQUc7QUFBQytELFNBQUssR0FBQy9ELENBQU47QUFBUTs7QUFBbEIsQ0FBMUMsRUFBOEQsQ0FBOUQ7QUFBaUUsSUFBSWdFLGFBQUo7QUFBa0JsRSxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQ0FBWixFQUE0RDtBQUFDaUUsZUFBYSxDQUFDaEUsQ0FBRCxFQUFHO0FBQUNnRSxpQkFBYSxHQUFDaEUsQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBNUQsRUFBZ0csQ0FBaEc7QUFBbUcsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSx1Q0FBWixFQUFvRDtBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBcEQsRUFBa0YsQ0FBbEY7QUFBcUYsSUFBSWlFLGdCQUFKLEVBQXFCQyxTQUFyQixFQUErQkMsZUFBL0I7QUFBK0NyRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxpQ0FBWixFQUE4QztBQUFDa0Usa0JBQWdCLENBQUNqRSxDQUFELEVBQUc7QUFBQ2lFLG9CQUFnQixHQUFDakUsQ0FBakI7QUFBbUIsR0FBeEM7O0FBQXlDa0UsV0FBUyxDQUFDbEUsQ0FBRCxFQUFHO0FBQUNrRSxhQUFTLEdBQUNsRSxDQUFWO0FBQVksR0FBbEU7O0FBQW1FbUUsaUJBQWUsQ0FBQ25FLENBQUQsRUFBRztBQUFDbUUsbUJBQWUsR0FBQ25FLENBQWhCO0FBQWtCOztBQUF4RyxDQUE5QyxFQUF3SixDQUF4SjtBQUEySixJQUFJb0Usa0JBQUo7QUFBdUJ0RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQ0FBWixFQUFtRDtBQUFDcUUsb0JBQWtCLENBQUNwRSxDQUFELEVBQUc7QUFBQ29FLHNCQUFrQixHQUFDcEUsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQW5ELEVBQWlHLENBQWpHO0FBQW9HLElBQUlxRSxZQUFKO0FBQWlCdkUsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ3NFLGNBQVksQ0FBQ3JFLENBQUQsRUFBRztBQUFDcUUsZ0JBQVksR0FBQ3JFLENBQWI7QUFBZTs7QUFBaEMsQ0FBakQsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSXNFLFNBQUo7QUFBY3hFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDhCQUFaLEVBQTJDO0FBQUN1RSxXQUFTLENBQUN0RSxDQUFELEVBQUc7QUFBQ3NFLGFBQVMsR0FBQ3RFLENBQVY7QUFBWTs7QUFBMUIsQ0FBM0MsRUFBdUUsRUFBdkU7QUFBMkUsSUFBSXVFLE1BQUo7QUFBV3pFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQ3dFLFFBQU0sQ0FBQ3ZFLENBQUQsRUFBRztBQUFDdUUsVUFBTSxHQUFDdkUsQ0FBUDtBQUFTOztBQUFwQixDQUF4QixFQUE4QyxFQUE5QztBQUFrRCxJQUFJd0UsVUFBSjtBQUFlMUUsTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQ3lFLFlBQVUsQ0FBQ3hFLENBQUQsRUFBRztBQUFDd0UsY0FBVSxHQUFDeEUsQ0FBWDtBQUFhOztBQUE1QixDQUFwQyxFQUFrRSxFQUFsRTtBQUFzRSxJQUFJeUUsT0FBSjtBQUFZM0UsTUFBTSxDQUFDQyxJQUFQLENBQVksU0FBWixFQUFzQjtBQUFDLE1BQUlDLENBQUosRUFBTTtBQUFDeUUsV0FBTyxHQUFDekUsQ0FBUjtBQUFVOztBQUFsQixDQUF0QixFQUEwQyxFQUExQzs7QUFlNXRDO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTBFLG9CQUFvQixHQUFHLENBQUNDLGNBQUQsRUFBaUJDLFVBQWpCLEtBQWdDO0FBQ25EO0FBQ0EsT0FBS0MsQ0FBTCxJQUFVRixjQUFWLEVBQXlCO0FBQ3JCLFNBQUszRSxDQUFMLElBQVU0RSxVQUFWLEVBQXFCO0FBQ2pCLFVBQUlELGNBQWMsQ0FBQ0UsQ0FBRCxDQUFkLENBQWtCaEUsT0FBbEIsSUFBNkIrRCxVQUFVLENBQUM1RSxDQUFELENBQVYsQ0FBY2EsT0FBL0MsRUFBdUQ7QUFDbkQ4RCxzQkFBYyxDQUFDRyxNQUFmLENBQXNCRCxDQUF0QixFQUF3QixDQUF4QjtBQUNIO0FBQ0o7QUFDSjs7QUFFRCxTQUFPRixjQUFQO0FBQ0gsQ0FYRDs7QUFhQUksc0JBQXNCLEdBQUlDLFFBQUQsSUFBYztBQUNuQyxNQUFJQSxRQUFRLENBQUNwRCxNQUFULElBQW1CLEVBQXZCLEVBQTBCO0FBQ3RCLFFBQUlaLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLG9FQUFxRTBFLFFBQXJFLHNCQUFmOztBQUNBLFFBQUloRSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBZ0M7QUFDNUIsVUFBSXlFLElBQUksR0FBR2pFLFFBQVEsQ0FBQ3dCLElBQVQsQ0FBY3lDLElBQXpCO0FBQ0EsYUFBT0EsSUFBSSxJQUFJQSxJQUFJLENBQUNyRCxNQUFiLElBQXVCcUQsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRQyxRQUEvQixJQUEyQ0QsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRQyxRQUFSLENBQWlCQyxPQUE1RCxJQUF1RUYsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRQyxRQUFSLENBQWlCQyxPQUFqQixDQUF5Qi9FLEdBQXZHO0FBQ0gsS0FIRCxNQUdPO0FBQ0hNLGFBQU8sQ0FBQ0MsR0FBUixDQUFZTSxJQUFJLENBQUNtRSxTQUFMLENBQWVwRSxRQUFmLENBQVo7QUFDSDtBQUNKLEdBUkQsTUFRTyxJQUFJZ0UsUUFBUSxDQUFDSyxPQUFULENBQWlCLGtCQUFqQixJQUFxQyxDQUF6QyxFQUEyQztBQUM5QyxRQUFJQyxRQUFRLEdBQUdyRixJQUFJLENBQUNLLEdBQUwsQ0FBUzBFLFFBQVQsQ0FBZjs7QUFDQSxRQUFJTSxRQUFRLENBQUM5RSxVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCLFVBQUkrRSxJQUFJLEdBQUdkLE9BQU8sQ0FBQ2UsSUFBUixDQUFhRixRQUFRLENBQUNuRSxPQUF0QixDQUFYO0FBQ0EsYUFBT29FLElBQUksQ0FBQyxtQkFBRCxDQUFKLENBQTBCRSxJQUExQixDQUErQixLQUEvQixDQUFQO0FBQ0gsS0FIRCxNQUdPO0FBQ0gvRSxhQUFPLENBQUNDLEdBQVIsQ0FBWU0sSUFBSSxDQUFDbUUsU0FBTCxDQUFlRSxRQUFmLENBQVo7QUFDSDtBQUNKO0FBQ0osQ0FsQkQsQyxDQW9CQTtBQUNBOzs7QUFFQXpGLE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsNEJBQTBCQyxPQUExQixFQUFrQztBQUM5QixRQUFJNkUsTUFBTSxHQUFHNUIsU0FBUyxDQUFDNkIsSUFBVixDQUFlO0FBQUNDLHFCQUFlLEVBQUMvRTtBQUFqQixLQUFmLEVBQTBDZ0YsS0FBMUMsRUFBYjtBQUNBLFFBQUlDLE9BQU8sR0FBR0osTUFBTSxDQUFDSyxHQUFQLENBQVcsQ0FBQ0MsS0FBRCxFQUFRekMsQ0FBUixLQUFjO0FBQ25DLGFBQU95QyxLQUFLLENBQUNDLE1BQWI7QUFDSCxLQUZhLENBQWQ7QUFHQSxRQUFJQyxXQUFXLEdBQUdoQyxTQUFTLENBQUN5QixJQUFWLENBQWU7QUFBQ00sWUFBTSxFQUFDO0FBQUNFLFdBQUcsRUFBQ0w7QUFBTDtBQUFSLEtBQWYsRUFBdUNELEtBQXZDLEVBQWxCLENBTDhCLENBTTlCOztBQUVBLFFBQUlPLGNBQWMsR0FBRyxDQUFyQjs7QUFDQSxTQUFLQyxDQUFMLElBQVVILFdBQVYsRUFBc0I7QUFDbEJFLG9CQUFjLElBQUlGLFdBQVcsQ0FBQ0csQ0FBRCxDQUFYLENBQWVDLFFBQWpDO0FBQ0g7O0FBQ0QsV0FBT0YsY0FBYyxHQUFDTixPQUFPLENBQUNsRSxNQUE5QjtBQUNILEdBZFU7O0FBZVgsc0JBQW9CZixPQUFwQixFQUE0QjtBQUN4QixRQUFJMEYsVUFBVSxHQUFHdEMsZ0JBQWdCLENBQUN1QyxhQUFqQixFQUFqQixDQUR3QixDQUV4Qjs7QUFDQSxRQUFJQyxRQUFRLEdBQUcsQ0FDWDtBQUFDQyxZQUFNLEVBQUM7QUFBQyxtQkFBVTdGO0FBQVg7QUFBUixLQURXLEVBRVg7QUFDQTtBQUFDOEYsV0FBSyxFQUFDO0FBQUMsa0JBQVMsQ0FBQztBQUFYO0FBQVAsS0FIVyxFQUlYO0FBQUNDLFlBQU0sRUFBRS9HLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCQyxZQUF2QixHQUFvQztBQUE3QyxLQUpXLEVBS1g7QUFBQ0MsYUFBTyxFQUFFO0FBQVYsS0FMVyxFQU1YO0FBQUNDLFlBQU0sRUFBQztBQUNKLGVBQU8sVUFESDtBQUVKLGtCQUFVO0FBQ04sa0JBQU87QUFDSEMsaUJBQUssRUFBRSxDQUFDO0FBQUNDLGlCQUFHLEVBQUUsQ0FBQyxTQUFELEVBQVksSUFBWjtBQUFOLGFBQUQsRUFBMkIsQ0FBM0IsRUFBOEIsQ0FBOUI7QUFESjtBQUREO0FBRk47QUFBUixLQU5XLENBQWYsQ0FId0IsQ0FrQnhCOztBQUVBLFdBQU90RCxPQUFPLENBQUN1RCxLQUFSLENBQWNiLFVBQVUsQ0FBQ2MsU0FBWCxDQUFxQlosUUFBckIsRUFBK0JhLE9BQS9CLEVBQWQsQ0FBUCxDQXBCd0IsQ0FxQnhCO0FBQ0gsR0FyQ1U7O0FBc0NYLDRCQUEwQixZQUFXO0FBQ2pDLFNBQUt4RyxPQUFMO0FBQ0EsUUFBSVYsR0FBRyxHQUFHbUgsR0FBRyxHQUFDLFNBQWQ7O0FBQ0EsUUFBRztBQUNDLFVBQUl2RyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxVQUFJb0gsTUFBTSxHQUFHdkcsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBYjtBQUNBLGFBQVFxRyxNQUFNLENBQUNwRyxNQUFQLENBQWNxRyxTQUFkLENBQXdCQyxtQkFBaEM7QUFDSCxLQUpELENBS0EsT0FBT2pILENBQVAsRUFBUztBQUNMLGFBQU8sQ0FBUDtBQUNIO0FBQ0osR0FqRFU7QUFrRFgsNkJBQTJCLFlBQVc7QUFDbEMsU0FBS0ssT0FBTDtBQUNBLFFBQUk2RyxVQUFVLEdBQUc3RCxTQUFTLENBQUM2QixJQUFWLENBQWUsRUFBZixFQUFrQjtBQUFDaUMsVUFBSSxFQUFDO0FBQUMzQixjQUFNLEVBQUMsQ0FBQztBQUFULE9BQU47QUFBa0I0QixXQUFLLEVBQUM7QUFBeEIsS0FBbEIsRUFBOENoQyxLQUE5QyxFQUFqQixDQUZrQyxDQUdsQzs7QUFDQSxRQUFJaUMsV0FBVyxHQUFHakksTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCRCxXQUF6Qzs7QUFDQSxRQUFJSCxVQUFVLElBQUlBLFVBQVUsQ0FBQy9GLE1BQVgsSUFBcUIsQ0FBdkMsRUFBMEM7QUFDdEMsVUFBSXFFLE1BQU0sR0FBRzBCLFVBQVUsQ0FBQyxDQUFELENBQVYsQ0FBYzFCLE1BQTNCO0FBQ0EsVUFBSUEsTUFBTSxHQUFHNkIsV0FBYixFQUNJLE9BQU83QixNQUFQO0FBQ1A7O0FBQ0QsV0FBTzZCLFdBQVA7QUFDSCxHQTdEVTtBQThEWCx5QkFBdUIsWUFBVztBQUM5QixRQUFJRSxPQUFKLEVBQ0ksT0FBTyxZQUFQLENBREosS0FFS3RILE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQVosRUFIeUIsQ0FJOUI7QUFDQTs7QUFDQSxRQUFJc0gsS0FBSyxHQUFHcEksTUFBTSxDQUFDcUksSUFBUCxDQUFZLHdCQUFaLENBQVosQ0FOOEIsQ0FPOUI7QUFDQTs7QUFDQSxRQUFJQyxJQUFJLEdBQUd0SSxNQUFNLENBQUNxSSxJQUFQLENBQVkseUJBQVosQ0FBWDtBQUNBeEgsV0FBTyxDQUFDQyxHQUFSLENBQVl3SCxJQUFaLEVBVjhCLENBVzlCOztBQUNBLFFBQUlGLEtBQUssR0FBR0UsSUFBWixFQUFrQjtBQUNkSCxhQUFPLEdBQUcsSUFBVjtBQUVBLFVBQUlJLFlBQVksR0FBRyxFQUFuQixDQUhjLENBSWQ7O0FBQ0FoSSxTQUFHLEdBQUdHLEdBQUcsR0FBQyxxQkFBVjs7QUFFQSxVQUFHO0FBQ0NTLGdCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQWEsWUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTdCLENBQW9DeUIsT0FBcEMsQ0FBNkNaLFNBQUQsSUFBZW1HLFlBQVksQ0FBQ25HLFNBQVMsQ0FBQ29HLGdCQUFYLENBQVosR0FBMkNwRyxTQUF0RztBQUNILE9BSEQsQ0FJQSxPQUFNeEIsQ0FBTixFQUFRO0FBQ0pDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBRURMLFNBQUcsR0FBR0csR0FBRyxHQUFDLHNDQUFWOztBQUVBLFVBQUc7QUFDQ1MsZ0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBYSxZQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBN0IsQ0FBb0N5QixPQUFwQyxDQUE2Q1osU0FBRCxJQUFlbUcsWUFBWSxDQUFDbkcsU0FBUyxDQUFDb0csZ0JBQVgsQ0FBWixHQUEyQ3BHLFNBQXRHO0FBQ0gsT0FIRCxDQUlBLE9BQU14QixDQUFOLEVBQVE7QUFDSkMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFFREwsU0FBRyxHQUFHRyxHQUFHLEdBQUMscUNBQVY7O0FBRUEsVUFBRztBQUNDUyxnQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0FhLFlBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE3QixDQUFvQ3lCLE9BQXBDLENBQTZDWixTQUFELElBQWVtRyxZQUFZLENBQUNuRyxTQUFTLENBQUNvRyxnQkFBWCxDQUFaLEdBQTJDcEcsU0FBdEc7QUFDSCxPQUhELENBSUEsT0FBTXhCLENBQU4sRUFBUTtBQUNKQyxlQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUNELFVBQUk2SCxlQUFlLEdBQUdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZSixZQUFaLEVBQTBCeEcsTUFBaEQ7QUFDQWxCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHFCQUFvQjJILGVBQWhDOztBQUNBLFdBQUssSUFBSXJDLE1BQU0sR0FBR2tDLElBQUksR0FBQyxDQUF2QixFQUEyQmxDLE1BQU0sSUFBSWdDLEtBQXJDLEVBQTZDaEMsTUFBTSxFQUFuRCxFQUF1RDtBQUNuRCxZQUFJd0MsY0FBYyxHQUFHLElBQUl4RixJQUFKLEVBQXJCLENBRG1ELENBRW5EOztBQUNBLGFBQUtuQyxPQUFMO0FBQ0EsWUFBSVYsR0FBRyxHQUFHbUgsR0FBRyxHQUFDLGdCQUFKLEdBQXVCdEIsTUFBakM7QUFDQSxZQUFJeUMsYUFBYSxHQUFHLEVBQXBCO0FBRUFoSSxlQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjs7QUFDQSxZQUFHO0FBQ0MsZ0JBQU11SSxjQUFjLEdBQUd6SSxVQUFVLENBQUNzRyxhQUFYLEdBQTJCb0MseUJBQTNCLEVBQXZCO0FBQ0EsZ0JBQU1DLG9CQUFvQixHQUFHNUUsZ0JBQWdCLENBQUN1QyxhQUFqQixHQUFpQ29DLHlCQUFqQyxFQUE3QjtBQUNBLGdCQUFNRSxhQUFhLEdBQUcxRSxrQkFBa0IsQ0FBQ29DLGFBQW5CLEdBQW1Db0MseUJBQW5DLEVBQXRCO0FBQ0EsZ0JBQU1HLGVBQWUsR0FBRzFFLFlBQVksQ0FBQ21DLGFBQWIsR0FBNkJvQyx5QkFBN0IsRUFBeEI7QUFFQSxjQUFJSSxrQkFBa0IsR0FBRyxJQUFJL0YsSUFBSixFQUF6QjtBQUNBLGNBQUlqQyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7O0FBQ0EsY0FBSVksUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCLGdCQUFJd0YsS0FBSyxHQUFHL0UsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBWjtBQUNBNkUsaUJBQUssR0FBR0EsS0FBSyxDQUFDNUUsTUFBZCxDQUYyQixDQUczQjs7QUFDQSxnQkFBSTZILFNBQVMsR0FBRyxFQUFoQjtBQUNBQSxxQkFBUyxDQUFDaEQsTUFBVixHQUFtQkEsTUFBbkI7QUFDQWdELHFCQUFTLENBQUNDLElBQVYsR0FBaUJsRCxLQUFLLENBQUNtRCxRQUFOLENBQWVELElBQWhDO0FBQ0FELHFCQUFTLENBQUNHLFFBQVYsR0FBcUJwRCxLQUFLLENBQUNBLEtBQU4sQ0FBWXhELElBQVosQ0FBaUJaLE1BQXRDO0FBQ0FxSCxxQkFBUyxDQUFDakcsSUFBVixHQUFpQixJQUFJQyxJQUFKLENBQVMrQyxLQUFLLENBQUNBLEtBQU4sQ0FBWXFELE1BQVosQ0FBbUJyRyxJQUE1QixDQUFqQjtBQUNBaUcscUJBQVMsQ0FBQ0ssYUFBVixHQUEwQnRELEtBQUssQ0FBQ0EsS0FBTixDQUFZcUQsTUFBWixDQUFtQkUsYUFBbkIsQ0FBaUNMLElBQTNEO0FBQ0FELHFCQUFTLENBQUNyRCxlQUFWLEdBQTRCSSxLQUFLLENBQUNBLEtBQU4sQ0FBWXFELE1BQVosQ0FBbUJHLGdCQUEvQztBQUNBUCxxQkFBUyxDQUFDckUsVUFBVixHQUF1QixFQUF2QjtBQUNBLGdCQUFJNkUsVUFBVSxHQUFHekQsS0FBSyxDQUFDQSxLQUFOLENBQVkwRCxXQUFaLENBQXdCRCxVQUF6Qzs7QUFDQSxnQkFBSUEsVUFBVSxJQUFJLElBQWxCLEVBQXVCO0FBQ25CO0FBQ0EsbUJBQUssSUFBSWxHLENBQUMsR0FBQyxDQUFYLEVBQWNBLENBQUMsR0FBQ2tHLFVBQVUsQ0FBQzdILE1BQTNCLEVBQW1DMkIsQ0FBQyxFQUFwQyxFQUF1QztBQUNuQyxvQkFBSWtHLFVBQVUsQ0FBQ2xHLENBQUQsQ0FBVixJQUFpQixJQUFyQixFQUEwQjtBQUN0QjBGLDJCQUFTLENBQUNyRSxVQUFWLENBQXFCK0UsSUFBckIsQ0FBMEJGLFVBQVUsQ0FBQ2xHLENBQUQsQ0FBVixDQUFjcUcsaUJBQXhDO0FBQ0g7QUFDSjs7QUFFRGxCLDJCQUFhLENBQUNlLFVBQWQsR0FBMkJBLFVBQVUsQ0FBQzdILE1BQXRDLENBUm1CLENBU25CO0FBQ0E7QUFDSCxhQXhCMEIsQ0EwQjNCOzs7QUFDQSxnQkFBSW9FLEtBQUssQ0FBQ0EsS0FBTixDQUFZeEQsSUFBWixDQUFpQnFILEdBQWpCLElBQXdCN0QsS0FBSyxDQUFDQSxLQUFOLENBQVl4RCxJQUFaLENBQWlCcUgsR0FBakIsQ0FBcUJqSSxNQUFyQixHQUE4QixDQUExRCxFQUE0RDtBQUN4RCxtQkFBS2tJLENBQUwsSUFBVTlELEtBQUssQ0FBQ0EsS0FBTixDQUFZeEQsSUFBWixDQUFpQnFILEdBQTNCLEVBQStCO0FBQzNCaEssc0JBQU0sQ0FBQ3FJLElBQVAsQ0FBWSxvQkFBWixFQUFrQzNELE1BQU0sQ0FBQ3dGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZaEUsS0FBSyxDQUFDQSxLQUFOLENBQVl4RCxJQUFaLENBQWlCcUgsR0FBakIsQ0FBcUJDLENBQXJCLENBQVosRUFBcUMsUUFBckMsQ0FBRCxDQUF4QyxFQUEwRmIsU0FBUyxDQUFDakcsSUFBcEcsRUFBMEcsQ0FBQ2lILEdBQUQsRUFBTTdJLE1BQU4sS0FBaUI7QUFDdkgsc0JBQUk2SSxHQUFKLEVBQVE7QUFDSnZKLDJCQUFPLENBQUNDLEdBQVIsQ0FBWXNKLEdBQVo7QUFDSDtBQUNKLGlCQUpEO0FBS0g7QUFDSixhQW5DMEIsQ0FxQzNCOzs7QUFDQSxnQkFBSWpFLEtBQUssQ0FBQ0EsS0FBTixDQUFZa0UsUUFBWixDQUFxQkEsUUFBekIsRUFBa0M7QUFDOUI1Rix1QkFBUyxDQUFDNkYsTUFBVixDQUFpQjtBQUNibEUsc0JBQU0sRUFBRUEsTUFESztBQUViaUUsd0JBQVEsRUFBRWxFLEtBQUssQ0FBQ0EsS0FBTixDQUFZa0UsUUFBWixDQUFxQkE7QUFGbEIsZUFBakI7QUFJSDs7QUFFRGpCLHFCQUFTLENBQUNtQixlQUFWLEdBQTRCbkIsU0FBUyxDQUFDckUsVUFBVixDQUFxQmhELE1BQWpEO0FBRUE4Ryx5QkFBYSxDQUFDekMsTUFBZCxHQUF1QkEsTUFBdkI7QUFFQSxnQkFBSW9FLGdCQUFnQixHQUFHLElBQUlwSCxJQUFKLEVBQXZCO0FBQ0F2QyxtQkFBTyxDQUFDQyxHQUFSLENBQVksc0JBQXFCLENBQUMwSixnQkFBZ0IsR0FBQ3JCLGtCQUFsQixJQUFzQyxJQUEzRCxHQUFpRSxVQUE3RTtBQUdBLGdCQUFJc0Isc0JBQXNCLEdBQUcsSUFBSXJILElBQUosRUFBN0IsQ0FyRDJCLENBc0QzQjs7QUFDQTdDLGVBQUcsR0FBR21ILEdBQUcsR0FBQyxxQkFBSixHQUEwQnRCLE1BQWhDO0FBQ0FqRixvQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0FNLG1CQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjtBQUNBLGdCQUFJd0UsVUFBVSxHQUFHM0QsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBakI7QUFDQXlELHNCQUFVLENBQUN4RCxNQUFYLENBQWtCbUosWUFBbEIsR0FBaUNDLFFBQVEsQ0FBQzVGLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0JtSixZQUFuQixDQUF6QztBQUNBdkcseUJBQWEsQ0FBQ21HLE1BQWQsQ0FBcUJ2RixVQUFVLENBQUN4RCxNQUFoQztBQUVBNkgscUJBQVMsQ0FBQ3dCLGVBQVYsR0FBNEI3RixVQUFVLENBQUN4RCxNQUFYLENBQWtCd0QsVUFBbEIsQ0FBNkJoRCxNQUF6RDtBQUNBLGdCQUFJOEksb0JBQW9CLEdBQUcsSUFBSXpILElBQUosRUFBM0I7QUFDQWEscUJBQVMsQ0FBQ3FHLE1BQVYsQ0FBaUJsQixTQUFqQjtBQUNBLGdCQUFJMEIsa0JBQWtCLEdBQUcsSUFBSTFILElBQUosRUFBekI7QUFDQXZDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBdUIsQ0FBQ2dLLGtCQUFrQixHQUFDRCxvQkFBcEIsSUFBMEMsSUFBakUsR0FBdUUsVUFBbkYsRUFsRTJCLENBb0UzQjs7QUFDQSxnQkFBSUUsa0JBQWtCLEdBQUcxSyxVQUFVLENBQUN5RixJQUFYLENBQWdCO0FBQUM5RSxxQkFBTyxFQUFDO0FBQUNnSyx1QkFBTyxFQUFDO0FBQVQ7QUFBVCxhQUFoQixFQUEwQ2hGLEtBQTFDLEVBQXpCOztBQUVBLGdCQUFJSSxNQUFNLEdBQUcsQ0FBYixFQUFlO0FBQ1g7QUFDQTtBQUNBLG1CQUFLMUMsQ0FBTCxJQUFVcUIsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQTVCLEVBQXVDO0FBQ25DLG9CQUFJL0QsT0FBTyxHQUFHK0QsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQWxCLENBQTZCckIsQ0FBN0IsRUFBZ0MxQyxPQUE5QztBQUNBLG9CQUFJaUssTUFBTSxHQUFHO0FBQ1Q3RSx3QkFBTSxFQUFFQSxNQURDO0FBRVRwRix5QkFBTyxFQUFFQSxPQUZBO0FBR1RrSyx3QkFBTSxFQUFFLEtBSEM7QUFJVEMsOEJBQVksRUFBRVIsUUFBUSxDQUFDNUYsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQWxCLENBQTZCckIsQ0FBN0IsRUFBZ0N5SCxZQUFqQyxDQUpiLENBSTJEOztBQUozRCxpQkFBYjs7QUFPQSxxQkFBS0MsQ0FBTCxJQUFVeEIsVUFBVixFQUFxQjtBQUNqQixzQkFBSUEsVUFBVSxDQUFDd0IsQ0FBRCxDQUFWLElBQWlCLElBQXJCLEVBQTBCO0FBQ3RCLHdCQUFJcEssT0FBTyxJQUFJNEksVUFBVSxDQUFDd0IsQ0FBRCxDQUFWLENBQWNyQixpQkFBN0IsRUFBK0M7QUFDM0NrQiw0QkFBTSxDQUFDQyxNQUFQLEdBQWdCLElBQWhCO0FBQ0F0QixnQ0FBVSxDQUFDM0UsTUFBWCxDQUFrQm1HLENBQWxCLEVBQW9CLENBQXBCO0FBQ0E7QUFDSDtBQUNKO0FBQ0osaUJBakJrQyxDQW1CbkM7QUFDQTs7O0FBRUEsb0JBQUtoRixNQUFNLEdBQUcsRUFBVixJQUFpQixDQUFyQixFQUF1QjtBQUNuQjtBQUNBLHNCQUFJaUYsU0FBUyxHQUFHckwsTUFBTSxDQUFDcUksSUFBUCxDQUFZLG1CQUFaLEVBQWlDckgsT0FBakMsQ0FBaEI7QUFDQSxzQkFBSXNLLE1BQU0sR0FBRyxDQUFiLENBSG1CLENBSW5CO0FBQ0E7O0FBQ0Esc0JBQUtELFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsSUFBakIsSUFBMkJBLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYUMsTUFBYixJQUF1QixJQUF0RCxFQUE0RDtBQUN4REEsMEJBQU0sR0FBR0QsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhQyxNQUF0QjtBQUNIOztBQUVELHNCQUFJQyxJQUFJLEdBQUd2TCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QkMsWUFBbEM7O0FBQ0Esc0JBQUlkLE1BQU0sR0FBR21GLElBQWIsRUFBa0I7QUFDZEEsd0JBQUksR0FBR25GLE1BQVA7QUFDSDs7QUFFRCxzQkFBSTZFLE1BQU0sQ0FBQ0MsTUFBWCxFQUFrQjtBQUNkLHdCQUFJSSxNQUFNLEdBQUdDLElBQWIsRUFBa0I7QUFDZEQsNEJBQU07QUFDVDs7QUFDREEsMEJBQU0sR0FBSUEsTUFBTSxHQUFHQyxJQUFWLEdBQWdCLEdBQXpCO0FBQ0F6QyxrQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDOUUsNkJBQU8sRUFBQ0E7QUFBVCxxQkFBcEIsRUFBdUN3SyxNQUF2QyxHQUFnREMsU0FBaEQsQ0FBMEQ7QUFBQ0MsMEJBQUksRUFBQztBQUFDSiw4QkFBTSxFQUFDQSxNQUFSO0FBQWdCSyxnQ0FBUSxFQUFDdkMsU0FBUyxDQUFDakc7QUFBbkM7QUFBTixxQkFBMUQ7QUFDSCxtQkFORCxNQU9JO0FBQ0FtSSwwQkFBTSxHQUFJQSxNQUFNLEdBQUdDLElBQVYsR0FBZ0IsR0FBekI7QUFDQXpDLGtDQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUM5RSw2QkFBTyxFQUFDQTtBQUFULHFCQUFwQixFQUF1Q3dLLE1BQXZDLEdBQWdEQyxTQUFoRCxDQUEwRDtBQUFDQywwQkFBSSxFQUFDO0FBQUNKLDhCQUFNLEVBQUNBO0FBQVI7QUFBTixxQkFBMUQ7QUFDSDtBQUNKOztBQUVEdEMsb0NBQW9CLENBQUNzQixNQUFyQixDQUE0QlcsTUFBNUIsRUFsRG1DLENBbURuQztBQUNIO0FBQ0o7O0FBRUQsZ0JBQUlXLFdBQVcsR0FBRzFILEtBQUssQ0FBQzdCLE9BQU4sQ0FBYztBQUFDd0oscUJBQU8sRUFBQzFGLEtBQUssQ0FBQ0EsS0FBTixDQUFZcUQsTUFBWixDQUFtQnNDO0FBQTVCLGFBQWQsQ0FBbEI7QUFDQSxnQkFBSUMsY0FBYyxHQUFHSCxXQUFXLEdBQUNBLFdBQVcsQ0FBQ0csY0FBYixHQUE0QixDQUE1RDtBQUNBLGdCQUFJdEYsUUFBSjtBQUNBLGdCQUFJdUYsU0FBUyxHQUFHaE0sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCK0QsZ0JBQXZDOztBQUNBLGdCQUFJRixjQUFKLEVBQW1CO0FBQ2Ysa0JBQUlHLFVBQVUsR0FBRzlDLFNBQVMsQ0FBQ2pHLElBQTNCO0FBQ0Esa0JBQUlnSixRQUFRLEdBQUcsSUFBSS9JLElBQUosQ0FBUzJJLGNBQVQsQ0FBZjtBQUNBdEYsc0JBQVEsR0FBRzJGLElBQUksQ0FBQ0MsR0FBTCxDQUFTSCxVQUFVLENBQUNJLE9BQVgsS0FBdUJILFFBQVEsQ0FBQ0csT0FBVCxFQUFoQyxDQUFYO0FBQ0FOLHVCQUFTLEdBQUcsQ0FBQ0osV0FBVyxDQUFDSSxTQUFaLElBQXlCNUMsU0FBUyxDQUFDaEQsTUFBVixHQUFtQixDQUE1QyxJQUFpREssUUFBbEQsSUFBOEQyQyxTQUFTLENBQUNoRCxNQUFwRjtBQUNIOztBQUVELGdCQUFJbUcsb0JBQW9CLEdBQUcsSUFBSW5KLElBQUosRUFBM0I7QUFDQXZDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSxpQ0FBZ0MsQ0FBQ3lMLG9CQUFvQixHQUFDOUIsc0JBQXRCLElBQThDLElBQTlFLEdBQW9GLFVBQWhHO0FBRUF2RyxpQkFBSyxDQUFDc0ksTUFBTixDQUFhO0FBQUNYLHFCQUFPLEVBQUMxRixLQUFLLENBQUNBLEtBQU4sQ0FBWXFELE1BQVosQ0FBbUJzQztBQUE1QixhQUFiLEVBQW9EO0FBQUNKLGtCQUFJLEVBQUM7QUFBQ0ssOEJBQWMsRUFBQzNDLFNBQVMsQ0FBQ2pHLElBQTFCO0FBQWdDNkkseUJBQVMsRUFBQ0E7QUFBMUM7QUFBTixhQUFwRDtBQUVBbkQseUJBQWEsQ0FBQzRELGdCQUFkLEdBQWlDVCxTQUFqQztBQUNBbkQseUJBQWEsQ0FBQ3BDLFFBQWQsR0FBeUJBLFFBQXpCO0FBRUFvQyx5QkFBYSxDQUFDMUYsSUFBZCxHQUFxQmlHLFNBQVMsQ0FBQ2pHLElBQS9CLENBcEoyQixDQXNKM0I7QUFDQTtBQUNBO0FBQ0E7O0FBRUEwRix5QkFBYSxDQUFDc0MsWUFBZCxHQUE2QixDQUE3QjtBQUVBLGdCQUFJdUIsMkJBQTJCLEdBQUcsSUFBSXRKLElBQUosRUFBbEM7O0FBQ0EsZ0JBQUkyQixVQUFVLENBQUN4RCxNQUFmLEVBQXNCO0FBQ2xCO0FBQ0FWLHFCQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBc0JpRSxVQUFVLENBQUN4RCxNQUFYLENBQWtCd0QsVUFBbEIsQ0FBNkJoRCxNQUEvRDs7QUFDQSxtQkFBSzVCLENBQUwsSUFBVTRFLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0J3RCxVQUE1QixFQUF1QztBQUNuQztBQUNBLG9CQUFJM0MsU0FBUyxHQUFHMkMsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQWxCLENBQTZCNUUsQ0FBN0IsQ0FBaEI7QUFDQWlDLHlCQUFTLENBQUMrSSxZQUFWLEdBQXlCUixRQUFRLENBQUN2SSxTQUFTLENBQUMrSSxZQUFYLENBQWpDO0FBQ0EvSSx5QkFBUyxDQUFDdUssaUJBQVYsR0FBOEJoQyxRQUFRLENBQUN2SSxTQUFTLENBQUN1SyxpQkFBWCxDQUF0QztBQUVBLG9CQUFJQyxRQUFRLEdBQUd2TSxVQUFVLENBQUNnQyxPQUFYLENBQW1CO0FBQUMsbUNBQWdCRCxTQUFTLENBQUN5SyxPQUFWLENBQWtCbkw7QUFBbkMsaUJBQW5CLENBQWY7O0FBQ0Esb0JBQUksQ0FBQ2tMLFFBQUwsRUFBYztBQUNWL0wseUJBQU8sQ0FBQ0MsR0FBUiw2QkFBaUNzQixTQUFTLENBQUNwQixPQUEzQyxjQUFzRG9CLFNBQVMsQ0FBQ3lLLE9BQVYsQ0FBa0JuTCxLQUF4RSxpQkFEVSxDQUVWO0FBQ0E7QUFDQTs7QUFFQVUsMkJBQVMsQ0FBQ3BCLE9BQVYsR0FBb0IyRCxVQUFVLENBQUN2QyxTQUFTLENBQUN5SyxPQUFYLENBQTlCO0FBQ0F6SywyQkFBUyxDQUFDMEssTUFBVixHQUFtQjlNLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmpHLFNBQVMsQ0FBQ3lLLE9BQXhDLEVBQWlEN00sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RixrQkFBeEUsQ0FBbkI7QUFDQTNLLDJCQUFTLENBQUM0SyxlQUFWLEdBQTRCaE4sTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCakcsU0FBUyxDQUFDeUssT0FBeEMsRUFBaUQ3TSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmdHLGtCQUF4RSxDQUE1QjtBQUNBN0ssMkJBQVMsQ0FBQ29HLGdCQUFWLEdBQTZCeEksTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCakcsU0FBUyxDQUFDeUssT0FBeEMsRUFBaUQ3TSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmlHLG1CQUF4RSxDQUE3QjtBQUVBLHNCQUFJQyxhQUFhLEdBQUc1RSxZQUFZLENBQUNuRyxTQUFTLENBQUNvRyxnQkFBWCxDQUFoQzs7QUFDQSxzQkFBSTJFLGFBQUosRUFBa0I7QUFDZCx3QkFBSUEsYUFBYSxDQUFDQyxXQUFkLENBQTBCakksUUFBOUIsRUFDSS9DLFNBQVMsQ0FBQ2lMLFdBQVYsR0FBeUJuSSxzQkFBc0IsQ0FBQ2lJLGFBQWEsQ0FBQ0MsV0FBZCxDQUEwQmpJLFFBQTNCLENBQS9DO0FBQ0ovQyw2QkFBUyxDQUFDRyxnQkFBVixHQUE2QjRLLGFBQWEsQ0FBQzVLLGdCQUEzQztBQUNBSCw2QkFBUyxDQUFDSSxpQkFBVixHQUE4QnhDLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxjQUFaLEVBQTRCOEUsYUFBYSxDQUFDNUssZ0JBQTFDLENBQTlCO0FBQ0FILDZCQUFTLENBQUNrTCxNQUFWLEdBQW1CSCxhQUFhLENBQUNHLE1BQWpDO0FBQ0FsTCw2QkFBUyxDQUFDdUYsTUFBVixHQUFtQndGLGFBQWEsQ0FBQ3hGLE1BQWpDO0FBQ0F2Riw2QkFBUyxDQUFDbUwsbUJBQVYsR0FBZ0NKLGFBQWEsQ0FBQ0ksbUJBQTlDO0FBQ0FuTCw2QkFBUyxDQUFDb0wsTUFBVixHQUFtQkwsYUFBYSxDQUFDSyxNQUFqQztBQUNBcEwsNkJBQVMsQ0FBQ3FMLGdCQUFWLEdBQTZCTixhQUFhLENBQUNNLGdCQUEzQztBQUNBckwsNkJBQVMsQ0FBQ2dMLFdBQVYsR0FBd0JELGFBQWEsQ0FBQ0MsV0FBdEM7QUFDQWhMLDZCQUFTLENBQUNzTCxXQUFWLEdBQXdCUCxhQUFhLENBQUNPLFdBQXRDO0FBQ0F0TCw2QkFBUyxDQUFDdUwscUJBQVYsR0FBa0NSLGFBQWEsQ0FBQ1EscUJBQWhEO0FBQ0F2TCw2QkFBUyxDQUFDd0wsZ0JBQVYsR0FBNkJULGFBQWEsQ0FBQ1MsZ0JBQTNDO0FBQ0F4TCw2QkFBUyxDQUFDeUwsY0FBVixHQUEyQlYsYUFBYSxDQUFDVSxjQUF6QztBQUNBekwsNkJBQVMsQ0FBQ00sVUFBVixHQUF1QnlLLGFBQWEsQ0FBQ3pLLFVBQXJDO0FBQ0FOLDZCQUFTLENBQUMwTCxlQUFWLEdBQTRCMUwsU0FBUyxDQUFDcUwsZ0JBQXRDLENBaEJjLENBaUJkO0FBQ0E7QUFDQTtBQUNILG1CQXBCRCxNQW9CTztBQUNINU0sMkJBQU8sQ0FBQ0MsR0FBUixDQUFZLGlCQUFaO0FBQ0gsbUJBbENTLENBb0NWOzs7QUFDQWdJLGdDQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUMwQyxvQ0FBZ0IsRUFBRXBHLFNBQVMsQ0FBQ29HO0FBQTdCLG1CQUFwQixFQUFvRWdELE1BQXBFLEdBQTZFQyxTQUE3RSxDQUF1RjtBQUFDQyx3QkFBSSxFQUFDdEo7QUFBTixtQkFBdkYsRUFyQ1UsQ0FzQ1Y7O0FBQ0E2RywrQkFBYSxDQUFDcUIsTUFBZCxDQUFxQjtBQUNqQnRKLDJCQUFPLEVBQUVvQixTQUFTLENBQUNwQixPQURGO0FBRWpCK00scUNBQWlCLEVBQUUsQ0FGRjtBQUdqQjVDLGdDQUFZLEVBQUUvSSxTQUFTLENBQUMrSSxZQUhQO0FBSWpCMUosd0JBQUksRUFBRSxLQUpXO0FBS2pCMkUsMEJBQU0sRUFBRWdELFNBQVMsQ0FBQ2hELE1BTEQ7QUFNakI0SCw4QkFBVSxFQUFFNUUsU0FBUyxDQUFDakc7QUFOTCxtQkFBckIsRUF2Q1UsQ0FnRFY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBO0FBQ0gsaUJBL0RELE1BZ0VJO0FBQ0Esc0JBQUlnSyxhQUFhLEdBQUc1RSxZQUFZLENBQUNxRSxRQUFRLENBQUNwRSxnQkFBVixDQUFoQzs7QUFDQSxzQkFBSTJFLGFBQUosRUFBa0I7QUFDZCx3QkFBSUEsYUFBYSxDQUFDQyxXQUFkLEtBQThCLENBQUNSLFFBQVEsQ0FBQ1EsV0FBVixJQUF5QkQsYUFBYSxDQUFDQyxXQUFkLENBQTBCakksUUFBMUIsS0FBdUN5SCxRQUFRLENBQUNRLFdBQVQsQ0FBcUJqSSxRQUFuSCxDQUFKLEVBQ0kvQyxTQUFTLENBQUNpTCxXQUFWLEdBQXlCbkksc0JBQXNCLENBQUNpSSxhQUFhLENBQUNDLFdBQWQsQ0FBMEJqSSxRQUEzQixDQUEvQztBQUNKL0MsNkJBQVMsQ0FBQ2tMLE1BQVYsR0FBbUJILGFBQWEsQ0FBQ0csTUFBakM7QUFDQWxMLDZCQUFTLENBQUN1RixNQUFWLEdBQW1Cd0YsYUFBYSxDQUFDeEYsTUFBakM7QUFDQXZGLDZCQUFTLENBQUNvTCxNQUFWLEdBQW1CTCxhQUFhLENBQUNLLE1BQWpDO0FBQ0FwTCw2QkFBUyxDQUFDcUwsZ0JBQVYsR0FBNkJOLGFBQWEsQ0FBQ00sZ0JBQTNDO0FBQ0FyTCw2QkFBUyxDQUFDZ0wsV0FBVixHQUF3QkQsYUFBYSxDQUFDQyxXQUF0QztBQUNBaEwsNkJBQVMsQ0FBQ3NMLFdBQVYsR0FBd0JQLGFBQWEsQ0FBQ08sV0FBdEM7QUFDQXRMLDZCQUFTLENBQUN1TCxxQkFBVixHQUFrQ1IsYUFBYSxDQUFDUSxxQkFBaEQ7QUFDQXZMLDZCQUFTLENBQUN3TCxnQkFBVixHQUE2QlQsYUFBYSxDQUFDUyxnQkFBM0M7QUFDQXhMLDZCQUFTLENBQUN5TCxjQUFWLEdBQTJCVixhQUFhLENBQUNVLGNBQXpDO0FBQ0F6TCw2QkFBUyxDQUFDTSxVQUFWLEdBQXVCeUssYUFBYSxDQUFDekssVUFBckMsQ0FaYyxDQWNkOztBQUVBLHdCQUFJMEQsTUFBTSxHQUFHLEVBQVQsSUFBZSxDQUFuQixFQUFxQjtBQUNqQiwwQkFBRztBQUNDLDRCQUFJakYsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0MsR0FBRyxHQUFHLHNCQUFOLEdBQTZCa00sUUFBUSxDQUFDcEssaUJBQXRDLEdBQXdELGVBQXhELEdBQXdFb0ssUUFBUSxDQUFDckssZ0JBQTFGLENBQWY7O0FBRUEsNEJBQUlwQixRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0IsOEJBQUlzTixjQUFjLEdBQUc3TSxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBbEQ7O0FBQ0EsOEJBQUkwTSxjQUFjLENBQUNyTCxNQUFuQixFQUEwQjtBQUN0QlIscUNBQVMsQ0FBQzBMLGVBQVYsR0FBNEJqTCxVQUFVLENBQUNvTCxjQUFjLENBQUNyTCxNQUFoQixDQUFWLEdBQWtDQyxVQUFVLENBQUNULFNBQVMsQ0FBQ3FMLGdCQUFYLENBQXhFO0FBQ0g7QUFDSjtBQUNKLHVCQVRELENBVUEsT0FBTTdNLENBQU4sRUFBUSxDQUNKO0FBQ0g7QUFDSjs7QUFFRGtJLGtDQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUMwQyxzQ0FBZ0IsRUFBRW9FLFFBQVEsQ0FBQ3BFO0FBQTVCLHFCQUFwQixFQUFtRWlELFNBQW5FLENBQTZFO0FBQUNDLDBCQUFJLEVBQUN0SjtBQUFOLHFCQUE3RSxFQWhDYyxDQWlDZDtBQUNBO0FBQ0gsbUJBbkNELE1BbUNRO0FBQ0p2QiwyQkFBTyxDQUFDQyxHQUFSLENBQVksaUJBQVo7QUFDSDs7QUFDRCxzQkFBSW9OLGVBQWUsR0FBRzNKLGtCQUFrQixDQUFDbEMsT0FBbkIsQ0FBMkI7QUFBQ3JCLDJCQUFPLEVBQUNvQixTQUFTLENBQUNwQjtBQUFuQixtQkFBM0IsRUFBd0Q7QUFBQ29GLDBCQUFNLEVBQUMsQ0FBQyxDQUFUO0FBQVk0Qix5QkFBSyxFQUFDO0FBQWxCLG1CQUF4RCxDQUF0Qjs7QUFFQSxzQkFBSWtHLGVBQUosRUFBb0I7QUFDaEIsd0JBQUlBLGVBQWUsQ0FBQy9DLFlBQWhCLElBQWdDL0ksU0FBUyxDQUFDK0ksWUFBOUMsRUFBMkQ7QUFDdkQsMEJBQUlnRCxVQUFVLEdBQUlELGVBQWUsQ0FBQy9DLFlBQWhCLEdBQStCL0ksU0FBUyxDQUFDK0ksWUFBMUMsR0FBd0QsTUFBeEQsR0FBK0QsSUFBaEY7QUFDQSwwQkFBSWlELFVBQVUsR0FBRztBQUNicE4sK0JBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCLE9BRE47QUFFYitNLHlDQUFpQixFQUFFRyxlQUFlLENBQUMvQyxZQUZ0QjtBQUdiQSxvQ0FBWSxFQUFFL0ksU0FBUyxDQUFDK0ksWUFIWDtBQUliMUosNEJBQUksRUFBRTBNLFVBSk87QUFLYi9ILDhCQUFNLEVBQUVnRCxTQUFTLENBQUNoRCxNQUxMO0FBTWI0SCxrQ0FBVSxFQUFFNUUsU0FBUyxDQUFDakc7QUFOVCx1QkFBakIsQ0FGdUQsQ0FVdkQ7QUFDQTs7QUFDQThGLG1DQUFhLENBQUNxQixNQUFkLENBQXFCOEQsVUFBckI7QUFDSDtBQUNKO0FBRUosaUJBbElrQyxDQXFJbkM7OztBQUVBdkYsNkJBQWEsQ0FBQ3NDLFlBQWQsSUFBOEIvSSxTQUFTLENBQUMrSSxZQUF4QztBQUNILGVBM0lpQixDQTZJbEI7OztBQUVBLGtCQUFJckcsY0FBYyxHQUFHWCxhQUFhLENBQUM5QixPQUFkLENBQXNCO0FBQUNxSSw0QkFBWSxFQUFDdEUsTUFBTSxHQUFDO0FBQXJCLGVBQXRCLENBQXJCOztBQUVBLGtCQUFJdEIsY0FBSixFQUFtQjtBQUNmLG9CQUFJdUosaUJBQWlCLEdBQUd4SixvQkFBb0IsQ0FBQ0MsY0FBYyxDQUFDQyxVQUFoQixFQUE0QkEsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQTlDLENBQTVDOztBQUVBLHFCQUFLdUosQ0FBTCxJQUFVRCxpQkFBVixFQUE0QjtBQUN4QnBGLCtCQUFhLENBQUNxQixNQUFkLENBQXFCO0FBQ2pCdEosMkJBQU8sRUFBRXFOLGlCQUFpQixDQUFDQyxDQUFELENBQWpCLENBQXFCdE4sT0FEYjtBQUVqQitNLHFDQUFpQixFQUFFTSxpQkFBaUIsQ0FBQ0MsQ0FBRCxDQUFqQixDQUFxQm5ELFlBRnZCO0FBR2pCQSxnQ0FBWSxFQUFFLENBSEc7QUFJakIxSix3QkFBSSxFQUFFLFFBSlc7QUFLakIyRSwwQkFBTSxFQUFFZ0QsU0FBUyxDQUFDaEQsTUFMRDtBQU1qQjRILDhCQUFVLEVBQUU1RSxTQUFTLENBQUNqRztBQU5MLG1CQUFyQjtBQVFIO0FBQ0o7QUFFSixhQTlUMEIsQ0FpVTNCOzs7QUFDQSxnQkFBSWlELE1BQU0sR0FBRyxLQUFULElBQWtCLENBQXRCLEVBQXdCO0FBQ3BCLGtCQUFJO0FBQ0F2Rix1QkFBTyxDQUFDQyxHQUFSLENBQVksdUNBQVo7QUFDQSxvQkFBSXlOLFlBQVksR0FBRyxFQUFuQjtBQUNBbE8sMEJBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0I7QUFBQzBJLHdCQUFNLEVBQUU7QUFBQ2hHLG9DQUFnQixFQUFFLENBQW5CO0FBQXNCYiwwQkFBTSxFQUFFO0FBQTlCO0FBQVQsaUJBQXBCLEVBQ00zRSxPQUROLENBQ2U3QyxDQUFELElBQU9vTyxZQUFZLENBQUNwTyxDQUFDLENBQUNxSSxnQkFBSCxDQUFaLEdBQW1DckksQ0FBQyxDQUFDd0gsTUFEMUQ7QUFFQWUsc0JBQU0sQ0FBQ0MsSUFBUCxDQUFZSixZQUFaLEVBQTBCdkYsT0FBMUIsQ0FBbUN5TCxTQUFELElBQWU7QUFDN0Msc0JBQUl0QixhQUFhLEdBQUc1RSxZQUFZLENBQUNrRyxTQUFELENBQWhDLENBRDZDLENBRTdDOztBQUNBLHNCQUFJdEIsYUFBYSxDQUFDeEYsTUFBZCxLQUF5QixDQUE3QixFQUNJOztBQUVKLHNCQUFJNEcsWUFBWSxDQUFDRSxTQUFELENBQVosSUFBMkJDLFNBQS9CLEVBQTBDO0FBQ3RDN04sMkJBQU8sQ0FBQ0MsR0FBUiwyQ0FBK0MyTixTQUEvQztBQUVBdEIsaUNBQWEsQ0FBQ04sT0FBZCxHQUF3QjtBQUNwQiw4QkFBUywwQkFEVztBQUVwQiwrQkFBUzdNLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4Qm9HLFNBQTlCO0FBRlcscUJBQXhCO0FBSUF0QixpQ0FBYSxDQUFDbk0sT0FBZCxHQUF3QjJELFVBQVUsQ0FBQ3dJLGFBQWEsQ0FBQ04sT0FBZixDQUFsQztBQUNBTSxpQ0FBYSxDQUFDM0ssaUJBQWQsR0FBa0N4QyxNQUFNLENBQUNxSSxJQUFQLENBQVksY0FBWixFQUE0QjhFLGFBQWEsQ0FBQzVLLGdCQUExQyxDQUFsQztBQUVBNEssaUNBQWEsQ0FBQ0wsTUFBZCxHQUF1QjlNLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QjhFLGFBQWEsQ0FBQ04sT0FBNUMsRUFBcUQ3TSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjhGLGtCQUE1RSxDQUF2QjtBQUNBSSxpQ0FBYSxDQUFDSCxlQUFkLEdBQWdDaE4sTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCOEUsYUFBYSxDQUFDTixPQUE1QyxFQUFxRDdNLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCZ0csa0JBQTVFLENBQWhDO0FBQ0FwTSwyQkFBTyxDQUFDQyxHQUFSLENBQVlNLElBQUksQ0FBQ21FLFNBQUwsQ0FBZTRILGFBQWYsQ0FBWjtBQUNBckUsa0NBQWMsQ0FBQ2hELElBQWYsQ0FBb0I7QUFBQzBDLHNDQUFnQixFQUFFaUc7QUFBbkIscUJBQXBCLEVBQW1EakQsTUFBbkQsR0FBNERDLFNBQTVELENBQXNFO0FBQUNDLDBCQUFJLEVBQUN5QjtBQUFOLHFCQUF0RTtBQUNILG1CQWRELE1BY08sSUFBSW9CLFlBQVksQ0FBQ0UsU0FBRCxDQUFaLElBQTJCLENBQS9CLEVBQWtDO0FBQ3JDM0Ysa0NBQWMsQ0FBQ2hELElBQWYsQ0FBb0I7QUFBQzBDLHNDQUFnQixFQUFFaUc7QUFBbkIscUJBQXBCLEVBQW1EakQsTUFBbkQsR0FBNERDLFNBQTVELENBQXNFO0FBQUNDLDBCQUFJLEVBQUN5QjtBQUFOLHFCQUF0RTtBQUNIO0FBQ0osaUJBdkJEO0FBd0JILGVBN0JELENBNkJFLE9BQU92TSxDQUFQLEVBQVM7QUFDUEMsdUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixhQW5XMEIsQ0FxVzNCOzs7QUFDQSxnQkFBSXdGLE1BQU0sR0FBRyxLQUFULElBQWtCLENBQXRCLEVBQXdCO0FBQ3BCdkYscUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHFCQUFaO0FBQ0FULHdCQUFVLENBQUN5RixJQUFYLENBQWdCLEVBQWhCLEVBQW9COUMsT0FBcEIsQ0FBNkJaLFNBQUQsSUFBZTtBQUN2QyxvQkFBSTtBQUNBLHNCQUFJdU0sVUFBVSxHQUFJekosc0JBQXNCLENBQUM5QyxTQUFTLENBQUNnTCxXQUFWLENBQXNCakksUUFBdkIsQ0FBeEM7O0FBQ0Esc0JBQUl3SixVQUFKLEVBQWdCO0FBQ1o3RixrQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDOUUsNkJBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCO0FBQXBCLHFCQUFwQixFQUNNd0ssTUFETixHQUNlQyxTQURmLENBQ3lCO0FBQUNDLDBCQUFJLEVBQUM7QUFBQyx1Q0FBY2lEO0FBQWY7QUFBTixxQkFEekI7QUFFSDtBQUNKLGlCQU5ELENBTUUsT0FBTy9OLENBQVAsRUFBVTtBQUNSQyx5QkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLGVBVkQ7QUFXSDs7QUFFRCxnQkFBSWdPLHlCQUF5QixHQUFHLElBQUl4TCxJQUFKLEVBQWhDO0FBQ0F2QyxtQkFBTyxDQUFDQyxHQUFSLENBQVksK0JBQThCLENBQUM4Tix5QkFBeUIsR0FBQ2xDLDJCQUEzQixJQUF3RCxJQUF0RixHQUE0RixVQUF4RyxFQXRYMkIsQ0F3WDNCOztBQUNBLGdCQUFJbUMsdUJBQXVCLEdBQUcsSUFBSXpMLElBQUosRUFBOUI7QUFDQWlCLHFCQUFTLENBQUNpRyxNQUFWLENBQWlCekIsYUFBakI7QUFDQSxnQkFBSWlHLHNCQUFzQixHQUFHLElBQUkxTCxJQUFKLEVBQTdCO0FBQ0F2QyxtQkFBTyxDQUFDQyxHQUFSLENBQVksNEJBQTJCLENBQUNnTyxzQkFBc0IsR0FBQ0QsdUJBQXhCLElBQWlELElBQTVFLEdBQWtGLFVBQTlGO0FBRUEsZ0JBQUlFLFlBQVksR0FBRyxJQUFJM0wsSUFBSixFQUFuQjs7QUFDQSxnQkFBSTBGLGNBQWMsQ0FBQy9HLE1BQWYsR0FBd0IsQ0FBNUIsRUFBOEI7QUFDMUI7QUFDQStHLDRCQUFjLENBQUNrRyxPQUFmLENBQXVCLENBQUM1RSxHQUFELEVBQU03SSxNQUFOLEtBQWlCO0FBQ3BDLG9CQUFJNkksR0FBSixFQUFRO0FBQ0p2Six5QkFBTyxDQUFDQyxHQUFSLENBQVlzSixHQUFaO0FBQ0g7O0FBQ0Qsb0JBQUk3SSxNQUFKLEVBQVcsQ0FDUDtBQUNIO0FBQ0osZUFQRDtBQVFIOztBQUVELGdCQUFJME4sVUFBVSxHQUFHLElBQUk3TCxJQUFKLEVBQWpCO0FBQ0F2QyxtQkFBTyxDQUFDQyxHQUFSLENBQVksNEJBQTJCLENBQUNtTyxVQUFVLEdBQUNGLFlBQVosSUFBMEIsSUFBckQsR0FBMkQsVUFBdkU7QUFFQSxnQkFBSUcsV0FBVyxHQUFHLElBQUk5TCxJQUFKLEVBQWxCOztBQUNBLGdCQUFJNEYsb0JBQW9CLENBQUNqSCxNQUFyQixHQUE4QixDQUFsQyxFQUFvQztBQUNoQ2lILGtDQUFvQixDQUFDZ0csT0FBckIsQ0FBNkIsQ0FBQzVFLEdBQUQsRUFBTTdJLE1BQU4sS0FBaUI7QUFDMUMsb0JBQUk2SSxHQUFKLEVBQVE7QUFDSnZKLHlCQUFPLENBQUNDLEdBQVIsQ0FBWXNKLEdBQVo7QUFDSDtBQUNKLGVBSkQ7QUFLSDs7QUFFRCxnQkFBSStFLFNBQVMsR0FBRyxJQUFJL0wsSUFBSixFQUFoQjtBQUNBdkMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLG9DQUFtQyxDQUFDcU8sU0FBUyxHQUFDRCxXQUFYLElBQXdCLElBQTNELEdBQWlFLFVBQTdFOztBQUVBLGdCQUFJakcsYUFBYSxDQUFDbEgsTUFBZCxHQUF1QixDQUEzQixFQUE2QjtBQUN6QmtILDJCQUFhLENBQUMrRixPQUFkLENBQXNCLENBQUM1RSxHQUFELEVBQU03SSxNQUFOLEtBQWlCO0FBQ25DLG9CQUFJNkksR0FBSixFQUFRO0FBQ0p2Six5QkFBTyxDQUFDQyxHQUFSLENBQVlzSixHQUFaO0FBQ0g7QUFDSixlQUpEO0FBS0g7O0FBRUQsZ0JBQUlsQixlQUFlLENBQUNuSCxNQUFoQixHQUF5QixDQUE3QixFQUErQjtBQUMzQm1ILDZCQUFlLENBQUM4RixPQUFoQixDQUF3QixDQUFDNUUsR0FBRCxFQUFNN0ksTUFBTixLQUFpQjtBQUNyQyxvQkFBSTZJLEdBQUosRUFBUTtBQUNKdkoseUJBQU8sQ0FBQ0MsR0FBUixDQUFZc0osR0FBWjtBQUNIO0FBQ0osZUFKRDtBQUtILGFBeGEwQixDQTBhM0I7OztBQUVBLGdCQUFJaEUsTUFBTSxHQUFHLEVBQVQsSUFBZSxDQUFuQixFQUFxQjtBQUNqQnZGLHFCQUFPLENBQUNDLEdBQVIsQ0FBWSxpREFBWjtBQUNBLGtCQUFJc08sZ0JBQWdCLEdBQUcvTyxVQUFVLENBQUN5RixJQUFYLENBQWdCO0FBQUM2QixzQkFBTSxFQUFDLENBQVI7QUFBVTJGLHNCQUFNLEVBQUM7QUFBakIsZUFBaEIsRUFBd0M7QUFBQ3ZGLG9CQUFJLEVBQUM7QUFBQ29ELDhCQUFZLEVBQUMsQ0FBQztBQUFmO0FBQU4sZUFBeEMsRUFBa0VuRixLQUFsRSxFQUF2QjtBQUNBLGtCQUFJcUosWUFBWSxHQUFHakQsSUFBSSxDQUFDa0QsSUFBTCxDQUFVRixnQkFBZ0IsQ0FBQ3JOLE1BQWpCLEdBQXdCLEdBQWxDLENBQW5CO0FBQ0Esa0JBQUl3TixlQUFlLEdBQUdILGdCQUFnQixDQUFDck4sTUFBakIsR0FBMEJzTixZQUFoRDtBQUVBLGtCQUFJRyxjQUFjLEdBQUcsQ0FBckI7QUFDQSxrQkFBSUMsaUJBQWlCLEdBQUcsQ0FBeEI7QUFFQSxrQkFBSUMsZ0JBQWdCLEdBQUcsQ0FBdkI7QUFDQSxrQkFBSUMsaUJBQWlCLEdBQUcsQ0FBeEI7QUFDQSxrQkFBSUMsb0JBQW9CLEdBQUcsQ0FBM0I7QUFDQSxrQkFBSUMscUJBQXFCLEdBQUcsQ0FBNUI7O0FBSUEsbUJBQUsxUCxDQUFMLElBQVVpUCxnQkFBVixFQUEyQjtBQUN2QixvQkFBSWpQLENBQUMsR0FBR2tQLFlBQVIsRUFBcUI7QUFDakJHLGdDQUFjLElBQUlKLGdCQUFnQixDQUFDalAsQ0FBRCxDQUFoQixDQUFvQmdMLFlBQXRDO0FBQ0gsaUJBRkQsTUFHSTtBQUNBc0UsbUNBQWlCLElBQUlMLGdCQUFnQixDQUFDalAsQ0FBRCxDQUFoQixDQUFvQmdMLFlBQXpDO0FBQ0g7O0FBR0Qsb0JBQUl5RSxvQkFBb0IsR0FBRyxJQUEzQixFQUFnQztBQUM1QkEsc0NBQW9CLElBQUlSLGdCQUFnQixDQUFDalAsQ0FBRCxDQUFoQixDQUFvQmdMLFlBQXBCLEdBQW1DdEMsYUFBYSxDQUFDc0MsWUFBekU7QUFDQXVFLGtDQUFnQjtBQUNuQjtBQUNKOztBQUVERyxtQ0FBcUIsR0FBRyxJQUFJRCxvQkFBNUI7QUFDQUQsK0JBQWlCLEdBQUdQLGdCQUFnQixDQUFDck4sTUFBakIsR0FBMEIyTixnQkFBOUM7QUFFQSxrQkFBSUksTUFBTSxHQUFHO0FBQ1QxSixzQkFBTSxFQUFFQSxNQURDO0FBRVRpSiw0QkFBWSxFQUFFQSxZQUZMO0FBR1RHLDhCQUFjLEVBQUVBLGNBSFA7QUFJVEQsK0JBQWUsRUFBRUEsZUFKUjtBQUtURSxpQ0FBaUIsRUFBRUEsaUJBTFY7QUFNVEMsZ0NBQWdCLEVBQUVBLGdCQU5UO0FBT1RFLG9DQUFvQixFQUFFQSxvQkFQYjtBQVFURCxpQ0FBaUIsRUFBRUEsaUJBUlY7QUFTVEUscUNBQXFCLEVBQUVBLHFCQVRkO0FBVVRFLDZCQUFhLEVBQUVYLGdCQUFnQixDQUFDck4sTUFWdkI7QUFXVGlPLGdDQUFnQixFQUFFbkgsYUFBYSxDQUFDc0MsWUFYdkI7QUFZVGEseUJBQVMsRUFBRTVDLFNBQVMsQ0FBQ2pHLElBWlo7QUFhVDhNLHdCQUFRLEVBQUUsSUFBSTdNLElBQUo7QUFiRCxlQUFiO0FBZ0JBdkMscUJBQU8sQ0FBQ0MsR0FBUixDQUFZZ1AsTUFBWjtBQUVBeEwsNkJBQWUsQ0FBQ2dHLE1BQWhCLENBQXVCd0YsTUFBdkI7QUFDSDtBQUNKO0FBQ0osU0EzZUQsQ0E0ZUEsT0FBT2xQLENBQVAsRUFBUztBQUNMQyxpQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDQXVILGlCQUFPLEdBQUcsS0FBVjtBQUNBLGlCQUFPLFNBQVA7QUFDSDs7QUFDRCxZQUFJK0gsWUFBWSxHQUFHLElBQUk5TSxJQUFKLEVBQW5CO0FBQ0F2QyxlQUFPLENBQUNDLEdBQVIsQ0FBWSxzQkFBcUIsQ0FBQ29QLFlBQVksR0FBQ3RILGNBQWQsSUFBOEIsSUFBbkQsR0FBeUQsVUFBckU7QUFDSDs7QUFDRFQsYUFBTyxHQUFHLEtBQVY7QUFDQWpFLFdBQUssQ0FBQ3NJLE1BQU4sQ0FBYTtBQUFDWCxlQUFPLEVBQUM3TCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjRFO0FBQWhDLE9BQWIsRUFBdUQ7QUFBQ0gsWUFBSSxFQUFDO0FBQUN5RSw4QkFBb0IsRUFBQyxJQUFJL00sSUFBSixFQUF0QjtBQUFrQ3FGLHlCQUFlLEVBQUNBO0FBQWxEO0FBQU4sT0FBdkQ7QUFDSDs7QUFFRCxXQUFPTCxLQUFQO0FBQ0gsR0EvbUJVO0FBZ25CWCxjQUFZLFVBQVNKLEtBQVQsRUFBZ0I7QUFDeEI7QUFDQSxXQUFRQSxLQUFLLEdBQUMsRUFBZDtBQUNILEdBbm5CVTtBQW9uQlgsYUFBVyxVQUFTQSxLQUFULEVBQWdCO0FBQ3ZCLFFBQUlBLEtBQUssR0FBR2hJLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxrQkFBWixDQUFaLEVBQTZDO0FBQ3pDLGFBQVEsS0FBUjtBQUNILEtBRkQsTUFFTztBQUNILGFBQVEsSUFBUjtBQUNIO0FBQ0o7QUExbkJVLENBQWYsRTs7Ozs7Ozs7Ozs7QUM3REEsSUFBSXJJLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSThELFNBQUo7QUFBY2hFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQytELFdBQVMsQ0FBQzlELENBQUQsRUFBRztBQUFDOEQsYUFBUyxHQUFDOUQsQ0FBVjtBQUFZOztBQUExQixDQUEzQixFQUF1RCxDQUF2RDtBQUEwRCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJcUUsWUFBSjtBQUFpQnZFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUNzRSxjQUFZLENBQUNyRSxDQUFELEVBQUc7QUFBQ3FFLGdCQUFZLEdBQUNyRSxDQUFiO0FBQWU7O0FBQWhDLENBQWpELEVBQW1GLENBQW5GO0FBS3RQaVEsZ0JBQWdCLENBQUMsZUFBRCxFQUFrQixVQUFTcEksS0FBVCxFQUFlO0FBQzdDLFNBQU87QUFDSGxDLFFBQUksR0FBRTtBQUNGLGFBQU83QixTQUFTLENBQUM2QixJQUFWLENBQWUsRUFBZixFQUFtQjtBQUFDa0MsYUFBSyxFQUFFQSxLQUFSO0FBQWVELFlBQUksRUFBRTtBQUFDM0IsZ0JBQU0sRUFBRSxDQUFDO0FBQVY7QUFBckIsT0FBbkIsQ0FBUDtBQUNILEtBSEU7O0FBSUhpSyxZQUFRLEVBQUUsQ0FDTjtBQUNJdkssVUFBSSxDQUFDSyxLQUFELEVBQU87QUFDUCxlQUFPOUYsVUFBVSxDQUFDeUYsSUFBWCxDQUNIO0FBQUM5RSxpQkFBTyxFQUFDbUYsS0FBSyxDQUFDSjtBQUFmLFNBREcsRUFFSDtBQUFDaUMsZUFBSyxFQUFDO0FBQVAsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FETTtBQUpQLEdBQVA7QUFlSCxDQWhCZSxDQUFoQjtBQWtCQW9JLGdCQUFnQixDQUFDLGdCQUFELEVBQW1CLFVBQVNoSyxNQUFULEVBQWdCO0FBQy9DLFNBQU87QUFDSE4sUUFBSSxHQUFFO0FBQ0YsYUFBTzdCLFNBQVMsQ0FBQzZCLElBQVYsQ0FBZTtBQUFDTSxjQUFNLEVBQUNBO0FBQVIsT0FBZixDQUFQO0FBQ0gsS0FIRTs7QUFJSGlLLFlBQVEsRUFBRSxDQUNOO0FBQ0l2SyxVQUFJLENBQUNLLEtBQUQsRUFBTztBQUNQLGVBQU8zQixZQUFZLENBQUNzQixJQUFiLENBQ0g7QUFBQ00sZ0JBQU0sRUFBQ0QsS0FBSyxDQUFDQztBQUFkLFNBREcsQ0FBUDtBQUdIOztBQUxMLEtBRE0sRUFRTjtBQUNJTixVQUFJLENBQUNLLEtBQUQsRUFBTztBQUNQLGVBQU85RixVQUFVLENBQUN5RixJQUFYLENBQ0g7QUFBQzlFLGlCQUFPLEVBQUNtRixLQUFLLENBQUNKO0FBQWYsU0FERyxFQUVIO0FBQUNpQyxlQUFLLEVBQUM7QUFBUCxTQUZHLENBQVA7QUFJSDs7QUFOTCxLQVJNO0FBSlAsR0FBUDtBQXNCSCxDQXZCZSxDQUFoQixDOzs7Ozs7Ozs7OztBQ3ZCQS9ILE1BQU0sQ0FBQ3FRLE1BQVAsQ0FBYztBQUFDck0sV0FBUyxFQUFDLE1BQUlBO0FBQWYsQ0FBZDtBQUF5QyxJQUFJc00sS0FBSjtBQUFVdFEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDcVEsT0FBSyxDQUFDcFEsQ0FBRCxFQUFHO0FBQUNvUSxTQUFLLEdBQUNwUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksNkJBQVosRUFBMEM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTFDLEVBQXdFLENBQXhFO0FBRzdHLE1BQU04RCxTQUFTLEdBQUcsSUFBSXNNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixRQUFyQixDQUFsQjtBQUVQdk0sU0FBUyxDQUFDd00sT0FBVixDQUFrQjtBQUNkQyxVQUFRLEdBQUU7QUFDTixXQUFPclEsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDckIsYUFBTyxFQUFDLEtBQUsrRTtBQUFkLEtBQW5CLENBQVA7QUFDSDs7QUFIYSxDQUFsQixFLENBTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0I7Ozs7Ozs7Ozs7O0FDdEJBLElBQUkvRixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSXdFLFVBQUo7QUFBZTFFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUN5RSxZQUFVLENBQUN4RSxDQUFELEVBQUc7QUFBQ3dFLGNBQVUsR0FBQ3hFLENBQVg7QUFBYTs7QUFBNUIsQ0FBdkMsRUFBcUUsQ0FBckU7QUFBd0UsSUFBSStELEtBQUosRUFBVXlNLFdBQVY7QUFBc0IxUSxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNnRSxPQUFLLENBQUMvRCxDQUFELEVBQUc7QUFBQytELFNBQUssR0FBQy9ELENBQU47QUFBUSxHQUFsQjs7QUFBbUJ3USxhQUFXLENBQUN4USxDQUFELEVBQUc7QUFBQ3dRLGVBQVcsR0FBQ3hRLENBQVo7QUFBYzs7QUFBaEQsQ0FBMUIsRUFBNEUsQ0FBNUU7QUFBK0UsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBN0MsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSW9FLGtCQUFKO0FBQXVCdEUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0JBQVosRUFBNEM7QUFBQ3FFLG9CQUFrQixDQUFDcEUsQ0FBRCxFQUFHO0FBQUNvRSxzQkFBa0IsR0FBQ3BFLENBQW5CO0FBQXFCOztBQUE1QyxDQUE1QyxFQUEwRixDQUExRjs7QUFPeGF5USxlQUFlLEdBQUcsQ0FBQ3hPLFNBQUQsRUFBWXlPLGFBQVosS0FBOEI7QUFDNUMsT0FBSyxJQUFJMVEsQ0FBVCxJQUFjMFEsYUFBZCxFQUE0QjtBQUN4QixRQUFJek8sU0FBUyxDQUFDeUssT0FBVixDQUFrQm5MLEtBQWxCLElBQTJCbVAsYUFBYSxDQUFDMVEsQ0FBRCxDQUFiLENBQWlCME0sT0FBakIsQ0FBeUJuTCxLQUF4RCxFQUE4RDtBQUMxRCxhQUFPaUosUUFBUSxDQUFDa0csYUFBYSxDQUFDMVEsQ0FBRCxDQUFiLENBQWlCMlEsS0FBbEIsQ0FBZjtBQUNIO0FBQ0o7QUFDSixDQU5EOztBQVFBOVEsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCw2QkFBMkIsWUFBVTtBQUNqQyxTQUFLRSxPQUFMO0FBQ0EsUUFBSVYsR0FBRyxHQUFHbUgsR0FBRyxHQUFDLHVCQUFkOztBQUNBLFFBQUc7QUFDQyxVQUFJdkcsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsVUFBSXdRLFNBQVMsR0FBRzNQLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWhCO0FBQ0F5UCxlQUFTLEdBQUdBLFNBQVMsQ0FBQ3hQLE1BQXRCO0FBQ0EsVUFBSTZFLE1BQU0sR0FBRzJLLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQjVLLE1BQW5DO0FBQ0EsVUFBSTZLLEtBQUssR0FBR0YsU0FBUyxDQUFDQyxXQUFWLENBQXNCQyxLQUFsQztBQUNBLFVBQUlDLElBQUksR0FBR0gsU0FBUyxDQUFDQyxXQUFWLENBQXNCRSxJQUFqQztBQUNBLFVBQUlDLFVBQVUsR0FBRy9FLElBQUksQ0FBQzZFLEtBQUwsQ0FBV3BPLFVBQVUsQ0FBQ2tPLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQkksS0FBdEIsQ0FBNEJILEtBQTVCLEVBQW1DSSxrQkFBbkMsQ0FBc0RDLEtBQXRELENBQTRELEdBQTVELEVBQWlFLENBQWpFLENBQUQsQ0FBVixHQUFnRixHQUEzRixDQUFqQjtBQUVBcE4sV0FBSyxDQUFDc0ksTUFBTixDQUFhO0FBQUNYLGVBQU8sRUFBQzdMLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNEU7QUFBaEMsT0FBYixFQUF1RDtBQUFDSCxZQUFJLEVBQUM7QUFDekQ2RixzQkFBWSxFQUFFbkwsTUFEMkM7QUFFekRvTCxxQkFBVyxFQUFFUCxLQUY0QztBQUd6RFEsb0JBQVUsRUFBRVAsSUFINkM7QUFJekRDLG9CQUFVLEVBQUVBLFVBSjZDO0FBS3pEcEwseUJBQWUsRUFBRWdMLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQmpNLFVBQXRCLENBQWlDMkwsUUFBakMsQ0FBMEMxUCxPQUxGO0FBTXpEMFEsa0JBQVEsRUFBRVgsU0FBUyxDQUFDQyxXQUFWLENBQXNCSSxLQUF0QixDQUE0QkgsS0FBNUIsRUFBbUNTLFFBTlk7QUFPekQ5SCxvQkFBVSxFQUFFbUgsU0FBUyxDQUFDQyxXQUFWLENBQXNCSSxLQUF0QixDQUE0QkgsS0FBNUIsRUFBbUNySDtBQVBVO0FBQU4sT0FBdkQ7QUFTSCxLQWxCRCxDQW1CQSxPQUFNaEosQ0FBTixFQUFRO0FBQ0pDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixHQTFCVTtBQTJCWCx3QkFBc0IsWUFBVTtBQUM1QixTQUFLSyxPQUFMO0FBQ0EsUUFBSVYsR0FBRyxHQUFHbUgsR0FBRyxHQUFDLFNBQWQ7O0FBQ0EsUUFBRztBQUNDLFVBQUl2RyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxVQUFJb0gsTUFBTSxHQUFHdkcsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBYjtBQUNBcUcsWUFBTSxHQUFHQSxNQUFNLENBQUNwRyxNQUFoQjtBQUNBLFVBQUlvUSxLQUFLLEdBQUcsRUFBWjtBQUNBQSxXQUFLLENBQUM5RixPQUFOLEdBQWdCbEUsTUFBTSxDQUFDaUssU0FBUCxDQUFpQkMsT0FBakM7QUFDQUYsV0FBSyxDQUFDRyxpQkFBTixHQUEwQm5LLE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQkMsbUJBQTNDO0FBQ0E4SixXQUFLLENBQUNJLGVBQU4sR0FBd0JwSyxNQUFNLENBQUNDLFNBQVAsQ0FBaUJvSyxpQkFBekM7QUFFQSxVQUFJQyxXQUFXLEdBQUd0QixXQUFXLENBQUN0TyxPQUFaLENBQW9CLEVBQXBCLEVBQXdCO0FBQUMwRixZQUFJLEVBQUU7QUFBQzNCLGdCQUFNLEVBQUUsQ0FBQztBQUFWO0FBQVAsT0FBeEIsQ0FBbEI7O0FBQ0EsVUFBSTZMLFdBQVcsSUFBSUEsV0FBVyxDQUFDN0wsTUFBWixJQUFzQnVMLEtBQUssQ0FBQ0csaUJBQS9DLEVBQWtFO0FBQzlELG1EQUFvQ0gsS0FBSyxDQUFDRyxpQkFBMUMsdUJBQXdFRyxXQUFXLENBQUM3TCxNQUFwRjtBQUNIOztBQUVEN0YsU0FBRyxHQUFHbUgsR0FBRyxHQUFDLGFBQVY7QUFDQXZHLGNBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLFVBQUl3RSxVQUFVLEdBQUczRCxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFqQjtBQUNBeUQsZ0JBQVUsR0FBR0EsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQS9CO0FBQ0E0TSxXQUFLLENBQUM1TSxVQUFOLEdBQW1CQSxVQUFVLENBQUNoRCxNQUE5QjtBQUNBLFVBQUltUSxRQUFRLEdBQUcsQ0FBZjs7QUFDQSxXQUFLL1IsQ0FBTCxJQUFVNEUsVUFBVixFQUFxQjtBQUNqQm1OLGdCQUFRLElBQUl2SCxRQUFRLENBQUM1RixVQUFVLENBQUM1RSxDQUFELENBQVYsQ0FBY2dMLFlBQWYsQ0FBcEI7QUFDSDs7QUFDRHdHLFdBQUssQ0FBQ1EsaUJBQU4sR0FBMEJELFFBQTFCO0FBR0FoTyxXQUFLLENBQUNzSSxNQUFOLENBQWE7QUFBQ1gsZUFBTyxFQUFDOEYsS0FBSyxDQUFDOUY7QUFBZixPQUFiLEVBQXNDO0FBQUNILFlBQUksRUFBQ2lHO0FBQU4sT0FBdEMsRUFBb0Q7QUFBQ25HLGNBQU0sRUFBRTtBQUFULE9BQXBELEVBMUJELENBMkJDOztBQUNBLFVBQUliLFFBQVEsQ0FBQ2dILEtBQUssQ0FBQ0csaUJBQVAsQ0FBUixHQUFvQyxDQUF4QyxFQUEwQztBQUN0QyxZQUFJTSxXQUFXLEdBQUcsRUFBbEI7QUFDQUEsbUJBQVcsQ0FBQ2hNLE1BQVosR0FBcUJ1RSxRQUFRLENBQUNoRCxNQUFNLENBQUNDLFNBQVAsQ0FBaUJDLG1CQUFsQixDQUE3QjtBQUNBdUssbUJBQVcsQ0FBQ2pQLElBQVosR0FBbUIsSUFBSUMsSUFBSixDQUFTdUUsTUFBTSxDQUFDQyxTQUFQLENBQWlCb0ssaUJBQTFCLENBQW5CO0FBRUF6UixXQUFHLEdBQUdHLEdBQUcsR0FBRyxlQUFaOztBQUNBLFlBQUc7QUFDQ1Msa0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLGNBQUk4UixPQUFPLEdBQUdqUixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBM0MsQ0FGRCxDQUdDO0FBQ0E7O0FBQ0E2USxxQkFBVyxDQUFDRSxZQUFaLEdBQTJCM0gsUUFBUSxDQUFDMEgsT0FBTyxDQUFDRSxhQUFULENBQW5DO0FBQ0FILHFCQUFXLENBQUNJLGVBQVosR0FBOEI3SCxRQUFRLENBQUMwSCxPQUFPLENBQUNJLGlCQUFULENBQXRDO0FBQ0gsU0FQRCxDQVFBLE9BQU03UixDQUFOLEVBQVE7QUFDSkMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBRURMLFdBQUcsR0FBR0csR0FBRyxHQUFHLGdCQUFOLEdBQXVCVixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QnlMLFlBQXBEOztBQUNBLFlBQUc7QUFDQ3ZSLGtCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQSxjQUFJb1MsTUFBTSxHQUFHdlIsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTFDO0FBQ0E2USxxQkFBVyxDQUFDUSxXQUFaLEdBQTBCakksUUFBUSxDQUFDZ0ksTUFBRCxDQUFsQztBQUNILFNBSkQsQ0FLQSxPQUFNL1IsQ0FBTixFQUFRO0FBQ0pDLGlCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUVETCxXQUFHLEdBQUdHLEdBQUcsR0FBRyw4QkFBWjs7QUFDQSxZQUFJO0FBQ0FTLGtCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQSxjQUFJc1MsSUFBSSxHQUFHelIsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQXhDOztBQUNBLGNBQUlzUixJQUFJLElBQUlBLElBQUksQ0FBQzlRLE1BQUwsR0FBYyxDQUExQixFQUE0QjtBQUN4QnFRLHVCQUFXLENBQUNVLGFBQVosR0FBNEIsRUFBNUI7QUFDQUQsZ0JBQUksQ0FBQzdQLE9BQUwsQ0FBYSxDQUFDK1AsTUFBRCxFQUFTclAsQ0FBVCxLQUFlO0FBQ3hCME8seUJBQVcsQ0FBQ1UsYUFBWixDQUEwQmhKLElBQTFCLENBQStCO0FBQzNCa0oscUJBQUssRUFBRUQsTUFBTSxDQUFDQyxLQURhO0FBRTNCRCxzQkFBTSxFQUFFbFEsVUFBVSxDQUFDa1EsTUFBTSxDQUFDQSxNQUFSO0FBRlMsZUFBL0I7QUFJSCxhQUxEO0FBTUg7QUFDSixTQVpELENBYUEsT0FBT25TLENBQVAsRUFBUztBQUNMQyxpQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFFREwsV0FBRyxHQUFHRyxHQUFHLEdBQUcsb0JBQVo7O0FBQ0EsWUFBRztBQUNDUyxrQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0EsY0FBSTBTLFNBQVMsR0FBRzdSLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE3Qzs7QUFDQSxjQUFJMFIsU0FBSixFQUFjO0FBQ1ZiLHVCQUFXLENBQUNhLFNBQVosR0FBd0JwUSxVQUFVLENBQUNvUSxTQUFELENBQWxDO0FBQ0g7QUFDSixTQU5ELENBT0EsT0FBTXJTLENBQU4sRUFBUTtBQUNKQyxpQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFFREwsV0FBRyxHQUFHRyxHQUFHLEdBQUcsNEJBQVo7O0FBQ0EsWUFBRztBQUNDUyxrQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0EsY0FBSTJTLFVBQVUsR0FBRzlSLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWpCOztBQUNBLGNBQUk0UixVQUFKLEVBQWU7QUFDWGQsdUJBQVcsQ0FBQ2UsZ0JBQVosR0FBK0J0USxVQUFVLENBQUNxUSxVQUFVLENBQUMzUixNQUFaLENBQXpDO0FBQ0g7QUFDSixTQU5ELENBT0EsT0FBTVgsQ0FBTixFQUFRO0FBQ0pDLGlCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUVEK1AsbUJBQVcsQ0FBQ3JHLE1BQVosQ0FBbUI4SCxXQUFuQjtBQUNILE9BbkdGLENBcUdDO0FBRUE7QUFDQTs7O0FBQ0EsYUFBT1QsS0FBSyxDQUFDRyxpQkFBYjtBQUNILEtBMUdELENBMkdBLE9BQU9sUixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDQSxhQUFPLDZCQUFQO0FBQ0g7QUFDSixHQTdJVTtBQThJWCwyQkFBeUIsWUFBVTtBQUMvQnNELFNBQUssQ0FBQzRCLElBQU4sR0FBYWlDLElBQWIsQ0FBa0I7QUFBQ3FMLGFBQU8sRUFBQyxDQUFDO0FBQVYsS0FBbEIsRUFBZ0NwTCxLQUFoQyxDQUFzQyxDQUF0QztBQUNILEdBaEpVO0FBaUpYLG1CQUFpQixZQUFVO0FBQ3ZCLFFBQUkySixLQUFLLEdBQUd6TixLQUFLLENBQUM3QixPQUFOLENBQWM7QUFBQ3dKLGFBQU8sRUFBRTdMLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNEU7QUFBakMsS0FBZCxDQUFaOztBQUVBLFFBQUk4RixLQUFLLElBQUlBLEtBQUssQ0FBQzBCLFdBQW5CLEVBQStCO0FBQzNCeFMsYUFBTyxDQUFDQyxHQUFSLENBQVksaUNBQVo7QUFDSCxLQUZELE1BR0ssSUFBSWQsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQnNNLEtBQWhCLENBQXNCRCxXQUExQixFQUF1QztBQUN4Q3hTLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHVDQUFaO0FBQ0EsVUFBSUssUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU1QsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQnVNLFdBQXpCLENBQWY7QUFDQSxVQUFJQyxPQUFPLEdBQUdwUyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFkO0FBQ0EsVUFBSW1TLEtBQUssR0FBR0QsT0FBTyxDQUFDRSxTQUFSLENBQWtCRCxLQUFsQixJQUEyQkQsT0FBTyxDQUFDRSxTQUFSLENBQWtCQyxZQUF6RDtBQUNBLFVBQUlDLFdBQVcsR0FBRztBQUNkL0gsZUFBTyxFQUFFMkgsT0FBTyxDQUFDMUgsUUFESDtBQUVkK0gsbUJBQVcsRUFBRUwsT0FBTyxDQUFDTSxZQUZQO0FBR2RDLHVCQUFlLEVBQUVQLE9BQU8sQ0FBQ1EsZ0JBSFg7QUFJZEMsWUFBSSxFQUFFVCxPQUFPLENBQUNFLFNBQVIsQ0FBa0JPLElBSlY7QUFLZEMsWUFBSSxFQUFFVixPQUFPLENBQUNFLFNBQVIsQ0FBa0JRLElBTFY7QUFNZEMsZUFBTyxFQUFFO0FBQ0x0QixjQUFJLEVBQUVXLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEJ0QixJQUQzQjtBQUVMM0ssZ0JBQU0sRUFBRXNMLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEJqTTtBQUY3QixTQU5LO0FBVWRrTSxZQUFJLEVBQUVaLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlUsSUFWVjtBQVdkWCxhQUFLLEVBQUU7QUFDSFksc0JBQVksRUFBRVosS0FBSyxDQUFDYSxhQURqQjtBQUVIQyw0QkFBa0IsRUFBRWQsS0FBSyxDQUFDZSxvQkFGdkI7QUFHSEMsNkJBQW1CLEVBQUVoQixLQUFLLENBQUNpQixxQkFIeEI7QUFJSEMsNkJBQW1CLEVBQUVsQixLQUFLLENBQUNtQjtBQUp4QixTQVhPO0FBaUJkQyxXQUFHLEVBQUUsSUFqQlM7QUFrQmRDLGdCQUFRLEVBQUM7QUFDTDVNLGdCQUFNLEVBQUVzTCxPQUFPLENBQUNFLFNBQVIsQ0FBa0JvQixRQUFsQixDQUEyQjVNO0FBRDlCLFNBbEJLO0FBcUJkeUssY0FBTSxFQUFFYSxPQUFPLENBQUNFLFNBQVIsQ0FBa0JmLE1BckJaO0FBc0Jkb0MsY0FBTSxFQUFFdkIsT0FBTyxDQUFDRSxTQUFSLENBQWtCcUI7QUF0QlosT0FBbEI7QUF5QkEsVUFBSS9FLGdCQUFnQixHQUFHLENBQXZCLENBOUJ3QyxDQWdDeEM7O0FBQ0EsVUFBSXdELE9BQU8sQ0FBQ0UsU0FBUixDQUFrQnNCLE9BQWxCLElBQTZCeEIsT0FBTyxDQUFDRSxTQUFSLENBQWtCc0IsT0FBbEIsQ0FBMEJDLE1BQXZELElBQWtFekIsT0FBTyxDQUFDRSxTQUFSLENBQWtCc0IsT0FBbEIsQ0FBMEJDLE1BQTFCLENBQWlDbFQsTUFBakMsR0FBMEMsQ0FBaEgsRUFBbUg7QUFDL0csYUFBSzJCLENBQUwsSUFBVThQLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQnNCLE9BQWxCLENBQTBCQyxNQUFwQyxFQUEyQztBQUN2QyxjQUFJQyxHQUFHLEdBQUcxQixPQUFPLENBQUNFLFNBQVIsQ0FBa0JzQixPQUFsQixDQUEwQkMsTUFBMUIsQ0FBaUN2UixDQUFqQyxFQUFvQ2hDLEtBQXBDLENBQTBDd1QsR0FBcEQsQ0FEdUMsQ0FFdkM7O0FBQ0EsZUFBS0MsQ0FBTCxJQUFVRCxHQUFWLEVBQWM7QUFDVixnQkFBSUEsR0FBRyxDQUFDQyxDQUFELENBQUgsQ0FBTzFULElBQVAsSUFBZSwrQkFBbkIsRUFBbUQ7QUFDL0NaLHFCQUFPLENBQUNDLEdBQVIsQ0FBWW9VLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU96VCxLQUFuQixFQUQrQyxDQUUvQzs7QUFDQSxrQkFBSVUsU0FBUyxHQUFHO0FBQ1pvRyxnQ0FBZ0IsRUFBRTBNLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU96VCxLQUFQLENBQWEwVCxNQURuQjtBQUVaaEksMkJBQVcsRUFBRThILEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU96VCxLQUFQLENBQWEwTCxXQUZkO0FBR1oxSywwQkFBVSxFQUFFd1MsR0FBRyxDQUFDQyxDQUFELENBQUgsQ0FBT3pULEtBQVAsQ0FBYWdCLFVBSGI7QUFJWjZLLG1DQUFtQixFQUFFMkgsR0FBRyxDQUFDQyxDQUFELENBQUgsQ0FBT3pULEtBQVAsQ0FBYTZMLG1CQUp0QjtBQUtaaEwsZ0NBQWdCLEVBQUUyUyxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPelQsS0FBUCxDQUFhcUksaUJBTG5CO0FBTVp2SCxpQ0FBaUIsRUFBRTBTLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU96VCxLQUFQLENBQWFjLGlCQU5wQjtBQU9aMkksNEJBQVksRUFBRWlCLElBQUksQ0FBQ2lKLEtBQUwsQ0FBVzFLLFFBQVEsQ0FBQ3VLLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU96VCxLQUFQLENBQWFBLEtBQWIsQ0FBbUJxUixNQUFwQixDQUFSLEdBQXNDL1MsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJxTyxlQUF4RSxDQVBGO0FBUVpoSSxzQkFBTSxFQUFFLEtBUkk7QUFTWjNGLHNCQUFNLEVBQUU7QUFUSSxlQUFoQjtBQVlBcUksOEJBQWdCLElBQUk1TixTQUFTLENBQUMrSSxZQUE5QjtBQUVBLGtCQUFJb0ssV0FBVyxHQUFHdlYsTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCNk0sR0FBRyxDQUFDQyxDQUFELENBQUgsQ0FBT3pULEtBQVAsQ0FBYTBULE1BQTNDLENBQWxCLENBakIrQyxDQWtCL0M7O0FBRUFoVCx1QkFBUyxDQUFDeUssT0FBVixHQUFvQjtBQUNoQix3QkFBTywwQkFEUztBQUVoQix5QkFBUTBJO0FBRlEsZUFBcEI7QUFLQW5ULHVCQUFTLENBQUNwQixPQUFWLEdBQW9CMkQsVUFBVSxDQUFDdkMsU0FBUyxDQUFDeUssT0FBWCxDQUE5QjtBQUNBekssdUJBQVMsQ0FBQzBLLE1BQVYsR0FBbUI5TSxNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJqRyxTQUFTLENBQUN5SyxPQUF4QyxFQUFpRDdNLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEYsa0JBQXhFLENBQW5CO0FBQ0EzSyx1QkFBUyxDQUFDNEssZUFBVixHQUE0QmhOLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmpHLFNBQVMsQ0FBQ3lLLE9BQXhDLEVBQWlEN00sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJnRyxrQkFBeEUsQ0FBNUI7QUFDQTFJLGdDQUFrQixDQUFDK0YsTUFBbkIsQ0FBMEI7QUFDdEJ0Six1QkFBTyxFQUFFb0IsU0FBUyxDQUFDcEIsT0FERztBQUV0QitNLGlDQUFpQixFQUFFLENBRkc7QUFHdEI1Qyw0QkFBWSxFQUFFL0ksU0FBUyxDQUFDK0ksWUFIRjtBQUl0QjFKLG9CQUFJLEVBQUUsS0FKZ0I7QUFLdEIyRSxzQkFBTSxFQUFFLENBTGM7QUFNdEI0SCwwQkFBVSxFQUFFd0YsT0FBTyxDQUFDTTtBQU5FLGVBQTFCO0FBU0F6VCx3QkFBVSxDQUFDaUssTUFBWCxDQUFrQmxJLFNBQWxCO0FBQ0g7QUFDSjtBQUNKO0FBQ0osT0EvRXVDLENBaUZ4Qzs7O0FBQ0F2QixhQUFPLENBQUNDLEdBQVIsQ0FBWSxxQ0FBWjs7QUFDQSxVQUFJMFMsT0FBTyxDQUFDRSxTQUFSLENBQWtCUyxPQUFsQixDQUEwQnBQLFVBQTFCLElBQXdDeU8sT0FBTyxDQUFDRSxTQUFSLENBQWtCUyxPQUFsQixDQUEwQnBQLFVBQTFCLENBQXFDaEQsTUFBckMsR0FBOEMsQ0FBMUYsRUFBNEY7QUFDeEZsQixlQUFPLENBQUNDLEdBQVIsQ0FBWTBTLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEJwUCxVQUExQixDQUFxQ2hELE1BQWpEO0FBQ0EsWUFBSXlULGdCQUFnQixHQUFHaEMsT0FBTyxDQUFDRSxTQUFSLENBQWtCUyxPQUFsQixDQUEwQnBQLFVBQWpEO0FBQ0EsWUFBSThMLGFBQWEsR0FBRzJDLE9BQU8sQ0FBQ3pPLFVBQTVCOztBQUNBLGFBQUssSUFBSTVFLENBQVQsSUFBY3FWLGdCQUFkLEVBQStCO0FBQzNCO0FBQ0EsY0FBSXBULFNBQVMsR0FBR29ULGdCQUFnQixDQUFDclYsQ0FBRCxDQUFoQztBQUNBaUMsbUJBQVMsQ0FBQ0ksaUJBQVYsR0FBOEJ4QyxNQUFNLENBQUNxSSxJQUFQLENBQVksY0FBWixFQUE0Qm1OLGdCQUFnQixDQUFDclYsQ0FBRCxDQUFoQixDQUFvQm9DLGdCQUFoRCxDQUE5QjtBQUVBLGNBQUlnVCxXQUFXLEdBQUd2VixNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJqRyxTQUFTLENBQUNvRyxnQkFBeEMsQ0FBbEI7QUFFQXBHLG1CQUFTLENBQUN5SyxPQUFWLEdBQW9CO0FBQ2hCLG9CQUFPLDBCQURTO0FBRWhCLHFCQUFRMEk7QUFGUSxXQUFwQjtBQUtBblQsbUJBQVMsQ0FBQ3BCLE9BQVYsR0FBb0IyRCxVQUFVLENBQUN2QyxTQUFTLENBQUN5SyxPQUFYLENBQTlCO0FBQ0F6SyxtQkFBUyxDQUFDeUssT0FBVixHQUFvQnpLLFNBQVMsQ0FBQ3lLLE9BQTlCO0FBQ0F6SyxtQkFBUyxDQUFDMEssTUFBVixHQUFtQjlNLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmpHLFNBQVMsQ0FBQ3lLLE9BQXhDLEVBQWlEN00sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RixrQkFBeEUsQ0FBbkI7QUFDQTNLLG1CQUFTLENBQUM0SyxlQUFWLEdBQTRCaE4sTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCakcsU0FBUyxDQUFDeUssT0FBeEMsRUFBaUQ3TSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmdHLGtCQUF4RSxDQUE1QjtBQUVBN0ssbUJBQVMsQ0FBQytJLFlBQVYsR0FBeUJ5RixlQUFlLENBQUN4TyxTQUFELEVBQVl5TyxhQUFaLENBQXhDO0FBQ0FiLDBCQUFnQixJQUFJNU4sU0FBUyxDQUFDK0ksWUFBOUI7QUFFQTlLLG9CQUFVLENBQUNtTCxNQUFYLENBQWtCO0FBQUNoRCw0QkFBZ0IsRUFBQ3BHLFNBQVMsQ0FBQ29HO0FBQTVCLFdBQWxCLEVBQWdFcEcsU0FBaEU7QUFDQW1DLDRCQUFrQixDQUFDK0YsTUFBbkIsQ0FBMEI7QUFDdEJ0SixtQkFBTyxFQUFFb0IsU0FBUyxDQUFDcEIsT0FERztBQUV0QitNLDZCQUFpQixFQUFFLENBRkc7QUFHdEI1Qyx3QkFBWSxFQUFFL0ksU0FBUyxDQUFDK0ksWUFIRjtBQUl0QjFKLGdCQUFJLEVBQUUsS0FKZ0I7QUFLdEIyRSxrQkFBTSxFQUFFLENBTGM7QUFNdEI0SCxzQkFBVSxFQUFFd0YsT0FBTyxDQUFDTTtBQU5FLFdBQTFCO0FBUUg7QUFDSjs7QUFFREYsaUJBQVcsQ0FBQ1AsV0FBWixHQUEwQixJQUExQjtBQUNBTyxpQkFBVyxDQUFDekIsaUJBQVosR0FBZ0NuQyxnQkFBaEM7QUFDQSxVQUFJek8sTUFBTSxHQUFHMkMsS0FBSyxDQUFDc0gsTUFBTixDQUFhO0FBQUNLLGVBQU8sRUFBQytILFdBQVcsQ0FBQy9IO0FBQXJCLE9BQWIsRUFBNEM7QUFBQ0gsWUFBSSxFQUFDa0k7QUFBTixPQUE1QyxDQUFiO0FBR0EvUyxhQUFPLENBQUNDLEdBQVIsQ0FBWSwwQ0FBWjtBQUVIOztBQUVELFdBQU8sSUFBUDtBQUNIO0FBeFJVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNmQSxJQUFJZCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUkrRCxLQUFKLEVBQVV5TSxXQUFWO0FBQXNCMVEsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDZ0UsT0FBSyxDQUFDL0QsQ0FBRCxFQUFHO0FBQUMrRCxTQUFLLEdBQUMvRCxDQUFOO0FBQVEsR0FBbEI7O0FBQW1Cd1EsYUFBVyxDQUFDeFEsQ0FBRCxFQUFHO0FBQUN3USxlQUFXLEdBQUN4USxDQUFaO0FBQWM7O0FBQWhELENBQTFCLEVBQTRFLENBQTVFO0FBQStFLElBQUlzVixTQUFKO0FBQWN4VixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDdVYsV0FBUyxDQUFDdFYsQ0FBRCxFQUFHO0FBQUNzVixhQUFTLEdBQUN0VixDQUFWO0FBQVk7O0FBQTFCLENBQTdDLEVBQXlFLENBQXpFO0FBQTRFLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBSzlRSCxNQUFNLENBQUMwVixPQUFQLENBQWUsb0JBQWYsRUFBcUMsWUFBWTtBQUM3QyxTQUFPLENBQ0gvRSxXQUFXLENBQUM3SyxJQUFaLENBQWlCLEVBQWpCLEVBQW9CO0FBQUNpQyxRQUFJLEVBQUM7QUFBQzNCLFlBQU0sRUFBQyxDQUFDO0FBQVQsS0FBTjtBQUFrQjRCLFNBQUssRUFBQztBQUF4QixHQUFwQixDQURHLEVBRUh5TixTQUFTLENBQUMzUCxJQUFWLENBQWUsRUFBZixFQUFrQjtBQUFDaUMsUUFBSSxFQUFDO0FBQUM0TixxQkFBZSxFQUFDLENBQUM7QUFBbEIsS0FBTjtBQUEyQjNOLFNBQUssRUFBQztBQUFqQyxHQUFsQixDQUZHLENBQVA7QUFJSCxDQUxEO0FBT0FvSSxnQkFBZ0IsQ0FBQyxjQUFELEVBQWlCLFlBQVU7QUFDdkMsU0FBTztBQUNIdEssUUFBSSxHQUFFO0FBQ0YsYUFBTzVCLEtBQUssQ0FBQzRCLElBQU4sQ0FBVztBQUFDK0YsZUFBTyxFQUFDN0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI0RTtBQUFoQyxPQUFYLENBQVA7QUFDSCxLQUhFOztBQUlId0UsWUFBUSxFQUFFLENBQ047QUFDSXZLLFVBQUksQ0FBQzZMLEtBQUQsRUFBTztBQUNQLGVBQU90UixVQUFVLENBQUN5RixJQUFYLENBQ0gsRUFERyxFQUVIO0FBQUMwSSxnQkFBTSxFQUFDO0FBQ0p4TixtQkFBTyxFQUFDLENBREo7QUFFSm9NLHVCQUFXLEVBQUMsQ0FGUjtBQUdKN0ssNEJBQWdCLEVBQUMsQ0FIYjtBQUlKb0Ysa0JBQU0sRUFBQyxDQUFDLENBSko7QUFLSjJGLGtCQUFNLEVBQUMsQ0FMSDtBQU1KRCx1QkFBVyxFQUFDO0FBTlI7QUFBUixTQUZHLENBQVA7QUFXSDs7QUFiTCxLQURNO0FBSlAsR0FBUDtBQXNCSCxDQXZCZSxDQUFoQixDOzs7Ozs7Ozs7OztBQ1pBcE4sTUFBTSxDQUFDcVEsTUFBUCxDQUFjO0FBQUNwTSxPQUFLLEVBQUMsTUFBSUEsS0FBWDtBQUFpQnlNLGFBQVcsRUFBQyxNQUFJQTtBQUFqQyxDQUFkO0FBQTZELElBQUlKLEtBQUo7QUFBVXRRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3FRLE9BQUssQ0FBQ3BRLENBQUQsRUFBRztBQUFDb1EsU0FBSyxHQUFDcFEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUExQyxFQUF3RSxDQUF4RTtBQUdqSSxNQUFNK0QsS0FBSyxHQUFHLElBQUlxTSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZDtBQUNBLE1BQU1HLFdBQVcsR0FBRyxJQUFJSixLQUFLLENBQUNDLFVBQVYsQ0FBcUIsY0FBckIsQ0FBcEI7QUFFUHRNLEtBQUssQ0FBQ3VNLE9BQU4sQ0FBYztBQUNWQyxVQUFRLEdBQUU7QUFDTixXQUFPclEsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDckIsYUFBTyxFQUFDLEtBQUsrRTtBQUFkLEtBQW5CLENBQVA7QUFDSDs7QUFIUyxDQUFkLEU7Ozs7Ozs7Ozs7O0FDTkEsSUFBSS9GLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXNWLFNBQUo7QUFBY3hWLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUN1VixXQUFTLENBQUN0VixDQUFELEVBQUc7QUFBQ3NWLGFBQVMsR0FBQ3RWLENBQVY7QUFBWTs7QUFBMUIsQ0FBL0IsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUlySkgsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCw0QkFBMEIsWUFBVTtBQUNoQyxTQUFLRSxPQUFMO0FBQ0EsUUFBSTJVLE1BQU0sR0FBRzVWLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNE8sV0FBcEM7O0FBQ0EsUUFBSUQsTUFBSixFQUFXO0FBQ1AsVUFBRztBQUNDLFlBQUlFLEdBQUcsR0FBRyxJQUFJMVMsSUFBSixFQUFWO0FBQ0EwUyxXQUFHLENBQUNDLFVBQUosQ0FBZSxDQUFmO0FBQ0EsWUFBSXhWLEdBQUcsR0FBRyx1REFBcURxVixNQUFyRCxHQUE0RCx3SEFBdEU7QUFDQSxZQUFJelUsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmOztBQUNBLFlBQUlZLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQjtBQUNBLGNBQUlnQyxJQUFJLEdBQUd2QixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFYO0FBQ0FxQixjQUFJLEdBQUdBLElBQUksQ0FBQ2lULE1BQUQsQ0FBWCxDQUgyQixDQUkzQjs7QUFDQSxpQkFBT0gsU0FBUyxDQUFDakssTUFBVixDQUFpQjtBQUFDbUssMkJBQWUsRUFBQ2hULElBQUksQ0FBQ2dUO0FBQXRCLFdBQWpCLEVBQXlEO0FBQUNqSyxnQkFBSSxFQUFDL0k7QUFBTixXQUF6RCxDQUFQO0FBQ0g7QUFDSixPQVpELENBYUEsT0FBTS9CLENBQU4sRUFBUTtBQUNKQyxlQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osS0FqQkQsTUFrQkk7QUFDQSxhQUFPLDJCQUFQO0FBQ0g7QUFDSixHQXpCVTtBQTBCWCx3QkFBc0IsWUFBVTtBQUM1QixTQUFLSyxPQUFMO0FBQ0EsUUFBSTJVLE1BQU0sR0FBRzVWLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNE8sV0FBcEM7O0FBQ0EsUUFBSUQsTUFBSixFQUFXO0FBQ1AsYUFBUUgsU0FBUyxDQUFDcFQsT0FBVixDQUFrQixFQUFsQixFQUFxQjtBQUFDMEYsWUFBSSxFQUFDO0FBQUM0Tix5QkFBZSxFQUFDLENBQUM7QUFBbEI7QUFBTixPQUFyQixDQUFSO0FBQ0gsS0FGRCxNQUdJO0FBQ0EsYUFBTywyQkFBUDtBQUNIO0FBRUo7QUFwQ1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ0pBMVYsTUFBTSxDQUFDcVEsTUFBUCxDQUFjO0FBQUNtRixXQUFTLEVBQUMsTUFBSUE7QUFBZixDQUFkO0FBQXlDLElBQUlsRixLQUFKO0FBQVV0USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNxUSxPQUFLLENBQUNwUSxDQUFELEVBQUc7QUFBQ29RLFNBQUssR0FBQ3BRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFNUMsTUFBTXNWLFNBQVMsR0FBRyxJQUFJbEYsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFlBQXJCLENBQWxCLEM7Ozs7Ozs7Ozs7O0FDRlAsSUFBSXhRLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSTZWLFdBQUo7QUFBZ0IvVixNQUFNLENBQUNDLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDOFYsYUFBVyxDQUFDN1YsQ0FBRCxFQUFHO0FBQUM2VixlQUFXLEdBQUM3VixDQUFaO0FBQWM7O0FBQTlCLENBQWhDLEVBQWdFLENBQWhFO0FBQW1FLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBSWxLSCxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLGdDQUE4QixZQUFVO0FBQ3BDLFNBQUtFLE9BQUw7QUFDQSxRQUFJOEQsVUFBVSxHQUFHMUUsVUFBVSxDQUFDeUYsSUFBWCxDQUFnQixFQUFoQixFQUFvQkUsS0FBcEIsRUFBakI7QUFDQSxRQUFJaEUsV0FBVyxHQUFHLEVBQWxCO0FBQ0FuQixXQUFPLENBQUNDLEdBQVIsQ0FBWSw2QkFBWjs7QUFDQSxTQUFLWCxDQUFMLElBQVU0RSxVQUFWLEVBQXFCO0FBQ2pCLFVBQUlBLFVBQVUsQ0FBQzVFLENBQUQsQ0FBVixDQUFjb0MsZ0JBQWxCLEVBQW1DO0FBQy9CLFlBQUloQyxHQUFHLEdBQUdHLEdBQUcsR0FBRyxzQkFBTixHQUE2QnFFLFVBQVUsQ0FBQzVFLENBQUQsQ0FBVixDQUFjb0MsZ0JBQTNDLEdBQTRELGNBQXRFOztBQUNBLFlBQUc7QUFDQyxjQUFJcEIsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmOztBQUNBLGNBQUlZLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQixnQkFBSThDLFVBQVUsR0FBR3JDLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE5QyxDQUQyQixDQUUzQjs7QUFDQVMsdUJBQVcsR0FBR0EsV0FBVyxDQUFDaVUsTUFBWixDQUFtQnhTLFVBQW5CLENBQWQ7QUFDSCxXQUpELE1BS0k7QUFDQTVDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWUssUUFBUSxDQUFDUixVQUFyQjtBQUNIO0FBQ0osU0FWRCxDQVdBLE9BQU9DLENBQVAsRUFBUztBQUNMQyxpQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKO0FBQ0o7O0FBRUQsU0FBSzhDLENBQUwsSUFBVTFCLFdBQVYsRUFBc0I7QUFDbEIsVUFBSUEsV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLElBQWtCMUIsV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLENBQWVkLE1BQXJDLEVBQ0laLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxDQUFlZCxNQUFmLEdBQXdCQyxVQUFVLENBQUNiLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxDQUFlZCxNQUFoQixDQUFsQztBQUNQLEtBNUJtQyxDQThCcEM7OztBQUNBLFFBQUlELElBQUksR0FBRztBQUNQWCxpQkFBVyxFQUFFQSxXQUROO0FBRVBrVSxlQUFTLEVBQUUsSUFBSTlTLElBQUo7QUFGSixLQUFYO0FBS0EsV0FBTzRTLFdBQVcsQ0FBQzFMLE1BQVosQ0FBbUIzSCxJQUFuQixDQUFQO0FBQ0gsR0F0Q1UsQ0F1Q1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBcERXLENBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSkExQyxNQUFNLENBQUNxUSxNQUFQLENBQWM7QUFBQzBGLGFBQVcsRUFBQyxNQUFJQTtBQUFqQixDQUFkO0FBQTZDLElBQUl6RixLQUFKO0FBQVV0USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNxUSxPQUFLLENBQUNwUSxDQUFELEVBQUc7QUFBQ29RLFNBQUssR0FBQ3BRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFaEQsTUFBTTZWLFdBQVcsR0FBRyxJQUFJekYsS0FBSyxDQUFDQyxVQUFWLENBQXFCLGFBQXJCLENBQXBCLEM7Ozs7Ozs7Ozs7O0FDRlAsSUFBSXhRLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUErQyxJQUFJZ1csVUFBSjtBQUFlbFcsTUFBTSxDQUFDQyxJQUFQLENBQVksa0JBQVosRUFBK0I7QUFBQ2lXLFlBQVUsQ0FBQ2hXLENBQUQsRUFBRztBQUFDZ1csY0FBVSxHQUFDaFcsQ0FBWDtBQUFhOztBQUE1QixDQUEvQixFQUE2RCxDQUE3RDtBQUl2SUgsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCxrQ0FBZ0MsWUFBVTtBQUN0QyxTQUFLRSxPQUFMOztBQUNBLFFBQUc7QUFDQyxVQUFJVixHQUFHLEdBQUdHLEdBQUcsR0FBRyxpQkFBaEI7QUFDQSxVQUFJUyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxVQUFJNlYsY0FBYyxHQUFHaFYsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQWxEO0FBRUEsVUFBSThVLHNCQUFzQixHQUFHLElBQUlDLEdBQUosQ0FBUUgsVUFBVSxDQUFDclEsSUFBWCxDQUNqQztBQUFDLGtCQUFTO0FBQUNRLGFBQUcsRUFBQyxDQUFDLFFBQUQsRUFBVyxVQUFYO0FBQUw7QUFBVixPQURpQyxFQUVuQ04sS0FGbUMsR0FFM0JFLEdBRjJCLENBRXRCbEIsQ0FBRCxJQUFNQSxDQUFDLENBQUN1UixJQUZlLENBQVIsQ0FBN0I7QUFJQSxVQUFJQyxLQUFLLEdBQUcsRUFBWjs7QUFFQSxVQUFJSixjQUFjLENBQUNyVSxNQUFmLEdBQXdCLENBQTVCLEVBQStCO0FBQzNCLGNBQU0wVSxPQUFPLEdBQUdOLFVBQVUsQ0FBQ3hQLGFBQVgsR0FBMkJvQyx5QkFBM0IsRUFBaEI7O0FBQ0EsYUFBSyxJQUFJckYsQ0FBVCxJQUFjMFMsY0FBZCxFQUE4QjtBQUMxQixjQUFJTSxFQUFFLEdBQUdOLGNBQWMsQ0FBQzFTLENBQUQsQ0FBdkI7QUFDQWdULFlBQUUsQ0FBQ0gsSUFBSCxHQUFVNUwsUUFBUSxDQUFDK0wsRUFBRSxDQUFDQyxFQUFKLENBQWxCOztBQUNBLGNBQUlELEVBQUUsQ0FBQ0gsSUFBSCxHQUFVLENBQVYsSUFBZSxDQUFDRixzQkFBc0IsQ0FBQ08sR0FBdkIsQ0FBMkJGLEVBQUUsQ0FBQ0gsSUFBOUIsQ0FBcEIsRUFBeUQ7QUFDckQsZ0JBQUk7QUFDQUUscUJBQU8sQ0FBQzNRLElBQVIsQ0FBYTtBQUFDeVEsb0JBQUksRUFBRUcsRUFBRSxDQUFDSDtBQUFWLGVBQWIsRUFBOEIvSyxNQUE5QixHQUF1Q0MsU0FBdkMsQ0FBaUQ7QUFBQ0Msb0JBQUksRUFBRWdMO0FBQVAsZUFBakQ7QUFDQUYsbUJBQUssQ0FBQzFNLElBQU4sQ0FBVzRNLEVBQUUsQ0FBQ0gsSUFBZDtBQUNILGFBSEQsQ0FHRSxPQUFNM1YsQ0FBTixFQUFTO0FBQ1A2VixxQkFBTyxDQUFDM1EsSUFBUixDQUFhO0FBQUN5USxvQkFBSSxFQUFFRyxFQUFFLENBQUNIO0FBQVYsZUFBYixFQUE4Qi9LLE1BQTlCLEdBQXVDQyxTQUF2QyxDQUFpRDtBQUFDQyxvQkFBSSxFQUFFZ0w7QUFBUCxlQUFqRDtBQUNBRixtQkFBSyxDQUFDMU0sSUFBTixDQUFXNE0sRUFBRSxDQUFDSCxJQUFkO0FBQ0ExVixxQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQUMsQ0FBQ08sUUFBRixDQUFXRyxPQUF2QjtBQUNIO0FBQ0o7QUFDSjs7QUFDRCxZQUFHa1YsS0FBSyxDQUFDelUsTUFBTixHQUFlLENBQWxCLEVBQXFCO0FBQ2pCMFUsaUJBQU8sQ0FBQ3pILE9BQVI7QUFDSDtBQUNKOztBQUNELGFBQU8sSUFBUDtBQUNILEtBaENELENBaUNBLE9BQU9wTyxDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKO0FBdkNVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNKQSxJQUFJWixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlnVyxVQUFKO0FBQWVsVyxNQUFNLENBQUNDLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDaVcsWUFBVSxDQUFDaFcsQ0FBRCxFQUFHO0FBQUNnVyxjQUFVLEdBQUNoVyxDQUFYO0FBQWE7O0FBQTVCLENBQS9CLEVBQTZELENBQTdEO0FBQWdFLElBQUkwVyxLQUFKO0FBQVU1VyxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMyVyxPQUFLLENBQUMxVyxDQUFELEVBQUc7QUFBQzBXLFNBQUssR0FBQzFXLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFJekpILE1BQU0sQ0FBQzBWLE9BQVAsQ0FBZSxxQkFBZixFQUFzQyxZQUFZO0FBQzlDLFNBQU9TLFVBQVUsQ0FBQ3JRLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0I7QUFBQ2lDLFFBQUksRUFBQztBQUFDd08sVUFBSSxFQUFDLENBQUM7QUFBUDtBQUFOLEdBQXBCLENBQVA7QUFDSCxDQUZEO0FBSUF2VyxNQUFNLENBQUMwVixPQUFQLENBQWUsbUJBQWYsRUFBb0MsVUFBVWlCLEVBQVYsRUFBYTtBQUM3Q0UsT0FBSyxDQUFDRixFQUFELEVBQUtHLE1BQUwsQ0FBTDtBQUNBLFNBQU9YLFVBQVUsQ0FBQ3JRLElBQVgsQ0FBZ0I7QUFBQ3lRLFFBQUksRUFBQ0k7QUFBTixHQUFoQixDQUFQO0FBQ0gsQ0FIRCxFOzs7Ozs7Ozs7OztBQ1JBMVcsTUFBTSxDQUFDcVEsTUFBUCxDQUFjO0FBQUM2RixZQUFVLEVBQUMsTUFBSUE7QUFBaEIsQ0FBZDtBQUEyQyxJQUFJNUYsS0FBSjtBQUFVdFEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDcVEsT0FBSyxDQUFDcFEsQ0FBRCxFQUFHO0FBQUNvUSxTQUFLLEdBQUNwUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRTlDLE1BQU1nVyxVQUFVLEdBQUcsSUFBSTVGLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixZQUFyQixDQUFuQixDOzs7Ozs7Ozs7OztBQ0ZQLElBQUl1RyxhQUFKOztBQUFrQjlXLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNDQUFaLEVBQW1EO0FBQUM4VyxTQUFPLENBQUM3VyxDQUFELEVBQUc7QUFBQzRXLGlCQUFhLEdBQUM1VyxDQUFkO0FBQWdCOztBQUE1QixDQUFuRCxFQUFpRixDQUFqRjtBQUFsQixJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBRVRILE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsd0JBQXNCLFVBQVNrVyxNQUFULEVBQWlCO0FBQ25DLFVBQU0xVyxHQUFHLGFBQU1HLEdBQU4sU0FBVDtBQUNBaUMsUUFBSSxHQUFHO0FBQ0gsWUFBTXNVLE1BQU0sQ0FBQ3ZWLEtBRFY7QUFFSCxjQUFRO0FBRkwsS0FBUDtBQUlBLFVBQU13VixTQUFTLEdBQUcsSUFBSTlULElBQUosR0FBV2tKLE9BQVgsRUFBbEI7QUFDQXpMLFdBQU8sQ0FBQ0MsR0FBUixpQ0FBcUNvVyxTQUFyQyxjQUFrRDNXLEdBQWxELHdCQUFtRWEsSUFBSSxDQUFDbUUsU0FBTCxDQUFlNUMsSUFBZixDQUFuRTtBQUVBLFFBQUl4QixRQUFRLEdBQUdmLElBQUksQ0FBQytXLElBQUwsQ0FBVTVXLEdBQVYsRUFBZTtBQUFDb0M7QUFBRCxLQUFmLENBQWY7QUFDQTlCLFdBQU8sQ0FBQ0MsR0FBUixtQ0FBdUNvVyxTQUF2QyxjQUFvRDNXLEdBQXBELGVBQTREYSxJQUFJLENBQUNtRSxTQUFMLENBQWVwRSxRQUFmLENBQTVEOztBQUNBLFFBQUlBLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUFnQztBQUM1QixVQUFJZ0MsSUFBSSxHQUFHeEIsUUFBUSxDQUFDd0IsSUFBcEI7QUFDQSxVQUFJQSxJQUFJLENBQUN5VSxJQUFULEVBQ0ksTUFBTSxJQUFJcFgsTUFBTSxDQUFDcVgsS0FBWCxDQUFpQjFVLElBQUksQ0FBQ3lVLElBQXRCLEVBQTRCaFcsSUFBSSxDQUFDQyxLQUFMLENBQVdzQixJQUFJLENBQUMyVSxPQUFoQixFQUF5QkMsT0FBckQsQ0FBTjtBQUNKLGFBQU9wVyxRQUFRLENBQUN3QixJQUFULENBQWM2VSxNQUFyQjtBQUNIO0FBQ0osR0FsQlU7QUFtQlgseUJBQXVCLFVBQVNDLElBQVQsRUFBZUMsSUFBZixFQUFxQjtBQUN4QyxVQUFNblgsR0FBRyxhQUFNRyxHQUFOLGNBQWFnWCxJQUFiLENBQVQ7QUFDQS9VLFFBQUksR0FBRztBQUNILG9DQUNPOFUsSUFEUDtBQUVJLG9CQUFZelgsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI0RSxPQUZ2QztBQUdJLG9CQUFZO0FBSGhCO0FBREcsS0FBUDtBQU9BLFFBQUkxSyxRQUFRLEdBQUdmLElBQUksQ0FBQytXLElBQUwsQ0FBVTVXLEdBQVYsRUFBZTtBQUFDb0M7QUFBRCxLQUFmLENBQWY7O0FBQ0EsUUFBSXhCLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUFnQztBQUM1QixhQUFPUyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFQO0FBQ0g7QUFDSixHQWhDVTtBQWlDWCwwQkFBd0IsVUFBU3FXLEtBQVQsRUFBZ0J4TixJQUFoQixFQUFzQnVOLElBQXRCLEVBQThDO0FBQUEsUUFBbEJFLFVBQWtCLHVFQUFQLEtBQU87QUFDbEUsVUFBTXJYLEdBQUcsYUFBTUcsR0FBTixjQUFhZ1gsSUFBYixDQUFUO0FBQ0EvVSxRQUFJLHFCQUFPZ1YsS0FBUDtBQUNBLGtCQUFZO0FBQ1IsZ0JBQVF4TixJQURBO0FBRVIsb0JBQVluSyxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjRFLE9BRjNCO0FBR1IsMEJBQWtCK0wsVUFIVjtBQUlSLG9CQUFZO0FBSko7QUFEWixNQUFKO0FBUUEsUUFBSXpXLFFBQVEsR0FBR2YsSUFBSSxDQUFDK1csSUFBTCxDQUFVNVcsR0FBVixFQUFlO0FBQUNvQztBQUFELEtBQWYsQ0FBZjs7QUFDQSxRQUFJeEIsUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQWdDO0FBQzVCLGFBQU9TLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCdVcsWUFBcEM7QUFDSDtBQUNKO0FBL0NVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNGQSxJQUFJN1gsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJb1EsS0FBSjtBQUFVdFEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDcVEsT0FBSyxDQUFDcFEsQ0FBRCxFQUFHO0FBQUNvUSxTQUFLLEdBQUNwUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlpRSxnQkFBSixFQUFxQkMsU0FBckIsRUFBK0J5VCxXQUEvQixFQUEyQ0Msb0JBQTNDO0FBQWdFOVgsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDa0Usa0JBQWdCLENBQUNqRSxDQUFELEVBQUc7QUFBQ2lFLG9CQUFnQixHQUFDakUsQ0FBakI7QUFBbUIsR0FBeEM7O0FBQXlDa0UsV0FBUyxDQUFDbEUsQ0FBRCxFQUFHO0FBQUNrRSxhQUFTLEdBQUNsRSxDQUFWO0FBQVksR0FBbEU7O0FBQW1FMlgsYUFBVyxDQUFDM1gsQ0FBRCxFQUFHO0FBQUMyWCxlQUFXLEdBQUMzWCxDQUFaO0FBQWMsR0FBaEc7O0FBQWlHNFgsc0JBQW9CLENBQUM1WCxDQUFELEVBQUc7QUFBQzRYLHdCQUFvQixHQUFDNVgsQ0FBckI7QUFBdUI7O0FBQWhKLENBQTVCLEVBQThLLENBQTlLO0FBQWlMLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBQThFLElBQUlnRSxhQUFKO0FBQWtCbEUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0NBQVosRUFBNEQ7QUFBQ2lFLGVBQWEsQ0FBQ2hFLENBQUQsRUFBRztBQUFDZ0UsaUJBQWEsR0FBQ2hFLENBQWQ7QUFBZ0I7O0FBQWxDLENBQTVELEVBQWdHLENBQWhHO0FBQW1HLElBQUk2WCxNQUFKO0FBQVcvWCxNQUFNLENBQUNDLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDOFgsUUFBTSxDQUFDN1gsQ0FBRCxFQUFHO0FBQUM2WCxVQUFNLEdBQUM3WCxDQUFQO0FBQVM7O0FBQXBCLENBQXJDLEVBQTJELENBQTNEO0FBQThELElBQUk4WCxpQkFBSjtBQUFzQmhZLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQytYLG1CQUFpQixDQUFDOVgsQ0FBRCxFQUFHO0FBQUM4WCxxQkFBaUIsR0FBQzlYLENBQWxCO0FBQW9COztBQUExQyxDQUE1QixFQUF3RSxDQUF4RTtBQUEyRSxJQUFJK1gsWUFBSjtBQUFpQmpZLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ2dZLGNBQVksQ0FBQy9YLENBQUQsRUFBRztBQUFDK1gsZ0JBQVksR0FBQy9YLENBQWI7QUFBZTs7QUFBaEMsQ0FBNUIsRUFBOEQsQ0FBOUQ7QUFBaUUsSUFBSThELFNBQUo7QUFBY2hFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdCQUFaLEVBQXFDO0FBQUMrRCxXQUFTLENBQUM5RCxDQUFELEVBQUc7QUFBQzhELGFBQVMsR0FBQzlELENBQVY7QUFBWTs7QUFBMUIsQ0FBckMsRUFBaUUsQ0FBakU7QUFBb0UsSUFBSStELEtBQUo7QUFBVWpFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUNnRSxPQUFLLENBQUMvRCxDQUFELEVBQUc7QUFBQytELFNBQUssR0FBQy9ELENBQU47QUFBUTs7QUFBbEIsQ0FBbkMsRUFBdUQsQ0FBdkQ7O0FBQTBELElBQUlnWSxDQUFKOztBQUFNbFksTUFBTSxDQUFDQyxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDOFcsU0FBTyxDQUFDN1csQ0FBRCxFQUFHO0FBQUNnWSxLQUFDLEdBQUNoWSxDQUFGO0FBQUk7O0FBQWhCLENBQXJCLEVBQXVDLEVBQXZDO0FBV3Y5QixNQUFNaVksaUJBQWlCLEdBQUcsSUFBMUI7O0FBRUEsTUFBTUMsYUFBYSxHQUFHLENBQUNwUSxXQUFELEVBQWNxUSxZQUFkLEtBQStCO0FBQ2pELE1BQUlDLFVBQVUsR0FBRyxFQUFqQjtBQUNBLFFBQU1DLElBQUksR0FBRztBQUFDQyxRQUFJLEVBQUUsQ0FDaEI7QUFBRXJTLFlBQU0sRUFBRTtBQUFFc1MsV0FBRyxFQUFFelE7QUFBUDtBQUFWLEtBRGdCLEVBRWhCO0FBQUU3QixZQUFNLEVBQUU7QUFBRXVTLFlBQUksRUFBRUw7QUFBUjtBQUFWLEtBRmdCO0FBQVAsR0FBYjtBQUdBLFFBQU1NLE9BQU8sR0FBRztBQUFDN1EsUUFBSSxFQUFDO0FBQUMzQixZQUFNLEVBQUU7QUFBVDtBQUFOLEdBQWhCO0FBQ0FuQyxXQUFTLENBQUM2QixJQUFWLENBQWUwUyxJQUFmLEVBQXFCSSxPQUFyQixFQUE4QjVWLE9BQTlCLENBQXVDbUQsS0FBRCxJQUFXO0FBQzdDb1MsY0FBVSxDQUFDcFMsS0FBSyxDQUFDQyxNQUFQLENBQVYsR0FBMkI7QUFDdkJBLFlBQU0sRUFBRUQsS0FBSyxDQUFDQyxNQURTO0FBRXZCTCxxQkFBZSxFQUFFSSxLQUFLLENBQUNKLGVBRkE7QUFHdkJ3RSxxQkFBZSxFQUFFcEUsS0FBSyxDQUFDb0UsZUFIQTtBQUl2QksscUJBQWUsRUFBRXpFLEtBQUssQ0FBQ3lFLGVBSkE7QUFLdkI3RixnQkFBVSxFQUFFb0IsS0FBSyxDQUFDcEIsVUFMSztBQU12QjVCLFVBQUksRUFBRWdELEtBQUssQ0FBQ2hEO0FBTlcsS0FBM0I7QUFRSCxHQVREO0FBV0FrQixXQUFTLENBQUN5QixJQUFWLENBQWUwUyxJQUFmLEVBQXFCSSxPQUFyQixFQUE4QjVWLE9BQTlCLENBQXVDbUQsS0FBRCxJQUFXO0FBQzdDLFFBQUksQ0FBQ29TLFVBQVUsQ0FBQ3BTLEtBQUssQ0FBQ0MsTUFBUCxDQUFmLEVBQStCO0FBQzNCbVMsZ0JBQVUsQ0FBQ3BTLEtBQUssQ0FBQ0MsTUFBUCxDQUFWLEdBQTJCO0FBQUVBLGNBQU0sRUFBRUQsS0FBSyxDQUFDQztBQUFoQixPQUEzQjtBQUNBdkYsYUFBTyxDQUFDQyxHQUFSLGlCQUFxQnFGLEtBQUssQ0FBQ0MsTUFBM0I7QUFDSDs7QUFDRCtSLEtBQUMsQ0FBQ1UsTUFBRixDQUFTTixVQUFVLENBQUNwUyxLQUFLLENBQUNDLE1BQVAsQ0FBbkIsRUFBbUM7QUFDL0J3RCxnQkFBVSxFQUFFekQsS0FBSyxDQUFDeUQsVUFEYTtBQUUvQjZDLHNCQUFnQixFQUFFdEcsS0FBSyxDQUFDc0csZ0JBRk87QUFHL0JoRyxjQUFRLEVBQUVOLEtBQUssQ0FBQ00sUUFIZTtBQUkvQjBFLGtCQUFZLEVBQUVoRixLQUFLLENBQUNnRjtBQUpXLEtBQW5DO0FBTUgsR0FYRDtBQVlBLFNBQU9vTixVQUFQO0FBQ0gsQ0E5QkQ7O0FBZ0NBLE1BQU1PLGlCQUFpQixHQUFHLENBQUNDLFlBQUQsRUFBZWhULGVBQWYsS0FBbUM7QUFDekQsTUFBSWlULGNBQWMsR0FBR2QsWUFBWSxDQUFDN1YsT0FBYixDQUNqQjtBQUFDNFcsU0FBSyxFQUFDRixZQUFQO0FBQXFCckksWUFBUSxFQUFDM0ssZUFBOUI7QUFBK0NtVCxlQUFXLEVBQUUsQ0FBQztBQUE3RCxHQURpQixDQUFyQjtBQUVBLE1BQUlDLGlCQUFpQixHQUFHblosTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCRCxXQUEvQztBQUNBLE1BQUltUixTQUFTLEdBQUcsRUFBaEI7O0FBQ0EsTUFBSUosY0FBSixFQUFvQjtBQUNoQkksYUFBUyxHQUFHakIsQ0FBQyxDQUFDa0IsSUFBRixDQUFPTCxjQUFQLEVBQXVCLENBQUMsV0FBRCxFQUFjLFlBQWQsQ0FBdkIsQ0FBWjtBQUNILEdBRkQsTUFFTztBQUNISSxhQUFTLEdBQUc7QUFDUkUsZUFBUyxFQUFFLENBREg7QUFFUkMsZ0JBQVUsRUFBRTtBQUZKLEtBQVo7QUFJSDs7QUFDRCxTQUFPSCxTQUFQO0FBQ0gsQ0FkRDs7QUFnQkFwWixNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLDRDQUEwQyxZQUFVO0FBQ2hELFFBQUksQ0FBQ3lZLGlCQUFMLEVBQXVCO0FBQ25CLFVBQUk7QUFDQSxZQUFJQyxTQUFTLEdBQUdyVyxJQUFJLENBQUMwUyxHQUFMLEVBQWhCO0FBQ0EwRCx5QkFBaUIsR0FBRyxJQUFwQjtBQUNBM1ksZUFBTyxDQUFDQyxHQUFSLENBQVksOEJBQVo7QUFDQSxhQUFLRyxPQUFMO0FBQ0EsWUFBSThELFVBQVUsR0FBRzFFLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0JFLEtBQXBCLEVBQWpCO0FBQ0EsWUFBSXNTLFlBQVksR0FBR3RZLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSx5QkFBWixDQUFuQjtBQUNBLFlBQUlxUixjQUFjLEdBQUcxQixNQUFNLENBQUMzVixPQUFQLENBQWU7QUFBQ3dKLGlCQUFPLEVBQUU3TCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjRFO0FBQWpDLFNBQWYsQ0FBckI7QUFDQSxZQUFJNUQsV0FBVyxHQUFJeVIsY0FBYyxJQUFFQSxjQUFjLENBQUNDLDhCQUFoQyxHQUFnRUQsY0FBYyxDQUFDQyw4QkFBL0UsR0FBOEczWixNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUJELFdBQXZKO0FBQ0FxUSxvQkFBWSxHQUFHbE0sSUFBSSxDQUFDd04sR0FBTCxDQUFTM1IsV0FBVyxHQUFHbVEsaUJBQXZCLEVBQTBDRSxZQUExQyxDQUFmO0FBQ0EsY0FBTXVCLGVBQWUsR0FBRzNCLFlBQVksQ0FBQ3ZSLGFBQWIsR0FBNkJtVCx1QkFBN0IsRUFBeEI7QUFFQSxZQUFJQyxhQUFhLEdBQUcsRUFBcEI7QUFDQWhWLGtCQUFVLENBQUMvQixPQUFYLENBQW9CWixTQUFELElBQWUyWCxhQUFhLENBQUMzWCxTQUFTLENBQUNwQixPQUFYLENBQWIsR0FBbUNvQixTQUFyRSxFQWJBLENBZUE7O0FBQ0EsWUFBSW1XLFVBQVUsR0FBR0YsYUFBYSxDQUFDcFEsV0FBRCxFQUFjcVEsWUFBZCxDQUE5QixDQWhCQSxDQWtCQTs7QUFDQSxZQUFJMEIsa0JBQWtCLEdBQUcsRUFBekI7O0FBRUE3QixTQUFDLENBQUNuVixPQUFGLENBQVV1VixVQUFWLEVBQXNCLENBQUNwUyxLQUFELEVBQVErUyxXQUFSLEtBQXdCO0FBQzFDLGNBQUluVCxlQUFlLEdBQUdJLEtBQUssQ0FBQ0osZUFBNUI7QUFDQSxjQUFJa1UsZUFBZSxHQUFHLElBQUkzRCxHQUFKLENBQVFuUSxLQUFLLENBQUNwQixVQUFkLENBQXRCO0FBQ0EsY0FBSW1WLGFBQWEsR0FBRy9WLGFBQWEsQ0FBQzlCLE9BQWQsQ0FBc0I7QUFBQ3FJLHdCQUFZLEVBQUN2RSxLQUFLLENBQUNDO0FBQXBCLFdBQXRCLENBQXBCO0FBQ0EsY0FBSStULGdCQUFnQixHQUFHLENBQXZCO0FBRUFELHVCQUFhLENBQUNuVixVQUFkLENBQXlCL0IsT0FBekIsQ0FBa0NvWCxlQUFELElBQXFCO0FBQ2xELGdCQUFJSCxlQUFlLENBQUNyRCxHQUFoQixDQUFvQndELGVBQWUsQ0FBQ3BaLE9BQXBDLENBQUosRUFDSW1aLGdCQUFnQixJQUFJdFgsVUFBVSxDQUFDdVgsZUFBZSxDQUFDalAsWUFBakIsQ0FBOUI7QUFDUCxXQUhEO0FBS0ErTyx1QkFBYSxDQUFDblYsVUFBZCxDQUF5Qi9CLE9BQXpCLENBQWtDb1gsZUFBRCxJQUFxQjtBQUNsRCxnQkFBSUMsZ0JBQWdCLEdBQUdELGVBQWUsQ0FBQ3BaLE9BQXZDOztBQUNBLGdCQUFJLENBQUNtWCxDQUFDLENBQUN2QixHQUFGLENBQU1vRCxrQkFBTixFQUEwQixDQUFDalUsZUFBRCxFQUFrQnNVLGdCQUFsQixDQUExQixDQUFMLEVBQXFFO0FBQ2pFLGtCQUFJakIsU0FBUyxHQUFHTixpQkFBaUIsQ0FBQ3VCLGdCQUFELEVBQW1CdFUsZUFBbkIsQ0FBakM7O0FBQ0FvUyxlQUFDLENBQUNtQyxHQUFGLENBQU1OLGtCQUFOLEVBQTBCLENBQUNqVSxlQUFELEVBQWtCc1UsZ0JBQWxCLENBQTFCLEVBQStEakIsU0FBL0Q7QUFDSDs7QUFFRGpCLGFBQUMsQ0FBQzNMLE1BQUYsQ0FBU3dOLGtCQUFULEVBQTZCLENBQUNqVSxlQUFELEVBQWtCc1UsZ0JBQWxCLEVBQW9DLFlBQXBDLENBQTdCLEVBQWlGRSxDQUFELElBQU9BLENBQUMsR0FBQyxDQUF6Rjs7QUFDQSxnQkFBSSxDQUFDTixlQUFlLENBQUNyRCxHQUFoQixDQUFvQnlELGdCQUFwQixDQUFMLEVBQTRDO0FBQ3hDbEMsZUFBQyxDQUFDM0wsTUFBRixDQUFTd04sa0JBQVQsRUFBNkIsQ0FBQ2pVLGVBQUQsRUFBa0JzVSxnQkFBbEIsRUFBb0MsV0FBcEMsQ0FBN0IsRUFBZ0ZFLENBQUQsSUFBT0EsQ0FBQyxHQUFDLENBQXhGOztBQUNBViw2QkFBZSxDQUFDdlAsTUFBaEIsQ0FBdUI7QUFDbkIyTyxxQkFBSyxFQUFFb0IsZ0JBRFk7QUFFbkJuQiwyQkFBVyxFQUFFL1MsS0FBSyxDQUFDQyxNQUZBO0FBR25Cc0ssd0JBQVEsRUFBRTNLLGVBSFM7QUFJbkJ3RSwrQkFBZSxFQUFFcEUsS0FBSyxDQUFDb0UsZUFKSjtBQUtuQkssK0JBQWUsRUFBRXpFLEtBQUssQ0FBQ3lFLGVBTEo7QUFNbkJ6SCxvQkFBSSxFQUFFZ0QsS0FBSyxDQUFDaEQsSUFOTztBQU9uQnlHLDBCQUFVLEVBQUV6RCxLQUFLLENBQUN5RCxVQVBDO0FBUW5CNkMsZ0NBQWdCLEVBQUV0RyxLQUFLLENBQUNzRyxnQkFSTDtBQVNuQmhHLHdCQUFRLEVBQUVOLEtBQUssQ0FBQ00sUUFURztBQVVuQitULDJCQUFXLEVBQUVyVSxLQUFLLENBQUNnRixZQVZBO0FBV25CZ1AsZ0NBWG1CO0FBWW5CTSx5QkFBUyxFQUFFbkMsWUFaUTtBQWFuQmdCLHlCQUFTLEVBQUVuQixDQUFDLENBQUMxWCxHQUFGLENBQU11WixrQkFBTixFQUEwQixDQUFDalUsZUFBRCxFQUFrQnNVLGdCQUFsQixFQUFvQyxXQUFwQyxDQUExQixDQWJRO0FBY25CZCwwQkFBVSxFQUFFcEIsQ0FBQyxDQUFDMVgsR0FBRixDQUFNdVosa0JBQU4sRUFBMEIsQ0FBQ2pVLGVBQUQsRUFBa0JzVSxnQkFBbEIsRUFBb0MsWUFBcEMsQ0FBMUI7QUFkTyxlQUF2QjtBQWdCSDtBQUNKLFdBM0JEO0FBNEJILFNBdkNEOztBQXlDQWxDLFNBQUMsQ0FBQ25WLE9BQUYsQ0FBVWdYLGtCQUFWLEVBQThCLENBQUNVLE1BQUQsRUFBUzNVLGVBQVQsS0FBNkI7QUFDdkRvUyxXQUFDLENBQUNuVixPQUFGLENBQVUwWCxNQUFWLEVBQWtCLENBQUNDLEtBQUQsRUFBUTVCLFlBQVIsS0FBeUI7QUFDdkNjLDJCQUFlLENBQUMvVCxJQUFoQixDQUFxQjtBQUNqQm1ULG1CQUFLLEVBQUVGLFlBRFU7QUFFakJySSxzQkFBUSxFQUFFM0ssZUFGTztBQUdqQm1ULHlCQUFXLEVBQUUsQ0FBQztBQUhHLGFBQXJCLEVBSUcxTixNQUpILEdBSVlDLFNBSlosQ0FJc0I7QUFBQ0Msa0JBQUksRUFBRTtBQUN6QnVOLHFCQUFLLEVBQUVGLFlBRGtCO0FBRXpCckksd0JBQVEsRUFBRTNLLGVBRmU7QUFHekJtVCwyQkFBVyxFQUFFLENBQUMsQ0FIVztBQUl6QnVCLHlCQUFTLEVBQUVuQyxZQUpjO0FBS3pCZ0IseUJBQVMsRUFBRW5CLENBQUMsQ0FBQzFYLEdBQUYsQ0FBTWthLEtBQU4sRUFBYSxXQUFiLENBTGM7QUFNekJwQiwwQkFBVSxFQUFFcEIsQ0FBQyxDQUFDMVgsR0FBRixDQUFNa2EsS0FBTixFQUFhLFlBQWI7QUFOYTtBQUFQLGFBSnRCO0FBWUgsV0FiRDtBQWNILFNBZkQ7O0FBaUJBLFlBQUlwRCxPQUFPLEdBQUcsRUFBZDs7QUFDQSxZQUFJc0MsZUFBZSxDQUFDOVgsTUFBaEIsR0FBeUIsQ0FBN0IsRUFBK0I7QUFDM0IsZ0JBQU02WSxNQUFNLEdBQUcxQyxZQUFZLENBQUMyQyxPQUFiLENBQXFCQyxLQUFyQixDQUEyQkYsTUFBMUMsQ0FEMkIsQ0FFM0I7QUFDQTtBQUNBOztBQUNBLGNBQUlHLFdBQVcsR0FBR2xCLGVBQWUsQ0FBQzdLLE9BQWhCLENBQXdCO0FBQUk7QUFBNUIsWUFBNkNnTSxJQUE3QyxDQUNkaGIsTUFBTSxDQUFDaWIsZUFBUCxDQUF1QixDQUFDMVosTUFBRCxFQUFTNkksR0FBVCxLQUFpQjtBQUNwQyxnQkFBSUEsR0FBSixFQUFRO0FBQ0pvUCwrQkFBaUIsR0FBRyxLQUFwQixDQURJLENBRUo7O0FBQ0Esb0JBQU1wUCxHQUFOO0FBQ0g7O0FBQ0QsZ0JBQUk3SSxNQUFKLEVBQVc7QUFDUDtBQUNBZ1cscUJBQU8sR0FBRyxXQUFJaFcsTUFBTSxDQUFDQSxNQUFQLENBQWMyWixTQUFsQiw2QkFDSTNaLE1BQU0sQ0FBQ0EsTUFBUCxDQUFjNFosU0FEbEIsNkJBRUk1WixNQUFNLENBQUNBLE1BQVAsQ0FBYzZaLFNBRmxCLGVBQVY7QUFHSDtBQUNKLFdBWkQsQ0FEYyxDQUFsQjtBQWVBcFgsaUJBQU8sQ0FBQ3VELEtBQVIsQ0FBY3dULFdBQWQ7QUFDSDs7QUFFRHZCLHlCQUFpQixHQUFHLEtBQXBCO0FBQ0F4QixjQUFNLENBQUN4TSxNQUFQLENBQWM7QUFBQ0ssaUJBQU8sRUFBRTdMLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNEU7QUFBakMsU0FBZCxFQUF5RDtBQUFDSCxjQUFJLEVBQUM7QUFBQ2lPLDBDQUE4QixFQUFDckIsWUFBaEM7QUFBOEMrQyx3Q0FBNEIsRUFBRSxJQUFJalksSUFBSjtBQUE1RTtBQUFOLFNBQXpEO0FBQ0EsaUNBQWtCQSxJQUFJLENBQUMwUyxHQUFMLEtBQWEyRCxTQUEvQixnQkFBOENsQyxPQUE5QztBQUNILE9BMUdELENBMEdFLE9BQU8zVyxDQUFQLEVBQVU7QUFDUjRZLHlCQUFpQixHQUFHLEtBQXBCO0FBQ0EsY0FBTTVZLENBQU47QUFDSDtBQUNKLEtBL0dELE1BZ0hJO0FBQ0EsYUFBTyxhQUFQO0FBQ0g7QUFDSixHQXJIVTtBQXNIWCxpREFBK0MsWUFBVTtBQUNyRDtBQUNBO0FBQ0EsUUFBSSxDQUFDMGEsc0JBQUwsRUFBNEI7QUFDeEJBLDRCQUFzQixHQUFHLElBQXpCO0FBQ0F6YSxhQUFPLENBQUNDLEdBQVIsQ0FBWSw4QkFBWjtBQUNBLFdBQUtHLE9BQUw7QUFDQSxVQUFJOEQsVUFBVSxHQUFHMUUsVUFBVSxDQUFDeUYsSUFBWCxDQUFnQixFQUFoQixFQUFvQkUsS0FBcEIsRUFBakI7QUFDQSxVQUFJc1MsWUFBWSxHQUFHdFksTUFBTSxDQUFDcUksSUFBUCxDQUFZLHlCQUFaLENBQW5CO0FBQ0EsVUFBSXFSLGNBQWMsR0FBRzFCLE1BQU0sQ0FBQzNWLE9BQVAsQ0FBZTtBQUFDd0osZUFBTyxFQUFFN0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI0RTtBQUFqQyxPQUFmLENBQXJCO0FBQ0EsVUFBSTVELFdBQVcsR0FBSXlSLGNBQWMsSUFBRUEsY0FBYyxDQUFDNkIscUJBQWhDLEdBQXVEN0IsY0FBYyxDQUFDNkIscUJBQXRFLEdBQTRGdmIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCRCxXQUFySSxDQVB3QixDQVF4QjtBQUNBOztBQUNBLFlBQU00UixlQUFlLEdBQUc1QixpQkFBaUIsQ0FBQ3RSLGFBQWxCLEdBQWtDb0MseUJBQWxDLEVBQXhCOztBQUNBLFdBQUtyRixDQUFMLElBQVVxQixVQUFWLEVBQXFCO0FBQ2pCO0FBQ0EsWUFBSWdVLFlBQVksR0FBR2hVLFVBQVUsQ0FBQ3JCLENBQUQsQ0FBVixDQUFjMUMsT0FBakM7QUFDQSxZQUFJd2EsYUFBYSxHQUFHcFgsZ0JBQWdCLENBQUMwQixJQUFqQixDQUFzQjtBQUN0QzlFLGlCQUFPLEVBQUMrWCxZQUQ4QjtBQUV0QzdOLGdCQUFNLEVBQUMsS0FGK0I7QUFHdEN1TixjQUFJLEVBQUUsQ0FBRTtBQUFFclMsa0JBQU0sRUFBRTtBQUFFc1MsaUJBQUcsRUFBRXpRO0FBQVA7QUFBVixXQUFGLEVBQW9DO0FBQUU3QixrQkFBTSxFQUFFO0FBQUV1UyxrQkFBSSxFQUFFTDtBQUFSO0FBQVYsV0FBcEM7QUFIZ0MsU0FBdEIsRUFJakJ0UyxLQUppQixFQUFwQjtBQU1BLFlBQUl5VixNQUFNLEdBQUcsRUFBYixDQVRpQixDQVdqQjs7QUFDQSxhQUFLalYsQ0FBTCxJQUFVZ1YsYUFBVixFQUF3QjtBQUNwQixjQUFJclYsS0FBSyxHQUFHbEMsU0FBUyxDQUFDNUIsT0FBVixDQUFrQjtBQUFDK0Qsa0JBQU0sRUFBQ29WLGFBQWEsQ0FBQ2hWLENBQUQsQ0FBYixDQUFpQko7QUFBekIsV0FBbEIsQ0FBWjtBQUNBLGNBQUlzVixjQUFjLEdBQUd6RCxpQkFBaUIsQ0FBQzVWLE9BQWxCLENBQTBCO0FBQUM0VyxpQkFBSyxFQUFDRixZQUFQO0FBQXFCckksb0JBQVEsRUFBQ3ZLLEtBQUssQ0FBQ0o7QUFBcEMsV0FBMUIsQ0FBckI7O0FBRUEsY0FBSSxPQUFPMFYsTUFBTSxDQUFDdFYsS0FBSyxDQUFDSixlQUFQLENBQWIsS0FBeUMsV0FBN0MsRUFBeUQ7QUFDckQsZ0JBQUkyVixjQUFKLEVBQW1CO0FBQ2ZELG9CQUFNLENBQUN0VixLQUFLLENBQUNKLGVBQVAsQ0FBTixHQUFnQzJWLGNBQWMsQ0FBQzNYLEtBQWYsR0FBcUIsQ0FBckQ7QUFDSCxhQUZELE1BR0k7QUFDQTBYLG9CQUFNLENBQUN0VixLQUFLLENBQUNKLGVBQVAsQ0FBTixHQUFnQyxDQUFoQztBQUNIO0FBQ0osV0FQRCxNQVFJO0FBQ0EwVixrQkFBTSxDQUFDdFYsS0FBSyxDQUFDSixlQUFQLENBQU47QUFDSDtBQUNKOztBQUVELGFBQUsvRSxPQUFMLElBQWdCeWEsTUFBaEIsRUFBdUI7QUFDbkIsY0FBSTlZLElBQUksR0FBRztBQUNQc1csaUJBQUssRUFBRUYsWUFEQTtBQUVQckksb0JBQVEsRUFBQzFQLE9BRkY7QUFHUCtDLGlCQUFLLEVBQUUwWCxNQUFNLENBQUN6YSxPQUFEO0FBSE4sV0FBWDtBQU1BNlkseUJBQWUsQ0FBQy9ULElBQWhCLENBQXFCO0FBQUNtVCxpQkFBSyxFQUFDRixZQUFQO0FBQXFCckksb0JBQVEsRUFBQzFQO0FBQTlCLFdBQXJCLEVBQTZEd0ssTUFBN0QsR0FBc0VDLFNBQXRFLENBQWdGO0FBQUNDLGdCQUFJLEVBQUMvSTtBQUFOLFdBQWhGO0FBQ0gsU0FyQ2dCLENBc0NqQjs7QUFFSDs7QUFFRCxVQUFJa1gsZUFBZSxDQUFDOVgsTUFBaEIsR0FBeUIsQ0FBN0IsRUFBK0I7QUFDM0I4WCx1QkFBZSxDQUFDN0ssT0FBaEIsQ0FBd0JoUCxNQUFNLENBQUNpYixlQUFQLENBQXVCLENBQUM3USxHQUFELEVBQU03SSxNQUFOLEtBQWlCO0FBQzVELGNBQUk2SSxHQUFKLEVBQVE7QUFDSmtSLGtDQUFzQixHQUFHLEtBQXpCO0FBQ0F6YSxtQkFBTyxDQUFDQyxHQUFSLENBQVlzSixHQUFaO0FBQ0g7O0FBQ0QsY0FBSTdJLE1BQUosRUFBVztBQUNQeVcsa0JBQU0sQ0FBQ3hNLE1BQVAsQ0FBYztBQUFDSyxxQkFBTyxFQUFFN0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI0RTtBQUFqQyxhQUFkLEVBQXlEO0FBQUNILGtCQUFJLEVBQUM7QUFBQzZQLHFDQUFxQixFQUFDakQsWUFBdkI7QUFBcUNxRCxtQ0FBbUIsRUFBRSxJQUFJdlksSUFBSjtBQUExRDtBQUFOLGFBQXpEO0FBQ0FrWSxrQ0FBc0IsR0FBRyxLQUF6QjtBQUNBemEsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFDSDtBQUNKLFNBVnVCLENBQXhCO0FBV0gsT0FaRCxNQWFJO0FBQ0F3YSw4QkFBc0IsR0FBRyxLQUF6QjtBQUNIOztBQUVELGFBQU8sSUFBUDtBQUNILEtBdkVELE1Bd0VJO0FBQ0EsYUFBTyxhQUFQO0FBQ0g7QUFDSixHQXBNVTtBQXFNWCxnREFBOEMsVUFBU25ZLElBQVQsRUFBYztBQUN4RCxTQUFLbEMsT0FBTDtBQUNBLFFBQUk2VSxHQUFHLEdBQUcsSUFBSTFTLElBQUosRUFBVjs7QUFFQSxRQUFJRCxJQUFJLElBQUksR0FBWixFQUFnQjtBQUNaLFVBQUlzSixnQkFBZ0IsR0FBRyxDQUF2QjtBQUNBLFVBQUltUCxrQkFBa0IsR0FBRyxDQUF6QjtBQUVBLFVBQUlDLFNBQVMsR0FBR3hYLFNBQVMsQ0FBQ3lCLElBQVYsQ0FBZTtBQUFFLGdCQUFRO0FBQUU0UyxhQUFHLEVBQUUsSUFBSXRWLElBQUosQ0FBU0EsSUFBSSxDQUFDMFMsR0FBTCxLQUFhLEtBQUssSUFBM0I7QUFBUDtBQUFWLE9BQWYsRUFBc0U5UCxLQUF0RSxFQUFoQjs7QUFDQSxVQUFJNlYsU0FBUyxDQUFDOVosTUFBVixHQUFtQixDQUF2QixFQUF5QjtBQUNyQixhQUFLMkIsQ0FBTCxJQUFVbVksU0FBVixFQUFvQjtBQUNoQnBQLDBCQUFnQixJQUFJb1AsU0FBUyxDQUFDblksQ0FBRCxDQUFULENBQWErQyxRQUFqQztBQUNBbVYsNEJBQWtCLElBQUlDLFNBQVMsQ0FBQ25ZLENBQUQsQ0FBVCxDQUFheUgsWUFBbkM7QUFDSDs7QUFDRHNCLHdCQUFnQixHQUFHQSxnQkFBZ0IsR0FBR29QLFNBQVMsQ0FBQzlaLE1BQWhEO0FBQ0E2WiwwQkFBa0IsR0FBR0Esa0JBQWtCLEdBQUdDLFNBQVMsQ0FBQzlaLE1BQXBEO0FBRUFtQyxhQUFLLENBQUNzSSxNQUFOLENBQWE7QUFBQ1gsaUJBQU8sRUFBQzdMLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNEU7QUFBaEMsU0FBYixFQUFzRDtBQUFDSCxjQUFJLEVBQUM7QUFBQ29RLGlDQUFxQixFQUFDRixrQkFBdkI7QUFBMkNHLCtCQUFtQixFQUFDdFA7QUFBL0Q7QUFBTixTQUF0RDtBQUNBcUwsbUJBQVcsQ0FBQ3hOLE1BQVosQ0FBbUI7QUFDZm1DLDBCQUFnQixFQUFFQSxnQkFESDtBQUVmbVAsNEJBQWtCLEVBQUVBLGtCQUZMO0FBR2ZuYSxjQUFJLEVBQUUwQixJQUhTO0FBSWYrUyxtQkFBUyxFQUFFSjtBQUpJLFNBQW5CO0FBTUg7QUFDSjs7QUFDRCxRQUFJM1MsSUFBSSxJQUFJLEdBQVosRUFBZ0I7QUFDWixVQUFJc0osZ0JBQWdCLEdBQUcsQ0FBdkI7QUFDQSxVQUFJbVAsa0JBQWtCLEdBQUcsQ0FBekI7QUFDQSxVQUFJQyxTQUFTLEdBQUd4WCxTQUFTLENBQUN5QixJQUFWLENBQWU7QUFBRSxnQkFBUTtBQUFFNFMsYUFBRyxFQUFFLElBQUl0VixJQUFKLENBQVNBLElBQUksQ0FBQzBTLEdBQUwsS0FBYSxLQUFHLEVBQUgsR0FBUSxJQUE5QjtBQUFQO0FBQVYsT0FBZixFQUF5RTlQLEtBQXpFLEVBQWhCOztBQUNBLFVBQUk2VixTQUFTLENBQUM5WixNQUFWLEdBQW1CLENBQXZCLEVBQXlCO0FBQ3JCLGFBQUsyQixDQUFMLElBQVVtWSxTQUFWLEVBQW9CO0FBQ2hCcFAsMEJBQWdCLElBQUlvUCxTQUFTLENBQUNuWSxDQUFELENBQVQsQ0FBYStDLFFBQWpDO0FBQ0FtViw0QkFBa0IsSUFBSUMsU0FBUyxDQUFDblksQ0FBRCxDQUFULENBQWF5SCxZQUFuQztBQUNIOztBQUNEc0Isd0JBQWdCLEdBQUdBLGdCQUFnQixHQUFHb1AsU0FBUyxDQUFDOVosTUFBaEQ7QUFDQTZaLDBCQUFrQixHQUFHQSxrQkFBa0IsR0FBR0MsU0FBUyxDQUFDOVosTUFBcEQ7QUFFQW1DLGFBQUssQ0FBQ3NJLE1BQU4sQ0FBYTtBQUFDWCxpQkFBTyxFQUFDN0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI0RTtBQUFoQyxTQUFiLEVBQXNEO0FBQUNILGNBQUksRUFBQztBQUFDc1EsK0JBQW1CLEVBQUNKLGtCQUFyQjtBQUF5Q0ssNkJBQWlCLEVBQUN4UDtBQUEzRDtBQUFOLFNBQXREO0FBQ0FxTCxtQkFBVyxDQUFDeE4sTUFBWixDQUFtQjtBQUNmbUMsMEJBQWdCLEVBQUVBLGdCQURIO0FBRWZtUCw0QkFBa0IsRUFBRUEsa0JBRkw7QUFHZm5hLGNBQUksRUFBRTBCLElBSFM7QUFJZitTLG1CQUFTLEVBQUVKO0FBSkksU0FBbkI7QUFNSDtBQUNKOztBQUVELFFBQUkzUyxJQUFJLElBQUksR0FBWixFQUFnQjtBQUNaLFVBQUlzSixnQkFBZ0IsR0FBRyxDQUF2QjtBQUNBLFVBQUltUCxrQkFBa0IsR0FBRyxDQUF6QjtBQUNBLFVBQUlDLFNBQVMsR0FBR3hYLFNBQVMsQ0FBQ3lCLElBQVYsQ0FBZTtBQUFFLGdCQUFRO0FBQUU0UyxhQUFHLEVBQUUsSUFBSXRWLElBQUosQ0FBU0EsSUFBSSxDQUFDMFMsR0FBTCxLQUFhLEtBQUcsRUFBSCxHQUFNLEVBQU4sR0FBVyxJQUFqQztBQUFQO0FBQVYsT0FBZixFQUE0RTlQLEtBQTVFLEVBQWhCOztBQUNBLFVBQUk2VixTQUFTLENBQUM5WixNQUFWLEdBQW1CLENBQXZCLEVBQXlCO0FBQ3JCLGFBQUsyQixDQUFMLElBQVVtWSxTQUFWLEVBQW9CO0FBQ2hCcFAsMEJBQWdCLElBQUlvUCxTQUFTLENBQUNuWSxDQUFELENBQVQsQ0FBYStDLFFBQWpDO0FBQ0FtViw0QkFBa0IsSUFBSUMsU0FBUyxDQUFDblksQ0FBRCxDQUFULENBQWF5SCxZQUFuQztBQUNIOztBQUNEc0Isd0JBQWdCLEdBQUdBLGdCQUFnQixHQUFHb1AsU0FBUyxDQUFDOVosTUFBaEQ7QUFDQTZaLDBCQUFrQixHQUFHQSxrQkFBa0IsR0FBR0MsU0FBUyxDQUFDOVosTUFBcEQ7QUFFQW1DLGFBQUssQ0FBQ3NJLE1BQU4sQ0FBYTtBQUFDWCxpQkFBTyxFQUFDN0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI0RTtBQUFoQyxTQUFiLEVBQXNEO0FBQUNILGNBQUksRUFBQztBQUFDd1EsOEJBQWtCLEVBQUNOLGtCQUFwQjtBQUF3Q08sNEJBQWdCLEVBQUMxUDtBQUF6RDtBQUFOLFNBQXREO0FBQ0FxTCxtQkFBVyxDQUFDeE4sTUFBWixDQUFtQjtBQUNmbUMsMEJBQWdCLEVBQUVBLGdCQURIO0FBRWZtUCw0QkFBa0IsRUFBRUEsa0JBRkw7QUFHZm5hLGNBQUksRUFBRTBCLElBSFM7QUFJZitTLG1CQUFTLEVBQUVKO0FBSkksU0FBbkI7QUFNSDtBQUNKLEtBcEV1RCxDQXNFeEQ7O0FBQ0gsR0E1UVU7QUE2UVgsZ0RBQThDLFlBQVU7QUFDcEQsU0FBSzdVLE9BQUw7QUFDQSxRQUFJOEQsVUFBVSxHQUFHMUUsVUFBVSxDQUFDeUYsSUFBWCxDQUFnQixFQUFoQixFQUFvQkUsS0FBcEIsRUFBakI7QUFDQSxRQUFJOFAsR0FBRyxHQUFHLElBQUkxUyxJQUFKLEVBQVY7O0FBQ0EsU0FBS00sQ0FBTCxJQUFVcUIsVUFBVixFQUFxQjtBQUNqQixVQUFJMEgsZ0JBQWdCLEdBQUcsQ0FBdkI7QUFFQSxVQUFJNUcsTUFBTSxHQUFHNUIsU0FBUyxDQUFDNkIsSUFBVixDQUFlO0FBQUNDLHVCQUFlLEVBQUNoQixVQUFVLENBQUNyQixDQUFELENBQVYsQ0FBYzFDLE9BQS9CO0FBQXdDLGdCQUFRO0FBQUUwWCxhQUFHLEVBQUUsSUFBSXRWLElBQUosQ0FBU0EsSUFBSSxDQUFDMFMsR0FBTCxLQUFhLEtBQUcsRUFBSCxHQUFNLEVBQU4sR0FBVyxJQUFqQztBQUFQO0FBQWhELE9BQWYsRUFBaUg7QUFBQ3RILGNBQU0sRUFBQztBQUFDcEksZ0JBQU0sRUFBQztBQUFSO0FBQVIsT0FBakgsRUFBc0lKLEtBQXRJLEVBQWI7O0FBRUEsVUFBSUgsTUFBTSxDQUFDOUQsTUFBUCxHQUFnQixDQUFwQixFQUFzQjtBQUNsQixZQUFJcWEsWUFBWSxHQUFHLEVBQW5COztBQUNBLGFBQUs1VixDQUFMLElBQVVYLE1BQVYsRUFBaUI7QUFDYnVXLHNCQUFZLENBQUN0UyxJQUFiLENBQWtCakUsTUFBTSxDQUFDVyxDQUFELENBQU4sQ0FBVUosTUFBNUI7QUFDSDs7QUFFRCxZQUFJeVYsU0FBUyxHQUFHeFgsU0FBUyxDQUFDeUIsSUFBVixDQUFlO0FBQUNNLGdCQUFNLEVBQUU7QUFBQ0UsZUFBRyxFQUFDOFY7QUFBTDtBQUFULFNBQWYsRUFBNkM7QUFBQzVOLGdCQUFNLEVBQUM7QUFBQ3BJLGtCQUFNLEVBQUMsQ0FBUjtBQUFVSyxvQkFBUSxFQUFDO0FBQW5CO0FBQVIsU0FBN0MsRUFBNkVULEtBQTdFLEVBQWhCOztBQUdBLGFBQUtxVyxDQUFMLElBQVVSLFNBQVYsRUFBb0I7QUFDaEJwUCwwQkFBZ0IsSUFBSW9QLFNBQVMsQ0FBQ1EsQ0FBRCxDQUFULENBQWE1VixRQUFqQztBQUNIOztBQUVEZ0csd0JBQWdCLEdBQUdBLGdCQUFnQixHQUFHb1AsU0FBUyxDQUFDOVosTUFBaEQ7QUFDSDs7QUFFRGdXLDBCQUFvQixDQUFDek4sTUFBckIsQ0FBNEI7QUFDeEJ2RSx1QkFBZSxFQUFFaEIsVUFBVSxDQUFDckIsQ0FBRCxDQUFWLENBQWMxQyxPQURQO0FBRXhCeUwsd0JBQWdCLEVBQUVBLGdCQUZNO0FBR3hCaEwsWUFBSSxFQUFFLGdDQUhrQjtBQUl4QnlVLGlCQUFTLEVBQUVKO0FBSmEsT0FBNUI7QUFNSDs7QUFFRCxXQUFPLElBQVA7QUFDSDtBQS9TVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDN0RBLElBQUk5VixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlpRSxnQkFBSixFQUFxQkMsU0FBckIsRUFBK0I2VCxZQUEvQixFQUE0Q0QsaUJBQTVDLEVBQThEM1QsZUFBOUQ7QUFBOEVyRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNrRSxrQkFBZ0IsQ0FBQ2pFLENBQUQsRUFBRztBQUFDaUUsb0JBQWdCLEdBQUNqRSxDQUFqQjtBQUFtQixHQUF4Qzs7QUFBeUNrRSxXQUFTLENBQUNsRSxDQUFELEVBQUc7QUFBQ2tFLGFBQVMsR0FBQ2xFLENBQVY7QUFBWSxHQUFsRTs7QUFBbUUrWCxjQUFZLENBQUMvWCxDQUFELEVBQUc7QUFBQytYLGdCQUFZLEdBQUMvWCxDQUFiO0FBQWUsR0FBbEc7O0FBQW1HOFgsbUJBQWlCLENBQUM5WCxDQUFELEVBQUc7QUFBQzhYLHFCQUFpQixHQUFDOVgsQ0FBbEI7QUFBb0IsR0FBNUk7O0FBQTZJbUUsaUJBQWUsQ0FBQ25FLENBQUQsRUFBRztBQUFDbUUsbUJBQWUsR0FBQ25FLENBQWhCO0FBQWtCOztBQUFsTCxDQUE1QixFQUFnTixDQUFoTjtBQUFtTixJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUloWEgsTUFBTSxDQUFDMFYsT0FBUCxDQUFlLHVCQUFmLEVBQXdDLFlBQVk7QUFDaEQsU0FBT3RSLGdCQUFnQixDQUFDMEIsSUFBakIsRUFBUDtBQUNILENBRkQ7QUFJQTlGLE1BQU0sQ0FBQzBWLE9BQVAsQ0FBZSwwQkFBZixFQUEyQyxVQUFTMVUsT0FBVCxFQUFrQnNiLEdBQWxCLEVBQXNCO0FBQzdELFNBQU9sWSxnQkFBZ0IsQ0FBQzBCLElBQWpCLENBQXNCO0FBQUM5RSxXQUFPLEVBQUNBO0FBQVQsR0FBdEIsRUFBd0M7QUFBQ2dILFNBQUssRUFBQ3NVLEdBQVA7QUFBWXZVLFFBQUksRUFBQztBQUFDM0IsWUFBTSxFQUFDLENBQUM7QUFBVDtBQUFqQixHQUF4QyxDQUFQO0FBQ0gsQ0FGRDtBQUlBcEcsTUFBTSxDQUFDMFYsT0FBUCxDQUFlLG1CQUFmLEVBQW9DLFlBQVU7QUFDMUMsU0FBT3JSLFNBQVMsQ0FBQ3lCLElBQVYsQ0FBZSxFQUFmLEVBQWtCO0FBQUNpQyxRQUFJLEVBQUM7QUFBQzNCLFlBQU0sRUFBQyxDQUFDO0FBQVQsS0FBTjtBQUFrQjRCLFNBQUssRUFBQztBQUF4QixHQUFsQixDQUFQO0FBQ0gsQ0FGRDtBQUlBaEksTUFBTSxDQUFDMFYsT0FBUCxDQUFlLHVCQUFmLEVBQXdDLFlBQVU7QUFDOUMsU0FBT3BSLGVBQWUsQ0FBQ3dCLElBQWhCLENBQXFCLEVBQXJCLEVBQXdCO0FBQUNpQyxRQUFJLEVBQUM7QUFBQzNCLFlBQU0sRUFBQyxDQUFDO0FBQVQsS0FBTjtBQUFtQjRCLFNBQUssRUFBQztBQUF6QixHQUF4QixDQUFQO0FBQ0gsQ0FGRDtBQUlBb0ksZ0JBQWdCLENBQUMsd0JBQUQsRUFBMkIsVUFBU3BQLE9BQVQsRUFBa0JTLElBQWxCLEVBQXVCO0FBQzlELE1BQUk4YSxVQUFVLEdBQUcsRUFBakI7O0FBQ0EsTUFBSTlhLElBQUksSUFBSSxPQUFaLEVBQW9CO0FBQ2hCOGEsY0FBVSxHQUFHO0FBQ1R0RCxXQUFLLEVBQUVqWTtBQURFLEtBQWI7QUFHSCxHQUpELE1BS0k7QUFDQXViLGNBQVUsR0FBRztBQUNUN0wsY0FBUSxFQUFFMVA7QUFERCxLQUFiO0FBR0g7O0FBQ0QsU0FBTztBQUNIOEUsUUFBSSxHQUFFO0FBQ0YsYUFBT21TLGlCQUFpQixDQUFDblMsSUFBbEIsQ0FBdUJ5VyxVQUF2QixDQUFQO0FBQ0gsS0FIRTs7QUFJSGxNLFlBQVEsRUFBRSxDQUNOO0FBQ0l2SyxVQUFJLENBQUM2VSxLQUFELEVBQU87QUFDUCxlQUFPdGEsVUFBVSxDQUFDeUYsSUFBWCxDQUNILEVBREcsRUFFSDtBQUFDMEksZ0JBQU0sRUFBQztBQUFDeE4sbUJBQU8sRUFBQyxDQUFUO0FBQVlvTSx1QkFBVyxFQUFDLENBQXhCO0FBQTJCQyx1QkFBVyxFQUFDO0FBQXZDO0FBQVIsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FETTtBQUpQLEdBQVA7QUFlSCxDQTNCZSxDQUFoQjtBQTZCQStDLGdCQUFnQixDQUFDLHlCQUFELEVBQTRCLFVBQVNwUCxPQUFULEVBQWtCUyxJQUFsQixFQUF1QjtBQUMvRCxTQUFPO0FBQ0hxRSxRQUFJLEdBQUU7QUFDRixhQUFPb1MsWUFBWSxDQUFDcFMsSUFBYixDQUNIO0FBQUMsU0FBQ3JFLElBQUQsR0FBUVQ7QUFBVCxPQURHLEVBRUg7QUFBQytHLFlBQUksRUFBRTtBQUFDMFMsbUJBQVMsRUFBRSxDQUFDO0FBQWI7QUFBUCxPQUZHLENBQVA7QUFJSCxLQU5FOztBQU9IcEssWUFBUSxFQUFFLENBQ047QUFDSXZLLFVBQUksR0FBRTtBQUNGLGVBQU96RixVQUFVLENBQUN5RixJQUFYLENBQ0gsRUFERyxFQUVIO0FBQUMwSSxnQkFBTSxFQUFDO0FBQUN4TixtQkFBTyxFQUFDLENBQVQ7QUFBWW9NLHVCQUFXLEVBQUMsQ0FBeEI7QUFBMkI3Syw0QkFBZ0IsRUFBQztBQUE1QztBQUFSLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE07QUFQUCxHQUFQO0FBa0JILENBbkJlLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDakRBdEMsTUFBTSxDQUFDcVEsTUFBUCxDQUFjO0FBQUNsTSxrQkFBZ0IsRUFBQyxNQUFJQSxnQkFBdEI7QUFBdUNDLFdBQVMsRUFBQyxNQUFJQSxTQUFyRDtBQUErRDRULG1CQUFpQixFQUFDLE1BQUlBLGlCQUFyRjtBQUF1R0MsY0FBWSxFQUFDLE1BQUlBLFlBQXhIO0FBQXFJNVQsaUJBQWUsRUFBQyxNQUFJQSxlQUF6SjtBQUF5S3dULGFBQVcsRUFBQyxNQUFJQSxXQUF6TDtBQUFxTUMsc0JBQW9CLEVBQUMsTUFBSUE7QUFBOU4sQ0FBZDtBQUFtUSxJQUFJeEgsS0FBSjtBQUFVdFEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDcVEsT0FBSyxDQUFDcFEsQ0FBRCxFQUFHO0FBQUNvUSxTQUFLLEdBQUNwUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQXZDLEVBQXFFLENBQXJFO0FBR3ZVLE1BQU1pRSxnQkFBZ0IsR0FBRyxJQUFJbU0sS0FBSyxDQUFDQyxVQUFWLENBQXFCLG1CQUFyQixDQUF6QjtBQUNBLE1BQU1uTSxTQUFTLEdBQUcsSUFBSWtNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixXQUFyQixDQUFsQjtBQUNBLE1BQU15SCxpQkFBaUIsR0FBRyxJQUFJMUgsS0FBSyxDQUFDQyxVQUFWLENBQXFCLHFCQUFyQixDQUExQjtBQUNBLE1BQU0wSCxZQUFZLEdBQUcsSUFBSzNILEtBQUssQ0FBQ0MsVUFBWCxDQUFzQixlQUF0QixDQUFyQjtBQUNBLE1BQU1sTSxlQUFlLEdBQUcsSUFBSWlNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQiw0QkFBckIsQ0FBeEI7QUFDQSxNQUFNc0gsV0FBVyxHQUFHLElBQUl2SCxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsY0FBckIsQ0FBcEI7QUFDQSxNQUFNdUgsb0JBQW9CLEdBQUcsSUFBSXhILEtBQUssQ0FBQ0MsVUFBVixDQUFxQix3QkFBckIsQ0FBN0I7QUFFUHlILGlCQUFpQixDQUFDeEgsT0FBbEIsQ0FBMEI7QUFDdEIrTCxpQkFBZSxHQUFFO0FBQ2IsUUFBSXBhLFNBQVMsR0FBRy9CLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQ3JCLGFBQU8sRUFBQyxLQUFLMFA7QUFBZCxLQUFuQixDQUFoQjtBQUNBLFdBQVF0TyxTQUFTLENBQUNnTCxXQUFYLEdBQXdCaEwsU0FBUyxDQUFDZ0wsV0FBVixDQUFzQnFQLE9BQTlDLEdBQXNELEtBQUsvTCxRQUFsRTtBQUNILEdBSnFCOztBQUt0QmdNLGNBQVksR0FBRTtBQUNWLFFBQUl0YSxTQUFTLEdBQUcvQixVQUFVLENBQUNnQyxPQUFYLENBQW1CO0FBQUNyQixhQUFPLEVBQUMsS0FBS2lZO0FBQWQsS0FBbkIsQ0FBaEI7QUFDQSxXQUFRN1csU0FBUyxDQUFDZ0wsV0FBWCxHQUF3QmhMLFNBQVMsQ0FBQ2dMLFdBQVYsQ0FBc0JxUCxPQUE5QyxHQUFzRCxLQUFLeEQsS0FBbEU7QUFDSDs7QUFScUIsQ0FBMUIsRTs7Ozs7Ozs7Ozs7QUNYQSxJQUFJalosTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJNlgsTUFBSjtBQUFXL1gsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDOFgsUUFBTSxDQUFDN1gsQ0FBRCxFQUFHO0FBQUM2WCxVQUFNLEdBQUM3WCxDQUFQO0FBQVM7O0FBQXBCLENBQTNCLEVBQWlELENBQWpEO0FBQW9ELElBQUkwVyxLQUFKO0FBQVU1VyxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMyVyxPQUFLLENBQUMxVyxDQUFELEVBQUc7QUFBQzBXLFNBQUssR0FBQzFXLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFJeklILE1BQU0sQ0FBQzBWLE9BQVAsQ0FBZSxlQUFmLEVBQWdDLFlBQVk7QUFDeEMsU0FBT3NDLE1BQU0sQ0FBQ2xTLElBQVAsQ0FBWTtBQUFDK0YsV0FBTyxFQUFDN0wsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI0RTtBQUFoQyxHQUFaLENBQVA7QUFDSCxDQUZELEU7Ozs7Ozs7Ozs7O0FDSkE1TCxNQUFNLENBQUNxUSxNQUFQLENBQWM7QUFBQzBILFFBQU0sRUFBQyxNQUFJQTtBQUFaLENBQWQ7QUFBbUMsSUFBSXpILEtBQUo7QUFBVXRRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3FRLE9BQUssQ0FBQ3BRLENBQUQsRUFBRztBQUFDb1EsU0FBSyxHQUFDcFEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUV0QyxNQUFNNlgsTUFBTSxHQUFHLElBQUl6SCxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsUUFBckIsQ0FBZixDOzs7Ozs7Ozs7OztBQ0ZQLElBQUl4USxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSXFFLFlBQUo7QUFBaUJ2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDc0UsY0FBWSxDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxnQkFBWSxHQUFDckUsQ0FBYjtBQUFlOztBQUFoQyxDQUFqRCxFQUFtRixDQUFuRjtBQUFzRixJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJb0Usa0JBQUo7QUFBdUJ0RSxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQkFBWixFQUE0QztBQUFDcUUsb0JBQWtCLENBQUNwRSxDQUFELEVBQUc7QUFBQ29FLHNCQUFrQixHQUFDcEUsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQTVDLEVBQTBGLENBQTFGO0FBTW5WLE1BQU13YyxhQUFhLEdBQUcsRUFBdEI7QUFFQTNjLE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsd0JBQXNCLFVBQVNzSSxJQUFULEVBQWUyQyxTQUFmLEVBQXlCO0FBQzNDLFNBQUsvSyxPQUFMO0FBQ0FvSSxRQUFJLEdBQUdBLElBQUksQ0FBQ3VULFdBQUwsRUFBUDtBQUNBLFFBQUlyYyxHQUFHLEdBQUdHLEdBQUcsR0FBRSxPQUFMLEdBQWEySSxJQUF2QjtBQUNBLFFBQUlsSSxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxRQUFJc2MsRUFBRSxHQUFHemIsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBVDtBQUVBVCxXQUFPLENBQUNDLEdBQVIsQ0FBWXVJLElBQVo7QUFFQXdULE1BQUUsQ0FBQ3pXLE1BQUgsR0FBWXVFLFFBQVEsQ0FBQ2tTLEVBQUUsQ0FBQ3pXLE1BQUosQ0FBcEIsQ0FUMkMsQ0FXM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQSxRQUFJMFcsSUFBSSxHQUFHdFksWUFBWSxDQUFDOEYsTUFBYixDQUFvQnVTLEVBQXBCLENBQVg7O0FBQ0EsUUFBSUMsSUFBSixFQUFTO0FBQ0wsYUFBT0EsSUFBUDtBQUNILEtBRkQsTUFHSyxPQUFPLEtBQVA7QUFDUixHQTlEVTtBQStEWCxpQ0FBK0IsVUFBUzliLE9BQVQsRUFBa0JvRixNQUFsQixFQUF5QjtBQUNwRDtBQUNBLFdBQU81QixZQUFZLENBQUNzQixJQUFiLENBQWtCO0FBQ3JCeEQsU0FBRyxFQUFFLENBQUM7QUFBQ21XLFlBQUksRUFBRSxDQUNUO0FBQUMseUJBQWU7QUFBaEIsU0FEUyxFQUVUO0FBQUMsbUNBQXlCO0FBQTFCLFNBRlMsRUFHVDtBQUFDLHFDQUEyQnpYO0FBQTVCLFNBSFM7QUFBUCxPQUFELEVBSUQ7QUFBQ3lYLFlBQUksRUFBQyxDQUNOO0FBQUMsbUNBQXlCO0FBQTFCLFNBRE0sRUFFTjtBQUFDLHFDQUEyQjtBQUE1QixTQUZNLEVBR047QUFBQyxtQ0FBeUI7QUFBMUIsU0FITSxFQUlOO0FBQUMscUNBQTJCelg7QUFBNUIsU0FKTTtBQUFOLE9BSkMsRUFTRDtBQUFDeVgsWUFBSSxFQUFDLENBQ047QUFBQyx5QkFBZTtBQUFoQixTQURNLEVBRU47QUFBQyxtQ0FBeUI7QUFBMUIsU0FGTSxFQUdOO0FBQUMscUNBQTJCelg7QUFBNUIsU0FITTtBQUFOLE9BVEMsRUFhRDtBQUFDeVgsWUFBSSxFQUFDLENBQ047QUFBQyx5QkFBZTtBQUFoQixTQURNLEVBRU47QUFBQyxtQ0FBeUI7QUFBMUIsU0FGTSxFQUdOO0FBQUMscUNBQTJCelg7QUFBNUIsU0FITTtBQUFOLE9BYkMsRUFpQkQ7QUFBQ3lYLFlBQUksRUFBQyxDQUNOO0FBQUMseUJBQWU7QUFBaEIsU0FETSxFQUVOO0FBQUMsbUNBQXlCO0FBQTFCLFNBRk0sRUFHTjtBQUFDLHFDQUEyQnpYO0FBQTVCLFNBSE07QUFBTixPQWpCQyxDQURnQjtBQXVCckIsY0FBUTtBQUFDZ0ssZUFBTyxFQUFFO0FBQVYsT0F2QmE7QUF3QnJCNUUsWUFBTSxFQUFDO0FBQUMyVyxXQUFHLEVBQUMzVztBQUFMO0FBeEJjLEtBQWxCLEVBeUJQO0FBQUMyQixVQUFJLEVBQUM7QUFBQzNCLGNBQU0sRUFBQyxDQUFDO0FBQVQsT0FBTjtBQUNJNEIsV0FBSyxFQUFFO0FBRFgsS0F6Qk8sRUEyQkxoQyxLQTNCSyxFQUFQO0FBNEJILEdBN0ZVO0FBOEZYLDJCQUF5QixVQUFTaEYsT0FBVCxFQUE4QjtBQUFBLFFBQVp3TixNQUFZLHVFQUFMLElBQUs7QUFDbkQ7QUFDQSxRQUFJcE0sU0FBSjtBQUNBLFFBQUksQ0FBQ29NLE1BQUwsRUFDSUEsTUFBTSxHQUFHO0FBQUN4TixhQUFPLEVBQUMsQ0FBVDtBQUFZb00saUJBQVcsRUFBQyxDQUF4QjtBQUEyQjdLLHNCQUFnQixFQUFDLENBQTVDO0FBQStDQyx1QkFBaUIsRUFBQztBQUFqRSxLQUFUOztBQUNKLFFBQUl4QixPQUFPLENBQUNnYyxRQUFSLENBQWlCaGQsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJnVyxtQkFBeEMsQ0FBSixFQUFpRTtBQUM3RDtBQUNBN2EsZUFBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDRSx3QkFBZ0IsRUFBQ3ZCO0FBQWxCLE9BQW5CLEVBQStDO0FBQUN3TjtBQUFELE9BQS9DLENBQVo7QUFDSCxLQUhELE1BSUssSUFBSXhOLE9BQU8sQ0FBQ2djLFFBQVIsQ0FBaUJoZCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmlXLG1CQUF4QyxDQUFKLEVBQWlFO0FBQ2xFO0FBQ0E5YSxlQUFTLEdBQUcvQixVQUFVLENBQUNnQyxPQUFYLENBQW1CO0FBQUNHLHlCQUFpQixFQUFDeEI7QUFBbkIsT0FBbkIsRUFBZ0Q7QUFBQ3dOO0FBQUQsT0FBaEQsQ0FBWjtBQUNILEtBSEksTUFJQSxJQUFJeE4sT0FBTyxDQUFDZSxNQUFSLEtBQW1CNGEsYUFBdkIsRUFBc0M7QUFDdkN2YSxlQUFTLEdBQUcvQixVQUFVLENBQUNnQyxPQUFYLENBQW1CO0FBQUNyQixlQUFPLEVBQUNBO0FBQVQsT0FBbkIsRUFBc0M7QUFBQ3dOO0FBQUQsT0FBdEMsQ0FBWjtBQUNIOztBQUNELFFBQUlwTSxTQUFKLEVBQWM7QUFDVixhQUFPQSxTQUFQO0FBQ0g7O0FBQ0QsV0FBTyxLQUFQO0FBRUg7QUFuSFUsQ0FBZixFOzs7Ozs7Ozs7OztBQ1JBLElBQUlwQyxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlxRSxZQUFKO0FBQWlCdkUsTUFBTSxDQUFDQyxJQUFQLENBQVksb0JBQVosRUFBaUM7QUFBQ3NFLGNBQVksQ0FBQ3JFLENBQUQsRUFBRztBQUFDcUUsZ0JBQVksR0FBQ3JFLENBQWI7QUFBZTs7QUFBaEMsQ0FBakMsRUFBbUUsQ0FBbkU7QUFBc0UsSUFBSThELFNBQUo7QUFBY2hFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdCQUFaLEVBQXFDO0FBQUMrRCxXQUFTLENBQUM5RCxDQUFELEVBQUc7QUFBQzhELGFBQVMsR0FBQzlELENBQVY7QUFBWTs7QUFBMUIsQ0FBckMsRUFBaUUsQ0FBakU7QUFLcktpUSxnQkFBZ0IsQ0FBQyxtQkFBRCxFQUFzQixZQUFvQjtBQUFBLE1BQVhwSSxLQUFXLHVFQUFILEVBQUc7QUFDdEQsU0FBTztBQUNIbEMsUUFBSSxHQUFFO0FBQ0YsYUFBT3RCLFlBQVksQ0FBQ3NCLElBQWIsQ0FBa0IsRUFBbEIsRUFBcUI7QUFBQ2lDLFlBQUksRUFBQztBQUFDM0IsZ0JBQU0sRUFBQyxDQUFDO0FBQVQsU0FBTjtBQUFtQjRCLGFBQUssRUFBQ0E7QUFBekIsT0FBckIsQ0FBUDtBQUNILEtBSEU7O0FBSUhxSSxZQUFRLEVBQUUsQ0FDTjtBQUNJdkssVUFBSSxDQUFDK1csRUFBRCxFQUFJO0FBQ0osZUFBTzVZLFNBQVMsQ0FBQzZCLElBQVYsQ0FDSDtBQUFDTSxnQkFBTSxFQUFDeVcsRUFBRSxDQUFDelc7QUFBWCxTQURHLEVBRUg7QUFBQ29JLGdCQUFNLEVBQUM7QUFBQ3JMLGdCQUFJLEVBQUMsQ0FBTjtBQUFTaUQsa0JBQU0sRUFBQztBQUFoQjtBQUFSLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE07QUFKUCxHQUFQO0FBZUgsQ0FoQmUsQ0FBaEI7QUFrQkFnSyxnQkFBZ0IsQ0FBQyx3QkFBRCxFQUEyQixVQUFTK00sZ0JBQVQsRUFBMkJDLGdCQUEzQixFQUF1RDtBQUFBLE1BQVZwVixLQUFVLHVFQUFKLEdBQUk7QUFDOUYsTUFBSXFWLEtBQUssR0FBRyxFQUFaOztBQUNBLE1BQUlGLGdCQUFnQixJQUFJQyxnQkFBeEIsRUFBeUM7QUFDckNDLFNBQUssR0FBRztBQUFDL2EsU0FBRyxFQUFDLENBQUM7QUFBQyxtQ0FBMEI2YTtBQUEzQixPQUFELEVBQStDO0FBQUMsbUNBQTBCQztBQUEzQixPQUEvQztBQUFMLEtBQVI7QUFDSDs7QUFFRCxNQUFJLENBQUNELGdCQUFELElBQXFCQyxnQkFBekIsRUFBMEM7QUFDdENDLFNBQUssR0FBRztBQUFDLGlDQUEwQkQ7QUFBM0IsS0FBUjtBQUNIOztBQUVELFNBQU87QUFDSHRYLFFBQUksR0FBRTtBQUNGLGFBQU90QixZQUFZLENBQUNzQixJQUFiLENBQWtCdVgsS0FBbEIsRUFBeUI7QUFBQ3RWLFlBQUksRUFBQztBQUFDM0IsZ0JBQU0sRUFBQyxDQUFDO0FBQVQsU0FBTjtBQUFtQjRCLGFBQUssRUFBQ0E7QUFBekIsT0FBekIsQ0FBUDtBQUNILEtBSEU7O0FBSUhxSSxZQUFRLEVBQUMsQ0FDTDtBQUNJdkssVUFBSSxDQUFDK1csRUFBRCxFQUFJO0FBQ0osZUFBTzVZLFNBQVMsQ0FBQzZCLElBQVYsQ0FDSDtBQUFDTSxnQkFBTSxFQUFDeVcsRUFBRSxDQUFDelc7QUFBWCxTQURHLEVBRUg7QUFBQ29JLGdCQUFNLEVBQUM7QUFBQ3JMLGdCQUFJLEVBQUMsQ0FBTjtBQUFTaUQsa0JBQU0sRUFBQztBQUFoQjtBQUFSLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBREs7QUFKTixHQUFQO0FBZUgsQ0F6QmUsQ0FBaEI7QUEyQkFnSyxnQkFBZ0IsQ0FBQyxzQkFBRCxFQUF5QixVQUFTL0csSUFBVCxFQUFjO0FBQ25ELFNBQU87QUFDSHZELFFBQUksR0FBRTtBQUNGLGFBQU90QixZQUFZLENBQUNzQixJQUFiLENBQWtCO0FBQUMwUixjQUFNLEVBQUNuTztBQUFSLE9BQWxCLENBQVA7QUFDSCxLQUhFOztBQUlIZ0gsWUFBUSxFQUFFLENBQ047QUFDSXZLLFVBQUksQ0FBQytXLEVBQUQsRUFBSTtBQUNKLGVBQU81WSxTQUFTLENBQUM2QixJQUFWLENBQ0g7QUFBQ00sZ0JBQU0sRUFBQ3lXLEVBQUUsQ0FBQ3pXO0FBQVgsU0FERyxFQUVIO0FBQUNvSSxnQkFBTSxFQUFDO0FBQUNyTCxnQkFBSSxFQUFDLENBQU47QUFBU2lELGtCQUFNLEVBQUM7QUFBaEI7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNO0FBSlAsR0FBUDtBQWVILENBaEJlLENBQWhCO0FBa0JBZ0ssZ0JBQWdCLENBQUMscUJBQUQsRUFBd0IsVUFBU2hLLE1BQVQsRUFBZ0I7QUFDcEQsU0FBTztBQUNITixRQUFJLEdBQUU7QUFDRixhQUFPdEIsWUFBWSxDQUFDc0IsSUFBYixDQUFrQjtBQUFDTSxjQUFNLEVBQUNBO0FBQVIsT0FBbEIsQ0FBUDtBQUNILEtBSEU7O0FBSUhpSyxZQUFRLEVBQUUsQ0FDTjtBQUNJdkssVUFBSSxDQUFDK1csRUFBRCxFQUFJO0FBQ0osZUFBTzVZLFNBQVMsQ0FBQzZCLElBQVYsQ0FDSDtBQUFDTSxnQkFBTSxFQUFDeVcsRUFBRSxDQUFDelc7QUFBWCxTQURHLEVBRUg7QUFBQ29JLGdCQUFNLEVBQUM7QUFBQ3JMLGdCQUFJLEVBQUMsQ0FBTjtBQUFTaUQsa0JBQU0sRUFBQztBQUFoQjtBQUFSLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE07QUFKUCxHQUFQO0FBZUgsQ0FoQmUsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUNwRUFuRyxNQUFNLENBQUNxUSxNQUFQLENBQWM7QUFBQzlMLGNBQVksRUFBQyxNQUFJQTtBQUFsQixDQUFkO0FBQStDLElBQUkrTCxLQUFKO0FBQVV0USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNxUSxPQUFLLENBQUNwUSxDQUFELEVBQUc7QUFBQ29RLFNBQUssR0FBQ3BRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSThELFNBQUo7QUFBY2hFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUMrRCxXQUFTLENBQUM5RCxDQUFELEVBQUc7QUFBQzhELGFBQVMsR0FBQzlELENBQVY7QUFBWTs7QUFBMUIsQ0FBbEMsRUFBOEQsQ0FBOUQ7QUFBaUUsSUFBSW1kLE1BQUo7QUFBV3JkLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtCQUFaLEVBQTRDO0FBQUNvZCxRQUFNLENBQUNuZCxDQUFELEVBQUc7QUFBQ21kLFVBQU0sR0FBQ25kLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUMsRUFBa0UsQ0FBbEU7QUFJOUwsTUFBTXFFLFlBQVksR0FBRyxJQUFJK0wsS0FBSyxDQUFDQyxVQUFWLENBQXFCLGNBQXJCLENBQXJCO0FBRVBoTSxZQUFZLENBQUNpTSxPQUFiLENBQXFCO0FBQ2pCdEssT0FBSyxHQUFFO0FBQ0gsV0FBT2xDLFNBQVMsQ0FBQzVCLE9BQVYsQ0FBa0I7QUFBQytELFlBQU0sRUFBQyxLQUFLQTtBQUFiLEtBQWxCLENBQVA7QUFDSDs7QUFIZ0IsQ0FBckIsRTs7Ozs7Ozs7Ozs7QUNOQSxJQUFJcEcsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJcUUsWUFBSjtBQUFpQnZFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUNzRSxjQUFZLENBQUNyRSxDQUFELEVBQUc7QUFBQ3FFLGdCQUFZLEdBQUNyRSxDQUFiO0FBQWU7O0FBQWhDLENBQWpELEVBQW1GLENBQW5GO0FBQXNGLElBQUk4RCxTQUFKO0FBQWNoRSxNQUFNLENBQUNDLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDK0QsV0FBUyxDQUFDOUQsQ0FBRCxFQUFHO0FBQUM4RCxhQUFTLEdBQUM5RCxDQUFWO0FBQVk7O0FBQTFCLENBQXJDLEVBQWlFLENBQWpFO0FBQW9FLElBQUk2VixXQUFKO0FBQWdCL1YsTUFBTSxDQUFDQyxJQUFQLENBQVksa0NBQVosRUFBK0M7QUFBQzhWLGFBQVcsQ0FBQzdWLENBQUQsRUFBRztBQUFDNlYsZUFBVyxHQUFDN1YsQ0FBWjtBQUFjOztBQUE5QixDQUEvQyxFQUErRSxDQUEvRTtBQUt6UUgsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCx3Q0FBc0MsVUFBU0MsT0FBVCxFQUFpQjtBQUNuRDtBQUNBLFFBQUk2YixFQUFFLEdBQUdyWSxZQUFZLENBQUNuQyxPQUFiLENBQXFCO0FBQUNvVyxVQUFJLEVBQUMsQ0FDaEM7QUFBQyxnREFBdUN6WDtBQUF4QyxPQURnQyxFQUVoQztBQUFDLDZCQUFvQjtBQUFyQixPQUZnQyxFQUdoQztBQUFDb1csWUFBSSxFQUFDO0FBQUNwTSxpQkFBTyxFQUFDO0FBQVQ7QUFBTixPQUhnQztBQUFOLEtBQXJCLENBQVQ7O0FBTUEsUUFBSTZSLEVBQUosRUFBTztBQUNILFVBQUkxVyxLQUFLLEdBQUdsQyxTQUFTLENBQUM1QixPQUFWLENBQWtCO0FBQUMrRCxjQUFNLEVBQUN5VyxFQUFFLENBQUN6VztBQUFYLE9BQWxCLENBQVo7O0FBQ0EsVUFBSUQsS0FBSixFQUFVO0FBQ04sZUFBT0EsS0FBSyxDQUFDaEQsSUFBYjtBQUNIO0FBQ0osS0FMRCxNQU1JO0FBQ0E7QUFDQSxhQUFPLEtBQVA7QUFDSDtBQUNKLEdBbkJVOztBQW9CWDtBQUNBLGlDQUErQm5DLE9BQS9CLEVBQXVDO0FBQ25DLFFBQUlULEdBQUcsR0FBR0csR0FBRyxHQUFHLHNCQUFOLEdBQTZCTSxPQUE3QixHQUFxQyxjQUEvQzs7QUFFQSxRQUFHO0FBQ0MsVUFBSWdCLFdBQVcsR0FBRzVCLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWxCOztBQUNBLFVBQUl5QixXQUFXLENBQUNyQixVQUFaLElBQTBCLEdBQTlCLEVBQWtDO0FBQzlCcUIsbUJBQVcsR0FBR1osSUFBSSxDQUFDQyxLQUFMLENBQVdXLFdBQVcsQ0FBQ1YsT0FBdkIsRUFBZ0NDLE1BQTlDO0FBQ0FTLG1CQUFXLENBQUNnQixPQUFaLENBQW9CLENBQUNTLFVBQUQsRUFBYUMsQ0FBYixLQUFtQjtBQUNuQyxjQUFJMUIsV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLElBQWtCMUIsV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLENBQWVkLE1BQXJDLEVBQ0laLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxDQUFlZCxNQUFmLEdBQXdCQyxVQUFVLENBQUNiLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxDQUFlZCxNQUFoQixDQUFsQztBQUNQLFNBSEQ7QUFLQSxlQUFPWixXQUFQO0FBQ0g7O0FBQUE7QUFDSixLQVhELENBWUEsT0FBT3BCLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0o7O0FBdkNVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNMQSxJQUFJWixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksa0JBQVosRUFBK0I7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQS9CLEVBQTZELENBQTdEO0FBQWdFLElBQUlpRSxnQkFBSjtBQUFxQm5FLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUNrRSxrQkFBZ0IsQ0FBQ2pFLENBQUQsRUFBRztBQUFDaUUsb0JBQWdCLEdBQUNqRSxDQUFqQjtBQUFtQjs7QUFBeEMsQ0FBdkMsRUFBaUYsQ0FBakY7QUFBb0YsSUFBSW9FLGtCQUFKO0FBQXVCdEUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0JBQVosRUFBNEM7QUFBQ3FFLG9CQUFrQixDQUFDcEUsQ0FBRCxFQUFHO0FBQUNvRSxzQkFBa0IsR0FBQ3BFLENBQW5CO0FBQXFCOztBQUE1QyxDQUE1QyxFQUEwRixDQUExRjtBQUsvUUgsTUFBTSxDQUFDMFYsT0FBUCxDQUFlLGdCQUFmLEVBQWlDLFlBQW1FO0FBQUEsTUFBekQzTixJQUF5RCx1RUFBbEQscUJBQWtEO0FBQUEsTUFBM0J3VixTQUEyQix1RUFBZixDQUFDLENBQWM7QUFBQSxNQUFYL08sTUFBVyx1RUFBSixFQUFJO0FBQ2hHLFNBQU9uTyxVQUFVLENBQUN5RixJQUFYLENBQWdCLEVBQWhCLEVBQW9CO0FBQUNpQyxRQUFJLEVBQUU7QUFBQyxPQUFDQSxJQUFELEdBQVF3VjtBQUFULEtBQVA7QUFBNEIvTyxVQUFNLEVBQUVBO0FBQXBDLEdBQXBCLENBQVA7QUFDSCxDQUZEO0FBSUE0QixnQkFBZ0IsQ0FBQyxzQkFBRCxFQUF3QjtBQUNwQ3RLLE1BQUksR0FBRztBQUNILFdBQU96RixVQUFVLENBQUN5RixJQUFYLENBQWdCLEVBQWhCLENBQVA7QUFDSCxHQUhtQzs7QUFJcEN1SyxVQUFRLEVBQUUsQ0FDTjtBQUNJdkssUUFBSSxDQUFDMFgsR0FBRCxFQUFNO0FBQ04sYUFBT3BaLGdCQUFnQixDQUFDMEIsSUFBakIsQ0FDSDtBQUFFOUUsZUFBTyxFQUFFd2MsR0FBRyxDQUFDeGM7QUFBZixPQURHLEVBRUg7QUFBRStHLFlBQUksRUFBRTtBQUFDM0IsZ0JBQU0sRUFBRTtBQUFULFNBQVI7QUFBcUI0QixhQUFLLEVBQUU7QUFBNUIsT0FGRyxDQUFQO0FBSUg7O0FBTkwsR0FETTtBQUowQixDQUF4QixDQUFoQjtBQWdCQWhJLE1BQU0sQ0FBQzBWLE9BQVAsQ0FBZSx5QkFBZixFQUEwQyxZQUFVO0FBQ2hELFNBQU9yVixVQUFVLENBQUN5RixJQUFYLENBQWdCO0FBQ25CNkIsVUFBTSxFQUFFLENBRFc7QUFFbkIyRixVQUFNLEVBQUM7QUFGWSxHQUFoQixFQUdMO0FBQ0V2RixRQUFJLEVBQUM7QUFDRG9ELGtCQUFZLEVBQUMsQ0FBQztBQURiLEtBRFA7QUFJRXFELFVBQU0sRUFBQztBQUNIeE4sYUFBTyxFQUFFLENBRE47QUFFSG9NLGlCQUFXLEVBQUMsQ0FGVDtBQUdIakMsa0JBQVksRUFBQyxDQUhWO0FBSUhrQyxpQkFBVyxFQUFDO0FBSlQ7QUFKVCxHQUhLLENBQVA7QUFlSCxDQWhCRDtBQWtCQStDLGdCQUFnQixDQUFDLG1CQUFELEVBQXNCLFVBQVNwUCxPQUFULEVBQWlCO0FBQ25ELE1BQUk0WCxPQUFPLEdBQUc7QUFBQzVYLFdBQU8sRUFBQ0E7QUFBVCxHQUFkOztBQUNBLE1BQUlBLE9BQU8sQ0FBQ3dFLE9BQVIsQ0FBZ0J4RixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmdXLG1CQUF2QyxLQUErRCxDQUFDLENBQXBFLEVBQXNFO0FBQ2xFckUsV0FBTyxHQUFHO0FBQUNyVyxzQkFBZ0IsRUFBQ3ZCO0FBQWxCLEtBQVY7QUFDSDs7QUFDRCxTQUFPO0FBQ0g4RSxRQUFJLEdBQUU7QUFDRixhQUFPekYsVUFBVSxDQUFDeUYsSUFBWCxDQUFnQjhTLE9BQWhCLENBQVA7QUFDSCxLQUhFOztBQUlIdkksWUFBUSxFQUFFLENBQ047QUFDSXZLLFVBQUksQ0FBQzBYLEdBQUQsRUFBSztBQUNMLGVBQU9qWixrQkFBa0IsQ0FBQ3VCLElBQW5CLENBQ0g7QUFBQzlFLGlCQUFPLEVBQUN3YyxHQUFHLENBQUN4YztBQUFiLFNBREcsRUFFSDtBQUFDK0csY0FBSSxFQUFDO0FBQUMzQixrQkFBTSxFQUFDLENBQUM7QUFBVCxXQUFOO0FBQW1CNEIsZUFBSyxFQUFDO0FBQXpCLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE0sRUFTTjtBQUNJbEMsVUFBSSxDQUFDMFgsR0FBRCxFQUFNO0FBQ04sZUFBT3BaLGdCQUFnQixDQUFDMEIsSUFBakIsQ0FDSDtBQUFFOUUsaUJBQU8sRUFBRXdjLEdBQUcsQ0FBQ3hjO0FBQWYsU0FERyxFQUVIO0FBQUUrRyxjQUFJLEVBQUU7QUFBQzNCLGtCQUFNLEVBQUUsQ0FBQztBQUFWLFdBQVI7QUFBc0I0QixlQUFLLEVBQUVoSSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QkM7QUFBcEQsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FUTTtBQUpQLEdBQVA7QUF1QkgsQ0E1QmUsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUMzQ0FqSCxNQUFNLENBQUNxUSxNQUFQLENBQWM7QUFBQ2pRLFlBQVUsRUFBQyxNQUFJQTtBQUFoQixDQUFkO0FBQTJDLElBQUlrUSxLQUFKO0FBQVV0USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNxUSxPQUFLLENBQUNwUSxDQUFELEVBQUc7QUFBQ29RLFNBQUssR0FBQ3BRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSWlFLGdCQUFKO0FBQXFCbkUsTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQ2tFLGtCQUFnQixDQUFDakUsQ0FBRCxFQUFHO0FBQUNpRSxvQkFBZ0IsR0FBQ2pFLENBQWpCO0FBQW1COztBQUF4QyxDQUFwQyxFQUE4RSxDQUE5RTtBQUFpRixJQUFJb0Usa0JBQUo7QUFBdUJ0RSxNQUFNLENBQUNDLElBQVAsQ0FBWSw0QkFBWixFQUF5QztBQUFDcUUsb0JBQWtCLENBQUNwRSxDQUFELEVBQUc7QUFBQ29FLHNCQUFrQixHQUFDcEUsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQXpDLEVBQXVGLENBQXZGO0FBSTdOLE1BQU1FLFVBQVUsR0FBRyxJQUFJa1EsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFlBQXJCLENBQW5CO0FBRVBuUSxVQUFVLENBQUNvUSxPQUFYLENBQW1CO0FBQ2ZnTixXQUFTLEdBQUU7QUFDUCxXQUFPclosZ0JBQWdCLENBQUMvQixPQUFqQixDQUF5QjtBQUFDckIsYUFBTyxFQUFDLEtBQUtBO0FBQWQsS0FBekIsQ0FBUDtBQUNILEdBSGM7O0FBSWYwYyxTQUFPLEdBQUU7QUFDTCxXQUFPblosa0JBQWtCLENBQUN1QixJQUFuQixDQUF3QjtBQUFDOUUsYUFBTyxFQUFDLEtBQUtBO0FBQWQsS0FBeEIsRUFBZ0Q7QUFBQytHLFVBQUksRUFBQztBQUFDM0IsY0FBTSxFQUFDLENBQUM7QUFBVCxPQUFOO0FBQW1CNEIsV0FBSyxFQUFDO0FBQXpCLEtBQWhELEVBQThFaEMsS0FBOUUsRUFBUDtBQUNIOztBQU5jLENBQW5CLEUsQ0FRQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNCQS9GLE1BQU0sQ0FBQ3FRLE1BQVAsQ0FBYztBQUFDL0wsb0JBQWtCLEVBQUMsTUFBSUE7QUFBeEIsQ0FBZDtBQUEyRCxJQUFJZ00sS0FBSjtBQUFVdFEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDcVEsT0FBSyxDQUFDcFEsQ0FBRCxFQUFHO0FBQUNvUSxTQUFLLEdBQUNwUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRTlELE1BQU1vRSxrQkFBa0IsR0FBRyxJQUFJZ00sS0FBSyxDQUFDQyxVQUFWLENBQXFCLHNCQUFyQixDQUEzQixDOzs7Ozs7Ozs7OztBQ0ZQdlEsTUFBTSxDQUFDcVEsTUFBUCxDQUFjO0FBQUM3TCxXQUFTLEVBQUMsTUFBSUE7QUFBZixDQUFkO0FBQXlDLElBQUk4TCxLQUFKO0FBQVV0USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNxUSxPQUFLLENBQUNwUSxDQUFELEVBQUc7QUFBQ29RLFNBQUssR0FBQ3BRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFNUMsTUFBTXNFLFNBQVMsR0FBRyxJQUFJOEwsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFdBQXJCLENBQWxCLEM7Ozs7Ozs7Ozs7O0FDRlB2USxNQUFNLENBQUNxUSxNQUFQLENBQWM7QUFBQ25NLGVBQWEsRUFBQyxNQUFJQTtBQUFuQixDQUFkO0FBQWlELElBQUlvTSxLQUFKO0FBQVV0USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNxUSxPQUFLLENBQUNwUSxDQUFELEVBQUc7QUFBQ29RLFNBQUssR0FBQ3BRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFcEQsTUFBTWdFLGFBQWEsR0FBRyxJQUFJb00sS0FBSyxDQUFDQyxVQUFWLENBQXFCLGdCQUFyQixDQUF0QixDOzs7Ozs7Ozs7OztBQ0ZQO0FBQ0Esd0M7Ozs7Ozs7Ozs7O0FDREEsSUFBSXZNLFNBQUo7QUFBY2hFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDRCQUFaLEVBQXlDO0FBQUMrRCxXQUFTLENBQUM5RCxDQUFELEVBQUc7QUFBQzhELGFBQVMsR0FBQzlELENBQVY7QUFBWTs7QUFBMUIsQ0FBekMsRUFBcUUsQ0FBckU7QUFBd0UsSUFBSWlFLGdCQUFKLEVBQXFCQyxTQUFyQixFQUErQjRULGlCQUEvQixFQUFpREMsWUFBakQsRUFBOERKLFdBQTlELEVBQTBFQyxvQkFBMUU7QUFBK0Y5WCxNQUFNLENBQUNDLElBQVAsQ0FBWSw4QkFBWixFQUEyQztBQUFDa0Usa0JBQWdCLENBQUNqRSxDQUFELEVBQUc7QUFBQ2lFLG9CQUFnQixHQUFDakUsQ0FBakI7QUFBbUIsR0FBeEM7O0FBQXlDa0UsV0FBUyxDQUFDbEUsQ0FBRCxFQUFHO0FBQUNrRSxhQUFTLEdBQUNsRSxDQUFWO0FBQVksR0FBbEU7O0FBQW1FOFgsbUJBQWlCLENBQUM5WCxDQUFELEVBQUc7QUFBQzhYLHFCQUFpQixHQUFDOVgsQ0FBbEI7QUFBb0IsR0FBNUc7O0FBQTZHK1gsY0FBWSxDQUFDL1gsQ0FBRCxFQUFHO0FBQUMrWCxnQkFBWSxHQUFDL1gsQ0FBYjtBQUFlLEdBQTVJOztBQUE2STJYLGFBQVcsQ0FBQzNYLENBQUQsRUFBRztBQUFDMlgsZUFBVyxHQUFDM1gsQ0FBWjtBQUFjLEdBQTFLOztBQUEySzRYLHNCQUFvQixDQUFDNVgsQ0FBRCxFQUFHO0FBQUM0WCx3QkFBb0IsR0FBQzVYLENBQXJCO0FBQXVCOztBQUExTixDQUEzQyxFQUF1USxDQUF2UTtBQUEwUSxJQUFJcUUsWUFBSjtBQUFpQnZFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdDQUFaLEVBQXFEO0FBQUNzRSxjQUFZLENBQUNyRSxDQUFELEVBQUc7QUFBQ3FFLGdCQUFZLEdBQUNyRSxDQUFiO0FBQWU7O0FBQWhDLENBQXJELEVBQXVGLENBQXZGO0FBQTBGLElBQUlnRSxhQUFKO0FBQWtCbEUsTUFBTSxDQUFDQyxJQUFQLENBQVksNENBQVosRUFBeUQ7QUFBQ2lFLGVBQWEsQ0FBQ2hFLENBQUQsRUFBRztBQUFDZ0UsaUJBQWEsR0FBQ2hFLENBQWQ7QUFBZ0I7O0FBQWxDLENBQXpELEVBQTZGLENBQTdGO0FBQWdHLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQWpELEVBQStFLENBQS9FO0FBQWtGLElBQUlvRSxrQkFBSjtBQUF1QnRFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG1DQUFaLEVBQWdEO0FBQUNxRSxvQkFBa0IsQ0FBQ3BFLENBQUQsRUFBRztBQUFDb0Usc0JBQWtCLEdBQUNwRSxDQUFuQjtBQUFxQjs7QUFBNUMsQ0FBaEQsRUFBOEYsQ0FBOUY7QUFBaUcsSUFBSXNFLFNBQUo7QUFBY3hFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtDQUFaLEVBQStDO0FBQUN1RSxXQUFTLENBQUN0RSxDQUFELEVBQUc7QUFBQ3NFLGFBQVMsR0FBQ3RFLENBQVY7QUFBWTs7QUFBMUIsQ0FBL0MsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSXNWLFNBQUo7QUFBY3hWLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUN1VixXQUFTLENBQUN0VixDQUFELEVBQUc7QUFBQ3NWLGFBQVMsR0FBQ3RWLENBQVY7QUFBWTs7QUFBMUIsQ0FBakQsRUFBNkUsQ0FBN0U7QUFBZ0YsSUFBSXdRLFdBQUo7QUFBZ0IxUSxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDeVEsYUFBVyxDQUFDeFEsQ0FBRCxFQUFHO0FBQUN3USxlQUFXLEdBQUN4USxDQUFaO0FBQWM7O0FBQTlCLENBQXZDLEVBQXVFLENBQXZFO0FBWS9qQ3dRLFdBQVcsQ0FBQ2hLLGFBQVosR0FBNEJnWCxXQUE1QixDQUF3QztBQUFDdlgsUUFBTSxFQUFFLENBQUM7QUFBVixDQUF4QyxFQUFxRDtBQUFDd1gsUUFBTSxFQUFDO0FBQVIsQ0FBckQ7QUFFQTNaLFNBQVMsQ0FBQzBDLGFBQVYsR0FBMEJnWCxXQUExQixDQUFzQztBQUFDdlgsUUFBTSxFQUFFLENBQUM7QUFBVixDQUF0QyxFQUFtRDtBQUFDd1gsUUFBTSxFQUFDO0FBQVIsQ0FBbkQ7QUFDQTNaLFNBQVMsQ0FBQzBDLGFBQVYsR0FBMEJnWCxXQUExQixDQUFzQztBQUFDNVgsaUJBQWUsRUFBQztBQUFqQixDQUF0QztBQUVBdEIsU0FBUyxDQUFDa0MsYUFBVixHQUEwQmdYLFdBQTFCLENBQXNDO0FBQUN2WCxRQUFNLEVBQUUsQ0FBQztBQUFWLENBQXRDLEUsQ0FFQTs7QUFFQWhDLGdCQUFnQixDQUFDdUMsYUFBakIsR0FBaUNnWCxXQUFqQyxDQUE2QztBQUFDM2MsU0FBTyxFQUFDLENBQVQ7QUFBV29GLFFBQU0sRUFBRSxDQUFDO0FBQXBCLENBQTdDLEVBQXFFO0FBQUN3WCxRQUFNLEVBQUM7QUFBUixDQUFyRTtBQUNBeFosZ0JBQWdCLENBQUN1QyxhQUFqQixHQUFpQ2dYLFdBQWpDLENBQTZDO0FBQUMzYyxTQUFPLEVBQUMsQ0FBVDtBQUFXa0ssUUFBTSxFQUFDLENBQWxCO0FBQXFCOUUsUUFBTSxFQUFFLENBQUM7QUFBOUIsQ0FBN0M7QUFFQS9CLFNBQVMsQ0FBQ3NDLGFBQVYsR0FBMEJnWCxXQUExQixDQUFzQztBQUFDdlgsUUFBTSxFQUFFLENBQUM7QUFBVixDQUF0QyxFQUFvRDtBQUFDd1gsUUFBTSxFQUFDO0FBQVIsQ0FBcEQ7QUFFQTFGLFlBQVksQ0FBQ3ZSLGFBQWIsR0FBNkJnWCxXQUE3QixDQUF5QztBQUFDak4sVUFBUSxFQUFDLENBQVY7QUFBYXVJLE9BQUssRUFBQyxDQUFuQjtBQUFzQndCLFdBQVMsRUFBRSxDQUFDO0FBQWxDLENBQXpDO0FBQ0F2QyxZQUFZLENBQUN2UixhQUFiLEdBQTZCZ1gsV0FBN0IsQ0FBeUM7QUFBQ2pOLFVBQVEsRUFBQyxDQUFWO0FBQWF3SSxhQUFXLEVBQUMsQ0FBQztBQUExQixDQUF6QztBQUNBaEIsWUFBWSxDQUFDdlIsYUFBYixHQUE2QmdYLFdBQTdCLENBQXlDO0FBQUMxRSxPQUFLLEVBQUMsQ0FBUDtBQUFVQyxhQUFXLEVBQUMsQ0FBQztBQUF2QixDQUF6QztBQUNBaEIsWUFBWSxDQUFDdlIsYUFBYixHQUE2QmdYLFdBQTdCLENBQXlDO0FBQUMxRSxPQUFLLEVBQUMsQ0FBUDtBQUFVdkksVUFBUSxFQUFDLENBQW5CO0FBQXNCd0ksYUFBVyxFQUFDLENBQUM7QUFBbkMsQ0FBekMsRUFBZ0Y7QUFBQzBFLFFBQU0sRUFBQztBQUFSLENBQWhGO0FBRUEzRixpQkFBaUIsQ0FBQ3RSLGFBQWxCLEdBQWtDZ1gsV0FBbEMsQ0FBOEM7QUFBQ2pOLFVBQVEsRUFBQztBQUFWLENBQTlDO0FBQ0F1SCxpQkFBaUIsQ0FBQ3RSLGFBQWxCLEdBQWtDZ1gsV0FBbEMsQ0FBOEM7QUFBQzFFLE9BQUssRUFBQztBQUFQLENBQTlDO0FBQ0FoQixpQkFBaUIsQ0FBQ3RSLGFBQWxCLEdBQWtDZ1gsV0FBbEMsQ0FBOEM7QUFBQ2pOLFVBQVEsRUFBQyxDQUFWO0FBQWF1SSxPQUFLLEVBQUM7QUFBbkIsQ0FBOUMsRUFBb0U7QUFBQzJFLFFBQU0sRUFBQztBQUFSLENBQXBFO0FBRUE5RixXQUFXLENBQUNuUixhQUFaLEdBQTRCZ1gsV0FBNUIsQ0FBd0M7QUFBQ2xjLE1BQUksRUFBQyxDQUFOO0FBQVN5VSxXQUFTLEVBQUMsQ0FBQztBQUFwQixDQUF4QyxFQUErRDtBQUFDMEgsUUFBTSxFQUFDO0FBQVIsQ0FBL0Q7QUFDQTdGLG9CQUFvQixDQUFDcFIsYUFBckIsR0FBcUNnWCxXQUFyQyxDQUFpRDtBQUFDNVgsaUJBQWUsRUFBQyxDQUFqQjtBQUFtQm1RLFdBQVMsRUFBQyxDQUFDO0FBQTlCLENBQWpELEVBQWtGO0FBQUMwSCxRQUFNLEVBQUM7QUFBUixDQUFsRixFLENBQ0E7O0FBRUFwWixZQUFZLENBQUNtQyxhQUFiLEdBQTZCZ1gsV0FBN0IsQ0FBeUM7QUFBQ25HLFFBQU0sRUFBQztBQUFSLENBQXpDLEVBQW9EO0FBQUNvRyxRQUFNLEVBQUM7QUFBUixDQUFwRDtBQUNBcFosWUFBWSxDQUFDbUMsYUFBYixHQUE2QmdYLFdBQTdCLENBQXlDO0FBQUN2WCxRQUFNLEVBQUMsQ0FBQztBQUFULENBQXpDLEUsQ0FDQTs7QUFDQTVCLFlBQVksQ0FBQ21DLGFBQWIsR0FBNkJnWCxXQUE3QixDQUF5QztBQUFDLDJCQUF3QjtBQUF6QixDQUF6QztBQUNBblosWUFBWSxDQUFDbUMsYUFBYixHQUE2QmdYLFdBQTdCLENBQXlDO0FBQUMsNkJBQTBCO0FBQTNCLENBQXpDO0FBRUF4WixhQUFhLENBQUN3QyxhQUFkLEdBQThCZ1gsV0FBOUIsQ0FBMEM7QUFBQ2pULGNBQVksRUFBQyxDQUFDO0FBQWYsQ0FBMUM7QUFFQXJLLFVBQVUsQ0FBQ3NHLGFBQVgsR0FBMkJnWCxXQUEzQixDQUF1QztBQUFDM2MsU0FBTyxFQUFDO0FBQVQsQ0FBdkMsRUFBbUQ7QUFBQzRjLFFBQU0sRUFBQyxJQUFSO0FBQWNDLHlCQUF1QixFQUFFO0FBQUU3YyxXQUFPLEVBQUU7QUFBRWdLLGFBQU8sRUFBRTtBQUFYO0FBQVg7QUFBdkMsQ0FBbkQ7QUFDQTNLLFVBQVUsQ0FBQ3NHLGFBQVgsR0FBMkJnWCxXQUEzQixDQUF1QztBQUFDblYsa0JBQWdCLEVBQUM7QUFBbEIsQ0FBdkMsRUFBNEQ7QUFBQ29WLFFBQU0sRUFBQztBQUFSLENBQTVEO0FBQ0F2ZCxVQUFVLENBQUNzRyxhQUFYLEdBQTJCZ1gsV0FBM0IsQ0FBdUM7QUFBQyxtQkFBZ0I7QUFBakIsQ0FBdkMsRUFBMkQ7QUFBQ0MsUUFBTSxFQUFDLElBQVI7QUFBY0MseUJBQXVCLEVBQUU7QUFBRSxxQkFBaUI7QUFBRTdTLGFBQU8sRUFBRTtBQUFYO0FBQW5CO0FBQXZDLENBQTNEO0FBRUF6RyxrQkFBa0IsQ0FBQ29DLGFBQW5CLEdBQW1DZ1gsV0FBbkMsQ0FBK0M7QUFBQzNjLFNBQU8sRUFBQyxDQUFUO0FBQVdvRixRQUFNLEVBQUMsQ0FBQztBQUFuQixDQUEvQztBQUNBN0Isa0JBQWtCLENBQUNvQyxhQUFuQixHQUFtQ2dYLFdBQW5DLENBQStDO0FBQUNsYyxNQUFJLEVBQUM7QUFBTixDQUEvQztBQUVBZ1UsU0FBUyxDQUFDOU8sYUFBVixHQUEwQmdYLFdBQTFCLENBQXNDO0FBQUNoSSxpQkFBZSxFQUFDLENBQUM7QUFBbEIsQ0FBdEMsRUFBMkQ7QUFBQ2lJLFFBQU0sRUFBQztBQUFSLENBQTNELEU7Ozs7Ozs7Ozs7O0FDdERBM2QsTUFBTSxDQUFDQyxJQUFQLENBQVksV0FBWjtBQUF5QkQsTUFBTSxDQUFDQyxJQUFQLENBQVksbUJBQVo7QUFBaUNELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHFCQUFaO0FBQW1DLElBQUk0ZCxVQUFKO0FBQWU3ZCxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDNGQsWUFBVSxDQUFDM2QsQ0FBRCxFQUFHO0FBQUMyZCxjQUFVLEdBQUMzZCxDQUFYO0FBQWE7O0FBQTVCLENBQW5DLEVBQWlFLENBQWpFO0FBQW9FLElBQUk0ZCxNQUFKO0FBQVc5ZCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUM2ZCxRQUFNLENBQUM1ZCxDQUFELEVBQUc7QUFBQzRkLFVBQU0sR0FBQzVkLENBQVA7QUFBUzs7QUFBcEIsQ0FBM0IsRUFBaUQsQ0FBakQ7QUFjM0w7QUFFQTJkLFVBQVUsQ0FBQ0UsSUFBSSxJQUFJO0FBQ2Y7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBLFFBQU1DLE1BQU0sR0FBR0YsTUFBTSxDQUFDRyxZQUFQLEVBQWY7QUFDQUYsTUFBSSxDQUFDRyxZQUFMLENBQWtCRixNQUFNLENBQUNHLElBQVAsQ0FBWUMsUUFBWixFQUFsQjtBQUNBTCxNQUFJLENBQUNHLFlBQUwsQ0FBa0JGLE1BQU0sQ0FBQ0ssS0FBUCxDQUFhRCxRQUFiLEVBQWxCLEVBZGUsQ0FnQmY7QUFDSCxDQWpCUyxDQUFWLEM7Ozs7Ozs7Ozs7O0FDaEJBcGUsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVo7QUFBa0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG1DQUFaO0FBQWlERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx3Q0FBWjtBQUFzREQsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVo7QUFBa0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHlDQUFaO0FBQXVERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx3Q0FBWjtBQUFzREQsTUFBTSxDQUFDQyxJQUFQLENBQVksNkNBQVo7QUFBMkRELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHFDQUFaO0FBQW1ERCxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQ0FBWjtBQUF3REQsTUFBTSxDQUFDQyxJQUFQLENBQVksd0NBQVo7QUFBc0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZDQUFaO0FBQTJERCxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQ0FBWjtBQUE2REQsTUFBTSxDQUFDQyxJQUFQLENBQVksMENBQVo7QUFBd0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtDQUFaO0FBQTZERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx5Q0FBWjtBQUF1REQsTUFBTSxDQUFDQyxJQUFQLENBQVksOENBQVo7QUFBNERELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHlDQUFaO0FBQXVERCxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQ0FBWjtBQUFvREQsTUFBTSxDQUFDQyxJQUFQLENBQVksd0NBQVosRTs7Ozs7Ozs7Ozs7QUNBLzlCLElBQUlxZSxNQUFKO0FBQVd0ZSxNQUFNLENBQUNDLElBQVAsQ0FBWSxRQUFaLEVBQXFCO0FBQUM4VyxTQUFPLENBQUM3VyxDQUFELEVBQUc7QUFBQ29lLFVBQU0sR0FBQ3BlLENBQVA7QUFBUzs7QUFBckIsQ0FBckIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUErQyxJQUFJeUUsT0FBSjtBQUFZM0UsTUFBTSxDQUFDQyxJQUFQLENBQVksU0FBWixFQUFzQjtBQUFDLE1BQUlDLENBQUosRUFBTTtBQUFDeUUsV0FBTyxHQUFDekUsQ0FBUjtBQUFVOztBQUFsQixDQUF0QixFQUEwQyxDQUExQzs7QUFJOUg7QUFDQSxJQUFJcWUsTUFBTSxHQUFHQyxHQUFHLENBQUNDLE9BQUosQ0FBWSxlQUFaLENBQWIsQyxDQUNBOzs7QUFDQSxJQUFJQyxJQUFJLEdBQUdGLEdBQUcsQ0FBQ0MsT0FBSixDQUFZLGVBQVosRUFBNkJDLElBQXhDOztBQUVBLFNBQVNDLFdBQVQsQ0FBcUJDLFNBQXJCLEVBQWdDO0FBQzVCLFNBQU9BLFNBQVMsQ0FBQzNZLEdBQVYsQ0FBYyxVQUFTNFksSUFBVCxFQUFlO0FBQ2hDLFdBQU8sQ0FBQyxNQUFNLENBQUNBLElBQUksR0FBRyxJQUFSLEVBQWNULFFBQWQsQ0FBdUIsRUFBdkIsQ0FBUCxFQUFtQ1UsS0FBbkMsQ0FBeUMsQ0FBQyxDQUExQyxDQUFQO0FBQ0gsR0FGTSxFQUVKQyxJQUZJLENBRUMsRUFGRCxDQUFQO0FBR0g7O0FBRURoZixNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYa2UsZ0JBQWMsRUFBRSxVQUFTN0osTUFBVCxFQUFpQjhKLE1BQWpCLEVBQXlCO0FBQ3JDO0FBQ0EsUUFBSUMsaUJBQWlCLEdBQUdqVixNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQTBCLEtBQTFCLENBQXhCO0FBQ0EsUUFBSWlWLE1BQU0sR0FBR2xWLE1BQU0sQ0FBQ21WLEtBQVAsQ0FBYSxFQUFiLENBQWI7QUFDQUYscUJBQWlCLENBQUNHLElBQWxCLENBQXVCRixNQUF2QixFQUErQixDQUEvQjtBQUNBbFYsVUFBTSxDQUFDQyxJQUFQLENBQVlpTCxNQUFNLENBQUMxVCxLQUFuQixFQUEwQixRQUExQixFQUFvQzRkLElBQXBDLENBQXlDRixNQUF6QyxFQUFpREQsaUJBQWlCLENBQUNwZCxNQUFuRTtBQUNBLFdBQU93YyxNQUFNLENBQUNnQixNQUFQLENBQWNMLE1BQWQsRUFBc0JYLE1BQU0sQ0FBQ2lCLE9BQVAsQ0FBZUosTUFBZixDQUF0QixDQUFQO0FBQ0gsR0FSVTtBQVNYSyxnQkFBYyxFQUFFLFVBQVNySyxNQUFULEVBQWlCO0FBQzdCO0FBQ0EsUUFBSStKLGlCQUFpQixHQUFHalYsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUEwQixLQUExQixDQUF4QjtBQUNBLFFBQUlpVixNQUFNLEdBQUdsVixNQUFNLENBQUNDLElBQVAsQ0FBWW9VLE1BQU0sQ0FBQ21CLFNBQVAsQ0FBaUJuQixNQUFNLENBQUNvQixNQUFQLENBQWN2SyxNQUFkLEVBQXNCd0ssS0FBdkMsQ0FBWixDQUFiO0FBQ0EsV0FBT1IsTUFBTSxDQUFDTCxLQUFQLENBQWFJLGlCQUFpQixDQUFDcGQsTUFBL0IsRUFBdUNzYyxRQUF2QyxDQUFnRCxRQUFoRCxDQUFQO0FBQ0gsR0FkVTtBQWVYd0IsY0FBWSxFQUFFLFVBQVNDLFlBQVQsRUFBc0I7QUFDaEMsUUFBSTllLE9BQU8sR0FBR3VkLE1BQU0sQ0FBQ29CLE1BQVAsQ0FBY0csWUFBZCxDQUFkO0FBQ0EsV0FBT3ZCLE1BQU0sQ0FBQ2dCLE1BQVAsQ0FBY3ZmLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCaVcsbUJBQXJDLEVBQTBEbGMsT0FBTyxDQUFDNGUsS0FBbEUsQ0FBUDtBQUNILEdBbEJVO0FBbUJYRyxtQkFBaUIsRUFBRSxVQUFTQyxVQUFULEVBQW9CO0FBQ25DLFFBQUl2YSxRQUFRLEdBQUdyRixJQUFJLENBQUNLLEdBQUwsQ0FBU3VmLFVBQVQsQ0FBZjs7QUFDQSxRQUFJdmEsUUFBUSxDQUFDOUUsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQixVQUFJK0UsSUFBSSxHQUFHZCxPQUFPLENBQUNlLElBQVIsQ0FBYUYsUUFBUSxDQUFDbkUsT0FBdEIsQ0FBWDtBQUNBLGFBQU9vRSxJQUFJLENBQUMsbUJBQUQsQ0FBSixDQUEwQkUsSUFBMUIsQ0FBK0IsS0FBL0IsQ0FBUDtBQUNIO0FBQ0o7QUF6QlUsQ0FBZixFOzs7Ozs7Ozs7OztBQ2ZBM0YsTUFBTSxDQUFDcVEsTUFBUCxDQUFjO0FBQUMyUCxhQUFXLEVBQUMsTUFBSUEsV0FBakI7QUFBNkJDLG9CQUFrQixFQUFDLE1BQUlBLGtCQUFwRDtBQUF1RUMsVUFBUSxFQUFDLE1BQUlBLFFBQXBGO0FBQTZGN0MsUUFBTSxFQUFDLE1BQUlBLE1BQXhHO0FBQStHOEMsVUFBUSxFQUFDLE1BQUlBO0FBQTVILENBQWQ7QUFBcUosSUFBSUMsS0FBSjtBQUFVcGdCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLE9BQVosRUFBb0I7QUFBQzhXLFNBQU8sQ0FBQzdXLENBQUQsRUFBRztBQUFDa2dCLFNBQUssR0FBQ2xnQixDQUFOO0FBQVE7O0FBQXBCLENBQXBCLEVBQTBDLENBQTFDO0FBQTZDLElBQUltZ0IsbUJBQUo7QUFBd0JyZ0IsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDb2dCLHFCQUFtQixDQUFDbmdCLENBQUQsRUFBRztBQUFDbWdCLHVCQUFtQixHQUFDbmdCLENBQXBCO0FBQXNCOztBQUE5QyxDQUF6QixFQUF5RSxDQUF6RTs7QUFHN04sTUFBTThmLFdBQVcsR0FBSU0sS0FBRCxJQUFXO0FBQ2xDLFVBQVFBLEtBQUssQ0FBQ3ZOLEtBQWQ7QUFDQSxTQUFLLE9BQUw7QUFDSSxhQUFPLElBQVA7O0FBQ0o7QUFDSSxhQUFPLElBQVA7QUFKSjtBQU1ILENBUE07O0FBVUEsTUFBTWtOLGtCQUFrQixHQUFJSyxLQUFELElBQVc7QUFDekMsVUFBUUEsS0FBSyxDQUFDNVksTUFBZDtBQUNBLFNBQUssUUFBTDtBQUNJLGFBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSixTQUFLLFVBQUw7QUFDSSxhQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxTQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssZUFBTDtBQUNJLGFBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSixTQUFLLGNBQUw7QUFDSSxhQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0o7QUFDSSxhQUFPLDhCQUFQO0FBWko7QUFjSCxDQWZNOztBQWlCQSxNQUFNd1ksUUFBUSxHQUFJSSxLQUFELElBQVc7QUFDL0IsVUFBUUEsS0FBSyxDQUFDQyxJQUFkO0FBQ0EsU0FBSyxLQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssSUFBTDtBQUNJLGFBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSixTQUFLLFNBQUw7QUFDSSxhQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxjQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKO0FBQ0ksYUFBTyw4QkFBUDtBQVZKO0FBWUgsQ0FiTTs7QUFlQSxNQUFNbEQsTUFBTSxHQUFJaUQsS0FBRCxJQUFXO0FBQzdCLE1BQUlBLEtBQUssQ0FBQ0UsS0FBVixFQUFnQjtBQUNaLFdBQU87QUFBTSxlQUFTLEVBQUM7QUFBaEIsT0FBMkM7QUFBRyxlQUFTLEVBQUM7QUFBYixNQUEzQyxDQUFQO0FBQ0gsR0FGRCxNQUdJO0FBQ0EsV0FBTztBQUFNLGVBQVMsRUFBQztBQUFoQixPQUEwQztBQUFHLGVBQVMsRUFBQztBQUFiLE1BQTFDLENBQVA7QUFDSDtBQUNKLENBUE07O0FBU0EsTUFBTUwsUUFBTixTQUF1QkMsS0FBSyxDQUFDSyxTQUE3QixDQUF1QztBQUMxQ0MsYUFBVyxDQUFDSixLQUFELEVBQVE7QUFDZixVQUFNQSxLQUFOO0FBQ0EsU0FBS0ssR0FBTCxHQUFXUCxLQUFLLENBQUNRLFNBQU4sRUFBWDtBQUNIOztBQUVEQyxRQUFNLEdBQUc7QUFDTCxXQUFPLENBQ0g7QUFBRyxTQUFHLEVBQUMsTUFBUDtBQUFjLGVBQVMsRUFBQywwQkFBeEI7QUFBbUQsU0FBRyxFQUFFLEtBQUtGO0FBQTdELGNBREcsRUFFSCxvQkFBQyxtQkFBRDtBQUFxQixTQUFHLEVBQUMsU0FBekI7QUFBbUMsZUFBUyxFQUFDLE9BQTdDO0FBQXFELFlBQU0sRUFBRSxLQUFLQTtBQUFsRSxPQUNLLEtBQUtMLEtBQUwsQ0FBV2xRLFFBQVgsR0FBb0IsS0FBS2tRLEtBQUwsQ0FBV2xRLFFBQS9CLEdBQXdDLEtBQUtrUSxLQUFMLENBQVdRLFdBRHhELENBRkcsQ0FBUDtBQU1IOztBQWJ5QyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3REOUM5Z0IsTUFBTSxDQUFDcVEsTUFBUCxDQUFjO0FBQUMwRyxTQUFPLEVBQUMsTUFBSWdLO0FBQWIsQ0FBZDtBQUFrQyxJQUFJaGhCLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSThnQixNQUFKO0FBQVdoaEIsTUFBTSxDQUFDQyxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDOFcsU0FBTyxDQUFDN1csQ0FBRCxFQUFHO0FBQUM4Z0IsVUFBTSxHQUFDOWdCLENBQVA7QUFBUzs7QUFBckIsQ0FBckIsRUFBNEMsQ0FBNUM7O0FBRzdHK2dCLFVBQVUsR0FBSXhmLEtBQUQsSUFBVztBQUN2QixNQUFJeWYsU0FBUyxHQUFHLFVBQWhCO0FBQ0F6ZixPQUFLLEdBQUcwSyxJQUFJLENBQUM2RSxLQUFMLENBQVd2UCxLQUFLLEdBQUcsSUFBbkIsSUFBMkIsSUFBbkM7QUFDQSxNQUFJMEssSUFBSSxDQUFDNkUsS0FBTCxDQUFXdlAsS0FBWCxNQUFzQkEsS0FBMUIsRUFDQ3lmLFNBQVMsR0FBRyxLQUFaLENBREQsS0FFSyxJQUFJL1UsSUFBSSxDQUFDNkUsS0FBTCxDQUFXdlAsS0FBSyxHQUFDLEVBQWpCLE1BQXlCQSxLQUFLLEdBQUMsRUFBbkMsRUFDSnlmLFNBQVMsR0FBRyxPQUFaLENBREksS0FFQSxJQUFJL1UsSUFBSSxDQUFDNkUsS0FBTCxDQUFXdlAsS0FBSyxHQUFDLEdBQWpCLE1BQTBCQSxLQUFLLEdBQUMsR0FBcEMsRUFDSnlmLFNBQVMsR0FBRyxRQUFaLENBREksS0FFQSxJQUFJL1UsSUFBSSxDQUFDNkUsS0FBTCxDQUFXdlAsS0FBSyxHQUFDLElBQWpCLE1BQTJCQSxLQUFLLEdBQUMsSUFBckMsRUFDSnlmLFNBQVMsR0FBRyxTQUFaO0FBQ0QsU0FBT0YsTUFBTSxDQUFDdmYsS0FBRCxDQUFOLENBQWMwZixNQUFkLENBQXFCRCxTQUFyQixDQUFQO0FBQ0EsQ0FaRDs7QUFjZSxNQUFNSCxJQUFOLENBQVc7QUFPekJMLGFBQVcsQ0FBQzVOLE1BQUQsRUFBcUI7QUFBQSxRQUFaQyxLQUFZLHVFQUFOLElBQU07QUFDL0IsUUFBSSxPQUFPRCxNQUFQLEtBQWtCLFFBQXRCLEVBQ0MsQ0FBQztBQUFDQSxZQUFEO0FBQVNDO0FBQVQsUUFBa0JELE1BQW5COztBQUNELFFBQUksQ0FBQ0MsS0FBRCxJQUFVQSxLQUFLLENBQUNxTyxXQUFOLE9BQXdCTCxJQUFJLENBQUNNLFlBQUwsQ0FBa0JELFdBQWxCLEVBQXRDLEVBQXVFO0FBQ3RFLFdBQUtFLE9BQUwsR0FBZXpLLE1BQU0sQ0FBQy9ELE1BQUQsQ0FBckI7QUFDQSxLQUZELE1BRU8sSUFBSUMsS0FBSyxDQUFDcU8sV0FBTixPQUF3QkwsSUFBSSxDQUFDUSxZQUFMLENBQWtCSCxXQUFsQixFQUE1QixFQUE2RDtBQUNuRSxXQUFLRSxPQUFMLEdBQWV6SyxNQUFNLENBQUMvRCxNQUFELENBQU4sR0FBaUJpTyxJQUFJLENBQUNTLGVBQXJDO0FBQ0EsS0FGTSxNQUdGO0FBQ0osWUFBTXBLLEtBQUssNkJBQXNCckUsS0FBdEIsRUFBWDtBQUNBO0FBQ0Q7O0FBRUQsTUFBSUQsTUFBSixHQUFjO0FBQ2IsV0FBTyxLQUFLd08sT0FBWjtBQUNBOztBQUVELE1BQUlHLGFBQUosR0FBcUI7QUFDcEIsV0FBTyxLQUFLSCxPQUFMLEdBQWVQLElBQUksQ0FBQ1MsZUFBM0I7QUFDQTs7QUFFRHBELFVBQVEsQ0FBRXNELFNBQUYsRUFBYTtBQUNwQjtBQUNBLFFBQUlDLFFBQVEsR0FBR1osSUFBSSxDQUFDUyxlQUFMLElBQXNCRSxTQUFTLEdBQUN2VixJQUFJLENBQUN5VixHQUFMLENBQVMsRUFBVCxFQUFhRixTQUFiLENBQUQsR0FBeUIsS0FBeEQsQ0FBZjs7QUFDQSxRQUFJLEtBQUs1TyxNQUFMLEdBQWM2TyxRQUFsQixFQUE0QjtBQUMzQix1QkFBVVgsTUFBTSxDQUFDLEtBQUtsTyxNQUFOLENBQU4sQ0FBb0JxTyxNQUFwQixDQUEyQixLQUEzQixDQUFWLGNBQStDSixJQUFJLENBQUNNLFlBQXBEO0FBQ0EsS0FGRCxNQUVPO0FBQ04sdUJBQVVLLFNBQVMsR0FBQ1YsTUFBTSxDQUFDLEtBQUtTLGFBQU4sQ0FBTixDQUEyQk4sTUFBM0IsQ0FBa0MsU0FBUyxJQUFJVSxNQUFKLENBQVdILFNBQVgsQ0FBM0MsQ0FBRCxHQUFtRVQsVUFBVSxDQUFDLEtBQUtRLGFBQU4sQ0FBaEcsY0FBd0hWLElBQUksQ0FBQ1EsWUFBN0g7QUFDQTtBQUNEOztBQUVETyxZQUFVLENBQUVaLFNBQUYsRUFBYTtBQUN0QixRQUFJcE8sTUFBTSxHQUFHLEtBQUtBLE1BQWxCOztBQUNBLFFBQUlvTyxTQUFKLEVBQWU7QUFDZHBPLFlBQU0sR0FBR2tPLE1BQU0sQ0FBQ2xPLE1BQUQsQ0FBTixDQUFlcU8sTUFBZixDQUFzQkQsU0FBdEIsQ0FBVDtBQUNBOztBQUNELHFCQUFVcE8sTUFBVixjQUFvQmlPLElBQUksQ0FBQ00sWUFBekI7QUFDQTs7QUFFRFUsYUFBVyxDQUFFYixTQUFGLEVBQWE7QUFDdkIsUUFBSXBPLE1BQU0sR0FBRyxLQUFLMk8sYUFBbEI7O0FBQ0EsUUFBSVAsU0FBSixFQUFlO0FBQ2RwTyxZQUFNLEdBQUdrTyxNQUFNLENBQUNsTyxNQUFELENBQU4sQ0FBZXFPLE1BQWYsQ0FBc0JELFNBQXRCLENBQVQ7QUFDQTs7QUFDRCxxQkFBVXBPLE1BQVYsY0FBb0JpTyxJQUFJLENBQUNRLFlBQXpCO0FBQ0E7O0FBcER3Qjs7QUFBTFIsSSxDQUNiUSxZLEdBQWV4aEIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJnYixZO0FBRHpCakIsSSxDQUVia0Isa0IsR0FBcUJsaUIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJrYixrQkFBdkIsSUFBOENuQixJQUFJLENBQUNRLFlBQUwsR0FBb0IsRztBQUYxRVIsSSxDQUdiTSxZLEdBQWV0aEIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJ5TCxZO0FBSHpCc08sSSxDQUliUyxlLEdBQWtCM0ssTUFBTSxDQUFDOVcsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJxTyxlQUF4QixDO0FBSlgwTCxJLENBS2JvQixRLEdBQVcsSUFBSXRMLE1BQU0sQ0FBQzlXLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCcU8sZUFBeEIsQzs7Ozs7Ozs7Ozs7QUN0QjdCclYsTUFBTSxDQUFDQyxJQUFQLENBQVkseUJBQVo7QUFBdUNELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVCQUFaO0FBSXZDO0FBQ0E7QUFFQWlJLE9BQU8sR0FBRyxLQUFWO0FBQ0FxUixpQkFBaUIsR0FBRyxLQUFwQjtBQUNBOEIsc0JBQXNCLEdBQUcsS0FBekI7QUFDQTVULEdBQUcsR0FBRzFILE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JxYixNQUFoQixDQUF1QkMsR0FBN0I7QUFDQTVoQixHQUFHLEdBQUdWLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JxYixNQUFoQixDQUF1QkUsR0FBN0I7QUFDQUMsV0FBVyxHQUFHLENBQWQ7QUFDQUMsVUFBVSxHQUFHLENBQWI7QUFDQUMsY0FBYyxHQUFHLENBQWpCO0FBQ0FDLGFBQWEsR0FBRyxDQUFoQjtBQUNBQyxxQkFBcUIsR0FBRyxDQUF4QjtBQUNBQyxnQkFBZ0IsR0FBRyxDQUFuQjtBQUNBQyxlQUFlLEdBQUcsQ0FBbEI7QUFDQUMsY0FBYyxHQUFHLENBQWpCO0FBRUEsTUFBTUMsZUFBZSxHQUFHLHdCQUF4Qjs7QUFFQUMsaUJBQWlCLEdBQUcsTUFBTTtBQUN0QmpqQixRQUFNLENBQUNxSSxJQUFQLENBQVksb0JBQVosRUFBa0MsQ0FBQzZhLEtBQUQsRUFBUTNoQixNQUFSLEtBQW1CO0FBQ2pELFFBQUkyaEIsS0FBSixFQUFVO0FBQ05yaUIsYUFBTyxDQUFDQyxHQUFSLENBQVksbUJBQWlCb2lCLEtBQTdCO0FBQ0gsS0FGRCxNQUdJO0FBQ0FyaUIsYUFBTyxDQUFDQyxHQUFSLENBQVksbUJBQWlCUyxNQUE3QjtBQUNIO0FBQ0osR0FQRDtBQVFILENBVEQ7O0FBV0E0aEIsV0FBVyxHQUFHLE1BQU07QUFDaEJuakIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLHFCQUFaLEVBQW1DLENBQUM2YSxLQUFELEVBQVEzaEIsTUFBUixLQUFtQjtBQUNsRCxRQUFJMmhCLEtBQUosRUFBVTtBQUNOcmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFpQm9pQixLQUE3QjtBQUNILEtBRkQsTUFHSTtBQUNBcmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFpQlMsTUFBN0I7QUFDSDtBQUNKLEdBUEQ7QUFRSCxDQVREOztBQVdBNmhCLGlCQUFpQixHQUFHLE1BQU07QUFDdEJwakIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLHlCQUFaLEVBQXVDLENBQUM2YSxLQUFELEVBQVEzaEIsTUFBUixLQUFtQjtBQUN0RCxRQUFJMmhCLEtBQUosRUFBVTtBQUNOcmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLG9CQUFrQm9pQixLQUE5QjtBQUNIO0FBQ0osR0FKRDtBQUtILENBTkQ7O0FBUUFHLGlCQUFpQixHQUFHLE1BQU07QUFDdkJyakIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLDhCQUFaLEVBQTRDLENBQUM2YSxLQUFELEVBQVEzaEIsTUFBUixLQUFtQjtBQUMzRCxRQUFJMmhCLEtBQUosRUFBVTtBQUNOcmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGFBQVlvaUIsS0FBeEI7QUFDSDs7QUFDRCxRQUFJM2hCLE1BQUosRUFBVztBQUNQVixhQUFPLENBQUNDLEdBQVIsQ0FBWSxhQUFXUyxNQUF2QjtBQUNIO0FBQ0osR0FQRDtBQVFGLENBVEQsQyxDQVdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBRUEraEIsa0JBQWtCLEdBQUcsTUFBTTtBQUN2QnRqQixRQUFNLENBQUNxSSxJQUFQLENBQVksd0NBQVosRUFBc0QsQ0FBQzZhLEtBQUQsRUFBUTNoQixNQUFSLEtBQWtCO0FBQ3BFLFFBQUkyaEIsS0FBSixFQUFVO0FBQ05yaUIsYUFBTyxDQUFDQyxHQUFSLENBQVksMEJBQXlCb2lCLEtBQXJDO0FBQ0g7O0FBQ0QsUUFBSTNoQixNQUFKLEVBQVc7QUFDUFYsYUFBTyxDQUFDQyxHQUFSLENBQVksc0JBQXNCUyxNQUFsQztBQUNIO0FBQ0osR0FQRDtBQVFKOzs7Ozs7Ozs7O0FBVUMsQ0FuQkQ7O0FBcUJBZ2lCLGNBQWMsR0FBRyxNQUFNO0FBQ25CdmpCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSw0QkFBWixFQUEwQyxDQUFDNmEsS0FBRCxFQUFRM2hCLE1BQVIsS0FBbUI7QUFDekQsUUFBSTJoQixLQUFKLEVBQVU7QUFDTnJpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSw0QkFBMkJvaUIsS0FBdkM7QUFDSCxLQUZELE1BR0k7QUFDQXJpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBd0JTLE1BQXBDO0FBQ0g7QUFDSixHQVBEO0FBUUgsQ0FURDs7QUFXQWlpQixpQkFBaUIsR0FBRyxNQUFLO0FBQ3JCO0FBQ0F4akIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLDRDQUFaLEVBQTBELEdBQTFELEVBQStELENBQUM2YSxLQUFELEVBQVEzaEIsTUFBUixLQUFtQjtBQUM5RSxRQUFJMmhCLEtBQUosRUFBVTtBQUNOcmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDBDQUF3Q29pQixLQUFwRDtBQUNILEtBRkQsTUFHSTtBQUNBcmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHVDQUFxQ1MsTUFBakQ7QUFDSDtBQUNKLEdBUEQ7QUFTQXZCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSx3QkFBWixFQUFzQyxDQUFDNmEsS0FBRCxFQUFRM2hCLE1BQVIsS0FBbUI7QUFDckQsUUFBSTJoQixLQUFKLEVBQVU7QUFDTnJpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSwyQkFBeUJvaUIsS0FBckM7QUFDSCxLQUZELE1BR0k7QUFDQXJpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBc0JTLE1BQWxDO0FBQ0g7QUFDSixHQVBEO0FBUUgsQ0FuQkQ7O0FBcUJBa2lCLGVBQWUsR0FBRyxNQUFLO0FBQ25CO0FBQ0F6akIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLDRDQUFaLEVBQTBELEdBQTFELEVBQStELENBQUM2YSxLQUFELEVBQVEzaEIsTUFBUixLQUFtQjtBQUM5RSxRQUFJMmhCLEtBQUosRUFBVTtBQUNOcmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHdDQUFzQ29pQixLQUFsRDtBQUNILEtBRkQsTUFHSTtBQUNBcmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHFDQUFtQ1MsTUFBL0M7QUFDSDtBQUNKLEdBUEQ7QUFRSCxDQVZEOztBQVlBbWlCLGNBQWMsR0FBRyxNQUFLO0FBQ2xCO0FBQ0ExakIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLDRDQUFaLEVBQTBELEdBQTFELEVBQStELENBQUM2YSxLQUFELEVBQVEzaEIsTUFBUixLQUFtQjtBQUM5RSxRQUFJMmhCLEtBQUosRUFBVTtBQUNOcmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHVDQUFxQ29pQixLQUFqRDtBQUNILEtBRkQsTUFHSTtBQUNBcmlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLG9DQUFrQ1MsTUFBOUM7QUFDSDtBQUNKLEdBUEQ7QUFTQXZCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSw0Q0FBWixFQUEwRCxDQUFDNmEsS0FBRCxFQUFRM2hCLE1BQVIsS0FBbUI7QUFDekUsUUFBSTJoQixLQUFKLEVBQVU7QUFDTnJpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSwyQ0FBMENvaUIsS0FBdEQ7QUFDSCxLQUZELE1BR0s7QUFDRHJpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx3Q0FBdUNTLE1BQW5EO0FBQ0g7QUFDSixHQVBEO0FBUUgsQ0FuQkQ7O0FBdUJBdkIsTUFBTSxDQUFDMmpCLE9BQVAsQ0FBZSxZQUFVO0FBQ3JCLE1BQUkzakIsTUFBTSxDQUFDNGpCLGFBQVgsRUFBeUI7QUEvSzdCLFFBQUlDLG1CQUFKO0FBQXdCNWpCLFVBQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUM4VyxhQUFPLENBQUM3VyxDQUFELEVBQUc7QUFBQzBqQiwyQkFBbUIsR0FBQzFqQixDQUFwQjtBQUFzQjs7QUFBbEMsS0FBdkMsRUFBMkUsQ0FBM0U7QUFnTGhCMmpCLFdBQU8sQ0FBQ0MsR0FBUixDQUFZQyw0QkFBWixHQUEyQyxDQUEzQztBQUVBdGIsVUFBTSxDQUFDQyxJQUFQLENBQVlrYixtQkFBWixFQUFpQzdnQixPQUFqQyxDQUEwQ2loQixHQUFELElBQVM7QUFDOUMsVUFBSWprQixNQUFNLENBQUNnSCxRQUFQLENBQWdCaWQsR0FBaEIsS0FBd0J2VixTQUE1QixFQUF1QztBQUNuQzdOLGVBQU8sQ0FBQ3FqQixJQUFSLGdDQUFxQ0QsR0FBckM7QUFDQWprQixjQUFNLENBQUNnSCxRQUFQLENBQWdCaWQsR0FBaEIsSUFBdUIsRUFBdkI7QUFDSDs7QUFDRHZiLFlBQU0sQ0FBQ0MsSUFBUCxDQUFZa2IsbUJBQW1CLENBQUNJLEdBQUQsQ0FBL0IsRUFBc0NqaEIsT0FBdEMsQ0FBK0NtaEIsS0FBRCxJQUFXO0FBQ3JELFlBQUlua0IsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmlkLEdBQWhCLEVBQXFCRSxLQUFyQixLQUErQnpWLFNBQW5DLEVBQTZDO0FBQ3pDN04saUJBQU8sQ0FBQ3FqQixJQUFSLGdDQUFxQ0QsR0FBckMsY0FBNENFLEtBQTVDO0FBQ0Fua0IsZ0JBQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JpZCxHQUFoQixFQUFxQkUsS0FBckIsSUFBOEJOLG1CQUFtQixDQUFDSSxHQUFELENBQW5CLENBQXlCRSxLQUF6QixDQUE5QjtBQUNIO0FBQ0osT0FMRDtBQU1ILEtBWEQ7QUFZSDs7QUFFRG5rQixRQUFNLENBQUNxSSxJQUFQLENBQVksZUFBWixFQUE2QixDQUFDK0IsR0FBRCxFQUFNN0ksTUFBTixLQUFpQjtBQUMxQyxRQUFJNkksR0FBSixFQUFRO0FBQ0p2SixhQUFPLENBQUNDLEdBQVIsQ0FBWXNKLEdBQVo7QUFDSDs7QUFDRCxRQUFJN0ksTUFBSixFQUFXO0FBQ1AsVUFBSXZCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JzTSxLQUFoQixDQUFzQjhRLFVBQTFCLEVBQXFDO0FBQ2pDMUIsc0JBQWMsR0FBRzFpQixNQUFNLENBQUNxa0IsV0FBUCxDQUFtQixZQUFVO0FBQzFDakIsMkJBQWlCO0FBQ3BCLFNBRmdCLEVBRWRwakIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCb2MsaUJBRlQsQ0FBakI7QUFJQTlCLG1CQUFXLEdBQUd4aUIsTUFBTSxDQUFDcWtCLFdBQVAsQ0FBbUIsWUFBVTtBQUN2Q2xCLHFCQUFXO0FBQ2QsU0FGYSxFQUVYbmpCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QnFjLGFBRlosQ0FBZDtBQUlBOUIsa0JBQVUsR0FBR3ppQixNQUFNLENBQUNxa0IsV0FBUCxDQUFtQixZQUFVO0FBQ3RDcEIsMkJBQWlCO0FBQ3BCLFNBRlksRUFFVmpqQixNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUJzYyxjQUZiLENBQWI7QUFJQUMsMEJBQWtCLEdBQUd6a0IsTUFBTSxDQUFDcWtCLFdBQVAsQ0FBb0IsWUFBVztBQUNoRGhCLDJCQUFpQjtBQUNwQixTQUZvQixFQUVsQnJqQixNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUJ3YyxnQkFGTCxDQUFyQixDQWJpQyxDQWlCakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRWdCN0Isd0JBQWdCLEdBQUc3aUIsTUFBTSxDQUFDcWtCLFdBQVAsQ0FBbUIsWUFBVTtBQUM1Q2YsNEJBQWtCO0FBQ3JCLFNBRmtCLEVBRWhCdGpCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QnljLG9CQUZQLENBQW5CO0FBSUE3Qix1QkFBZSxHQUFHOWlCLE1BQU0sQ0FBQ3FrQixXQUFQLENBQW1CLFlBQVU7QUFDM0NkLHdCQUFjO0FBQ2pCLFNBRmlCLEVBRWZ2akIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCMGMsa0JBRlIsQ0FBbEI7QUFJQTdCLHNCQUFjLEdBQUcvaUIsTUFBTSxDQUFDcWtCLFdBQVAsQ0FBbUIsWUFBVTtBQUMxQyxjQUFJdk8sR0FBRyxHQUFHLElBQUkxUyxJQUFKLEVBQVY7O0FBQ0EsY0FBSzBTLEdBQUcsQ0FBQytPLGFBQUosTUFBdUIsQ0FBNUIsRUFBK0I7QUFDM0JyQiw2QkFBaUI7QUFDcEI7O0FBRUQsY0FBSzFOLEdBQUcsQ0FBQ2dQLGFBQUosTUFBdUIsQ0FBeEIsSUFBK0JoUCxHQUFHLENBQUMrTyxhQUFKLE1BQXVCLENBQTFELEVBQTZEO0FBQ3pEcEIsMkJBQWU7QUFDbEI7O0FBRUQsY0FBSzNOLEdBQUcsQ0FBQ2lQLFdBQUosTUFBcUIsQ0FBdEIsSUFBNkJqUCxHQUFHLENBQUNnUCxhQUFKLE1BQXVCLENBQXBELElBQTJEaFAsR0FBRyxDQUFDK08sYUFBSixNQUF1QixDQUF0RixFQUF5RjtBQUNyRm5CLDBCQUFjO0FBQ2pCO0FBQ0osU0FiZ0IsRUFhZCxJQWJjLENBQWpCO0FBY0g7QUFDSjtBQUNKLEdBdEREO0FBd0RILENBMUVELEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcvaW1wb3J0cy9hcGkvdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcbmNvbnN0IGZldGNoRnJvbVVybCA9ICh1cmwpID0+IHtcbiAgICB0cnl7XG4gICAgICAgIGxldCByZXMgPSBIVFRQLmdldChMQ0QgKyB1cmwpO1xuICAgICAgICBpZiAocmVzLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgIHJldHVybiByZXNcbiAgICAgICAgfTtcbiAgICB9XG4gICAgY2F0Y2ggKGUpe1xuICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICB9XG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnYWNjb3VudHMuZ2V0QWNjb3VudERldGFpbCc6IGZ1bmN0aW9uKGFkZHJlc3Mpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHVybCA9IExDRCArICcvYXV0aC9hY2NvdW50cy8nKyBhZGRyZXNzO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgYXZhaWxhYmxlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmIChhdmFpbGFibGUuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEpTT04ucGFyc2UoYXZhaWxhYmxlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICBsZXQgYWNjb3VudDtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UudHlwZSA9PT0gJ2Nvc21vcy1zZGsvQWNjb3VudCcpXG4gICAgICAgICAgICAgICAgICAgIGFjY291bnQgPSByZXNwb25zZS52YWx1ZTtcbiAgICAgICAgICAgICAgICBlbHNlIGlmIChyZXNwb25zZS50eXBlID09PSAnY29zbW9zLXNkay9EZWxheWVkVmVzdGluZ0FjY291bnQnIHx8IHJlc3BvbnNlLnR5cGUgPT09ICdjb3Ntb3Mtc2RrL0NvbnRpbnVvdXNWZXN0aW5nQWNjb3VudCcpXG4gICAgICAgICAgICAgICAgICAgIGFjY291bnQgPSByZXNwb25zZS52YWx1ZS5CYXNlVmVzdGluZ0FjY291bnQuQmFzZUFjY291bnRcbiAgICAgICAgICAgICAgICBpZiAoYWNjb3VudCAmJiBhY2NvdW50LmFjY291bnRfbnVtYmVyICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBhY2NvdW50XG4gICAgICAgICAgICAgICAgcmV0dXJuIG51bGxcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKVxuICAgICAgICB9XG4gICAgfSxcbiAgICAnYWNjb3VudHMuZ2V0QmFsYW5jZSc6IGZ1bmN0aW9uKGFkZHJlc3Mpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IGJhbGFuY2UgPSB7fVxuXG4gICAgICAgIC8vIGdldCBhdmFpbGFibGUgYXRvbXNcbiAgICAgICAgbGV0IHVybCA9IExDRCArICcvYmFuay9iYWxhbmNlcy8nKyBhZGRyZXNzO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgYXZhaWxhYmxlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmIChhdmFpbGFibGUuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKEpTT04ucGFyc2UoYXZhaWxhYmxlLmNvbnRlbnQpKVxuICAgICAgICAgICAgICAgIGJhbGFuY2UuYXZhaWxhYmxlID0gSlNPTi5wYXJzZShhdmFpbGFibGUuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgIGlmIChiYWxhbmNlLmF2YWlsYWJsZSAmJiBiYWxhbmNlLmF2YWlsYWJsZS5sZW5ndGggPiAwKVxuICAgICAgICAgICAgICAgICAgICBiYWxhbmNlLmF2YWlsYWJsZSA9IGJhbGFuY2UuYXZhaWxhYmxlWzBdO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgIH1cblxuICAgICAgICAvLyBnZXQgZGVsZWdhdGVkIGFtbm91bnRzXG4gICAgICAgIHVybCA9IExDRCArICcvc3Rha2luZy9kZWxlZ2F0b3JzLycrYWRkcmVzcysnL2RlbGVnYXRpb25zJztcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IGRlbGVnYXRpb25zID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmIChkZWxlZ2F0aW9ucy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgYmFsYW5jZS5kZWxlZ2F0aW9ucyA9IEpTT04ucGFyc2UoZGVsZWdhdGlvbnMuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG4gICAgICAgIC8vIGdldCB1bmJvbmRpbmdcbiAgICAgICAgdXJsID0gTENEICsgJy9zdGFraW5nL2RlbGVnYXRvcnMvJythZGRyZXNzKycvdW5ib25kaW5nX2RlbGVnYXRpb25zJztcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IHVuYm9uZGluZyA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBpZiAodW5ib25kaW5nLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICBiYWxhbmNlLnVuYm9uZGluZyA9IEpTT04ucGFyc2UodW5ib25kaW5nLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGdldCByZXdhcmRzXG4gICAgICAgIHVybCA9IExDRCArICcvZGlzdHJpYnV0aW9uL2RlbGVnYXRvcnMvJythZGRyZXNzKycvcmV3YXJkcyc7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCByZXdhcmRzID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmIChyZXdhcmRzLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICBiYWxhbmNlLnJld2FyZHMgPSBKU09OLnBhcnNlKHJld2FyZHMuY29udGVudCkucmVzdWx0LnRvdGFsO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gZ2V0IGNvbW1pc3Npb25cbiAgICAgICAgbGV0IHZhbGlkYXRvciA9IFZhbGlkYXRvcnMuZmluZE9uZShcbiAgICAgICAgICAgIHskb3I6IFt7b3BlcmF0b3JfYWRkcmVzczphZGRyZXNzfSwge2RlbGVnYXRvcl9hZGRyZXNzOmFkZHJlc3N9LCB7YWRkcmVzczphZGRyZXNzfV19KVxuICAgICAgICBpZiAodmFsaWRhdG9yKSB7XG4gICAgICAgICAgICBsZXQgdXJsID0gTENEICsgJy9kaXN0cmlidXRpb24vdmFsaWRhdG9ycy8nICsgdmFsaWRhdG9yLm9wZXJhdG9yX2FkZHJlc3M7XG4gICAgICAgICAgICBiYWxhbmNlLm9wZXJhdG9yX2FkZHJlc3MgPSB2YWxpZGF0b3Iub3BlcmF0b3JfYWRkcmVzcztcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgbGV0IHJld2FyZHMgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgIGlmIChyZXdhcmRzLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGNvbnRlbnQgPSBKU09OLnBhcnNlKHJld2FyZHMuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICBpZiAoY29udGVudC52YWxfY29tbWlzc2lvbiAmJiBjb250ZW50LnZhbF9jb21taXNzaW9uLmxlbmd0aCA+IDApXG4gICAgICAgICAgICAgICAgICAgICAgICBiYWxhbmNlLmNvbW1pc3Npb24gPSBjb250ZW50LnZhbF9jb21taXNzaW9uWzBdO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gYmFsYW5jZTtcbiAgICB9LFxuICAgICdhY2NvdW50cy5nZXREZWxlZ2F0aW9uJyhhZGRyZXNzLCB2YWxpZGF0b3Ipe1xuICAgICAgICBsZXQgdXJsID0gYC9zdGFraW5nL2RlbGVnYXRvcnMvJHthZGRyZXNzfS9kZWxlZ2F0aW9ucy8ke3ZhbGlkYXRvcn1gO1xuICAgICAgICBsZXQgZGVsZWdhdGlvbnMgPSBmZXRjaEZyb21VcmwodXJsKTtcbiAgICAgICAgZGVsZWdhdGlvbnMgPSBkZWxlZ2F0aW9ucyAmJiBkZWxlZ2F0aW9ucy5kYXRhLnJlc3VsdDtcbiAgICAgICAgaWYgKGRlbGVnYXRpb25zICYmIGRlbGVnYXRpb25zLnNoYXJlcylcbiAgICAgICAgICAgIGRlbGVnYXRpb25zLnNoYXJlcyA9IHBhcnNlRmxvYXQoZGVsZWdhdGlvbnMuc2hhcmVzKTtcblxuICAgICAgICB1cmwgPSBgL3N0YWtpbmcvcmVkZWxlZ2F0aW9ucz9kZWxlZ2F0b3I9JHthZGRyZXNzfSZ2YWxpZGF0b3JfdG89JHt2YWxpZGF0b3J9YDtcbiAgICAgICAgbGV0IHJlbGVnYXRpb25zID0gZmV0Y2hGcm9tVXJsKHVybCk7XG4gICAgICAgIHJlbGVnYXRpb25zID0gcmVsZWdhdGlvbnMgJiYgcmVsZWdhdGlvbnMuZGF0YS5yZXN1bHQ7XG4gICAgICAgIGxldCBjb21wbGV0aW9uVGltZTtcbiAgICAgICAgaWYgKHJlbGVnYXRpb25zKSB7XG4gICAgICAgICAgICByZWxlZ2F0aW9ucy5mb3JFYWNoKChyZWxlZ2F0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgbGV0IGVudHJpZXMgPSByZWxlZ2F0aW9uLmVudHJpZXNcbiAgICAgICAgICAgICAgICBsZXQgdGltZSA9IG5ldyBEYXRlKGVudHJpZXNbZW50cmllcy5sZW5ndGgtMV0uY29tcGxldGlvbl90aW1lKVxuICAgICAgICAgICAgICAgIGlmICghY29tcGxldGlvblRpbWUgfHwgdGltZSA+IGNvbXBsZXRpb25UaW1lKVxuICAgICAgICAgICAgICAgICAgICBjb21wbGV0aW9uVGltZSA9IHRpbWVcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICBkZWxlZ2F0aW9ucy5yZWRlbGVnYXRpb25Db21wbGV0aW9uVGltZSA9IGNvbXBsZXRpb25UaW1lO1xuICAgICAgICB9XG5cbiAgICAgICAgdXJsID0gYC9zdGFraW5nL2RlbGVnYXRvcnMvJHthZGRyZXNzfS91bmJvbmRpbmdfZGVsZWdhdGlvbnMvJHt2YWxpZGF0b3J9YDtcbiAgICAgICAgbGV0IHVuZGVsZWdhdGlvbnMgPSBmZXRjaEZyb21VcmwodXJsKTtcbiAgICAgICAgdW5kZWxlZ2F0aW9ucyA9IHVuZGVsZWdhdGlvbnMgJiYgdW5kZWxlZ2F0aW9ucy5kYXRhLnJlc3VsdDtcbiAgICAgICAgaWYgKHVuZGVsZWdhdGlvbnMpIHtcbiAgICAgICAgICAgIGRlbGVnYXRpb25zLnVuYm9uZGluZyA9IHVuZGVsZWdhdGlvbnMuZW50cmllcy5sZW5ndGg7XG4gICAgICAgICAgICBkZWxlZ2F0aW9ucy51bmJvbmRpbmdDb21wbGV0aW9uVGltZSA9IHVuZGVsZWdhdGlvbnMuZW50cmllc1swXS5jb21wbGV0aW9uX3RpbWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGRlbGVnYXRpb25zO1xuICAgIH0sXG4gICAgJ2FjY291bnRzLmdldEFsbERlbGVnYXRpb25zJyhhZGRyZXNzKXtcbiAgICAgICAgbGV0IHVybCA9IExDRCArICcvc3Rha2luZy9kZWxlZ2F0b3JzLycrYWRkcmVzcysnL2RlbGVnYXRpb25zJztcblxuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgZGVsZWdhdGlvbnMgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICBkZWxlZ2F0aW9ucyA9IEpTT04ucGFyc2UoZGVsZWdhdGlvbnMuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgIGlmIChkZWxlZ2F0aW9ucyAmJiBkZWxlZ2F0aW9ucy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgZGVsZWdhdGlvbnMuZm9yRWFjaCgoZGVsZWdhdGlvbiwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zW2ldICYmIGRlbGVnYXRpb25zW2ldLnNoYXJlcylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxlZ2F0aW9uc1tpXS5zaGFyZXMgPSBwYXJzZUZsb2F0KGRlbGVnYXRpb25zW2ldLnNoYXJlcyk7XG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgcmV0dXJuIGRlbGVnYXRpb25zO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ2FjY291bnRzLmdldEFsbFVuYm9uZGluZ3MnKGFkZHJlc3Mpe1xuICAgICAgICBsZXQgdXJsID0gTENEICsgJy9zdGFraW5nL2RlbGVnYXRvcnMvJythZGRyZXNzKycvdW5ib25kaW5nX2RlbGVnYXRpb25zJztcblxuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgdW5ib25kaW5ncyA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBpZiAodW5ib25kaW5ncy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgdW5ib25kaW5ncyA9IEpTT04ucGFyc2UodW5ib25kaW5ncy5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHVuYm9uZGluZ3M7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAnYWNjb3VudHMuZ2V0QWxsUmVkZWxlZ2F0aW9ucycoYWRkcmVzcywgdmFsaWRhdG9yKXtcbiAgICAgICAgbGV0IHVybCA9IGAvc3Rha2luZy9yZWRlbGVnYXRpb25zP2RlbGVnYXRvcj0ke2FkZHJlc3N9JnZhbGlkYXRvcl9mcm9tPSR7dmFsaWRhdG9yfWA7XG4gICAgICAgIGxldCByZXN1bHQgPSBmZXRjaEZyb21VcmwodXJsKTtcbiAgICAgICAgaWYgKHJlc3VsdCAmJiByZXN1bHQuZGF0YSkge1xuICAgICAgICAgICAgbGV0IHJlZGVsZWdhdGlvbnMgPSB7fVxuICAgICAgICAgICAgcmVzdWx0LmRhdGEuZm9yRWFjaCgocmVkZWxlZ2F0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgbGV0IGVudHJpZXMgPSByZWRlbGVnYXRpb24uZW50cmllcztcbiAgICAgICAgICAgICAgICByZWRlbGVnYXRpb25zW3JlZGVsZWdhdGlvbi52YWxpZGF0b3JfZHN0X2FkZHJlc3NdID0ge1xuICAgICAgICAgICAgICAgICAgICBjb3VudDogZW50cmllcy5sZW5ndGgsXG4gICAgICAgICAgICAgICAgICAgIGNvbXBsZXRpb25UaW1lOiBlbnRyaWVzWzBdLmNvbXBsZXRpb25fdGltZVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICByZXR1cm4gcmVkZWxlZ2F0aW9uc1xuICAgICAgICB9XG4gICAgfVxufSkiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5pbXBvcnQgeyBQcm9taXNlIH0gZnJvbSBcIm1ldGVvci9wcm9taXNlXCI7XG5pbXBvcnQgeyBCbG9ja3Njb24gfSBmcm9tICcvaW1wb3J0cy9hcGkvYmxvY2tzL2Jsb2Nrcy5qcyc7XG5pbXBvcnQgeyBDaGFpbiB9IGZyb20gJy9pbXBvcnRzL2FwaS9jaGFpbi9jaGFpbi5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JTZXRzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL3ZhbGlkYXRvci1zZXRzL3ZhbGlkYXRvci1zZXRzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcvaW1wb3J0cy9hcGkvdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMsIEFuYWx5dGljcywgVlBEaXN0cmlidXRpb25zfSBmcm9tICcvaW1wb3J0cy9hcGkvcmVjb3Jkcy9yZWNvcmRzLmpzJztcbmltcG9ydCB7IFZvdGluZ1Bvd2VySGlzdG9yeSB9IGZyb20gJy9pbXBvcnRzL2FwaS92b3RpbmctcG93ZXIvaGlzdG9yeS5qcyc7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi8uLi90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzJztcbmltcG9ydCB7IEV2aWRlbmNlcyB9IGZyb20gJy4uLy4uL2V2aWRlbmNlcy9ldmlkZW5jZXMuanMnO1xuaW1wb3J0IHsgc2hhMjU2IH0gZnJvbSAnanMtc2hhMjU2JztcbmltcG9ydCB7IGdldEFkZHJlc3MgfSBmcm9tICd0ZW5kZXJtaW50L2xpYi9wdWJrZXknO1xuaW1wb3J0ICogYXMgY2hlZXJpbyBmcm9tICdjaGVlcmlvJztcblxuLy8gaW1wb3J0IEJsb2NrIGZyb20gJy4uLy4uLy4uL3VpL2NvbXBvbmVudHMvQmxvY2snO1xuXG4vLyBnZXRWYWxpZGF0b3JWb3RpbmdQb3dlciA9ICh2YWxpZGF0b3JzLCBhZGRyZXNzKSA9PiB7XG4vLyAgICAgZm9yICh2IGluIHZhbGlkYXRvcnMpe1xuLy8gICAgICAgICBpZiAodmFsaWRhdG9yc1t2XS5hZGRyZXNzID09IGFkZHJlc3Mpe1xuLy8gICAgICAgICAgICAgcmV0dXJuIHBhcnNlSW50KHZhbGlkYXRvcnNbdl0udm90aW5nX3Bvd2VyKTtcbi8vICAgICAgICAgfVxuLy8gICAgIH1cbi8vIH1cblxuZ2V0UmVtb3ZlZFZhbGlkYXRvcnMgPSAocHJldlZhbGlkYXRvcnMsIHZhbGlkYXRvcnMpID0+IHtcbiAgICAvLyBsZXQgcmVtb3ZlVmFsaWRhdG9ycyA9IFtdO1xuICAgIGZvciAocCBpbiBwcmV2VmFsaWRhdG9ycyl7XG4gICAgICAgIGZvciAodiBpbiB2YWxpZGF0b3JzKXtcbiAgICAgICAgICAgIGlmIChwcmV2VmFsaWRhdG9yc1twXS5hZGRyZXNzID09IHZhbGlkYXRvcnNbdl0uYWRkcmVzcyl7XG4gICAgICAgICAgICAgICAgcHJldlZhbGlkYXRvcnMuc3BsaWNlKHAsMSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gcHJldlZhbGlkYXRvcnM7XG59XG5cbmdldFZhbGlkYXRvclByb2ZpbGVVcmwgPSAoaWRlbnRpdHkpID0+IHtcbiAgICBpZiAoaWRlbnRpdHkubGVuZ3RoID09IDE2KXtcbiAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQoYGh0dHBzOi8va2V5YmFzZS5pby9fL2FwaS8xLjAvdXNlci9sb29rdXAuanNvbj9rZXlfc3VmZml4PSR7aWRlbnRpdHl9JmZpZWxkcz1waWN0dXJlc2ApXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCkge1xuICAgICAgICAgICAgbGV0IHRoZW0gPSByZXNwb25zZS5kYXRhLnRoZW1cbiAgICAgICAgICAgIHJldHVybiB0aGVtICYmIHRoZW0ubGVuZ3RoICYmIHRoZW1bMF0ucGljdHVyZXMgJiYgdGhlbVswXS5waWN0dXJlcy5wcmltYXJ5ICYmIHRoZW1bMF0ucGljdHVyZXMucHJpbWFyeS51cmw7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeShyZXNwb25zZSkpXG4gICAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGlkZW50aXR5LmluZGV4T2YoXCJrZXliYXNlLmlvL3RlYW0vXCIpPjApe1xuICAgICAgICBsZXQgdGVhbVBhZ2UgPSBIVFRQLmdldChpZGVudGl0eSk7XG4gICAgICAgIGlmICh0ZWFtUGFnZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICBsZXQgcGFnZSA9IGNoZWVyaW8ubG9hZCh0ZWFtUGFnZS5jb250ZW50KTtcbiAgICAgICAgICAgIHJldHVybiBwYWdlKFwiLmtiLW1haW4tY2FyZCBpbWdcIikuYXR0cignc3JjJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeSh0ZWFtUGFnZSkpXG4gICAgICAgIH1cbiAgICB9XG59XG5cbi8vIHZhciBmaWx0ZXJlZCA9IFsxLCAyLCAzLCA0LCA1XS5maWx0ZXIobm90Q29udGFpbmVkSW4oWzEsIDIsIDMsIDVdKSk7XG4vLyBjb25zb2xlLmxvZyhmaWx0ZXJlZCk7IC8vIFs0XVxuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ2Jsb2Nrcy5hdmVyYWdlQmxvY2tUaW1lJyhhZGRyZXNzKXtcbiAgICAgICAgbGV0IGJsb2NrcyA9IEJsb2Nrc2Nvbi5maW5kKHtwcm9wb3NlckFkZHJlc3M6YWRkcmVzc30pLmZldGNoKCk7XG4gICAgICAgIGxldCBoZWlnaHRzID0gYmxvY2tzLm1hcCgoYmxvY2ssIGkpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBibG9jay5oZWlnaHQ7XG4gICAgICAgIH0pO1xuICAgICAgICBsZXQgYmxvY2tzU3RhdHMgPSBBbmFseXRpY3MuZmluZCh7aGVpZ2h0OnskaW46aGVpZ2h0c319KS5mZXRjaCgpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhibG9ja3NTdGF0cyk7XG5cbiAgICAgICAgbGV0IHRvdGFsQmxvY2tEaWZmID0gMDtcbiAgICAgICAgZm9yIChiIGluIGJsb2Nrc1N0YXRzKXtcbiAgICAgICAgICAgIHRvdGFsQmxvY2tEaWZmICs9IGJsb2Nrc1N0YXRzW2JdLnRpbWVEaWZmO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0b3RhbEJsb2NrRGlmZi9oZWlnaHRzLmxlbmd0aDtcbiAgICB9LFxuICAgICdibG9ja3MuZmluZFVwVGltZScoYWRkcmVzcyl7XG4gICAgICAgIGxldCBjb2xsZWN0aW9uID0gVmFsaWRhdG9yUmVjb3Jkcy5yYXdDb2xsZWN0aW9uKCk7XG4gICAgICAgIC8vIGxldCBhZ2dyZWdhdGVRdWVyeSA9IE1ldGVvci53cmFwQXN5bmMoY29sbGVjdGlvbi5hZ2dyZWdhdGUsIGNvbGxlY3Rpb24pO1xuICAgICAgICB2YXIgcGlwZWxpbmUgPSBbXG4gICAgICAgICAgICB7JG1hdGNoOntcImFkZHJlc3NcIjphZGRyZXNzfX0sXG4gICAgICAgICAgICAvLyB7JHByb2plY3Q6e2FkZHJlc3M6MSxoZWlnaHQ6MSxleGlzdHM6MX19LFxuICAgICAgICAgICAgeyRzb3J0OntcImhlaWdodFwiOi0xfX0sXG4gICAgICAgICAgICB7JGxpbWl0OihNZXRlb3Iuc2V0dGluZ3MucHVibGljLnVwdGltZVdpbmRvdy0xKX0sXG4gICAgICAgICAgICB7JHVud2luZDogXCIkX2lkXCJ9LFxuICAgICAgICAgICAgeyRncm91cDp7XG4gICAgICAgICAgICAgICAgXCJfaWRcIjogXCIkYWRkcmVzc1wiLFxuICAgICAgICAgICAgICAgIFwidXB0aW1lXCI6IHtcbiAgICAgICAgICAgICAgICAgICAgXCIkc3VtXCI6e1xuICAgICAgICAgICAgICAgICAgICAgICAgJGNvbmQ6IFt7JGVxOiBbJyRleGlzdHMnLCB0cnVlXX0sIDEsIDBdXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB9XTtcbiAgICAgICAgLy8gbGV0IHJlc3VsdCA9IGFnZ3JlZ2F0ZVF1ZXJ5KHBpcGVsaW5lLCB7IGN1cnNvcjoge30gfSk7XG5cbiAgICAgICAgcmV0dXJuIFByb21pc2UuYXdhaXQoY29sbGVjdGlvbi5hZ2dyZWdhdGUocGlwZWxpbmUpLnRvQXJyYXkoKSk7XG4gICAgICAgIC8vIHJldHVybiAuYWdncmVnYXRlKClcbiAgICB9LFxuICAgICdibG9ja3MuZ2V0TGF0ZXN0SGVpZ2h0JzogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgdXJsID0gUlBDKycvc3RhdHVzJztcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGxldCBzdGF0dXMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgcmV0dXJuIChzdGF0dXMucmVzdWx0LnN5bmNfaW5mby5sYXRlc3RfYmxvY2tfaGVpZ2h0KTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ2Jsb2Nrcy5nZXRDdXJyZW50SGVpZ2h0JzogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgY3VyckhlaWdodCA9IEJsb2Nrc2Nvbi5maW5kKHt9LHtzb3J0OntoZWlnaHQ6LTF9LGxpbWl0OjF9KS5mZXRjaCgpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhcImN1cnJlbnRIZWlnaHQ6XCIrY3VyckhlaWdodCk7XG4gICAgICAgIGxldCBzdGFydEhlaWdodCA9IE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuc3RhcnRIZWlnaHQ7XG4gICAgICAgIGlmIChjdXJySGVpZ2h0ICYmIGN1cnJIZWlnaHQubGVuZ3RoID09IDEpIHtcbiAgICAgICAgICAgIGxldCBoZWlnaHQgPSBjdXJySGVpZ2h0WzBdLmhlaWdodDtcbiAgICAgICAgICAgIGlmIChoZWlnaHQgPiBzdGFydEhlaWdodClcbiAgICAgICAgICAgICAgICByZXR1cm4gaGVpZ2h0XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN0YXJ0SGVpZ2h0XG4gICAgfSxcbiAgICAnYmxvY2tzLmJsb2Nrc1VwZGF0ZSc6IGZ1bmN0aW9uKCkge1xuICAgICAgICBpZiAoU1lOQ0lORylcbiAgICAgICAgICAgIHJldHVybiBcIlN5bmNpbmcuLi5cIjtcbiAgICAgICAgZWxzZSBjb25zb2xlLmxvZyhcInN0YXJ0IHRvIHN5bmNcIik7XG4gICAgICAgIC8vIE1ldGVvci5jbGVhckludGVydmFsKE1ldGVvci50aW1lckhhbmRsZSk7XG4gICAgICAgIC8vIGdldCB0aGUgbGF0ZXN0IGhlaWdodFxuICAgICAgICBsZXQgdW50aWwgPSBNZXRlb3IuY2FsbCgnYmxvY2tzLmdldExhdGVzdEhlaWdodCcpO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyh1bnRpbCk7XG4gICAgICAgIC8vIGdldCB0aGUgY3VycmVudCBoZWlnaHQgaW4gZGJcbiAgICAgICAgbGV0IGN1cnIgPSBNZXRlb3IuY2FsbCgnYmxvY2tzLmdldEN1cnJlbnRIZWlnaHQnKTtcbiAgICAgICAgY29uc29sZS5sb2coY3Vycik7XG4gICAgICAgIC8vIGxvb3AgaWYgdGhlcmUncyB1cGRhdGUgaW4gZGJcbiAgICAgICAgaWYgKHVudGlsID4gY3Vycikge1xuICAgICAgICAgICAgU1lOQ0lORyA9IHRydWU7XG5cbiAgICAgICAgICAgIGxldCB2YWxpZGF0b3JTZXQgPSB7fVxuICAgICAgICAgICAgLy8gZ2V0IGxhdGVzdCB2YWxpZGF0b3IgY2FuZGlkYXRlIGluZm9ybWF0aW9uXG4gICAgICAgICAgICB1cmwgPSBMQ0QrJy9zdGFraW5nL3ZhbGlkYXRvcnMnO1xuXG4gICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgIEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0LmZvckVhY2goKHZhbGlkYXRvcikgPT4gdmFsaWRhdG9yU2V0W3ZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5XSA9IHZhbGlkYXRvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdXJsID0gTENEKycvc3Rha2luZy92YWxpZGF0b3JzP3N0YXR1cz11bmJvbmRpbmcnO1xuXG4gICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgIEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0LmZvckVhY2goKHZhbGlkYXRvcikgPT4gdmFsaWRhdG9yU2V0W3ZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5XSA9IHZhbGlkYXRvcilcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB1cmwgPSBMQ0QrJy9zdGFraW5nL3ZhbGlkYXRvcnM/c3RhdHVzPXVuYm9uZGVkJztcblxuICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdC5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHZhbGlkYXRvclNldFt2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleV0gPSB2YWxpZGF0b3IpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxldCB0b3RhbFZhbGlkYXRvcnMgPSBPYmplY3Qua2V5cyh2YWxpZGF0b3JTZXQpLmxlbmd0aDtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWxsIHZhbGlkYXRvcnM6IFwiKyB0b3RhbFZhbGlkYXRvcnMpO1xuICAgICAgICAgICAgZm9yIChsZXQgaGVpZ2h0ID0gY3VycisxIDsgaGVpZ2h0IDw9IHVudGlsIDsgaGVpZ2h0KyspIHtcbiAgICAgICAgICAgICAgICBsZXQgc3RhcnRCbG9ja1RpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgIC8vIGFkZCB0aW1lb3V0IGhlcmU/IGFuZCBvdXRzaWRlIHRoaXMgbG9vcCAoZm9yIGNhdGNoZWQgdXAgYW5kIGtlZXAgZmV0Y2hpbmcpP1xuICAgICAgICAgICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICAgICAgICAgIGxldCB1cmwgPSBSUEMrJy9ibG9jaz9oZWlnaHQ9JyArIGhlaWdodDtcbiAgICAgICAgICAgICAgICBsZXQgYW5hbHl0aWNzRGF0YSA9IHt9O1xuXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2codXJsKTtcbiAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtWYWxpZGF0b3JzID0gVmFsaWRhdG9ycy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBidWxrVmFsaWRhdG9yUmVjb3JkcyA9IFZhbGlkYXRvclJlY29yZHMucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AoKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYnVsa1ZQSGlzdG9yeSA9IFZvdGluZ1Bvd2VySGlzdG9yeS5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBidWxrVHJhbnNhdGlvbnMgPSBUcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AoKTtcblxuICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRHZXRIZWlnaHRUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBibG9jayA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9jayA9IGJsb2NrLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHN0b3JlIGhlaWdodCwgaGFzaCwgbnVtdHJhbnNhY3Rpb24gYW5kIHRpbWUgaW4gZGJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBibG9ja0RhdGEgPSB7fTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS5oZWlnaHQgPSBoZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEuaGFzaCA9IGJsb2NrLmJsb2NrX2lkLmhhc2g7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEudHJhbnNOdW0gPSBibG9jay5ibG9jay5kYXRhLmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS50aW1lID0gbmV3IERhdGUoYmxvY2suYmxvY2suaGVhZGVyLnRpbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLmxhc3RCbG9ja0hhc2ggPSBibG9jay5ibG9jay5oZWFkZXIubGFzdF9ibG9ja19pZC5oYXNoO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLnByb3Bvc2VyQWRkcmVzcyA9IGJsb2NrLmJsb2NrLmhlYWRlci5wcm9wb3Nlcl9hZGRyZXNzO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLnZhbGlkYXRvcnMgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwcmVjb21taXRzID0gYmxvY2suYmxvY2subGFzdF9jb21taXQucHJlY29tbWl0cztcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmVjb21taXRzICE9IG51bGwpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHByZWNvbW1pdHMubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpPTA7IGk8cHJlY29tbWl0cy5sZW5ndGg7IGkrKyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmVjb21taXRzW2ldICE9IG51bGwpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLnZhbGlkYXRvcnMucHVzaChwcmVjb21taXRzW2ldLnZhbGlkYXRvcl9hZGRyZXNzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFuYWx5dGljc0RhdGEucHJlY29tbWl0cyA9IHByZWNvbW1pdHMubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHJlY29yZCBmb3IgYW5hbHl0aWNzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUHJlY29tbWl0UmVjb3Jkcy5pbnNlcnQoe2hlaWdodDpoZWlnaHQsIHByZWNvbW1pdHM6cHJlY29tbWl0cy5sZW5ndGh9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gc2F2ZSB0eHMgaW4gZGF0YWJhc2VcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChibG9jay5ibG9jay5kYXRhLnR4cyAmJiBibG9jay5ibG9jay5kYXRhLnR4cy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHQgaW4gYmxvY2suYmxvY2suZGF0YS50eHMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBNZXRlb3IuY2FsbCgnVHJhbnNhY3Rpb25zLmluZGV4Jywgc2hhMjU2KEJ1ZmZlci5mcm9tKGJsb2NrLmJsb2NrLmRhdGEudHhzW3RdLCAnYmFzZTY0JykpLCBibG9ja0RhdGEudGltZSwgKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHNhdmUgZG91YmxlIHNpZ24gZXZpZGVuY2VzXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYmxvY2suYmxvY2suZXZpZGVuY2UuZXZpZGVuY2Upe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEV2aWRlbmNlcy5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXZpZGVuY2U6IGJsb2NrLmJsb2NrLmV2aWRlbmNlLmV2aWRlbmNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS5wcmVjb21taXRzQ291bnQgPSBibG9ja0RhdGEudmFsaWRhdG9ycy5sZW5ndGg7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGFuYWx5dGljc0RhdGEuaGVpZ2h0ID0gaGVpZ2h0O1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZW5kR2V0SGVpZ2h0VGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkdldCBoZWlnaHQgdGltZTogXCIrKChlbmRHZXRIZWlnaHRUaW1lLXN0YXJ0R2V0SGVpZ2h0VGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcblxuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRHZXRWYWxpZGF0b3JzVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB1cGRhdGUgY2hhaW4gc3RhdHVzXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmwgPSBSUEMrJy92YWxpZGF0b3JzP2hlaWdodD0nK2hlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9ycyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JzLnJlc3VsdC5ibG9ja19oZWlnaHQgPSBwYXJzZUludCh2YWxpZGF0b3JzLnJlc3VsdC5ibG9ja19oZWlnaHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgVmFsaWRhdG9yU2V0cy5pbnNlcnQodmFsaWRhdG9ycy5yZXN1bHQpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEudmFsaWRhdG9yc0NvdW50ID0gdmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9ycy5sZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRCbG9ja0luc2VydFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgQmxvY2tzY29uLmluc2VydChibG9ja0RhdGEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGVuZEJsb2NrSW5zZXJ0VGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkJsb2NrIGluc2VydCB0aW1lOiBcIisoKGVuZEJsb2NrSW5zZXJ0VGltZS1zdGFydEJsb2NrSW5zZXJ0VGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gc3RvcmUgdmFsZGlhdG9ycyBleGlzdCByZWNvcmRzXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZXhpc3RpbmdWYWxpZGF0b3JzID0gVmFsaWRhdG9ycy5maW5kKHthZGRyZXNzOnskZXhpc3RzOnRydWV9fSkuZmV0Y2goKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGhlaWdodCA+IDEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHJlY29yZCBwcmVjb21taXRzIGFuZCBjYWxjdWxhdGUgdXB0aW1lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gb25seSByZWNvcmQgZnJvbSBibG9jayAyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChpIGluIHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgYWRkcmVzcyA9IHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnNbaV0uYWRkcmVzcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlY29yZCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0czogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IHBhcnNlSW50KHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnNbaV0udm90aW5nX3Bvd2VyKS8vZ2V0VmFsaWRhdG9yVm90aW5nUG93ZXIoZXhpc3RpbmdWYWxpZGF0b3JzLCBhZGRyZXNzKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChqIGluIHByZWNvbW1pdHMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByZWNvbW1pdHNbal0gIT0gbnVsbCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGFkZHJlc3MgPT0gcHJlY29tbWl0c1tqXS52YWxpZGF0b3JfYWRkcmVzcyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlY29yZC5leGlzdHMgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmVjb21taXRzLnNwbGljZShqLDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjYWxjdWxhdGUgdGhlIHVwdGltZSBiYXNlZCBvbiB0aGUgcmVjb3JkcyBzdG9yZWQgaW4gcHJldmlvdXMgYmxvY2tzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIG9ubHkgZG8gdGhpcyBldmVyeSAxNSBibG9ja3MgflxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICgoaGVpZ2h0ICUgMTUpID09IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGV0IHN0YXJ0QWdnVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgbnVtQmxvY2tzID0gTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5maW5kVXBUaW1lJywgYWRkcmVzcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdXB0aW1lID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGxldCBlbmRBZ2dUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwiR2V0IGFnZ3JlZ2F0ZWQgdXB0aW1lIGZvciBcIitleGlzdGluZ1ZhbGlkYXRvcnNbaV0uYWRkcmVzcytcIjogXCIrKChlbmRBZ2dUaW1lLXN0YXJ0QWdnVGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICgobnVtQmxvY2tzWzBdICE9IG51bGwpICYmIChudW1CbG9ja3NbMF0udXB0aW1lICE9IG51bGwpKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cHRpbWUgPSBudW1CbG9ja3NbMF0udXB0aW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgYmFzZSA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMudXB0aW1lV2luZG93O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGhlaWdodCA8IGJhc2Upe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhc2UgPSBoZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZWNvcmQuZXhpc3RzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodXB0aW1lIDwgYmFzZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwdGltZSsrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cHRpbWUgPSAodXB0aW1lIC8gYmFzZSkqMTAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JzLmZpbmQoe2FkZHJlc3M6YWRkcmVzc30pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDp7dXB0aW1lOnVwdGltZSwgbGFzdFNlZW46YmxvY2tEYXRhLnRpbWV9fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNle1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwdGltZSA9ICh1cHRpbWUgLyBiYXNlKSoxMDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7YWRkcmVzczphZGRyZXNzfSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0Ont1cHRpbWU6dXB0aW1lfX0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvclJlY29yZHMuaW5zZXJ0KHJlY29yZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFZhbGlkYXRvclJlY29yZHMudXBkYXRlKHtoZWlnaHQ6aGVpZ2h0LGFkZHJlc3M6cmVjb3JkLmFkZHJlc3N9LHJlY29yZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY2hhaW5TdGF0dXMgPSBDaGFpbi5maW5kT25lKHtjaGFpbklkOmJsb2NrLmJsb2NrLmhlYWRlci5jaGFpbl9pZH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGxhc3RTeW5jZWRUaW1lID0gY2hhaW5TdGF0dXM/Y2hhaW5TdGF0dXMubGFzdFN5bmNlZFRpbWU6MDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCB0aW1lRGlmZjtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBibG9ja1RpbWUgPSBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLmRlZmF1bHRCbG9ja1RpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobGFzdFN5bmNlZFRpbWUpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBkYXRlTGF0ZXN0ID0gYmxvY2tEYXRhLnRpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGVMYXN0ID0gbmV3IERhdGUobGFzdFN5bmNlZFRpbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpbWVEaWZmID0gTWF0aC5hYnMoZGF0ZUxhdGVzdC5nZXRUaW1lKCkgLSBkYXRlTGFzdC5nZXRUaW1lKCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrVGltZSA9IChjaGFpblN0YXR1cy5ibG9ja1RpbWUgKiAoYmxvY2tEYXRhLmhlaWdodCAtIDEpICsgdGltZURpZmYpIC8gYmxvY2tEYXRhLmhlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGVuZEdldFZhbGlkYXRvcnNUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiR2V0IGhlaWdodCB2YWxpZGF0b3JzIHRpbWU6IFwiKygoZW5kR2V0VmFsaWRhdG9yc1RpbWUtc3RhcnRHZXRWYWxpZGF0b3JzVGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOmJsb2NrLmJsb2NrLmhlYWRlci5jaGFpbl9pZH0sIHskc2V0OntsYXN0U3luY2VkVGltZTpibG9ja0RhdGEudGltZSwgYmxvY2tUaW1lOmJsb2NrVGltZX19KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS5hdmVyYWdlQmxvY2tUaW1lID0gYmxvY2tUaW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS50aW1lRGlmZiA9IHRpbWVEaWZmO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLnRpbWUgPSBibG9ja0RhdGEudGltZTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gaW5pdGlhbGl6ZSB2YWxpZGF0b3IgZGF0YSBhdCBmaXJzdCBibG9ja1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gaWYgKGhlaWdodCA9PSAxKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICBWYWxpZGF0b3JzLnJlbW92ZSh7fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGFuYWx5dGljc0RhdGEudm90aW5nX3Bvd2VyID0gMDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0RmluZFZhbGlkYXRvcnNOYW1lVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9ycy5yZXN1bHQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvcnMgYXJlIGFsbCB0aGUgdmFsaWRhdG9ycyBpbiB0aGUgY3VycmVudCBoZWlnaHRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInZhbGlkYXRvclNldCBzaXplOiBcIit2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzLmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2IGluIHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBWYWxpZGF0b3JzLmluc2VydCh2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzW3ZdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvciA9IHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnNbdl07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci52b3RpbmdfcG93ZXIgPSBwYXJzZUludCh2YWxpZGF0b3Iudm90aW5nX3Bvd2VyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnByb3Bvc2VyX3ByaW9yaXR5ID0gcGFyc2VJbnQodmFsaWRhdG9yLnByb3Bvc2VyX3ByaW9yaXR5KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsRXhpc3QgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe1wicHViX2tleS52YWx1ZVwiOnZhbGlkYXRvci5wdWJfa2V5LnZhbHVlfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdmFsRXhpc3Qpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coYHZhbGlkYXRvciBwdWJfa2V5ICR7dmFsaWRhdG9yLmFkZHJlc3N9ICR7dmFsaWRhdG9yLnB1Yl9rZXkudmFsdWV9IG5vdCBpbiBkYmApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGV0IGNvbW1hbmQgPSBNZXRlb3Iuc2V0dGluZ3MuYmluLmdhaWFkZWJ1ZytcIiBwdWJrZXkgXCIrdmFsaWRhdG9yLnB1Yl9rZXkudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhjb21tYW5kKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGxldCB0ZW1wVmFsID0gdmFsaWRhdG9yO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYWRkcmVzcyA9IGdldEFkZHJlc3ModmFsaWRhdG9yLnB1Yl9rZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFjY3B1YiA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbGlkYXRvci5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY1B1Yik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsUHViKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5ID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4Q29uc1B1Yik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3JEYXRhID0gdmFsaWRhdG9yU2V0W3ZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5XVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvckRhdGEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JEYXRhLmRlc2NyaXB0aW9uLmlkZW50aXR5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHJvZmlsZV91cmwgPSAgZ2V0VmFsaWRhdG9yUHJvZmlsZVVybCh2YWxpZGF0b3JEYXRhLmRlc2NyaXB0aW9uLmlkZW50aXR5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5vcGVyYXRvcl9hZGRyZXNzID0gdmFsaWRhdG9yRGF0YS5vcGVyYXRvcl9hZGRyZXNzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZWxlZ2F0b3JfYWRkcmVzcyA9IE1ldGVvci5jYWxsKCdnZXREZWxlZ2F0b3InLCB2YWxpZGF0b3JEYXRhLm9wZXJhdG9yX2FkZHJlc3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5qYWlsZWQgPSB2YWxpZGF0b3JEYXRhLmphaWxlZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iuc3RhdHVzID0gdmFsaWRhdG9yRGF0YS5zdGF0dXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLm1pbl9zZWxmX2RlbGVnYXRpb24gPSB2YWxpZGF0b3JEYXRhLm1pbl9zZWxmX2RlbGVnYXRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnRva2VucyA9IHZhbGlkYXRvckRhdGEudG9rZW5zO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzID0gdmFsaWRhdG9yRGF0YS5kZWxlZ2F0b3Jfc2hhcmVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZXNjcmlwdGlvbiA9IHZhbGlkYXRvckRhdGEuZGVzY3JpcHRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmJvbmRfaGVpZ2h0ID0gdmFsaWRhdG9yRGF0YS5ib25kX2hlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYm9uZF9pbnRyYV90eF9jb3VudGVyID0gdmFsaWRhdG9yRGF0YS5ib25kX2ludHJhX3R4X2NvdW50ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnVuYm9uZGluZ19oZWlnaHQgPSB2YWxpZGF0b3JEYXRhLnVuYm9uZGluZ19oZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnVuYm9uZGluZ190aW1lID0gdmFsaWRhdG9yRGF0YS51bmJvbmRpbmdfdGltZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuY29tbWlzc2lvbiA9IHZhbGlkYXRvckRhdGEuY29tbWlzc2lvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iuc2VsZl9kZWxlZ2F0aW9uID0gdmFsaWRhdG9yLmRlbGVnYXRvcl9zaGFyZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLnJlbW92ZWQgPSBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IucmVtb3ZlZEF0ID0gMFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvclNldC5zcGxpY2UodmFsLCAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ25vIGNvbiBwdWIga2V5PycpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGJ1bGtWYWxpZGF0b3JzLmluc2VydCh2YWxpZGF0b3IpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7Y29uc2Vuc3VzX3B1YmtleTogdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXl9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6dmFsaWRhdG9yfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcInZhbGlkYXRvciBmaXJzdCBhcHBlYXJzOiBcIitidWxrVmFsaWRhdG9ycy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZQSGlzdG9yeS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IHZhbGlkYXRvci5hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZXZfdm90aW5nX3Bvd2VyOiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogdmFsaWRhdG9yLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnYWRkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGJsb2NrRGF0YS5oZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogYmxvY2tEYXRhLnRpbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBNZXRlb3IuY2FsbCgncnVuQ29kZScsIGNvbW1hbmQsIGZ1bmN0aW9uKGVycm9yLCByZXN1bHQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmFkZHJlc3MgPSByZXN1bHQubWF0Y2goL1xcc1swLTlBLUZdezQwfSQvaWdtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5hZGRyZXNzID0gdmFsaWRhdG9yLmFkZHJlc3NbMF0udHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmhleCA9IHJlc3VsdC5tYXRjaCgvXFxzWzAtOUEtRl17NjR9JC9pZ20pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmhleCA9IHZhbGlkYXRvci5oZXhbMF0udHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmNvc21vc2FjY3B1YiA9IHJlc3VsdC5tYXRjaCgvY29zbW9zcHViLiokL2lnbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuY29zbW9zYWNjcHViID0gdmFsaWRhdG9yLmNvc21vc2FjY3B1YlswXS50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gcmVzdWx0Lm1hdGNoKC9jb3Ntb3N2YWxvcGVycHViLiokL2lnbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gdmFsaWRhdG9yLm9wZXJhdG9yX3B1YmtleVswXS50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleSA9IHJlc3VsdC5tYXRjaCgvY29zbW9zdmFsY29uc3B1Yi4qJC9pZ20pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXkgPSB2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleVswXS50cmltKCk7XG5cblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNle1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvckRhdGEgPSB2YWxpZGF0b3JTZXRbdmFsRXhpc3QuY29uc2Vuc3VzX3B1YmtleV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JEYXRhKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yRGF0YS5kZXNjcmlwdGlvbiAmJiAoIXZhbEV4aXN0LmRlc2NyaXB0aW9uIHx8IHZhbGlkYXRvckRhdGEuZGVzY3JpcHRpb24uaWRlbnRpdHkgIT09IHZhbEV4aXN0LmRlc2NyaXB0aW9uLmlkZW50aXR5KSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnByb2ZpbGVfdXJsID0gIGdldFZhbGlkYXRvclByb2ZpbGVVcmwodmFsaWRhdG9yRGF0YS5kZXNjcmlwdGlvbi5pZGVudGl0eSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuamFpbGVkID0gdmFsaWRhdG9yRGF0YS5qYWlsZWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnN0YXR1cyA9IHZhbGlkYXRvckRhdGEuc3RhdHVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci50b2tlbnMgPSB2YWxpZGF0b3JEYXRhLnRva2VucztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuZGVsZWdhdG9yX3NoYXJlcyA9IHZhbGlkYXRvckRhdGEuZGVsZWdhdG9yX3NoYXJlcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuZGVzY3JpcHRpb24gPSB2YWxpZGF0b3JEYXRhLmRlc2NyaXB0aW9uO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5ib25kX2hlaWdodCA9IHZhbGlkYXRvckRhdGEuYm9uZF9oZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmJvbmRfaW50cmFfdHhfY291bnRlciA9IHZhbGlkYXRvckRhdGEuYm9uZF9pbnRyYV90eF9jb3VudGVyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci51bmJvbmRpbmdfaGVpZ2h0ID0gdmFsaWRhdG9yRGF0YS51bmJvbmRpbmdfaGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci51bmJvbmRpbmdfdGltZSA9IHZhbGlkYXRvckRhdGEudW5ib25kaW5nX3RpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmNvbW1pc3Npb24gPSB2YWxpZGF0b3JEYXRhLmNvbW1pc3Npb247XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjYWxjdWxhdGUgc2VsZiBkZWxlZ2F0aW9uIHBlcmNlbnRhZ2UgZXZlcnkgMzAgYmxvY2tzXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVpZ2h0ICUgMzAgPT0gMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KExDRCArICcvc3Rha2luZy9kZWxlZ2F0b3JzLycrdmFsRXhpc3QuZGVsZWdhdG9yX2FkZHJlc3MrJy9kZWxlZ2F0aW9ucy8nK3ZhbEV4aXN0Lm9wZXJhdG9yX2FkZHJlc3MpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzZWxmRGVsZWdhdGlvbiA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzZWxmRGVsZWdhdGlvbi5zaGFyZXMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iuc2VsZl9kZWxlZ2F0aW9uID0gcGFyc2VGbG9hdChzZWxmRGVsZWdhdGlvbi5zaGFyZXMpL3BhcnNlRmxvYXQodmFsaWRhdG9yLmRlbGVnYXRvcl9zaGFyZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7Y29uc2Vuc3VzX3B1YmtleTogdmFsRXhpc3QuY29uc2Vuc3VzX3B1YmtleX0pLnVwZGF0ZU9uZSh7JHNldDp2YWxpZGF0b3J9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcInZhbGlkYXRvciBleGlzaXRzOiBcIitidWxrVmFsaWRhdG9ycy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvclNldC5zcGxpY2UodmFsLCAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdubyBjb24gcHViIGtleT8nKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByZXZWb3RpbmdQb3dlciA9IFZvdGluZ1Bvd2VySGlzdG9yeS5maW5kT25lKHthZGRyZXNzOnZhbGlkYXRvci5hZGRyZXNzfSwge2hlaWdodDotMSwgbGltaXQ6MX0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJldlZvdGluZ1Bvd2VyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJldlZvdGluZ1Bvd2VyLnZvdGluZ19wb3dlciAhPSB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNoYW5nZVR5cGUgPSAocHJldlZvdGluZ1Bvd2VyLnZvdGluZ19wb3dlciA+IHZhbGlkYXRvci52b3RpbmdfcG93ZXIpPydkb3duJzondXAnO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgY2hhbmdlRGF0YSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IHZhbGlkYXRvci5hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IHByZXZWb3RpbmdQb3dlci52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IHZhbGlkYXRvci52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBjaGFuZ2VUeXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBibG9ja0RhdGEuaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogYmxvY2tEYXRhLnRpbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ3ZvdGluZyBwb3dlciBjaGFuZ2VkLicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhjaGFuZ2VEYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZQSGlzdG9yeS5pbnNlcnQoY2hhbmdlRGF0YSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHZhbGlkYXRvcik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS52b3RpbmdfcG93ZXIgKz0gdmFsaWRhdG9yLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBpZiB0aGVyZSBpcyB2YWxpZGF0b3IgcmVtb3ZlZFxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByZXZWYWxpZGF0b3JzID0gVmFsaWRhdG9yU2V0cy5maW5kT25lKHtibG9ja19oZWlnaHQ6aGVpZ2h0LTF9KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmV2VmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZW1vdmVkVmFsaWRhdG9ycyA9IGdldFJlbW92ZWRWYWxpZGF0b3JzKHByZXZWYWxpZGF0b3JzLnZhbGlkYXRvcnMsIHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnMpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAociBpbiByZW1vdmVkVmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVlBIaXN0b3J5Lmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogcmVtb3ZlZFZhbGlkYXRvcnNbcl0uYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmV2X3ZvdGluZ19wb3dlcjogcmVtb3ZlZFZhbGlkYXRvcnNbcl0udm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAncmVtb3ZlJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGJsb2NrRGF0YS5oZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogYmxvY2tEYXRhLnRpbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2hlY2sgaWYgdGhlcmUncyBhbnkgdmFsaWRhdG9yIG5vdCBpbiBkYiAxNDQwMCBibG9ja3MofjEgZGF5KVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGhlaWdodCAlIDE0NDAwID09IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdDaGVja2luZyBhbGwgdmFsaWRhdG9ycyBhZ2FpbnN0IGRiLi4uJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRiVmFsaWRhdG9ycyA9IHt9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZhbGlkYXRvcnMuZmluZCh7fSwge2ZpZWxkczoge2NvbnNlbnN1c19wdWJrZXk6IDEsIHN0YXR1czogMX19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLmZvckVhY2goKHYpID0+IGRiVmFsaWRhdG9yc1t2LmNvbnNlbnN1c19wdWJrZXldID0gdi5zdGF0dXMpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE9iamVjdC5rZXlzKHZhbGlkYXRvclNldCkuZm9yRWFjaCgoY29uUHViS2V5KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yRGF0YSA9IHZhbGlkYXRvclNldFtjb25QdWJLZXldO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQWN0aXZlIHZhbGlkYXRvcnMgc2hvdWxkIGhhdmUgYmVlbiB1cGRhdGVkIGluIHByZXZpb3VzIHN0ZXBzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yRGF0YS5zdGF0dXMgPT09IDIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkYlZhbGlkYXRvcnNbY29uUHViS2V5XSA9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgdmFsaWRhdG9yIHdpdGggY29uc2Vuc3VzX3B1YmtleSAke2NvblB1YktleX0gbm90IGluIGRiYCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JEYXRhLnB1Yl9rZXkgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwidHlwZVwiIDogXCJ0ZW5kZXJtaW50L1B1YktleUVkMjU1MTlcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ2YWx1ZVwiOiBNZXRlb3IuY2FsbCgnYmVjaDMyVG9QdWJrZXknLCBjb25QdWJLZXkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvckRhdGEuYWRkcmVzcyA9IGdldEFkZHJlc3ModmFsaWRhdG9yRGF0YS5wdWJfa2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JEYXRhLmRlbGVnYXRvcl9hZGRyZXNzID0gTWV0ZW9yLmNhbGwoJ2dldERlbGVnYXRvcicsIHZhbGlkYXRvckRhdGEub3BlcmF0b3JfYWRkcmVzcyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JEYXRhLmFjY3B1YiA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbGlkYXRvckRhdGEucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhBY2NQdWIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvckRhdGEub3BlcmF0b3JfcHVia2V5ID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yRGF0YS5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeFZhbFB1Yik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkodmFsaWRhdG9yRGF0YSkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7Y29uc2Vuc3VzX3B1YmtleTogY29uUHViS2V5fSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OnZhbGlkYXRvckRhdGF9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoZGJWYWxpZGF0b3JzW2NvblB1YktleV0gPT0gMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JzLmZpbmQoe2NvbnNlbnN1c19wdWJrZXk6IGNvblB1YktleX0pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDp2YWxpZGF0b3JEYXRhfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBmZXRjaGluZyBrZXliYXNlIGV2ZXJ5IDE0NDAwIGJsb2Nrcyh+MSBkYXkpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVpZ2h0ICUgMTQ0MDAgPT0gMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0ZldGNoaW5nIGtleWJhc2UuLi4nKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZhbGlkYXRvcnMuZmluZCh7fSkuZm9yRWFjaCgodmFsaWRhdG9yKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJvZmlsZVVybCA9ICBnZXRWYWxpZGF0b3JQcm9maWxlVXJsKHZhbGlkYXRvci5kZXNjcmlwdGlvbi5pZGVudGl0eSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcm9maWxlVXJsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7YWRkcmVzczogdmFsaWRhdG9yLmFkZHJlc3N9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OnsncHJvZmlsZV91cmwnOnByb2ZpbGVVcmx9fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZW5kRmluZFZhbGlkYXRvcnNOYW1lVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkdldCB2YWxpZGF0b3JzIG5hbWUgdGltZTogXCIrKChlbmRGaW5kVmFsaWRhdG9yc05hbWVUaW1lLXN0YXJ0RmluZFZhbGlkYXRvcnNOYW1lVGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gcmVjb3JkIGZvciBhbmFseXRpY3NcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzdGFydEFuYXl0aWNzSW5zZXJ0VGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBBbmFseXRpY3MuaW5zZXJ0KGFuYWx5dGljc0RhdGEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGVuZEFuYWx5dGljc0luc2VydFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJBbmFseXRpY3MgaW5zZXJ0IHRpbWU6IFwiKygoZW5kQW5hbHl0aWNzSW5zZXJ0VGltZS1zdGFydEFuYXl0aWNzSW5zZXJ0VGltZSkvMTAwMCkrXCJzZWNvbmRzLlwiKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0VlVwVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYnVsa1ZhbGlkYXRvcnMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coYnVsa1ZhbGlkYXRvcnMubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5leGVjdXRlKChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlbmRWVXBUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiVmFsaWRhdG9yIHVwZGF0ZSB0aW1lOiBcIisoKGVuZFZVcFRpbWUtc3RhcnRWVXBUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRWUlRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGJ1bGtWYWxpZGF0b3JSZWNvcmRzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JSZWNvcmRzLmV4ZWN1dGUoKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZW5kVlJUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiVmFsaWRhdG9yIHJlY29yZHMgdXBkYXRlIHRpbWU6IFwiKygoZW5kVlJUaW1lLXN0YXJ0VlJUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYnVsa1ZQSGlzdG9yeS5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVlBIaXN0b3J5LmV4ZWN1dGUoKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYnVsa1RyYW5zYXRpb25zLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtUcmFuc2F0aW9ucy5leGVjdXRlKChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2FsY3VsYXRlIHZvdGluZyBwb3dlciBkaXN0cmlidXRpb24gZXZlcnkgNjAgYmxvY2tzIH4gNW1pbnNcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGhlaWdodCAlIDYwID09IDEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiPT09PT0gY2FsY3VsYXRlIHZvdGluZyBwb3dlciBkaXN0cmlidXRpb24gPT09PT1cIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGFjdGl2ZVZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe3N0YXR1czoyLGphaWxlZDpmYWxzZX0se3NvcnQ6e3ZvdGluZ19wb3dlcjotMX19KS5mZXRjaCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBudW1Ub3BUd2VudHkgPSBNYXRoLmNlaWwoYWN0aXZlVmFsaWRhdG9ycy5sZW5ndGgqMC4yKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgbnVtQm90dG9tRWlnaHR5ID0gYWN0aXZlVmFsaWRhdG9ycy5sZW5ndGggLSBudW1Ub3BUd2VudHk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdG9wVHdlbnR5UG93ZXIgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBib3R0b21FaWdodHlQb3dlciA9IDA7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgbnVtVG9wVGhpcnR5Rm91ciA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG51bUJvdHRvbVNpeHR5U2l4ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdG9wVGhpcnR5Rm91clBlcmNlbnQgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBib3R0b21TaXh0eVNpeFBlcmNlbnQgPSAwO1xuXG5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodiBpbiBhY3RpdmVWYWxpZGF0b3JzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHYgPCBudW1Ub3BUd2VudHkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wVHdlbnR5UG93ZXIgKz0gYWN0aXZlVmFsaWRhdG9yc1t2XS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvdHRvbUVpZ2h0eVBvd2VyICs9IGFjdGl2ZVZhbGlkYXRvcnNbdl0udm90aW5nX3Bvd2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodG9wVGhpcnR5Rm91clBlcmNlbnQgPCAwLjM0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvcFRoaXJ0eUZvdXJQZXJjZW50ICs9IGFjdGl2ZVZhbGlkYXRvcnNbdl0udm90aW5nX3Bvd2VyIC8gYW5hbHl0aWNzRGF0YS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Ub3BUaGlydHlGb3VyKys7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3R0b21TaXh0eVNpeFBlcmNlbnQgPSAxIC0gdG9wVGhpcnR5Rm91clBlcmNlbnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVtQm90dG9tU2l4dHlTaXggPSBhY3RpdmVWYWxpZGF0b3JzLmxlbmd0aCAtIG51bVRvcFRoaXJ0eUZvdXI7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdnBEaXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVtVG9wVHdlbnR5OiBudW1Ub3BUd2VudHksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvcFR3ZW50eVBvd2VyOiB0b3BUd2VudHlQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVtQm90dG9tRWlnaHR5OiBudW1Cb3R0b21FaWdodHksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvdHRvbUVpZ2h0eVBvd2VyOiBib3R0b21FaWdodHlQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVtVG9wVGhpcnR5Rm91cjogbnVtVG9wVGhpcnR5Rm91cixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wVGhpcnR5Rm91clBlcmNlbnQ6IHRvcFRoaXJ0eUZvdXJQZXJjZW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Cb3R0b21TaXh0eVNpeDogbnVtQm90dG9tU2l4dHlTaXgsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvdHRvbVNpeHR5U2l4UGVyY2VudDogYm90dG9tU2l4dHlTaXhQZXJjZW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1WYWxpZGF0b3JzOiBhY3RpdmVWYWxpZGF0b3JzLmxlbmd0aCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWxWb3RpbmdQb3dlcjogYW5hbHl0aWNzRGF0YS52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrVGltZTogYmxvY2tEYXRhLnRpbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNyZWF0ZUF0OiBuZXcgRGF0ZSgpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2codnBEaXN0KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZQRGlzdHJpYnV0aW9ucy5pbnNlcnQodnBEaXN0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgICAgICBTWU5DSU5HID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcIlN0b3BwZWRcIjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgbGV0IGVuZEJsb2NrVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJUaGlzIGJsb2NrIHVzZWQ6IFwiKygoZW5kQmxvY2tUaW1lLXN0YXJ0QmxvY2tUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgU1lOQ0lORyA9IGZhbHNlO1xuICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0sIHskc2V0OntsYXN0QmxvY2tzU3luY2VkVGltZTpuZXcgRGF0ZSgpLCB0b3RhbFZhbGlkYXRvcnM6dG90YWxWYWxpZGF0b3JzfX0pO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHVudGlsO1xuICAgIH0sXG4gICAgJ2FkZExpbWl0JzogZnVuY3Rpb24obGltaXQpIHtcbiAgICAgICAgLy8gY29uc29sZS5sb2cobGltaXQrMTApXG4gICAgICAgIHJldHVybiAobGltaXQrMTApO1xuICAgIH0sXG4gICAgJ2hhc01vcmUnOiBmdW5jdGlvbihsaW1pdCkge1xuICAgICAgICBpZiAobGltaXQgPiBNZXRlb3IuY2FsbCgnZ2V0Q3VycmVudEhlaWdodCcpKSB7XG4gICAgICAgICAgICByZXR1cm4gKGZhbHNlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiAodHJ1ZSk7XG4gICAgICAgIH1cbiAgICB9XG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vYmxvY2tzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVHJhbnNhY3Rpb25zIH0gZnJvbSAnLi4vLi4vdHJhbnNhY3Rpb25zL3RyYW5zYWN0aW9ucy5qcyc7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ2Jsb2Nrcy5oZWlnaHQnLCBmdW5jdGlvbihsaW1pdCl7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKHt9LCB7bGltaXQ6IGxpbWl0LCBzb3J0OiB7aGVpZ2h0OiAtMX19KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQoYmxvY2spe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2FkZHJlc3M6YmxvY2sucHJvcG9zZXJBZGRyZXNzfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtsaW1pdDoxfVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ2Jsb2Nrcy5maW5kT25lJywgZnVuY3Rpb24oaGVpZ2h0KXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmQoe2hlaWdodDpoZWlnaHR9KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQoYmxvY2spe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7aGVpZ2h0OmJsb2NrLmhlaWdodH1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZChibG9jayl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWRkcmVzczpibG9jay5wcm9wb3NlckFkZHJlc3N9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2xpbWl0OjF9XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuXG5leHBvcnQgY29uc3QgQmxvY2tzY29uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2Jsb2NrcycpO1xuXG5CbG9ja3Njb24uaGVscGVycyh7XG4gICAgcHJvcG9zZXIoKXtcbiAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZE9uZSh7YWRkcmVzczp0aGlzLnByb3Bvc2VyQWRkcmVzc30pO1xuICAgIH1cbn0pO1xuXG4vLyBCbG9ja3Njb24uaGVscGVycyh7XG4vLyAgICAgc29ydGVkKGxpbWl0KSB7XG4vLyAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZCh7fSwge3NvcnQ6IHtoZWlnaHQ6LTF9LCBsaW1pdDogbGltaXR9KTtcbi8vICAgICB9XG4vLyB9KTtcblxuXG4vLyBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKSB7XG4vLyAgICAgTWV0ZW9yLmNhbGwoJ2Jsb2Nrc1VwZGF0ZScsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4vLyAgICAgICAgIGNvbnNvbGUubG9nKHJlc3VsdCk7XG4vLyAgICAgfSlcbi8vIH0sIDMwMDAwMDAwKTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5pbXBvcnQgeyBnZXRBZGRyZXNzIH0gZnJvbSAndGVuZGVybWludC9saWIvcHVia2V5LmpzJztcbmltcG9ydCB7IENoYWluLCBDaGFpblN0YXRlcyB9IGZyb20gJy4uL2NoYWluLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnLi4vLi4vdm90aW5nLXBvd2VyL2hpc3RvcnkuanMnO1xuXG5maW5kVm90aW5nUG93ZXIgPSAodmFsaWRhdG9yLCBnZW5WYWxpZGF0b3JzKSA9PiB7XG4gICAgZm9yIChsZXQgdiBpbiBnZW5WYWxpZGF0b3JzKXtcbiAgICAgICAgaWYgKHZhbGlkYXRvci5wdWJfa2V5LnZhbHVlID09IGdlblZhbGlkYXRvcnNbdl0ucHViX2tleS52YWx1ZSl7XG4gICAgICAgICAgICByZXR1cm4gcGFyc2VJbnQoZ2VuVmFsaWRhdG9yc1t2XS5wb3dlcik7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnY2hhaW4uZ2V0Q29uc2Vuc3VzU3RhdGUnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHVybCA9IFJQQysnL2R1bXBfY29uc2Vuc3VzX3N0YXRlJztcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGxldCBjb25zZW5zdXMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgY29uc2Vuc3VzID0gY29uc2Vuc3VzLnJlc3VsdDtcbiAgICAgICAgICAgIGxldCBoZWlnaHQgPSBjb25zZW5zdXMucm91bmRfc3RhdGUuaGVpZ2h0O1xuICAgICAgICAgICAgbGV0IHJvdW5kID0gY29uc2Vuc3VzLnJvdW5kX3N0YXRlLnJvdW5kO1xuICAgICAgICAgICAgbGV0IHN0ZXAgPSBjb25zZW5zdXMucm91bmRfc3RhdGUuc3RlcDtcbiAgICAgICAgICAgIGxldCB2b3RlZFBvd2VyID0gTWF0aC5yb3VuZChwYXJzZUZsb2F0KGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS52b3Rlc1tyb3VuZF0ucHJldm90ZXNfYml0X2FycmF5LnNwbGl0KFwiIFwiKVszXSkqMTAwKTtcblxuICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0sIHskc2V0OntcbiAgICAgICAgICAgICAgICB2b3RpbmdIZWlnaHQ6IGhlaWdodCxcbiAgICAgICAgICAgICAgICB2b3RpbmdSb3VuZDogcm91bmQsXG4gICAgICAgICAgICAgICAgdm90aW5nU3RlcDogc3RlcCxcbiAgICAgICAgICAgICAgICB2b3RlZFBvd2VyOiB2b3RlZFBvd2VyLFxuICAgICAgICAgICAgICAgIHByb3Bvc2VyQWRkcmVzczogY29uc2Vuc3VzLnJvdW5kX3N0YXRlLnZhbGlkYXRvcnMucHJvcG9zZXIuYWRkcmVzcyxcbiAgICAgICAgICAgICAgICBwcmV2b3RlczogY29uc2Vuc3VzLnJvdW5kX3N0YXRlLnZvdGVzW3JvdW5kXS5wcmV2b3RlcyxcbiAgICAgICAgICAgICAgICBwcmVjb21taXRzOiBjb25zZW5zdXMucm91bmRfc3RhdGUudm90ZXNbcm91bmRdLnByZWNvbW1pdHNcbiAgICAgICAgICAgIH19KTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAnY2hhaW4udXBkYXRlU3RhdHVzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB1cmwgPSBSUEMrJy9zdGF0dXMnO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgbGV0IHN0YXR1cyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICBzdGF0dXMgPSBzdGF0dXMucmVzdWx0O1xuICAgICAgICAgICAgbGV0IGNoYWluID0ge307XG4gICAgICAgICAgICBjaGFpbi5jaGFpbklkID0gc3RhdHVzLm5vZGVfaW5mby5uZXR3b3JrO1xuICAgICAgICAgICAgY2hhaW4ubGF0ZXN0QmxvY2tIZWlnaHQgPSBzdGF0dXMuc3luY19pbmZvLmxhdGVzdF9ibG9ja19oZWlnaHQ7XG4gICAgICAgICAgICBjaGFpbi5sYXRlc3RCbG9ja1RpbWUgPSBzdGF0dXMuc3luY19pbmZvLmxhdGVzdF9ibG9ja190aW1lO1xuXG4gICAgICAgICAgICBsZXQgbGF0ZXN0U3RhdGUgPSBDaGFpblN0YXRlcy5maW5kT25lKHt9LCB7c29ydDoge2hlaWdodDogLTF9fSlcbiAgICAgICAgICAgIGlmIChsYXRlc3RTdGF0ZSAmJiBsYXRlc3RTdGF0ZS5oZWlnaHQgPj0gY2hhaW4ubGF0ZXN0QmxvY2tIZWlnaHQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYG5vIHVwZGF0ZXMgKGdldHRpbmcgYmxvY2sgJHtjaGFpbi5sYXRlc3RCbG9ja0hlaWdodH0gYXQgYmxvY2sgJHtsYXRlc3RTdGF0ZS5oZWlnaHR9KWBcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdXJsID0gUlBDKycvdmFsaWRhdG9ycyc7XG4gICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBsZXQgdmFsaWRhdG9ycyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICB2YWxpZGF0b3JzID0gdmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9ycztcbiAgICAgICAgICAgIGNoYWluLnZhbGlkYXRvcnMgPSB2YWxpZGF0b3JzLmxlbmd0aDtcbiAgICAgICAgICAgIGxldCBhY3RpdmVWUCA9IDA7XG4gICAgICAgICAgICBmb3IgKHYgaW4gdmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgYWN0aXZlVlAgKz0gcGFyc2VJbnQodmFsaWRhdG9yc1t2XS52b3RpbmdfcG93ZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2hhaW4uYWN0aXZlVm90aW5nUG93ZXIgPSBhY3RpdmVWUDtcblxuXG4gICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6Y2hhaW4uY2hhaW5JZH0sIHskc2V0OmNoYWlufSwge3Vwc2VydDogdHJ1ZX0pO1xuICAgICAgICAgICAgLy8gR2V0IGNoYWluIHN0YXRlc1xuICAgICAgICAgICAgaWYgKHBhcnNlSW50KGNoYWluLmxhdGVzdEJsb2NrSGVpZ2h0KSA+IDApe1xuICAgICAgICAgICAgICAgIGxldCBjaGFpblN0YXRlcyA9IHt9O1xuICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLmhlaWdodCA9IHBhcnNlSW50KHN0YXR1cy5zeW5jX2luZm8ubGF0ZXN0X2Jsb2NrX2hlaWdodCk7XG4gICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMudGltZSA9IG5ldyBEYXRlKHN0YXR1cy5zeW5jX2luZm8ubGF0ZXN0X2Jsb2NrX3RpbWUpO1xuXG4gICAgICAgICAgICAgICAgdXJsID0gTENEICsgJy9zdGFraW5nL3Bvb2wnO1xuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgYm9uZGluZyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAvLyBjaGFpbi5ib25kZWRUb2tlbnMgPSBib25kaW5nLmJvbmRlZF90b2tlbnM7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNoYWluLm5vdEJvbmRlZFRva2VucyA9IGJvbmRpbmcubm90X2JvbmRlZF90b2tlbnM7XG4gICAgICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLmJvbmRlZFRva2VucyA9IHBhcnNlSW50KGJvbmRpbmcuYm9uZGVkX3Rva2Vucyk7XG4gICAgICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLm5vdEJvbmRlZFRva2VucyA9IHBhcnNlSW50KGJvbmRpbmcubm90X2JvbmRlZF90b2tlbnMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdXJsID0gTENEICsgJy9zdXBwbHkvdG90YWwvJytNZXRlb3Iuc2V0dGluZ3MucHVibGljLm1pbnRpbmdEZW5vbTtcbiAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHN1cHBseSA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy50b3RhbFN1cHBseSA9IHBhcnNlSW50KHN1cHBseSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB1cmwgPSBMQ0QgKyAnL2Rpc3RyaWJ1dGlvbi9jb21tdW5pdHlfcG9vbCc7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgcG9vbCA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICBpZiAocG9vbCAmJiBwb29sLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMuY29tbXVuaXR5UG9vbCA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9vbC5mb3JFYWNoKChhbW91bnQsIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5jb21tdW5pdHlQb29sLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZW5vbTogYW1vdW50LmRlbm9tLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IHBhcnNlRmxvYXQoYW1vdW50LmFtb3VudClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdXJsID0gTENEICsgJy9taW50aW5nL2luZmxhdGlvbic7XG4gICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBpbmZsYXRpb24gPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGluZmxhdGlvbil7XG4gICAgICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5pbmZsYXRpb24gPSBwYXJzZUZsb2F0KGluZmxhdGlvbilcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdXJsID0gTENEICsgJy9taW50aW5nL2FubnVhbC1wcm92aXNpb25zJztcbiAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHByb3Zpc2lvbnMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgICAgICBpZiAocHJvdmlzaW9ucyl7XG4gICAgICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5hbm51YWxQcm92aXNpb25zID0gcGFyc2VGbG9hdChwcm92aXNpb25zLnJlc3VsdClcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgQ2hhaW5TdGF0ZXMuaW5zZXJ0KGNoYWluU3RhdGVzKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gY2hhaW4udG90YWxWb3RpbmdQb3dlciA9IHRvdGFsVlA7XG5cbiAgICAgICAgICAgIC8vIHZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe30pLmZldGNoKCk7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyh2YWxpZGF0b3JzKTtcbiAgICAgICAgICAgIHJldHVybiBjaGFpbi5sYXRlc3RCbG9ja0hlaWdodDtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgIHJldHVybiBcIkVycm9yIGdldHRpbmcgY2hhaW4gc3RhdHVzLlwiO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAnY2hhaW4uZ2V0TGF0ZXN0U3RhdHVzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgQ2hhaW4uZmluZCgpLnNvcnQoe2NyZWF0ZWQ6LTF9KS5saW1pdCgxKTtcbiAgICB9LFxuICAgICdjaGFpbi5nZW5lc2lzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgbGV0IGNoYWluID0gQ2hhaW4uZmluZE9uZSh7Y2hhaW5JZDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSk7XG5cbiAgICAgICAgaWYgKGNoYWluICYmIGNoYWluLnJlYWRHZW5lc2lzKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdHZW5lc2lzIGZpbGUgaGFzIGJlZW4gcHJvY2Vzc2VkJyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoTWV0ZW9yLnNldHRpbmdzLmRlYnVnLnJlYWRHZW5lc2lzKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnPT09IFN0YXJ0IHByb2Nlc3NpbmcgZ2VuZXNpcyBmaWxlID09PScpO1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQoTWV0ZW9yLnNldHRpbmdzLmdlbmVzaXNGaWxlKTtcbiAgICAgICAgICAgIGxldCBnZW5lc2lzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgIGxldCBkaXN0ciA9IGdlbmVzaXMuYXBwX3N0YXRlLmRpc3RyIHx8IGdlbmVzaXMuYXBwX3N0YXRlLmRpc3RyaWJ1dGlvblxuICAgICAgICAgICAgbGV0IGNoYWluUGFyYW1zID0ge1xuICAgICAgICAgICAgICAgIGNoYWluSWQ6IGdlbmVzaXMuY2hhaW5faWQsXG4gICAgICAgICAgICAgICAgZ2VuZXNpc1RpbWU6IGdlbmVzaXMuZ2VuZXNpc190aW1lLFxuICAgICAgICAgICAgICAgIGNvbnNlbnN1c1BhcmFtczogZ2VuZXNpcy5jb25zZW5zdXNfcGFyYW1zLFxuICAgICAgICAgICAgICAgIGF1dGg6IGdlbmVzaXMuYXBwX3N0YXRlLmF1dGgsXG4gICAgICAgICAgICAgICAgYmFuazogZ2VuZXNpcy5hcHBfc3RhdGUuYmFuayxcbiAgICAgICAgICAgICAgICBzdGFraW5nOiB7XG4gICAgICAgICAgICAgICAgICAgIHBvb2w6IGdlbmVzaXMuYXBwX3N0YXRlLnN0YWtpbmcucG9vbCxcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1zOiBnZW5lc2lzLmFwcF9zdGF0ZS5zdGFraW5nLnBhcmFtc1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgbWludDogZ2VuZXNpcy5hcHBfc3RhdGUubWludCxcbiAgICAgICAgICAgICAgICBkaXN0cjoge1xuICAgICAgICAgICAgICAgICAgICBjb21tdW5pdHlUYXg6IGRpc3RyLmNvbW11bml0eV90YXgsXG4gICAgICAgICAgICAgICAgICAgIGJhc2VQcm9wb3NlclJld2FyZDogZGlzdHIuYmFzZV9wcm9wb3Nlcl9yZXdhcmQsXG4gICAgICAgICAgICAgICAgICAgIGJvbnVzUHJvcG9zZXJSZXdhcmQ6IGRpc3RyLmJvbnVzX3Byb3Bvc2VyX3Jld2FyZCxcbiAgICAgICAgICAgICAgICAgICAgd2l0aGRyYXdBZGRyRW5hYmxlZDogZGlzdHIud2l0aGRyYXdfYWRkcl9lbmFibGVkXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBnb3Y6IG51bGwsXG4gICAgICAgICAgICAgICAgc2xhc2hpbmc6e1xuICAgICAgICAgICAgICAgICAgICBwYXJhbXM6IGdlbmVzaXMuYXBwX3N0YXRlLnNsYXNoaW5nLnBhcmFtc1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgc3VwcGx5OiBnZW5lc2lzLmFwcF9zdGF0ZS5zdXBwbHksXG4gICAgICAgICAgICAgICAgY3Jpc2lzOiBnZW5lc2lzLmFwcF9zdGF0ZS5jcmlzaXNcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgbGV0IHRvdGFsVm90aW5nUG93ZXIgPSAwO1xuXG4gICAgICAgICAgICAvLyByZWFkIGdlbnR4XG4gICAgICAgICAgICBpZiAoZ2VuZXNpcy5hcHBfc3RhdGUuZ2VudXRpbCAmJiBnZW5lc2lzLmFwcF9zdGF0ZS5nZW51dGlsLmdlbnR4cyAmJiAoZ2VuZXNpcy5hcHBfc3RhdGUuZ2VudXRpbC5nZW50eHMubGVuZ3RoID4gMCkpe1xuICAgICAgICAgICAgICAgIGZvciAoaSBpbiBnZW5lc2lzLmFwcF9zdGF0ZS5nZW51dGlsLmdlbnR4cyl7XG4gICAgICAgICAgICAgICAgICAgIGxldCBtc2cgPSBnZW5lc2lzLmFwcF9zdGF0ZS5nZW51dGlsLmdlbnR4c1tpXS52YWx1ZS5tc2c7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKG1zZy50eXBlKTtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChtIGluIG1zZyl7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobXNnW21dLnR5cGUgPT0gXCJjb3Ntb3Mtc2RrL01zZ0NyZWF0ZVZhbGlkYXRvclwiKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhtc2dbbV0udmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGxldCBjb21tYW5kID0gTWV0ZW9yLnNldHRpbmdzLmJpbi5nYWlhZGVidWcrXCIgcHVia2V5IFwiK21zZ1ttXS52YWx1ZS5wdWJrZXk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvciA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc2Vuc3VzX3B1YmtleTogbXNnW21dLnZhbHVlLnB1YmtleSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IG1zZ1ttXS52YWx1ZS5kZXNjcmlwdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tbWlzc2lvbjogbXNnW21dLnZhbHVlLmNvbW1pc3Npb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbl9zZWxmX2RlbGVnYXRpb246IG1zZ1ttXS52YWx1ZS5taW5fc2VsZl9kZWxlZ2F0aW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcGVyYXRvcl9hZGRyZXNzOiBtc2dbbV0udmFsdWUudmFsaWRhdG9yX2FkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGVnYXRvcl9hZGRyZXNzOiBtc2dbbV0udmFsdWUuZGVsZWdhdG9yX2FkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogTWF0aC5mbG9vcihwYXJzZUludChtc2dbbV0udmFsdWUudmFsdWUuYW1vdW50KSAvIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuc3Rha2luZ0ZyYWN0aW9uKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgamFpbGVkOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiAyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWxWb3RpbmdQb3dlciArPSB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHB1YmtleVZhbHVlID0gTWV0ZW9yLmNhbGwoJ2JlY2gzMlRvUHVia2V5JywgbXNnW21dLnZhbHVlLnB1YmtleSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gVmFsaWRhdG9ycy51cHNlcnQoe2NvbnNlbnN1c19wdWJrZXk6bXNnW21dLnZhbHVlLnB1YmtleX0sdmFsaWRhdG9yKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5wdWJfa2V5ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInR5cGVcIjpcInRlbmRlcm1pbnQvUHViS2V5RWQyNTUxOVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInZhbHVlXCI6cHVia2V5VmFsdWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYWRkcmVzcyA9IGdldEFkZHJlc3ModmFsaWRhdG9yLnB1Yl9rZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5hY2NwdWIgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3IucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhBY2NQdWIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXkgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3IucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhWYWxQdWIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZvdGluZ1Bvd2VySGlzdG9yeS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOiB2YWxpZGF0b3IuYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogdmFsaWRhdG9yLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2FkZCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogZ2VuZXNpcy5nZW5lc2lzX3RpbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZhbGlkYXRvcnMuaW5zZXJ0KHZhbGlkYXRvcik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIHJlYWQgdmFsaWRhdG9ycyBmcm9tIHByZXZpb3VzIGNoYWluXG4gICAgICAgICAgICBjb25zb2xlLmxvZygncmVhZCB2YWxpZGF0b3JzIGZyb20gcHJldmlvdXMgY2hhaW4nKTtcbiAgICAgICAgICAgIGlmIChnZW5lc2lzLmFwcF9zdGF0ZS5zdGFraW5nLnZhbGlkYXRvcnMgJiYgZ2VuZXNpcy5hcHBfc3RhdGUuc3Rha2luZy52YWxpZGF0b3JzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGdlbmVzaXMuYXBwX3N0YXRlLnN0YWtpbmcudmFsaWRhdG9ycy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgIGxldCBnZW5WYWxpZGF0b3JzU2V0ID0gZ2VuZXNpcy5hcHBfc3RhdGUuc3Rha2luZy52YWxpZGF0b3JzO1xuICAgICAgICAgICAgICAgIGxldCBnZW5WYWxpZGF0b3JzID0gZ2VuZXNpcy52YWxpZGF0b3JzO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IHYgaW4gZ2VuVmFsaWRhdG9yc1NldCl7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGdlblZhbGlkYXRvcnNbdl0pO1xuICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yID0gZ2VuVmFsaWRhdG9yc1NldFt2XTtcbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmRlbGVnYXRvcl9hZGRyZXNzID0gTWV0ZW9yLmNhbGwoJ2dldERlbGVnYXRvcicsIGdlblZhbGlkYXRvcnNTZXRbdl0ub3BlcmF0b3JfYWRkcmVzcyk7XG5cbiAgICAgICAgICAgICAgICAgICAgbGV0IHB1YmtleVZhbHVlID0gTWV0ZW9yLmNhbGwoJ2JlY2gzMlRvUHVia2V5JywgdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXkpO1xuXG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5wdWJfa2V5ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCI6XCJ0ZW5kZXJtaW50L1B1YktleUVkMjU1MTlcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIFwidmFsdWVcIjpwdWJrZXlWYWx1ZVxuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFkZHJlc3MgPSBnZXRBZGRyZXNzKHZhbGlkYXRvci5wdWJfa2V5KTtcbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnB1Yl9rZXkgPSB2YWxpZGF0b3IucHViX2tleTtcbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFjY3B1YiA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbGlkYXRvci5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY1B1Yik7XG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXkgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3IucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhWYWxQdWIpO1xuXG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci52b3RpbmdfcG93ZXIgPSBmaW5kVm90aW5nUG93ZXIodmFsaWRhdG9yLCBnZW5WYWxpZGF0b3JzKTtcbiAgICAgICAgICAgICAgICAgICAgdG90YWxWb3RpbmdQb3dlciArPSB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyO1xuXG4gICAgICAgICAgICAgICAgICAgIFZhbGlkYXRvcnMudXBzZXJ0KHtjb25zZW5zdXNfcHVia2V5OnZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5fSx2YWxpZGF0b3IpO1xuICAgICAgICAgICAgICAgICAgICBWb3RpbmdQb3dlckhpc3RvcnkuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IHZhbGlkYXRvci5hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IHZhbGlkYXRvci52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnYWRkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrX3RpbWU6IGdlbmVzaXMuZ2VuZXNpc190aW1lXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY2hhaW5QYXJhbXMucmVhZEdlbmVzaXMgPSB0cnVlO1xuICAgICAgICAgICAgY2hhaW5QYXJhbXMuYWN0aXZlVm90aW5nUG93ZXIgPSB0b3RhbFZvdGluZ1Bvd2VyO1xuICAgICAgICAgICAgbGV0IHJlc3VsdCA9IENoYWluLnVwc2VydCh7Y2hhaW5JZDpjaGFpblBhcmFtcy5jaGFpbklkfSwgeyRzZXQ6Y2hhaW5QYXJhbXN9KTtcblxuXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnPT09IEZpbmlzaGVkIHByb2Nlc3NpbmcgZ2VuZXNpcyBmaWxlID09PScpO1xuXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBDaGFpbiwgQ2hhaW5TdGF0ZXMgfSBmcm9tICcuLi9jaGFpbi5qcyc7XG5pbXBvcnQgeyBDb2luU3RhdHMgfSBmcm9tICcuLi8uLi9jb2luLXN0YXRzL2NvaW4tc3RhdHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5cbk1ldGVvci5wdWJsaXNoKCdjaGFpblN0YXRlcy5sYXRlc3QnLCBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIFtcbiAgICAgICAgQ2hhaW5TdGF0ZXMuZmluZCh7fSx7c29ydDp7aGVpZ2h0Oi0xfSxsaW1pdDoxfSksXG4gICAgICAgIENvaW5TdGF0cy5maW5kKHt9LHtzb3J0OntsYXN0X3VwZGF0ZWRfYXQ6LTF9LGxpbWl0OjF9KVxuICAgIF07XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgnY2hhaW4uc3RhdHVzJywgZnVuY3Rpb24oKXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gQ2hhaW4uZmluZCh7Y2hhaW5JZDpNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9KTtcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKGNoYWluKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczoxLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOjEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3BlcmF0b3JfYWRkcmVzczoxLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czotMSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqYWlsZWQ6MSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9maWxlX3VybDoxXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSk7IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5cbmV4cG9ydCBjb25zdCBDaGFpbiA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjaGFpbicpO1xuZXhwb3J0IGNvbnN0IENoYWluU3RhdGVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NoYWluX3N0YXRlcycpXG5cbkNoYWluLmhlbHBlcnMoe1xuICAgIHByb3Bvc2VyKCl7XG4gICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmRPbmUoe2FkZHJlc3M6dGhpcy5wcm9wb3NlckFkZHJlc3N9KTtcbiAgICB9XG59KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQ29pblN0YXRzIH0gZnJvbSAnLi4vY29pbi1zdGF0cy5qcyc7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ2NvaW5TdGF0cy5nZXRDb2luU3RhdHMnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IGNvaW5JZCA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY29pbmdlY2tvSWQ7XG4gICAgICAgIGlmIChjb2luSWQpe1xuICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgIGxldCBub3cgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgIG5vdy5zZXRNaW51dGVzKDApO1xuICAgICAgICAgICAgICAgIGxldCB1cmwgPSBcImh0dHBzOi8vYXBpLmNvaW5nZWNrby5jb20vYXBpL3YzL3NpbXBsZS9wcmljZT9pZHM9XCIrY29pbklkK1wiJnZzX2N1cnJlbmNpZXM9dXNkJmluY2x1ZGVfbWFya2V0X2NhcD10cnVlJmluY2x1ZGVfMjRocl92b2w9dHJ1ZSZpbmNsdWRlXzI0aHJfY2hhbmdlPXRydWUmaW5jbHVkZV9sYXN0X3VwZGF0ZWRfYXQ9dHJ1ZVwiO1xuICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBkYXRhID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgZGF0YSA9IGRhdGFbY29pbklkXTtcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coY29pblN0YXRzKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIENvaW5TdGF0cy51cHNlcnQoe2xhc3RfdXBkYXRlZF9hdDpkYXRhLmxhc3RfdXBkYXRlZF9hdH0sIHskc2V0OmRhdGF9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgcmV0dXJuIFwiTm8gY29pbmdlY2tvIElkIHByb3ZpZGVkLlwiXG4gICAgICAgIH1cbiAgICB9LFxuICAgICdjb2luU3RhdHMuZ2V0U3RhdHMnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IGNvaW5JZCA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY29pbmdlY2tvSWQ7XG4gICAgICAgIGlmIChjb2luSWQpe1xuICAgICAgICAgICAgcmV0dXJuIChDb2luU3RhdHMuZmluZE9uZSh7fSx7c29ydDp7bGFzdF91cGRhdGVkX2F0Oi0xfX0pKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgcmV0dXJuIFwiTm8gY29pbmdlY2tvIElkIHByb3ZpZGVkLlwiO1xuICAgICAgICB9XG5cbiAgICB9XG59KSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IENvaW5TdGF0cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjb2luX3N0YXRzJyk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IERlbGVnYXRpb25zIH0gZnJvbSAnLi4vZGVsZWdhdGlvbnMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnZGVsZWdhdGlvbnMuZ2V0RGVsZWdhdGlvbnMnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe30pLmZldGNoKCk7XG4gICAgICAgIGxldCBkZWxlZ2F0aW9ucyA9IFtdO1xuICAgICAgICBjb25zb2xlLmxvZyhcIj09PSBHZXR0aW5nIGRlbGVnYXRpb25zID09PVwiKTtcbiAgICAgICAgZm9yICh2IGluIHZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgaWYgKHZhbGlkYXRvcnNbdl0ub3BlcmF0b3JfYWRkcmVzcyl7XG4gICAgICAgICAgICAgICAgbGV0IHVybCA9IExDRCArICcvc3Rha2luZy92YWxpZGF0b3JzLycrdmFsaWRhdG9yc1t2XS5vcGVyYXRvcl9hZGRyZXNzK1wiL2RlbGVnYXRpb25zXCI7XG4gICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRlbGVnYXRpb24gPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGRlbGVnYXRpb24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgZGVsZWdhdGlvbnMgPSBkZWxlZ2F0aW9ucy5jb25jYXQoZGVsZWdhdGlvbik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlLnN0YXR1c0NvZGUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgfSAgICBcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGZvciAoaSBpbiBkZWxlZ2F0aW9ucyl7XG4gICAgICAgICAgICBpZiAoZGVsZWdhdGlvbnNbaV0gJiYgZGVsZWdhdGlvbnNbaV0uc2hhcmVzKVxuICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zW2ldLnNoYXJlcyA9IHBhcnNlRmxvYXQoZGVsZWdhdGlvbnNbaV0uc2hhcmVzKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGRlbGVnYXRpb25zKTtcbiAgICAgICAgbGV0IGRhdGEgPSB7XG4gICAgICAgICAgICBkZWxlZ2F0aW9uczogZGVsZWdhdGlvbnMsXG4gICAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gRGVsZWdhdGlvbnMuaW5zZXJ0KGRhdGEpO1xuICAgIH1cbiAgICAvLyAnYmxvY2tzLmF2ZXJhZ2VCbG9ja1RpbWUnKGFkZHJlc3Mpe1xuICAgIC8vICAgICBsZXQgYmxvY2tzID0gQmxvY2tzY29uLmZpbmQoe3Byb3Bvc2VyQWRkcmVzczphZGRyZXNzfSkuZmV0Y2goKTtcbiAgICAvLyAgICAgbGV0IGhlaWdodHMgPSBibG9ja3MubWFwKChibG9jaywgaSkgPT4ge1xuICAgIC8vICAgICAgICAgcmV0dXJuIGJsb2NrLmhlaWdodDtcbiAgICAvLyAgICAgfSk7XG4gICAgLy8gICAgIGxldCBibG9ja3NTdGF0cyA9IEFuYWx5dGljcy5maW5kKHtoZWlnaHQ6eyRpbjpoZWlnaHRzfX0pLmZldGNoKCk7XG4gICAgLy8gICAgIC8vIGNvbnNvbGUubG9nKGJsb2Nrc1N0YXRzKTtcblxuICAgIC8vICAgICBsZXQgdG90YWxCbG9ja0RpZmYgPSAwO1xuICAgIC8vICAgICBmb3IgKGIgaW4gYmxvY2tzU3RhdHMpe1xuICAgIC8vICAgICAgICAgdG90YWxCbG9ja0RpZmYgKz0gYmxvY2tzU3RhdHNbYl0udGltZURpZmY7XG4gICAgLy8gICAgIH1cbiAgICAvLyAgICAgcmV0dXJuIHRvdGFsQmxvY2tEaWZmL2hlaWdodHMubGVuZ3RoO1xuICAgIC8vIH1cbn0pIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgRGVsZWdhdGlvbnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZGVsZWdhdGlvbnMnKTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IEVudGVycHJpc2UgfSBmcm9tICcuLi9lbnRlcnByaXNlLmpzJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdlbnRlcnByaXNlLmdldFB1cmNoYXNlT3JkZXJzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL2VudGVycHJpc2UvcG9zJztcbiAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBsZXQgcHVyY2hhc2VPcmRlcnMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcblxuICAgICAgICAgICAgbGV0IGZpbmlzaGVkUHVyY2hhc2VPcmRlcnMgPSBuZXcgU2V0KEVudGVycHJpc2UuZmluZChcbiAgICAgICAgICAgICAgICB7XCJzdGF0dXNcIjp7JGluOltcInJlamVjdFwiLCBcImNvbXBsZXRlXCJdfX1cbiAgICAgICAgICAgICkuZmV0Y2goKS5tYXAoKHApPT4gcC5wb0lkKSk7XG5cbiAgICAgICAgICAgIGxldCBwb0lkcyA9IFtdO1xuXG4gICAgICAgICAgICBpZiAocHVyY2hhc2VPcmRlcnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtQb3MgPSBFbnRlcnByaXNlLnJhd0NvbGxlY3Rpb24oKS5pbml0aWFsaXplVW5vcmRlcmVkQnVsa09wKCk7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSBpbiBwdXJjaGFzZU9yZGVycykge1xuICAgICAgICAgICAgICAgICAgICBsZXQgcG8gPSBwdXJjaGFzZU9yZGVyc1tpXVxuICAgICAgICAgICAgICAgICAgICBwby5wb0lkID0gcGFyc2VJbnQocG8uaWQpO1xuICAgICAgICAgICAgICAgICAgICBpZiAocG8ucG9JZCA+IDAgJiYgIWZpbmlzaGVkUHVyY2hhc2VPcmRlcnMuaGFzKHBvLnBvSWQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtQb3MuZmluZCh7cG9JZDogcG8ucG9JZH0pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDogcG99KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwb0lkcy5wdXNoKHBvLnBvSWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaChlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1Bvcy5maW5kKHtwb0lkOiBwby5wb0lkfSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OiBwb30pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvSWRzLnB1c2gocG8ucG9JZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZS5yZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZihwb0lkcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgIGJ1bGtQb3MuZXhlY3V0ZSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0cnVlXG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICB9XG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBFbnRlcnByaXNlIH0gZnJvbSAnLi4vZW50ZXJwcmlzZS5qcyc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjaydcblxuTWV0ZW9yLnB1Ymxpc2goJ2VudGVycHJpc2UubGlzdF9wb3MnLCBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIEVudGVycHJpc2UuZmluZCh7fSwge3NvcnQ6e3BvSWQ6LTF9fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ2VudGVycHJpc2Uub25lX3BvJywgZnVuY3Rpb24gKGlkKXtcbiAgICBjaGVjayhpZCwgTnVtYmVyKTtcbiAgICByZXR1cm4gRW50ZXJwcmlzZS5maW5kKHtwb0lkOmlkfSk7XG59KSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IEVudGVycHJpc2UgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZW50ZXJwcmlzZScpO1xuIiwiaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICd0cmFuc2FjdGlvbi5zdWJtaXQnOiBmdW5jdGlvbih0eEluZm8pIHtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7TENEfS90eHNgO1xuICAgICAgICBkYXRhID0ge1xuICAgICAgICAgICAgXCJ0eFwiOiB0eEluZm8udmFsdWUsXG4gICAgICAgICAgICBcIm1vZGVcIjogXCJzeW5jXCJcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB0aW1lc3RhbXAgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcbiAgICAgICAgY29uc29sZS5sb2coYHN1Ym1pdHRpbmcgdHJhbnNhY3Rpb24ke3RpbWVzdGFtcH0gJHt1cmx9IHdpdGggZGF0YSAke0pTT04uc3RyaW5naWZ5KGRhdGEpfWApXG5cbiAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5wb3N0KHVybCwge2RhdGF9KTtcbiAgICAgICAgY29uc29sZS5sb2coYHJlc3BvbnNlIGZvciB0cmFuc2FjdGlvbiR7dGltZXN0YW1wfSAke3VybH06ICR7SlNPTi5zdHJpbmdpZnkocmVzcG9uc2UpfWApXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCkge1xuICAgICAgICAgICAgbGV0IGRhdGEgPSByZXNwb25zZS5kYXRhXG4gICAgICAgICAgICBpZiAoZGF0YS5jb2RlKVxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoZGF0YS5jb2RlLCBKU09OLnBhcnNlKGRhdGEucmF3X2xvZykubWVzc2FnZSlcbiAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhLnR4aGFzaDtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ3RyYW5zYWN0aW9uLmV4ZWN1dGUnOiBmdW5jdGlvbihib2R5LCBwYXRoKSB7XG4gICAgICAgIGNvbnN0IHVybCA9IGAke0xDRH0vJHtwYXRofWA7XG4gICAgICAgIGRhdGEgPSB7XG4gICAgICAgICAgICBcImJhc2VfcmVxXCI6IHtcbiAgICAgICAgICAgICAgICAuLi5ib2R5LFxuICAgICAgICAgICAgICAgIFwiY2hhaW5faWRcIjogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkLFxuICAgICAgICAgICAgICAgIFwic2ltdWxhdGVcIjogZmFsc2VcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5wb3N0KHVybCwge2RhdGF9KTtcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKSB7XG4gICAgICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ3RyYW5zYWN0aW9uLnNpbXVsYXRlJzogZnVuY3Rpb24odHhNc2csIGZyb20sIHBhdGgsIGFkanVzdG1lbnQ9JzEuMicpIHtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7TENEfS8ke3BhdGh9YDtcbiAgICAgICAgZGF0YSA9IHsuLi50eE1zZyxcbiAgICAgICAgICAgIFwiYmFzZV9yZXFcIjoge1xuICAgICAgICAgICAgICAgIFwiZnJvbVwiOiBmcm9tLFxuICAgICAgICAgICAgICAgIFwiY2hhaW5faWRcIjogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkLFxuICAgICAgICAgICAgICAgIFwiZ2FzX2FkanVzdG1lbnRcIjogYWRqdXN0bWVudCxcbiAgICAgICAgICAgICAgICBcInNpbXVsYXRlXCI6IHRydWVcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5wb3N0KHVybCwge2RhdGF9KTtcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKSB7XG4gICAgICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5nYXNfZXN0aW1hdGU7XG4gICAgICAgIH1cbiAgICB9LFxufSkiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMsIEFuYWx5dGljcywgQXZlcmFnZURhdGEsIEF2ZXJhZ2VWYWxpZGF0b3JEYXRhIH0gZnJvbSAnLi4vcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclNldHMgfSBmcm9tICcvaW1wb3J0cy9hcGkvdmFsaWRhdG9yLXNldHMvdmFsaWRhdG9yLXNldHMuanMnO1xuaW1wb3J0IHsgU3RhdHVzIH0gZnJvbSAnLi4vLi4vc3RhdHVzL3N0YXR1cy5qcyc7XG5pbXBvcnQgeyBNaXNzZWRCbG9ja3NTdGF0cyB9IGZyb20gJy4uL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgTWlzc2VkQmxvY2tzIH0gZnJvbSAnLi4vcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBCbG9ja3Njb24gfSBmcm9tICcuLi8uLi9ibG9ja3MvYmxvY2tzLmpzJztcbmltcG9ydCB7IENoYWluIH0gZnJvbSAnLi4vLi4vY2hhaW4vY2hhaW4uanMnO1xuaW1wb3J0IF8gZnJvbSAnbG9kYXNoJztcbmNvbnN0IEJVTEtVUERBVEVNQVhTSVpFID0gMTAwMDtcblxuY29uc3QgZ2V0QmxvY2tTdGF0cyA9IChzdGFydEhlaWdodCwgbGF0ZXN0SGVpZ2h0KSA9PiB7XG4gICAgbGV0IGJsb2NrU3RhdHMgPSB7fTtcbiAgICBjb25zdCBjb25kID0geyRhbmQ6IFtcbiAgICAgICAgeyBoZWlnaHQ6IHsgJGd0OiBzdGFydEhlaWdodCB9IH0sXG4gICAgICAgIHsgaGVpZ2h0OiB7ICRsdGU6IGxhdGVzdEhlaWdodCB9IH0gXX07XG4gICAgY29uc3Qgb3B0aW9ucyA9IHtzb3J0OntoZWlnaHQ6IDF9fTtcbiAgICBCbG9ja3Njb24uZmluZChjb25kLCBvcHRpb25zKS5mb3JFYWNoKChibG9jaykgPT4ge1xuICAgICAgICBibG9ja1N0YXRzW2Jsb2NrLmhlaWdodF0gPSB7XG4gICAgICAgICAgICBoZWlnaHQ6IGJsb2NrLmhlaWdodCxcbiAgICAgICAgICAgIHByb3Bvc2VyQWRkcmVzczogYmxvY2sucHJvcG9zZXJBZGRyZXNzLFxuICAgICAgICAgICAgcHJlY29tbWl0c0NvdW50OiBibG9jay5wcmVjb21taXRzQ291bnQsXG4gICAgICAgICAgICB2YWxpZGF0b3JzQ291bnQ6IGJsb2NrLnZhbGlkYXRvcnNDb3VudCxcbiAgICAgICAgICAgIHZhbGlkYXRvcnM6IGJsb2NrLnZhbGlkYXRvcnMsXG4gICAgICAgICAgICB0aW1lOiBibG9jay50aW1lXG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIEFuYWx5dGljcy5maW5kKGNvbmQsIG9wdGlvbnMpLmZvckVhY2goKGJsb2NrKSA9PiB7XG4gICAgICAgIGlmICghYmxvY2tTdGF0c1tibG9jay5oZWlnaHRdKSB7XG4gICAgICAgICAgICBibG9ja1N0YXRzW2Jsb2NrLmhlaWdodF0gPSB7IGhlaWdodDogYmxvY2suaGVpZ2h0IH07XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgYmxvY2sgJHtibG9jay5oZWlnaHR9IGRvZXMgbm90IGhhdmUgYW4gZW50cnlgKTtcbiAgICAgICAgfVxuICAgICAgICBfLmFzc2lnbihibG9ja1N0YXRzW2Jsb2NrLmhlaWdodF0sIHtcbiAgICAgICAgICAgIHByZWNvbW1pdHM6IGJsb2NrLnByZWNvbW1pdHMsXG4gICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lOiBibG9jay5hdmVyYWdlQmxvY2tUaW1lLFxuICAgICAgICAgICAgdGltZURpZmY6IGJsb2NrLnRpbWVEaWZmLFxuICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiBibG9jay52b3RpbmdfcG93ZXJcbiAgICAgICAgfSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGJsb2NrU3RhdHM7XG59XG5cbmNvbnN0IGdldFByZXZpb3VzUmVjb3JkID0gKHZvdGVyQWRkcmVzcywgcHJvcG9zZXJBZGRyZXNzKSA9PiB7XG4gICAgbGV0IHByZXZpb3VzUmVjb3JkID0gTWlzc2VkQmxvY2tzLmZpbmRPbmUoXG4gICAgICAgIHt2b3Rlcjp2b3RlckFkZHJlc3MsIHByb3Bvc2VyOnByb3Bvc2VyQWRkcmVzcywgYmxvY2tIZWlnaHQ6IC0xfSk7XG4gICAgbGV0IGxhc3RVcGRhdGVkSGVpZ2h0ID0gTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGFydEhlaWdodDtcbiAgICBsZXQgcHJldlN0YXRzID0ge307XG4gICAgaWYgKHByZXZpb3VzUmVjb3JkKSB7XG4gICAgICAgIHByZXZTdGF0cyA9IF8ucGljayhwcmV2aW91c1JlY29yZCwgWydtaXNzQ291bnQnLCAndG90YWxDb3VudCddKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBwcmV2U3RhdHMgPSB7XG4gICAgICAgICAgICBtaXNzQ291bnQ6IDAsXG4gICAgICAgICAgICB0b3RhbENvdW50OiAwXG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHByZXZTdGF0cztcbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdWYWxpZGF0b3JSZWNvcmRzLmNhbGN1bGF0ZU1pc3NlZEJsb2Nrcyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIGlmICghQ09VTlRNSVNTRURCTE9DS1Mpe1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBsZXQgc3RhcnRUaW1lID0gRGF0ZS5ub3coKTtcbiAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLUyA9IHRydWU7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2NhbHVsYXRlIG1pc3NlZCBibG9ja3MgY291bnQnKTtcbiAgICAgICAgICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7fSkuZmV0Y2goKTtcbiAgICAgICAgICAgICAgICBsZXQgbGF0ZXN0SGVpZ2h0ID0gTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5nZXRDdXJyZW50SGVpZ2h0Jyk7XG4gICAgICAgICAgICAgICAgbGV0IGV4cGxvcmVyU3RhdHVzID0gU3RhdHVzLmZpbmRPbmUoe2NoYWluSWQ6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0pO1xuICAgICAgICAgICAgICAgIGxldCBzdGFydEhlaWdodCA9IChleHBsb3JlclN0YXR1cyYmZXhwbG9yZXJTdGF0dXMubGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrSGVpZ2h0KT9leHBsb3JlclN0YXR1cy5sYXN0UHJvY2Vzc2VkTWlzc2VkQmxvY2tIZWlnaHQ6TWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGFydEhlaWdodDtcbiAgICAgICAgICAgICAgICBsYXRlc3RIZWlnaHQgPSBNYXRoLm1pbihzdGFydEhlaWdodCArIEJVTEtVUERBVEVNQVhTSVpFLCBsYXRlc3RIZWlnaHQpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtNaXNzZWRTdGF0cyA9IE1pc3NlZEJsb2Nrcy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZU9yZGVyZWRCdWxrT3AoKTtcblxuICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3JzTWFwID0ge307XG4gICAgICAgICAgICAgICAgdmFsaWRhdG9ycy5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHZhbGlkYXRvcnNNYXBbdmFsaWRhdG9yLmFkZHJlc3NdID0gdmFsaWRhdG9yKTtcblxuICAgICAgICAgICAgICAgIC8vIGEgbWFwIG9mIGJsb2NrIGhlaWdodCB0byBibG9jayBzdGF0c1xuICAgICAgICAgICAgICAgIGxldCBibG9ja1N0YXRzID0gZ2V0QmxvY2tTdGF0cyhzdGFydEhlaWdodCwgbGF0ZXN0SGVpZ2h0KTtcblxuICAgICAgICAgICAgICAgIC8vIHByb3Bvc2VyVm90ZXJTdGF0cyBpcyBhIHByb3Bvc2VyLXZvdGVyIG1hcCBjb3VudGluZyBudW1iZXJzIG9mIHByb3Bvc2VkIGJsb2NrcyBvZiB3aGljaCB2b3RlciBpcyBhbiBhY3RpdmUgdmFsaWRhdG9yXG4gICAgICAgICAgICAgICAgbGV0IHByb3Bvc2VyVm90ZXJTdGF0cyA9IHt9XG5cbiAgICAgICAgICAgICAgICBfLmZvckVhY2goYmxvY2tTdGF0cywgKGJsb2NrLCBibG9ja0hlaWdodCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBsZXQgcHJvcG9zZXJBZGRyZXNzID0gYmxvY2sucHJvcG9zZXJBZGRyZXNzO1xuICAgICAgICAgICAgICAgICAgICBsZXQgdm90ZWRWYWxpZGF0b3JzID0gbmV3IFNldChibG9jay52YWxpZGF0b3JzKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvclNldHMgPSBWYWxpZGF0b3JTZXRzLmZpbmRPbmUoe2Jsb2NrX2hlaWdodDpibG9jay5oZWlnaHR9KTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHZvdGVkVm90aW5nUG93ZXIgPSAwO1xuXG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvclNldHMudmFsaWRhdG9ycy5mb3JFYWNoKChhY3RpdmVWYWxpZGF0b3IpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2b3RlZFZhbGlkYXRvcnMuaGFzKGFjdGl2ZVZhbGlkYXRvci5hZGRyZXNzKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RlZFZvdGluZ1Bvd2VyICs9IHBhcnNlRmxvYXQoYWN0aXZlVmFsaWRhdG9yLnZvdGluZ19wb3dlcilcbiAgICAgICAgICAgICAgICAgICAgfSlcblxuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JTZXRzLnZhbGlkYXRvcnMuZm9yRWFjaCgoYWN0aXZlVmFsaWRhdG9yKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY3VycmVudFZhbGlkYXRvciA9IGFjdGl2ZVZhbGlkYXRvci5hZGRyZXNzXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIV8uaGFzKHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvcl0pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByZXZTdGF0cyA9IGdldFByZXZpb3VzUmVjb3JkKGN1cnJlbnRWYWxpZGF0b3IsIHByb3Bvc2VyQWRkcmVzcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXy5zZXQocHJvcG9zZXJWb3RlclN0YXRzLCBbcHJvcG9zZXJBZGRyZXNzLCBjdXJyZW50VmFsaWRhdG9yXSwgcHJldlN0YXRzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgXy51cGRhdGUocHJvcG9zZXJWb3RlclN0YXRzLCBbcHJvcG9zZXJBZGRyZXNzLCBjdXJyZW50VmFsaWRhdG9yLCAndG90YWxDb3VudCddLCAobikgPT4gbisxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdm90ZWRWYWxpZGF0b3JzLmhhcyhjdXJyZW50VmFsaWRhdG9yKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF8udXBkYXRlKHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvciwgJ21pc3NDb3VudCddLCAobikgPT4gbisxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrTWlzc2VkU3RhdHMuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90ZXI6IGN1cnJlbnRWYWxpZGF0b3IsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrSGVpZ2h0OiBibG9jay5oZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2VyOiBwcm9wb3NlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZWNvbW1pdHNDb3VudDogYmxvY2sucHJlY29tbWl0c0NvdW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JzQ291bnQ6IGJsb2NrLnZhbGlkYXRvcnNDb3VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZTogYmxvY2sudGltZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJlY29tbWl0czogYmxvY2sucHJlY29tbWl0cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZTogYmxvY2suYXZlcmFnZUJsb2NrVGltZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGltZURpZmY6IGJsb2NrLnRpbWVEaWZmLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdQb3dlcjogYmxvY2sudm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RlZFZvdGluZ1Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkQXQ6IGxhdGVzdEhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWlzc0NvdW50OiBfLmdldChwcm9wb3NlclZvdGVyU3RhdHMsIFtwcm9wb3NlckFkZHJlc3MsIGN1cnJlbnRWYWxpZGF0b3IsICdtaXNzQ291bnQnXSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsQ291bnQ6IF8uZ2V0KHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvciwgJ3RvdGFsQ291bnQnXSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIF8uZm9yRWFjaChwcm9wb3NlclZvdGVyU3RhdHMsICh2b3RlcnMsIHByb3Bvc2VyQWRkcmVzcykgPT4ge1xuICAgICAgICAgICAgICAgICAgICBfLmZvckVhY2godm90ZXJzLCAoc3RhdHMsIHZvdGVyQWRkcmVzcykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgYnVsa01pc3NlZFN0YXRzLmZpbmQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGVyOiB2b3RlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zZXI6IHByb3Bvc2VyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja0hlaWdodDogLTFcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGVyOiB2b3RlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zZXI6IHByb3Bvc2VyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja0hlaWdodDogLTEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEF0OiBsYXRlc3RIZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWlzc0NvdW50OiBfLmdldChzdGF0cywgJ21pc3NDb3VudCcpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsQ291bnQ6IF8uZ2V0KHN0YXRzLCAndG90YWxDb3VudCcpXG4gICAgICAgICAgICAgICAgICAgICAgICB9fSk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgbGV0IG1lc3NhZ2UgPSAnJztcbiAgICAgICAgICAgICAgICBpZiAoYnVsa01pc3NlZFN0YXRzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjbGllbnQgPSBNaXNzZWRCbG9ja3MuX2RyaXZlci5tb25nby5jbGllbnQ7XG4gICAgICAgICAgICAgICAgICAgIC8vIFRPRE86IGFkZCB0cmFuc2FjdGlvbiBiYWNrIGFmdGVyIHJlcGxpY2Egc2V0KCMxNDYpIGlzIHNldCB1cFxuICAgICAgICAgICAgICAgICAgICAvLyBsZXQgc2Vzc2lvbiA9IGNsaWVudC5zdGFydFNlc3Npb24oKTtcbiAgICAgICAgICAgICAgICAgICAgLy8gc2Vzc2lvbi5zdGFydFRyYW5zYWN0aW9uKCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBidWxrUHJvbWlzZSA9IGJ1bGtNaXNzZWRTdGF0cy5leGVjdXRlKG51bGwvKiwge3Nlc3Npb259Ki8pLnRoZW4oXG4gICAgICAgICAgICAgICAgICAgICAgICBNZXRlb3IuYmluZEVudmlyb25tZW50KChyZXN1bHQsIGVycikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLUyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBQcm9taXNlLmF3YWl0KHNlc3Npb24uYWJvcnRUcmFuc2FjdGlvbigpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUHJvbWlzZS5hd2FpdChzZXNzaW9uLmNvbW1pdFRyYW5zYWN0aW9uKCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlID0gYCgke3Jlc3VsdC5yZXN1bHQubkluc2VydGVkfSBpbnNlcnRlZCwgYCArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYCR7cmVzdWx0LnJlc3VsdC5uVXBzZXJ0ZWR9IHVwc2VydGVkLCBgICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgJHtyZXN1bHQucmVzdWx0Lm5Nb2RpZmllZH0gbW9kaWZpZWQpYDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgICAgICAgICAgICAgUHJvbWlzZS5hd2FpdChidWxrUHJvbWlzZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1MgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBTdGF0dXMudXBzZXJ0KHtjaGFpbklkOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LCB7JHNldDp7bGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrSGVpZ2h0OmxhdGVzdEhlaWdodCwgbGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrVGltZTogbmV3IERhdGUoKX19KTtcbiAgICAgICAgICAgICAgICByZXR1cm4gYGRvbmUgaW4gJHtEYXRlLm5vdygpIC0gc3RhcnRUaW1lfW1zICR7bWVzc2FnZX1gO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgcmV0dXJuIFwidXBkYXRpbmcuLi5cIjtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ1ZhbGlkYXRvclJlY29yZHMuY2FsY3VsYXRlTWlzc2VkQmxvY2tzU3RhdHMnOiBmdW5jdGlvbigpe1xuICAgICAgICAvLyBUT0RPOiBkZXByZWNhdGUgdGhpcyBtZXRob2QgYW5kIE1pc3NlZEJsb2Nrc1N0YXRzIGNvbGxlY3Rpb25cbiAgICAgICAgLy8gY29uc29sZS5sb2coXCJWYWxpZGF0b3JSZWNvcmRzLmNhbGN1bGF0ZU1pc3NlZEJsb2NrczogXCIrQ09VTlRNSVNTRURCTE9DS1MpO1xuICAgICAgICBpZiAoIUNPVU5UTUlTU0VEQkxPQ0tTU1RBVFMpe1xuICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1NTVEFUUyA9IHRydWU7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnY2FsdWxhdGUgbWlzc2VkIGJsb2NrcyBzdGF0cycpO1xuICAgICAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgICAgICBsZXQgdmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7fSkuZmV0Y2goKTtcbiAgICAgICAgICAgIGxldCBsYXRlc3RIZWlnaHQgPSBNZXRlb3IuY2FsbCgnYmxvY2tzLmdldEN1cnJlbnRIZWlnaHQnKTtcbiAgICAgICAgICAgIGxldCBleHBsb3JlclN0YXR1cyA9IFN0YXR1cy5maW5kT25lKHtjaGFpbklkOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9KTtcbiAgICAgICAgICAgIGxldCBzdGFydEhlaWdodCA9IChleHBsb3JlclN0YXR1cyYmZXhwbG9yZXJTdGF0dXMubGFzdE1pc3NlZEJsb2NrSGVpZ2h0KT9leHBsb3JlclN0YXR1cy5sYXN0TWlzc2VkQmxvY2tIZWlnaHQ6TWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGFydEhlaWdodDtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGxhdGVzdEhlaWdodCk7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhzdGFydEhlaWdodCk7XG4gICAgICAgICAgICBjb25zdCBidWxrTWlzc2VkU3RhdHMgPSBNaXNzZWRCbG9ja3NTdGF0cy5yYXdDb2xsZWN0aW9uKCkuaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCgpO1xuICAgICAgICAgICAgZm9yIChpIGluIHZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgICAgIC8vIGlmICgodmFsaWRhdG9yc1tpXS5hZGRyZXNzID09IFwiQjg1NTJFQUMwRDEyM0E2QkY2MDkxMjMwNDdBNTE4MUQ0NUVFOTBCNVwiKSB8fCAodmFsaWRhdG9yc1tpXS5hZGRyZXNzID09IFwiNjlEOTlCMkM2NjA0M0FDQkVBQTg0NDc1MjVDMzU2QUZDNjQwOEUwQ1wiKSB8fCAodmFsaWRhdG9yc1tpXS5hZGRyZXNzID09IFwiMzVBRDdBMkNEMkZDNzE3MTFBNjc1ODMwRUMxMTU4MDgyMjczRDQ1N1wiKSl7XG4gICAgICAgICAgICAgICAgbGV0IHZvdGVyQWRkcmVzcyA9IHZhbGlkYXRvcnNbaV0uYWRkcmVzcztcbiAgICAgICAgICAgICAgICBsZXQgbWlzc2VkUmVjb3JkcyA9IFZhbGlkYXRvclJlY29yZHMuZmluZCh7XG4gICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6dm90ZXJBZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICBleGlzdHM6ZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICRhbmQ6IFsgeyBoZWlnaHQ6IHsgJGd0OiBzdGFydEhlaWdodCB9IH0sIHsgaGVpZ2h0OiB7ICRsdGU6IGxhdGVzdEhlaWdodCB9IH0gXVxuICAgICAgICAgICAgICAgIH0pLmZldGNoKCk7XG5cbiAgICAgICAgICAgICAgICBsZXQgY291bnRzID0ge307XG5cbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcIm1pc3NlZFJlY29yZHMgdG8gcHJvY2VzczogXCIrbWlzc2VkUmVjb3Jkcy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgIGZvciAoYiBpbiBtaXNzZWRSZWNvcmRzKXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGJsb2NrID0gQmxvY2tzY29uLmZpbmRPbmUoe2hlaWdodDptaXNzZWRSZWNvcmRzW2JdLmhlaWdodH0pO1xuICAgICAgICAgICAgICAgICAgICBsZXQgZXhpc3RpbmdSZWNvcmQgPSBNaXNzZWRCbG9ja3NTdGF0cy5maW5kT25lKHt2b3Rlcjp2b3RlckFkZHJlc3MsIHByb3Bvc2VyOmJsb2NrLnByb3Bvc2VyQWRkcmVzc30pO1xuXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY291bnRzW2Jsb2NrLnByb3Bvc2VyQWRkcmVzc10gPT09ICd1bmRlZmluZWQnKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChleGlzdGluZ1JlY29yZCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY291bnRzW2Jsb2NrLnByb3Bvc2VyQWRkcmVzc10gPSBleGlzdGluZ1JlY29yZC5jb3VudCsxO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb3VudHNbYmxvY2sucHJvcG9zZXJBZGRyZXNzXSA9IDE7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50c1tibG9jay5wcm9wb3NlckFkZHJlc3NdKys7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBmb3IgKGFkZHJlc3MgaW4gY291bnRzKXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGEgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2b3Rlcjogdm90ZXJBZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zZXI6YWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50OiBjb3VudHNbYWRkcmVzc11cbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGJ1bGtNaXNzZWRTdGF0cy5maW5kKHt2b3Rlcjp2b3RlckFkZHJlc3MsIHByb3Bvc2VyOmFkZHJlc3N9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6ZGF0YX0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyB9XG5cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKGJ1bGtNaXNzZWRTdGF0cy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICBidWxrTWlzc2VkU3RhdHMuZXhlY3V0ZShNZXRlb3IuYmluZEVudmlyb25tZW50KChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTU1RBVFMgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICBTdGF0dXMudXBzZXJ0KHtjaGFpbklkOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LCB7JHNldDp7bGFzdE1pc3NlZEJsb2NrSGVpZ2h0OmxhdGVzdEhlaWdodCwgbGFzdE1pc3NlZEJsb2NrVGltZTogbmV3IERhdGUoKX19KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTU1RBVFMgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZG9uZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1NTVEFUUyA9IGZhbHNlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgcmV0dXJuIFwidXBkYXRpbmcuLi5cIjtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ0FuYWx5dGljcy5hZ2dyZWdhdGVCbG9ja1RpbWVBbmRWb3RpbmdQb3dlcic6IGZ1bmN0aW9uKHRpbWUpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IG5vdyA9IG5ldyBEYXRlKCk7XG5cbiAgICAgICAgaWYgKHRpbWUgPT0gJ20nKXtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlQmxvY2tUaW1lID0gMDtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlVm90aW5nUG93ZXIgPSAwO1xuXG4gICAgICAgICAgICBsZXQgYW5hbHl0aWNzID0gQW5hbHl0aWNzLmZpbmQoeyBcInRpbWVcIjogeyAkZ3Q6IG5ldyBEYXRlKERhdGUubm93KCkgLSA2MCAqIDEwMDApIH0gfSkuZmV0Y2goKTtcbiAgICAgICAgICAgIGlmIChhbmFseXRpY3MubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgZm9yIChpIGluIGFuYWx5dGljcyl7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgKz0gYW5hbHl0aWNzW2ldLnRpbWVEaWZmO1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgKz0gYW5hbHl0aWNzW2ldLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSA9IGF2ZXJhZ2VCbG9ja1RpbWUgLyBhbmFseXRpY3MubGVuZ3RoO1xuICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlciA9IGF2ZXJhZ2VWb3RpbmdQb3dlciAvIGFuYWx5dGljcy5sZW5ndGg7XG5cbiAgICAgICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSx7JHNldDp7bGFzdE1pbnV0ZVZvdGluZ1Bvd2VyOmF2ZXJhZ2VWb3RpbmdQb3dlciwgbGFzdE1pbnV0ZUJsb2NrVGltZTphdmVyYWdlQmxvY2tUaW1lfX0pO1xuICAgICAgICAgICAgICAgIEF2ZXJhZ2VEYXRhLmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlcjogYXZlcmFnZVZvdGluZ1Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiB0aW1lLFxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5vd1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRpbWUgPT0gJ2gnKXtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlQmxvY2tUaW1lID0gMDtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlVm90aW5nUG93ZXIgPSAwO1xuICAgICAgICAgICAgbGV0IGFuYWx5dGljcyA9IEFuYWx5dGljcy5maW5kKHsgXCJ0aW1lXCI6IHsgJGd0OiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gNjAqNjAgKiAxMDAwKSB9IH0pLmZldGNoKCk7XG4gICAgICAgICAgICBpZiAoYW5hbHl0aWNzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgIGZvciAoaSBpbiBhbmFseXRpY3Mpe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lICs9IGFuYWx5dGljc1tpXS50aW1lRGlmZjtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyICs9IGFuYWx5dGljc1tpXS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgPSBhdmVyYWdlQmxvY2tUaW1lIC8gYW5hbHl0aWNzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgPSBhdmVyYWdlVm90aW5nUG93ZXIgLyBhbmFseXRpY3MubGVuZ3RoO1xuXG4gICAgICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0seyRzZXQ6e2xhc3RIb3VyVm90aW5nUG93ZXI6YXZlcmFnZVZvdGluZ1Bvd2VyLCBsYXN0SG91ckJsb2NrVGltZTphdmVyYWdlQmxvY2tUaW1lfX0pO1xuICAgICAgICAgICAgICAgIEF2ZXJhZ2VEYXRhLmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlcjogYXZlcmFnZVZvdGluZ1Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiB0aW1lLFxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5vd1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodGltZSA9PSAnZCcpe1xuICAgICAgICAgICAgbGV0IGF2ZXJhZ2VCbG9ja1RpbWUgPSAwO1xuICAgICAgICAgICAgbGV0IGF2ZXJhZ2VWb3RpbmdQb3dlciA9IDA7XG4gICAgICAgICAgICBsZXQgYW5hbHl0aWNzID0gQW5hbHl0aWNzLmZpbmQoeyBcInRpbWVcIjogeyAkZ3Q6IG5ldyBEYXRlKERhdGUubm93KCkgLSAyNCo2MCo2MCAqIDEwMDApIH0gfSkuZmV0Y2goKTtcbiAgICAgICAgICAgIGlmIChhbmFseXRpY3MubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgZm9yIChpIGluIGFuYWx5dGljcyl7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgKz0gYW5hbHl0aWNzW2ldLnRpbWVEaWZmO1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgKz0gYW5hbHl0aWNzW2ldLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSA9IGF2ZXJhZ2VCbG9ja1RpbWUgLyBhbmFseXRpY3MubGVuZ3RoO1xuICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlciA9IGF2ZXJhZ2VWb3RpbmdQb3dlciAvIGFuYWx5dGljcy5sZW5ndGg7XG5cbiAgICAgICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSx7JHNldDp7bGFzdERheVZvdGluZ1Bvd2VyOmF2ZXJhZ2VWb3RpbmdQb3dlciwgbGFzdERheUJsb2NrVGltZTphdmVyYWdlQmxvY2tUaW1lfX0pO1xuICAgICAgICAgICAgICAgIEF2ZXJhZ2VEYXRhLmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlcjogYXZlcmFnZVZvdGluZ1Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiB0aW1lLFxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5vd1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyByZXR1cm4gYW5hbHl0aWNzLmxlbmd0aDtcbiAgICB9LFxuICAgICdBbmFseXRpY3MuYWdncmVnYXRlVmFsaWRhdG9yRGFpbHlCbG9ja1RpbWUnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe30pLmZldGNoKCk7XG4gICAgICAgIGxldCBub3cgPSBuZXcgRGF0ZSgpO1xuICAgICAgICBmb3IgKGkgaW4gdmFsaWRhdG9ycyl7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZUJsb2NrVGltZSA9IDA7XG5cbiAgICAgICAgICAgIGxldCBibG9ja3MgPSBCbG9ja3Njb24uZmluZCh7cHJvcG9zZXJBZGRyZXNzOnZhbGlkYXRvcnNbaV0uYWRkcmVzcywgXCJ0aW1lXCI6IHsgJGd0OiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gMjQqNjAqNjAgKiAxMDAwKSB9fSwge2ZpZWxkczp7aGVpZ2h0OjF9fSkuZmV0Y2goKTtcblxuICAgICAgICAgICAgaWYgKGJsb2Nrcy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICBsZXQgYmxvY2tIZWlnaHRzID0gW107XG4gICAgICAgICAgICAgICAgZm9yIChiIGluIGJsb2Nrcyl7XG4gICAgICAgICAgICAgICAgICAgIGJsb2NrSGVpZ2h0cy5wdXNoKGJsb2Nrc1tiXS5oZWlnaHQpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGxldCBhbmFseXRpY3MgPSBBbmFseXRpY3MuZmluZCh7aGVpZ2h0OiB7JGluOmJsb2NrSGVpZ2h0c319LCB7ZmllbGRzOntoZWlnaHQ6MSx0aW1lRGlmZjoxfX0pLmZldGNoKCk7XG5cblxuICAgICAgICAgICAgICAgIGZvciAoYSBpbiBhbmFseXRpY3Mpe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lICs9IGFuYWx5dGljc1thXS50aW1lRGlmZjtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lID0gYXZlcmFnZUJsb2NrVGltZSAvIGFuYWx5dGljcy5sZW5ndGg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIEF2ZXJhZ2VWYWxpZGF0b3JEYXRhLmluc2VydCh7XG4gICAgICAgICAgICAgICAgcHJvcG9zZXJBZGRyZXNzOiB2YWxpZGF0b3JzW2ldLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZTogYXZlcmFnZUJsb2NrVGltZSxcbiAgICAgICAgICAgICAgICB0eXBlOiAnVmFsaWRhdG9yRGFpbHlBdmVyYWdlQmxvY2tUaW1lJyxcbiAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5vd1xuICAgICAgICAgICAgfSlcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMsIEFuYWx5dGljcywgTWlzc2VkQmxvY2tzLCBNaXNzZWRCbG9ja3NTdGF0cywgVlBEaXN0cmlidXRpb25zIH0gZnJvbSAnLi4vcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcblxuTWV0ZW9yLnB1Ymxpc2goJ3ZhbGlkYXRvcl9yZWNvcmRzLmFsbCcsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gVmFsaWRhdG9yUmVjb3Jkcy5maW5kKCk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ3ZhbGlkYXRvcl9yZWNvcmRzLnVwdGltZScsIGZ1bmN0aW9uKGFkZHJlc3MsIG51bSl7XG4gICAgcmV0dXJuIFZhbGlkYXRvclJlY29yZHMuZmluZCh7YWRkcmVzczphZGRyZXNzfSx7bGltaXQ6bnVtLCBzb3J0OntoZWlnaHQ6LTF9fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ2FuYWx5dGljcy5oaXN0b3J5JywgZnVuY3Rpb24oKXtcbiAgICByZXR1cm4gQW5hbHl0aWNzLmZpbmQoe30se3NvcnQ6e2hlaWdodDotMX0sbGltaXQ6NTB9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaCgndnBEaXN0cmlidXRpb24ubGF0ZXN0JywgZnVuY3Rpb24oKXtcbiAgICByZXR1cm4gVlBEaXN0cmlidXRpb25zLmZpbmQoe30se3NvcnQ6e2hlaWdodDotMX0sIGxpbWl0OjF9KTtcbn0pO1xuXG5wdWJsaXNoQ29tcG9zaXRlKCdtaXNzZWRibG9ja3MudmFsaWRhdG9yJywgZnVuY3Rpb24oYWRkcmVzcywgdHlwZSl7XG4gICAgbGV0IGNvbmRpdGlvbnMgPSB7fTtcbiAgICBpZiAodHlwZSA9PSAndm90ZXInKXtcbiAgICAgICAgY29uZGl0aW9ucyA9IHtcbiAgICAgICAgICAgIHZvdGVyOiBhZGRyZXNzXG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZXtcbiAgICAgICAgY29uZGl0aW9ucyA9IHtcbiAgICAgICAgICAgIHByb3Bvc2VyOiBhZGRyZXNzXG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIE1pc3NlZEJsb2Nrc1N0YXRzLmZpbmQoY29uZGl0aW9ucylcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHN0YXRzKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7YWRkcmVzczoxLCBkZXNjcmlwdGlvbjoxLCBwcm9maWxlX3VybDoxfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pO1xuXG5wdWJsaXNoQ29tcG9zaXRlKCdtaXNzZWRyZWNvcmRzLnZhbGlkYXRvcicsIGZ1bmN0aW9uKGFkZHJlc3MsIHR5cGUpe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBNaXNzZWRCbG9ja3MuZmluZChcbiAgICAgICAgICAgICAgICB7W3R5cGVdOiBhZGRyZXNzfSxcbiAgICAgICAgICAgICAgICB7c29ydDoge3VwZGF0ZWRBdDogLTF9fVxuICAgICAgICAgICAgKVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7YWRkcmVzczoxLCBkZXNjcmlwdGlvbjoxLCBvcGVyYXRvcl9hZGRyZXNzOjF9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzJztcblxuZXhwb3J0IGNvbnN0IFZhbGlkYXRvclJlY29yZHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndmFsaWRhdG9yX3JlY29yZHMnKTtcbmV4cG9ydCBjb25zdCBBbmFseXRpY3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignYW5hbHl0aWNzJyk7XG5leHBvcnQgY29uc3QgTWlzc2VkQmxvY2tzU3RhdHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignbWlzc2VkX2Jsb2Nrc19zdGF0cycpO1xuZXhwb3J0IGNvbnN0IE1pc3NlZEJsb2NrcyA9IG5ldyAgTW9uZ28uQ29sbGVjdGlvbignbWlzc2VkX2Jsb2NrcycpO1xuZXhwb3J0IGNvbnN0IFZQRGlzdHJpYnV0aW9ucyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd2b3RpbmdfcG93ZXJfZGlzdHJpYnV0aW9ucycpO1xuZXhwb3J0IGNvbnN0IEF2ZXJhZ2VEYXRhID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2F2ZXJhZ2VfZGF0YScpO1xuZXhwb3J0IGNvbnN0IEF2ZXJhZ2VWYWxpZGF0b3JEYXRhID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2F2ZXJhZ2VfdmFsaWRhdG9yX2RhdGEnKTtcblxuTWlzc2VkQmxvY2tzU3RhdHMuaGVscGVycyh7XG4gICAgcHJvcG9zZXJNb25pa2VyKCl7XG4gICAgICAgIGxldCB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe2FkZHJlc3M6dGhpcy5wcm9wb3Nlcn0pO1xuICAgICAgICByZXR1cm4gKHZhbGlkYXRvci5kZXNjcmlwdGlvbik/dmFsaWRhdG9yLmRlc2NyaXB0aW9uLm1vbmlrZXI6dGhpcy5wcm9wb3NlcjtcbiAgICB9LFxuICAgIHZvdGVyTW9uaWtlcigpe1xuICAgICAgICBsZXQgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKHthZGRyZXNzOnRoaXMudm90ZXJ9KTtcbiAgICAgICAgcmV0dXJuICh2YWxpZGF0b3IuZGVzY3JpcHRpb24pP3ZhbGlkYXRvci5kZXNjcmlwdGlvbi5tb25pa2VyOnRoaXMudm90ZXI7XG4gICAgfVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgU3RhdHVzIH0gZnJvbSAnLi4vc3RhdHVzLmpzJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJ1xuXG5NZXRlb3IucHVibGlzaCgnc3RhdHVzLnN0YXR1cycsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gU3RhdHVzLmZpbmQoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSk7XG59KTtcblxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgU3RhdHVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3N0YXR1cycpOyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uLy4uL3RyYW5zYWN0aW9ucy90cmFuc2FjdGlvbnMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBWb3RpbmdQb3dlckhpc3RvcnkgfSBmcm9tICcuLi8uLi92b3RpbmctcG93ZXIvaGlzdG9yeS5qcyc7XG5cbmNvbnN0IEFkZHJlc3NMZW5ndGggPSA0MDtcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdUcmFuc2FjdGlvbnMuaW5kZXgnOiBmdW5jdGlvbihoYXNoLCBibG9ja1RpbWUpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgaGFzaCA9IGhhc2gudG9VcHBlckNhc2UoKTtcbiAgICAgICAgbGV0IHVybCA9IExDRCsgJy90eHMvJytoYXNoO1xuICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICBsZXQgdHggPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKGhhc2gpO1xuXG4gICAgICAgIHR4LmhlaWdodCA9IHBhcnNlSW50KHR4LmhlaWdodCk7XG5cbiAgICAgICAgLy8gaWYgKCF0eC5jb2RlKXtcbiAgICAgICAgLy8gICAgIGxldCBtc2cgPSB0eC50eC52YWx1ZS5tc2c7XG4gICAgICAgIC8vICAgICBmb3IgKGxldCBtIGluIG1zZyl7XG4gICAgICAgIC8vICAgICAgICAgaWYgKG1zZ1ttXS50eXBlID09IFwiY29zbW9zLXNkay9Nc2dDcmVhdGVWYWxpZGF0b3JcIil7XG4gICAgICAgIC8vICAgICAgICAgICAgIGNvbnNvbGUubG9nKG1zZ1ttXS52YWx1ZSk7XG4gICAgICAgIC8vICAgICAgICAgICAgIGxldCBjb21tYW5kID0gTWV0ZW9yLnNldHRpbmdzLmJpbi5nYWlhZGVidWcrXCIgcHVia2V5IFwiK21zZ1ttXS52YWx1ZS5wdWJrZXk7XG4gICAgICAgIC8vICAgICAgICAgICAgIGxldCB2YWxpZGF0b3IgPSB7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBjb25zZW5zdXNfcHVia2V5OiBtc2dbbV0udmFsdWUucHVia2V5LFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IG1zZ1ttXS52YWx1ZS5kZXNjcmlwdGlvbixcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIGNvbW1pc3Npb246IG1zZ1ttXS52YWx1ZS5jb21taXNzaW9uLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgbWluX3NlbGZfZGVsZWdhdGlvbjogbXNnW21dLnZhbHVlLm1pbl9zZWxmX2RlbGVnYXRpb24sXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBvcGVyYXRvcl9hZGRyZXNzOiBtc2dbbV0udmFsdWUudmFsaWRhdG9yX2FkZHJlc3MsXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBkZWxlZ2F0b3JfYWRkcmVzczogbXNnW21dLnZhbHVlLmRlbGVnYXRvcl9hZGRyZXNzLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiBNYXRoLmZsb29yKHBhcnNlSW50KG1zZ1ttXS52YWx1ZS52YWx1ZS5hbW91bnQpIC8gMTAwMDAwMClcbiAgICAgICAgLy8gICAgICAgICAgICAgfVxuXG4gICAgICAgIC8vICAgICAgICAgICAgIE1ldGVvci5jYWxsKCdydW5Db2RlJywgY29tbWFuZCwgZnVuY3Rpb24oZXJyb3IsIHJlc3VsdCl7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYWRkcmVzcyA9IHJlc3VsdC5tYXRjaCgvXFxzWzAtOUEtRl17NDB9JC9pZ20pO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFkZHJlc3MgPSB2YWxpZGF0b3IuYWRkcmVzc1swXS50cmltKCk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuaGV4ID0gcmVzdWx0Lm1hdGNoKC9cXHNbMC05QS1GXXs2NH0kL2lnbSk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuaGV4ID0gdmFsaWRhdG9yLmhleFswXS50cmltKCk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHViX2tleSA9IHJlc3VsdC5tYXRjaCgve1wiLipcIn0vaWdtKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHZhbGlkYXRvci5wdWJfa2V5ID0gSlNPTi5wYXJzZSh2YWxpZGF0b3IucHViX2tleVswXS50cmltKCkpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgbGV0IHJlID0gbmV3IFJlZ0V4cChNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY1B1YitcIi4qJFwiLFwiaWdtXCIpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmNvc21vc2FjY3B1YiA9IHJlc3VsdC5tYXRjaChyZSk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuY29zbW9zYWNjcHViID0gdmFsaWRhdG9yLmNvc21vc2FjY3B1YlswXS50cmltKCk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICByZSA9IG5ldyBSZWdFeHAoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhWYWxQdWIrXCIuKiRcIixcImlnbVwiKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXkgPSByZXN1bHQubWF0Y2gocmUpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLm9wZXJhdG9yX3B1YmtleSA9IHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXlbMF0udHJpbSgpO1xuXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBWYWxpZGF0b3JzLnVwc2VydCh7Y29uc2Vuc3VzX3B1YmtleTptc2dbbV0udmFsdWUucHVia2V5fSx2YWxpZGF0b3IpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgVm90aW5nUG93ZXJIaXN0b3J5Lmluc2VydCh7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogdmFsaWRhdG9yLmFkZHJlc3MsXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IDAsXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdhZGQnLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogdHguaGVpZ2h0KzIsXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogYmxvY2tUaW1lXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgLy8gICAgICAgICAgICAgfSlcbiAgICAgICAgLy8gICAgICAgICB9XG4gICAgICAgIC8vICAgICB9XG4gICAgICAgIC8vIH1cblxuXG4gICAgICAgIGxldCB0eElkID0gVHJhbnNhY3Rpb25zLmluc2VydCh0eCk7XG4gICAgICAgIGlmICh0eElkKXtcbiAgICAgICAgICAgIHJldHVybiB0eElkO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgJ1RyYW5zYWN0aW9ucy5maW5kRGVsZWdhdGlvbic6IGZ1bmN0aW9uKGFkZHJlc3MsIGhlaWdodCl7XG4gICAgICAgIC8vIGZvbGxvd2luZyBjb3Ntb3Mtc2RrL3gvc2xhc2hpbmcvc3BlYy8wNl9ldmVudHMubWQgYW5kIGNvc21vcy1zZGsveC9zdGFraW5nL3NwZWMvMDZfZXZlbnRzLm1kXG4gICAgICAgIHJldHVybiBUcmFuc2FjdGlvbnMuZmluZCh7XG4gICAgICAgICAgICAkb3I6IFt7JGFuZDogW1xuICAgICAgICAgICAgICAgIHtcImV2ZW50cy50eXBlXCI6IFwiZGVsZWdhdGVcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCI6IFwidmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6IGFkZHJlc3N9XG4gICAgICAgICAgICBdfSwgeyRhbmQ6W1xuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOiBcImFjdGlvblwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOiBcInVuamFpbFwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy5rZXlcIjogXCJzZW5kZXJcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjogYWRkcmVzc31cbiAgICAgICAgICAgIF19LCB7JGFuZDpbXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLnR5cGVcIjogXCJjcmVhdGVfdmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOiBcInZhbGlkYXRvclwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOiBhZGRyZXNzfVxuICAgICAgICAgICAgXX0sIHskYW5kOltcbiAgICAgICAgICAgICAgICB7XCJldmVudHMudHlwZVwiOiBcInVuYm9uZFwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy5rZXlcIjogXCJ2YWxpZGF0b3JcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjogYWRkcmVzc31cbiAgICAgICAgICAgIF19LCB7JGFuZDpbXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLnR5cGVcIjogXCJyZWRlbGVnYXRlXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOiBcImRlc3RpbmF0aW9uX3ZhbGlkYXRvclwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOiBhZGRyZXNzfVxuICAgICAgICAgICAgXX1dLFxuICAgICAgICAgICAgXCJjb2RlXCI6IHskZXhpc3RzOiBmYWxzZX0sXG4gICAgICAgICAgICBoZWlnaHQ6eyRsdDpoZWlnaHR9fSxcbiAgICAgICAge3NvcnQ6e2hlaWdodDotMX0sXG4gICAgICAgICAgICBsaW1pdDogMX1cbiAgICAgICAgKS5mZXRjaCgpO1xuICAgIH0sXG4gICAgJ1RyYW5zYWN0aW9ucy5maW5kVXNlcic6IGZ1bmN0aW9uKGFkZHJlc3MsIGZpZWxkcz1udWxsKXtcbiAgICAgICAgLy8gYWRkcmVzcyBpcyBlaXRoZXIgZGVsZWdhdG9yIGFkZHJlc3Mgb3IgdmFsaWRhdG9yIG9wZXJhdG9yIGFkZHJlc3NcbiAgICAgICAgbGV0IHZhbGlkYXRvcjtcbiAgICAgICAgaWYgKCFmaWVsZHMpXG4gICAgICAgICAgICBmaWVsZHMgPSB7YWRkcmVzczoxLCBkZXNjcmlwdGlvbjoxLCBvcGVyYXRvcl9hZGRyZXNzOjEsIGRlbGVnYXRvcl9hZGRyZXNzOjF9O1xuICAgICAgICBpZiAoYWRkcmVzcy5pbmNsdWRlcyhNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeFZhbEFkZHIpKXtcbiAgICAgICAgICAgIC8vIHZhbGlkYXRvciBvcGVyYXRvciBhZGRyZXNzXG4gICAgICAgICAgICB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe29wZXJhdG9yX2FkZHJlc3M6YWRkcmVzc30sIHtmaWVsZHN9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChhZGRyZXNzLmluY2x1ZGVzKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4QWNjQWRkcikpe1xuICAgICAgICAgICAgLy8gZGVsZWdhdG9yIGFkZHJlc3NcbiAgICAgICAgICAgIHZhbGlkYXRvciA9IFZhbGlkYXRvcnMuZmluZE9uZSh7ZGVsZWdhdG9yX2FkZHJlc3M6YWRkcmVzc30sIHtmaWVsZHN9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChhZGRyZXNzLmxlbmd0aCA9PT0gQWRkcmVzc0xlbmd0aCkge1xuICAgICAgICAgICAgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKHthZGRyZXNzOmFkZHJlc3N9LCB7ZmllbGRzfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHZhbGlkYXRvcil7XG4gICAgICAgICAgICByZXR1cm4gdmFsaWRhdG9yO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcblxuICAgIH1cbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi90cmFuc2FjdGlvbnMuanMnO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vLi4vYmxvY2tzL2Jsb2Nrcy5qcyc7XG5cblxucHVibGlzaENvbXBvc2l0ZSgndHJhbnNhY3Rpb25zLmxpc3QnLCBmdW5jdGlvbihsaW1pdCA9IDMwKXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQoe30se3NvcnQ6e2hlaWdodDotMX0sIGxpbWl0OmxpbWl0fSlcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHR4KXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2hlaWdodDp0eC5oZWlnaHR9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7dGltZToxLCBoZWlnaHQ6MX19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgndHJhbnNhY3Rpb25zLnZhbGlkYXRvcicsIGZ1bmN0aW9uKHZhbGlkYXRvckFkZHJlc3MsIGRlbGVnYXRvckFkZHJlc3MsIGxpbWl0PTEwMCl7XG4gICAgbGV0IHF1ZXJ5ID0ge307XG4gICAgaWYgKHZhbGlkYXRvckFkZHJlc3MgJiYgZGVsZWdhdG9yQWRkcmVzcyl7XG4gICAgICAgIHF1ZXJ5ID0geyRvcjpbe1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjp2YWxpZGF0b3JBZGRyZXNzfSwge1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjpkZWxlZ2F0b3JBZGRyZXNzfV19XG4gICAgfVxuXG4gICAgaWYgKCF2YWxpZGF0b3JBZGRyZXNzICYmIGRlbGVnYXRvckFkZHJlc3Mpe1xuICAgICAgICBxdWVyeSA9IHtcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6ZGVsZWdhdG9yQWRkcmVzc31cbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQocXVlcnksIHtzb3J0OntoZWlnaHQ6LTF9LCBsaW1pdDpsaW1pdH0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOltcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHR4KXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2hlaWdodDp0eC5oZWlnaHR9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7dGltZToxLCBoZWlnaHQ6MX19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KVxuXG5wdWJsaXNoQ29tcG9zaXRlKCd0cmFuc2FjdGlvbnMuZmluZE9uZScsIGZ1bmN0aW9uKGhhc2gpe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBUcmFuc2FjdGlvbnMuZmluZCh7dHhoYXNoOmhhc2h9KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQodHgpe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7aGVpZ2h0OnR4LmhlaWdodH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmllbGRzOnt0aW1lOjEsIGhlaWdodDoxfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pXG5cbnB1Ymxpc2hDb21wb3NpdGUoJ3RyYW5zYWN0aW9ucy5oZWlnaHQnLCBmdW5jdGlvbihoZWlnaHQpe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBUcmFuc2FjdGlvbnMuZmluZCh7aGVpZ2h0OmhlaWdodH0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZCh0eCl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHtoZWlnaHQ6dHguaGVpZ2h0fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e3RpbWU6MSwgaGVpZ2h0OjF9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBCbG9ja3Njb24gfSBmcm9tICcuLi9ibG9ja3MvYmxvY2tzLmpzJztcbmltcG9ydCB7IFR4SWNvbiB9IGZyb20gJy4uLy4uL3VpL2NvbXBvbmVudHMvSWNvbnMuanN4JztcblxuZXhwb3J0IGNvbnN0IFRyYW5zYWN0aW9ucyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd0cmFuc2FjdGlvbnMnKTtcblxuVHJhbnNhY3Rpb25zLmhlbHBlcnMoe1xuICAgIGJsb2NrKCl7XG4gICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZE9uZSh7aGVpZ2h0OnRoaXMuaGVpZ2h0fSk7XG4gICAgfVxufSkiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uLy4uL3RyYW5zYWN0aW9ucy90cmFuc2FjdGlvbnMuanMnO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vLi4vYmxvY2tzL2Jsb2Nrcy5qcyc7XG5pbXBvcnQgeyBEZWxlZ2F0aW9ucyB9IGZyb20gJy4uLy4uL2RlbGVnYXRpb25zL2RlbGVnYXRpb25zLmpzJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdWYWxpZGF0b3JzLmZpbmRDcmVhdGVWYWxpZGF0b3JUaW1lJzogZnVuY3Rpb24oYWRkcmVzcyl7XG4gICAgICAgIC8vIGxvb2sgdXAgdGhlIGNyZWF0ZSB2YWxpZGF0b3IgdGltZSB0byBjb25zaWRlciBpZiB0aGUgdmFsaWRhdG9yIGhhcyBuZXZlciB1cGRhdGVkIHRoZSBjb21taXNzaW9uXG4gICAgICAgIGxldCB0eCA9IFRyYW5zYWN0aW9ucy5maW5kT25lKHskYW5kOltcbiAgICAgICAgICAgIHtcInR4LnZhbHVlLm1zZy52YWx1ZS5kZWxlZ2F0b3JfYWRkcmVzc1wiOmFkZHJlc3N9LFxuICAgICAgICAgICAge1widHgudmFsdWUubXNnLnR5cGVcIjpcImNvc21vcy1zZGsvTXNnQ3JlYXRlVmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAge2NvZGU6eyRleGlzdHM6ZmFsc2V9fVxuICAgICAgICBdfSk7XG5cbiAgICAgICAgaWYgKHR4KXtcbiAgICAgICAgICAgIGxldCBibG9jayA9IEJsb2Nrc2Nvbi5maW5kT25lKHtoZWlnaHQ6dHguaGVpZ2h0fSk7XG4gICAgICAgICAgICBpZiAoYmxvY2spe1xuICAgICAgICAgICAgICAgIHJldHVybiBibG9jay50aW1lO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICAvLyBubyBzdWNoIGNyZWF0ZSB2YWxpZGF0b3IgdHhcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgLy8gYXN5bmMgJ1ZhbGlkYXRvcnMuZ2V0QWxsRGVsZWdhdGlvbnMnKGFkZHJlc3Mpe1xuICAgICdWYWxpZGF0b3JzLmdldEFsbERlbGVnYXRpb25zJyhhZGRyZXNzKXtcbiAgICAgICAgbGV0IHVybCA9IExDRCArICcvc3Rha2luZy92YWxpZGF0b3JzLycrYWRkcmVzcysnL2RlbGVnYXRpb25zJztcblxuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgZGVsZWdhdGlvbnMgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICBkZWxlZ2F0aW9ucyA9IEpTT04ucGFyc2UoZGVsZWdhdGlvbnMuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zLmZvckVhY2goKGRlbGVnYXRpb24sIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zW2ldICYmIGRlbGVnYXRpb25zW2ldLnNoYXJlcylcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zW2ldLnNoYXJlcyA9IHBhcnNlRmxvYXQoZGVsZWdhdGlvbnNbaV0uc2hhcmVzKTtcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHJldHVybiBkZWxlZ2F0aW9ucztcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICB9XG59KTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi92YWxpZGF0b3JzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMgfSBmcm9tICcuLi8uLi9yZWNvcmRzL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnLi4vLi4vdm90aW5nLXBvd2VyL2hpc3RvcnkuanMnO1xuXG5NZXRlb3IucHVibGlzaCgndmFsaWRhdG9ycy5hbGwnLCBmdW5jdGlvbiAoc29ydCA9IFwiZGVzY3JpcHRpb24ubW9uaWtlclwiLCBkaXJlY3Rpb24gPSAtMSwgZmllbGRzPXt9KSB7XG4gICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZCh7fSwge3NvcnQ6IHtbc29ydF06IGRpcmVjdGlvbn0sIGZpZWxkczogZmllbGRzfSk7XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgndmFsaWRhdG9ycy5maXJzdFNlZW4nLHtcbiAgICBmaW5kKCkge1xuICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKHt9KTtcbiAgICB9LFxuICAgIGNoaWxkcmVuOiBbXG4gICAgICAgIHtcbiAgICAgICAgICAgIGZpbmQodmFsKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvclJlY29yZHMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgeyBhZGRyZXNzOiB2YWwuYWRkcmVzcyB9LFxuICAgICAgICAgICAgICAgICAgICB7IHNvcnQ6IHtoZWlnaHQ6IDF9LCBsaW1pdDogMX1cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgXVxufSk7XG5cbk1ldGVvci5wdWJsaXNoKCd2YWxpZGF0b3JzLnZvdGluZ19wb3dlcicsIGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZCh7XG4gICAgICAgIHN0YXR1czogMixcbiAgICAgICAgamFpbGVkOmZhbHNlXG4gICAgfSx7XG4gICAgICAgIHNvcnQ6e1xuICAgICAgICAgICAgdm90aW5nX3Bvd2VyOi0xXG4gICAgICAgIH0sXG4gICAgICAgIGZpZWxkczp7XG4gICAgICAgICAgICBhZGRyZXNzOiAxLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246MSxcbiAgICAgICAgICAgIHZvdGluZ19wb3dlcjoxLFxuICAgICAgICAgICAgcHJvZmlsZV91cmw6MVxuICAgICAgICB9XG4gICAgfVxuICAgICk7XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgndmFsaWRhdG9yLmRldGFpbHMnLCBmdW5jdGlvbihhZGRyZXNzKXtcbiAgICBsZXQgb3B0aW9ucyA9IHthZGRyZXNzOmFkZHJlc3N9O1xuICAgIGlmIChhZGRyZXNzLmluZGV4T2YoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhWYWxBZGRyKSAhPSAtMSl7XG4gICAgICAgIG9wdGlvbnMgPSB7b3BlcmF0b3JfYWRkcmVzczphZGRyZXNzfVxuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKG9wdGlvbnMpXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZCh2YWwpe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVm90aW5nUG93ZXJIaXN0b3J5LmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWRkcmVzczp2YWwuYWRkcmVzc30sXG4gICAgICAgICAgICAgICAgICAgICAgICB7c29ydDp7aGVpZ2h0Oi0xfSwgbGltaXQ6NTB9XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQodmFsKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JSZWNvcmRzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGFkZHJlc3M6IHZhbC5hZGRyZXNzIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IHNvcnQ6IHtoZWlnaHQ6IC0xfSwgbGltaXQ6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMudXB0aW1lV2luZG93fVxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgVmFsaWRhdG9yUmVjb3JkcyB9IGZyb20gJy4uL3JlY29yZHMvcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBWb3RpbmdQb3dlckhpc3RvcnkgfSBmcm9tICcuLi92b3RpbmctcG93ZXIvaGlzdG9yeS5qcyc7XG5cbmV4cG9ydCBjb25zdCBWYWxpZGF0b3JzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3ZhbGlkYXRvcnMnKTtcblxuVmFsaWRhdG9ycy5oZWxwZXJzKHtcbiAgICBmaXJzdFNlZW4oKXtcbiAgICAgICAgcmV0dXJuIFZhbGlkYXRvclJlY29yZHMuZmluZE9uZSh7YWRkcmVzczp0aGlzLmFkZHJlc3N9KTtcbiAgICB9LFxuICAgIGhpc3RvcnkoKXtcbiAgICAgICAgcmV0dXJuIFZvdGluZ1Bvd2VySGlzdG9yeS5maW5kKHthZGRyZXNzOnRoaXMuYWRkcmVzc30sIHtzb3J0OntoZWlnaHQ6LTF9LCBsaW1pdDo1MH0pLmZldGNoKCk7XG4gICAgfVxufSlcbi8vIFZhbGlkYXRvcnMuaGVscGVycyh7XG4vLyAgICAgdXB0aW1lKCl7XG4vLyAgICAgICAgIC8vIGNvbnNvbGUubG9nKHRoaXMuYWRkcmVzcyk7XG4vLyAgICAgICAgIGxldCBsYXN0SHVuZHJlZCA9IFZhbGlkYXRvclJlY29yZHMuZmluZCh7YWRkcmVzczp0aGlzLmFkZHJlc3N9LCB7c29ydDp7aGVpZ2h0Oi0xfSwgbGltaXQ6MTAwfSkuZmV0Y2goKTtcbi8vICAgICAgICAgY29uc29sZS5sb2cobGFzdEh1bmRyZWQpO1xuLy8gICAgICAgICBsZXQgdXB0aW1lID0gMDtcbi8vICAgICAgICAgZm9yIChpIGluIGxhc3RIdW5kcmVkKXtcbi8vICAgICAgICAgICAgIGlmIChsYXN0SHVuZHJlZFtpXS5leGlzdHMpe1xuLy8gICAgICAgICAgICAgICAgIHVwdGltZSs9MTtcbi8vICAgICAgICAgICAgIH1cbi8vICAgICAgICAgfVxuLy8gICAgICAgICByZXR1cm4gdXB0aW1lO1xuLy8gICAgIH1cbi8vIH0pIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgVm90aW5nUG93ZXJIaXN0b3J5ID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3ZvdGluZ19wb3dlcl9oaXN0b3J5Jyk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBFdmlkZW5jZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZXZpZGVuY2VzJyk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBWYWxpZGF0b3JTZXRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3ZhbGlkYXRvcl9zZXRzJyk7XG4iLCIvLyBJbXBvcnQgbW9kdWxlcyB1c2VkIGJ5IGJvdGggY2xpZW50IGFuZCBzZXJ2ZXIgdGhyb3VnaCBhIHNpbmdsZSBpbmRleCBlbnRyeSBwb2ludFxuLy8gZS5nLiB1c2VyYWNjb3VudHMgY29uZmlndXJhdGlvbiBmaWxlLlxuIiwiaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vLi4vYXBpL2Jsb2Nrcy9ibG9ja3MuanMnO1xuLy9pbXBvcnQgeyBQcm9wb3NhbHMgfSBmcm9tICcuLi8uLi9hcGkvcHJvcG9zYWxzL3Byb3Bvc2Fscy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JSZWNvcmRzLCBBbmFseXRpY3MsIE1pc3NlZEJsb2Nrc1N0YXRzLCBNaXNzZWRCbG9ja3MsIEF2ZXJhZ2VEYXRhLCBBdmVyYWdlVmFsaWRhdG9yRGF0YSB9IGZyb20gJy4uLy4uL2FwaS9yZWNvcmRzL3JlY29yZHMuanMnO1xuLy8gaW1wb3J0IHsgU3RhdHVzIH0gZnJvbSAnLi4vLi4vYXBpL3N0YXR1cy9zdGF0dXMuanMnO1xuaW1wb3J0IHsgVHJhbnNhY3Rpb25zIH0gZnJvbSAnLi4vLi4vYXBpL3RyYW5zYWN0aW9ucy90cmFuc2FjdGlvbnMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9yU2V0cyB9IGZyb20gJy4uLy4uL2FwaS92YWxpZGF0b3Itc2V0cy92YWxpZGF0b3Itc2V0cy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vLi4vYXBpL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBWb3RpbmdQb3dlckhpc3RvcnkgfSBmcm9tICcuLi8uLi9hcGkvdm90aW5nLXBvd2VyL2hpc3RvcnkuanMnO1xuaW1wb3J0IHsgRXZpZGVuY2VzIH0gZnJvbSAnLi4vLi4vYXBpL2V2aWRlbmNlcy9ldmlkZW5jZXMuanMnO1xuaW1wb3J0IHsgQ29pblN0YXRzIH0gZnJvbSAnLi4vLi4vYXBpL2NvaW4tc3RhdHMvY29pbi1zdGF0cy5qcyc7XG5pbXBvcnQgeyBDaGFpblN0YXRlcyB9IGZyb20gJy4uLy4uL2FwaS9jaGFpbi9jaGFpbi5qcyc7XG5cbkNoYWluU3RhdGVzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7aGVpZ2h0OiAtMX0se3VuaXF1ZTp0cnVlfSk7XG5cbkJsb2Nrc2Nvbi5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2hlaWdodDogLTF9LHt1bmlxdWU6dHJ1ZX0pO1xuQmxvY2tzY29uLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7cHJvcG9zZXJBZGRyZXNzOjF9KTtcblxuRXZpZGVuY2VzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7aGVpZ2h0OiAtMX0pO1xuXG4vL1Byb3Bvc2Fscy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2FsSWQ6IDF9LCB7dW5pcXVlOnRydWV9KTtcblxuVmFsaWRhdG9yUmVjb3Jkcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2FkZHJlc3M6MSxoZWlnaHQ6IC0xfSwge3VuaXF1ZToxfSk7XG5WYWxpZGF0b3JSZWNvcmRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7YWRkcmVzczoxLGV4aXN0czoxLCBoZWlnaHQ6IC0xfSk7XG5cbkFuYWx5dGljcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2hlaWdodDogLTF9LCB7dW5pcXVlOnRydWV9KVxuXG5NaXNzZWRCbG9ja3MucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NlcjoxLCB2b3RlcjoxLCB1cGRhdGVkQXQ6IC0xfSk7XG5NaXNzZWRCbG9ja3MucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NlcjoxLCBibG9ja0hlaWdodDotMX0pO1xuTWlzc2VkQmxvY2tzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7dm90ZXI6MSwgYmxvY2tIZWlnaHQ6LTF9KTtcbk1pc3NlZEJsb2Nrcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3ZvdGVyOjEsIHByb3Bvc2VyOjEsIGJsb2NrSGVpZ2h0Oi0xfSwge3VuaXF1ZTp0cnVlfSk7XG5cbk1pc3NlZEJsb2Nrc1N0YXRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7cHJvcG9zZXI6MX0pO1xuTWlzc2VkQmxvY2tzU3RhdHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHt2b3RlcjoxfSk7XG5NaXNzZWRCbG9ja3NTdGF0cy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2VyOjEsIHZvdGVyOjF9LHt1bmlxdWU6dHJ1ZX0pO1xuXG5BdmVyYWdlRGF0YS5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3R5cGU6MSwgY3JlYXRlZEF0Oi0xfSx7dW5pcXVlOnRydWV9KTtcbkF2ZXJhZ2VWYWxpZGF0b3JEYXRhLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7cHJvcG9zZXJBZGRyZXNzOjEsY3JlYXRlZEF0Oi0xfSx7dW5pcXVlOnRydWV9KTtcbi8vIFN0YXR1cy5yYXdDb2xsZWN0aW9uLmNyZWF0ZUluZGV4KHt9KVxuXG5UcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHt0eGhhc2g6MX0se3VuaXF1ZTp0cnVlfSk7XG5UcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtoZWlnaHQ6LTF9KTtcbi8vIFRyYW5zYWN0aW9ucy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2FjdGlvbjoxfSk7XG5UcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtcImV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOjF9KTtcblRyYW5zYWN0aW9ucy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjoxfSk7XG5cblZhbGlkYXRvclNldHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtibG9ja19oZWlnaHQ6LTF9KTtcblxuVmFsaWRhdG9ycy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2FkZHJlc3M6MX0se3VuaXF1ZTp0cnVlLCBwYXJ0aWFsRmlsdGVyRXhwcmVzc2lvbjogeyBhZGRyZXNzOiB7ICRleGlzdHM6IHRydWUgfSB9IH0pO1xuVmFsaWRhdG9ycy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2NvbnNlbnN1c19wdWJrZXk6MX0se3VuaXF1ZTp0cnVlfSk7XG5WYWxpZGF0b3JzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7XCJwdWJfa2V5LnZhbHVlXCI6MX0se3VuaXF1ZTp0cnVlLCBwYXJ0aWFsRmlsdGVyRXhwcmVzc2lvbjogeyBcInB1Yl9rZXkudmFsdWVcIjogeyAkZXhpc3RzOiB0cnVlIH0gfX0pO1xuXG5Wb3RpbmdQb3dlckhpc3RvcnkucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHthZGRyZXNzOjEsaGVpZ2h0Oi0xfSk7XG5Wb3RpbmdQb3dlckhpc3RvcnkucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHt0eXBlOjF9KTtcblxuQ29pblN0YXRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7bGFzdF91cGRhdGVkX2F0Oi0xfSx7dW5pcXVlOnRydWV9KTtcbiIsIi8vIEltcG9ydCBzZXJ2ZXIgc3RhcnR1cCB0aHJvdWdoIGEgc2luZ2xlIGluZGV4IGVudHJ5IHBvaW50XG5cbmltcG9ydCAnLi91dGlsLmpzJztcbmltcG9ydCAnLi9yZWdpc3Rlci1hcGkuanMnO1xuaW1wb3J0ICcuL2NyZWF0ZS1pbmRleGVzLmpzJztcblxuLy8gaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0Jztcbi8vIGltcG9ydCB7IHJlbmRlclRvTm9kZVN0cmVhbSB9IGZyb20gJ3JlYWN0LWRvbS9zZXJ2ZXInO1xuLy8gaW1wb3J0IHsgcmVuZGVyVG9TdHJpbmcgfSBmcm9tIFwicmVhY3QtZG9tL3NlcnZlclwiO1xuaW1wb3J0IHsgb25QYWdlTG9hZCB9IGZyb20gJ21ldGVvci9zZXJ2ZXItcmVuZGVyJztcbi8vIGltcG9ydCB7IFN0YXRpY1JvdXRlciB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuLy8gaW1wb3J0IHsgU2VydmVyU3R5bGVTaGVldCB9IGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiXG5pbXBvcnQgeyBIZWxtZXQgfSBmcm9tICdyZWFjdC1oZWxtZXQnO1xuXG4vLyBpbXBvcnQgQXBwIGZyb20gJy4uLy4uL3VpL0FwcC5qc3gnO1xuXG5vblBhZ2VMb2FkKHNpbmsgPT4ge1xuICAgIC8vIGNvbnN0IGNvbnRleHQgPSB7fTtcbiAgICAvLyBjb25zdCBzaGVldCA9IG5ldyBTZXJ2ZXJTdHlsZVNoZWV0KClcblxuICAgIC8vIGNvbnN0IGh0bWwgPSByZW5kZXJUb1N0cmluZyhzaGVldC5jb2xsZWN0U3R5bGVzKFxuICAgIC8vICAgICA8U3RhdGljUm91dGVyIGxvY2F0aW9uPXtzaW5rLnJlcXVlc3QudXJsfSBjb250ZXh0PXtjb250ZXh0fT5cbiAgICAvLyAgICAgICAgIDxBcHAgLz5cbiAgICAvLyAgICAgPC9TdGF0aWNSb3V0ZXI+XG4gICAgLy8gICApKTtcblxuICAgIC8vIHNpbmsucmVuZGVySW50b0VsZW1lbnRCeUlkKCdhcHAnLCBodG1sKTtcblxuICAgIGNvbnN0IGhlbG1ldCA9IEhlbG1ldC5yZW5kZXJTdGF0aWMoKTtcbiAgICBzaW5rLmFwcGVuZFRvSGVhZChoZWxtZXQubWV0YS50b1N0cmluZygpKTtcbiAgICBzaW5rLmFwcGVuZFRvSGVhZChoZWxtZXQudGl0bGUudG9TdHJpbmcoKSk7XG5cbiAgICAvLyBzaW5rLmFwcGVuZFRvSGVhZChzaGVldC5nZXRTdHlsZVRhZ3MoKSk7XG59KTsiLCIvLyBSZWdpc3RlciB5b3VyIGFwaXMgaGVyZVxuXG5pbXBvcnQgJy4uLy4uL2FwaS9sZWRnZXIvc2VydmVyL21ldGhvZHMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9jaGFpbi9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9jaGFpbi9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvYmxvY2tzL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL2Jsb2Nrcy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvdmFsaWRhdG9ycy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS92YWxpZGF0b3JzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9yZWNvcmRzL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL3JlY29yZHMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbi8vaW1wb3J0ICcuLi8uLi9hcGkvcHJvcG9zYWxzL3NlcnZlci9tZXRob2RzLmpzJztcbi8vaW1wb3J0ICcuLi8uLi9hcGkvcHJvcG9zYWxzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvZW50ZXJwcmlzZS9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9lbnRlcnByaXNlL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS92b3RpbmctcG93ZXIvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL3RyYW5zYWN0aW9ucy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS90cmFuc2FjdGlvbnMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL2RlbGVnYXRpb25zL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL2RlbGVnYXRpb25zL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9zdGF0dXMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL2FjY291bnRzL3NlcnZlci9tZXRob2RzLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvY29pbi1zdGF0cy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG4iLCJpbXBvcnQgYmVjaDMyIGZyb20gJ2JlY2gzMidcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5pbXBvcnQgKiBhcyBjaGVlcmlvIGZyb20gJ2NoZWVyaW8nO1xuXG4vLyBMb2FkIGZ1dHVyZSBmcm9tIGZpYmVyc1xudmFyIEZ1dHVyZSA9IE5wbS5yZXF1aXJlKFwiZmliZXJzL2Z1dHVyZVwiKTtcbi8vIExvYWQgZXhlY1xudmFyIGV4ZWMgPSBOcG0ucmVxdWlyZShcImNoaWxkX3Byb2Nlc3NcIikuZXhlYztcblxuZnVuY3Rpb24gdG9IZXhTdHJpbmcoYnl0ZUFycmF5KSB7XG4gICAgcmV0dXJuIGJ5dGVBcnJheS5tYXAoZnVuY3Rpb24oYnl0ZSkge1xuICAgICAgICByZXR1cm4gKCcwJyArIChieXRlICYgMHhGRikudG9TdHJpbmcoMTYpKS5zbGljZSgtMik7XG4gICAgfSkuam9pbignJylcbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgIHB1YmtleVRvQmVjaDMyOiBmdW5jdGlvbihwdWJrZXksIHByZWZpeCkge1xuICAgICAgICAvLyAnMTYyNERFNjQyMCcgaXMgZWQyNTUxOSBwdWJrZXkgcHJlZml4XG4gICAgICAgIGxldCBwdWJrZXlBbWlub1ByZWZpeCA9IEJ1ZmZlci5mcm9tKCcxNjI0REU2NDIwJywgJ2hleCcpXG4gICAgICAgIGxldCBidWZmZXIgPSBCdWZmZXIuYWxsb2MoMzcpXG4gICAgICAgIHB1YmtleUFtaW5vUHJlZml4LmNvcHkoYnVmZmVyLCAwKVxuICAgICAgICBCdWZmZXIuZnJvbShwdWJrZXkudmFsdWUsICdiYXNlNjQnKS5jb3B5KGJ1ZmZlciwgcHVia2V5QW1pbm9QcmVmaXgubGVuZ3RoKVxuICAgICAgICByZXR1cm4gYmVjaDMyLmVuY29kZShwcmVmaXgsIGJlY2gzMi50b1dvcmRzKGJ1ZmZlcikpXG4gICAgfSxcbiAgICBiZWNoMzJUb1B1YmtleTogZnVuY3Rpb24ocHVia2V5KSB7XG4gICAgICAgIC8vICcxNjI0REU2NDIwJyBpcyBlZDI1NTE5IHB1YmtleSBwcmVmaXhcbiAgICAgICAgbGV0IHB1YmtleUFtaW5vUHJlZml4ID0gQnVmZmVyLmZyb20oJzE2MjRERTY0MjAnLCAnaGV4JylcbiAgICAgICAgbGV0IGJ1ZmZlciA9IEJ1ZmZlci5mcm9tKGJlY2gzMi5mcm9tV29yZHMoYmVjaDMyLmRlY29kZShwdWJrZXkpLndvcmRzKSk7XG4gICAgICAgIHJldHVybiBidWZmZXIuc2xpY2UocHVia2V5QW1pbm9QcmVmaXgubGVuZ3RoKS50b1N0cmluZygnYmFzZTY0Jyk7XG4gICAgfSxcbiAgICBnZXREZWxlZ2F0b3I6IGZ1bmN0aW9uKG9wZXJhdG9yQWRkcil7XG4gICAgICAgIGxldCBhZGRyZXNzID0gYmVjaDMyLmRlY29kZShvcGVyYXRvckFkZHIpO1xuICAgICAgICByZXR1cm4gYmVjaDMyLmVuY29kZShNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY0FkZHIsIGFkZHJlc3Mud29yZHMpO1xuICAgIH0sXG4gICAgZ2V0S2V5YmFzZVRlYW1QaWM6IGZ1bmN0aW9uKGtleWJhc2VVcmwpe1xuICAgICAgICBsZXQgdGVhbVBhZ2UgPSBIVFRQLmdldChrZXliYXNlVXJsKTtcbiAgICAgICAgaWYgKHRlYW1QYWdlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgIGxldCBwYWdlID0gY2hlZXJpby5sb2FkKHRlYW1QYWdlLmNvbnRlbnQpO1xuICAgICAgICAgICAgcmV0dXJuIHBhZ2UoXCIua2ItbWFpbi1jYXJkIGltZ1wiKS5hdHRyKCdzcmMnKTtcbiAgICAgICAgfVxuICAgIH1cbn0pXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgVW5jb250cm9sbGVkVG9vbHRpcCB9IGZyb20gJ3JlYWN0c3RyYXAnO1xuXG5leHBvcnQgY29uc3QgRGVub21TeW1ib2wgPSAocHJvcHMpID0+IHtcbiAgICBzd2l0Y2ggKHByb3BzLmRlbm9tKXtcbiAgICBjYXNlIFwic3RlYWtcIjpcbiAgICAgICAgcmV0dXJuICfwn6WpJztcbiAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gJ/CfjYUnO1xuICAgIH1cbn1cblxuXG5leHBvcnQgY29uc3QgUHJvcG9zYWxTdGF0dXNJY29uID0gKHByb3BzKSA9PiB7XG4gICAgc3dpdGNoIChwcm9wcy5zdGF0dXMpe1xuICAgIGNhc2UgJ1Bhc3NlZCc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtY2hlY2stY2lyY2xlIHRleHQtc3VjY2Vzc1wiPjwvaT47XG4gICAgY2FzZSAnUmVqZWN0ZWQnOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLXRpbWVzLWNpcmNsZSB0ZXh0LWRhbmdlclwiPjwvaT47XG4gICAgY2FzZSAnUmVtb3ZlZCc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtdHJhc2gtYWx0IHRleHQtZGFya1wiPjwvaT5cbiAgICBjYXNlICdEZXBvc2l0UGVyaW9kJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1iYXR0ZXJ5LWhhbGYgdGV4dC13YXJuaW5nXCI+PC9pPjtcbiAgICBjYXNlICdWb3RpbmdQZXJpb2QnOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLWhhbmQtcGFwZXIgdGV4dC1pbmZvXCI+PC9pPjtcbiAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gPGk+PC9pPjtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCBWb3RlSWNvbiA9IChwcm9wcykgPT4ge1xuICAgIHN3aXRjaCAocHJvcHMudm90ZSl7XG4gICAgY2FzZSAneWVzJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1jaGVjayB0ZXh0LXN1Y2Nlc3NcIj48L2k+O1xuICAgIGNhc2UgJ25vJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS10aW1lcyB0ZXh0LWRhbmdlclwiPjwvaT47XG4gICAgY2FzZSAnYWJzdGFpbic6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtdXNlci1zbGFzaCB0ZXh0LXdhcm5pbmdcIj48L2k+O1xuICAgIGNhc2UgJ25vX3dpdGhfdmV0byc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtZXhjbGFtYXRpb24tdHJpYW5nbGUgdGV4dC1pbmZvXCI+PC9pPjtcbiAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gPGk+PC9pPjtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCBUeEljb24gPSAocHJvcHMpID0+IHtcbiAgICBpZiAocHJvcHMudmFsaWQpe1xuICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zdWNjZXNzIHRleHQtbm93cmFwXCI+PGkgY2xhc3NOYW1lPVwiZmFzIGZhLWNoZWNrLWNpcmNsZVwiPjwvaT48L3NwYW4+O1xuICAgIH1cbiAgICBlbHNle1xuICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1kYW5nZXIgdGV4dC1ub3dyYXBcIj48aSBjbGFzc05hbWU9XCJmYXMgZmEtdGltZXMtY2lyY2xlXCI+PC9pPjwvc3Bhbj47XG4gICAgfVxufVxuXG5leHBvcnQgY2xhc3MgSW5mb0ljb24gZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xuICAgIGNvbnN0cnVjdG9yKHByb3BzKSB7XG4gICAgICAgIHN1cGVyKHByb3BzKTtcbiAgICAgICAgdGhpcy5yZWYgPSBSZWFjdC5jcmVhdGVSZWYoKTtcbiAgICB9XG5cbiAgICByZW5kZXIoKSB7XG4gICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICA8aSBrZXk9J2ljb24nIGNsYXNzTmFtZT0nbWF0ZXJpYWwtaWNvbnMgaW5mby1pY29uJyByZWY9e3RoaXMucmVmfT5pbmZvPC9pPixcbiAgICAgICAgICAgIDxVbmNvbnRyb2xsZWRUb29sdGlwIGtleT0ndG9vbHRpcCcgcGxhY2VtZW50PSdyaWdodCcgdGFyZ2V0PXt0aGlzLnJlZn0+XG4gICAgICAgICAgICAgICAge3RoaXMucHJvcHMuY2hpbGRyZW4/dGhpcy5wcm9wcy5jaGlsZHJlbjp0aGlzLnByb3BzLnRvb2x0aXBUZXh0fVxuICAgICAgICAgICAgPC9VbmNvbnRyb2xsZWRUb29sdGlwPlxuICAgICAgICBdXG4gICAgfVxufSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IG51bWJybyBmcm9tICdudW1icm8nO1xuXG5hdXRvZm9ybWF0ID0gKHZhbHVlKSA9PiB7XG5cdGxldCBmb3JtYXR0ZXIgPSAnMCwwLjAwMDAnO1xuXHR2YWx1ZSA9IE1hdGgucm91bmQodmFsdWUgKiAxMDAwKSAvIDEwMDBcblx0aWYgKE1hdGgucm91bmQodmFsdWUpID09PSB2YWx1ZSlcblx0XHRmb3JtYXR0ZXIgPSAnMCwwJ1xuXHRlbHNlIGlmIChNYXRoLnJvdW5kKHZhbHVlKjEwKSA9PT0gdmFsdWUqMTApXG5cdFx0Zm9ybWF0dGVyID0gJzAsMC4wJ1xuXHRlbHNlIGlmIChNYXRoLnJvdW5kKHZhbHVlKjEwMCkgPT09IHZhbHVlKjEwMClcblx0XHRmb3JtYXR0ZXIgPSAnMCwwLjAwJ1xuXHRlbHNlIGlmIChNYXRoLnJvdW5kKHZhbHVlKjEwMDApID09PSB2YWx1ZSoxMDAwKVxuXHRcdGZvcm1hdHRlciA9ICcwLDAuMDAwJ1xuXHRyZXR1cm4gbnVtYnJvKHZhbHVlKS5mb3JtYXQoZm9ybWF0dGVyKVxufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBDb2luIHtcblx0c3RhdGljIFN0YWtpbmdEZW5vbSA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuc3Rha2luZ0Rlbm9tO1xuXHRzdGF0aWMgU3Rha2luZ0Rlbm9tUGx1cmFsID0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5zdGFraW5nRGVub21QbHVyYWwgfHwgKENvaW4uU3Rha2luZ0Rlbm9tICsgJ3MnKTtcblx0c3RhdGljIE1pbnRpbmdEZW5vbSA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMubWludGluZ0Rlbm9tO1xuXHRzdGF0aWMgU3Rha2luZ0ZyYWN0aW9uID0gTnVtYmVyKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuc3Rha2luZ0ZyYWN0aW9uKTtcblx0c3RhdGljIE1pblN0YWtlID0gMSAvIE51bWJlcihNZXRlb3Iuc2V0dGluZ3MucHVibGljLnN0YWtpbmdGcmFjdGlvbik7XG5cblx0Y29uc3RydWN0b3IoYW1vdW50LCBkZW5vbT1udWxsKSB7XG5cdFx0aWYgKHR5cGVvZiBhbW91bnQgPT09ICdvYmplY3QnKVxuXHRcdFx0KHthbW91bnQsIGRlbm9tfSA9IGFtb3VudClcblx0XHRpZiAoIWRlbm9tIHx8IGRlbm9tLnRvTG93ZXJDYXNlKCkgPT09IENvaW4uTWludGluZ0Rlbm9tLnRvTG93ZXJDYXNlKCkpIHtcblx0XHRcdHRoaXMuX2Ftb3VudCA9IE51bWJlcihhbW91bnQpO1xuXHRcdH0gZWxzZSBpZiAoZGVub20udG9Mb3dlckNhc2UoKSA9PT0gQ29pbi5TdGFraW5nRGVub20udG9Mb3dlckNhc2UoKSkge1xuXHRcdFx0dGhpcy5fYW1vdW50ID0gTnVtYmVyKGFtb3VudCkgKiBDb2luLlN0YWtpbmdGcmFjdGlvbjtcblx0XHR9XG5cdFx0ZWxzZSB7XG5cdFx0XHR0aHJvdyBFcnJvcihgdW5zdXBwb3J0ZWQgZGVub20gJHtkZW5vbX1gKTtcblx0XHR9XG5cdH1cblxuXHRnZXQgYW1vdW50ICgpIHtcblx0XHRyZXR1cm4gdGhpcy5fYW1vdW50O1xuXHR9XG5cblx0Z2V0IHN0YWtpbmdBbW91bnQgKCkge1xuXHRcdHJldHVybiB0aGlzLl9hbW91bnQgLyBDb2luLlN0YWtpbmdGcmFjdGlvbjtcblx0fVxuXG5cdHRvU3RyaW5nIChwcmVjaXNpb24pIHtcblx0XHQvLyBkZWZhdWx0IHRvIGRpc3BsYXkgaW4gbWludCBkZW5vbSBpZiBpdCBoYXMgbW9yZSB0aGFuIDQgZGVjaW1hbCBwbGFjZXNcblx0XHRsZXQgbWluU3Rha2UgPSBDb2luLlN0YWtpbmdGcmFjdGlvbi8ocHJlY2lzaW9uP01hdGgucG93KDEwLCBwcmVjaXNpb24pOjEwMDAwKVxuXHRcdGlmICh0aGlzLmFtb3VudCA8IG1pblN0YWtlKSB7XG5cdFx0XHRyZXR1cm4gYCR7bnVtYnJvKHRoaXMuYW1vdW50KS5mb3JtYXQoJzAsMCcpfSAke0NvaW4uTWludGluZ0Rlbm9tfWA7XG5cdFx0fSBlbHNlIHtcblx0XHRcdHJldHVybiBgJHtwcmVjaXNpb24/bnVtYnJvKHRoaXMuc3Rha2luZ0Ftb3VudCkuZm9ybWF0KCcwLDAuJyArICcwJy5yZXBlYXQocHJlY2lzaW9uKSk6YXV0b2Zvcm1hdCh0aGlzLnN0YWtpbmdBbW91bnQpfSAke0NvaW4uU3Rha2luZ0Rlbm9tfWBcblx0XHR9XG5cdH1cblxuXHRtaW50U3RyaW5nIChmb3JtYXR0ZXIpIHtcblx0XHRsZXQgYW1vdW50ID0gdGhpcy5hbW91bnRcblx0XHRpZiAoZm9ybWF0dGVyKSB7XG5cdFx0XHRhbW91bnQgPSBudW1icm8oYW1vdW50KS5mb3JtYXQoZm9ybWF0dGVyKVxuXHRcdH1cblx0XHRyZXR1cm4gYCR7YW1vdW50fSAke0NvaW4uTWludGluZ0Rlbm9tfWA7XG5cdH1cblxuXHRzdGFrZVN0cmluZyAoZm9ybWF0dGVyKSB7XG5cdFx0bGV0IGFtb3VudCA9IHRoaXMuc3Rha2luZ0Ftb3VudFxuXHRcdGlmIChmb3JtYXR0ZXIpIHtcblx0XHRcdGFtb3VudCA9IG51bWJybyhhbW91bnQpLmZvcm1hdChmb3JtYXR0ZXIpXG5cdFx0fVxuXHRcdHJldHVybiBgJHthbW91bnR9ICR7Q29pbi5TdGFraW5nRGVub219YDtcblx0fVxufSIsIi8vIFNlcnZlciBlbnRyeSBwb2ludCwgaW1wb3J0cyBhbGwgc2VydmVyIGNvZGVcblxuaW1wb3J0ICcvaW1wb3J0cy9zdGFydHVwL3NlcnZlcic7XG5pbXBvcnQgJy9pbXBvcnRzL3N0YXJ0dXAvYm90aCc7XG4vLyBpbXBvcnQgbW9tZW50IGZyb20gJ21vbWVudCc7XG4vLyBpbXBvcnQgJy9pbXBvcnRzL2FwaS9ibG9ja3MvYmxvY2tzLmpzJztcblxuU1lOQ0lORyA9IGZhbHNlO1xuQ09VTlRNSVNTRURCTE9DS1MgPSBmYWxzZTtcbkNPVU5UTUlTU0VEQkxPQ0tTU1RBVFMgPSBmYWxzZTtcblJQQyA9IE1ldGVvci5zZXR0aW5ncy5yZW1vdGUucnBjO1xuTENEID0gTWV0ZW9yLnNldHRpbmdzLnJlbW90ZS5sY2Q7XG50aW1lckJsb2NrcyA9IDA7XG50aW1lckNoYWluID0gMDtcbnRpbWVyQ29uc2Vuc3VzID0gMDtcbnRpbWVyUHJvcG9zYWwgPSAwO1xudGltZXJQcm9wb3NhbHNSZXN1bHRzID0gMDtcbnRpbWVyTWlzc2VkQmxvY2sgPSAwO1xudGltZXJEZWxlZ2F0aW9uID0gMDtcbnRpbWVyQWdncmVnYXRlID0gMDtcblxuY29uc3QgREVGQVVMVFNFVFRJTkdTID0gJy9kZWZhdWx0X3NldHRpbmdzLmpzb24nO1xuXG51cGRhdGVDaGFpblN0YXR1cyA9ICgpID0+IHtcbiAgICBNZXRlb3IuY2FsbCgnY2hhaW4udXBkYXRlU3RhdHVzJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidXBkYXRlU3RhdHVzOiBcIitlcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidXBkYXRlU3RhdHVzOiBcIityZXN1bHQpO1xuICAgICAgICB9XG4gICAgfSlcbn1cblxudXBkYXRlQmxvY2sgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5ibG9ja3NVcGRhdGUnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ1cGRhdGVCbG9ja3M6IFwiK2Vycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ1cGRhdGVCbG9ja3M6IFwiK3Jlc3VsdCk7XG4gICAgICAgIH1cbiAgICB9KVxufVxuXG5nZXRDb25zZW5zdXNTdGF0ZSA9ICgpID0+IHtcbiAgICBNZXRlb3IuY2FsbCgnY2hhaW4uZ2V0Q29uc2Vuc3VzU3RhdGUnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgY29uc2Vuc3VzOiBcIitlcnJvcilcbiAgICAgICAgfVxuICAgIH0pXG59XG5cbmdldFB1cmNoYXNlT3JkZXJzID0gKCkgPT4ge1xuICAgTWV0ZW9yLmNhbGwoJ2VudGVycHJpc2UuZ2V0UHVyY2hhc2VPcmRlcnMnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IHBvOiBcIisgZXJyb3IpO1xuICAgICAgIH1cbiAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgcG86IFwiK3Jlc3VsdCk7XG4gICAgICAgfVxuICAgfSk7XG59XG5cbi8vZ2V0UHJvcG9zYWxzID0gKCkgPT4ge1xuLy8gICAgTWV0ZW9yLmNhbGwoJ3Byb3Bvc2Fscy5nZXRQcm9wb3NhbHMnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuLy8gICAgICAgIGlmIChlcnJvcil7XG4vLyAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IHByb3Bvc2FsOiBcIisgZXJyb3IpO1xuLy8gICAgICAgIH1cbi8vICAgICAgICBpZiAocmVzdWx0KXtcbi8vICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgcHJvcG9zYWw6IFwiK3Jlc3VsdCk7XG4vLyAgICAgICAgfVxuLy8gICAgfSk7XG4vL31cbi8vXG4vL2dldFByb3Bvc2Fsc1Jlc3VsdHMgPSAoKSA9PiB7XG4vLyAgICBNZXRlb3IuY2FsbCgncHJvcG9zYWxzLmdldFByb3Bvc2FsUmVzdWx0cycsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4vLyAgICAgICAgaWYgKGVycm9yKXtcbi8vICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgcHJvcG9zYWxzIHJlc3VsdDogXCIrZXJyb3IpO1xuLy8gICAgICAgIH1cbi8vICAgICAgICBpZiAocmVzdWx0KXtcbi8vICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgcHJvcG9zYWxzIHJlc3VsdDogXCIrcmVzdWx0KTtcbi8vICAgICAgICB9XG4vLyAgICB9KTtcbi8vfVxuXG51cGRhdGVNaXNzZWRCbG9ja3MgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwoJ1ZhbGlkYXRvclJlY29yZHMuY2FsY3VsYXRlTWlzc2VkQmxvY2tzJywgKGVycm9yLCByZXN1bHQpID0+e1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJtaXNzZWQgYmxvY2tzIGVycm9yOiBcIisgZXJyb3IpXG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIm1pc3NlZCBibG9ja3Mgb2s6XCIgKyByZXN1bHQpO1xuICAgICAgICB9XG4gICAgfSk7XG4vKlxuICAgIE1ldGVvci5jYWxsKCdWYWxpZGF0b3JSZWNvcmRzLmNhbGN1bGF0ZU1pc3NlZEJsb2Nrc1N0YXRzJywgKGVycm9yLCByZXN1bHQpID0+e1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJtaXNzZWQgYmxvY2tzIHN0YXRzIGVycm9yOiBcIisgZXJyb3IpXG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIm1pc3NlZCBibG9ja3Mgc3RhdHMgb2s6XCIgKyByZXN1bHQpO1xuICAgICAgICB9XG4gICAgfSk7XG4qL1xufVxuXG5nZXREZWxlZ2F0aW9ucyA9ICgpID0+IHtcbiAgICBNZXRlb3IuY2FsbCgnZGVsZWdhdGlvbnMuZ2V0RGVsZWdhdGlvbnMnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgZGVsZWdhdGlvbnMgZXJyb3I6IFwiKyBlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgZGVsZWdhdGlvbnMgb2s6IFwiKyByZXN1bHQpXG4gICAgICAgIH1cbiAgICB9KTtcbn1cblxuYWdncmVnYXRlTWludXRlbHkgPSAoKSA9PntcbiAgICAvLyBkb2luZyBzb21ldGhpbmcgZXZlcnkgbWluXG4gICAgTWV0ZW9yLmNhbGwoJ0FuYWx5dGljcy5hZ2dyZWdhdGVCbG9ja1RpbWVBbmRWb3RpbmdQb3dlcicsIFwibVwiLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgbWludXRlbHkgYmxvY2sgdGltZSBlcnJvcjogXCIrZXJyb3IpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRlIG1pbnV0ZWx5IGJsb2NrIHRpbWUgb2s6IFwiK3Jlc3VsdClcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgTWV0ZW9yLmNhbGwoJ2NvaW5TdGF0cy5nZXRDb2luU3RhdHMnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgY29pbiBzdGF0cyBlcnJvcjogXCIrZXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBjb2luIHN0YXRzIG9rOiBcIityZXN1bHQpXG4gICAgICAgIH1cbiAgICB9KTtcbn1cblxuYWdncmVnYXRlSG91cmx5ID0gKCkgPT57XG4gICAgLy8gZG9pbmcgc29tZXRoaW5nIGV2ZXJ5IGhvdXJcbiAgICBNZXRlb3IuY2FsbCgnQW5hbHl0aWNzLmFnZ3JlZ2F0ZUJsb2NrVGltZUFuZFZvdGluZ1Bvd2VyJywgXCJoXCIsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSBob3VybHkgYmxvY2sgdGltZSBlcnJvcjogXCIrZXJyb3IpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRlIGhvdXJseSBibG9jayB0aW1lIG9rOiBcIityZXN1bHQpXG4gICAgICAgIH1cbiAgICB9KTtcbn1cblxuYWdncmVnYXRlRGFpbHkgPSAoKSA9PntcbiAgICAvLyBkb2luZyBzb210aGluZyBldmVyeSBkYXlcbiAgICBNZXRlb3IuY2FsbCgnQW5hbHl0aWNzLmFnZ3JlZ2F0ZUJsb2NrVGltZUFuZFZvdGluZ1Bvd2VyJywgXCJkXCIsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSBkYWlseSBibG9jayB0aW1lIGVycm9yOiBcIitlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgZGFpbHkgYmxvY2sgdGltZSBvazogXCIrcmVzdWx0KVxuICAgICAgICB9XG4gICAgfSk7XG5cbiAgICBNZXRlb3IuY2FsbCgnQW5hbHl0aWNzLmFnZ3JlZ2F0ZVZhbGlkYXRvckRhaWx5QmxvY2tUaW1lJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRlIHZhbGlkYXRvcnMgYmxvY2sgdGltZSBlcnJvcjpcIisgZXJyb3IpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSB2YWxpZGF0b3JzIGJsb2NrIHRpbWUgb2s6XCIrIHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICB9KVxufVxuXG5cblxuTWV0ZW9yLnN0YXJ0dXAoZnVuY3Rpb24oKXtcbiAgICBpZiAoTWV0ZW9yLmlzRGV2ZWxvcG1lbnQpe1xuICAgICAgICBwcm9jZXNzLmVudi5OT0RFX1RMU19SRUpFQ1RfVU5BVVRIT1JJWkVEID0gMDtcbiAgICAgICAgaW1wb3J0IERFRkFVTFRTRVRUSU5HU0pTT04gZnJvbSAnLi4vZGVmYXVsdF9zZXR0aW5ncy5qc29uJ1xuICAgICAgICBPYmplY3Qua2V5cyhERUZBVUxUU0VUVElOR1NKU09OKS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgICAgICAgIGlmIChNZXRlb3Iuc2V0dGluZ3Nba2V5XSA9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYENIRUNLIFNFVFRJTkdTIEpTT046ICR7a2V5fSBpcyBtaXNzaW5nIGZyb20gc2V0dGluZ3NgKVxuICAgICAgICAgICAgICAgIE1ldGVvci5zZXR0aW5nc1trZXldID0ge307XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBPYmplY3Qua2V5cyhERUZBVUxUU0VUVElOR1NKU09OW2tleV0pLmZvckVhY2goKHBhcmFtKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKE1ldGVvci5zZXR0aW5nc1trZXldW3BhcmFtXSA9PSB1bmRlZmluZWQpe1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYENIRUNLIFNFVFRJTkdTIEpTT046ICR7a2V5fS4ke3BhcmFtfSBpcyBtaXNzaW5nIGZyb20gc2V0dGluZ3NgKVxuICAgICAgICAgICAgICAgICAgICBNZXRlb3Iuc2V0dGluZ3Nba2V5XVtwYXJhbV0gPSBERUZBVUxUU0VUVElOR1NKU09OW2tleV1bcGFyYW1dXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSlcbiAgICAgICAgfSlcbiAgICB9XG5cbiAgICBNZXRlb3IuY2FsbCgnY2hhaW4uZ2VuZXNpcycsIChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgICBpZiAoTWV0ZW9yLnNldHRpbmdzLmRlYnVnLnN0YXJ0VGltZXIpe1xuICAgICAgICAgICAgICAgIHRpbWVyQ29uc2Vuc3VzID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgIGdldENvbnNlbnN1c1N0YXRlKCk7XG4gICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5jb25zZW5zdXNJbnRlcnZhbCk7XG5cbiAgICAgICAgICAgICAgICB0aW1lckJsb2NrcyA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVCbG9jaygpO1xuICAgICAgICAgICAgICAgIH0sIE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuYmxvY2tJbnRlcnZhbCk7XG5cbiAgICAgICAgICAgICAgICB0aW1lckNoYWluID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZUNoYWluU3RhdHVzKCk7XG4gICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGF0dXNJbnRlcnZhbCk7XG5cbiAgICAgICAgICAgICAgICB0aW1lclB1cmNoYXNlT3JkZXIgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgICBnZXRQdXJjaGFzZU9yZGVycygpO1xuICAgICAgICAgICAgICAgIH0sIE1ldGVvci5zZXR0aW5ncy5wYXJhbXMucHJvcG9zYWxJbnRlcnZhbCk7XG5cbi8vICAgICAgICAgICAgICAgIHRpbWVyUHJvcG9zYWwgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKXtcbi8vICAgICAgICAgICAgICAgICAgICBnZXRQcm9wb3NhbHMoKTtcbi8vICAgICAgICAgICAgICAgIH0sIE1ldGVvci5zZXR0aW5ncy5wYXJhbXMucHJvcG9zYWxJbnRlcnZhbCk7XG4vL1xuLy8gICAgICAgICAgICAgICAgdGltZXJQcm9wb3NhbHNSZXN1bHRzID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCl7XG4vLyAgICAgICAgICAgICAgICAgICAgZ2V0UHJvcG9zYWxzUmVzdWx0cygpO1xuLy8gICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5wcm9wb3NhbEludGVydmFsKTtcblxuICAgICAgICAgICAgICAgIHRpbWVyTWlzc2VkQmxvY2sgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlTWlzc2VkQmxvY2tzKCk7XG4gICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5taXNzZWRCbG9ja3NJbnRlcnZhbCk7XG5cbiAgICAgICAgICAgICAgICB0aW1lckRlbGVnYXRpb24gPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAgICAgZ2V0RGVsZWdhdGlvbnMoKTtcbiAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLmRlbGVnYXRpb25JbnRlcnZhbCk7XG5cbiAgICAgICAgICAgICAgICB0aW1lckFnZ3JlZ2F0ZSA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgICAgICBsZXQgbm93ID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKChub3cuZ2V0VVRDU2Vjb25kcygpID09IDApKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFnZ3JlZ2F0ZU1pbnV0ZWx5KCk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBpZiAoKG5vdy5nZXRVVENNaW51dGVzKCkgPT0gMCkgJiYgKG5vdy5nZXRVVENTZWNvbmRzKCkgPT0gMCkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgYWdncmVnYXRlSG91cmx5KCk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBpZiAoKG5vdy5nZXRVVENIb3VycygpID09IDApICYmIChub3cuZ2V0VVRDTWludXRlcygpID09IDApICYmIChub3cuZ2V0VVRDU2Vjb25kcygpID09IDApKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFnZ3JlZ2F0ZURhaWx5KCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LCAxMDAwKVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSlcblxufSk7XG4iXX0=
