var require = meteorInstall({"imports":{"api":{"accounts":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/accounts/server/methods.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Validators;
module.link("/imports/api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);

const fetchFromUrl = url => {
  try {
    let res = HTTP.get(LCD + url);

    if (res.statusCode == 200) {
      return res;
    }

    ;
  } catch (e) {
    console.log(e);
  }
};

Meteor.methods({
  'accounts.getAccountDetail': function (address) {
    this.unblock();
    let url = LCD + '/auth/accounts/' + address;

    try {
      let available = HTTP.get(url);

      if (available.statusCode == 200) {
        let response = JSON.parse(available.content).result;
        let account;
        if (response.type === 'cosmos-sdk/Account') account = response.value;else if (response.type === 'cosmos-sdk/DelayedVestingAccount' || response.type === 'cosmos-sdk/ContinuousVestingAccount') account = response.value.BaseVestingAccount.BaseAccount;
        if (account && account.account_number != null) return account;
        return null;
      }
    } catch (e) {
      console.log(e);
    }
  },
  'accounts.getBalance': function (address) {
    this.unblock();
    let balance = {}; // get available atoms

    let url = LCD + '/bank/balances/' + address;

    try {
      let available = HTTP.get(url);

      if (available.statusCode == 200) {
        // console.log(JSON.parse(available.content))
        balance.available = JSON.parse(available.content).result;
        if (balance.available && balance.available.length > 0) balance.available = balance.available[0];
      }
    } catch (e) {
      console.log(e);
    } // get delegated amnounts


    url = LCD + '/staking/delegators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        balance.delegations = JSON.parse(delegations.content).result;
      }
    } catch (e) {
      console.log(e);
    } // get unbonding


    url = LCD + '/staking/delegators/' + address + '/unbonding_delegations';

    try {
      let unbonding = HTTP.get(url);

      if (unbonding.statusCode == 200) {
        balance.unbonding = JSON.parse(unbonding.content).result;
      }
    } catch (e) {
      console.log(e);
    } // get rewards


    url = LCD + '/distribution/delegators/' + address + '/rewards';

    try {
      let rewards = HTTP.get(url);

      if (rewards.statusCode == 200) {
        balance.rewards = JSON.parse(rewards.content).result.total;
      }
    } catch (e) {
      console.log(e);
    } // get commission


    let validator = Validators.findOne({
      $or: [{
        operator_address: address
      }, {
        delegator_address: address
      }, {
        address: address
      }]
    });

    if (validator) {
      let url = LCD + '/distribution/validators/' + validator.operator_address;
      balance.operator_address = validator.operator_address;

      try {
        let rewards = HTTP.get(url);

        if (rewards.statusCode == 200) {
          let content = JSON.parse(rewards.content).result;
          if (content.val_commission && content.val_commission.length > 0) balance.commission = content.val_commission[0];
        }
      } catch (e) {
        console.log(e);
      }
    }

    return balance;
  },

  'accounts.getDelegation'(address, validator) {
    let url = "/staking/delegators/".concat(address, "/delegations/").concat(validator);
    let delegations = fetchFromUrl(url);
    delegations = delegations && delegations.data.result;
    if (delegations && delegations.shares) delegations.shares = parseFloat(delegations.shares);
    url = "/staking/redelegations?delegator=".concat(address, "&validator_to=").concat(validator);
    let relegations = fetchFromUrl(url);
    relegations = relegations && relegations.data.result;
    let completionTime;

    if (relegations) {
      relegations.forEach(relegation => {
        let entries = relegation.entries;
        let time = new Date(entries[entries.length - 1].completion_time);
        if (!completionTime || time > completionTime) completionTime = time;
      });
      delegations.redelegationCompletionTime = completionTime;
    }

    url = "/staking/delegators/".concat(address, "/unbonding_delegations/").concat(validator);
    let undelegations = fetchFromUrl(url);
    undelegations = undelegations && undelegations.data.result;

    if (undelegations) {
      delegations.unbonding = undelegations.entries.length;
      delegations.unbondingCompletionTime = undelegations.entries[0].completion_time;
    }

    return delegations;
  },

  'accounts.getAllDelegations'(address) {
    let url = LCD + '/staking/delegators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        delegations = JSON.parse(delegations.content).result;

        if (delegations && delegations.length > 0) {
          delegations.forEach((delegation, i) => {
            if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
          });
        }

        return delegations;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  },

  'accounts.getAllUnbondings'(address) {
    let url = LCD + '/staking/delegators/' + address + '/unbonding_delegations';

    try {
      let unbondings = HTTP.get(url);

      if (unbondings.statusCode == 200) {
        unbondings = JSON.parse(unbondings.content).result;
        return unbondings;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  },

  'accounts.getAllRedelegations'(address, validator) {
    let url = "/staking/redelegations?delegator=".concat(address, "&validator_from=").concat(validator);
    let result = fetchFromUrl(url);

    if (result && result.data) {
      let redelegations = {};
      result.data.forEach(redelegation => {
        let entries = redelegation.entries;
        redelegations[redelegation.validator_dst_address] = {
          count: entries.length,
          completionTime: entries[0].completion_time
        };
      });
      return redelegations;
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"blocks":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/server/methods.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Promise;
module.link("meteor/promise", {
  Promise(v) {
    Promise = v;
  }

}, 2);
let Blockscon;
module.link("/imports/api/blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 3);
let Chain;
module.link("/imports/api/chain/chain.js", {
  Chain(v) {
    Chain = v;
  }

}, 4);
let ValidatorSets;
module.link("/imports/api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 5);
let Validators;
module.link("/imports/api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 6);
let ValidatorRecords, Analytics, VPDistributions;
module.link("/imports/api/records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  VPDistributions(v) {
    VPDistributions = v;
  }

}, 7);
let VotingPowerHistory;
module.link("/imports/api/voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 8);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 9);
let Evidences;
module.link("../../evidences/evidences.js", {
  Evidences(v) {
    Evidences = v;
  }

}, 10);
let sha256;
module.link("js-sha256", {
  sha256(v) {
    sha256 = v;
  }

}, 11);
let getAddress;
module.link("tendermint/lib/pubkey", {
  getAddress(v) {
    getAddress = v;
  }

}, 12);
let cheerio;
module.link("cheerio", {
  "*"(v) {
    cheerio = v;
  }

}, 13);

// import Block from '../../../ui/components/Block';
// getValidatorVotingPower = (validators, address) => {
//     for (v in validators){
//         if (validators[v].address == address){
//             return parseInt(validators[v].voting_power);
//         }
//     }
// }
getRemovedValidators = (prevValidators, validators) => {
  // let removeValidators = [];
  for (p in prevValidators) {
    for (v in validators) {
      if (prevValidators[p].address == validators[v].address) {
        prevValidators.splice(p, 1);
      }
    }
  }

  return prevValidators;
};

getValidatorProfileUrl = identity => {
  if (identity.length == 16) {
    let response = HTTP.get("https://keybase.io/_/api/1.0/user/lookup.json?key_suffix=".concat(identity, "&fields=pictures"));

    if (response.statusCode == 200) {
      let them = response.data.them;
      return them && them.length && them[0].pictures && them[0].pictures.primary && them[0].pictures.primary.url;
    } else {
      console.log(JSON.stringify(response));
    }
  } else if (identity.indexOf("keybase.io/team/") > 0) {
    let teamPage = HTTP.get(identity);

    if (teamPage.statusCode == 200) {
      let page = cheerio.load(teamPage.content);
      return page(".kb-main-card img").attr('src');
    } else {
      console.log(JSON.stringify(teamPage));
    }
  }
}; // var filtered = [1, 2, 3, 4, 5].filter(notContainedIn([1, 2, 3, 5]));
// console.log(filtered); // [4]


Meteor.methods({
  'blocks.averageBlockTime'(address) {
    let blocks = Blockscon.find({
      proposerAddress: address
    }).fetch();
    let heights = blocks.map((block, i) => {
      return block.height;
    });
    let blocksStats = Analytics.find({
      height: {
        $in: heights
      }
    }).fetch(); // console.log(blocksStats);

    let totalBlockDiff = 0;

    for (b in blocksStats) {
      totalBlockDiff += blocksStats[b].timeDiff;
    }

    return totalBlockDiff / heights.length;
  },

  'blocks.findUpTime'(address) {
    let collection = ValidatorRecords.rawCollection(); // let aggregateQuery = Meteor.wrapAsync(collection.aggregate, collection);

    var pipeline = [{
      $match: {
        "address": address
      }
    }, // {$project:{address:1,height:1,exists:1}},
    {
      $sort: {
        "height": -1
      }
    }, {
      $limit: Meteor.settings.public.uptimeWindow - 1
    }, {
      $unwind: "$_id"
    }, {
      $group: {
        "_id": "$address",
        "uptime": {
          "$sum": {
            $cond: [{
              $eq: ['$exists', true]
            }, 1, 0]
          }
        }
      }
    }]; // let result = aggregateQuery(pipeline, { cursor: {} });

    return Promise.await(collection.aggregate(pipeline).toArray()); // return .aggregate()
  },

  'blocks.getLatestHeight': function () {
    this.unblock();
    let url = RPC + '/status';

    try {
      let response = HTTP.get(url);
      let status = JSON.parse(response.content);
      return status.result.sync_info.latest_block_height;
    } catch (e) {
      return 0;
    }
  },
  'blocks.getCurrentHeight': function () {
    this.unblock();
    let currHeight = Blockscon.find({}, {
      sort: {
        height: -1
      },
      limit: 1
    }).fetch(); // console.log("currentHeight:"+currHeight);

    let startHeight = Meteor.settings.params.startHeight;

    if (currHeight && currHeight.length == 1) {
      let height = currHeight[0].height;
      if (height > startHeight) return height;
    }

    return startHeight;
  },
  'blocks.blocksUpdate': function () {
    if (SYNCING) return "Syncing...";else console.log("start to sync"); // Meteor.clearInterval(Meteor.timerHandle);
    // get the latest height

    let until = Meteor.call('blocks.getLatestHeight'); // console.log(until);
    // get the current height in db

    let curr = Meteor.call('blocks.getCurrentHeight');
    console.log(curr); // loop if there's update in db

    if (until > curr) {
      SYNCING = true;
      let validatorSet = {}; // get latest validator candidate information

      url = LCD + '/staking/validators';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      url = LCD + '/staking/validators?status=unbonding';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      url = LCD + '/staking/validators?status=unbonded';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      let totalValidators = Object.keys(validatorSet).length;
      console.log("all validators: " + totalValidators);

      for (let height = curr + 1; height <= until; height++) {
        let startBlockTime = new Date(); // add timeout here? and outside this loop (for catched up and keep fetching)?

        this.unblock();
        let url = RPC + '/block?height=' + height;
        let analyticsData = {};
        console.log(url);

        try {
          const bulkValidators = Validators.rawCollection().initializeUnorderedBulkOp();
          const bulkValidatorRecords = ValidatorRecords.rawCollection().initializeUnorderedBulkOp();
          const bulkVPHistory = VotingPowerHistory.rawCollection().initializeUnorderedBulkOp();
          const bulkTransations = Transactions.rawCollection().initializeUnorderedBulkOp();
          let startGetHeightTime = new Date();
          let response = HTTP.get(url);

          if (response.statusCode == 200) {
            let block = JSON.parse(response.content);
            block = block.result; // store height, hash, numtransaction and time in db

            let blockData = {};
            blockData.height = height;
            blockData.hash = block.block_id.hash;
            blockData.transNum = block.block.data.txs === null ? 0 : block.block.data.txs.length;
            blockData.time = new Date(block.block.header.time);
            blockData.lastBlockHash = block.block.header.last_block_id.hash;
            blockData.proposerAddress = block.block.header.proposer_address;
            blockData.validators = [];
            let precommits = block.block.last_commit.signatures;

            if (precommits != null) {
              // console.log(precommits.length);
              for (let i = 0; i < precommits.length; i++) {
                if (precommits[i] != null) {
                  blockData.validators.push(precommits[i].validator_address);
                }
              }

              analyticsData.precommits = precommits.length; // record for analytics
              // PrecommitRecords.insert({height:height, precommits:precommits.length});
            } // save txs in database


            if (block.block.data.txs && block.block.data.txs.length > 0) {
              for (t in block.block.data.txs) {
                Meteor.call('Transactions.index', sha256(Buffer.from(block.block.data.txs[t], 'base64')), blockData.time, (err, result) => {
                  if (err) {
                    console.log(err);
                  }
                });
              }
            } // save double sign evidences


            if (block.block.evidence.evidence) {
              Evidences.insert({
                height: height,
                evidence: block.block.evidence.evidence
              });
            }

            blockData.precommitsCount = blockData.validators.length;
            analyticsData.height = height;
            let endGetHeightTime = new Date();
            console.log("Get height time: " + (endGetHeightTime - startGetHeightTime) / 1000 + "seconds.");
            let startGetValidatorsTime = new Date(); // update chain status

            url = RPC + '/validators?height=' + height;
            response = HTTP.get(url);
            console.log(url);
            let validators = JSON.parse(response.content);
            validators.result.block_height = parseInt(validators.result.block_height);
            ValidatorSets.insert(validators.result);
            blockData.validatorsCount = validators.result.validators.length;
            let startBlockInsertTime = new Date();
            Blockscon.insert(blockData);
            let endBlockInsertTime = new Date();
            console.log("Block insert time: " + (endBlockInsertTime - startBlockInsertTime) / 1000 + "seconds."); // store valdiators exist records

            let existingValidators = Validators.find({
              address: {
                $exists: true
              }
            }).fetch();

            if (height > 1) {
              // record precommits and calculate uptime
              // only record from block 2
              for (i in validators.result.validators) {
                let address = validators.result.validators[i].address;
                let record = {
                  height: height,
                  address: address,
                  exists: false,
                  voting_power: parseInt(validators.result.validators[i].voting_power) //getValidatorVotingPower(existingValidators, address)

                };

                for (j in precommits) {
                  if (precommits[j] != null) {
                    if (address == precommits[j].validator_address) {
                      record.exists = true;
                      precommits.splice(j, 1);
                      break;
                    }
                  }
                } // calculate the uptime based on the records stored in previous blocks
                // only do this every 15 blocks ~


                if (height % 15 == 0) {
                  // let startAggTime = new Date();
                  let numBlocks = Meteor.call('blocks.findUpTime', address);
                  let uptime = 0; // let endAggTime = new Date();
                  // console.log("Get aggregated uptime for "+existingValidators[i].address+": "+((endAggTime-startAggTime)/1000)+"seconds.");

                  if (numBlocks[0] != null && numBlocks[0].uptime != null) {
                    uptime = numBlocks[0].uptime;
                  }

                  let base = Meteor.settings.public.uptimeWindow;

                  if (height < base) {
                    base = height;
                  }

                  if (record.exists) {
                    if (uptime < base) {
                      uptime++;
                    }

                    uptime = uptime / base * 100;
                    bulkValidators.find({
                      address: address
                    }).upsert().updateOne({
                      $set: {
                        uptime: uptime,
                        lastSeen: blockData.time
                      }
                    });
                  } else {
                    uptime = uptime / base * 100;
                    bulkValidators.find({
                      address: address
                    }).upsert().updateOne({
                      $set: {
                        uptime: uptime
                      }
                    });
                  }
                }

                bulkValidatorRecords.insert(record); // ValidatorRecords.update({height:height,address:record.address},record);
              }
            }

            let chainStatus = Chain.findOne({
              chainId: block.block.header.chain_id
            });
            let lastSyncedTime = chainStatus ? chainStatus.lastSyncedTime : 0;
            let timeDiff;
            let blockTime = Meteor.settings.params.defaultBlockTime;

            if (lastSyncedTime) {
              let dateLatest = blockData.time;
              let dateLast = new Date(lastSyncedTime);
              timeDiff = Math.abs(dateLatest.getTime() - dateLast.getTime()); // disregard first couple of blocks to avoid high avg time due to genesis date

              if (blockData.height > 2) {
                blockTime = (chainStatus.blockTime * (blockData.height - 1) + timeDiff) / blockData.height;
              }
            }

            let endGetValidatorsTime = new Date();
            console.log("Get height validators time: " + (endGetValidatorsTime - startGetValidatorsTime) / 1000 + "seconds.");
            Chain.update({
              chainId: block.block.header.chain_id
            }, {
              $set: {
                lastSyncedTime: blockData.time,
                blockTime: blockTime
              }
            });
            analyticsData.averageBlockTime = blockTime;
            analyticsData.timeDiff = timeDiff;
            analyticsData.time = blockData.time; // initialize validator data at first block
            // if (height == 1){
            //     Validators.remove({});
            // }

            analyticsData.voting_power = 0;
            let startFindValidatorsNameTime = new Date();

            if (validators.result) {
              // validators are all the validators in the current height
              console.log("validatorSet size: " + validators.result.validators.length);

              for (v in validators.result.validators) {
                // Validators.insert(validators.result.validators[v]);
                let validator = validators.result.validators[v];
                validator.voting_power = parseInt(validator.voting_power);
                validator.proposer_priority = parseInt(validator.proposer_priority);
                let valExist = Validators.findOne({
                  "pub_key.value": validator.pub_key.value
                });

                if (!valExist) {
                  console.log("validator pub_key ".concat(validator.address, " ").concat(validator.pub_key.value, " not in db")); // let command = Meteor.settings.bin.gaiadebug+" pubkey "+validator.pub_key.value;
                  // console.log(command);
                  // let tempVal = validator;

                  validator.address = getAddress(validator.pub_key);
                  validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
                  validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
                  validator.consensus_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixConsPub);
                  let validatorData = validatorSet[validator.consensus_pubkey];

                  if (validatorData) {
                    if (validatorData.description.identity) validator.profile_url = getValidatorProfileUrl(validatorData.description.identity);
                    validator.operator_address = validatorData.operator_address;
                    validator.delegator_address = Meteor.call('getDelegator', validatorData.operator_address);
                    validator.jailed = validatorData.jailed;
                    validator.status = validatorData.status;
                    validator.min_self_delegation = validatorData.min_self_delegation;
                    validator.tokens = validatorData.tokens;
                    validator.delegator_shares = validatorData.delegator_shares;
                    validator.description = validatorData.description;
                    validator.bond_height = validatorData.bond_height;
                    validator.bond_intra_tx_counter = validatorData.bond_intra_tx_counter;
                    validator.unbonding_height = validatorData.unbonding_height;
                    validator.unbonding_time = validatorData.unbonding_time;
                    validator.commission = validatorData.commission;
                    validator.self_delegation = validator.delegator_shares; // validator.removed = false,
                    // validator.removedAt = 0
                    // validatorSet.splice(val, 1);
                  } else {
                    console.log('no con pub key?');
                  } // bulkValidators.insert(validator);


                  bulkValidators.find({
                    consensus_pubkey: validator.consensus_pubkey
                  }).upsert().updateOne({
                    $set: validator
                  }); // console.log("validator first appears: "+bulkValidators.length);

                  bulkVPHistory.insert({
                    address: validator.address,
                    prev_voting_power: 0,
                    voting_power: validator.voting_power,
                    type: 'add',
                    height: blockData.height,
                    block_time: blockData.time
                  }); // Meteor.call('runCode', command, function(error, result){
                  // validator.address = result.match(/\s[0-9A-F]{40}$/igm);
                  // validator.address = validator.address[0].trim();
                  // validator.hex = result.match(/\s[0-9A-F]{64}$/igm);
                  // validator.hex = validator.hex[0].trim();
                  // validator.cosmosaccpub = result.match(/cosmospub.*$/igm);
                  // validator.cosmosaccpub = validator.cosmosaccpub[0].trim();
                  // validator.operator_pubkey = result.match(/cosmosvaloperpub.*$/igm);
                  // validator.operator_pubkey = validator.operator_pubkey[0].trim();
                  // validator.consensus_pubkey = result.match(/cosmosvalconspub.*$/igm);
                  // validator.consensus_pubkey = validator.consensus_pubkey[0].trim();
                  // });
                } else {
                  let validatorData = validatorSet[valExist.consensus_pubkey];

                  if (validatorData) {
                    if (validatorData.description && (!valExist.description || validatorData.description.identity !== valExist.description.identity)) validator.profile_url = getValidatorProfileUrl(validatorData.description.identity);
                    validator.jailed = validatorData.jailed;
                    validator.status = validatorData.status;
                    validator.tokens = validatorData.tokens;
                    validator.delegator_shares = validatorData.delegator_shares;
                    validator.description = validatorData.description;
                    validator.bond_height = validatorData.bond_height;
                    validator.bond_intra_tx_counter = validatorData.bond_intra_tx_counter;
                    validator.unbonding_height = validatorData.unbonding_height;
                    validator.unbonding_time = validatorData.unbonding_time;
                    validator.commission = validatorData.commission; // calculate self delegation percentage every 30 blocks

                    if (height % 30 == 1) {
                      try {
                        let response = HTTP.get(LCD + '/staking/delegators/' + valExist.delegator_address + '/delegations/' + valExist.operator_address);

                        if (response.statusCode == 200) {
                          let selfDelegation = JSON.parse(response.content).result;

                          if (selfDelegation.shares) {
                            validator.self_delegation = parseFloat(selfDelegation.shares) / parseFloat(validator.delegator_shares);
                          }
                        }
                      } catch (e) {// console.log(e);
                      }
                    }

                    bulkValidators.find({
                      consensus_pubkey: valExist.consensus_pubkey
                    }).updateOne({
                      $set: validator
                    }); // console.log("validator exisits: "+bulkValidators.length);
                    // validatorSet.splice(val, 1);
                  } else {
                    console.log('no con pub key?');
                  }

                  let prevVotingPower = VotingPowerHistory.findOne({
                    address: validator.address
                  }, {
                    height: -1,
                    limit: 1
                  });

                  if (prevVotingPower) {
                    if (prevVotingPower.voting_power != validator.voting_power) {
                      let changeType = prevVotingPower.voting_power > validator.voting_power ? 'down' : 'up';
                      let changeData = {
                        address: validator.address,
                        prev_voting_power: prevVotingPower.voting_power,
                        voting_power: validator.voting_power,
                        type: changeType,
                        height: blockData.height,
                        block_time: blockData.time
                      }; // console.log('voting power changed.');
                      // console.log(changeData);

                      bulkVPHistory.insert(changeData);
                    }
                  }
                } // console.log(validator);


                analyticsData.voting_power += validator.voting_power;
              } // if there is validator removed


              let prevValidators = ValidatorSets.findOne({
                block_height: height - 1
              });

              if (prevValidators) {
                let removedValidators = getRemovedValidators(prevValidators.validators, validators.result.validators);

                for (r in removedValidators) {
                  bulkVPHistory.insert({
                    address: removedValidators[r].address,
                    prev_voting_power: removedValidators[r].voting_power,
                    voting_power: 0,
                    type: 'remove',
                    height: blockData.height,
                    block_time: blockData.time
                  });
                }
              }
            } // check if there's any validator not in db 14400 blocks(~1 day)


            if (height % 14400 == 0) {
              try {
                console.log('Checking all validators against db...');
                let dbValidators = {};
                Validators.find({}, {
                  fields: {
                    consensus_pubkey: 1,
                    status: 1
                  }
                }).forEach(v => dbValidators[v.consensus_pubkey] = v.status);
                Object.keys(validatorSet).forEach(conPubKey => {
                  let validatorData = validatorSet[conPubKey]; // Active validators should have been updated in previous steps

                  if (validatorData.status === 2) return;

                  if (dbValidators[conPubKey] == undefined) {
                    console.log("validator with consensus_pubkey ".concat(conPubKey, " not in db"));
                    validatorData.pub_key = {
                      "type": "tendermint/PubKeyEd25519",
                      "value": Meteor.call('bech32ToPubkey', conPubKey)
                    };
                    validatorData.address = getAddress(validatorData.pub_key);
                    validatorData.delegator_address = Meteor.call('getDelegator', validatorData.operator_address);
                    validatorData.accpub = Meteor.call('pubkeyToBech32', validatorData.pub_key, Meteor.settings.public.bech32PrefixAccPub);
                    validatorData.operator_pubkey = Meteor.call('pubkeyToBech32', validatorData.pub_key, Meteor.settings.public.bech32PrefixValPub);
                    console.log(JSON.stringify(validatorData));
                    bulkValidators.find({
                      consensus_pubkey: conPubKey
                    }).upsert().updateOne({
                      $set: validatorData
                    });
                  } else if (dbValidators[conPubKey] == 2) {
                    bulkValidators.find({
                      consensus_pubkey: conPubKey
                    }).upsert().updateOne({
                      $set: validatorData
                    });
                  }
                });
              } catch (e) {
                console.log(e);
              }
            } // fetching keybase every 14400 blocks(~1 day)


            if (height % 14400 == 1) {
              console.log('Fetching keybase...');
              Validators.find({}).forEach(validator => {
                try {
                  let profileUrl = getValidatorProfileUrl(validator.description.identity);

                  if (profileUrl) {
                    bulkValidators.find({
                      address: validator.address
                    }).upsert().updateOne({
                      $set: {
                        'profile_url': profileUrl
                      }
                    });
                  }
                } catch (e) {
                  console.log(e);
                }
              });
            }

            let endFindValidatorsNameTime = new Date();
            console.log("Get validators name time: " + (endFindValidatorsNameTime - startFindValidatorsNameTime) / 1000 + "seconds."); // record for analytics

            let startAnayticsInsertTime = new Date();
            Analytics.insert(analyticsData);
            let endAnalyticsInsertTime = new Date();
            console.log("Analytics insert time: " + (endAnalyticsInsertTime - startAnayticsInsertTime) / 1000 + "seconds.");
            let startVUpTime = new Date();

            if (bulkValidators.length > 0) {
              // console.log(bulkValidators.length);
              bulkValidators.execute((err, result) => {
                if (err) {
                  console.log(err);
                }

                if (result) {// console.log(result);
                }
              });
            }

            let endVUpTime = new Date();
            console.log("Validator update time: " + (endVUpTime - startVUpTime) / 1000 + "seconds.");
            let startVRTime = new Date();

            if (bulkValidatorRecords.length > 0) {
              bulkValidatorRecords.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            }

            let endVRTime = new Date();
            console.log("Validator records update time: " + (endVRTime - startVRTime) / 1000 + "seconds.");

            if (bulkVPHistory.length > 0) {
              bulkVPHistory.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            }

            if (bulkTransations.length > 0) {
              bulkTransations.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            } // calculate voting power distribution every 60 blocks ~ 5mins


            if (height % 60 == 1) {
              console.log("===== calculate voting power distribution =====");
              let activeValidators = Validators.find({
                status: 2,
                jailed: false
              }, {
                sort: {
                  voting_power: -1
                }
              }).fetch();
              let numTopTwenty = Math.ceil(activeValidators.length * 0.2);
              let numBottomEighty = activeValidators.length - numTopTwenty;
              let topTwentyPower = 0;
              let bottomEightyPower = 0;
              let numTopThirtyFour = 0;
              let numBottomSixtySix = 0;
              let topThirtyFourPercent = 0;
              let bottomSixtySixPercent = 0;

              for (v in activeValidators) {
                if (v < numTopTwenty) {
                  topTwentyPower += activeValidators[v].voting_power;
                } else {
                  bottomEightyPower += activeValidators[v].voting_power;
                }

                if (topThirtyFourPercent < 0.34) {
                  topThirtyFourPercent += activeValidators[v].voting_power / analyticsData.voting_power;
                  numTopThirtyFour++;
                }
              }

              bottomSixtySixPercent = 1 - topThirtyFourPercent;
              numBottomSixtySix = activeValidators.length - numTopThirtyFour;
              let vpDist = {
                height: height,
                numTopTwenty: numTopTwenty,
                topTwentyPower: topTwentyPower,
                numBottomEighty: numBottomEighty,
                bottomEightyPower: bottomEightyPower,
                numTopThirtyFour: numTopThirtyFour,
                topThirtyFourPercent: topThirtyFourPercent,
                numBottomSixtySix: numBottomSixtySix,
                bottomSixtySixPercent: bottomSixtySixPercent,
                numValidators: activeValidators.length,
                totalVotingPower: analyticsData.voting_power,
                blockTime: blockData.time,
                createAt: new Date()
              };
              console.log(vpDist);
              VPDistributions.insert(vpDist);
            }
          }
        } catch (e) {
          console.log(e);
          SYNCING = false;
          return "Stopped";
        }

        let endBlockTime = new Date();
        console.log("This block used: " + (endBlockTime - startBlockTime) / 1000 + "seconds.");
      }

      SYNCING = false;
      Chain.update({
        chainId: Meteor.settings.public.chainId
      }, {
        $set: {
          lastBlocksSyncedTime: new Date(),
          totalValidators: totalValidators
        }
      });
    }

    return until;
  },
  'addLimit': function (limit) {
    // console.log(limit+10)
    return limit + 10;
  },
  'hasMore': function (limit) {
    if (limit > Meteor.call('getCurrentHeight')) {
      return false;
    } else {
      return true;
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/server/publications.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Blockscon;
module.link("../blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 3);
publishComposite('blocks.height', function (limit) {
  return {
    find() {
      return Blockscon.find({}, {
        limit: limit,
        sort: {
          height: -1
        }
      });
    },

    children: [{
      find(block) {
        return Validators.find({
          address: block.proposerAddress
        }, {
          limit: 1
        });
      }

    }]
  };
});
publishComposite('blocks.findOne', function (height) {
  return {
    find() {
      return Blockscon.find({
        height: height
      });
    },

    children: [{
      find(block) {
        return Transactions.find({
          height: block.height
        });
      }

    }, {
      find(block) {
        return Validators.find({
          address: block.proposerAddress
        }, {
          limit: 1
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"blocks.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/blocks.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Blockscon: () => Blockscon
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const Blockscon = new Mongo.Collection('blocks');
Blockscon.helpers({
  proposer() {
    return Validators.findOne({
      address: this.proposerAddress
    });
  }

}); // Blockscon.helpers({
//     sorted(limit) {
//         return Blockscon.find({}, {sort: {height:-1}, limit: limit});
//     }
// });
// Meteor.setInterval(function() {
//     Meteor.call('blocksUpdate', (error, result) => {
//         console.log(result);
//     })
// }, 30000000);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chain":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/server/methods.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let getAddress;
module.link("tendermint/lib/pubkey.js", {
  getAddress(v) {
    getAddress = v;
  }

}, 2);
let Chain, ChainStates;
module.link("../chain.js", {
  Chain(v) {
    Chain = v;
  },

  ChainStates(v) {
    ChainStates = v;
  }

}, 3);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 4);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 5);

findVotingPower = (validator, genValidators) => {
  for (let v in genValidators) {
    if (validator.pub_key.value == genValidators[v].pub_key.value) {
      return parseInt(genValidators[v].power);
    }
  }
};

Meteor.methods({
  'chain.getConsensusState': function () {
    this.unblock();
    let url = RPC + '/dump_consensus_state';

    try {
      let response = HTTP.get(url);
      let consensus = JSON.parse(response.content);
      consensus = consensus.result;
      let height = consensus.round_state.height;
      let round = consensus.round_state.round;
      let step = consensus.round_state.step;
      let votedPower = Math.round(parseFloat(consensus.round_state.votes[round].prevotes_bit_array.split(" ")[3]) * 100);
      Chain.update({
        chainId: Meteor.settings.public.chainId
      }, {
        $set: {
          votingHeight: height,
          votingRound: round,
          votingStep: step,
          votedPower: votedPower,
          proposerAddress: consensus.round_state.validators.proposer.address,
          prevotes: consensus.round_state.votes[round].prevotes,
          precommits: consensus.round_state.votes[round].precommits
        }
      });
    } catch (e) {
      console.log(e);
    }
  },
  'chain.updateStatus': function () {
    this.unblock();
    let url = RPC + '/status';

    try {
      let response = HTTP.get(url);
      let status = JSON.parse(response.content);
      status = status.result;
      let chain = {};
      chain.chainId = status.node_info.network;
      chain.latestBlockHeight = status.sync_info.latest_block_height;
      chain.latestBlockTime = status.sync_info.latest_block_time;
      let latestState = ChainStates.findOne({}, {
        sort: {
          height: -1
        }
      });

      if (latestState && latestState.height >= chain.latestBlockHeight) {
        return "no updates (getting block ".concat(chain.latestBlockHeight, " at block ").concat(latestState.height, ")");
      }

      url = RPC + '/validators';
      response = HTTP.get(url);
      let validators = JSON.parse(response.content);
      validators = validators.result.validators;
      chain.validators = validators.length;
      let activeVP = 0;

      for (v in validators) {
        activeVP += parseInt(validators[v].voting_power);
      }

      chain.activeVotingPower = activeVP;
      Chain.update({
        chainId: chain.chainId
      }, {
        $set: chain
      }, {
        upsert: true
      }); // Get chain states

      if (parseInt(chain.latestBlockHeight) > 0) {
        let chainStates = {};
        chainStates.height = parseInt(status.sync_info.latest_block_height);
        chainStates.time = new Date(status.sync_info.latest_block_time);
        url = LCD + '/staking/pool';

        try {
          response = HTTP.get(url);
          let bonding = JSON.parse(response.content).result; // chain.bondedTokens = bonding.bonded_tokens;
          // chain.notBondedTokens = bonding.not_bonded_tokens;

          chainStates.bondedTokens = parseInt(bonding.bonded_tokens);
          chainStates.notBondedTokens = parseInt(bonding.not_bonded_tokens);
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/supply/total/' + Meteor.settings.public.mintingDenom;

        try {
          response = HTTP.get(url);
          let supply = JSON.parse(response.content).result;
          chainStates.totalSupply = parseInt(supply);
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/distribution/community_pool';

        try {
          response = HTTP.get(url);
          let pool = JSON.parse(response.content).result;

          if (pool && pool.length > 0) {
            chainStates.communityPool = [];
            pool.forEach((amount, i) => {
              chainStates.communityPool.push({
                denom: amount.denom,
                amount: parseFloat(amount.amount)
              });
            });
          }
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/minting/inflation';

        try {
          response = HTTP.get(url);
          let inflation = JSON.parse(response.content).result;

          if (inflation) {
            chainStates.inflation = parseFloat(inflation);
          }
        } catch (e) {
          console.log(e);
        }

        url = LCD + '/minting/annual-provisions';

        try {
          response = HTTP.get(url);
          let provisions = JSON.parse(response.content);

          if (provisions) {
            chainStates.annualProvisions = parseFloat(provisions.result);
          }
        } catch (e) {
          console.log(e);
        }

        ChainStates.insert(chainStates);
      } // chain.totalVotingPower = totalVP;
      // validators = Validators.find({}).fetch();
      // console.log(validators);


      return chain.latestBlockHeight;
    } catch (e) {
      console.log(e);
      return "Error getting chain status.";
    }
  },
  'chain.getLatestStatus': function () {
    Chain.find().sort({
      created: -1
    }).limit(1);
  },
  'chain.genesis': function () {
    let chain = Chain.findOne({
      chainId: Meteor.settings.public.chainId
    });

    if (chain && chain.readGenesis) {
      console.log('Genesis file has been processed');
    } else if (Meteor.settings.debug.readGenesis) {
      console.log('=== Start processing genesis file ===');
      let response = HTTP.get(Meteor.settings.genesisFile);
      let genesis = JSON.parse(response.content);
      let distr = genesis.app_state.distr || genesis.app_state.distribution;
      let chainParams = {
        chainId: genesis.chain_id,
        genesisTime: genesis.genesis_time,
        consensusParams: genesis.consensus_params,
        auth: genesis.app_state.auth,
        bank: genesis.app_state.bank,
        staking: {
          pool: genesis.app_state.staking.pool,
          params: genesis.app_state.staking.params
        },
        mint: genesis.app_state.mint,
        distr: {
          communityTax: distr.community_tax,
          baseProposerReward: distr.base_proposer_reward,
          bonusProposerReward: distr.bonus_proposer_reward,
          withdrawAddrEnabled: distr.withdraw_addr_enabled
        },
        gov: null,
        slashing: {
          params: genesis.app_state.slashing.params
        },
        supply: genesis.app_state.supply,
        crisis: genesis.app_state.crisis
      };
      let totalVotingPower = 0; // read gentx

      if (genesis.app_state.genutil && genesis.app_state.genutil.gentxs && genesis.app_state.genutil.gentxs.length > 0) {
        for (i in genesis.app_state.genutil.gentxs) {
          let msg = genesis.app_state.genutil.gentxs[i].value.msg; // console.log(msg.type);

          for (m in msg) {
            if (msg[m].type == "cosmos-sdk/MsgCreateValidator") {
              console.log(msg[m].value); // let command = Meteor.settings.bin.gaiadebug+" pubkey "+msg[m].value.pubkey;

              let validator = {
                consensus_pubkey: msg[m].value.pubkey,
                description: msg[m].value.description,
                commission: msg[m].value.commission,
                min_self_delegation: msg[m].value.min_self_delegation,
                operator_address: msg[m].value.validator_address,
                delegator_address: msg[m].value.delegator_address,
                voting_power: Math.floor(parseInt(msg[m].value.value.amount) / Meteor.settings.public.stakingFraction),
                jailed: false,
                status: 2
              };
              totalVotingPower += validator.voting_power;
              let pubkeyValue = Meteor.call('bech32ToPubkey', msg[m].value.pubkey); // Validators.upsert({consensus_pubkey:msg[m].value.pubkey},validator);

              validator.pub_key = {
                "type": "tendermint/PubKeyEd25519",
                "value": pubkeyValue
              };
              validator.address = getAddress(validator.pub_key);
              validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
              validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
              VotingPowerHistory.insert({
                address: validator.address,
                prev_voting_power: 0,
                voting_power: validator.voting_power,
                type: 'add',
                height: 0,
                block_time: genesis.genesis_time
              });
              Validators.insert(validator);
            }
          }
        }
      } // read validators from previous chain


      console.log('read validators from previous chain');

      if (genesis.app_state.staking.validators && genesis.app_state.staking.validators.length > 0) {
        console.log(genesis.app_state.staking.validators.length);
        let genValidatorsSet = genesis.app_state.staking.validators;
        let genValidators = genesis.validators;

        for (let v in genValidatorsSet) {
          // console.log(genValidators[v]);
          let validator = genValidatorsSet[v];
          validator.delegator_address = Meteor.call('getDelegator', genValidatorsSet[v].operator_address);
          let pubkeyValue = Meteor.call('bech32ToPubkey', validator.consensus_pubkey);
          validator.pub_key = {
            "type": "tendermint/PubKeyEd25519",
            "value": pubkeyValue
          };
          validator.address = getAddress(validator.pub_key);
          validator.pub_key = validator.pub_key;
          validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
          validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
          validator.voting_power = findVotingPower(validator, genValidators);
          totalVotingPower += validator.voting_power;
          Validators.upsert({
            consensus_pubkey: validator.consensus_pubkey
          }, validator);
          VotingPowerHistory.insert({
            address: validator.address,
            prev_voting_power: 0,
            voting_power: validator.voting_power,
            type: 'add',
            height: 0,
            block_time: genesis.genesis_time
          });
        }
      }

      chainParams.readGenesis = true;
      chainParams.activeVotingPower = totalVotingPower;
      let result = Chain.upsert({
        chainId: chainParams.chainId
      }, {
        $set: chainParams
      });
      console.log('=== Finished processing genesis file ===');
    }

    return true;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/server/publications.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Chain, ChainStates;
module.link("../chain.js", {
  Chain(v) {
    Chain = v;
  },

  ChainStates(v) {
    ChainStates = v;
  }

}, 1);
let CoinStats;
module.link("../../coin-stats/coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
Meteor.publish('chainStates.latest', function () {
  return [ChainStates.find({}, {
    sort: {
      height: -1
    },
    limit: 1
  }), CoinStats.find({}, {
    sort: {
      last_updated_at: -1
    },
    limit: 1
  })];
});
publishComposite('chain.status', function () {
  return {
    find() {
      return Chain.find({
        chainId: Meteor.settings.public.chainId
      });
    },

    children: [{
      find(chain) {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            operator_address: 1,
            status: -1,
            jailed: 1,
            profile_url: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chain.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/chain.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Chain: () => Chain,
  ChainStates: () => ChainStates
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const Chain = new Mongo.Collection('chain');
const ChainStates = new Mongo.Collection('chain_states');
Chain.helpers({
  proposer() {
    return Validators.findOne({
      address: this.proposerAddress
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"coin-stats":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/coin-stats/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let CoinStats;
module.link("../coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 1);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 2);
Meteor.methods({
  'coinStats.getCoinStats': function () {
    this.unblock();
    let coinId = Meteor.settings.public.coingeckoId;

    if (coinId) {
      try {
        let now = new Date();
        now.setMinutes(0);
        let url = "https://api.coingecko.com/api/v3/simple/price?ids=" + coinId + "&vs_currencies=usd&include_market_cap=true&include_24hr_vol=true&include_24hr_change=true&include_last_updated_at=true";
        let response = HTTP.get(url);

        if (response.statusCode == 200) {
          // console.log(JSON.parse(response.content));
          let data = JSON.parse(response.content);
          data = data[coinId]; // console.log(coinStats);

          return CoinStats.upsert({
            last_updated_at: data.last_updated_at
          }, {
            $set: data
          });
        }
      } catch (e) {
        console.log(e);
      }
    } else {
      return "No coingecko Id provided.";
    }
  },
  'coinStats.getStats': function () {
    this.unblock();
    let coinId = Meteor.settings.public.coingeckoId;

    if (coinId) {
      return CoinStats.findOne({}, {
        sort: {
          last_updated_at: -1
        }
      });
    } else {
      return "No coingecko Id provided.";
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"coin-stats.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/coin-stats/coin-stats.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  CoinStats: () => CoinStats
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const CoinStats = new Mongo.Collection('coin_stats');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"delegations":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/server/methods.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Delegations;
module.link("../delegations.js", {
  Delegations(v) {
    Delegations = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
Meteor.methods({
  'delegations.getDelegations': function () {
    this.unblock();
    let validators = Validators.find({}).fetch();
    let delegations = [];
    console.log("=== Getting delegations ===");

    for (v in validators) {
      if (validators[v].operator_address) {
        let url = LCD + '/staking/validators/' + validators[v].operator_address + "/delegations";

        try {
          let response = HTTP.get(url);

          if (response.statusCode == 200) {
            let delegation = JSON.parse(response.content).result; // console.log(delegation);

            delegations = delegations.concat(delegation);
          } else {
            console.log(response.statusCode);
          }
        } catch (e) {
          console.log(e);
        }
      }
    }

    for (i in delegations) {
      if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
    } // console.log(delegations);


    let data = {
      delegations: delegations,
      createdAt: new Date()
    };
    return Delegations.insert(data);
  } // 'blocks.averageBlockTime'(address){
  //     let blocks = Blockscon.find({proposerAddress:address}).fetch();
  //     let heights = blocks.map((block, i) => {
  //         return block.height;
  //     });
  //     let blocksStats = Analytics.find({height:{$in:heights}}).fetch();
  //     // console.log(blocksStats);
  //     let totalBlockDiff = 0;
  //     for (b in blocksStats){
  //         totalBlockDiff += blocksStats[b].timeDiff;
  //     }
  //     return totalBlockDiff/heights.length;
  // }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/server/publications.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"delegations.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/delegations.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Delegations: () => Delegations
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Delegations = new Mongo.Collection('delegations');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"enterprise":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/enterprise/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Enterprise;
module.link("../enterprise.js", {
  Enterprise(v) {
    Enterprise = v;
  }

}, 2);
Meteor.methods({
  'enterprise.getPurchaseOrders': function () {
    this.unblock();

    try {
      let url = LCD + '/enterprise/pos';
      let response = HTTP.get(url);
      let purchaseOrders = JSON.parse(response.content).result;
      let finishedPurchaseOrders = new Set(Enterprise.find({
        "status": {
          $in: ["reject", "complete"]
        }
      }).fetch().map(p => p.poId));
      let poIds = [];

      if (purchaseOrders.length > 0) {
        const bulkPos = Enterprise.rawCollection().initializeUnorderedBulkOp();

        for (let i in purchaseOrders) {
          let po = purchaseOrders[i];
          po.poId = parseInt(po.id);

          if (po.poId > 0 && !finishedPurchaseOrders.has(po.poId)) {
            try {
              bulkPos.find({
                poId: po.poId
              }).upsert().updateOne({
                $set: po
              });
              poIds.push(po.poId);
            } catch (e) {
              bulkPos.find({
                poId: po.poId
              }).upsert().updateOne({
                $set: po
              });
              poIds.push(po.poId);
              console.log(e.response.content);
            }
          }
        }

        if (poIds.length > 0) {
          bulkPos.execute();
        }
      }

      return true;
    } catch (e) {
      console.log(e);
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/enterprise/server/publications.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Enterprise;
module.link("../enterprise.js", {
  Enterprise(v) {
    Enterprise = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
Meteor.publish('enterprise.list_pos', function () {
  return Enterprise.find({}, {
    sort: {
      poId: -1
    }
  });
});
Meteor.publish('enterprise.one_po', function (id) {
  check(id, Number);
  return Enterprise.find({
    poId: id
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"enterprise.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/enterprise/enterprise.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Enterprise: () => Enterprise
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Enterprise = new Mongo.Collection('enterprise');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"ledger":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/ledger/server/methods.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 0);
Meteor.methods({
  'transaction.submit': function (txInfo) {
    const url = "".concat(LCD, "/txs");
    data = {
      "tx": txInfo.value,
      "mode": "sync"
    };
    const timestamp = new Date().getTime();
    console.log("submitting transaction".concat(timestamp, " ").concat(url, " with data ").concat(JSON.stringify(data)));
    let response = HTTP.post(url, {
      data
    });
    console.log("response for transaction".concat(timestamp, " ").concat(url, ": ").concat(JSON.stringify(response)));

    if (response.statusCode == 200) {
      let data = response.data;
      if (data.code) throw new Meteor.Error(data.code, JSON.parse(data.raw_log).message);
      return response.data.txhash;
    }
  },
  'transaction.execute': function (body, path) {
    const url = "".concat(LCD, "/").concat(path);
    data = {
      "base_req": _objectSpread({}, body, {
        "chain_id": Meteor.settings.public.chainId,
        "simulate": false
      })
    };
    let response = HTTP.post(url, {
      data
    });

    if (response.statusCode == 200) {
      return JSON.parse(response.content);
    }
  },
  'transaction.simulate': function (txMsg, from, path) {
    let adjustment = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '1.2';
    const url = "".concat(LCD, "/").concat(path);
    data = _objectSpread({}, txMsg, {
      "base_req": {
        "from": from,
        "chain_id": Meteor.settings.public.chainId,
        "gas_adjustment": adjustment,
        "simulate": true
      }
    });
    let response = HTTP.post(url, {
      data
    });

    if (response.statusCode == 200) {
      return JSON.parse(response.content).gas_estimate;
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"records":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/server/methods.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let ValidatorRecords, Analytics, AverageData, AverageValidatorData;
module.link("../records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  AverageData(v) {
    AverageData = v;
  },

  AverageValidatorData(v) {
    AverageValidatorData = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
let ValidatorSets;
module.link("/imports/api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 4);
let Status;
module.link("../../status/status.js", {
  Status(v) {
    Status = v;
  }

}, 5);
let MissedBlocksStats;
module.link("../records.js", {
  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  }

}, 6);
let MissedBlocks;
module.link("../records.js", {
  MissedBlocks(v) {
    MissedBlocks = v;
  }

}, 7);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 8);
let Chain;
module.link("../../chain/chain.js", {
  Chain(v) {
    Chain = v;
  }

}, 9);

let _;

module.link("lodash", {
  default(v) {
    _ = v;
  }

}, 10);
const BULKUPDATEMAXSIZE = 1000;

const getBlockStats = (startHeight, latestHeight) => {
  let blockStats = {};
  const cond = {
    $and: [{
      height: {
        $gt: startHeight
      }
    }, {
      height: {
        $lte: latestHeight
      }
    }]
  };
  const options = {
    sort: {
      height: 1
    }
  };
  Blockscon.find(cond, options).forEach(block => {
    blockStats[block.height] = {
      height: block.height,
      proposerAddress: block.proposerAddress,
      precommitsCount: block.precommitsCount,
      validatorsCount: block.validatorsCount,
      validators: block.validators,
      time: block.time
    };
  });
  Analytics.find(cond, options).forEach(block => {
    if (!blockStats[block.height]) {
      blockStats[block.height] = {
        height: block.height
      };
      console.log("block ".concat(block.height, " does not have an entry"));
    }

    _.assign(blockStats[block.height], {
      precommits: block.precommits,
      averageBlockTime: block.averageBlockTime,
      timeDiff: block.timeDiff,
      voting_power: block.voting_power
    });
  });
  return blockStats;
};

const getPreviousRecord = (voterAddress, proposerAddress) => {
  let previousRecord = MissedBlocks.findOne({
    voter: voterAddress,
    proposer: proposerAddress,
    blockHeight: -1
  });
  let lastUpdatedHeight = Meteor.settings.params.startHeight;
  let prevStats = {};

  if (previousRecord) {
    prevStats = _.pick(previousRecord, ['missCount', 'totalCount']);
  } else {
    prevStats = {
      missCount: 0,
      totalCount: 0
    };
  }

  return prevStats;
};

Meteor.methods({
  'ValidatorRecords.calculateMissedBlocks': function () {
    if (!COUNTMISSEDBLOCKS) {
      try {
        let startTime = Date.now();
        COUNTMISSEDBLOCKS = true;
        console.log('calulate missed blocks count');
        this.unblock();
        let validators = Validators.find({}).fetch();
        let latestHeight = Meteor.call('blocks.getCurrentHeight');
        let explorerStatus = Status.findOne({
          chainId: Meteor.settings.public.chainId
        });
        let startHeight = explorerStatus && explorerStatus.lastProcessedMissedBlockHeight ? explorerStatus.lastProcessedMissedBlockHeight : Meteor.settings.params.startHeight;
        latestHeight = Math.min(startHeight + BULKUPDATEMAXSIZE, latestHeight);
        const bulkMissedStats = MissedBlocks.rawCollection().initializeOrderedBulkOp();
        let validatorsMap = {};
        validators.forEach(validator => validatorsMap[validator.address] = validator); // a map of block height to block stats

        let blockStats = getBlockStats(startHeight, latestHeight); // proposerVoterStats is a proposer-voter map counting numbers of proposed blocks of which voter is an active validator

        let proposerVoterStats = {};

        _.forEach(blockStats, (block, blockHeight) => {
          let proposerAddress = block.proposerAddress;
          let votedValidators = new Set(block.validators);
          let validatorSets = ValidatorSets.findOne({
            block_height: block.height
          });
          let votedVotingPower = 0;
          validatorSets.validators.forEach(activeValidator => {
            if (votedValidators.has(activeValidator.address)) votedVotingPower += parseFloat(activeValidator.voting_power);
          });
          validatorSets.validators.forEach(activeValidator => {
            let currentValidator = activeValidator.address;

            if (!_.has(proposerVoterStats, [proposerAddress, currentValidator])) {
              let prevStats = getPreviousRecord(currentValidator, proposerAddress);

              _.set(proposerVoterStats, [proposerAddress, currentValidator], prevStats);
            }

            _.update(proposerVoterStats, [proposerAddress, currentValidator, 'totalCount'], n => n + 1);

            if (!votedValidators.has(currentValidator)) {
              _.update(proposerVoterStats, [proposerAddress, currentValidator, 'missCount'], n => n + 1);

              bulkMissedStats.insert({
                voter: currentValidator,
                blockHeight: block.height,
                proposer: proposerAddress,
                precommitsCount: block.precommitsCount,
                validatorsCount: block.validatorsCount,
                time: block.time,
                precommits: block.precommits,
                averageBlockTime: block.averageBlockTime,
                timeDiff: block.timeDiff,
                votingPower: block.voting_power,
                votedVotingPower,
                updatedAt: latestHeight,
                missCount: _.get(proposerVoterStats, [proposerAddress, currentValidator, 'missCount']),
                totalCount: _.get(proposerVoterStats, [proposerAddress, currentValidator, 'totalCount'])
              });
            }
          });
        });

        _.forEach(proposerVoterStats, (voters, proposerAddress) => {
          _.forEach(voters, (stats, voterAddress) => {
            bulkMissedStats.find({
              voter: voterAddress,
              proposer: proposerAddress,
              blockHeight: -1
            }).upsert().updateOne({
              $set: {
                voter: voterAddress,
                proposer: proposerAddress,
                blockHeight: -1,
                updatedAt: latestHeight,
                missCount: _.get(stats, 'missCount'),
                totalCount: _.get(stats, 'totalCount')
              }
            });
          });
        });

        let message = '';

        if (bulkMissedStats.length > 0) {
          const client = MissedBlocks._driver.mongo.client; // TODO: add transaction back after replica set(#146) is set up
          // let session = client.startSession();
          // session.startTransaction();

          let bulkPromise = bulkMissedStats.execute(null
          /*, {session}*/
          ).then(Meteor.bindEnvironment((result, err) => {
            if (err) {
              COUNTMISSEDBLOCKS = false; // Promise.await(session.abortTransaction());

              throw err;
            }

            if (result) {
              // Promise.await(session.commitTransaction());
              message = "(".concat(result.result.nInserted, " inserted, ") + "".concat(result.result.nUpserted, " upserted, ") + "".concat(result.result.nModified, " modified)");
            }
          }));
          Promise.await(bulkPromise);
        }

        COUNTMISSEDBLOCKS = false;
        Status.upsert({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastProcessedMissedBlockHeight: latestHeight,
            lastProcessedMissedBlockTime: new Date()
          }
        });
        return "done in ".concat(Date.now() - startTime, "ms ").concat(message);
      } catch (e) {
        COUNTMISSEDBLOCKS = false;
        throw e;
      }
    } else {
      return "updating...";
    }
  },
  'ValidatorRecords.calculateMissedBlocksStats': function () {
    // TODO: deprecate this method and MissedBlocksStats collection
    // console.log("ValidatorRecords.calculateMissedBlocks: "+COUNTMISSEDBLOCKS);
    if (!COUNTMISSEDBLOCKSSTATS) {
      COUNTMISSEDBLOCKSSTATS = true;
      console.log('calulate missed blocks stats');
      this.unblock();
      let validators = Validators.find({}).fetch();
      let latestHeight = Meteor.call('blocks.getCurrentHeight');
      let explorerStatus = Status.findOne({
        chainId: Meteor.settings.public.chainId
      });
      let startHeight = explorerStatus && explorerStatus.lastMissedBlockHeight ? explorerStatus.lastMissedBlockHeight : Meteor.settings.params.startHeight; // console.log(latestHeight);
      // console.log(startHeight);

      const bulkMissedStats = MissedBlocksStats.rawCollection().initializeUnorderedBulkOp();

      for (i in validators) {
        // if ((validators[i].address == "B8552EAC0D123A6BF609123047A5181D45EE90B5") || (validators[i].address == "69D99B2C66043ACBEAA8447525C356AFC6408E0C") || (validators[i].address == "35AD7A2CD2FC71711A675830EC1158082273D457")){
        let voterAddress = validators[i].address;
        let missedRecords = ValidatorRecords.find({
          address: voterAddress,
          exists: false,
          $and: [{
            height: {
              $gt: startHeight
            }
          }, {
            height: {
              $lte: latestHeight
            }
          }]
        }).fetch();
        let counts = {}; // console.log("missedRecords to process: "+missedRecords.length);

        for (b in missedRecords) {
          let block = Blockscon.findOne({
            height: missedRecords[b].height
          });
          let existingRecord = MissedBlocksStats.findOne({
            voter: voterAddress,
            proposer: block.proposerAddress
          });

          if (typeof counts[block.proposerAddress] === 'undefined') {
            if (existingRecord) {
              counts[block.proposerAddress] = existingRecord.count + 1;
            } else {
              counts[block.proposerAddress] = 1;
            }
          } else {
            counts[block.proposerAddress]++;
          }
        }

        for (address in counts) {
          let data = {
            voter: voterAddress,
            proposer: address,
            count: counts[address]
          };
          bulkMissedStats.find({
            voter: voterAddress,
            proposer: address
          }).upsert().updateOne({
            $set: data
          });
        } // }

      }

      if (bulkMissedStats.length > 0) {
        bulkMissedStats.execute(Meteor.bindEnvironment((err, result) => {
          if (err) {
            COUNTMISSEDBLOCKSSTATS = false;
            console.log(err);
          }

          if (result) {
            Status.upsert({
              chainId: Meteor.settings.public.chainId
            }, {
              $set: {
                lastMissedBlockHeight: latestHeight,
                lastMissedBlockTime: new Date()
              }
            });
            COUNTMISSEDBLOCKSSTATS = false;
            console.log("done");
          }
        }));
      } else {
        COUNTMISSEDBLOCKSSTATS = false;
      }

      return true;
    } else {
      return "updating...";
    }
  },
  'Analytics.aggregateBlockTimeAndVotingPower': function (time) {
    this.unblock();
    let now = new Date();

    if (time == 'm') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastMinuteVotingPower: averageVotingPower,
            lastMinuteBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    }

    if (time == 'h') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 60 * 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastHourVotingPower: averageVotingPower,
            lastHourBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    }

    if (time == 'd') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastDayVotingPower: averageVotingPower,
            lastDayBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    } // return analytics.length;

  },
  'Analytics.aggregateValidatorDailyBlockTime': function () {
    this.unblock();
    let validators = Validators.find({}).fetch();
    let now = new Date();

    for (i in validators) {
      let averageBlockTime = 0;
      let blocks = Blockscon.find({
        proposerAddress: validators[i].address,
        "time": {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }, {
        fields: {
          height: 1
        }
      }).fetch();

      if (blocks.length > 0) {
        let blockHeights = [];

        for (b in blocks) {
          blockHeights.push(blocks[b].height);
        }

        let analytics = Analytics.find({
          height: {
            $in: blockHeights
          }
        }, {
          fields: {
            height: 1,
            timeDiff: 1
          }
        }).fetch();

        for (a in analytics) {
          averageBlockTime += analytics[a].timeDiff;
        }

        averageBlockTime = averageBlockTime / analytics.length;
      }

      AverageValidatorData.insert({
        proposerAddress: validators[i].address,
        averageBlockTime: averageBlockTime,
        type: 'ValidatorDailyAverageBlockTime',
        createdAt: now
      });
    }

    return true;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/server/publications.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatorRecords, Analytics, MissedBlocks, MissedBlocksStats, VPDistributions;
module.link("../records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  MissedBlocks(v) {
    MissedBlocks = v;
  },

  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  },

  VPDistributions(v) {
    VPDistributions = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
Meteor.publish('validator_records.all', function () {
  return ValidatorRecords.find();
});
Meteor.publish('validator_records.uptime', function (address, num) {
  return ValidatorRecords.find({
    address: address
  }, {
    limit: num,
    sort: {
      height: -1
    }
  });
});
Meteor.publish('analytics.history', function () {
  return Analytics.find({}, {
    sort: {
      height: -1
    },
    limit: 50
  });
});
Meteor.publish('vpDistribution.latest', function () {
  return VPDistributions.find({}, {
    sort: {
      height: -1
    },
    limit: 1
  });
});
publishComposite('missedblocks.validator', function (address, type) {
  let conditions = {};

  if (type == 'voter') {
    conditions = {
      voter: address
    };
  } else {
    conditions = {
      proposer: address
    };
  }

  return {
    find() {
      return MissedBlocksStats.find(conditions);
    },

    children: [{
      find(stats) {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            profile_url: 1
          }
        });
      }

    }]
  };
});
publishComposite('missedrecords.validator', function (address, type) {
  return {
    find() {
      return MissedBlocks.find({
        [type]: address
      }, {
        sort: {
          updatedAt: -1
        }
      });
    },

    children: [{
      find() {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            operator_address: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"records.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/records.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  ValidatorRecords: () => ValidatorRecords,
  Analytics: () => Analytics,
  MissedBlocksStats: () => MissedBlocksStats,
  MissedBlocks: () => MissedBlocks,
  VPDistributions: () => VPDistributions,
  AverageData: () => AverageData,
  AverageValidatorData: () => AverageValidatorData
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const ValidatorRecords = new Mongo.Collection('validator_records');
const Analytics = new Mongo.Collection('analytics');
const MissedBlocksStats = new Mongo.Collection('missed_blocks_stats');
const MissedBlocks = new Mongo.Collection('missed_blocks');
const VPDistributions = new Mongo.Collection('voting_power_distributions');
const AverageData = new Mongo.Collection('average_data');
const AverageValidatorData = new Mongo.Collection('average_validator_data');
MissedBlocksStats.helpers({
  proposerMoniker() {
    let validator = Validators.findOne({
      address: this.proposer
    });
    return validator.description ? validator.description.moniker : this.proposer;
  },

  voterMoniker() {
    let validator = Validators.findOne({
      address: this.voter
    });
    return validator.description ? validator.description.moniker : this.voter;
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"status":{"server":{"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/status/server/publications.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Status;
module.link("../status.js", {
  Status(v) {
    Status = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
Meteor.publish('status.status', function () {
  return Status.find({
    chainId: Meteor.settings.public.chainId
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"status.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/status/status.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Status: () => Status
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Status = new Mongo.Collection('status');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactions":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/server/methods.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 4);
const AddressLength = 40;
Meteor.methods({
  'Transactions.index': function (hash, blockTime) {
    this.unblock();
    hash = hash.toUpperCase();
    let url = LCD + '/txs/' + hash;
    let response = HTTP.get(url);
    let tx = JSON.parse(response.content);
    console.log(hash);
    tx.height = parseInt(tx.height); // if (!tx.code){
    //     let msg = tx.tx.value.msg;
    //     for (let m in msg){
    //         if (msg[m].type == "cosmos-sdk/MsgCreateValidator"){
    //             console.log(msg[m].value);
    //             let command = Meteor.settings.bin.gaiadebug+" pubkey "+msg[m].value.pubkey;
    //             let validator = {
    //                 consensus_pubkey: msg[m].value.pubkey,
    //                 description: msg[m].value.description,
    //                 commission: msg[m].value.commission,
    //                 min_self_delegation: msg[m].value.min_self_delegation,
    //                 operator_address: msg[m].value.validator_address,
    //                 delegator_address: msg[m].value.delegator_address,
    //                 voting_power: Math.floor(parseInt(msg[m].value.value.amount) / 1000000)
    //             }
    //             Meteor.call('runCode', command, function(error, result){
    //                 validator.address = result.match(/\s[0-9A-F]{40}$/igm);
    //                 validator.address = validator.address[0].trim();
    //                 validator.hex = result.match(/\s[0-9A-F]{64}$/igm);
    //                 validator.hex = validator.hex[0].trim();
    //                 validator.pub_key = result.match(/{".*"}/igm);
    //                 validator.pub_key = JSON.parse(validator.pub_key[0].trim());
    //                 let re = new RegExp(Meteor.settings.public.bech32PrefixAccPub+".*$","igm");
    //                 validator.cosmosaccpub = result.match(re);
    //                 validator.cosmosaccpub = validator.cosmosaccpub[0].trim();
    //                 re = new RegExp(Meteor.settings.public.bech32PrefixValPub+".*$","igm");
    //                 validator.operator_pubkey = result.match(re);
    //                 validator.operator_pubkey = validator.operator_pubkey[0].trim();
    //                 Validators.upsert({consensus_pubkey:msg[m].value.pubkey},validator);
    //                 VotingPowerHistory.insert({
    //                     address: validator.address,
    //                     prev_voting_power: 0,
    //                     voting_power: validator.voting_power,
    //                     type: 'add',
    //                     height: tx.height+2,
    //                     block_time: blockTime
    //                 });
    //             })
    //         }
    //     }
    // }

    let txId = Transactions.insert(tx);

    if (txId) {
      return txId;
    } else return false;
  },
  'Transactions.findDelegation': function (address, height) {
    // following cosmos-sdk/x/slashing/spec/06_events.md and cosmos-sdk/x/staking/spec/06_events.md
    return Transactions.find({
      $or: [{
        $and: [{
          "events.type": "delegate"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.attributes.key": "action"
        }, {
          "events.attributes.value": "unjail"
        }, {
          "events.attributes.key": "sender"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "create_validator"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "unbond"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "redelegate"
        }, {
          "events.attributes.key": "destination_validator"
        }, {
          "events.attributes.value": address
        }]
      }],
      "code": {
        $exists: false
      },
      height: {
        $lt: height
      }
    }, {
      sort: {
        height: -1
      },
      limit: 1
    }).fetch();
  },
  'Transactions.findUser': function (address) {
    let fields = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    // address is either delegator address or validator operator address
    let validator;
    if (!fields) fields = {
      address: 1,
      description: 1,
      operator_address: 1,
      delegator_address: 1
    };

    if (address.includes(Meteor.settings.public.bech32PrefixValAddr)) {
      // validator operator address
      validator = Validators.findOne({
        operator_address: address
      }, {
        fields
      });
    } else if (address.includes(Meteor.settings.public.bech32PrefixAccAddr)) {
      // delegator address
      validator = Validators.findOne({
        delegator_address: address
      }, {
        fields
      });
    } else if (address.length === AddressLength) {
      validator = Validators.findOne({
        address: address
      }, {
        fields
      });
    }

    if (validator) {
      return validator;
    }

    return false;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/server/publications.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Transactions;
module.link("../transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 1);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 2);
publishComposite('transactions.list', function () {
  let limit = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 30;
  return {
    find() {
      return Transactions.find({}, {
        sort: {
          height: -1
        },
        limit: limit
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.validator', function (validatorAddress, delegatorAddress) {
  let limit = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 100;
  let query = {};

  if (validatorAddress && delegatorAddress) {
    query = {
      $or: [{
        "events.attributes.value": validatorAddress
      }, {
        "events.attributes.value": delegatorAddress
      }]
    };
  }

  if (!validatorAddress && delegatorAddress) {
    query = {
      "events.attributes.value": delegatorAddress
    };
  }

  return {
    find() {
      return Transactions.find(query, {
        sort: {
          height: -1
        },
        limit: limit
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.findOne', function (hash) {
  return {
    find() {
      return Transactions.find({
        txhash: hash
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.height', function (height) {
  return {
    find() {
      return Transactions.find({
        height: height
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactions.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/transactions.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Transactions: () => Transactions
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Blockscon;
module.link("../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 1);
let TxIcon;
module.link("../../ui/components/Icons.jsx", {
  TxIcon(v) {
    TxIcon = v;
  }

}, 2);
const Transactions = new Mongo.Collection('transactions');
Transactions.helpers({
  block() {
    return Blockscon.findOne({
      height: this.height
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validators":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 1);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 2);
let Delegations;
module.link("../../delegations/delegations.js", {
  Delegations(v) {
    Delegations = v;
  }

}, 3);
Meteor.methods({
  'Validators.findCreateValidatorTime': function (address) {
    // look up the create validator time to consider if the validator has never updated the commission
    let tx = Transactions.findOne({
      $and: [{
        "tx.value.msg.value.delegator_address": address
      }, {
        "tx.value.msg.type": "cosmos-sdk/MsgCreateValidator"
      }, {
        code: {
          $exists: false
        }
      }]
    });

    if (tx) {
      let block = Blockscon.findOne({
        height: tx.height
      });

      if (block) {
        return block.time;
      }
    } else {
      // no such create validator tx
      return false;
    }
  },

  // async 'Validators.getAllDelegations'(address){
  'Validators.getAllDelegations'(address) {
    let url = LCD + '/staking/validators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        delegations = JSON.parse(delegations.content).result;
        delegations.forEach((delegation, i) => {
          if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
        });
        return delegations;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/server/publications.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Validators;
module.link("../validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
let ValidatorRecords;
module.link("../../records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  }

}, 2);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 3);
Meteor.publish('validators.all', function () {
  let sort = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "description.moniker";
  let direction = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : -1;
  let fields = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return Validators.find({}, {
    sort: {
      [sort]: direction
    },
    fields: fields
  });
});
publishComposite('validators.firstSeen', {
  find() {
    return Validators.find({});
  },

  children: [{
    find(val) {
      return ValidatorRecords.find({
        address: val.address
      }, {
        sort: {
          height: 1
        },
        limit: 1
      });
    }

  }]
});
Meteor.publish('validators.voting_power', function () {
  return Validators.find({
    status: 2,
    jailed: false
  }, {
    sort: {
      voting_power: -1
    },
    fields: {
      address: 1,
      description: 1,
      voting_power: 1,
      profile_url: 1
    }
  });
});
publishComposite('validator.details', function (address) {
  let options = {
    address: address
  };

  if (address.indexOf(Meteor.settings.public.bech32PrefixValAddr) != -1) {
    options = {
      operator_address: address
    };
  }

  return {
    find() {
      return Validators.find(options);
    },

    children: [{
      find(val) {
        return VotingPowerHistory.find({
          address: val.address
        }, {
          sort: {
            height: -1
          },
          limit: 50
        });
      }

    }, {
      find(val) {
        return ValidatorRecords.find({
          address: val.address
        }, {
          sort: {
            height: -1
          },
          limit: Meteor.settings.public.uptimeWindow
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validators.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/validators.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Validators: () => Validators
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let ValidatorRecords;
module.link("../records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  }

}, 1);
let VotingPowerHistory;
module.link("../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 2);
const Validators = new Mongo.Collection('validators');
Validators.helpers({
  firstSeen() {
    return ValidatorRecords.findOne({
      address: this.address
    });
  },

  history() {
    return VotingPowerHistory.find({
      address: this.address
    }, {
      sort: {
        height: -1
      },
      limit: 50
    }).fetch();
  }

}); // Validators.helpers({
//     uptime(){
//         // console.log(this.address);
//         let lastHundred = ValidatorRecords.find({address:this.address}, {sort:{height:-1}, limit:100}).fetch();
//         console.log(lastHundred);
//         let uptime = 0;
//         for (i in lastHundred){
//             if (lastHundred[i].exists){
//                 uptime+=1;
//             }
//         }
//         return uptime;
//     }
// })
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"voting-power":{"server":{"publications.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/voting-power/server/publications.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"history.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/voting-power/history.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  VotingPowerHistory: () => VotingPowerHistory
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const VotingPowerHistory = new Mongo.Collection('voting_power_history');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"evidences":{"evidences.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/evidences/evidences.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Evidences: () => Evidences
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Evidences = new Mongo.Collection('evidences');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validator-sets":{"validator-sets.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validator-sets/validator-sets.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  ValidatorSets: () => ValidatorSets
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const ValidatorSets = new Mongo.Collection('validator_sets');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"startup":{"both":{"index.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/both/index.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Import modules used by both client and server through a single index entry point
// e.g. useraccounts configuration file.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"create-indexes.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/create-indexes.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Blockscon;
module.link("../../api/blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 0);
let ValidatorRecords, Analytics, MissedBlocksStats, MissedBlocks, AverageData, AverageValidatorData;
module.link("../../api/records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  },

  MissedBlocks(v) {
    MissedBlocks = v;
  },

  AverageData(v) {
    AverageData = v;
  },

  AverageValidatorData(v) {
    AverageValidatorData = v;
  }

}, 1);
let Transactions;
module.link("../../api/transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 2);
let ValidatorSets;
module.link("../../api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 3);
let Validators;
module.link("../../api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 4);
let VotingPowerHistory;
module.link("../../api/voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 5);
let Evidences;
module.link("../../api/evidences/evidences.js", {
  Evidences(v) {
    Evidences = v;
  }

}, 6);
let CoinStats;
module.link("../../api/coin-stats/coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 7);
let ChainStates;
module.link("../../api/chain/chain.js", {
  ChainStates(v) {
    ChainStates = v;
  }

}, 8);
ChainStates.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
Blockscon.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
Blockscon.rawCollection().createIndex({
  proposerAddress: 1
});
Evidences.rawCollection().createIndex({
  height: -1
}); //Proposals.rawCollection().createIndex({proposalId: 1}, {unique:true});

ValidatorRecords.rawCollection().createIndex({
  address: 1,
  height: -1
}, {
  unique: 1
});
ValidatorRecords.rawCollection().createIndex({
  address: 1,
  exists: 1,
  height: -1
});
Analytics.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
MissedBlocks.rawCollection().createIndex({
  proposer: 1,
  voter: 1,
  updatedAt: -1
});
MissedBlocks.rawCollection().createIndex({
  proposer: 1,
  blockHeight: -1
});
MissedBlocks.rawCollection().createIndex({
  voter: 1,
  blockHeight: -1
});
MissedBlocks.rawCollection().createIndex({
  voter: 1,
  proposer: 1,
  blockHeight: -1
}, {
  unique: true
});
MissedBlocksStats.rawCollection().createIndex({
  proposer: 1
});
MissedBlocksStats.rawCollection().createIndex({
  voter: 1
});
MissedBlocksStats.rawCollection().createIndex({
  proposer: 1,
  voter: 1
}, {
  unique: true
});
AverageData.rawCollection().createIndex({
  type: 1,
  createdAt: -1
}, {
  unique: true
});
AverageValidatorData.rawCollection().createIndex({
  proposerAddress: 1,
  createdAt: -1
}, {
  unique: true
}); // Status.rawCollection.createIndex({})

Transactions.rawCollection().createIndex({
  txhash: 1
}, {
  unique: true
});
Transactions.rawCollection().createIndex({
  height: -1
}); // Transactions.rawCollection().createIndex({action:1});

Transactions.rawCollection().createIndex({
  "events.attributes.key": 1
});
Transactions.rawCollection().createIndex({
  "events.attributes.value": 1
});
ValidatorSets.rawCollection().createIndex({
  block_height: -1
});
Validators.rawCollection().createIndex({
  address: 1
}, {
  unique: true,
  partialFilterExpression: {
    address: {
      $exists: true
    }
  }
});
Validators.rawCollection().createIndex({
  consensus_pubkey: 1
}, {
  unique: true
});
Validators.rawCollection().createIndex({
  "pub_key.value": 1
}, {
  unique: true,
  partialFilterExpression: {
    "pub_key.value": {
      $exists: true
    }
  }
});
VotingPowerHistory.rawCollection().createIndex({
  address: 1,
  height: -1
});
VotingPowerHistory.rawCollection().createIndex({
  type: 1
});
CoinStats.rawCollection().createIndex({
  last_updated_at: -1
}, {
  unique: true
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/index.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("./util.js");
module.link("./register-api.js");
module.link("./create-indexes.js");
let onPageLoad;
module.link("meteor/server-render", {
  onPageLoad(v) {
    onPageLoad = v;
  }

}, 0);
let Helmet;
module.link("react-helmet", {
  Helmet(v) {
    Helmet = v;
  }

}, 1);
// import App from '../../ui/App.jsx';
onPageLoad(sink => {
  // const context = {};
  // const sheet = new ServerStyleSheet()
  // const html = renderToString(sheet.collectStyles(
  //     <StaticRouter location={sink.request.url} context={context}>
  //         <App />
  //     </StaticRouter>
  //   ));
  // sink.renderIntoElementById('app', html);
  const helmet = Helmet.renderStatic();
  sink.appendToHead(helmet.meta.toString());
  sink.appendToHead(helmet.title.toString()); // sink.appendToHead(sheet.getStyleTags());
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"register-api.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/register-api.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("../../api/ledger/server/methods.js");
module.link("../../api/chain/server/methods.js");
module.link("../../api/chain/server/publications.js");
module.link("../../api/blocks/server/methods.js");
module.link("../../api/blocks/server/publications.js");
module.link("../../api/validators/server/methods.js");
module.link("../../api/validators/server/publications.js");
module.link("../../api/records/server/methods.js");
module.link("../../api/records/server/publications.js");
module.link("../../api/enterprise/server/methods.js");
module.link("../../api/enterprise/server/publications.js");
module.link("../../api/voting-power/server/publications.js");
module.link("../../api/transactions/server/methods.js");
module.link("../../api/transactions/server/publications.js");
module.link("../../api/delegations/server/methods.js");
module.link("../../api/delegations/server/publications.js");
module.link("../../api/status/server/publications.js");
module.link("../../api/accounts/server/methods.js");
module.link("../../api/coin-stats/server/methods.js");
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"util.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/util.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let bech32;
module.link("bech32", {
  default(v) {
    bech32 = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let cheerio;
module.link("cheerio", {
  "*"(v) {
    cheerio = v;
  }

}, 2);

// Load future from fibers
var Future = Npm.require("fibers/future"); // Load exec


var exec = Npm.require("child_process").exec;

function toHexString(byteArray) {
  return byteArray.map(function (byte) {
    return ('0' + (byte & 0xFF).toString(16)).slice(-2);
  }).join('');
}

Meteor.methods({
  pubkeyToBech32: function (pubkey, prefix) {
    // '1624DE6420' is ed25519 pubkey prefix
    let pubkeyAminoPrefix = Buffer.from('1624DE6420', 'hex');
    let buffer = Buffer.alloc(37);
    pubkeyAminoPrefix.copy(buffer, 0);
    Buffer.from(pubkey.value, 'base64').copy(buffer, pubkeyAminoPrefix.length);
    return bech32.encode(prefix, bech32.toWords(buffer));
  },
  bech32ToPubkey: function (pubkey) {
    // '1624DE6420' is ed25519 pubkey prefix
    let pubkeyAminoPrefix = Buffer.from('1624DE6420', 'hex');
    let buffer = Buffer.from(bech32.fromWords(bech32.decode(pubkey).words));
    return buffer.slice(pubkeyAminoPrefix.length).toString('base64');
  },
  getDelegator: function (operatorAddr) {
    let address = bech32.decode(operatorAddr);
    return bech32.encode(Meteor.settings.public.bech32PrefixAccAddr, address.words);
  },
  getKeybaseTeamPic: function (keybaseUrl) {
    let teamPage = HTTP.get(keybaseUrl);

    if (teamPage.statusCode == 200) {
      let page = cheerio.load(teamPage.content);
      return page(".kb-main-card img").attr('src');
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"ui":{"components":{"Icons.jsx":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/ui/components/Icons.jsx                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  DenomSymbol: () => DenomSymbol,
  ProposalStatusIcon: () => ProposalStatusIcon,
  VoteIcon: () => VoteIcon,
  TxIcon: () => TxIcon,
  InfoIcon: () => InfoIcon
});
let React;
module.link("react", {
  default(v) {
    React = v;
  }

}, 0);
let UncontrolledTooltip;
module.link("reactstrap", {
  UncontrolledTooltip(v) {
    UncontrolledTooltip = v;
  }

}, 1);

const DenomSymbol = props => {
  switch (props.denom) {
    case "steak":
      return '🥩';

    default:
      return '🍅';
  }
};

const ProposalStatusIcon = props => {
  switch (props.status) {
    case 'Passed':
      return React.createElement("i", {
        className: "fas fa-check-circle text-success"
      });

    case 'Rejected':
      return React.createElement("i", {
        className: "fas fa-times-circle text-danger"
      });

    case 'Removed':
      return React.createElement("i", {
        className: "fas fa-trash-alt text-dark"
      });

    case 'DepositPeriod':
      return React.createElement("i", {
        className: "fas fa-battery-half text-warning"
      });

    case 'VotingPeriod':
      return React.createElement("i", {
        className: "fas fa-hand-paper text-info"
      });

    default:
      return React.createElement("i", null);
  }
};

const VoteIcon = props => {
  switch (props.vote) {
    case 'yes':
      return React.createElement("i", {
        className: "fas fa-check text-success"
      });

    case 'no':
      return React.createElement("i", {
        className: "fas fa-times text-danger"
      });

    case 'abstain':
      return React.createElement("i", {
        className: "fas fa-user-slash text-warning"
      });

    case 'no_with_veto':
      return React.createElement("i", {
        className: "fas fa-exclamation-triangle text-info"
      });

    default:
      return React.createElement("i", null);
  }
};

const TxIcon = props => {
  if (props.valid) {
    return React.createElement("span", {
      className: "text-success text-nowrap"
    }, React.createElement("i", {
      className: "fas fa-check-circle"
    }));
  } else {
    return React.createElement("span", {
      className: "text-danger text-nowrap"
    }, React.createElement("i", {
      className: "fas fa-times-circle"
    }));
  }
};

class InfoIcon extends React.Component {
  constructor(props) {
    super(props);
    this.ref = React.createRef();
  }

  render() {
    return [React.createElement("i", {
      key: "icon",
      className: "material-icons info-icon",
      ref: this.ref
    }, "info"), React.createElement(UncontrolledTooltip, {
      key: "tooltip",
      placement: "right",
      target: this.ref
    }, this.props.children ? this.props.children : this.props.tooltipText)];
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"both":{"i18n":{"en-us.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/en-us.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('en-US','',{"common":{"height":"Height","voter":"Voter","votingPower":"Voting Power","addresses":"Addresses","amounts":"Amounts","delegators":"delegators","block":"block","blocks":"blocks","precommit":"precommit","precommits":"precommits","last":"last","backToList":"Back to List","information":"Information","time":"Time","hash":"Hash","more":"More","fullStop":".","searchPlaceholder":"Search with tx hash / block height / address","cancel":"Cancel","retry":"Retry"},"navbar":{"siteName":"Unification Mainchain","version":"beta","validators":"Validators","blocks":"Blocks","transactions":"Transactions","proposals":"Proposals","votingPower":"Voting Power","lang":"ENG","english":"English","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"Fork me!","signers":"Signers"},"consensus":{"consensusState":"Consensus State","round":"Round","step":"Step"},"chainStates":{"price":"Price","marketCap":"Market Cap","inflation":"Inflation","communityPool":"Community Pool"},"chainStatus":{"startMessage":"The chain is going to start in","stopWarning":"The chain appears to be stopped for <em>{$time}</em>! Feed me with new blocks 😭!","latestHeight":"Latest Block Height","averageBlockTime":"Average Block Time","all":"All","now":"Now","allTime":"All Time","lastMinute":"Last Minute","lastHour":"Last Hour","lastDay":"Last Day","seconds":"seconds","activeValidators":"Active Validators","outOfValidators":"out of {$totalValidators} validators","onlineVotingPower":"Online Voting Power","fromTotalStakes":"{$percent} from {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"Block Time History","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"Random Validators","moniker":"Moniker","uptime":"Uptime","selfPercentage":"Self%","commission":"Commission","lastSeen":"Last Seen","status":"Status","jailed":"Jailed","navActive":"Active","navInactive":"Inactive","active":"Active Validators","inactive":"Inactive Validators","listOfActive":"Here is a list of active validators.","listOfInactive":"Here is a list of inactive validators.","validatorDetails":"Validator Details","lastNumBlocks":"Last {$numBlocks} blocks","validatorInfo":"Validator Info","operatorAddress":"Operator Address","selfDelegationAddress":"Self-Delegate Address","commissionRate":"Commission Rate","maxRate":"Max Rate","maxChangeRate":"Max Change Rate","selfDelegationRatio":"Self Delegation Ratio","proposerPriority":"Proposer Priority","delegatorShares":"Delegator Shares","userDelegateShares":"Shares Delegated by you","tokens":"Tokens","unbondingHeight":"Unbonding Height","unbondingTime":"Unbonding Time","powerChange":"Power Change","delegations":"Delegations","transactions":"Transactions","validatorNotExists":"Validator does not exist.","backToValidator":"Back to Validator","missedBlocks":"Missed Blocks","missedPrecommits":"Missed Precommits","missedBlocksTitle":"Missed blocks of {$moniker}","totalMissed":"Total missed","block":"Block","missedCount":"Miss Count","iDontMiss":"I do not miss ","lastSyncTime":"Last sync time","delegator":"Delegator","amount":"Amount","website":"Website"},"blocks":{"block":"Block","proposer":"Proposer","latestBlocks":"Latest blocks","noBlock":"No block.","numOfTxs":"No. of Txs","numOfTransactions":"No. of Transactions","notFound":"No such block found."},"transactions":{"transaction":"Transaction","transactions":"Transactions","notFound":"No transaction found.","activities":"Activities","txHash":"Tx Hash","valid":"Valid","fee":"Fee","gasUsedWanted":"Gas (used / wanted)","noTxFound":"No such transaction found.","noValidatorTxsFound":"No transaction related to this validator was found.","memo":"Memo","transfer":"Transfer","staking":"Staking","distribution":"Distribution","governance":"Governance","slashing":"Slashing","enterprise":"Enterprise","wrkchain":"WRKChain","beacon":"BEACON"},"proposals":{"notFound":"No proposal found.","listOfProposals":"Here is a list of governance proposals.","proposer":"Proposer","proposal":"proposal","proposals":"Proposals","proposalID":"Proposal ID","title":"Title","status":"Status","submitTime":"Submit Time","depositEndTime":"Deposit End Time","votingStartTime":"Voting Start Time","votingEndTime":"End Voting Time","totalDeposit":"Total Deposit","description":"Description","proposalType":"Proposal Type","proposalStatus":"Proposal Status","notStarted":"not started","final":"final","deposit":"Deposit","tallyResult":"Tally Result","yes":"Yes","abstain":"Abstain","no":"No","noWithVeto":"No with Veto","percentageVoted":"<span class=\"text-info\">{$percent}</span> of online voting power has been voted.","validMessage":"This proposal is {$tentative}<strong>valid</strong>.","invalidMessage":"Less than {$quorum} of voting power is voted. This proposal is <strong>invalid</strong>.","moreVoteMessage":"It will be a valid proposal once <span class=\"text-info\">{$moreVotes}</span> more votes are casted."},"votingPower":{"distribution":"Voting Power Distribution","pareto":"Pareto Principle (20/80 rule)","minValidators34":"Min no. of validators hold 34%+ power"},"accounts":{"accountDetails":"Account Details","available":"Available","delegated":"Delegated","unbonding":"Unbonding","rewards":"Rewards","total":"Total","notFound":"This account does not exist. Are you looking for a wrong address?","validators":"Validators","shares":"Shares","mature":"Mature","no":"No ","delegation":"Delegation","plural":"s","signOut":"Sign out","signInText":"You are signed in as ","toLoginAs":"To log in as","signInWithLedger":"Sign In With Ledger","signInWarning":"Please make sure your Ledger device is connected and <strong class=\"text-primary\">Cosmos App 1.5.0 or above</strong> is opened.","pleaseAccept":"please accept in your Ledger device."},"signers":{"latestSigners":"Latest Signers","signers":"Signers","active":"Active Signers","activeValidators":"Active Validators","blocksSigned":"Blocks Signed","signed":"Signed","percentMissed":"% Missed","lastSigned":"Last Signed"},"activities":{"single":"A","happened":"happened.","senders":"The following sender(s)","sent":"sent","receivers":"to the following receipient(s)","received":"received","failedTo":"failed to ","to":"to","from":"from","operatingAt":"operating at","withMoniker":"with moniker","withTitle":"with title","withA":"with a","purchased":"purchased","decision":"decision"},"messageTypes":{"send":"Send","multiSend":"Multi Send","createValidator":"Create Validator","editValidator":"Edit Validator","delegate":"Delegate","undelegate":"Undelegate","redelegate":"Redelegate","submitProposal":"Submit Proposal","deposit":"Deposit","vote":"Vote","withdrawComission":"Withdraw Commission","withdrawReward":"Withdraw Reward","modifyWithdrawAddress":"Modify Withdraw Address","unjail":"Unjail","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive","enterprisePurchase":"Purchase Enterprise UND","enterpriseProcess":"Process Enterprise Purchase Order","wrkchainRegister":"Register WRKChain","wrkchainRecord":"Record WRKChain Hashes","beaconRegister":"Register BEACON","beaconRecord":"Record BEACON Timestamp"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"zh-hans.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/zh-hans.i18n.yml.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('zh-Hans','',{"common":{"height":"高度","voter":"投票人","votingPower":"投票权","addresses":"地址","amounts":"数量","delegators":"委托人","block":"区块","blocks":"区块","precommit":"建块前保证","precommits":"建块前保证","last":"最后","backToList":"回到列表","information":"资讯","time":"时间","hash":"哈希","more":"更多","fullStop":"。","searchPlaceholder":"搜寻交易哈希 / 区块高度 / 地址","cancel":"取消","retry":"重试"},"navbar":{"siteName":"北斗","version":"beta","validators":"验证人","blocks":"区块","transactions":"交易","proposals":"治理提案","votingPower":"投票权分布","lang":"中文（简）","english":"English","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"Fork me!","signers":"签名人"},"consensus":{"consensusState":"共识状态","round":"轮数","step":"阶数"},"chainStates":{"price":"价格","marketCap":"市值","inflation":"通胀率","communityPool":"社区储备"},"chainStatus":{"startMessage":"这链将还有以下时间便会开始","stopWarning":"这链似乎已经停了 <em>{$time}</em>！ 请继续喂我吃新的区块 😭!","latestHeight":"最新区块高度","averageBlockTime":"平均区块时间","all":"全部","now":"现在","allTime":"全部","lastMinute":"前一分钟","lastHour":"前一小时","lastDay":"前一天","seconds":"秒","activeValidators":"有效验证人","outOfValidators":"来自总共 {$totalValidators} 个验证人","onlineVotingPower":"在线投票权","fromTotalStakes":"为 {$totalStakes} 颗 {$denom} 的 {$percent}"},"analytics":{"blockTimeHistory":"在线投票权","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"随机验证人","moniker":"验证人代号","uptime":"上线时间比重","selfPercentage":"自我委托%","commission":"佣金","lastSeen":"最后投票时间","status":"状态","jailed":"被禁制","navActive":"有效","navInactive":"无效","active":"有效验证人","inactive":"无效验证人","listOfActive":"这名单显示所有有效验证人","listOfInactive":"这名单显示所有无效验证人","validatorDetails":"验证人详情","lastNumBlocks":"最后 {$numBlocks} 个区块","validatorInfo":"验证人资讯","operatorAddress":"操作地址","selfDelegationAddress":"自我委托地址","commissionRate":"佣金","maxRate":"最大佣金限制","maxChangeRate":"每天最大佣金变化限制","selfDelegationRatio":"自我委托比例","proposerPriority":"建块优先权","delegatorShares":"委托股数","userDelegateShares":"你委托的股数","tokens":"代币数量","unbondingHeight":"解绑高度","unbondingTime":"解绑时间","powerChange":"投票权变更","delegations":"委托","transactions":"交易","validatorNotExists":"验证人不存在。","backToValidator":"回到验证人页面","missedBlocks":"错过了的区块","missedPrecommits":"遗留了的建块前保证","missedBlocksTitle":"错过了 {$moniker} 的区块","totalMissed":"一共错过了","block":"区块","missedCount":"错过数量","iDontMiss":"我不会错过任何一个","lastSyncTime":"上一次同步时间","delegator":"委托人","amount":"数量","website":"网站"},"blocks":{"proposer":"建块人","block":"区块","latestBlocks":"最近区块","noBlock":"没有区块。","numOfTxs":"交易数量","numOfTransactions":"交易数量","notFound":"没有这个区块。"},"transactions":{"transaction":"交易","transactions":"交易","notFound":"沒有交易。","activities":"活动","txHash":"交易哈希","valid":"有效","fee":"费用","gasUsedWanted":"瓦斯 (已用 / 要求)","noTxFound":"没有这笔交易。","noValidatorTxsFound":"没有跟这个验证人有关的交易","memo":"备忘录","transfer":"代币转移","staking":"委托","distribution":"收益分配","governance":"链上治理","slashing":"削减","enterprise":"企业","wrkchain":"WRKChain","beacon":"BEACON"},"proposals":{"notFound":"没有治理提案","listOfProposals":"这名单显示所有治理提案","proposer":"提案人","proposal":"治理提案","proposals":"治理提案","proposalID":"提案编号","title":"主题","status":"状态","submitTime":"提案时间","depositEndTime":"存入押金","votingStartTime":"投票开始时间","votingEndTime":"投票结束时间","totalDeposit":"押金总额","description":"详细内容","proposalType":"提案类型","proposalStatus":"提案状态","notStarted":"未开始","final":"最后结果","deposit":"押金","tallyResult":"投票结果","yes":"赞成","abstain":"弃权","no":"反对","noWithVeto":"强烈反对","percentageVoted":"现时在线投票权的投票率是 <span class=\"text-info\">{$percent}</span>。","validMessage":"这个提案 {$tentative} <strong>有效</strong>.","invalidMessage":"已投票的在线投票权少于 {$quorum}。这个提案 <strong>無效</strong>。","moreVoteMessage":"当再有多 <span class=\"text-info\">{$moreVotes}</span> 投票权投了票的话，这个提案将会有效。"},"votingPower":{"distribution":"投票权分布","pareto":"帕累托原则 (20/80 定率)","minValidators34":"最少合共有超过 34% 投票权的验证人"},"accounts":{"accountDetails":"帐户详情","available":"可用的","delegated":"委托中","unbonding":"解绑中","rewards":"未取回收益","total":"总共","notFound":"这个帐户不存在。你是否在查看一个错误的地址？","validators":"验证人","shares":"股数","mature":"成熟日期","no":"没有","delegation":"委托","plural":"","signOut":"登出","signInText":"你已登录以下帐户","toLoginAs":"登录以下帐户","signInWithLedger":"透过 Ledger 登录","signInWarning":"请确定你已经连接 Ledger 设备，并已开启 <strong class=\"text-primary\">Cosmos App 版本 1.5.0 或以上</strong>。","pleaseAccept":"请从你的 Ledger 设备确认。"},"signers":{"latestSigners":"Latest Signers","signers":"Signers","active":"Active Signers","activeValidators":"Active Validators","blocksSigned":"Blocks Signed","signed":"Signed","percentMissed":"% Missed","lastSigned":"Last Signed"},"activities":{"single":"一个","happened":"发生了","senders":"以下的帐户","sent":"发了","receivers":"到以下的帐户","received":"收到","failedTo":"未能","to":"到","from":"从","operatingAt":"操作地址为","withMoniker":"而验证人代号为","withTitle":"治理提案主题为","withA":"投了","purchased":"已购买","decision":"决定"},"messageTypes":{"send":"发送","multiSend":"多重发送","createValidator":"建立验证人","editValidator":"编辑验证人资料","delegate":"委托","undelegate":"解委托","redelegate":"转委托","submitProposal":"提交议案","deposit":"存入","vote":"投票","withdrawComission":"提取手续费","withdrawReward":"提取收益","modifyWithdrawAddress":"更改收益取回地址","unjail":"赦免","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive","enterprisePurchase":"Purchase Enterprise UND","enterpriseProcess":"Process Enterprise Purchase Order","wrkchainRegister":"Register WRKChain","wrkchainRecord":"Record WRKChain Hashes","beaconRegister":"Register BEACON","beaconRecord":"Record BEACON Timestamp"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"zh-hant.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/zh-hant.i18n.yml.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('zh-Hant','',{"common":{"height":"高度","voter":"投票人","votingPower":"投票權","addresses":"地址","amounts":"數量","delegators":"委托人","block":"區塊","blocks":"區塊","precommit":"建塊前保證","precommits":"建塊前保證","last":"最後","backToList":"回到列表","information":"資訊","time":"時間","hash":"哈希","more":"更多","fullStop":"。","searchPlaceholder":"搜尋交易哈希 / 區塊高度 / 地址","cancel":"取消","retry":"重試"},"navbar":{"siteName":"北斗","version":"beta","validators":"驗證人","blocks":"區塊","transactions":"交易","proposals":"治理提案","votingPower":"投票權分佈","lang":"中文（繁）","english":"English","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"Fork me!","signers":"簽名人"},"consensus":{"consensusState":"共識狀態","round":"輪數","step":"階數"},"chainStates":{"price":"價格","marketCap":"市值","inflation":"通漲率","communityPool":"社區儲備"},"chainStatus":{"startMessage":"這鏈將還有以下時間便會開始","stopWarning":"這鏈似乎已經停了 <em>{$time}</em>！ 請繼續餵我吃新的區塊 😭!","latestHeight":"最新區塊高度","averageBlockTime":"平均區塊時間","all":"全部","now":"現在","allTime":"全部","lastMinute":"前一分鐘","lastHour":"前一小時","lastDay":"前一天","seconds":"秒","activeValidators":"有效驗證人","outOfValidators":"來自總共 {$totalValidators} 個驗證人","onlineVotingPower":"在線投票權","fromTotalStakes":"為 {$totalStakes} 顆 {$denom} 的 {$percent}"},"analytics":{"blockTimeHistory":"在線投票權","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"隨機驗證人","moniker":"驗證人代號","uptime":"上線時間比重","selfPercentage":"自我委托%","commission":"佣金","lastSeen":"最後投票時間","status":"狀態","jailed":"被禁制","navActive":"有效","navInactive":"無效","active":"有效驗證人","inactive":"無效驗證人","listOfActive":"這名單顯示所有有效驗證人","listOfInactive":"這名單顯示所有無效驗證人","validatorDetails":"驗證人詳情","lastNumBlocks":"最後 {$numBlocks} 個區塊","validatorInfo":"驗證人資訊","operatorAddress":"操作地址","selfDelegationAddress":"自我委托地址","commissionRate":"佣金","maxRate":"最大佣金限制","maxChangeRate":"每天最大佣金變化限制","selfDelegationRatio":"自我委托比列","proposerPriority":"建塊優先權","delegatorShares":"委托股數","userDelegateShares":"你委托的股數","tokens":"代幣數量","unbondingHeight":"解綁高度","unbondingTime":"解綁時間","powerChange":"投票權變更","delegations":"委托","transactions":"交易","validatorNotExists":"驗證人不存在。","backToValidator":"回到驗證人頁面","missedBlocks":"錯過了的區塊","missedPrecommits":"遺留了的建塊前保證","missedBlocksTitle":"錯過了 {$moniker} 的區塊","totalMissed":"一共錯過了","block":"區塊","missedCount":"錯過數量","iDontMiss":"我不會錯過任何一個","lastSyncTime":"上一次同步時間","delegator":"委托人","amount":"數量","website":"網站"},"blocks":{"proposer":"建塊人","block":"區塊","latestBlocks":"最近區塊","noBlock":"沒有區塊。","numOfTxs":"交易數量","numOfTransactions":"交易數量","notFound":"沒有這個區塊。"},"transactions":{"transaction":"交易","transactions":"交易","notFound":"沒有交易。","activities":"活動","txHash":"交易哈希","valid":"有效","fee":"費用","gasUsedWanted":"瓦斯 (已用 / 要求)","noTxFound":"沒有這筆交易。","noValidatorTxsFound":"沒有跟這個驗證人有關的交易","memo":"備忘錄","transfer":"代幣轉移","staking":"委托","distribution":"收益分配","governance":"鏈上治理","slashing":"削減","enterprise":"企業","wrkchain":"WRKChain","beacon":"BEACON"},"proposals":{"notFound":"沒有治理提案","listOfProposals":"這名單顯示所有治理提案","proposer":"提案人","proposal":"治理提案","proposals":"治理提案","proposalID":"提案編號","title":"主題","status":"狀態","submitTime":"提案時間","depositEndTime":"存入押金","votingStartTime":"投票開始時間","votingEndTime":"投票結束時間","totalDeposit":"押金總額","description":"詳細內容","proposalType":"提案類型","proposalStatus":"提案狀態","notStarted":"未開始","final":"最後結果","deposit":"押金","tallyResult":"投票結果","yes":"贊成","abstain":"棄權","no":"反對","noWithVeto":"強烈反對","percentageVoted":"現時在線投票權的投票率是 <span class=\"text-info\">{$percent}</span>。","validMessage":"這個提案 {$tentative} <strong>有效</strong>.","invalidMessage":"已投票的在線投票權少於 {$quorum}。這個 <strong>無效</strong>。","moreVoteMessage":"當再有多 <span class=\"text-info\">{$moreVotes}</span> 投票權投了票的話，這個提案將會有效。"},"votingPower":{"distribution":"投票權分佈","pareto":"帕累托原則 (20/80 定率)","minValidators34":"最少合共有超過 34% 投票權的驗證人"},"accounts":{"accountDetails":"帳戶詳情","available":"可用的","delegated":"委托中","unbonding":"解綁中","rewards":"未取回收益","total":"總共","notFound":"這個帳戶不存在。你是否在查看一個錯誤的地址？","validators":"驗證人","shares":"股數","mature":"成熟日期","no":"沒有","delegation":"委托","plural":"","signOut":"登出","signInText":"你已登入以下帳戶","toLoginAs":"登入以下帳戶","signInWithLedger":"透過 Ledger 登入","signInWarning":"請確定你已經連接 Ledger 設備，並已開啓 <strong class=\"text-primary\">Cosmos App 版本 1.5.0 或以上</strong>。","pleaseAccept":"請從你的 Ledger 設備確認。"},"signers":{"latestSigners":"Latest Signers","signers":"Signers","active":"Active Signers","activeValidators":"Active Validators","blocksSigned":"Blocks Signed","signed":"Signed","percentMissed":"% Missed","lastSigned":"Last Signed"},"activities":{"single":"一個","happened":"發生了","senders":"以下的帳戶","sent":"發了","receivers":"到以下的帳戶","received":"收到","failedTo":"未能","to":"到","from":"從","operatingAt":"操作地止為","withMoniker":"而驗證人代號為","withTitle":"治理提案主題為","withA":"投了","purchased":"已購買","decision":"決定"},"messageTypes":{"send":"發送","multiSend":"多重發送","createValidator":"建立驗證人","editValidator":"編輯驗證人資料","delegate":"委托","undelegate":"解委托","redelegate":"轉委托","submitProposal":"提交議案","deposit":"存入","vote":"投票","withdrawComission":"提取手續費","withdrawReward":"提取收益","modifyWithdrawAddress":"更改收益取回地址","unjail":"赦免","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive","enterprisePurchase":"Purchase Enterprise UND","enterpriseProcess":"Process Enterprise Purchase Order","wrkchainRegister":"Register WRKChain","wrkchainRecord":"Record WRKChain Hashes","beaconRegister":"Register BEACON","beaconRecord":"Record BEACON Timestamp"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"utils":{"coins.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/utils/coins.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => Coin
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let numbro;
module.link("numbro", {
  default(v) {
    numbro = v;
  }

}, 1);

autoformat = value => {
  let formatter = '0,0.0000';
  value = Math.round(value * 1000) / 1000;
  if (Math.round(value) === value) formatter = '0,0';else if (Math.round(value * 10) === value * 10) formatter = '0,0.0';else if (Math.round(value * 100) === value * 100) formatter = '0,0.00';else if (Math.round(value * 1000) === value * 1000) formatter = '0,0.000';
  return numbro(value).format(formatter);
};

class Coin {
  constructor(amount) {
    let denom = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    if (typeof amount === 'object') ({
      amount,
      denom
    } = amount);

    if (!denom || denom.toLowerCase() === Coin.MintingDenom.toLowerCase()) {
      this._amount = Number(amount);
    } else if (denom.toLowerCase() === Coin.StakingDenom.toLowerCase()) {
      this._amount = Number(amount) * Coin.StakingFraction;
    } else {
      throw Error("unsupported denom ".concat(denom));
    }
  }

  get amount() {
    return this._amount;
  }

  get stakingAmount() {
    return this._amount / Coin.StakingFraction;
  }

  toString(precision) {
    // default to display in mint denom if it has more than 4 decimal places
    let minStake = Coin.StakingFraction / (precision ? Math.pow(10, precision) : 10000);

    if (this.amount < minStake) {
      return "".concat(numbro(this.amount).format('0,0'), " ").concat(Coin.MintingDenom);
    } else {
      return "".concat(precision ? numbro(this.stakingAmount).format('0,0.' + '0'.repeat(precision)) : autoformat(this.stakingAmount), " ").concat(Coin.StakingDenom);
    }
  }

  mintString(formatter) {
    let amount = this.amount;

    if (formatter) {
      amount = numbro(amount).format(formatter);
    }

    return "".concat(amount, " ").concat(Coin.MintingDenom);
  }

  stakeString(formatter) {
    let amount = this.stakingAmount;

    if (formatter) {
      amount = numbro(amount).format(formatter);
    }

    return "".concat(amount, " ").concat(Coin.StakingDenom);
  }

}

Coin.StakingDenom = Meteor.settings.public.stakingDenom;
Coin.StakingDenomPlural = Meteor.settings.public.stakingDenomPlural || Coin.StakingDenom + 's';
Coin.MintingDenom = Meteor.settings.public.mintingDenom;
Coin.StakingFraction = Number(Meteor.settings.public.stakingFraction);
Coin.MinStake = 1 / Number(Meteor.settings.public.stakingFraction);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("/imports/startup/server");
module.link("/imports/startup/both");
// import moment from 'moment';
// import '/imports/api/blocks/blocks.js';
SYNCING = false;
COUNTMISSEDBLOCKS = false;
COUNTMISSEDBLOCKSSTATS = false;
RPC = Meteor.settings.remote.rpc;
LCD = Meteor.settings.remote.lcd;
timerBlocks = 0;
timerChain = 0;
timerConsensus = 0;
timerProposal = 0;
timerProposalsResults = 0;
timerMissedBlock = 0;
timerDelegation = 0;
timerAggregate = 0;
const DEFAULTSETTINGS = '/default_settings.json';

updateChainStatus = () => {
  Meteor.call('chain.updateStatus', (error, result) => {
    if (error) {
      console.log("updateStatus: " + error);
    } else {
      console.log("updateStatus: " + result);
    }
  });
};

updateBlock = () => {
  Meteor.call('blocks.blocksUpdate', (error, result) => {
    if (error) {
      console.log("updateBlocks: " + error);
    } else {
      console.log("updateBlocks: " + result);
    }
  });
};

getConsensusState = () => {
  Meteor.call('chain.getConsensusState', (error, result) => {
    if (error) {
      console.log("get consensus: " + error);
    }
  });
};

getPurchaseOrders = () => {
  Meteor.call('enterprise.getPurchaseOrders', (error, result) => {
    if (error) {
      console.log("get po: " + error);
    }

    if (result) {
      console.log("get po: " + result);
    }
  });
}; //getProposals = () => {
//    Meteor.call('proposals.getProposals', (error, result) => {
//        if (error){
//            console.log("get proposal: "+ error);
//        }
//        if (result){
//            console.log("get proposal: "+result);
//        }
//    });
//}
//
//getProposalsResults = () => {
//    Meteor.call('proposals.getProposalResults', (error, result) => {
//        if (error){
//            console.log("get proposals result: "+error);
//        }
//        if (result){
//            console.log("get proposals result: "+result);
//        }
//    });
//}


updateMissedBlocks = () => {
  Meteor.call('ValidatorRecords.calculateMissedBlocks', (error, result) => {
    if (error) {
      console.log("missed blocks error: " + error);
    }

    if (result) {
      console.log("missed blocks ok:" + result);
    }
  });
  /*
      Meteor.call('ValidatorRecords.calculateMissedBlocksStats', (error, result) =>{
          if (error){
              console.log("missed blocks stats error: "+ error)
          }
          if (result){
              console.log("missed blocks stats ok:" + result);
          }
      });
  */
};

getDelegations = () => {
  Meteor.call('delegations.getDelegations', (error, result) => {
    if (error) {
      console.log("get delegations error: " + error);
    } else {
      console.log("get delegations ok: " + result);
    }
  });
};

aggregateMinutely = () => {
  // doing something every min
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "m", (error, result) => {
    if (error) {
      console.log("aggregate minutely block time error: " + error);
    } else {
      console.log("aggregate minutely block time ok: " + result);
    }
  });
  Meteor.call('coinStats.getCoinStats', (error, result) => {
    if (error) {
      console.log("get coin stats error: " + error);
    } else {
      console.log("get coin stats ok: " + result);
    }
  });
};

aggregateHourly = () => {
  // doing something every hour
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "h", (error, result) => {
    if (error) {
      console.log("aggregate hourly block time error: " + error);
    } else {
      console.log("aggregate hourly block time ok: " + result);
    }
  });
};

aggregateDaily = () => {
  // doing somthing every day
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "d", (error, result) => {
    if (error) {
      console.log("aggregate daily block time error: " + error);
    } else {
      console.log("aggregate daily block time ok: " + result);
    }
  });
  Meteor.call('Analytics.aggregateValidatorDailyBlockTime', (error, result) => {
    if (error) {
      console.log("aggregate validators block time error:" + error);
    } else {
      console.log("aggregate validators block time ok:" + result);
    }
  });
};

Meteor.startup(function () {
  if (Meteor.isDevelopment) {
    let DEFAULTSETTINGSJSON;
    module.link("../default_settings.json", {
      default(v) {
        DEFAULTSETTINGSJSON = v;
      }

    }, 0);
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;
    Object.keys(DEFAULTSETTINGSJSON).forEach(key => {
      if (Meteor.settings[key] == undefined) {
        console.warn("CHECK SETTINGS JSON: ".concat(key, " is missing from settings"));
        Meteor.settings[key] = {};
      }

      Object.keys(DEFAULTSETTINGSJSON[key]).forEach(param => {
        if (Meteor.settings[key][param] == undefined) {
          console.warn("CHECK SETTINGS JSON: ".concat(key, ".").concat(param, " is missing from settings"));
          Meteor.settings[key][param] = DEFAULTSETTINGSJSON[key][param];
        }
      });
    });
  }

  Meteor.call('chain.genesis', (err, result) => {
    if (err) {
      console.log(err);
    }

    if (result) {
      if (Meteor.settings.debug.startTimer) {
        timerConsensus = Meteor.setInterval(function () {
          getConsensusState();
        }, Meteor.settings.params.consensusInterval);
        timerBlocks = Meteor.setInterval(function () {
          updateBlock();
        }, Meteor.settings.params.blockInterval);
        timerChain = Meteor.setInterval(function () {
          updateChainStatus();
        }, Meteor.settings.params.statusInterval);
        timerPurchaseOrder = Meteor.setInterval(function () {
          getPurchaseOrders();
        }, Meteor.settings.params.proposalInterval); //                timerProposal = Meteor.setInterval(function(){
        //                    getProposals();
        //                }, Meteor.settings.params.proposalInterval);
        //
        //                timerProposalsResults = Meteor.setInterval(function(){
        //                    getProposalsResults();
        //                }, Meteor.settings.params.proposalInterval);

        timerMissedBlock = Meteor.setInterval(function () {
          updateMissedBlocks();
        }, Meteor.settings.params.missedBlocksInterval);
        timerDelegation = Meteor.setInterval(function () {
          getDelegations();
        }, Meteor.settings.params.delegationInterval);
        timerAggregate = Meteor.setInterval(function () {
          let now = new Date();

          if (now.getUTCSeconds() == 0) {
            aggregateMinutely();
          }

          if (now.getUTCMinutes() == 0 && now.getUTCSeconds() == 0) {
            aggregateHourly();
          }

          if (now.getUTCHours() == 0 && now.getUTCMinutes() == 0 && now.getUTCSeconds() == 0) {
            aggregateDaily();
          }
        }, 1000);
      }
    }
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"default_settings.json":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// default_settings.json                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "public": {
    "chainName": "Cosmos Testnet",
    "chainId": "{Chain ID}",
    "gtm": "{Add your Google Tag Manager ID here}",
    "slashingWindow": 10000,
    "uptimeWindow": 250,
    "initialPageSize": 30,
    "bech32PrefixAccAddr": "cosmos",
    "bech32PrefixAccPub": "cosmospub",
    "bech32PrefixValAddr": "cosmosvaloper",
    "bech32PrefixValPub": "cosmosvaloperpub",
    "bech32PrefixConsAddr": "cosmosvalcons",
    "bech32PrefixConsPub": "cosmosvalconspub",
    "stakingDenom": "ATOM",
    "stakingDenomPlural": null,
    "mintingDenom": "uatom",
    "stakingFraction": 1000000,
    "powerReduction": null,
    "gasPrice": 0.02,
    "coingeckoId": "cosmos"
  },
  "genesisFile": "{Replace the address of the genesis file of the chain}",
  "remote": {
    "rpc": "https://gaia-seeds.interblock.io",
    "lcd": "https://gaia-seeds.interblock.io:1317"
  },
  "debug": {
    "startTimer": true,
    "readGenesis": true
  },
  "params": {
    "startHeight": 0,
    "defaultBlockTime": 5000,
    "blockInterval": 15000,
    "consensusInterval": 1000,
    "statusInterval": 7500,
    "signingInfoInterval": 1800000,
    "proposalInterval": 5000,
    "missedBlocksInterval": 60000,
    "delegationInterval": 900000
  }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx",
    ".mjs",
    ".i18n.yml"
  ]
});

require("/both/i18n/en-us.i18n.yml.js");
require("/both/i18n/zh-hans.i18n.yml.js");
require("/both/i18n/zh-hant.i18n.yml.js");
require("/both/utils/coins.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWNjb3VudHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jsb2Nrcy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYmxvY2tzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jsb2Nrcy9ibG9ja3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2NoYWluL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jaGFpbi9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jaGFpbi9jaGFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29pbi1zdGF0cy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29pbi1zdGF0cy9jb2luLXN0YXRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9kZWxlZ2F0aW9ucy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZGVsZWdhdGlvbnMvZGVsZWdhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2VudGVycHJpc2Uvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2VudGVycHJpc2Uvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZW50ZXJwcmlzZS9lbnRlcnByaXNlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9sZWRnZXIvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3JlY29yZHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3JlY29yZHMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcmVjb3Jkcy9yZWNvcmRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zdGF0dXMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc3RhdHVzL3N0YXR1cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdHJhbnNhY3Rpb25zL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90cmFuc2FjdGlvbnMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdHJhbnNhY3Rpb25zL3RyYW5zYWN0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdmFsaWRhdG9ycy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdmFsaWRhdG9ycy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3ZvdGluZy1wb3dlci9oaXN0b3J5LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9ldmlkZW5jZXMvZXZpZGVuY2VzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS92YWxpZGF0b3Itc2V0cy92YWxpZGF0b3Itc2V0cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL2JvdGgvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvY3JlYXRlLWluZGV4ZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvcmVnaXN0ZXItYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyL3V0aWwuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdWkvY29tcG9uZW50cy9JY29ucy5qc3giLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvdXRpbHMvY29pbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIk1ldGVvciIsIm1vZHVsZSIsImxpbmsiLCJ2IiwiSFRUUCIsIlZhbGlkYXRvcnMiLCJmZXRjaEZyb21VcmwiLCJ1cmwiLCJyZXMiLCJnZXQiLCJMQ0QiLCJzdGF0dXNDb2RlIiwiZSIsImNvbnNvbGUiLCJsb2ciLCJtZXRob2RzIiwiYWRkcmVzcyIsInVuYmxvY2siLCJhdmFpbGFibGUiLCJyZXNwb25zZSIsIkpTT04iLCJwYXJzZSIsImNvbnRlbnQiLCJyZXN1bHQiLCJhY2NvdW50IiwidHlwZSIsInZhbHVlIiwiQmFzZVZlc3RpbmdBY2NvdW50IiwiQmFzZUFjY291bnQiLCJhY2NvdW50X251bWJlciIsImJhbGFuY2UiLCJsZW5ndGgiLCJkZWxlZ2F0aW9ucyIsInVuYm9uZGluZyIsInJld2FyZHMiLCJ0b3RhbCIsInZhbGlkYXRvciIsImZpbmRPbmUiLCIkb3IiLCJvcGVyYXRvcl9hZGRyZXNzIiwiZGVsZWdhdG9yX2FkZHJlc3MiLCJ2YWxfY29tbWlzc2lvbiIsImNvbW1pc3Npb24iLCJkYXRhIiwic2hhcmVzIiwicGFyc2VGbG9hdCIsInJlbGVnYXRpb25zIiwiY29tcGxldGlvblRpbWUiLCJmb3JFYWNoIiwicmVsZWdhdGlvbiIsImVudHJpZXMiLCJ0aW1lIiwiRGF0ZSIsImNvbXBsZXRpb25fdGltZSIsInJlZGVsZWdhdGlvbkNvbXBsZXRpb25UaW1lIiwidW5kZWxlZ2F0aW9ucyIsInVuYm9uZGluZ0NvbXBsZXRpb25UaW1lIiwiZGVsZWdhdGlvbiIsImkiLCJ1bmJvbmRpbmdzIiwicmVkZWxlZ2F0aW9ucyIsInJlZGVsZWdhdGlvbiIsInZhbGlkYXRvcl9kc3RfYWRkcmVzcyIsImNvdW50IiwiUHJvbWlzZSIsIkJsb2Nrc2NvbiIsIkNoYWluIiwiVmFsaWRhdG9yU2V0cyIsIlZhbGlkYXRvclJlY29yZHMiLCJBbmFseXRpY3MiLCJWUERpc3RyaWJ1dGlvbnMiLCJWb3RpbmdQb3dlckhpc3RvcnkiLCJUcmFuc2FjdGlvbnMiLCJFdmlkZW5jZXMiLCJzaGEyNTYiLCJnZXRBZGRyZXNzIiwiY2hlZXJpbyIsImdldFJlbW92ZWRWYWxpZGF0b3JzIiwicHJldlZhbGlkYXRvcnMiLCJ2YWxpZGF0b3JzIiwicCIsInNwbGljZSIsImdldFZhbGlkYXRvclByb2ZpbGVVcmwiLCJpZGVudGl0eSIsInRoZW0iLCJwaWN0dXJlcyIsInByaW1hcnkiLCJzdHJpbmdpZnkiLCJpbmRleE9mIiwidGVhbVBhZ2UiLCJwYWdlIiwibG9hZCIsImF0dHIiLCJibG9ja3MiLCJmaW5kIiwicHJvcG9zZXJBZGRyZXNzIiwiZmV0Y2giLCJoZWlnaHRzIiwibWFwIiwiYmxvY2siLCJoZWlnaHQiLCJibG9ja3NTdGF0cyIsIiRpbiIsInRvdGFsQmxvY2tEaWZmIiwiYiIsInRpbWVEaWZmIiwiY29sbGVjdGlvbiIsInJhd0NvbGxlY3Rpb24iLCJwaXBlbGluZSIsIiRtYXRjaCIsIiRzb3J0IiwiJGxpbWl0Iiwic2V0dGluZ3MiLCJwdWJsaWMiLCJ1cHRpbWVXaW5kb3ciLCIkdW53aW5kIiwiJGdyb3VwIiwiJGNvbmQiLCIkZXEiLCJhd2FpdCIsImFnZ3JlZ2F0ZSIsInRvQXJyYXkiLCJSUEMiLCJzdGF0dXMiLCJzeW5jX2luZm8iLCJsYXRlc3RfYmxvY2tfaGVpZ2h0IiwiY3VyckhlaWdodCIsInNvcnQiLCJsaW1pdCIsInN0YXJ0SGVpZ2h0IiwicGFyYW1zIiwiU1lOQ0lORyIsInVudGlsIiwiY2FsbCIsImN1cnIiLCJ2YWxpZGF0b3JTZXQiLCJjb25zZW5zdXNfcHVia2V5IiwidG90YWxWYWxpZGF0b3JzIiwiT2JqZWN0Iiwia2V5cyIsInN0YXJ0QmxvY2tUaW1lIiwiYW5hbHl0aWNzRGF0YSIsImJ1bGtWYWxpZGF0b3JzIiwiaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCIsImJ1bGtWYWxpZGF0b3JSZWNvcmRzIiwiYnVsa1ZQSGlzdG9yeSIsImJ1bGtUcmFuc2F0aW9ucyIsInN0YXJ0R2V0SGVpZ2h0VGltZSIsImJsb2NrRGF0YSIsImhhc2giLCJibG9ja19pZCIsInRyYW5zTnVtIiwidHhzIiwiaGVhZGVyIiwibGFzdEJsb2NrSGFzaCIsImxhc3RfYmxvY2tfaWQiLCJwcm9wb3Nlcl9hZGRyZXNzIiwicHJlY29tbWl0cyIsImxhc3RfY29tbWl0Iiwic2lnbmF0dXJlcyIsInB1c2giLCJ2YWxpZGF0b3JfYWRkcmVzcyIsInQiLCJCdWZmZXIiLCJmcm9tIiwiZXJyIiwiZXZpZGVuY2UiLCJpbnNlcnQiLCJwcmVjb21taXRzQ291bnQiLCJlbmRHZXRIZWlnaHRUaW1lIiwic3RhcnRHZXRWYWxpZGF0b3JzVGltZSIsImJsb2NrX2hlaWdodCIsInBhcnNlSW50IiwidmFsaWRhdG9yc0NvdW50Iiwic3RhcnRCbG9ja0luc2VydFRpbWUiLCJlbmRCbG9ja0luc2VydFRpbWUiLCJleGlzdGluZ1ZhbGlkYXRvcnMiLCIkZXhpc3RzIiwicmVjb3JkIiwiZXhpc3RzIiwidm90aW5nX3Bvd2VyIiwiaiIsIm51bUJsb2NrcyIsInVwdGltZSIsImJhc2UiLCJ1cHNlcnQiLCJ1cGRhdGVPbmUiLCIkc2V0IiwibGFzdFNlZW4iLCJjaGFpblN0YXR1cyIsImNoYWluSWQiLCJjaGFpbl9pZCIsImxhc3RTeW5jZWRUaW1lIiwiYmxvY2tUaW1lIiwiZGVmYXVsdEJsb2NrVGltZSIsImRhdGVMYXRlc3QiLCJkYXRlTGFzdCIsIk1hdGgiLCJhYnMiLCJnZXRUaW1lIiwiZW5kR2V0VmFsaWRhdG9yc1RpbWUiLCJ1cGRhdGUiLCJhdmVyYWdlQmxvY2tUaW1lIiwic3RhcnRGaW5kVmFsaWRhdG9yc05hbWVUaW1lIiwicHJvcG9zZXJfcHJpb3JpdHkiLCJ2YWxFeGlzdCIsInB1Yl9rZXkiLCJhY2NwdWIiLCJiZWNoMzJQcmVmaXhBY2NQdWIiLCJvcGVyYXRvcl9wdWJrZXkiLCJiZWNoMzJQcmVmaXhWYWxQdWIiLCJiZWNoMzJQcmVmaXhDb25zUHViIiwidmFsaWRhdG9yRGF0YSIsImRlc2NyaXB0aW9uIiwicHJvZmlsZV91cmwiLCJqYWlsZWQiLCJtaW5fc2VsZl9kZWxlZ2F0aW9uIiwidG9rZW5zIiwiZGVsZWdhdG9yX3NoYXJlcyIsImJvbmRfaGVpZ2h0IiwiYm9uZF9pbnRyYV90eF9jb3VudGVyIiwidW5ib25kaW5nX2hlaWdodCIsInVuYm9uZGluZ190aW1lIiwic2VsZl9kZWxlZ2F0aW9uIiwicHJldl92b3RpbmdfcG93ZXIiLCJibG9ja190aW1lIiwic2VsZkRlbGVnYXRpb24iLCJwcmV2Vm90aW5nUG93ZXIiLCJjaGFuZ2VUeXBlIiwiY2hhbmdlRGF0YSIsInJlbW92ZWRWYWxpZGF0b3JzIiwiciIsImRiVmFsaWRhdG9ycyIsImZpZWxkcyIsImNvblB1YktleSIsInVuZGVmaW5lZCIsInByb2ZpbGVVcmwiLCJlbmRGaW5kVmFsaWRhdG9yc05hbWVUaW1lIiwic3RhcnRBbmF5dGljc0luc2VydFRpbWUiLCJlbmRBbmFseXRpY3NJbnNlcnRUaW1lIiwic3RhcnRWVXBUaW1lIiwiZXhlY3V0ZSIsImVuZFZVcFRpbWUiLCJzdGFydFZSVGltZSIsImVuZFZSVGltZSIsImFjdGl2ZVZhbGlkYXRvcnMiLCJudW1Ub3BUd2VudHkiLCJjZWlsIiwibnVtQm90dG9tRWlnaHR5IiwidG9wVHdlbnR5UG93ZXIiLCJib3R0b21FaWdodHlQb3dlciIsIm51bVRvcFRoaXJ0eUZvdXIiLCJudW1Cb3R0b21TaXh0eVNpeCIsInRvcFRoaXJ0eUZvdXJQZXJjZW50IiwiYm90dG9tU2l4dHlTaXhQZXJjZW50IiwidnBEaXN0IiwibnVtVmFsaWRhdG9ycyIsInRvdGFsVm90aW5nUG93ZXIiLCJjcmVhdGVBdCIsImVuZEJsb2NrVGltZSIsImxhc3RCbG9ja3NTeW5jZWRUaW1lIiwicHVibGlzaENvbXBvc2l0ZSIsImNoaWxkcmVuIiwiZXhwb3J0IiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwiaGVscGVycyIsInByb3Bvc2VyIiwiQ2hhaW5TdGF0ZXMiLCJmaW5kVm90aW5nUG93ZXIiLCJnZW5WYWxpZGF0b3JzIiwicG93ZXIiLCJjb25zZW5zdXMiLCJyb3VuZF9zdGF0ZSIsInJvdW5kIiwic3RlcCIsInZvdGVkUG93ZXIiLCJ2b3RlcyIsInByZXZvdGVzX2JpdF9hcnJheSIsInNwbGl0Iiwidm90aW5nSGVpZ2h0Iiwidm90aW5nUm91bmQiLCJ2b3RpbmdTdGVwIiwicHJldm90ZXMiLCJjaGFpbiIsIm5vZGVfaW5mbyIsIm5ldHdvcmsiLCJsYXRlc3RCbG9ja0hlaWdodCIsImxhdGVzdEJsb2NrVGltZSIsImxhdGVzdF9ibG9ja190aW1lIiwibGF0ZXN0U3RhdGUiLCJhY3RpdmVWUCIsImFjdGl2ZVZvdGluZ1Bvd2VyIiwiY2hhaW5TdGF0ZXMiLCJib25kaW5nIiwiYm9uZGVkVG9rZW5zIiwiYm9uZGVkX3Rva2VucyIsIm5vdEJvbmRlZFRva2VucyIsIm5vdF9ib25kZWRfdG9rZW5zIiwibWludGluZ0Rlbm9tIiwic3VwcGx5IiwidG90YWxTdXBwbHkiLCJwb29sIiwiY29tbXVuaXR5UG9vbCIsImFtb3VudCIsImRlbm9tIiwiaW5mbGF0aW9uIiwicHJvdmlzaW9ucyIsImFubnVhbFByb3Zpc2lvbnMiLCJjcmVhdGVkIiwicmVhZEdlbmVzaXMiLCJkZWJ1ZyIsImdlbmVzaXNGaWxlIiwiZ2VuZXNpcyIsImRpc3RyIiwiYXBwX3N0YXRlIiwiZGlzdHJpYnV0aW9uIiwiY2hhaW5QYXJhbXMiLCJnZW5lc2lzVGltZSIsImdlbmVzaXNfdGltZSIsImNvbnNlbnN1c1BhcmFtcyIsImNvbnNlbnN1c19wYXJhbXMiLCJhdXRoIiwiYmFuayIsInN0YWtpbmciLCJtaW50IiwiY29tbXVuaXR5VGF4IiwiY29tbXVuaXR5X3RheCIsImJhc2VQcm9wb3NlclJld2FyZCIsImJhc2VfcHJvcG9zZXJfcmV3YXJkIiwiYm9udXNQcm9wb3NlclJld2FyZCIsImJvbnVzX3Byb3Bvc2VyX3Jld2FyZCIsIndpdGhkcmF3QWRkckVuYWJsZWQiLCJ3aXRoZHJhd19hZGRyX2VuYWJsZWQiLCJnb3YiLCJzbGFzaGluZyIsImNyaXNpcyIsImdlbnV0aWwiLCJnZW50eHMiLCJtc2ciLCJtIiwicHVia2V5IiwiZmxvb3IiLCJzdGFraW5nRnJhY3Rpb24iLCJwdWJrZXlWYWx1ZSIsImdlblZhbGlkYXRvcnNTZXQiLCJDb2luU3RhdHMiLCJwdWJsaXNoIiwibGFzdF91cGRhdGVkX2F0IiwiY29pbklkIiwiY29pbmdlY2tvSWQiLCJub3ciLCJzZXRNaW51dGVzIiwiRGVsZWdhdGlvbnMiLCJjb25jYXQiLCJjcmVhdGVkQXQiLCJFbnRlcnByaXNlIiwicHVyY2hhc2VPcmRlcnMiLCJmaW5pc2hlZFB1cmNoYXNlT3JkZXJzIiwiU2V0IiwicG9JZCIsInBvSWRzIiwiYnVsa1BvcyIsInBvIiwiaWQiLCJoYXMiLCJjaGVjayIsIk51bWJlciIsIl9vYmplY3RTcHJlYWQiLCJkZWZhdWx0IiwidHhJbmZvIiwidGltZXN0YW1wIiwicG9zdCIsImNvZGUiLCJFcnJvciIsInJhd19sb2ciLCJtZXNzYWdlIiwidHhoYXNoIiwiYm9keSIsInBhdGgiLCJ0eE1zZyIsImFkanVzdG1lbnQiLCJnYXNfZXN0aW1hdGUiLCJBdmVyYWdlRGF0YSIsIkF2ZXJhZ2VWYWxpZGF0b3JEYXRhIiwiU3RhdHVzIiwiTWlzc2VkQmxvY2tzU3RhdHMiLCJNaXNzZWRCbG9ja3MiLCJfIiwiQlVMS1VQREFURU1BWFNJWkUiLCJnZXRCbG9ja1N0YXRzIiwibGF0ZXN0SGVpZ2h0IiwiYmxvY2tTdGF0cyIsImNvbmQiLCIkYW5kIiwiJGd0IiwiJGx0ZSIsIm9wdGlvbnMiLCJhc3NpZ24iLCJnZXRQcmV2aW91c1JlY29yZCIsInZvdGVyQWRkcmVzcyIsInByZXZpb3VzUmVjb3JkIiwidm90ZXIiLCJibG9ja0hlaWdodCIsImxhc3RVcGRhdGVkSGVpZ2h0IiwicHJldlN0YXRzIiwicGljayIsIm1pc3NDb3VudCIsInRvdGFsQ291bnQiLCJDT1VOVE1JU1NFREJMT0NLUyIsInN0YXJ0VGltZSIsImV4cGxvcmVyU3RhdHVzIiwibGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrSGVpZ2h0IiwibWluIiwiYnVsa01pc3NlZFN0YXRzIiwiaW5pdGlhbGl6ZU9yZGVyZWRCdWxrT3AiLCJ2YWxpZGF0b3JzTWFwIiwicHJvcG9zZXJWb3RlclN0YXRzIiwidm90ZWRWYWxpZGF0b3JzIiwidmFsaWRhdG9yU2V0cyIsInZvdGVkVm90aW5nUG93ZXIiLCJhY3RpdmVWYWxpZGF0b3IiLCJjdXJyZW50VmFsaWRhdG9yIiwic2V0IiwibiIsInZvdGluZ1Bvd2VyIiwidXBkYXRlZEF0Iiwidm90ZXJzIiwic3RhdHMiLCJjbGllbnQiLCJfZHJpdmVyIiwibW9uZ28iLCJidWxrUHJvbWlzZSIsInRoZW4iLCJiaW5kRW52aXJvbm1lbnQiLCJuSW5zZXJ0ZWQiLCJuVXBzZXJ0ZWQiLCJuTW9kaWZpZWQiLCJsYXN0UHJvY2Vzc2VkTWlzc2VkQmxvY2tUaW1lIiwiQ09VTlRNSVNTRURCTE9DS1NTVEFUUyIsImxhc3RNaXNzZWRCbG9ja0hlaWdodCIsIm1pc3NlZFJlY29yZHMiLCJjb3VudHMiLCJleGlzdGluZ1JlY29yZCIsImxhc3RNaXNzZWRCbG9ja1RpbWUiLCJhdmVyYWdlVm90aW5nUG93ZXIiLCJhbmFseXRpY3MiLCJsYXN0TWludXRlVm90aW5nUG93ZXIiLCJsYXN0TWludXRlQmxvY2tUaW1lIiwibGFzdEhvdXJWb3RpbmdQb3dlciIsImxhc3RIb3VyQmxvY2tUaW1lIiwibGFzdERheVZvdGluZ1Bvd2VyIiwibGFzdERheUJsb2NrVGltZSIsImJsb2NrSGVpZ2h0cyIsImEiLCJudW0iLCJjb25kaXRpb25zIiwicHJvcG9zZXJNb25pa2VyIiwibW9uaWtlciIsInZvdGVyTW9uaWtlciIsIkFkZHJlc3NMZW5ndGgiLCJ0b1VwcGVyQ2FzZSIsInR4IiwidHhJZCIsIiRsdCIsImluY2x1ZGVzIiwiYmVjaDMyUHJlZml4VmFsQWRkciIsImJlY2gzMlByZWZpeEFjY0FkZHIiLCJ2YWxpZGF0b3JBZGRyZXNzIiwiZGVsZWdhdG9yQWRkcmVzcyIsInF1ZXJ5IiwiVHhJY29uIiwiZGlyZWN0aW9uIiwidmFsIiwiZmlyc3RTZWVuIiwiaGlzdG9yeSIsImNyZWF0ZUluZGV4IiwidW5pcXVlIiwicGFydGlhbEZpbHRlckV4cHJlc3Npb24iLCJvblBhZ2VMb2FkIiwiSGVsbWV0Iiwic2luayIsImhlbG1ldCIsInJlbmRlclN0YXRpYyIsImFwcGVuZFRvSGVhZCIsIm1ldGEiLCJ0b1N0cmluZyIsInRpdGxlIiwiYmVjaDMyIiwiRnV0dXJlIiwiTnBtIiwicmVxdWlyZSIsImV4ZWMiLCJ0b0hleFN0cmluZyIsImJ5dGVBcnJheSIsImJ5dGUiLCJzbGljZSIsImpvaW4iLCJwdWJrZXlUb0JlY2gzMiIsInByZWZpeCIsInB1YmtleUFtaW5vUHJlZml4IiwiYnVmZmVyIiwiYWxsb2MiLCJjb3B5IiwiZW5jb2RlIiwidG9Xb3JkcyIsImJlY2gzMlRvUHVia2V5IiwiZnJvbVdvcmRzIiwiZGVjb2RlIiwid29yZHMiLCJnZXREZWxlZ2F0b3IiLCJvcGVyYXRvckFkZHIiLCJnZXRLZXliYXNlVGVhbVBpYyIsImtleWJhc2VVcmwiLCJEZW5vbVN5bWJvbCIsIlByb3Bvc2FsU3RhdHVzSWNvbiIsIlZvdGVJY29uIiwiSW5mb0ljb24iLCJSZWFjdCIsIlVuY29udHJvbGxlZFRvb2x0aXAiLCJwcm9wcyIsInZvdGUiLCJ2YWxpZCIsIkNvbXBvbmVudCIsImNvbnN0cnVjdG9yIiwicmVmIiwiY3JlYXRlUmVmIiwicmVuZGVyIiwidG9vbHRpcFRleHQiLCJDb2luIiwibnVtYnJvIiwiYXV0b2Zvcm1hdCIsImZvcm1hdHRlciIsImZvcm1hdCIsInRvTG93ZXJDYXNlIiwiTWludGluZ0Rlbm9tIiwiX2Ftb3VudCIsIlN0YWtpbmdEZW5vbSIsIlN0YWtpbmdGcmFjdGlvbiIsInN0YWtpbmdBbW91bnQiLCJwcmVjaXNpb24iLCJtaW5TdGFrZSIsInBvdyIsInJlcGVhdCIsIm1pbnRTdHJpbmciLCJzdGFrZVN0cmluZyIsInN0YWtpbmdEZW5vbSIsIlN0YWtpbmdEZW5vbVBsdXJhbCIsInN0YWtpbmdEZW5vbVBsdXJhbCIsIk1pblN0YWtlIiwicmVtb3RlIiwicnBjIiwibGNkIiwidGltZXJCbG9ja3MiLCJ0aW1lckNoYWluIiwidGltZXJDb25zZW5zdXMiLCJ0aW1lclByb3Bvc2FsIiwidGltZXJQcm9wb3NhbHNSZXN1bHRzIiwidGltZXJNaXNzZWRCbG9jayIsInRpbWVyRGVsZWdhdGlvbiIsInRpbWVyQWdncmVnYXRlIiwiREVGQVVMVFNFVFRJTkdTIiwidXBkYXRlQ2hhaW5TdGF0dXMiLCJlcnJvciIsInVwZGF0ZUJsb2NrIiwiZ2V0Q29uc2Vuc3VzU3RhdGUiLCJnZXRQdXJjaGFzZU9yZGVycyIsInVwZGF0ZU1pc3NlZEJsb2NrcyIsImdldERlbGVnYXRpb25zIiwiYWdncmVnYXRlTWludXRlbHkiLCJhZ2dyZWdhdGVIb3VybHkiLCJhZ2dyZWdhdGVEYWlseSIsInN0YXJ0dXAiLCJpc0RldmVsb3BtZW50IiwiREVGQVVMVFNFVFRJTkdTSlNPTiIsInByb2Nlc3MiLCJlbnYiLCJOT0RFX1RMU19SRUpFQ1RfVU5BVVRIT1JJWkVEIiwia2V5Iiwid2FybiIsInBhcmFtIiwic3RhcnRUaW1lciIsInNldEludGVydmFsIiwiY29uc2Vuc3VzSW50ZXJ2YWwiLCJibG9ja0ludGVydmFsIiwic3RhdHVzSW50ZXJ2YWwiLCJ0aW1lclB1cmNoYXNlT3JkZXIiLCJwcm9wb3NhbEludGVydmFsIiwibWlzc2VkQmxvY2tzSW50ZXJ2YWwiLCJkZWxlZ2F0aW9uSW50ZXJ2YWwiLCJnZXRVVENTZWNvbmRzIiwiZ2V0VVRDTWludXRlcyIsImdldFVUQ0hvdXJzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUErQyxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVDQUFaLEVBQW9EO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUFwRCxFQUFrRixDQUFsRjs7QUFHdkksTUFBTUcsWUFBWSxHQUFJQyxHQUFELElBQVM7QUFDMUIsTUFBRztBQUNDLFFBQUlDLEdBQUcsR0FBR0osSUFBSSxDQUFDSyxHQUFMLENBQVNDLEdBQUcsR0FBR0gsR0FBZixDQUFWOztBQUNBLFFBQUlDLEdBQUcsQ0FBQ0csVUFBSixJQUFrQixHQUF0QixFQUEwQjtBQUN0QixhQUFPSCxHQUFQO0FBQ0g7O0FBQUE7QUFDSixHQUxELENBTUEsT0FBT0ksQ0FBUCxFQUFTO0FBQ0xDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixDQVZEOztBQVlBWixNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLCtCQUE2QixVQUFTQyxPQUFULEVBQWlCO0FBQzFDLFNBQUtDLE9BQUw7QUFDQSxRQUFJVixHQUFHLEdBQUdHLEdBQUcsR0FBRyxpQkFBTixHQUF5Qk0sT0FBbkM7O0FBQ0EsUUFBRztBQUNDLFVBQUlFLFNBQVMsR0FBR2QsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBaEI7O0FBQ0EsVUFBSVcsU0FBUyxDQUFDUCxVQUFWLElBQXdCLEdBQTVCLEVBQWdDO0FBQzVCLFlBQUlRLFFBQVEsR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdILFNBQVMsQ0FBQ0ksT0FBckIsRUFBOEJDLE1BQTdDO0FBQ0EsWUFBSUMsT0FBSjtBQUNBLFlBQUlMLFFBQVEsQ0FBQ00sSUFBVCxLQUFrQixvQkFBdEIsRUFDSUQsT0FBTyxHQUFHTCxRQUFRLENBQUNPLEtBQW5CLENBREosS0FFSyxJQUFJUCxRQUFRLENBQUNNLElBQVQsS0FBa0Isa0NBQWxCLElBQXdETixRQUFRLENBQUNNLElBQVQsS0FBa0IscUNBQTlFLEVBQ0RELE9BQU8sR0FBR0wsUUFBUSxDQUFDTyxLQUFULENBQWVDLGtCQUFmLENBQWtDQyxXQUE1QztBQUNKLFlBQUlKLE9BQU8sSUFBSUEsT0FBTyxDQUFDSyxjQUFSLElBQTBCLElBQXpDLEVBQ0ksT0FBT0wsT0FBUDtBQUNKLGVBQU8sSUFBUDtBQUNIO0FBQ0osS0FiRCxDQWNBLE9BQU9aLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osR0FyQlU7QUFzQlgseUJBQXVCLFVBQVNJLE9BQVQsRUFBaUI7QUFDcEMsU0FBS0MsT0FBTDtBQUNBLFFBQUlhLE9BQU8sR0FBRyxFQUFkLENBRm9DLENBSXBDOztBQUNBLFFBQUl2QixHQUFHLEdBQUdHLEdBQUcsR0FBRyxpQkFBTixHQUF5Qk0sT0FBbkM7O0FBQ0EsUUFBRztBQUNDLFVBQUlFLFNBQVMsR0FBR2QsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBaEI7O0FBQ0EsVUFBSVcsU0FBUyxDQUFDUCxVQUFWLElBQXdCLEdBQTVCLEVBQWdDO0FBQzVCO0FBQ0FtQixlQUFPLENBQUNaLFNBQVIsR0FBb0JFLElBQUksQ0FBQ0MsS0FBTCxDQUFXSCxTQUFTLENBQUNJLE9BQXJCLEVBQThCQyxNQUFsRDtBQUNBLFlBQUlPLE9BQU8sQ0FBQ1osU0FBUixJQUFxQlksT0FBTyxDQUFDWixTQUFSLENBQWtCYSxNQUFsQixHQUEyQixDQUFwRCxFQUNJRCxPQUFPLENBQUNaLFNBQVIsR0FBb0JZLE9BQU8sQ0FBQ1osU0FBUixDQUFrQixDQUFsQixDQUFwQjtBQUNQO0FBQ0osS0FSRCxDQVNBLE9BQU9OLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNILEtBakJtQyxDQW1CcEM7OztBQUNBTCxPQUFHLEdBQUdHLEdBQUcsR0FBRyxzQkFBTixHQUE2Qk0sT0FBN0IsR0FBcUMsY0FBM0M7O0FBQ0EsUUFBRztBQUNDLFVBQUlnQixXQUFXLEdBQUc1QixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFsQjs7QUFDQSxVQUFJeUIsV0FBVyxDQUFDckIsVUFBWixJQUEwQixHQUE5QixFQUFrQztBQUM5Qm1CLGVBQU8sQ0FBQ0UsV0FBUixHQUFzQlosSUFBSSxDQUFDQyxLQUFMLENBQVdXLFdBQVcsQ0FBQ1YsT0FBdkIsRUFBZ0NDLE1BQXREO0FBQ0g7QUFDSixLQUxELENBTUEsT0FBT1gsQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0gsS0E3Qm1DLENBOEJwQzs7O0FBQ0FMLE9BQUcsR0FBR0csR0FBRyxHQUFHLHNCQUFOLEdBQTZCTSxPQUE3QixHQUFxQyx3QkFBM0M7O0FBQ0EsUUFBRztBQUNDLFVBQUlpQixTQUFTLEdBQUc3QixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFoQjs7QUFDQSxVQUFJMEIsU0FBUyxDQUFDdEIsVUFBVixJQUF3QixHQUE1QixFQUFnQztBQUM1Qm1CLGVBQU8sQ0FBQ0csU0FBUixHQUFvQmIsSUFBSSxDQUFDQyxLQUFMLENBQVdZLFNBQVMsQ0FBQ1gsT0FBckIsRUFBOEJDLE1BQWxEO0FBQ0g7QUFDSixLQUxELENBTUEsT0FBT1gsQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0gsS0F4Q21DLENBMENwQzs7O0FBQ0FMLE9BQUcsR0FBR0csR0FBRyxHQUFHLDJCQUFOLEdBQWtDTSxPQUFsQyxHQUEwQyxVQUFoRDs7QUFDQSxRQUFHO0FBQ0MsVUFBSWtCLE9BQU8sR0FBRzlCLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWQ7O0FBQ0EsVUFBSTJCLE9BQU8sQ0FBQ3ZCLFVBQVIsSUFBc0IsR0FBMUIsRUFBOEI7QUFDMUJtQixlQUFPLENBQUNJLE9BQVIsR0FBa0JkLElBQUksQ0FBQ0MsS0FBTCxDQUFXYSxPQUFPLENBQUNaLE9BQW5CLEVBQTRCQyxNQUE1QixDQUFtQ1ksS0FBckQ7QUFDSDtBQUNKLEtBTEQsQ0FNQSxPQUFPdkIsQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0gsS0FwRG1DLENBc0RwQzs7O0FBQ0EsUUFBSXdCLFNBQVMsR0FBRy9CLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FDWjtBQUFDQyxTQUFHLEVBQUUsQ0FBQztBQUFDQyx3QkFBZ0IsRUFBQ3ZCO0FBQWxCLE9BQUQsRUFBNkI7QUFBQ3dCLHlCQUFpQixFQUFDeEI7QUFBbkIsT0FBN0IsRUFBMEQ7QUFBQ0EsZUFBTyxFQUFDQTtBQUFULE9BQTFEO0FBQU4sS0FEWSxDQUFoQjs7QUFFQSxRQUFJb0IsU0FBSixFQUFlO0FBQ1gsVUFBSTdCLEdBQUcsR0FBR0csR0FBRyxHQUFHLDJCQUFOLEdBQW9DMEIsU0FBUyxDQUFDRyxnQkFBeEQ7QUFDQVQsYUFBTyxDQUFDUyxnQkFBUixHQUEyQkgsU0FBUyxDQUFDRyxnQkFBckM7O0FBQ0EsVUFBSTtBQUNBLFlBQUlMLE9BQU8sR0FBRzlCLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWQ7O0FBQ0EsWUFBSTJCLE9BQU8sQ0FBQ3ZCLFVBQVIsSUFBc0IsR0FBMUIsRUFBOEI7QUFDMUIsY0FBSVcsT0FBTyxHQUFHRixJQUFJLENBQUNDLEtBQUwsQ0FBV2EsT0FBTyxDQUFDWixPQUFuQixFQUE0QkMsTUFBMUM7QUFDQSxjQUFJRCxPQUFPLENBQUNtQixjQUFSLElBQTBCbkIsT0FBTyxDQUFDbUIsY0FBUixDQUF1QlYsTUFBdkIsR0FBZ0MsQ0FBOUQsRUFDSUQsT0FBTyxDQUFDWSxVQUFSLEdBQXFCcEIsT0FBTyxDQUFDbUIsY0FBUixDQUF1QixDQUF2QixDQUFyQjtBQUNQO0FBRUosT0FSRCxDQVNBLE9BQU83QixDQUFQLEVBQVM7QUFDTEMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKOztBQUVELFdBQU9rQixPQUFQO0FBQ0gsR0FqR1U7O0FBa0dYLDJCQUF5QmQsT0FBekIsRUFBa0NvQixTQUFsQyxFQUE0QztBQUN4QyxRQUFJN0IsR0FBRyxpQ0FBMEJTLE9BQTFCLDBCQUFpRG9CLFNBQWpELENBQVA7QUFDQSxRQUFJSixXQUFXLEdBQUcxQixZQUFZLENBQUNDLEdBQUQsQ0FBOUI7QUFDQXlCLGVBQVcsR0FBR0EsV0FBVyxJQUFJQSxXQUFXLENBQUNXLElBQVosQ0FBaUJwQixNQUE5QztBQUNBLFFBQUlTLFdBQVcsSUFBSUEsV0FBVyxDQUFDWSxNQUEvQixFQUNJWixXQUFXLENBQUNZLE1BQVosR0FBcUJDLFVBQVUsQ0FBQ2IsV0FBVyxDQUFDWSxNQUFiLENBQS9CO0FBRUpyQyxPQUFHLDhDQUF1Q1MsT0FBdkMsMkJBQStEb0IsU0FBL0QsQ0FBSDtBQUNBLFFBQUlVLFdBQVcsR0FBR3hDLFlBQVksQ0FBQ0MsR0FBRCxDQUE5QjtBQUNBdUMsZUFBVyxHQUFHQSxXQUFXLElBQUlBLFdBQVcsQ0FBQ0gsSUFBWixDQUFpQnBCLE1BQTlDO0FBQ0EsUUFBSXdCLGNBQUo7O0FBQ0EsUUFBSUQsV0FBSixFQUFpQjtBQUNiQSxpQkFBVyxDQUFDRSxPQUFaLENBQXFCQyxVQUFELElBQWdCO0FBQ2hDLFlBQUlDLE9BQU8sR0FBR0QsVUFBVSxDQUFDQyxPQUF6QjtBQUNBLFlBQUlDLElBQUksR0FBRyxJQUFJQyxJQUFKLENBQVNGLE9BQU8sQ0FBQ0EsT0FBTyxDQUFDbkIsTUFBUixHQUFlLENBQWhCLENBQVAsQ0FBMEJzQixlQUFuQyxDQUFYO0FBQ0EsWUFBSSxDQUFDTixjQUFELElBQW1CSSxJQUFJLEdBQUdKLGNBQTlCLEVBQ0lBLGNBQWMsR0FBR0ksSUFBakI7QUFDUCxPQUxEO0FBTUFuQixpQkFBVyxDQUFDc0IsMEJBQVosR0FBeUNQLGNBQXpDO0FBQ0g7O0FBRUR4QyxPQUFHLGlDQUEwQlMsT0FBMUIsb0NBQTJEb0IsU0FBM0QsQ0FBSDtBQUNBLFFBQUltQixhQUFhLEdBQUdqRCxZQUFZLENBQUNDLEdBQUQsQ0FBaEM7QUFDQWdELGlCQUFhLEdBQUdBLGFBQWEsSUFBSUEsYUFBYSxDQUFDWixJQUFkLENBQW1CcEIsTUFBcEQ7O0FBQ0EsUUFBSWdDLGFBQUosRUFBbUI7QUFDZnZCLGlCQUFXLENBQUNDLFNBQVosR0FBd0JzQixhQUFhLENBQUNMLE9BQWQsQ0FBc0JuQixNQUE5QztBQUNBQyxpQkFBVyxDQUFDd0IsdUJBQVosR0FBc0NELGFBQWEsQ0FBQ0wsT0FBZCxDQUFzQixDQUF0QixFQUF5QkcsZUFBL0Q7QUFDSDs7QUFDRCxXQUFPckIsV0FBUDtBQUNILEdBL0hVOztBQWdJWCwrQkFBNkJoQixPQUE3QixFQUFxQztBQUNqQyxRQUFJVCxHQUFHLEdBQUdHLEdBQUcsR0FBRyxzQkFBTixHQUE2Qk0sT0FBN0IsR0FBcUMsY0FBL0M7O0FBRUEsUUFBRztBQUNDLFVBQUlnQixXQUFXLEdBQUc1QixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFsQjs7QUFDQSxVQUFJeUIsV0FBVyxDQUFDckIsVUFBWixJQUEwQixHQUE5QixFQUFrQztBQUM5QnFCLG1CQUFXLEdBQUdaLElBQUksQ0FBQ0MsS0FBTCxDQUFXVyxXQUFXLENBQUNWLE9BQXZCLEVBQWdDQyxNQUE5Qzs7QUFDQSxZQUFJUyxXQUFXLElBQUlBLFdBQVcsQ0FBQ0QsTUFBWixHQUFxQixDQUF4QyxFQUEwQztBQUN0Q0MscUJBQVcsQ0FBQ2dCLE9BQVosQ0FBb0IsQ0FBQ1MsVUFBRCxFQUFhQyxDQUFiLEtBQW1CO0FBQ25DLGdCQUFJMUIsV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLElBQWtCMUIsV0FBVyxDQUFDMEIsQ0FBRCxDQUFYLENBQWVkLE1BQXJDLEVBQ0laLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxDQUFlZCxNQUFmLEdBQXdCQyxVQUFVLENBQUNiLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxDQUFlZCxNQUFoQixDQUFsQztBQUNQLFdBSEQ7QUFJSDs7QUFFRCxlQUFPWixXQUFQO0FBQ0g7O0FBQUE7QUFDSixLQWJELENBY0EsT0FBT3BCLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osR0FwSlU7O0FBcUpYLDhCQUE0QkksT0FBNUIsRUFBb0M7QUFDaEMsUUFBSVQsR0FBRyxHQUFHRyxHQUFHLEdBQUcsc0JBQU4sR0FBNkJNLE9BQTdCLEdBQXFDLHdCQUEvQzs7QUFFQSxRQUFHO0FBQ0MsVUFBSTJDLFVBQVUsR0FBR3ZELElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWpCOztBQUNBLFVBQUlvRCxVQUFVLENBQUNoRCxVQUFYLElBQXlCLEdBQTdCLEVBQWlDO0FBQzdCZ0Qsa0JBQVUsR0FBR3ZDLElBQUksQ0FBQ0MsS0FBTCxDQUFXc0MsVUFBVSxDQUFDckMsT0FBdEIsRUFBK0JDLE1BQTVDO0FBQ0EsZUFBT29DLFVBQVA7QUFDSDs7QUFBQTtBQUNKLEtBTkQsQ0FPQSxPQUFPL0MsQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixHQWxLVTs7QUFtS1gsaUNBQStCSSxPQUEvQixFQUF3Q29CLFNBQXhDLEVBQWtEO0FBQzlDLFFBQUk3QixHQUFHLDhDQUF1Q1MsT0FBdkMsNkJBQWlFb0IsU0FBakUsQ0FBUDtBQUNBLFFBQUliLE1BQU0sR0FBR2pCLFlBQVksQ0FBQ0MsR0FBRCxDQUF6Qjs7QUFDQSxRQUFJZ0IsTUFBTSxJQUFJQSxNQUFNLENBQUNvQixJQUFyQixFQUEyQjtBQUN2QixVQUFJaUIsYUFBYSxHQUFHLEVBQXBCO0FBQ0FyQyxZQUFNLENBQUNvQixJQUFQLENBQVlLLE9BQVosQ0FBcUJhLFlBQUQsSUFBa0I7QUFDbEMsWUFBSVgsT0FBTyxHQUFHVyxZQUFZLENBQUNYLE9BQTNCO0FBQ0FVLHFCQUFhLENBQUNDLFlBQVksQ0FBQ0MscUJBQWQsQ0FBYixHQUFvRDtBQUNoREMsZUFBSyxFQUFFYixPQUFPLENBQUNuQixNQURpQztBQUVoRGdCLHdCQUFjLEVBQUVHLE9BQU8sQ0FBQyxDQUFELENBQVAsQ0FBV0c7QUFGcUIsU0FBcEQ7QUFJSCxPQU5EO0FBT0EsYUFBT08sYUFBUDtBQUNIO0FBQ0o7O0FBakxVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNmQSxJQUFJNUQsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUk2RCxPQUFKO0FBQVkvRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDOEQsU0FBTyxDQUFDN0QsQ0FBRCxFQUFHO0FBQUM2RCxXQUFPLEdBQUM3RCxDQUFSO0FBQVU7O0FBQXRCLENBQTdCLEVBQXFELENBQXJEO0FBQXdELElBQUk4RCxTQUFKO0FBQWNoRSxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQkFBWixFQUE0QztBQUFDK0QsV0FBUyxDQUFDOUQsQ0FBRCxFQUFHO0FBQUM4RCxhQUFTLEdBQUM5RCxDQUFWO0FBQVk7O0FBQTFCLENBQTVDLEVBQXdFLENBQXhFO0FBQTJFLElBQUkrRCxLQUFKO0FBQVVqRSxNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDZ0UsT0FBSyxDQUFDL0QsQ0FBRCxFQUFHO0FBQUMrRCxTQUFLLEdBQUMvRCxDQUFOO0FBQVE7O0FBQWxCLENBQTFDLEVBQThELENBQTlEO0FBQWlFLElBQUlnRSxhQUFKO0FBQWtCbEUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0NBQVosRUFBNEQ7QUFBQ2lFLGVBQWEsQ0FBQ2hFLENBQUQsRUFBRztBQUFDZ0UsaUJBQWEsR0FBQ2hFLENBQWQ7QUFBZ0I7O0FBQWxDLENBQTVELEVBQWdHLENBQWhHO0FBQW1HLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksdUNBQVosRUFBb0Q7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQXBELEVBQWtGLENBQWxGO0FBQXFGLElBQUlpRSxnQkFBSixFQUFxQkMsU0FBckIsRUFBK0JDLGVBQS9CO0FBQStDckUsTUFBTSxDQUFDQyxJQUFQLENBQVksaUNBQVosRUFBOEM7QUFBQ2tFLGtCQUFnQixDQUFDakUsQ0FBRCxFQUFHO0FBQUNpRSxvQkFBZ0IsR0FBQ2pFLENBQWpCO0FBQW1CLEdBQXhDOztBQUF5Q2tFLFdBQVMsQ0FBQ2xFLENBQUQsRUFBRztBQUFDa0UsYUFBUyxHQUFDbEUsQ0FBVjtBQUFZLEdBQWxFOztBQUFtRW1FLGlCQUFlLENBQUNuRSxDQUFELEVBQUc7QUFBQ21FLG1CQUFlLEdBQUNuRSxDQUFoQjtBQUFrQjs7QUFBeEcsQ0FBOUMsRUFBd0osQ0FBeEo7QUFBMkosSUFBSW9FLGtCQUFKO0FBQXVCdEUsTUFBTSxDQUFDQyxJQUFQLENBQVksc0NBQVosRUFBbUQ7QUFBQ3FFLG9CQUFrQixDQUFDcEUsQ0FBRCxFQUFHO0FBQUNvRSxzQkFBa0IsR0FBQ3BFLENBQW5CO0FBQXFCOztBQUE1QyxDQUFuRCxFQUFpRyxDQUFqRztBQUFvRyxJQUFJcUUsWUFBSjtBQUFpQnZFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUNzRSxjQUFZLENBQUNyRSxDQUFELEVBQUc7QUFBQ3FFLGdCQUFZLEdBQUNyRSxDQUFiO0FBQWU7O0FBQWhDLENBQWpELEVBQW1GLENBQW5GO0FBQXNGLElBQUlzRSxTQUFKO0FBQWN4RSxNQUFNLENBQUNDLElBQVAsQ0FBWSw4QkFBWixFQUEyQztBQUFDdUUsV0FBUyxDQUFDdEUsQ0FBRCxFQUFHO0FBQUNzRSxhQUFTLEdBQUN0RSxDQUFWO0FBQVk7O0FBQTFCLENBQTNDLEVBQXVFLEVBQXZFO0FBQTJFLElBQUl1RSxNQUFKO0FBQVd6RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUN3RSxRQUFNLENBQUN2RSxDQUFELEVBQUc7QUFBQ3VFLFVBQU0sR0FBQ3ZFLENBQVA7QUFBUzs7QUFBcEIsQ0FBeEIsRUFBOEMsRUFBOUM7QUFBa0QsSUFBSXdFLFVBQUo7QUFBZTFFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVCQUFaLEVBQW9DO0FBQUN5RSxZQUFVLENBQUN4RSxDQUFELEVBQUc7QUFBQ3dFLGNBQVUsR0FBQ3hFLENBQVg7QUFBYTs7QUFBNUIsQ0FBcEMsRUFBa0UsRUFBbEU7QUFBc0UsSUFBSXlFLE9BQUo7QUFBWTNFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFNBQVosRUFBc0I7QUFBQyxNQUFJQyxDQUFKLEVBQU07QUFBQ3lFLFdBQU8sR0FBQ3pFLENBQVI7QUFBVTs7QUFBbEIsQ0FBdEIsRUFBMEMsRUFBMUM7O0FBZTV0QztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEwRSxvQkFBb0IsR0FBRyxDQUFDQyxjQUFELEVBQWlCQyxVQUFqQixLQUFnQztBQUNuRDtBQUNBLE9BQUtDLENBQUwsSUFBVUYsY0FBVixFQUF5QjtBQUNyQixTQUFLM0UsQ0FBTCxJQUFVNEUsVUFBVixFQUFxQjtBQUNqQixVQUFJRCxjQUFjLENBQUNFLENBQUQsQ0FBZCxDQUFrQmhFLE9BQWxCLElBQTZCK0QsVUFBVSxDQUFDNUUsQ0FBRCxDQUFWLENBQWNhLE9BQS9DLEVBQXVEO0FBQ25EOEQsc0JBQWMsQ0FBQ0csTUFBZixDQUFzQkQsQ0FBdEIsRUFBd0IsQ0FBeEI7QUFDSDtBQUNKO0FBQ0o7O0FBRUQsU0FBT0YsY0FBUDtBQUNILENBWEQ7O0FBYUFJLHNCQUFzQixHQUFJQyxRQUFELElBQWM7QUFDbkMsTUFBSUEsUUFBUSxDQUFDcEQsTUFBVCxJQUFtQixFQUF2QixFQUEwQjtBQUN0QixRQUFJWixRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxvRUFBcUUwRSxRQUFyRSxzQkFBZjs7QUFDQSxRQUFJaEUsUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQWdDO0FBQzVCLFVBQUl5RSxJQUFJLEdBQUdqRSxRQUFRLENBQUN3QixJQUFULENBQWN5QyxJQUF6QjtBQUNBLGFBQU9BLElBQUksSUFBSUEsSUFBSSxDQUFDckQsTUFBYixJQUF1QnFELElBQUksQ0FBQyxDQUFELENBQUosQ0FBUUMsUUFBL0IsSUFBMkNELElBQUksQ0FBQyxDQUFELENBQUosQ0FBUUMsUUFBUixDQUFpQkMsT0FBNUQsSUFBdUVGLElBQUksQ0FBQyxDQUFELENBQUosQ0FBUUMsUUFBUixDQUFpQkMsT0FBakIsQ0FBeUIvRSxHQUF2RztBQUNILEtBSEQsTUFHTztBQUNITSxhQUFPLENBQUNDLEdBQVIsQ0FBWU0sSUFBSSxDQUFDbUUsU0FBTCxDQUFlcEUsUUFBZixDQUFaO0FBQ0g7QUFDSixHQVJELE1BUU8sSUFBSWdFLFFBQVEsQ0FBQ0ssT0FBVCxDQUFpQixrQkFBakIsSUFBcUMsQ0FBekMsRUFBMkM7QUFDOUMsUUFBSUMsUUFBUSxHQUFHckYsSUFBSSxDQUFDSyxHQUFMLENBQVMwRSxRQUFULENBQWY7O0FBQ0EsUUFBSU0sUUFBUSxDQUFDOUUsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQixVQUFJK0UsSUFBSSxHQUFHZCxPQUFPLENBQUNlLElBQVIsQ0FBYUYsUUFBUSxDQUFDbkUsT0FBdEIsQ0FBWDtBQUNBLGFBQU9vRSxJQUFJLENBQUMsbUJBQUQsQ0FBSixDQUEwQkUsSUFBMUIsQ0FBK0IsS0FBL0IsQ0FBUDtBQUNILEtBSEQsTUFHTztBQUNIL0UsYUFBTyxDQUFDQyxHQUFSLENBQVlNLElBQUksQ0FBQ21FLFNBQUwsQ0FBZUUsUUFBZixDQUFaO0FBQ0g7QUFDSjtBQUNKLENBbEJELEMsQ0FvQkE7QUFDQTs7O0FBRUF6RixNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLDRCQUEwQkMsT0FBMUIsRUFBa0M7QUFDOUIsUUFBSTZFLE1BQU0sR0FBRzVCLFNBQVMsQ0FBQzZCLElBQVYsQ0FBZTtBQUFDQyxxQkFBZSxFQUFDL0U7QUFBakIsS0FBZixFQUEwQ2dGLEtBQTFDLEVBQWI7QUFDQSxRQUFJQyxPQUFPLEdBQUdKLE1BQU0sQ0FBQ0ssR0FBUCxDQUFXLENBQUNDLEtBQUQsRUFBUXpDLENBQVIsS0FBYztBQUNuQyxhQUFPeUMsS0FBSyxDQUFDQyxNQUFiO0FBQ0gsS0FGYSxDQUFkO0FBR0EsUUFBSUMsV0FBVyxHQUFHaEMsU0FBUyxDQUFDeUIsSUFBVixDQUFlO0FBQUNNLFlBQU0sRUFBQztBQUFDRSxXQUFHLEVBQUNMO0FBQUw7QUFBUixLQUFmLEVBQXVDRCxLQUF2QyxFQUFsQixDQUw4QixDQU05Qjs7QUFFQSxRQUFJTyxjQUFjLEdBQUcsQ0FBckI7O0FBQ0EsU0FBS0MsQ0FBTCxJQUFVSCxXQUFWLEVBQXNCO0FBQ2xCRSxvQkFBYyxJQUFJRixXQUFXLENBQUNHLENBQUQsQ0FBWCxDQUFlQyxRQUFqQztBQUNIOztBQUNELFdBQU9GLGNBQWMsR0FBQ04sT0FBTyxDQUFDbEUsTUFBOUI7QUFDSCxHQWRVOztBQWVYLHNCQUFvQmYsT0FBcEIsRUFBNEI7QUFDeEIsUUFBSTBGLFVBQVUsR0FBR3RDLGdCQUFnQixDQUFDdUMsYUFBakIsRUFBakIsQ0FEd0IsQ0FFeEI7O0FBQ0EsUUFBSUMsUUFBUSxHQUFHLENBQ1g7QUFBQ0MsWUFBTSxFQUFDO0FBQUMsbUJBQVU3RjtBQUFYO0FBQVIsS0FEVyxFQUVYO0FBQ0E7QUFBQzhGLFdBQUssRUFBQztBQUFDLGtCQUFTLENBQUM7QUFBWDtBQUFQLEtBSFcsRUFJWDtBQUFDQyxZQUFNLEVBQUUvRyxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QkMsWUFBdkIsR0FBb0M7QUFBN0MsS0FKVyxFQUtYO0FBQUNDLGFBQU8sRUFBRTtBQUFWLEtBTFcsRUFNWDtBQUFDQyxZQUFNLEVBQUM7QUFDSixlQUFPLFVBREg7QUFFSixrQkFBVTtBQUNOLGtCQUFPO0FBQ0hDLGlCQUFLLEVBQUUsQ0FBQztBQUFDQyxpQkFBRyxFQUFFLENBQUMsU0FBRCxFQUFZLElBQVo7QUFBTixhQUFELEVBQTJCLENBQTNCLEVBQThCLENBQTlCO0FBREo7QUFERDtBQUZOO0FBQVIsS0FOVyxDQUFmLENBSHdCLENBa0J4Qjs7QUFFQSxXQUFPdEQsT0FBTyxDQUFDdUQsS0FBUixDQUFjYixVQUFVLENBQUNjLFNBQVgsQ0FBcUJaLFFBQXJCLEVBQStCYSxPQUEvQixFQUFkLENBQVAsQ0FwQndCLENBcUJ4QjtBQUNILEdBckNVOztBQXNDWCw0QkFBMEIsWUFBVztBQUNqQyxTQUFLeEcsT0FBTDtBQUNBLFFBQUlWLEdBQUcsR0FBR21ILEdBQUcsR0FBQyxTQUFkOztBQUNBLFFBQUc7QUFDQyxVQUFJdkcsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsVUFBSW9ILE1BQU0sR0FBR3ZHLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWI7QUFDQSxhQUFRcUcsTUFBTSxDQUFDcEcsTUFBUCxDQUFjcUcsU0FBZCxDQUF3QkMsbUJBQWhDO0FBQ0gsS0FKRCxDQUtBLE9BQU9qSCxDQUFQLEVBQVM7QUFDTCxhQUFPLENBQVA7QUFDSDtBQUNKLEdBakRVO0FBa0RYLDZCQUEyQixZQUFXO0FBQ2xDLFNBQUtLLE9BQUw7QUFDQSxRQUFJNkcsVUFBVSxHQUFHN0QsU0FBUyxDQUFDNkIsSUFBVixDQUFlLEVBQWYsRUFBa0I7QUFBQ2lDLFVBQUksRUFBQztBQUFDM0IsY0FBTSxFQUFDLENBQUM7QUFBVCxPQUFOO0FBQWtCNEIsV0FBSyxFQUFDO0FBQXhCLEtBQWxCLEVBQThDaEMsS0FBOUMsRUFBakIsQ0FGa0MsQ0FHbEM7O0FBQ0EsUUFBSWlDLFdBQVcsR0FBR2pJLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QkQsV0FBekM7O0FBQ0EsUUFBSUgsVUFBVSxJQUFJQSxVQUFVLENBQUMvRixNQUFYLElBQXFCLENBQXZDLEVBQTBDO0FBQ3RDLFVBQUlxRSxNQUFNLEdBQUcwQixVQUFVLENBQUMsQ0FBRCxDQUFWLENBQWMxQixNQUEzQjtBQUNBLFVBQUlBLE1BQU0sR0FBRzZCLFdBQWIsRUFDSSxPQUFPN0IsTUFBUDtBQUNQOztBQUNELFdBQU82QixXQUFQO0FBQ0gsR0E3RFU7QUE4RFgseUJBQXVCLFlBQVc7QUFDOUIsUUFBSUUsT0FBSixFQUNJLE9BQU8sWUFBUCxDQURKLEtBRUt0SCxPQUFPLENBQUNDLEdBQVIsQ0FBWSxlQUFaLEVBSHlCLENBSTlCO0FBQ0E7O0FBQ0EsUUFBSXNILEtBQUssR0FBR3BJLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSx3QkFBWixDQUFaLENBTjhCLENBTzlCO0FBQ0E7O0FBQ0EsUUFBSUMsSUFBSSxHQUFHdEksTUFBTSxDQUFDcUksSUFBUCxDQUFZLHlCQUFaLENBQVg7QUFDQXhILFdBQU8sQ0FBQ0MsR0FBUixDQUFZd0gsSUFBWixFQVY4QixDQVc5Qjs7QUFDQSxRQUFJRixLQUFLLEdBQUdFLElBQVosRUFBa0I7QUFDZEgsYUFBTyxHQUFHLElBQVY7QUFFQSxVQUFJSSxZQUFZLEdBQUcsRUFBbkIsQ0FIYyxDQUlkOztBQUNBaEksU0FBRyxHQUFHRyxHQUFHLEdBQUMscUJBQVY7O0FBRUEsVUFBRztBQUNDUyxnQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0FhLFlBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE3QixDQUFvQ3lCLE9BQXBDLENBQTZDWixTQUFELElBQWVtRyxZQUFZLENBQUNuRyxTQUFTLENBQUNvRyxnQkFBWCxDQUFaLEdBQTJDcEcsU0FBdEc7QUFDSCxPQUhELENBSUEsT0FBTXhCLENBQU4sRUFBUTtBQUNKQyxlQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUVETCxTQUFHLEdBQUdHLEdBQUcsR0FBQyxzQ0FBVjs7QUFFQSxVQUFHO0FBQ0NTLGdCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQWEsWUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTdCLENBQW9DeUIsT0FBcEMsQ0FBNkNaLFNBQUQsSUFBZW1HLFlBQVksQ0FBQ25HLFNBQVMsQ0FBQ29HLGdCQUFYLENBQVosR0FBMkNwRyxTQUF0RztBQUNILE9BSEQsQ0FJQSxPQUFNeEIsQ0FBTixFQUFRO0FBQ0pDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBRURMLFNBQUcsR0FBR0csR0FBRyxHQUFDLHFDQUFWOztBQUVBLFVBQUc7QUFDQ1MsZ0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBYSxZQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBN0IsQ0FBb0N5QixPQUFwQyxDQUE2Q1osU0FBRCxJQUFlbUcsWUFBWSxDQUFDbkcsU0FBUyxDQUFDb0csZ0JBQVgsQ0FBWixHQUEyQ3BHLFNBQXRHO0FBQ0gsT0FIRCxDQUlBLE9BQU14QixDQUFOLEVBQVE7QUFDSkMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFDRCxVQUFJNkgsZUFBZSxHQUFHQyxNQUFNLENBQUNDLElBQVAsQ0FBWUosWUFBWixFQUEwQnhHLE1BQWhEO0FBQ0FsQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxxQkFBb0IySCxlQUFoQzs7QUFDQSxXQUFLLElBQUlyQyxNQUFNLEdBQUdrQyxJQUFJLEdBQUMsQ0FBdkIsRUFBMkJsQyxNQUFNLElBQUlnQyxLQUFyQyxFQUE2Q2hDLE1BQU0sRUFBbkQsRUFBdUQ7QUFDbkQsWUFBSXdDLGNBQWMsR0FBRyxJQUFJeEYsSUFBSixFQUFyQixDQURtRCxDQUVuRDs7QUFDQSxhQUFLbkMsT0FBTDtBQUNBLFlBQUlWLEdBQUcsR0FBR21ILEdBQUcsR0FBQyxnQkFBSixHQUF1QnRCLE1BQWpDO0FBQ0EsWUFBSXlDLGFBQWEsR0FBRyxFQUFwQjtBQUVBaEksZUFBTyxDQUFDQyxHQUFSLENBQVlQLEdBQVo7O0FBQ0EsWUFBRztBQUNDLGdCQUFNdUksY0FBYyxHQUFHekksVUFBVSxDQUFDc0csYUFBWCxHQUEyQm9DLHlCQUEzQixFQUF2QjtBQUNBLGdCQUFNQyxvQkFBb0IsR0FBRzVFLGdCQUFnQixDQUFDdUMsYUFBakIsR0FBaUNvQyx5QkFBakMsRUFBN0I7QUFDQSxnQkFBTUUsYUFBYSxHQUFHMUUsa0JBQWtCLENBQUNvQyxhQUFuQixHQUFtQ29DLHlCQUFuQyxFQUF0QjtBQUNBLGdCQUFNRyxlQUFlLEdBQUcxRSxZQUFZLENBQUNtQyxhQUFiLEdBQTZCb0MseUJBQTdCLEVBQXhCO0FBRUEsY0FBSUksa0JBQWtCLEdBQUcsSUFBSS9GLElBQUosRUFBekI7QUFDQSxjQUFJakMsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmOztBQUNBLGNBQUlZLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQixnQkFBSXdGLEtBQUssR0FBRy9FLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQVo7QUFDQTZFLGlCQUFLLEdBQUdBLEtBQUssQ0FBQzVFLE1BQWQsQ0FGMkIsQ0FHM0I7O0FBQ0EsZ0JBQUk2SCxTQUFTLEdBQUcsRUFBaEI7QUFDQUEscUJBQVMsQ0FBQ2hELE1BQVYsR0FBbUJBLE1BQW5CO0FBQ0FnRCxxQkFBUyxDQUFDQyxJQUFWLEdBQWlCbEQsS0FBSyxDQUFDbUQsUUFBTixDQUFlRCxJQUFoQztBQUNBRCxxQkFBUyxDQUFDRyxRQUFWLEdBQXNCcEQsS0FBSyxDQUFDQSxLQUFOLENBQVl4RCxJQUFaLENBQWlCNkcsR0FBakIsS0FBeUIsSUFBMUIsR0FBa0MsQ0FBbEMsR0FBc0NyRCxLQUFLLENBQUNBLEtBQU4sQ0FBWXhELElBQVosQ0FBaUI2RyxHQUFqQixDQUFxQnpILE1BQWhGO0FBQ0FxSCxxQkFBUyxDQUFDakcsSUFBVixHQUFpQixJQUFJQyxJQUFKLENBQVMrQyxLQUFLLENBQUNBLEtBQU4sQ0FBWXNELE1BQVosQ0FBbUJ0RyxJQUE1QixDQUFqQjtBQUNBaUcscUJBQVMsQ0FBQ00sYUFBVixHQUEwQnZELEtBQUssQ0FBQ0EsS0FBTixDQUFZc0QsTUFBWixDQUFtQkUsYUFBbkIsQ0FBaUNOLElBQTNEO0FBQ0FELHFCQUFTLENBQUNyRCxlQUFWLEdBQTRCSSxLQUFLLENBQUNBLEtBQU4sQ0FBWXNELE1BQVosQ0FBbUJHLGdCQUEvQztBQUNBUixxQkFBUyxDQUFDckUsVUFBVixHQUF1QixFQUF2QjtBQUNBLGdCQUFJOEUsVUFBVSxHQUFHMUQsS0FBSyxDQUFDQSxLQUFOLENBQVkyRCxXQUFaLENBQXdCQyxVQUF6Qzs7QUFDQSxnQkFBSUYsVUFBVSxJQUFJLElBQWxCLEVBQXVCO0FBQ25CO0FBQ0EsbUJBQUssSUFBSW5HLENBQUMsR0FBQyxDQUFYLEVBQWNBLENBQUMsR0FBQ21HLFVBQVUsQ0FBQzlILE1BQTNCLEVBQW1DMkIsQ0FBQyxFQUFwQyxFQUF1QztBQUNuQyxvQkFBSW1HLFVBQVUsQ0FBQ25HLENBQUQsQ0FBVixJQUFpQixJQUFyQixFQUEwQjtBQUN0QjBGLDJCQUFTLENBQUNyRSxVQUFWLENBQXFCaUYsSUFBckIsQ0FBMEJILFVBQVUsQ0FBQ25HLENBQUQsQ0FBVixDQUFjdUcsaUJBQXhDO0FBQ0g7QUFDSjs7QUFFRHBCLDJCQUFhLENBQUNnQixVQUFkLEdBQTJCQSxVQUFVLENBQUM5SCxNQUF0QyxDQVJtQixDQVNuQjtBQUNBO0FBQ0gsYUF4QjBCLENBMEIzQjs7O0FBQ0EsZ0JBQUlvRSxLQUFLLENBQUNBLEtBQU4sQ0FBWXhELElBQVosQ0FBaUI2RyxHQUFqQixJQUF3QnJELEtBQUssQ0FBQ0EsS0FBTixDQUFZeEQsSUFBWixDQUFpQjZHLEdBQWpCLENBQXFCekgsTUFBckIsR0FBOEIsQ0FBMUQsRUFBNEQ7QUFDeEQsbUJBQUttSSxDQUFMLElBQVUvRCxLQUFLLENBQUNBLEtBQU4sQ0FBWXhELElBQVosQ0FBaUI2RyxHQUEzQixFQUErQjtBQUMzQnhKLHNCQUFNLENBQUNxSSxJQUFQLENBQVksb0JBQVosRUFBa0MzRCxNQUFNLENBQUN5RixNQUFNLENBQUNDLElBQVAsQ0FBWWpFLEtBQUssQ0FBQ0EsS0FBTixDQUFZeEQsSUFBWixDQUFpQjZHLEdBQWpCLENBQXFCVSxDQUFyQixDQUFaLEVBQXFDLFFBQXJDLENBQUQsQ0FBeEMsRUFBMEZkLFNBQVMsQ0FBQ2pHLElBQXBHLEVBQTBHLENBQUNrSCxHQUFELEVBQU05SSxNQUFOLEtBQWlCO0FBQ3ZILHNCQUFJOEksR0FBSixFQUFRO0FBQ0p4SiwyQkFBTyxDQUFDQyxHQUFSLENBQVl1SixHQUFaO0FBQ0g7QUFDSixpQkFKRDtBQUtIO0FBQ0osYUFuQzBCLENBcUMzQjs7O0FBQ0EsZ0JBQUlsRSxLQUFLLENBQUNBLEtBQU4sQ0FBWW1FLFFBQVosQ0FBcUJBLFFBQXpCLEVBQWtDO0FBQzlCN0YsdUJBQVMsQ0FBQzhGLE1BQVYsQ0FBaUI7QUFDYm5FLHNCQUFNLEVBQUVBLE1BREs7QUFFYmtFLHdCQUFRLEVBQUVuRSxLQUFLLENBQUNBLEtBQU4sQ0FBWW1FLFFBQVosQ0FBcUJBO0FBRmxCLGVBQWpCO0FBSUg7O0FBRURsQixxQkFBUyxDQUFDb0IsZUFBVixHQUE0QnBCLFNBQVMsQ0FBQ3JFLFVBQVYsQ0FBcUJoRCxNQUFqRDtBQUVBOEcseUJBQWEsQ0FBQ3pDLE1BQWQsR0FBdUJBLE1BQXZCO0FBRUEsZ0JBQUlxRSxnQkFBZ0IsR0FBRyxJQUFJckgsSUFBSixFQUF2QjtBQUNBdkMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFxQixDQUFDMkosZ0JBQWdCLEdBQUN0QixrQkFBbEIsSUFBc0MsSUFBM0QsR0FBaUUsVUFBN0U7QUFHQSxnQkFBSXVCLHNCQUFzQixHQUFHLElBQUl0SCxJQUFKLEVBQTdCLENBckQyQixDQXNEM0I7O0FBQ0E3QyxlQUFHLEdBQUdtSCxHQUFHLEdBQUMscUJBQUosR0FBMEJ0QixNQUFoQztBQUNBakYsb0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBTSxtQkFBTyxDQUFDQyxHQUFSLENBQVlQLEdBQVo7QUFDQSxnQkFBSXdFLFVBQVUsR0FBRzNELElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWpCO0FBQ0F5RCxzQkFBVSxDQUFDeEQsTUFBWCxDQUFrQm9KLFlBQWxCLEdBQWlDQyxRQUFRLENBQUM3RixVQUFVLENBQUN4RCxNQUFYLENBQWtCb0osWUFBbkIsQ0FBekM7QUFDQXhHLHlCQUFhLENBQUNvRyxNQUFkLENBQXFCeEYsVUFBVSxDQUFDeEQsTUFBaEM7QUFFQTZILHFCQUFTLENBQUN5QixlQUFWLEdBQTRCOUYsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQWxCLENBQTZCaEQsTUFBekQ7QUFDQSxnQkFBSStJLG9CQUFvQixHQUFHLElBQUkxSCxJQUFKLEVBQTNCO0FBQ0FhLHFCQUFTLENBQUNzRyxNQUFWLENBQWlCbkIsU0FBakI7QUFDQSxnQkFBSTJCLGtCQUFrQixHQUFHLElBQUkzSCxJQUFKLEVBQXpCO0FBQ0F2QyxtQkFBTyxDQUFDQyxHQUFSLENBQVksd0JBQXVCLENBQUNpSyxrQkFBa0IsR0FBQ0Qsb0JBQXBCLElBQTBDLElBQWpFLEdBQXVFLFVBQW5GLEVBbEUyQixDQW9FM0I7O0FBQ0EsZ0JBQUlFLGtCQUFrQixHQUFHM0ssVUFBVSxDQUFDeUYsSUFBWCxDQUFnQjtBQUFDOUUscUJBQU8sRUFBQztBQUFDaUssdUJBQU8sRUFBQztBQUFUO0FBQVQsYUFBaEIsRUFBMENqRixLQUExQyxFQUF6Qjs7QUFFQSxnQkFBSUksTUFBTSxHQUFHLENBQWIsRUFBZTtBQUNYO0FBQ0E7QUFDQSxtQkFBSzFDLENBQUwsSUFBVXFCLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0J3RCxVQUE1QixFQUF1QztBQUNuQyxvQkFBSS9ELE9BQU8sR0FBRytELFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0J3RCxVQUFsQixDQUE2QnJCLENBQTdCLEVBQWdDMUMsT0FBOUM7QUFDQSxvQkFBSWtLLE1BQU0sR0FBRztBQUNUOUUsd0JBQU0sRUFBRUEsTUFEQztBQUVUcEYseUJBQU8sRUFBRUEsT0FGQTtBQUdUbUssd0JBQU0sRUFBRSxLQUhDO0FBSVRDLDhCQUFZLEVBQUVSLFFBQVEsQ0FBQzdGLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0J3RCxVQUFsQixDQUE2QnJCLENBQTdCLEVBQWdDMEgsWUFBakMsQ0FKYixDQUkyRDs7QUFKM0QsaUJBQWI7O0FBT0EscUJBQUtDLENBQUwsSUFBVXhCLFVBQVYsRUFBcUI7QUFDakIsc0JBQUlBLFVBQVUsQ0FBQ3dCLENBQUQsQ0FBVixJQUFpQixJQUFyQixFQUEwQjtBQUN0Qix3QkFBSXJLLE9BQU8sSUFBSTZJLFVBQVUsQ0FBQ3dCLENBQUQsQ0FBVixDQUFjcEIsaUJBQTdCLEVBQStDO0FBQzNDaUIsNEJBQU0sQ0FBQ0MsTUFBUCxHQUFnQixJQUFoQjtBQUNBdEIsZ0NBQVUsQ0FBQzVFLE1BQVgsQ0FBa0JvRyxDQUFsQixFQUFvQixDQUFwQjtBQUNBO0FBQ0g7QUFDSjtBQUNKLGlCQWpCa0MsQ0FtQm5DO0FBQ0E7OztBQUVBLG9CQUFLakYsTUFBTSxHQUFHLEVBQVYsSUFBaUIsQ0FBckIsRUFBdUI7QUFDbkI7QUFDQSxzQkFBSWtGLFNBQVMsR0FBR3RMLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxtQkFBWixFQUFpQ3JILE9BQWpDLENBQWhCO0FBQ0Esc0JBQUl1SyxNQUFNLEdBQUcsQ0FBYixDQUhtQixDQUluQjtBQUNBOztBQUNBLHNCQUFLRCxTQUFTLENBQUMsQ0FBRCxDQUFULElBQWdCLElBQWpCLElBQTJCQSxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWFDLE1BQWIsSUFBdUIsSUFBdEQsRUFBNEQ7QUFDeERBLDBCQUFNLEdBQUdELFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYUMsTUFBdEI7QUFDSDs7QUFFRCxzQkFBSUMsSUFBSSxHQUFHeEwsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJDLFlBQWxDOztBQUNBLHNCQUFJZCxNQUFNLEdBQUdvRixJQUFiLEVBQWtCO0FBQ2RBLHdCQUFJLEdBQUdwRixNQUFQO0FBQ0g7O0FBRUQsc0JBQUk4RSxNQUFNLENBQUNDLE1BQVgsRUFBa0I7QUFDZCx3QkFBSUksTUFBTSxHQUFHQyxJQUFiLEVBQWtCO0FBQ2RELDRCQUFNO0FBQ1Q7O0FBQ0RBLDBCQUFNLEdBQUlBLE1BQU0sR0FBR0MsSUFBVixHQUFnQixHQUF6QjtBQUNBMUMsa0NBQWMsQ0FBQ2hELElBQWYsQ0FBb0I7QUFBQzlFLDZCQUFPLEVBQUNBO0FBQVQscUJBQXBCLEVBQXVDeUssTUFBdkMsR0FBZ0RDLFNBQWhELENBQTBEO0FBQUNDLDBCQUFJLEVBQUM7QUFBQ0osOEJBQU0sRUFBQ0EsTUFBUjtBQUFnQkssZ0NBQVEsRUFBQ3hDLFNBQVMsQ0FBQ2pHO0FBQW5DO0FBQU4scUJBQTFEO0FBQ0gsbUJBTkQsTUFPSTtBQUNBb0ksMEJBQU0sR0FBSUEsTUFBTSxHQUFHQyxJQUFWLEdBQWdCLEdBQXpCO0FBQ0ExQyxrQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDOUUsNkJBQU8sRUFBQ0E7QUFBVCxxQkFBcEIsRUFBdUN5SyxNQUF2QyxHQUFnREMsU0FBaEQsQ0FBMEQ7QUFBQ0MsMEJBQUksRUFBQztBQUFDSiw4QkFBTSxFQUFDQTtBQUFSO0FBQU4scUJBQTFEO0FBQ0g7QUFDSjs7QUFFRHZDLG9DQUFvQixDQUFDdUIsTUFBckIsQ0FBNEJXLE1BQTVCLEVBbERtQyxDQW1EbkM7QUFDSDtBQUNKOztBQUVELGdCQUFJVyxXQUFXLEdBQUczSCxLQUFLLENBQUM3QixPQUFOLENBQWM7QUFBQ3lKLHFCQUFPLEVBQUMzRixLQUFLLENBQUNBLEtBQU4sQ0FBWXNELE1BQVosQ0FBbUJzQztBQUE1QixhQUFkLENBQWxCO0FBQ0EsZ0JBQUlDLGNBQWMsR0FBR0gsV0FBVyxHQUFDQSxXQUFXLENBQUNHLGNBQWIsR0FBNEIsQ0FBNUQ7QUFDQSxnQkFBSXZGLFFBQUo7QUFDQSxnQkFBSXdGLFNBQVMsR0FBR2pNLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QmdFLGdCQUF2Qzs7QUFDQSxnQkFBSUYsY0FBSixFQUFtQjtBQUNmLGtCQUFJRyxVQUFVLEdBQUcvQyxTQUFTLENBQUNqRyxJQUEzQjtBQUNBLGtCQUFJaUosUUFBUSxHQUFHLElBQUloSixJQUFKLENBQVM0SSxjQUFULENBQWY7QUFDQXZGLHNCQUFRLEdBQUc0RixJQUFJLENBQUNDLEdBQUwsQ0FBU0gsVUFBVSxDQUFDSSxPQUFYLEtBQXVCSCxRQUFRLENBQUNHLE9BQVQsRUFBaEMsQ0FBWCxDQUhlLENBSWY7O0FBQ0Esa0JBQUduRCxTQUFTLENBQUNoRCxNQUFWLEdBQW1CLENBQXRCLEVBQXlCO0FBQ3JCNkYseUJBQVMsR0FBRyxDQUFDSixXQUFXLENBQUNJLFNBQVosSUFBeUI3QyxTQUFTLENBQUNoRCxNQUFWLEdBQW1CLENBQTVDLElBQWlESyxRQUFsRCxJQUE4RDJDLFNBQVMsQ0FBQ2hELE1BQXBGO0FBQ0g7QUFDSjs7QUFFRCxnQkFBSW9HLG9CQUFvQixHQUFHLElBQUlwSixJQUFKLEVBQTNCO0FBQ0F2QyxtQkFBTyxDQUFDQyxHQUFSLENBQVksaUNBQWdDLENBQUMwTCxvQkFBb0IsR0FBQzlCLHNCQUF0QixJQUE4QyxJQUE5RSxHQUFvRixVQUFoRztBQUVBeEcsaUJBQUssQ0FBQ3VJLE1BQU4sQ0FBYTtBQUFDWCxxQkFBTyxFQUFDM0YsS0FBSyxDQUFDQSxLQUFOLENBQVlzRCxNQUFaLENBQW1Cc0M7QUFBNUIsYUFBYixFQUFvRDtBQUFDSixrQkFBSSxFQUFDO0FBQUNLLDhCQUFjLEVBQUM1QyxTQUFTLENBQUNqRyxJQUExQjtBQUFnQzhJLHlCQUFTLEVBQUNBO0FBQTFDO0FBQU4sYUFBcEQ7QUFFQXBELHlCQUFhLENBQUM2RCxnQkFBZCxHQUFpQ1QsU0FBakM7QUFDQXBELHlCQUFhLENBQUNwQyxRQUFkLEdBQXlCQSxRQUF6QjtBQUVBb0MseUJBQWEsQ0FBQzFGLElBQWQsR0FBcUJpRyxTQUFTLENBQUNqRyxJQUEvQixDQXZKMkIsQ0F5SjNCO0FBQ0E7QUFDQTtBQUNBOztBQUVBMEYseUJBQWEsQ0FBQ3VDLFlBQWQsR0FBNkIsQ0FBN0I7QUFFQSxnQkFBSXVCLDJCQUEyQixHQUFHLElBQUl2SixJQUFKLEVBQWxDOztBQUNBLGdCQUFJMkIsVUFBVSxDQUFDeEQsTUFBZixFQUFzQjtBQUNsQjtBQUNBVixxQkFBTyxDQUFDQyxHQUFSLENBQVksd0JBQXNCaUUsVUFBVSxDQUFDeEQsTUFBWCxDQUFrQndELFVBQWxCLENBQTZCaEQsTUFBL0Q7O0FBQ0EsbUJBQUs1QixDQUFMLElBQVU0RSxVQUFVLENBQUN4RCxNQUFYLENBQWtCd0QsVUFBNUIsRUFBdUM7QUFDbkM7QUFDQSxvQkFBSTNDLFNBQVMsR0FBRzJDLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0J3RCxVQUFsQixDQUE2QjVFLENBQTdCLENBQWhCO0FBQ0FpQyx5QkFBUyxDQUFDZ0osWUFBVixHQUF5QlIsUUFBUSxDQUFDeEksU0FBUyxDQUFDZ0osWUFBWCxDQUFqQztBQUNBaEoseUJBQVMsQ0FBQ3dLLGlCQUFWLEdBQThCaEMsUUFBUSxDQUFDeEksU0FBUyxDQUFDd0ssaUJBQVgsQ0FBdEM7QUFFQSxvQkFBSUMsUUFBUSxHQUFHeE0sVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDLG1DQUFnQkQsU0FBUyxDQUFDMEssT0FBVixDQUFrQnBMO0FBQW5DLGlCQUFuQixDQUFmOztBQUNBLG9CQUFJLENBQUNtTCxRQUFMLEVBQWM7QUFDVmhNLHlCQUFPLENBQUNDLEdBQVIsNkJBQWlDc0IsU0FBUyxDQUFDcEIsT0FBM0MsY0FBc0RvQixTQUFTLENBQUMwSyxPQUFWLENBQWtCcEwsS0FBeEUsaUJBRFUsQ0FFVjtBQUNBO0FBQ0E7O0FBRUFVLDJCQUFTLENBQUNwQixPQUFWLEdBQW9CMkQsVUFBVSxDQUFDdkMsU0FBUyxDQUFDMEssT0FBWCxDQUE5QjtBQUNBMUssMkJBQVMsQ0FBQzJLLE1BQVYsR0FBbUIvTSxNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJqRyxTQUFTLENBQUMwSyxPQUF4QyxFQUFpRDlNLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCK0Ysa0JBQXhFLENBQW5CO0FBQ0E1SywyQkFBUyxDQUFDNkssZUFBVixHQUE0QmpOLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmpHLFNBQVMsQ0FBQzBLLE9BQXhDLEVBQWlEOU0sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJpRyxrQkFBeEUsQ0FBNUI7QUFDQTlLLDJCQUFTLENBQUNvRyxnQkFBVixHQUE2QnhJLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmpHLFNBQVMsQ0FBQzBLLE9BQXhDLEVBQWlEOU0sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJrRyxtQkFBeEUsQ0FBN0I7QUFFQSxzQkFBSUMsYUFBYSxHQUFHN0UsWUFBWSxDQUFDbkcsU0FBUyxDQUFDb0csZ0JBQVgsQ0FBaEM7O0FBQ0Esc0JBQUk0RSxhQUFKLEVBQWtCO0FBQ2Qsd0JBQUlBLGFBQWEsQ0FBQ0MsV0FBZCxDQUEwQmxJLFFBQTlCLEVBQ0kvQyxTQUFTLENBQUNrTCxXQUFWLEdBQXlCcEksc0JBQXNCLENBQUNrSSxhQUFhLENBQUNDLFdBQWQsQ0FBMEJsSSxRQUEzQixDQUEvQztBQUNKL0MsNkJBQVMsQ0FBQ0csZ0JBQVYsR0FBNkI2SyxhQUFhLENBQUM3SyxnQkFBM0M7QUFDQUgsNkJBQVMsQ0FBQ0ksaUJBQVYsR0FBOEJ4QyxNQUFNLENBQUNxSSxJQUFQLENBQVksY0FBWixFQUE0QitFLGFBQWEsQ0FBQzdLLGdCQUExQyxDQUE5QjtBQUNBSCw2QkFBUyxDQUFDbUwsTUFBVixHQUFtQkgsYUFBYSxDQUFDRyxNQUFqQztBQUNBbkwsNkJBQVMsQ0FBQ3VGLE1BQVYsR0FBbUJ5RixhQUFhLENBQUN6RixNQUFqQztBQUNBdkYsNkJBQVMsQ0FBQ29MLG1CQUFWLEdBQWdDSixhQUFhLENBQUNJLG1CQUE5QztBQUNBcEwsNkJBQVMsQ0FBQ3FMLE1BQVYsR0FBbUJMLGFBQWEsQ0FBQ0ssTUFBakM7QUFDQXJMLDZCQUFTLENBQUNzTCxnQkFBVixHQUE2Qk4sYUFBYSxDQUFDTSxnQkFBM0M7QUFDQXRMLDZCQUFTLENBQUNpTCxXQUFWLEdBQXdCRCxhQUFhLENBQUNDLFdBQXRDO0FBQ0FqTCw2QkFBUyxDQUFDdUwsV0FBVixHQUF3QlAsYUFBYSxDQUFDTyxXQUF0QztBQUNBdkwsNkJBQVMsQ0FBQ3dMLHFCQUFWLEdBQWtDUixhQUFhLENBQUNRLHFCQUFoRDtBQUNBeEwsNkJBQVMsQ0FBQ3lMLGdCQUFWLEdBQTZCVCxhQUFhLENBQUNTLGdCQUEzQztBQUNBekwsNkJBQVMsQ0FBQzBMLGNBQVYsR0FBMkJWLGFBQWEsQ0FBQ1UsY0FBekM7QUFDQTFMLDZCQUFTLENBQUNNLFVBQVYsR0FBdUIwSyxhQUFhLENBQUMxSyxVQUFyQztBQUNBTiw2QkFBUyxDQUFDMkwsZUFBVixHQUE0QjNMLFNBQVMsQ0FBQ3NMLGdCQUF0QyxDQWhCYyxDQWlCZDtBQUNBO0FBQ0E7QUFDSCxtQkFwQkQsTUFvQk87QUFDSDdNLDJCQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWjtBQUNILG1CQWxDUyxDQW9DVjs7O0FBQ0FnSSxnQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDMEMsb0NBQWdCLEVBQUVwRyxTQUFTLENBQUNvRztBQUE3QixtQkFBcEIsRUFBb0VpRCxNQUFwRSxHQUE2RUMsU0FBN0UsQ0FBdUY7QUFBQ0Msd0JBQUksRUFBQ3ZKO0FBQU4sbUJBQXZGLEVBckNVLENBc0NWOztBQUNBNkcsK0JBQWEsQ0FBQ3NCLE1BQWQsQ0FBcUI7QUFDakJ2SiwyQkFBTyxFQUFFb0IsU0FBUyxDQUFDcEIsT0FERjtBQUVqQmdOLHFDQUFpQixFQUFFLENBRkY7QUFHakI1QyxnQ0FBWSxFQUFFaEosU0FBUyxDQUFDZ0osWUFIUDtBQUlqQjNKLHdCQUFJLEVBQUUsS0FKVztBQUtqQjJFLDBCQUFNLEVBQUVnRCxTQUFTLENBQUNoRCxNQUxEO0FBTWpCNkgsOEJBQVUsRUFBRTdFLFNBQVMsQ0FBQ2pHO0FBTkwsbUJBQXJCLEVBdkNVLENBZ0RWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFJQTtBQUNILGlCQS9ERCxNQWdFSTtBQUNBLHNCQUFJaUssYUFBYSxHQUFHN0UsWUFBWSxDQUFDc0UsUUFBUSxDQUFDckUsZ0JBQVYsQ0FBaEM7O0FBQ0Esc0JBQUk0RSxhQUFKLEVBQWtCO0FBQ2Qsd0JBQUlBLGFBQWEsQ0FBQ0MsV0FBZCxLQUE4QixDQUFDUixRQUFRLENBQUNRLFdBQVYsSUFBeUJELGFBQWEsQ0FBQ0MsV0FBZCxDQUEwQmxJLFFBQTFCLEtBQXVDMEgsUUFBUSxDQUFDUSxXQUFULENBQXFCbEksUUFBbkgsQ0FBSixFQUNJL0MsU0FBUyxDQUFDa0wsV0FBVixHQUF5QnBJLHNCQUFzQixDQUFDa0ksYUFBYSxDQUFDQyxXQUFkLENBQTBCbEksUUFBM0IsQ0FBL0M7QUFDSi9DLDZCQUFTLENBQUNtTCxNQUFWLEdBQW1CSCxhQUFhLENBQUNHLE1BQWpDO0FBQ0FuTCw2QkFBUyxDQUFDdUYsTUFBVixHQUFtQnlGLGFBQWEsQ0FBQ3pGLE1BQWpDO0FBQ0F2Riw2QkFBUyxDQUFDcUwsTUFBVixHQUFtQkwsYUFBYSxDQUFDSyxNQUFqQztBQUNBckwsNkJBQVMsQ0FBQ3NMLGdCQUFWLEdBQTZCTixhQUFhLENBQUNNLGdCQUEzQztBQUNBdEwsNkJBQVMsQ0FBQ2lMLFdBQVYsR0FBd0JELGFBQWEsQ0FBQ0MsV0FBdEM7QUFDQWpMLDZCQUFTLENBQUN1TCxXQUFWLEdBQXdCUCxhQUFhLENBQUNPLFdBQXRDO0FBQ0F2TCw2QkFBUyxDQUFDd0wscUJBQVYsR0FBa0NSLGFBQWEsQ0FBQ1EscUJBQWhEO0FBQ0F4TCw2QkFBUyxDQUFDeUwsZ0JBQVYsR0FBNkJULGFBQWEsQ0FBQ1MsZ0JBQTNDO0FBQ0F6TCw2QkFBUyxDQUFDMEwsY0FBVixHQUEyQlYsYUFBYSxDQUFDVSxjQUF6QztBQUNBMUwsNkJBQVMsQ0FBQ00sVUFBVixHQUF1QjBLLGFBQWEsQ0FBQzFLLFVBQXJDLENBWmMsQ0FjZDs7QUFFQSx3QkFBSTBELE1BQU0sR0FBRyxFQUFULElBQWUsQ0FBbkIsRUFBcUI7QUFDakIsMEJBQUc7QUFDQyw0QkFBSWpGLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNDLEdBQUcsR0FBRyxzQkFBTixHQUE2Qm1NLFFBQVEsQ0FBQ3JLLGlCQUF0QyxHQUF3RCxlQUF4RCxHQUF3RXFLLFFBQVEsQ0FBQ3RLLGdCQUExRixDQUFmOztBQUVBLDRCQUFJcEIsUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCLDhCQUFJdU4sY0FBYyxHQUFHOU0sSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQWxEOztBQUNBLDhCQUFJMk0sY0FBYyxDQUFDdEwsTUFBbkIsRUFBMEI7QUFDdEJSLHFDQUFTLENBQUMyTCxlQUFWLEdBQTRCbEwsVUFBVSxDQUFDcUwsY0FBYyxDQUFDdEwsTUFBaEIsQ0FBVixHQUFrQ0MsVUFBVSxDQUFDVCxTQUFTLENBQUNzTCxnQkFBWCxDQUF4RTtBQUNIO0FBQ0o7QUFDSix1QkFURCxDQVVBLE9BQU05TSxDQUFOLEVBQVEsQ0FDSjtBQUNIO0FBQ0o7O0FBRURrSSxrQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDMEMsc0NBQWdCLEVBQUVxRSxRQUFRLENBQUNyRTtBQUE1QixxQkFBcEIsRUFBbUVrRCxTQUFuRSxDQUE2RTtBQUFDQywwQkFBSSxFQUFDdko7QUFBTixxQkFBN0UsRUFoQ2MsQ0FpQ2Q7QUFDQTtBQUNILG1CQW5DRCxNQW1DUTtBQUNKdkIsMkJBQU8sQ0FBQ0MsR0FBUixDQUFZLGlCQUFaO0FBQ0g7O0FBQ0Qsc0JBQUlxTixlQUFlLEdBQUc1SixrQkFBa0IsQ0FBQ2xDLE9BQW5CLENBQTJCO0FBQUNyQiwyQkFBTyxFQUFDb0IsU0FBUyxDQUFDcEI7QUFBbkIsbUJBQTNCLEVBQXdEO0FBQUNvRiwwQkFBTSxFQUFDLENBQUMsQ0FBVDtBQUFZNEIseUJBQUssRUFBQztBQUFsQixtQkFBeEQsQ0FBdEI7O0FBRUEsc0JBQUltRyxlQUFKLEVBQW9CO0FBQ2hCLHdCQUFJQSxlQUFlLENBQUMvQyxZQUFoQixJQUFnQ2hKLFNBQVMsQ0FBQ2dKLFlBQTlDLEVBQTJEO0FBQ3ZELDBCQUFJZ0QsVUFBVSxHQUFJRCxlQUFlLENBQUMvQyxZQUFoQixHQUErQmhKLFNBQVMsQ0FBQ2dKLFlBQTFDLEdBQXdELE1BQXhELEdBQStELElBQWhGO0FBQ0EsMEJBQUlpRCxVQUFVLEdBQUc7QUFDYnJOLCtCQUFPLEVBQUVvQixTQUFTLENBQUNwQixPQUROO0FBRWJnTix5Q0FBaUIsRUFBRUcsZUFBZSxDQUFDL0MsWUFGdEI7QUFHYkEsb0NBQVksRUFBRWhKLFNBQVMsQ0FBQ2dKLFlBSFg7QUFJYjNKLDRCQUFJLEVBQUUyTSxVQUpPO0FBS2JoSSw4QkFBTSxFQUFFZ0QsU0FBUyxDQUFDaEQsTUFMTDtBQU1iNkgsa0NBQVUsRUFBRTdFLFNBQVMsQ0FBQ2pHO0FBTlQsdUJBQWpCLENBRnVELENBVXZEO0FBQ0E7O0FBQ0E4RixtQ0FBYSxDQUFDc0IsTUFBZCxDQUFxQjhELFVBQXJCO0FBQ0g7QUFDSjtBQUVKLGlCQWxJa0MsQ0FxSW5DOzs7QUFFQXhGLDZCQUFhLENBQUN1QyxZQUFkLElBQThCaEosU0FBUyxDQUFDZ0osWUFBeEM7QUFDSCxlQTNJaUIsQ0E2SWxCOzs7QUFFQSxrQkFBSXRHLGNBQWMsR0FBR1gsYUFBYSxDQUFDOUIsT0FBZCxDQUFzQjtBQUFDc0ksNEJBQVksRUFBQ3ZFLE1BQU0sR0FBQztBQUFyQixlQUF0QixDQUFyQjs7QUFFQSxrQkFBSXRCLGNBQUosRUFBbUI7QUFDZixvQkFBSXdKLGlCQUFpQixHQUFHekosb0JBQW9CLENBQUNDLGNBQWMsQ0FBQ0MsVUFBaEIsRUFBNEJBLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0J3RCxVQUE5QyxDQUE1Qzs7QUFFQSxxQkFBS3dKLENBQUwsSUFBVUQsaUJBQVYsRUFBNEI7QUFDeEJyRiwrQkFBYSxDQUFDc0IsTUFBZCxDQUFxQjtBQUNqQnZKLDJCQUFPLEVBQUVzTixpQkFBaUIsQ0FBQ0MsQ0FBRCxDQUFqQixDQUFxQnZOLE9BRGI7QUFFakJnTixxQ0FBaUIsRUFBRU0saUJBQWlCLENBQUNDLENBQUQsQ0FBakIsQ0FBcUJuRCxZQUZ2QjtBQUdqQkEsZ0NBQVksRUFBRSxDQUhHO0FBSWpCM0osd0JBQUksRUFBRSxRQUpXO0FBS2pCMkUsMEJBQU0sRUFBRWdELFNBQVMsQ0FBQ2hELE1BTEQ7QUFNakI2SCw4QkFBVSxFQUFFN0UsU0FBUyxDQUFDakc7QUFOTCxtQkFBckI7QUFRSDtBQUNKO0FBRUosYUFqVTBCLENBb1UzQjs7O0FBQ0EsZ0JBQUlpRCxNQUFNLEdBQUcsS0FBVCxJQUFrQixDQUF0QixFQUF3QjtBQUNwQixrQkFBSTtBQUNBdkYsdUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHVDQUFaO0FBQ0Esb0JBQUkwTixZQUFZLEdBQUcsRUFBbkI7QUFDQW5PLDBCQUFVLENBQUN5RixJQUFYLENBQWdCLEVBQWhCLEVBQW9CO0FBQUMySSx3QkFBTSxFQUFFO0FBQUNqRyxvQ0FBZ0IsRUFBRSxDQUFuQjtBQUFzQmIsMEJBQU0sRUFBRTtBQUE5QjtBQUFULGlCQUFwQixFQUNNM0UsT0FETixDQUNlN0MsQ0FBRCxJQUFPcU8sWUFBWSxDQUFDck8sQ0FBQyxDQUFDcUksZ0JBQUgsQ0FBWixHQUFtQ3JJLENBQUMsQ0FBQ3dILE1BRDFEO0FBRUFlLHNCQUFNLENBQUNDLElBQVAsQ0FBWUosWUFBWixFQUEwQnZGLE9BQTFCLENBQW1DMEwsU0FBRCxJQUFlO0FBQzdDLHNCQUFJdEIsYUFBYSxHQUFHN0UsWUFBWSxDQUFDbUcsU0FBRCxDQUFoQyxDQUQ2QyxDQUU3Qzs7QUFDQSxzQkFBSXRCLGFBQWEsQ0FBQ3pGLE1BQWQsS0FBeUIsQ0FBN0IsRUFDSTs7QUFFSixzQkFBSTZHLFlBQVksQ0FBQ0UsU0FBRCxDQUFaLElBQTJCQyxTQUEvQixFQUEwQztBQUN0QzlOLDJCQUFPLENBQUNDLEdBQVIsMkNBQStDNE4sU0FBL0M7QUFFQXRCLGlDQUFhLENBQUNOLE9BQWQsR0FBd0I7QUFDcEIsOEJBQVMsMEJBRFc7QUFFcEIsK0JBQVM5TSxNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJxRyxTQUE5QjtBQUZXLHFCQUF4QjtBQUlBdEIsaUNBQWEsQ0FBQ3BNLE9BQWQsR0FBd0IyRCxVQUFVLENBQUN5SSxhQUFhLENBQUNOLE9BQWYsQ0FBbEM7QUFDQU0saUNBQWEsQ0FBQzVLLGlCQUFkLEdBQWtDeEMsTUFBTSxDQUFDcUksSUFBUCxDQUFZLGNBQVosRUFBNEIrRSxhQUFhLENBQUM3SyxnQkFBMUMsQ0FBbEM7QUFFQTZLLGlDQUFhLENBQUNMLE1BQWQsR0FBdUIvTSxNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEIrRSxhQUFhLENBQUNOLE9BQTVDLEVBQXFEOU0sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUIrRixrQkFBNUUsQ0FBdkI7QUFDQUksaUNBQWEsQ0FBQ0gsZUFBZCxHQUFnQ2pOLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QitFLGFBQWEsQ0FBQ04sT0FBNUMsRUFBcUQ5TSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmlHLGtCQUE1RSxDQUFoQztBQUNBck0sMkJBQU8sQ0FBQ0MsR0FBUixDQUFZTSxJQUFJLENBQUNtRSxTQUFMLENBQWU2SCxhQUFmLENBQVo7QUFDQXRFLGtDQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUMwQyxzQ0FBZ0IsRUFBRWtHO0FBQW5CLHFCQUFwQixFQUFtRGpELE1BQW5ELEdBQTREQyxTQUE1RCxDQUFzRTtBQUFDQywwQkFBSSxFQUFDeUI7QUFBTixxQkFBdEU7QUFDSCxtQkFkRCxNQWNPLElBQUlvQixZQUFZLENBQUNFLFNBQUQsQ0FBWixJQUEyQixDQUEvQixFQUFrQztBQUNyQzVGLGtDQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUMwQyxzQ0FBZ0IsRUFBRWtHO0FBQW5CLHFCQUFwQixFQUFtRGpELE1BQW5ELEdBQTREQyxTQUE1RCxDQUFzRTtBQUFDQywwQkFBSSxFQUFDeUI7QUFBTixxQkFBdEU7QUFDSDtBQUNKLGlCQXZCRDtBQXdCSCxlQTdCRCxDQTZCRSxPQUFPeE0sQ0FBUCxFQUFTO0FBQ1BDLHVCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osYUF0VzBCLENBd1czQjs7O0FBQ0EsZ0JBQUl3RixNQUFNLEdBQUcsS0FBVCxJQUFrQixDQUF0QixFQUF3QjtBQUNwQnZGLHFCQUFPLENBQUNDLEdBQVIsQ0FBWSxxQkFBWjtBQUNBVCx3QkFBVSxDQUFDeUYsSUFBWCxDQUFnQixFQUFoQixFQUFvQjlDLE9BQXBCLENBQTZCWixTQUFELElBQWU7QUFDdkMsb0JBQUk7QUFDQSxzQkFBSXdNLFVBQVUsR0FBSTFKLHNCQUFzQixDQUFDOUMsU0FBUyxDQUFDaUwsV0FBVixDQUFzQmxJLFFBQXZCLENBQXhDOztBQUNBLHNCQUFJeUosVUFBSixFQUFnQjtBQUNaOUYsa0NBQWMsQ0FBQ2hELElBQWYsQ0FBb0I7QUFBQzlFLDZCQUFPLEVBQUVvQixTQUFTLENBQUNwQjtBQUFwQixxQkFBcEIsRUFDTXlLLE1BRE4sR0FDZUMsU0FEZixDQUN5QjtBQUFDQywwQkFBSSxFQUFDO0FBQUMsdUNBQWNpRDtBQUFmO0FBQU4scUJBRHpCO0FBRUg7QUFDSixpQkFORCxDQU1FLE9BQU9oTyxDQUFQLEVBQVU7QUFDUkMseUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixlQVZEO0FBV0g7O0FBRUQsZ0JBQUlpTyx5QkFBeUIsR0FBRyxJQUFJekwsSUFBSixFQUFoQztBQUNBdkMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLCtCQUE4QixDQUFDK04seUJBQXlCLEdBQUNsQywyQkFBM0IsSUFBd0QsSUFBdEYsR0FBNEYsVUFBeEcsRUF6WDJCLENBMlgzQjs7QUFDQSxnQkFBSW1DLHVCQUF1QixHQUFHLElBQUkxTCxJQUFKLEVBQTlCO0FBQ0FpQixxQkFBUyxDQUFDa0csTUFBVixDQUFpQjFCLGFBQWpCO0FBQ0EsZ0JBQUlrRyxzQkFBc0IsR0FBRyxJQUFJM0wsSUFBSixFQUE3QjtBQUNBdkMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUEyQixDQUFDaU8sc0JBQXNCLEdBQUNELHVCQUF4QixJQUFpRCxJQUE1RSxHQUFrRixVQUE5RjtBQUVBLGdCQUFJRSxZQUFZLEdBQUcsSUFBSTVMLElBQUosRUFBbkI7O0FBQ0EsZ0JBQUkwRixjQUFjLENBQUMvRyxNQUFmLEdBQXdCLENBQTVCLEVBQThCO0FBQzFCO0FBQ0ErRyw0QkFBYyxDQUFDbUcsT0FBZixDQUF1QixDQUFDNUUsR0FBRCxFQUFNOUksTUFBTixLQUFpQjtBQUNwQyxvQkFBSThJLEdBQUosRUFBUTtBQUNKeEoseUJBQU8sQ0FBQ0MsR0FBUixDQUFZdUosR0FBWjtBQUNIOztBQUNELG9CQUFJOUksTUFBSixFQUFXLENBQ1A7QUFDSDtBQUNKLGVBUEQ7QUFRSDs7QUFFRCxnQkFBSTJOLFVBQVUsR0FBRyxJQUFJOUwsSUFBSixFQUFqQjtBQUNBdkMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUEyQixDQUFDb08sVUFBVSxHQUFDRixZQUFaLElBQTBCLElBQXJELEdBQTJELFVBQXZFO0FBRUEsZ0JBQUlHLFdBQVcsR0FBRyxJQUFJL0wsSUFBSixFQUFsQjs7QUFDQSxnQkFBSTRGLG9CQUFvQixDQUFDakgsTUFBckIsR0FBOEIsQ0FBbEMsRUFBb0M7QUFDaENpSCxrQ0FBb0IsQ0FBQ2lHLE9BQXJCLENBQTZCLENBQUM1RSxHQUFELEVBQU05SSxNQUFOLEtBQWlCO0FBQzFDLG9CQUFJOEksR0FBSixFQUFRO0FBQ0p4Six5QkFBTyxDQUFDQyxHQUFSLENBQVl1SixHQUFaO0FBQ0g7QUFDSixlQUpEO0FBS0g7O0FBRUQsZ0JBQUkrRSxTQUFTLEdBQUcsSUFBSWhNLElBQUosRUFBaEI7QUFDQXZDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSxvQ0FBbUMsQ0FBQ3NPLFNBQVMsR0FBQ0QsV0FBWCxJQUF3QixJQUEzRCxHQUFpRSxVQUE3RTs7QUFFQSxnQkFBSWxHLGFBQWEsQ0FBQ2xILE1BQWQsR0FBdUIsQ0FBM0IsRUFBNkI7QUFDekJrSCwyQkFBYSxDQUFDZ0csT0FBZCxDQUFzQixDQUFDNUUsR0FBRCxFQUFNOUksTUFBTixLQUFpQjtBQUNuQyxvQkFBSThJLEdBQUosRUFBUTtBQUNKeEoseUJBQU8sQ0FBQ0MsR0FBUixDQUFZdUosR0FBWjtBQUNIO0FBQ0osZUFKRDtBQUtIOztBQUVELGdCQUFJbkIsZUFBZSxDQUFDbkgsTUFBaEIsR0FBeUIsQ0FBN0IsRUFBK0I7QUFDM0JtSCw2QkFBZSxDQUFDK0YsT0FBaEIsQ0FBd0IsQ0FBQzVFLEdBQUQsRUFBTTlJLE1BQU4sS0FBaUI7QUFDckMsb0JBQUk4SSxHQUFKLEVBQVE7QUFDSnhKLHlCQUFPLENBQUNDLEdBQVIsQ0FBWXVKLEdBQVo7QUFDSDtBQUNKLGVBSkQ7QUFLSCxhQTNhMEIsQ0E2YTNCOzs7QUFFQSxnQkFBSWpFLE1BQU0sR0FBRyxFQUFULElBQWUsQ0FBbkIsRUFBcUI7QUFDakJ2RixxQkFBTyxDQUFDQyxHQUFSLENBQVksaURBQVo7QUFDQSxrQkFBSXVPLGdCQUFnQixHQUFHaFAsVUFBVSxDQUFDeUYsSUFBWCxDQUFnQjtBQUFDNkIsc0JBQU0sRUFBQyxDQUFSO0FBQVU0RixzQkFBTSxFQUFDO0FBQWpCLGVBQWhCLEVBQXdDO0FBQUN4RixvQkFBSSxFQUFDO0FBQUNxRCw4QkFBWSxFQUFDLENBQUM7QUFBZjtBQUFOLGVBQXhDLEVBQWtFcEYsS0FBbEUsRUFBdkI7QUFDQSxrQkFBSXNKLFlBQVksR0FBR2pELElBQUksQ0FBQ2tELElBQUwsQ0FBVUYsZ0JBQWdCLENBQUN0TixNQUFqQixHQUF3QixHQUFsQyxDQUFuQjtBQUNBLGtCQUFJeU4sZUFBZSxHQUFHSCxnQkFBZ0IsQ0FBQ3ROLE1BQWpCLEdBQTBCdU4sWUFBaEQ7QUFFQSxrQkFBSUcsY0FBYyxHQUFHLENBQXJCO0FBQ0Esa0JBQUlDLGlCQUFpQixHQUFHLENBQXhCO0FBRUEsa0JBQUlDLGdCQUFnQixHQUFHLENBQXZCO0FBQ0Esa0JBQUlDLGlCQUFpQixHQUFHLENBQXhCO0FBQ0Esa0JBQUlDLG9CQUFvQixHQUFHLENBQTNCO0FBQ0Esa0JBQUlDLHFCQUFxQixHQUFHLENBQTVCOztBQUlBLG1CQUFLM1AsQ0FBTCxJQUFVa1AsZ0JBQVYsRUFBMkI7QUFDdkIsb0JBQUlsUCxDQUFDLEdBQUdtUCxZQUFSLEVBQXFCO0FBQ2pCRyxnQ0FBYyxJQUFJSixnQkFBZ0IsQ0FBQ2xQLENBQUQsQ0FBaEIsQ0FBb0JpTCxZQUF0QztBQUNILGlCQUZELE1BR0k7QUFDQXNFLG1DQUFpQixJQUFJTCxnQkFBZ0IsQ0FBQ2xQLENBQUQsQ0FBaEIsQ0FBb0JpTCxZQUF6QztBQUNIOztBQUdELG9CQUFJeUUsb0JBQW9CLEdBQUcsSUFBM0IsRUFBZ0M7QUFDNUJBLHNDQUFvQixJQUFJUixnQkFBZ0IsQ0FBQ2xQLENBQUQsQ0FBaEIsQ0FBb0JpTCxZQUFwQixHQUFtQ3ZDLGFBQWEsQ0FBQ3VDLFlBQXpFO0FBQ0F1RSxrQ0FBZ0I7QUFDbkI7QUFDSjs7QUFFREcsbUNBQXFCLEdBQUcsSUFBSUQsb0JBQTVCO0FBQ0FELCtCQUFpQixHQUFHUCxnQkFBZ0IsQ0FBQ3ROLE1BQWpCLEdBQTBCNE4sZ0JBQTlDO0FBRUEsa0JBQUlJLE1BQU0sR0FBRztBQUNUM0osc0JBQU0sRUFBRUEsTUFEQztBQUVUa0osNEJBQVksRUFBRUEsWUFGTDtBQUdURyw4QkFBYyxFQUFFQSxjQUhQO0FBSVRELCtCQUFlLEVBQUVBLGVBSlI7QUFLVEUsaUNBQWlCLEVBQUVBLGlCQUxWO0FBTVRDLGdDQUFnQixFQUFFQSxnQkFOVDtBQU9URSxvQ0FBb0IsRUFBRUEsb0JBUGI7QUFRVEQsaUNBQWlCLEVBQUVBLGlCQVJWO0FBU1RFLHFDQUFxQixFQUFFQSxxQkFUZDtBQVVURSw2QkFBYSxFQUFFWCxnQkFBZ0IsQ0FBQ3ROLE1BVnZCO0FBV1RrTyxnQ0FBZ0IsRUFBRXBILGFBQWEsQ0FBQ3VDLFlBWHZCO0FBWVRhLHlCQUFTLEVBQUU3QyxTQUFTLENBQUNqRyxJQVpaO0FBYVQrTSx3QkFBUSxFQUFFLElBQUk5TSxJQUFKO0FBYkQsZUFBYjtBQWdCQXZDLHFCQUFPLENBQUNDLEdBQVIsQ0FBWWlQLE1BQVo7QUFFQXpMLDZCQUFlLENBQUNpRyxNQUFoQixDQUF1QndGLE1BQXZCO0FBQ0g7QUFDSjtBQUNKLFNBOWVELENBK2VBLE9BQU9uUCxDQUFQLEVBQVM7QUFDTEMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0F1SCxpQkFBTyxHQUFHLEtBQVY7QUFDQSxpQkFBTyxTQUFQO0FBQ0g7O0FBQ0QsWUFBSWdJLFlBQVksR0FBRyxJQUFJL00sSUFBSixFQUFuQjtBQUNBdkMsZUFBTyxDQUFDQyxHQUFSLENBQVksc0JBQXFCLENBQUNxUCxZQUFZLEdBQUN2SCxjQUFkLElBQThCLElBQW5ELEdBQXlELFVBQXJFO0FBQ0g7O0FBQ0RULGFBQU8sR0FBRyxLQUFWO0FBQ0FqRSxXQUFLLENBQUN1SSxNQUFOLENBQWE7QUFBQ1gsZUFBTyxFQUFDOUwsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI2RTtBQUFoQyxPQUFiLEVBQXVEO0FBQUNILFlBQUksRUFBQztBQUFDeUUsOEJBQW9CLEVBQUMsSUFBSWhOLElBQUosRUFBdEI7QUFBa0NxRix5QkFBZSxFQUFDQTtBQUFsRDtBQUFOLE9BQXZEO0FBQ0g7O0FBRUQsV0FBT0wsS0FBUDtBQUNILEdBbG5CVTtBQW1uQlgsY0FBWSxVQUFTSixLQUFULEVBQWdCO0FBQ3hCO0FBQ0EsV0FBUUEsS0FBSyxHQUFDLEVBQWQ7QUFDSCxHQXRuQlU7QUF1bkJYLGFBQVcsVUFBU0EsS0FBVCxFQUFnQjtBQUN2QixRQUFJQSxLQUFLLEdBQUdoSSxNQUFNLENBQUNxSSxJQUFQLENBQVksa0JBQVosQ0FBWixFQUE2QztBQUN6QyxhQUFRLEtBQVI7QUFDSCxLQUZELE1BRU87QUFDSCxhQUFRLElBQVI7QUFDSDtBQUNKO0FBN25CVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDN0RBLElBQUlySSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUk4RCxTQUFKO0FBQWNoRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMrRCxXQUFTLENBQUM5RCxDQUFELEVBQUc7QUFBQzhELGFBQVMsR0FBQzlELENBQVY7QUFBWTs7QUFBMUIsQ0FBM0IsRUFBdUQsQ0FBdkQ7QUFBMEQsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBN0MsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSXFFLFlBQUo7QUFBaUJ2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDc0UsY0FBWSxDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxnQkFBWSxHQUFDckUsQ0FBYjtBQUFlOztBQUFoQyxDQUFqRCxFQUFtRixDQUFuRjtBQUt0UGtRLGdCQUFnQixDQUFDLGVBQUQsRUFBa0IsVUFBU3JJLEtBQVQsRUFBZTtBQUM3QyxTQUFPO0FBQ0hsQyxRQUFJLEdBQUU7QUFDRixhQUFPN0IsU0FBUyxDQUFDNkIsSUFBVixDQUFlLEVBQWYsRUFBbUI7QUFBQ2tDLGFBQUssRUFBRUEsS0FBUjtBQUFlRCxZQUFJLEVBQUU7QUFBQzNCLGdCQUFNLEVBQUUsQ0FBQztBQUFWO0FBQXJCLE9BQW5CLENBQVA7QUFDSCxLQUhFOztBQUlIa0ssWUFBUSxFQUFFLENBQ047QUFDSXhLLFVBQUksQ0FBQ0ssS0FBRCxFQUFPO0FBQ1AsZUFBTzlGLFVBQVUsQ0FBQ3lGLElBQVgsQ0FDSDtBQUFDOUUsaUJBQU8sRUFBQ21GLEtBQUssQ0FBQ0o7QUFBZixTQURHLEVBRUg7QUFBQ2lDLGVBQUssRUFBQztBQUFQLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE07QUFKUCxHQUFQO0FBZUgsQ0FoQmUsQ0FBaEI7QUFrQkFxSSxnQkFBZ0IsQ0FBQyxnQkFBRCxFQUFtQixVQUFTakssTUFBVCxFQUFnQjtBQUMvQyxTQUFPO0FBQ0hOLFFBQUksR0FBRTtBQUNGLGFBQU83QixTQUFTLENBQUM2QixJQUFWLENBQWU7QUFBQ00sY0FBTSxFQUFDQTtBQUFSLE9BQWYsQ0FBUDtBQUNILEtBSEU7O0FBSUhrSyxZQUFRLEVBQUUsQ0FDTjtBQUNJeEssVUFBSSxDQUFDSyxLQUFELEVBQU87QUFDUCxlQUFPM0IsWUFBWSxDQUFDc0IsSUFBYixDQUNIO0FBQUNNLGdCQUFNLEVBQUNELEtBQUssQ0FBQ0M7QUFBZCxTQURHLENBQVA7QUFHSDs7QUFMTCxLQURNLEVBUU47QUFDSU4sVUFBSSxDQUFDSyxLQUFELEVBQU87QUFDUCxlQUFPOUYsVUFBVSxDQUFDeUYsSUFBWCxDQUNIO0FBQUM5RSxpQkFBTyxFQUFDbUYsS0FBSyxDQUFDSjtBQUFmLFNBREcsRUFFSDtBQUFDaUMsZUFBSyxFQUFDO0FBQVAsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FSTTtBQUpQLEdBQVA7QUFzQkgsQ0F2QmUsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUN2QkEvSCxNQUFNLENBQUNzUSxNQUFQLENBQWM7QUFBQ3RNLFdBQVMsRUFBQyxNQUFJQTtBQUFmLENBQWQ7QUFBeUMsSUFBSXVNLEtBQUo7QUFBVXZRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3NRLE9BQUssQ0FBQ3JRLENBQUQsRUFBRztBQUFDcVEsU0FBSyxHQUFDclEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUExQyxFQUF3RSxDQUF4RTtBQUc3RyxNQUFNOEQsU0FBUyxHQUFHLElBQUl1TSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsUUFBckIsQ0FBbEI7QUFFUHhNLFNBQVMsQ0FBQ3lNLE9BQVYsQ0FBa0I7QUFDZEMsVUFBUSxHQUFFO0FBQ04sV0FBT3RRLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQ3JCLGFBQU8sRUFBQyxLQUFLK0U7QUFBZCxLQUFuQixDQUFQO0FBQ0g7O0FBSGEsQ0FBbEIsRSxDQU1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCOzs7Ozs7Ozs7OztBQ3RCQSxJQUFJL0YsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUl3RSxVQUFKO0FBQWUxRSxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDeUUsWUFBVSxDQUFDeEUsQ0FBRCxFQUFHO0FBQUN3RSxjQUFVLEdBQUN4RSxDQUFYO0FBQWE7O0FBQTVCLENBQXZDLEVBQXFFLENBQXJFO0FBQXdFLElBQUkrRCxLQUFKLEVBQVUwTSxXQUFWO0FBQXNCM1EsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDZ0UsT0FBSyxDQUFDL0QsQ0FBRCxFQUFHO0FBQUMrRCxTQUFLLEdBQUMvRCxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CeVEsYUFBVyxDQUFDelEsQ0FBRCxFQUFHO0FBQUN5USxlQUFXLEdBQUN6USxDQUFaO0FBQWM7O0FBQWhELENBQTFCLEVBQTRFLENBQTVFO0FBQStFLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBQThFLElBQUlvRSxrQkFBSjtBQUF1QnRFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtCQUFaLEVBQTRDO0FBQUNxRSxvQkFBa0IsQ0FBQ3BFLENBQUQsRUFBRztBQUFDb0Usc0JBQWtCLEdBQUNwRSxDQUFuQjtBQUFxQjs7QUFBNUMsQ0FBNUMsRUFBMEYsQ0FBMUY7O0FBT3hhMFEsZUFBZSxHQUFHLENBQUN6TyxTQUFELEVBQVkwTyxhQUFaLEtBQThCO0FBQzVDLE9BQUssSUFBSTNRLENBQVQsSUFBYzJRLGFBQWQsRUFBNEI7QUFDeEIsUUFBSTFPLFNBQVMsQ0FBQzBLLE9BQVYsQ0FBa0JwTCxLQUFsQixJQUEyQm9QLGFBQWEsQ0FBQzNRLENBQUQsQ0FBYixDQUFpQjJNLE9BQWpCLENBQXlCcEwsS0FBeEQsRUFBOEQ7QUFDMUQsYUFBT2tKLFFBQVEsQ0FBQ2tHLGFBQWEsQ0FBQzNRLENBQUQsQ0FBYixDQUFpQjRRLEtBQWxCLENBQWY7QUFDSDtBQUNKO0FBQ0osQ0FORDs7QUFRQS9RLE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsNkJBQTJCLFlBQVU7QUFDakMsU0FBS0UsT0FBTDtBQUNBLFFBQUlWLEdBQUcsR0FBR21ILEdBQUcsR0FBQyx1QkFBZDs7QUFDQSxRQUFHO0FBQ0MsVUFBSXZHLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjtBQUNBLFVBQUl5USxTQUFTLEdBQUc1UCxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFoQjtBQUNBMFAsZUFBUyxHQUFHQSxTQUFTLENBQUN6UCxNQUF0QjtBQUNBLFVBQUk2RSxNQUFNLEdBQUc0SyxTQUFTLENBQUNDLFdBQVYsQ0FBc0I3SyxNQUFuQztBQUNBLFVBQUk4SyxLQUFLLEdBQUdGLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQkMsS0FBbEM7QUFDQSxVQUFJQyxJQUFJLEdBQUdILFNBQVMsQ0FBQ0MsV0FBVixDQUFzQkUsSUFBakM7QUFDQSxVQUFJQyxVQUFVLEdBQUcvRSxJQUFJLENBQUM2RSxLQUFMLENBQVdyTyxVQUFVLENBQUNtTyxTQUFTLENBQUNDLFdBQVYsQ0FBc0JJLEtBQXRCLENBQTRCSCxLQUE1QixFQUFtQ0ksa0JBQW5DLENBQXNEQyxLQUF0RCxDQUE0RCxHQUE1RCxFQUFpRSxDQUFqRSxDQUFELENBQVYsR0FBZ0YsR0FBM0YsQ0FBakI7QUFFQXJOLFdBQUssQ0FBQ3VJLE1BQU4sQ0FBYTtBQUFDWCxlQUFPLEVBQUM5TCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjZFO0FBQWhDLE9BQWIsRUFBdUQ7QUFBQ0gsWUFBSSxFQUFDO0FBQ3pENkYsc0JBQVksRUFBRXBMLE1BRDJDO0FBRXpEcUwscUJBQVcsRUFBRVAsS0FGNEM7QUFHekRRLG9CQUFVLEVBQUVQLElBSDZDO0FBSXpEQyxvQkFBVSxFQUFFQSxVQUo2QztBQUt6RHJMLHlCQUFlLEVBQUVpTCxTQUFTLENBQUNDLFdBQVYsQ0FBc0JsTSxVQUF0QixDQUFpQzRMLFFBQWpDLENBQTBDM1AsT0FMRjtBQU16RDJRLGtCQUFRLEVBQUVYLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQkksS0FBdEIsQ0FBNEJILEtBQTVCLEVBQW1DUyxRQU5ZO0FBT3pEOUgsb0JBQVUsRUFBRW1ILFNBQVMsQ0FBQ0MsV0FBVixDQUFzQkksS0FBdEIsQ0FBNEJILEtBQTVCLEVBQW1Dckg7QUFQVTtBQUFOLE9BQXZEO0FBU0gsS0FsQkQsQ0FtQkEsT0FBTWpKLENBQU4sRUFBUTtBQUNKQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osR0ExQlU7QUEyQlgsd0JBQXNCLFlBQVU7QUFDNUIsU0FBS0ssT0FBTDtBQUNBLFFBQUlWLEdBQUcsR0FBR21ILEdBQUcsR0FBQyxTQUFkOztBQUNBLFFBQUc7QUFDQyxVQUFJdkcsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsVUFBSW9ILE1BQU0sR0FBR3ZHLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWI7QUFDQXFHLFlBQU0sR0FBR0EsTUFBTSxDQUFDcEcsTUFBaEI7QUFDQSxVQUFJcVEsS0FBSyxHQUFHLEVBQVo7QUFDQUEsV0FBSyxDQUFDOUYsT0FBTixHQUFnQm5FLE1BQU0sQ0FBQ2tLLFNBQVAsQ0FBaUJDLE9BQWpDO0FBQ0FGLFdBQUssQ0FBQ0csaUJBQU4sR0FBMEJwSyxNQUFNLENBQUNDLFNBQVAsQ0FBaUJDLG1CQUEzQztBQUNBK0osV0FBSyxDQUFDSSxlQUFOLEdBQXdCckssTUFBTSxDQUFDQyxTQUFQLENBQWlCcUssaUJBQXpDO0FBRUEsVUFBSUMsV0FBVyxHQUFHdEIsV0FBVyxDQUFDdk8sT0FBWixDQUFvQixFQUFwQixFQUF3QjtBQUFDMEYsWUFBSSxFQUFFO0FBQUMzQixnQkFBTSxFQUFFLENBQUM7QUFBVjtBQUFQLE9BQXhCLENBQWxCOztBQUNBLFVBQUk4TCxXQUFXLElBQUlBLFdBQVcsQ0FBQzlMLE1BQVosSUFBc0J3TCxLQUFLLENBQUNHLGlCQUEvQyxFQUFrRTtBQUM5RCxtREFBb0NILEtBQUssQ0FBQ0csaUJBQTFDLHVCQUF3RUcsV0FBVyxDQUFDOUwsTUFBcEY7QUFDSDs7QUFFRDdGLFNBQUcsR0FBR21ILEdBQUcsR0FBQyxhQUFWO0FBQ0F2RyxjQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQSxVQUFJd0UsVUFBVSxHQUFHM0QsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBakI7QUFDQXlELGdCQUFVLEdBQUdBLFVBQVUsQ0FBQ3hELE1BQVgsQ0FBa0J3RCxVQUEvQjtBQUNBNk0sV0FBSyxDQUFDN00sVUFBTixHQUFtQkEsVUFBVSxDQUFDaEQsTUFBOUI7QUFDQSxVQUFJb1EsUUFBUSxHQUFHLENBQWY7O0FBQ0EsV0FBS2hTLENBQUwsSUFBVTRFLFVBQVYsRUFBcUI7QUFDakJvTixnQkFBUSxJQUFJdkgsUUFBUSxDQUFDN0YsVUFBVSxDQUFDNUUsQ0FBRCxDQUFWLENBQWNpTCxZQUFmLENBQXBCO0FBQ0g7O0FBQ0R3RyxXQUFLLENBQUNRLGlCQUFOLEdBQTBCRCxRQUExQjtBQUdBak8sV0FBSyxDQUFDdUksTUFBTixDQUFhO0FBQUNYLGVBQU8sRUFBQzhGLEtBQUssQ0FBQzlGO0FBQWYsT0FBYixFQUFzQztBQUFDSCxZQUFJLEVBQUNpRztBQUFOLE9BQXRDLEVBQW9EO0FBQUNuRyxjQUFNLEVBQUU7QUFBVCxPQUFwRCxFQTFCRCxDQTJCQzs7QUFDQSxVQUFJYixRQUFRLENBQUNnSCxLQUFLLENBQUNHLGlCQUFQLENBQVIsR0FBb0MsQ0FBeEMsRUFBMEM7QUFDdEMsWUFBSU0sV0FBVyxHQUFHLEVBQWxCO0FBQ0FBLG1CQUFXLENBQUNqTSxNQUFaLEdBQXFCd0UsUUFBUSxDQUFDakQsTUFBTSxDQUFDQyxTQUFQLENBQWlCQyxtQkFBbEIsQ0FBN0I7QUFDQXdLLG1CQUFXLENBQUNsUCxJQUFaLEdBQW1CLElBQUlDLElBQUosQ0FBU3VFLE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQnFLLGlCQUExQixDQUFuQjtBQUVBMVIsV0FBRyxHQUFHRyxHQUFHLEdBQUcsZUFBWjs7QUFDQSxZQUFHO0FBQ0NTLGtCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQSxjQUFJK1IsT0FBTyxHQUFHbFIsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTNDLENBRkQsQ0FHQztBQUNBOztBQUNBOFEscUJBQVcsQ0FBQ0UsWUFBWixHQUEyQjNILFFBQVEsQ0FBQzBILE9BQU8sQ0FBQ0UsYUFBVCxDQUFuQztBQUNBSCxxQkFBVyxDQUFDSSxlQUFaLEdBQThCN0gsUUFBUSxDQUFDMEgsT0FBTyxDQUFDSSxpQkFBVCxDQUF0QztBQUNILFNBUEQsQ0FRQSxPQUFNOVIsQ0FBTixFQUFRO0FBQ0pDLGlCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUVETCxXQUFHLEdBQUdHLEdBQUcsR0FBRyxnQkFBTixHQUF1QlYsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUIwTCxZQUFwRDs7QUFDQSxZQUFHO0FBQ0N4UixrQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0EsY0FBSXFTLE1BQU0sR0FBR3hSLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUExQztBQUNBOFEscUJBQVcsQ0FBQ1EsV0FBWixHQUEwQmpJLFFBQVEsQ0FBQ2dJLE1BQUQsQ0FBbEM7QUFDSCxTQUpELENBS0EsT0FBTWhTLENBQU4sRUFBUTtBQUNKQyxpQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFFREwsV0FBRyxHQUFHRyxHQUFHLEdBQUcsOEJBQVo7O0FBQ0EsWUFBSTtBQUNBUyxrQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0EsY0FBSXVTLElBQUksR0FBRzFSLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUF4Qzs7QUFDQSxjQUFJdVIsSUFBSSxJQUFJQSxJQUFJLENBQUMvUSxNQUFMLEdBQWMsQ0FBMUIsRUFBNEI7QUFDeEJzUSx1QkFBVyxDQUFDVSxhQUFaLEdBQTRCLEVBQTVCO0FBQ0FELGdCQUFJLENBQUM5UCxPQUFMLENBQWEsQ0FBQ2dRLE1BQUQsRUFBU3RQLENBQVQsS0FBZTtBQUN4QjJPLHlCQUFXLENBQUNVLGFBQVosQ0FBMEIvSSxJQUExQixDQUErQjtBQUMzQmlKLHFCQUFLLEVBQUVELE1BQU0sQ0FBQ0MsS0FEYTtBQUUzQkQsc0JBQU0sRUFBRW5RLFVBQVUsQ0FBQ21RLE1BQU0sQ0FBQ0EsTUFBUjtBQUZTLGVBQS9CO0FBSUgsYUFMRDtBQU1IO0FBQ0osU0FaRCxDQWFBLE9BQU9wUyxDQUFQLEVBQVM7QUFDTEMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBRURMLFdBQUcsR0FBR0csR0FBRyxHQUFHLG9CQUFaOztBQUNBLFlBQUc7QUFDQ1Msa0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLGNBQUkyUyxTQUFTLEdBQUc5UixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBN0M7O0FBQ0EsY0FBSTJSLFNBQUosRUFBYztBQUNWYix1QkFBVyxDQUFDYSxTQUFaLEdBQXdCclEsVUFBVSxDQUFDcVEsU0FBRCxDQUFsQztBQUNIO0FBQ0osU0FORCxDQU9BLE9BQU10UyxDQUFOLEVBQVE7QUFDSkMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBRURMLFdBQUcsR0FBR0csR0FBRyxHQUFHLDRCQUFaOztBQUNBLFlBQUc7QUFDQ1Msa0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLGNBQUk0UyxVQUFVLEdBQUcvUixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFqQjs7QUFDQSxjQUFJNlIsVUFBSixFQUFlO0FBQ1hkLHVCQUFXLENBQUNlLGdCQUFaLEdBQStCdlEsVUFBVSxDQUFDc1EsVUFBVSxDQUFDNVIsTUFBWixDQUF6QztBQUNIO0FBQ0osU0FORCxDQU9BLE9BQU1YLENBQU4sRUFBUTtBQUNKQyxpQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFFRGdRLG1CQUFXLENBQUNyRyxNQUFaLENBQW1COEgsV0FBbkI7QUFDSCxPQW5HRixDQXFHQztBQUVBO0FBQ0E7OztBQUNBLGFBQU9ULEtBQUssQ0FBQ0csaUJBQWI7QUFDSCxLQTFHRCxDQTJHQSxPQUFPblIsQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0EsYUFBTyw2QkFBUDtBQUNIO0FBQ0osR0E3SVU7QUE4SVgsMkJBQXlCLFlBQVU7QUFDL0JzRCxTQUFLLENBQUM0QixJQUFOLEdBQWFpQyxJQUFiLENBQWtCO0FBQUNzTCxhQUFPLEVBQUMsQ0FBQztBQUFWLEtBQWxCLEVBQWdDckwsS0FBaEMsQ0FBc0MsQ0FBdEM7QUFDSCxHQWhKVTtBQWlKWCxtQkFBaUIsWUFBVTtBQUN2QixRQUFJNEosS0FBSyxHQUFHMU4sS0FBSyxDQUFDN0IsT0FBTixDQUFjO0FBQUN5SixhQUFPLEVBQUU5TCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjZFO0FBQWpDLEtBQWQsQ0FBWjs7QUFFQSxRQUFJOEYsS0FBSyxJQUFJQSxLQUFLLENBQUMwQixXQUFuQixFQUErQjtBQUMzQnpTLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGlDQUFaO0FBQ0gsS0FGRCxNQUdLLElBQUlkLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0J1TSxLQUFoQixDQUFzQkQsV0FBMUIsRUFBdUM7QUFDeEN6UyxhQUFPLENBQUNDLEdBQVIsQ0FBWSx1Q0FBWjtBQUNBLFVBQUlLLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNULE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0J3TSxXQUF6QixDQUFmO0FBQ0EsVUFBSUMsT0FBTyxHQUFHclMsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBZDtBQUNBLFVBQUlvUyxLQUFLLEdBQUdELE9BQU8sQ0FBQ0UsU0FBUixDQUFrQkQsS0FBbEIsSUFBMkJELE9BQU8sQ0FBQ0UsU0FBUixDQUFrQkMsWUFBekQ7QUFDQSxVQUFJQyxXQUFXLEdBQUc7QUFDZC9ILGVBQU8sRUFBRTJILE9BQU8sQ0FBQzFILFFBREg7QUFFZCtILG1CQUFXLEVBQUVMLE9BQU8sQ0FBQ00sWUFGUDtBQUdkQyx1QkFBZSxFQUFFUCxPQUFPLENBQUNRLGdCQUhYO0FBSWRDLFlBQUksRUFBRVQsT0FBTyxDQUFDRSxTQUFSLENBQWtCTyxJQUpWO0FBS2RDLFlBQUksRUFBRVYsT0FBTyxDQUFDRSxTQUFSLENBQWtCUSxJQUxWO0FBTWRDLGVBQU8sRUFBRTtBQUNMdEIsY0FBSSxFQUFFVyxPQUFPLENBQUNFLFNBQVIsQ0FBa0JTLE9BQWxCLENBQTBCdEIsSUFEM0I7QUFFTDVLLGdCQUFNLEVBQUV1TCxPQUFPLENBQUNFLFNBQVIsQ0FBa0JTLE9BQWxCLENBQTBCbE07QUFGN0IsU0FOSztBQVVkbU0sWUFBSSxFQUFFWixPQUFPLENBQUNFLFNBQVIsQ0FBa0JVLElBVlY7QUFXZFgsYUFBSyxFQUFFO0FBQ0hZLHNCQUFZLEVBQUVaLEtBQUssQ0FBQ2EsYUFEakI7QUFFSEMsNEJBQWtCLEVBQUVkLEtBQUssQ0FBQ2Usb0JBRnZCO0FBR0hDLDZCQUFtQixFQUFFaEIsS0FBSyxDQUFDaUIscUJBSHhCO0FBSUhDLDZCQUFtQixFQUFFbEIsS0FBSyxDQUFDbUI7QUFKeEIsU0FYTztBQWlCZEMsV0FBRyxFQUFFLElBakJTO0FBa0JkQyxnQkFBUSxFQUFDO0FBQ0w3TSxnQkFBTSxFQUFFdUwsT0FBTyxDQUFDRSxTQUFSLENBQWtCb0IsUUFBbEIsQ0FBMkI3TTtBQUQ5QixTQWxCSztBQXFCZDBLLGNBQU0sRUFBRWEsT0FBTyxDQUFDRSxTQUFSLENBQWtCZixNQXJCWjtBQXNCZG9DLGNBQU0sRUFBRXZCLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQnFCO0FBdEJaLE9BQWxCO0FBeUJBLFVBQUkvRSxnQkFBZ0IsR0FBRyxDQUF2QixDQTlCd0MsQ0FnQ3hDOztBQUNBLFVBQUl3RCxPQUFPLENBQUNFLFNBQVIsQ0FBa0JzQixPQUFsQixJQUE2QnhCLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQnNCLE9BQWxCLENBQTBCQyxNQUF2RCxJQUFrRXpCLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQnNCLE9BQWxCLENBQTBCQyxNQUExQixDQUFpQ25ULE1BQWpDLEdBQTBDLENBQWhILEVBQW1IO0FBQy9HLGFBQUsyQixDQUFMLElBQVUrUCxPQUFPLENBQUNFLFNBQVIsQ0FBa0JzQixPQUFsQixDQUEwQkMsTUFBcEMsRUFBMkM7QUFDdkMsY0FBSUMsR0FBRyxHQUFHMUIsT0FBTyxDQUFDRSxTQUFSLENBQWtCc0IsT0FBbEIsQ0FBMEJDLE1BQTFCLENBQWlDeFIsQ0FBakMsRUFBb0NoQyxLQUFwQyxDQUEwQ3lULEdBQXBELENBRHVDLENBRXZDOztBQUNBLGVBQUtDLENBQUwsSUFBVUQsR0FBVixFQUFjO0FBQ1YsZ0JBQUlBLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU8zVCxJQUFQLElBQWUsK0JBQW5CLEVBQW1EO0FBQy9DWixxQkFBTyxDQUFDQyxHQUFSLENBQVlxVSxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPMVQsS0FBbkIsRUFEK0MsQ0FFL0M7O0FBQ0Esa0JBQUlVLFNBQVMsR0FBRztBQUNab0csZ0NBQWdCLEVBQUUyTSxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPMVQsS0FBUCxDQUFhMlQsTUFEbkI7QUFFWmhJLDJCQUFXLEVBQUU4SCxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPMVQsS0FBUCxDQUFhMkwsV0FGZDtBQUdaM0ssMEJBQVUsRUFBRXlTLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU8xVCxLQUFQLENBQWFnQixVQUhiO0FBSVo4SyxtQ0FBbUIsRUFBRTJILEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU8xVCxLQUFQLENBQWE4TCxtQkFKdEI7QUFLWmpMLGdDQUFnQixFQUFFNFMsR0FBRyxDQUFDQyxDQUFELENBQUgsQ0FBTzFULEtBQVAsQ0FBYXVJLGlCQUxuQjtBQU1aekgsaUNBQWlCLEVBQUUyUyxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPMVQsS0FBUCxDQUFhYyxpQkFOcEI7QUFPWjRJLDRCQUFZLEVBQUVpQixJQUFJLENBQUNpSixLQUFMLENBQVcxSyxRQUFRLENBQUN1SyxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPMVQsS0FBUCxDQUFhQSxLQUFiLENBQW1Cc1IsTUFBcEIsQ0FBUixHQUFzQ2hULE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCc08sZUFBeEUsQ0FQRjtBQVFaaEksc0JBQU0sRUFBRSxLQVJJO0FBU1o1RixzQkFBTSxFQUFFO0FBVEksZUFBaEI7QUFZQXNJLDhCQUFnQixJQUFJN04sU0FBUyxDQUFDZ0osWUFBOUI7QUFFQSxrQkFBSW9LLFdBQVcsR0FBR3hWLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QjhNLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU8xVCxLQUFQLENBQWEyVCxNQUEzQyxDQUFsQixDQWpCK0MsQ0FrQi9DOztBQUVBalQsdUJBQVMsQ0FBQzBLLE9BQVYsR0FBb0I7QUFDaEIsd0JBQU8sMEJBRFM7QUFFaEIseUJBQVEwSTtBQUZRLGVBQXBCO0FBS0FwVCx1QkFBUyxDQUFDcEIsT0FBVixHQUFvQjJELFVBQVUsQ0FBQ3ZDLFNBQVMsQ0FBQzBLLE9BQVgsQ0FBOUI7QUFDQTFLLHVCQUFTLENBQUMySyxNQUFWLEdBQW1CL00sTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCakcsU0FBUyxDQUFDMEssT0FBeEMsRUFBaUQ5TSxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QitGLGtCQUF4RSxDQUFuQjtBQUNBNUssdUJBQVMsQ0FBQzZLLGVBQVYsR0FBNEJqTixNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJqRyxTQUFTLENBQUMwSyxPQUF4QyxFQUFpRDlNLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCaUcsa0JBQXhFLENBQTVCO0FBQ0EzSSxnQ0FBa0IsQ0FBQ2dHLE1BQW5CLENBQTBCO0FBQ3RCdkosdUJBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCLE9BREc7QUFFdEJnTixpQ0FBaUIsRUFBRSxDQUZHO0FBR3RCNUMsNEJBQVksRUFBRWhKLFNBQVMsQ0FBQ2dKLFlBSEY7QUFJdEIzSixvQkFBSSxFQUFFLEtBSmdCO0FBS3RCMkUsc0JBQU0sRUFBRSxDQUxjO0FBTXRCNkgsMEJBQVUsRUFBRXdGLE9BQU8sQ0FBQ007QUFORSxlQUExQjtBQVNBMVQsd0JBQVUsQ0FBQ2tLLE1BQVgsQ0FBa0JuSSxTQUFsQjtBQUNIO0FBQ0o7QUFDSjtBQUNKLE9BL0V1QyxDQWlGeEM7OztBQUNBdkIsYUFBTyxDQUFDQyxHQUFSLENBQVkscUNBQVo7O0FBQ0EsVUFBSTJTLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEJyUCxVQUExQixJQUF3QzBPLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEJyUCxVQUExQixDQUFxQ2hELE1BQXJDLEdBQThDLENBQTFGLEVBQTRGO0FBQ3hGbEIsZUFBTyxDQUFDQyxHQUFSLENBQVkyUyxPQUFPLENBQUNFLFNBQVIsQ0FBa0JTLE9BQWxCLENBQTBCclAsVUFBMUIsQ0FBcUNoRCxNQUFqRDtBQUNBLFlBQUkwVCxnQkFBZ0IsR0FBR2hDLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEJyUCxVQUFqRDtBQUNBLFlBQUkrTCxhQUFhLEdBQUcyQyxPQUFPLENBQUMxTyxVQUE1Qjs7QUFDQSxhQUFLLElBQUk1RSxDQUFULElBQWNzVixnQkFBZCxFQUErQjtBQUMzQjtBQUNBLGNBQUlyVCxTQUFTLEdBQUdxVCxnQkFBZ0IsQ0FBQ3RWLENBQUQsQ0FBaEM7QUFDQWlDLG1CQUFTLENBQUNJLGlCQUFWLEdBQThCeEMsTUFBTSxDQUFDcUksSUFBUCxDQUFZLGNBQVosRUFBNEJvTixnQkFBZ0IsQ0FBQ3RWLENBQUQsQ0FBaEIsQ0FBb0JvQyxnQkFBaEQsQ0FBOUI7QUFFQSxjQUFJaVQsV0FBVyxHQUFHeFYsTUFBTSxDQUFDcUksSUFBUCxDQUFZLGdCQUFaLEVBQThCakcsU0FBUyxDQUFDb0csZ0JBQXhDLENBQWxCO0FBRUFwRyxtQkFBUyxDQUFDMEssT0FBVixHQUFvQjtBQUNoQixvQkFBTywwQkFEUztBQUVoQixxQkFBUTBJO0FBRlEsV0FBcEI7QUFLQXBULG1CQUFTLENBQUNwQixPQUFWLEdBQW9CMkQsVUFBVSxDQUFDdkMsU0FBUyxDQUFDMEssT0FBWCxDQUE5QjtBQUNBMUssbUJBQVMsQ0FBQzBLLE9BQVYsR0FBb0IxSyxTQUFTLENBQUMwSyxPQUE5QjtBQUNBMUssbUJBQVMsQ0FBQzJLLE1BQVYsR0FBbUIvTSxNQUFNLENBQUNxSSxJQUFQLENBQVksZ0JBQVosRUFBOEJqRyxTQUFTLENBQUMwSyxPQUF4QyxFQUFpRDlNLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCK0Ysa0JBQXhFLENBQW5CO0FBQ0E1SyxtQkFBUyxDQUFDNkssZUFBVixHQUE0QmpOLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmpHLFNBQVMsQ0FBQzBLLE9BQXhDLEVBQWlEOU0sTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJpRyxrQkFBeEUsQ0FBNUI7QUFFQTlLLG1CQUFTLENBQUNnSixZQUFWLEdBQXlCeUYsZUFBZSxDQUFDek8sU0FBRCxFQUFZME8sYUFBWixDQUF4QztBQUNBYiwwQkFBZ0IsSUFBSTdOLFNBQVMsQ0FBQ2dKLFlBQTlCO0FBRUEvSyxvQkFBVSxDQUFDb0wsTUFBWCxDQUFrQjtBQUFDakQsNEJBQWdCLEVBQUNwRyxTQUFTLENBQUNvRztBQUE1QixXQUFsQixFQUFnRXBHLFNBQWhFO0FBQ0FtQyw0QkFBa0IsQ0FBQ2dHLE1BQW5CLENBQTBCO0FBQ3RCdkosbUJBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCLE9BREc7QUFFdEJnTiw2QkFBaUIsRUFBRSxDQUZHO0FBR3RCNUMsd0JBQVksRUFBRWhKLFNBQVMsQ0FBQ2dKLFlBSEY7QUFJdEIzSixnQkFBSSxFQUFFLEtBSmdCO0FBS3RCMkUsa0JBQU0sRUFBRSxDQUxjO0FBTXRCNkgsc0JBQVUsRUFBRXdGLE9BQU8sQ0FBQ007QUFORSxXQUExQjtBQVFIO0FBQ0o7O0FBRURGLGlCQUFXLENBQUNQLFdBQVosR0FBMEIsSUFBMUI7QUFDQU8saUJBQVcsQ0FBQ3pCLGlCQUFaLEdBQWdDbkMsZ0JBQWhDO0FBQ0EsVUFBSTFPLE1BQU0sR0FBRzJDLEtBQUssQ0FBQ3VILE1BQU4sQ0FBYTtBQUFDSyxlQUFPLEVBQUMrSCxXQUFXLENBQUMvSDtBQUFyQixPQUFiLEVBQTRDO0FBQUNILFlBQUksRUFBQ2tJO0FBQU4sT0FBNUMsQ0FBYjtBQUdBaFQsYUFBTyxDQUFDQyxHQUFSLENBQVksMENBQVo7QUFFSDs7QUFFRCxXQUFPLElBQVA7QUFDSDtBQXhSVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDZkEsSUFBSWQsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJK0QsS0FBSixFQUFVME0sV0FBVjtBQUFzQjNRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ2dFLE9BQUssQ0FBQy9ELENBQUQsRUFBRztBQUFDK0QsU0FBSyxHQUFDL0QsQ0FBTjtBQUFRLEdBQWxCOztBQUFtQnlRLGFBQVcsQ0FBQ3pRLENBQUQsRUFBRztBQUFDeVEsZUFBVyxHQUFDelEsQ0FBWjtBQUFjOztBQUFoRCxDQUExQixFQUE0RSxDQUE1RTtBQUErRSxJQUFJdVYsU0FBSjtBQUFjelYsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ3dWLFdBQVMsQ0FBQ3ZWLENBQUQsRUFBRztBQUFDdVYsYUFBUyxHQUFDdlYsQ0FBVjtBQUFZOztBQUExQixDQUE3QyxFQUF5RSxDQUF6RTtBQUE0RSxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUs5UUgsTUFBTSxDQUFDMlYsT0FBUCxDQUFlLG9CQUFmLEVBQXFDLFlBQVk7QUFDN0MsU0FBTyxDQUNIL0UsV0FBVyxDQUFDOUssSUFBWixDQUFpQixFQUFqQixFQUFvQjtBQUFDaUMsUUFBSSxFQUFDO0FBQUMzQixZQUFNLEVBQUMsQ0FBQztBQUFULEtBQU47QUFBa0I0QixTQUFLLEVBQUM7QUFBeEIsR0FBcEIsQ0FERyxFQUVIME4sU0FBUyxDQUFDNVAsSUFBVixDQUFlLEVBQWYsRUFBa0I7QUFBQ2lDLFFBQUksRUFBQztBQUFDNk4scUJBQWUsRUFBQyxDQUFDO0FBQWxCLEtBQU47QUFBMkI1TixTQUFLLEVBQUM7QUFBakMsR0FBbEIsQ0FGRyxDQUFQO0FBSUgsQ0FMRDtBQU9BcUksZ0JBQWdCLENBQUMsY0FBRCxFQUFpQixZQUFVO0FBQ3ZDLFNBQU87QUFDSHZLLFFBQUksR0FBRTtBQUNGLGFBQU81QixLQUFLLENBQUM0QixJQUFOLENBQVc7QUFBQ2dHLGVBQU8sRUFBQzlMLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNkU7QUFBaEMsT0FBWCxDQUFQO0FBQ0gsS0FIRTs7QUFJSHdFLFlBQVEsRUFBRSxDQUNOO0FBQ0l4SyxVQUFJLENBQUM4TCxLQUFELEVBQU87QUFDUCxlQUFPdlIsVUFBVSxDQUFDeUYsSUFBWCxDQUNILEVBREcsRUFFSDtBQUFDMkksZ0JBQU0sRUFBQztBQUNKek4sbUJBQU8sRUFBQyxDQURKO0FBRUpxTSx1QkFBVyxFQUFDLENBRlI7QUFHSjlLLDRCQUFnQixFQUFDLENBSGI7QUFJSm9GLGtCQUFNLEVBQUMsQ0FBQyxDQUpKO0FBS0o0RixrQkFBTSxFQUFDLENBTEg7QUFNSkQsdUJBQVcsRUFBQztBQU5SO0FBQVIsU0FGRyxDQUFQO0FBV0g7O0FBYkwsS0FETTtBQUpQLEdBQVA7QUFzQkgsQ0F2QmUsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUNaQXJOLE1BQU0sQ0FBQ3NRLE1BQVAsQ0FBYztBQUFDck0sT0FBSyxFQUFDLE1BQUlBLEtBQVg7QUFBaUIwTSxhQUFXLEVBQUMsTUFBSUE7QUFBakMsQ0FBZDtBQUE2RCxJQUFJSixLQUFKO0FBQVV2USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNzUSxPQUFLLENBQUNyUSxDQUFELEVBQUc7QUFBQ3FRLFNBQUssR0FBQ3JRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBMUMsRUFBd0UsQ0FBeEU7QUFHakksTUFBTStELEtBQUssR0FBRyxJQUFJc00sS0FBSyxDQUFDQyxVQUFWLENBQXFCLE9BQXJCLENBQWQ7QUFDQSxNQUFNRyxXQUFXLEdBQUcsSUFBSUosS0FBSyxDQUFDQyxVQUFWLENBQXFCLGNBQXJCLENBQXBCO0FBRVB2TSxLQUFLLENBQUN3TSxPQUFOLENBQWM7QUFDVkMsVUFBUSxHQUFFO0FBQ04sV0FBT3RRLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQ3JCLGFBQU8sRUFBQyxLQUFLK0U7QUFBZCxLQUFuQixDQUFQO0FBQ0g7O0FBSFMsQ0FBZCxFOzs7Ozs7Ozs7OztBQ05BLElBQUkvRixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl1VixTQUFKO0FBQWN6VixNQUFNLENBQUNDLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDd1YsV0FBUyxDQUFDdlYsQ0FBRCxFQUFHO0FBQUN1VixhQUFTLEdBQUN2VixDQUFWO0FBQVk7O0FBQTFCLENBQS9CLEVBQTJELENBQTNEO0FBQThELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFJckpILE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsNEJBQTBCLFlBQVU7QUFDaEMsU0FBS0UsT0FBTDtBQUNBLFFBQUk0VSxNQUFNLEdBQUc3VixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjZPLFdBQXBDOztBQUNBLFFBQUlELE1BQUosRUFBVztBQUNQLFVBQUc7QUFDQyxZQUFJRSxHQUFHLEdBQUcsSUFBSTNTLElBQUosRUFBVjtBQUNBMlMsV0FBRyxDQUFDQyxVQUFKLENBQWUsQ0FBZjtBQUNBLFlBQUl6VixHQUFHLEdBQUcsdURBQXFEc1YsTUFBckQsR0FBNEQsd0hBQXRFO0FBQ0EsWUFBSTFVLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjs7QUFDQSxZQUFJWSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0I7QUFDQSxjQUFJZ0MsSUFBSSxHQUFHdkIsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBWDtBQUNBcUIsY0FBSSxHQUFHQSxJQUFJLENBQUNrVCxNQUFELENBQVgsQ0FIMkIsQ0FJM0I7O0FBQ0EsaUJBQU9ILFNBQVMsQ0FBQ2pLLE1BQVYsQ0FBaUI7QUFBQ21LLDJCQUFlLEVBQUNqVCxJQUFJLENBQUNpVDtBQUF0QixXQUFqQixFQUF5RDtBQUFDakssZ0JBQUksRUFBQ2hKO0FBQU4sV0FBekQsQ0FBUDtBQUNIO0FBQ0osT0FaRCxDQWFBLE9BQU0vQixDQUFOLEVBQVE7QUFDSkMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLEtBakJELE1Ba0JJO0FBQ0EsYUFBTywyQkFBUDtBQUNIO0FBQ0osR0F6QlU7QUEwQlgsd0JBQXNCLFlBQVU7QUFDNUIsU0FBS0ssT0FBTDtBQUNBLFFBQUk0VSxNQUFNLEdBQUc3VixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjZPLFdBQXBDOztBQUNBLFFBQUlELE1BQUosRUFBVztBQUNQLGFBQVFILFNBQVMsQ0FBQ3JULE9BQVYsQ0FBa0IsRUFBbEIsRUFBcUI7QUFBQzBGLFlBQUksRUFBQztBQUFDNk4seUJBQWUsRUFBQyxDQUFDO0FBQWxCO0FBQU4sT0FBckIsQ0FBUjtBQUNILEtBRkQsTUFHSTtBQUNBLGFBQU8sMkJBQVA7QUFDSDtBQUVKO0FBcENVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNKQTNWLE1BQU0sQ0FBQ3NRLE1BQVAsQ0FBYztBQUFDbUYsV0FBUyxFQUFDLE1BQUlBO0FBQWYsQ0FBZDtBQUF5QyxJQUFJbEYsS0FBSjtBQUFVdlEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDc1EsT0FBSyxDQUFDclEsQ0FBRCxFQUFHO0FBQUNxUSxTQUFLLEdBQUNyUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRTVDLE1BQU11VixTQUFTLEdBQUcsSUFBSWxGLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixZQUFyQixDQUFsQixDOzs7Ozs7Ozs7OztBQ0ZQLElBQUl6USxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUk4VixXQUFKO0FBQWdCaFcsTUFBTSxDQUFDQyxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQytWLGFBQVcsQ0FBQzlWLENBQUQsRUFBRztBQUFDOFYsZUFBVyxHQUFDOVYsQ0FBWjtBQUFjOztBQUE5QixDQUFoQyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUlsS0gsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCxnQ0FBOEIsWUFBVTtBQUNwQyxTQUFLRSxPQUFMO0FBQ0EsUUFBSThELFVBQVUsR0FBRzFFLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0JFLEtBQXBCLEVBQWpCO0FBQ0EsUUFBSWhFLFdBQVcsR0FBRyxFQUFsQjtBQUNBbkIsV0FBTyxDQUFDQyxHQUFSLENBQVksNkJBQVo7O0FBQ0EsU0FBS1gsQ0FBTCxJQUFVNEUsVUFBVixFQUFxQjtBQUNqQixVQUFJQSxVQUFVLENBQUM1RSxDQUFELENBQVYsQ0FBY29DLGdCQUFsQixFQUFtQztBQUMvQixZQUFJaEMsR0FBRyxHQUFHRyxHQUFHLEdBQUcsc0JBQU4sR0FBNkJxRSxVQUFVLENBQUM1RSxDQUFELENBQVYsQ0FBY29DLGdCQUEzQyxHQUE0RCxjQUF0RTs7QUFDQSxZQUFHO0FBQ0MsY0FBSXBCLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjs7QUFDQSxjQUFJWSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0IsZ0JBQUk4QyxVQUFVLEdBQUdyQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBOUMsQ0FEMkIsQ0FFM0I7O0FBQ0FTLHVCQUFXLEdBQUdBLFdBQVcsQ0FBQ2tVLE1BQVosQ0FBbUJ6UyxVQUFuQixDQUFkO0FBQ0gsV0FKRCxNQUtJO0FBQ0E1QyxtQkFBTyxDQUFDQyxHQUFSLENBQVlLLFFBQVEsQ0FBQ1IsVUFBckI7QUFDSDtBQUNKLFNBVkQsQ0FXQSxPQUFPQyxDQUFQLEVBQVM7QUFDTEMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSjtBQUNKOztBQUVELFNBQUs4QyxDQUFMLElBQVUxQixXQUFWLEVBQXNCO0FBQ2xCLFVBQUlBLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxJQUFrQjFCLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxDQUFlZCxNQUFyQyxFQUNJWixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBZixHQUF3QkMsVUFBVSxDQUFDYixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBaEIsQ0FBbEM7QUFDUCxLQTVCbUMsQ0E4QnBDOzs7QUFDQSxRQUFJRCxJQUFJLEdBQUc7QUFDUFgsaUJBQVcsRUFBRUEsV0FETjtBQUVQbVUsZUFBUyxFQUFFLElBQUkvUyxJQUFKO0FBRkosS0FBWDtBQUtBLFdBQU82UyxXQUFXLENBQUMxTCxNQUFaLENBQW1CNUgsSUFBbkIsQ0FBUDtBQUNILEdBdENVLENBdUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQXBEVyxDQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0pBMUMsTUFBTSxDQUFDc1EsTUFBUCxDQUFjO0FBQUMwRixhQUFXLEVBQUMsTUFBSUE7QUFBakIsQ0FBZDtBQUE2QyxJQUFJekYsS0FBSjtBQUFVdlEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDc1EsT0FBSyxDQUFDclEsQ0FBRCxFQUFHO0FBQUNxUSxTQUFLLEdBQUNyUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRWhELE1BQU04VixXQUFXLEdBQUcsSUFBSXpGLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixhQUFyQixDQUFwQixDOzs7Ozs7Ozs7OztBQ0ZQLElBQUl6USxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSWlXLFVBQUo7QUFBZW5XLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUNrVyxZQUFVLENBQUNqVyxDQUFELEVBQUc7QUFBQ2lXLGNBQVUsR0FBQ2pXLENBQVg7QUFBYTs7QUFBNUIsQ0FBL0IsRUFBNkQsQ0FBN0Q7QUFJdklILE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsa0NBQWdDLFlBQVU7QUFDdEMsU0FBS0UsT0FBTDs7QUFDQSxRQUFHO0FBQ0MsVUFBSVYsR0FBRyxHQUFHRyxHQUFHLEdBQUcsaUJBQWhCO0FBQ0EsVUFBSVMsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsVUFBSThWLGNBQWMsR0FBR2pWLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUFsRDtBQUVBLFVBQUkrVSxzQkFBc0IsR0FBRyxJQUFJQyxHQUFKLENBQVFILFVBQVUsQ0FBQ3RRLElBQVgsQ0FDakM7QUFBQyxrQkFBUztBQUFDUSxhQUFHLEVBQUMsQ0FBQyxRQUFELEVBQVcsVUFBWDtBQUFMO0FBQVYsT0FEaUMsRUFFbkNOLEtBRm1DLEdBRTNCRSxHQUYyQixDQUV0QmxCLENBQUQsSUFBTUEsQ0FBQyxDQUFDd1IsSUFGZSxDQUFSLENBQTdCO0FBSUEsVUFBSUMsS0FBSyxHQUFHLEVBQVo7O0FBRUEsVUFBSUosY0FBYyxDQUFDdFUsTUFBZixHQUF3QixDQUE1QixFQUErQjtBQUMzQixjQUFNMlUsT0FBTyxHQUFHTixVQUFVLENBQUN6UCxhQUFYLEdBQTJCb0MseUJBQTNCLEVBQWhCOztBQUNBLGFBQUssSUFBSXJGLENBQVQsSUFBYzJTLGNBQWQsRUFBOEI7QUFDMUIsY0FBSU0sRUFBRSxHQUFHTixjQUFjLENBQUMzUyxDQUFELENBQXZCO0FBQ0FpVCxZQUFFLENBQUNILElBQUgsR0FBVTVMLFFBQVEsQ0FBQytMLEVBQUUsQ0FBQ0MsRUFBSixDQUFsQjs7QUFDQSxjQUFJRCxFQUFFLENBQUNILElBQUgsR0FBVSxDQUFWLElBQWUsQ0FBQ0Ysc0JBQXNCLENBQUNPLEdBQXZCLENBQTJCRixFQUFFLENBQUNILElBQTlCLENBQXBCLEVBQXlEO0FBQ3JELGdCQUFJO0FBQ0FFLHFCQUFPLENBQUM1USxJQUFSLENBQWE7QUFBQzBRLG9CQUFJLEVBQUVHLEVBQUUsQ0FBQ0g7QUFBVixlQUFiLEVBQThCL0ssTUFBOUIsR0FBdUNDLFNBQXZDLENBQWlEO0FBQUNDLG9CQUFJLEVBQUVnTDtBQUFQLGVBQWpEO0FBQ0FGLG1CQUFLLENBQUN6TSxJQUFOLENBQVcyTSxFQUFFLENBQUNILElBQWQ7QUFDSCxhQUhELENBR0UsT0FBTTVWLENBQU4sRUFBUztBQUNQOFYscUJBQU8sQ0FBQzVRLElBQVIsQ0FBYTtBQUFDMFEsb0JBQUksRUFBRUcsRUFBRSxDQUFDSDtBQUFWLGVBQWIsRUFBOEIvSyxNQUE5QixHQUF1Q0MsU0FBdkMsQ0FBaUQ7QUFBQ0Msb0JBQUksRUFBRWdMO0FBQVAsZUFBakQ7QUFDQUYsbUJBQUssQ0FBQ3pNLElBQU4sQ0FBVzJNLEVBQUUsQ0FBQ0gsSUFBZDtBQUNBM1YscUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFDLENBQUNPLFFBQUYsQ0FBV0csT0FBdkI7QUFDSDtBQUNKO0FBQ0o7O0FBQ0QsWUFBR21WLEtBQUssQ0FBQzFVLE1BQU4sR0FBZSxDQUFsQixFQUFxQjtBQUNqQjJVLGlCQUFPLENBQUN6SCxPQUFSO0FBQ0g7QUFDSjs7QUFDRCxhQUFPLElBQVA7QUFDSCxLQWhDRCxDQWlDQSxPQUFPck8sQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSjtBQXZDVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDSkEsSUFBSVosTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJaVcsVUFBSjtBQUFlblcsTUFBTSxDQUFDQyxJQUFQLENBQVksa0JBQVosRUFBK0I7QUFBQ2tXLFlBQVUsQ0FBQ2pXLENBQUQsRUFBRztBQUFDaVcsY0FBVSxHQUFDalcsQ0FBWDtBQUFhOztBQUE1QixDQUEvQixFQUE2RCxDQUE3RDtBQUFnRSxJQUFJMlcsS0FBSjtBQUFVN1csTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDNFcsT0FBSyxDQUFDM1csQ0FBRCxFQUFHO0FBQUMyVyxTQUFLLEdBQUMzVyxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBSXpKSCxNQUFNLENBQUMyVixPQUFQLENBQWUscUJBQWYsRUFBc0MsWUFBWTtBQUM5QyxTQUFPUyxVQUFVLENBQUN0USxJQUFYLENBQWdCLEVBQWhCLEVBQW9CO0FBQUNpQyxRQUFJLEVBQUM7QUFBQ3lPLFVBQUksRUFBQyxDQUFDO0FBQVA7QUFBTixHQUFwQixDQUFQO0FBQ0gsQ0FGRDtBQUlBeFcsTUFBTSxDQUFDMlYsT0FBUCxDQUFlLG1CQUFmLEVBQW9DLFVBQVVpQixFQUFWLEVBQWE7QUFDN0NFLE9BQUssQ0FBQ0YsRUFBRCxFQUFLRyxNQUFMLENBQUw7QUFDQSxTQUFPWCxVQUFVLENBQUN0USxJQUFYLENBQWdCO0FBQUMwUSxRQUFJLEVBQUNJO0FBQU4sR0FBaEIsQ0FBUDtBQUNILENBSEQsRTs7Ozs7Ozs7Ozs7QUNSQTNXLE1BQU0sQ0FBQ3NRLE1BQVAsQ0FBYztBQUFDNkYsWUFBVSxFQUFDLE1BQUlBO0FBQWhCLENBQWQ7QUFBMkMsSUFBSTVGLEtBQUo7QUFBVXZRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3NRLE9BQUssQ0FBQ3JRLENBQUQsRUFBRztBQUFDcVEsU0FBSyxHQUFDclEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUU5QyxNQUFNaVcsVUFBVSxHQUFHLElBQUk1RixLQUFLLENBQUNDLFVBQVYsQ0FBcUIsWUFBckIsQ0FBbkIsQzs7Ozs7Ozs7Ozs7QUNGUCxJQUFJdUcsYUFBSjs7QUFBa0IvVyxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQ0FBWixFQUFtRDtBQUFDK1csU0FBTyxDQUFDOVcsQ0FBRCxFQUFHO0FBQUM2VyxpQkFBYSxHQUFDN1csQ0FBZDtBQUFnQjs7QUFBNUIsQ0FBbkQsRUFBaUYsQ0FBakY7QUFBbEIsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUVUSCxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLHdCQUFzQixVQUFTbVcsTUFBVCxFQUFpQjtBQUNuQyxVQUFNM1csR0FBRyxhQUFNRyxHQUFOLFNBQVQ7QUFDQWlDLFFBQUksR0FBRztBQUNILFlBQU11VSxNQUFNLENBQUN4VixLQURWO0FBRUgsY0FBUTtBQUZMLEtBQVA7QUFJQSxVQUFNeVYsU0FBUyxHQUFHLElBQUkvVCxJQUFKLEdBQVdtSixPQUFYLEVBQWxCO0FBQ0ExTCxXQUFPLENBQUNDLEdBQVIsaUNBQXFDcVcsU0FBckMsY0FBa0Q1VyxHQUFsRCx3QkFBbUVhLElBQUksQ0FBQ21FLFNBQUwsQ0FBZTVDLElBQWYsQ0FBbkU7QUFFQSxRQUFJeEIsUUFBUSxHQUFHZixJQUFJLENBQUNnWCxJQUFMLENBQVU3VyxHQUFWLEVBQWU7QUFBQ29DO0FBQUQsS0FBZixDQUFmO0FBQ0E5QixXQUFPLENBQUNDLEdBQVIsbUNBQXVDcVcsU0FBdkMsY0FBb0Q1VyxHQUFwRCxlQUE0RGEsSUFBSSxDQUFDbUUsU0FBTCxDQUFlcEUsUUFBZixDQUE1RDs7QUFDQSxRQUFJQSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBZ0M7QUFDNUIsVUFBSWdDLElBQUksR0FBR3hCLFFBQVEsQ0FBQ3dCLElBQXBCO0FBQ0EsVUFBSUEsSUFBSSxDQUFDMFUsSUFBVCxFQUNJLE1BQU0sSUFBSXJYLE1BQU0sQ0FBQ3NYLEtBQVgsQ0FBaUIzVSxJQUFJLENBQUMwVSxJQUF0QixFQUE0QmpXLElBQUksQ0FBQ0MsS0FBTCxDQUFXc0IsSUFBSSxDQUFDNFUsT0FBaEIsRUFBeUJDLE9BQXJELENBQU47QUFDSixhQUFPclcsUUFBUSxDQUFDd0IsSUFBVCxDQUFjOFUsTUFBckI7QUFDSDtBQUNKLEdBbEJVO0FBbUJYLHlCQUF1QixVQUFTQyxJQUFULEVBQWVDLElBQWYsRUFBcUI7QUFDeEMsVUFBTXBYLEdBQUcsYUFBTUcsR0FBTixjQUFhaVgsSUFBYixDQUFUO0FBQ0FoVixRQUFJLEdBQUc7QUFDSCxvQ0FDTytVLElBRFA7QUFFSSxvQkFBWTFYLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNkUsT0FGdkM7QUFHSSxvQkFBWTtBQUhoQjtBQURHLEtBQVA7QUFPQSxRQUFJM0ssUUFBUSxHQUFHZixJQUFJLENBQUNnWCxJQUFMLENBQVU3VyxHQUFWLEVBQWU7QUFBQ29DO0FBQUQsS0FBZixDQUFmOztBQUNBLFFBQUl4QixRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBZ0M7QUFDNUIsYUFBT1MsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBUDtBQUNIO0FBQ0osR0FoQ1U7QUFpQ1gsMEJBQXdCLFVBQVNzVyxLQUFULEVBQWdCeE4sSUFBaEIsRUFBc0J1TixJQUF0QixFQUE4QztBQUFBLFFBQWxCRSxVQUFrQix1RUFBUCxLQUFPO0FBQ2xFLFVBQU10WCxHQUFHLGFBQU1HLEdBQU4sY0FBYWlYLElBQWIsQ0FBVDtBQUNBaFYsUUFBSSxxQkFBT2lWLEtBQVA7QUFDQSxrQkFBWTtBQUNSLGdCQUFReE4sSUFEQTtBQUVSLG9CQUFZcEssTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI2RSxPQUYzQjtBQUdSLDBCQUFrQitMLFVBSFY7QUFJUixvQkFBWTtBQUpKO0FBRFosTUFBSjtBQVFBLFFBQUkxVyxRQUFRLEdBQUdmLElBQUksQ0FBQ2dYLElBQUwsQ0FBVTdXLEdBQVYsRUFBZTtBQUFDb0M7QUFBRCxLQUFmLENBQWY7O0FBQ0EsUUFBSXhCLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUFnQztBQUM1QixhQUFPUyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QndXLFlBQXBDO0FBQ0g7QUFDSjtBQS9DVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDRkEsSUFBSTlYLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXFRLEtBQUo7QUFBVXZRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3NRLE9BQUssQ0FBQ3JRLENBQUQsRUFBRztBQUFDcVEsU0FBSyxHQUFDclEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJaUUsZ0JBQUosRUFBcUJDLFNBQXJCLEVBQStCMFQsV0FBL0IsRUFBMkNDLG9CQUEzQztBQUFnRS9YLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ2tFLGtCQUFnQixDQUFDakUsQ0FBRCxFQUFHO0FBQUNpRSxvQkFBZ0IsR0FBQ2pFLENBQWpCO0FBQW1CLEdBQXhDOztBQUF5Q2tFLFdBQVMsQ0FBQ2xFLENBQUQsRUFBRztBQUFDa0UsYUFBUyxHQUFDbEUsQ0FBVjtBQUFZLEdBQWxFOztBQUFtRTRYLGFBQVcsQ0FBQzVYLENBQUQsRUFBRztBQUFDNFgsZUFBVyxHQUFDNVgsQ0FBWjtBQUFjLEdBQWhHOztBQUFpRzZYLHNCQUFvQixDQUFDN1gsQ0FBRCxFQUFHO0FBQUM2WCx3QkFBb0IsR0FBQzdYLENBQXJCO0FBQXVCOztBQUFoSixDQUE1QixFQUE4SyxDQUE5SztBQUFpTCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJZ0UsYUFBSjtBQUFrQmxFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtDQUFaLEVBQTREO0FBQUNpRSxlQUFhLENBQUNoRSxDQUFELEVBQUc7QUFBQ2dFLGlCQUFhLEdBQUNoRSxDQUFkO0FBQWdCOztBQUFsQyxDQUE1RCxFQUFnRyxDQUFoRztBQUFtRyxJQUFJOFgsTUFBSjtBQUFXaFksTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQytYLFFBQU0sQ0FBQzlYLENBQUQsRUFBRztBQUFDOFgsVUFBTSxHQUFDOVgsQ0FBUDtBQUFTOztBQUFwQixDQUFyQyxFQUEyRCxDQUEzRDtBQUE4RCxJQUFJK1gsaUJBQUo7QUFBc0JqWSxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNnWSxtQkFBaUIsQ0FBQy9YLENBQUQsRUFBRztBQUFDK1gscUJBQWlCLEdBQUMvWCxDQUFsQjtBQUFvQjs7QUFBMUMsQ0FBNUIsRUFBd0UsQ0FBeEU7QUFBMkUsSUFBSWdZLFlBQUo7QUFBaUJsWSxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNpWSxjQUFZLENBQUNoWSxDQUFELEVBQUc7QUFBQ2dZLGdCQUFZLEdBQUNoWSxDQUFiO0FBQWU7O0FBQWhDLENBQTVCLEVBQThELENBQTlEO0FBQWlFLElBQUk4RCxTQUFKO0FBQWNoRSxNQUFNLENBQUNDLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDK0QsV0FBUyxDQUFDOUQsQ0FBRCxFQUFHO0FBQUM4RCxhQUFTLEdBQUM5RCxDQUFWO0FBQVk7O0FBQTFCLENBQXJDLEVBQWlFLENBQWpFO0FBQW9FLElBQUkrRCxLQUFKO0FBQVVqRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDZ0UsT0FBSyxDQUFDL0QsQ0FBRCxFQUFHO0FBQUMrRCxTQUFLLEdBQUMvRCxDQUFOO0FBQVE7O0FBQWxCLENBQW5DLEVBQXVELENBQXZEOztBQUEwRCxJQUFJaVksQ0FBSjs7QUFBTW5ZLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQytXLFNBQU8sQ0FBQzlXLENBQUQsRUFBRztBQUFDaVksS0FBQyxHQUFDalksQ0FBRjtBQUFJOztBQUFoQixDQUFyQixFQUF1QyxFQUF2QztBQVd2OUIsTUFBTWtZLGlCQUFpQixHQUFHLElBQTFCOztBQUVBLE1BQU1DLGFBQWEsR0FBRyxDQUFDclEsV0FBRCxFQUFjc1EsWUFBZCxLQUErQjtBQUNqRCxNQUFJQyxVQUFVLEdBQUcsRUFBakI7QUFDQSxRQUFNQyxJQUFJLEdBQUc7QUFBQ0MsUUFBSSxFQUFFLENBQ2hCO0FBQUV0UyxZQUFNLEVBQUU7QUFBRXVTLFdBQUcsRUFBRTFRO0FBQVA7QUFBVixLQURnQixFQUVoQjtBQUFFN0IsWUFBTSxFQUFFO0FBQUV3UyxZQUFJLEVBQUVMO0FBQVI7QUFBVixLQUZnQjtBQUFQLEdBQWI7QUFHQSxRQUFNTSxPQUFPLEdBQUc7QUFBQzlRLFFBQUksRUFBQztBQUFDM0IsWUFBTSxFQUFFO0FBQVQ7QUFBTixHQUFoQjtBQUNBbkMsV0FBUyxDQUFDNkIsSUFBVixDQUFlMlMsSUFBZixFQUFxQkksT0FBckIsRUFBOEI3VixPQUE5QixDQUF1Q21ELEtBQUQsSUFBVztBQUM3Q3FTLGNBQVUsQ0FBQ3JTLEtBQUssQ0FBQ0MsTUFBUCxDQUFWLEdBQTJCO0FBQ3ZCQSxZQUFNLEVBQUVELEtBQUssQ0FBQ0MsTUFEUztBQUV2QkwscUJBQWUsRUFBRUksS0FBSyxDQUFDSixlQUZBO0FBR3ZCeUUscUJBQWUsRUFBRXJFLEtBQUssQ0FBQ3FFLGVBSEE7QUFJdkJLLHFCQUFlLEVBQUUxRSxLQUFLLENBQUMwRSxlQUpBO0FBS3ZCOUYsZ0JBQVUsRUFBRW9CLEtBQUssQ0FBQ3BCLFVBTEs7QUFNdkI1QixVQUFJLEVBQUVnRCxLQUFLLENBQUNoRDtBQU5XLEtBQTNCO0FBUUgsR0FURDtBQVdBa0IsV0FBUyxDQUFDeUIsSUFBVixDQUFlMlMsSUFBZixFQUFxQkksT0FBckIsRUFBOEI3VixPQUE5QixDQUF1Q21ELEtBQUQsSUFBVztBQUM3QyxRQUFJLENBQUNxUyxVQUFVLENBQUNyUyxLQUFLLENBQUNDLE1BQVAsQ0FBZixFQUErQjtBQUMzQm9TLGdCQUFVLENBQUNyUyxLQUFLLENBQUNDLE1BQVAsQ0FBVixHQUEyQjtBQUFFQSxjQUFNLEVBQUVELEtBQUssQ0FBQ0M7QUFBaEIsT0FBM0I7QUFDQXZGLGFBQU8sQ0FBQ0MsR0FBUixpQkFBcUJxRixLQUFLLENBQUNDLE1BQTNCO0FBQ0g7O0FBQ0RnUyxLQUFDLENBQUNVLE1BQUYsQ0FBU04sVUFBVSxDQUFDclMsS0FBSyxDQUFDQyxNQUFQLENBQW5CLEVBQW1DO0FBQy9CeUQsZ0JBQVUsRUFBRTFELEtBQUssQ0FBQzBELFVBRGE7QUFFL0I2QyxzQkFBZ0IsRUFBRXZHLEtBQUssQ0FBQ3VHLGdCQUZPO0FBRy9CakcsY0FBUSxFQUFFTixLQUFLLENBQUNNLFFBSGU7QUFJL0IyRSxrQkFBWSxFQUFFakYsS0FBSyxDQUFDaUY7QUFKVyxLQUFuQztBQU1ILEdBWEQ7QUFZQSxTQUFPb04sVUFBUDtBQUNILENBOUJEOztBQWdDQSxNQUFNTyxpQkFBaUIsR0FBRyxDQUFDQyxZQUFELEVBQWVqVCxlQUFmLEtBQW1DO0FBQ3pELE1BQUlrVCxjQUFjLEdBQUdkLFlBQVksQ0FBQzlWLE9BQWIsQ0FDakI7QUFBQzZXLFNBQUssRUFBQ0YsWUFBUDtBQUFxQnJJLFlBQVEsRUFBQzVLLGVBQTlCO0FBQStDb1QsZUFBVyxFQUFFLENBQUM7QUFBN0QsR0FEaUIsQ0FBckI7QUFFQSxNQUFJQyxpQkFBaUIsR0FBR3BaLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QkQsV0FBL0M7QUFDQSxNQUFJb1IsU0FBUyxHQUFHLEVBQWhCOztBQUNBLE1BQUlKLGNBQUosRUFBb0I7QUFDaEJJLGFBQVMsR0FBR2pCLENBQUMsQ0FBQ2tCLElBQUYsQ0FBT0wsY0FBUCxFQUF1QixDQUFDLFdBQUQsRUFBYyxZQUFkLENBQXZCLENBQVo7QUFDSCxHQUZELE1BRU87QUFDSEksYUFBUyxHQUFHO0FBQ1JFLGVBQVMsRUFBRSxDQURIO0FBRVJDLGdCQUFVLEVBQUU7QUFGSixLQUFaO0FBSUg7O0FBQ0QsU0FBT0gsU0FBUDtBQUNILENBZEQ7O0FBZ0JBclosTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCw0Q0FBMEMsWUFBVTtBQUNoRCxRQUFJLENBQUMwWSxpQkFBTCxFQUF1QjtBQUNuQixVQUFJO0FBQ0EsWUFBSUMsU0FBUyxHQUFHdFcsSUFBSSxDQUFDMlMsR0FBTCxFQUFoQjtBQUNBMEQseUJBQWlCLEdBQUcsSUFBcEI7QUFDQTVZLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLDhCQUFaO0FBQ0EsYUFBS0csT0FBTDtBQUNBLFlBQUk4RCxVQUFVLEdBQUcxRSxVQUFVLENBQUN5RixJQUFYLENBQWdCLEVBQWhCLEVBQW9CRSxLQUFwQixFQUFqQjtBQUNBLFlBQUl1UyxZQUFZLEdBQUd2WSxNQUFNLENBQUNxSSxJQUFQLENBQVkseUJBQVosQ0FBbkI7QUFDQSxZQUFJc1IsY0FBYyxHQUFHMUIsTUFBTSxDQUFDNVYsT0FBUCxDQUFlO0FBQUN5SixpQkFBTyxFQUFFOUwsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI2RTtBQUFqQyxTQUFmLENBQXJCO0FBQ0EsWUFBSTdELFdBQVcsR0FBSTBSLGNBQWMsSUFBRUEsY0FBYyxDQUFDQyw4QkFBaEMsR0FBZ0VELGNBQWMsQ0FBQ0MsOEJBQS9FLEdBQThHNVosTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCRCxXQUF2SjtBQUNBc1Esb0JBQVksR0FBR2xNLElBQUksQ0FBQ3dOLEdBQUwsQ0FBUzVSLFdBQVcsR0FBR29RLGlCQUF2QixFQUEwQ0UsWUFBMUMsQ0FBZjtBQUNBLGNBQU11QixlQUFlLEdBQUczQixZQUFZLENBQUN4UixhQUFiLEdBQTZCb1QsdUJBQTdCLEVBQXhCO0FBRUEsWUFBSUMsYUFBYSxHQUFHLEVBQXBCO0FBQ0FqVixrQkFBVSxDQUFDL0IsT0FBWCxDQUFvQlosU0FBRCxJQUFlNFgsYUFBYSxDQUFDNVgsU0FBUyxDQUFDcEIsT0FBWCxDQUFiLEdBQW1Db0IsU0FBckUsRUFiQSxDQWVBOztBQUNBLFlBQUlvVyxVQUFVLEdBQUdGLGFBQWEsQ0FBQ3JRLFdBQUQsRUFBY3NRLFlBQWQsQ0FBOUIsQ0FoQkEsQ0FrQkE7O0FBQ0EsWUFBSTBCLGtCQUFrQixHQUFHLEVBQXpCOztBQUVBN0IsU0FBQyxDQUFDcFYsT0FBRixDQUFVd1YsVUFBVixFQUFzQixDQUFDclMsS0FBRCxFQUFRZ1QsV0FBUixLQUF3QjtBQUMxQyxjQUFJcFQsZUFBZSxHQUFHSSxLQUFLLENBQUNKLGVBQTVCO0FBQ0EsY0FBSW1VLGVBQWUsR0FBRyxJQUFJM0QsR0FBSixDQUFRcFEsS0FBSyxDQUFDcEIsVUFBZCxDQUF0QjtBQUNBLGNBQUlvVixhQUFhLEdBQUdoVyxhQUFhLENBQUM5QixPQUFkLENBQXNCO0FBQUNzSSx3QkFBWSxFQUFDeEUsS0FBSyxDQUFDQztBQUFwQixXQUF0QixDQUFwQjtBQUNBLGNBQUlnVSxnQkFBZ0IsR0FBRyxDQUF2QjtBQUVBRCx1QkFBYSxDQUFDcFYsVUFBZCxDQUF5Qi9CLE9BQXpCLENBQWtDcVgsZUFBRCxJQUFxQjtBQUNsRCxnQkFBSUgsZUFBZSxDQUFDckQsR0FBaEIsQ0FBb0J3RCxlQUFlLENBQUNyWixPQUFwQyxDQUFKLEVBQ0lvWixnQkFBZ0IsSUFBSXZYLFVBQVUsQ0FBQ3dYLGVBQWUsQ0FBQ2pQLFlBQWpCLENBQTlCO0FBQ1AsV0FIRDtBQUtBK08sdUJBQWEsQ0FBQ3BWLFVBQWQsQ0FBeUIvQixPQUF6QixDQUFrQ3FYLGVBQUQsSUFBcUI7QUFDbEQsZ0JBQUlDLGdCQUFnQixHQUFHRCxlQUFlLENBQUNyWixPQUF2Qzs7QUFDQSxnQkFBSSxDQUFDb1gsQ0FBQyxDQUFDdkIsR0FBRixDQUFNb0Qsa0JBQU4sRUFBMEIsQ0FBQ2xVLGVBQUQsRUFBa0J1VSxnQkFBbEIsQ0FBMUIsQ0FBTCxFQUFxRTtBQUNqRSxrQkFBSWpCLFNBQVMsR0FBR04saUJBQWlCLENBQUN1QixnQkFBRCxFQUFtQnZVLGVBQW5CLENBQWpDOztBQUNBcVMsZUFBQyxDQUFDbUMsR0FBRixDQUFNTixrQkFBTixFQUEwQixDQUFDbFUsZUFBRCxFQUFrQnVVLGdCQUFsQixDQUExQixFQUErRGpCLFNBQS9EO0FBQ0g7O0FBRURqQixhQUFDLENBQUMzTCxNQUFGLENBQVN3TixrQkFBVCxFQUE2QixDQUFDbFUsZUFBRCxFQUFrQnVVLGdCQUFsQixFQUFvQyxZQUFwQyxDQUE3QixFQUFpRkUsQ0FBRCxJQUFPQSxDQUFDLEdBQUMsQ0FBekY7O0FBQ0EsZ0JBQUksQ0FBQ04sZUFBZSxDQUFDckQsR0FBaEIsQ0FBb0J5RCxnQkFBcEIsQ0FBTCxFQUE0QztBQUN4Q2xDLGVBQUMsQ0FBQzNMLE1BQUYsQ0FBU3dOLGtCQUFULEVBQTZCLENBQUNsVSxlQUFELEVBQWtCdVUsZ0JBQWxCLEVBQW9DLFdBQXBDLENBQTdCLEVBQWdGRSxDQUFELElBQU9BLENBQUMsR0FBQyxDQUF4Rjs7QUFDQVYsNkJBQWUsQ0FBQ3ZQLE1BQWhCLENBQXVCO0FBQ25CMk8scUJBQUssRUFBRW9CLGdCQURZO0FBRW5CbkIsMkJBQVcsRUFBRWhULEtBQUssQ0FBQ0MsTUFGQTtBQUduQnVLLHdCQUFRLEVBQUU1SyxlQUhTO0FBSW5CeUUsK0JBQWUsRUFBRXJFLEtBQUssQ0FBQ3FFLGVBSko7QUFLbkJLLCtCQUFlLEVBQUUxRSxLQUFLLENBQUMwRSxlQUxKO0FBTW5CMUgsb0JBQUksRUFBRWdELEtBQUssQ0FBQ2hELElBTk87QUFPbkIwRywwQkFBVSxFQUFFMUQsS0FBSyxDQUFDMEQsVUFQQztBQVFuQjZDLGdDQUFnQixFQUFFdkcsS0FBSyxDQUFDdUcsZ0JBUkw7QUFTbkJqRyx3QkFBUSxFQUFFTixLQUFLLENBQUNNLFFBVEc7QUFVbkJnVSwyQkFBVyxFQUFFdFUsS0FBSyxDQUFDaUYsWUFWQTtBQVduQmdQLGdDQVhtQjtBQVluQk0seUJBQVMsRUFBRW5DLFlBWlE7QUFhbkJnQix5QkFBUyxFQUFFbkIsQ0FBQyxDQUFDM1gsR0FBRixDQUFNd1osa0JBQU4sRUFBMEIsQ0FBQ2xVLGVBQUQsRUFBa0J1VSxnQkFBbEIsRUFBb0MsV0FBcEMsQ0FBMUIsQ0FiUTtBQWNuQmQsMEJBQVUsRUFBRXBCLENBQUMsQ0FBQzNYLEdBQUYsQ0FBTXdaLGtCQUFOLEVBQTBCLENBQUNsVSxlQUFELEVBQWtCdVUsZ0JBQWxCLEVBQW9DLFlBQXBDLENBQTFCO0FBZE8sZUFBdkI7QUFnQkg7QUFDSixXQTNCRDtBQTRCSCxTQXZDRDs7QUF5Q0FsQyxTQUFDLENBQUNwVixPQUFGLENBQVVpWCxrQkFBVixFQUE4QixDQUFDVSxNQUFELEVBQVM1VSxlQUFULEtBQTZCO0FBQ3ZEcVMsV0FBQyxDQUFDcFYsT0FBRixDQUFVMlgsTUFBVixFQUFrQixDQUFDQyxLQUFELEVBQVE1QixZQUFSLEtBQXlCO0FBQ3ZDYywyQkFBZSxDQUFDaFUsSUFBaEIsQ0FBcUI7QUFDakJvVCxtQkFBSyxFQUFFRixZQURVO0FBRWpCckksc0JBQVEsRUFBRTVLLGVBRk87QUFHakJvVCx5QkFBVyxFQUFFLENBQUM7QUFIRyxhQUFyQixFQUlHMU4sTUFKSCxHQUlZQyxTQUpaLENBSXNCO0FBQUNDLGtCQUFJLEVBQUU7QUFDekJ1TixxQkFBSyxFQUFFRixZQURrQjtBQUV6QnJJLHdCQUFRLEVBQUU1SyxlQUZlO0FBR3pCb1QsMkJBQVcsRUFBRSxDQUFDLENBSFc7QUFJekJ1Qix5QkFBUyxFQUFFbkMsWUFKYztBQUt6QmdCLHlCQUFTLEVBQUVuQixDQUFDLENBQUMzWCxHQUFGLENBQU1tYSxLQUFOLEVBQWEsV0FBYixDQUxjO0FBTXpCcEIsMEJBQVUsRUFBRXBCLENBQUMsQ0FBQzNYLEdBQUYsQ0FBTW1hLEtBQU4sRUFBYSxZQUFiO0FBTmE7QUFBUCxhQUp0QjtBQVlILFdBYkQ7QUFjSCxTQWZEOztBQWlCQSxZQUFJcEQsT0FBTyxHQUFHLEVBQWQ7O0FBQ0EsWUFBSXNDLGVBQWUsQ0FBQy9YLE1BQWhCLEdBQXlCLENBQTdCLEVBQStCO0FBQzNCLGdCQUFNOFksTUFBTSxHQUFHMUMsWUFBWSxDQUFDMkMsT0FBYixDQUFxQkMsS0FBckIsQ0FBMkJGLE1BQTFDLENBRDJCLENBRTNCO0FBQ0E7QUFDQTs7QUFDQSxjQUFJRyxXQUFXLEdBQUdsQixlQUFlLENBQUM3SyxPQUFoQixDQUF3QjtBQUFJO0FBQTVCLFlBQTZDZ00sSUFBN0MsQ0FDZGpiLE1BQU0sQ0FBQ2tiLGVBQVAsQ0FBdUIsQ0FBQzNaLE1BQUQsRUFBUzhJLEdBQVQsS0FBaUI7QUFDcEMsZ0JBQUlBLEdBQUosRUFBUTtBQUNKb1AsK0JBQWlCLEdBQUcsS0FBcEIsQ0FESSxDQUVKOztBQUNBLG9CQUFNcFAsR0FBTjtBQUNIOztBQUNELGdCQUFJOUksTUFBSixFQUFXO0FBQ1A7QUFDQWlXLHFCQUFPLEdBQUcsV0FBSWpXLE1BQU0sQ0FBQ0EsTUFBUCxDQUFjNFosU0FBbEIsNkJBQ0k1WixNQUFNLENBQUNBLE1BQVAsQ0FBYzZaLFNBRGxCLDZCQUVJN1osTUFBTSxDQUFDQSxNQUFQLENBQWM4WixTQUZsQixlQUFWO0FBR0g7QUFDSixXQVpELENBRGMsQ0FBbEI7QUFlQXJYLGlCQUFPLENBQUN1RCxLQUFSLENBQWN5VCxXQUFkO0FBQ0g7O0FBRUR2Qix5QkFBaUIsR0FBRyxLQUFwQjtBQUNBeEIsY0FBTSxDQUFDeE0sTUFBUCxDQUFjO0FBQUNLLGlCQUFPLEVBQUU5TCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjZFO0FBQWpDLFNBQWQsRUFBeUQ7QUFBQ0gsY0FBSSxFQUFDO0FBQUNpTywwQ0FBOEIsRUFBQ3JCLFlBQWhDO0FBQThDK0Msd0NBQTRCLEVBQUUsSUFBSWxZLElBQUo7QUFBNUU7QUFBTixTQUF6RDtBQUNBLGlDQUFrQkEsSUFBSSxDQUFDMlMsR0FBTCxLQUFhMkQsU0FBL0IsZ0JBQThDbEMsT0FBOUM7QUFDSCxPQTFHRCxDQTBHRSxPQUFPNVcsQ0FBUCxFQUFVO0FBQ1I2WSx5QkFBaUIsR0FBRyxLQUFwQjtBQUNBLGNBQU03WSxDQUFOO0FBQ0g7QUFDSixLQS9HRCxNQWdISTtBQUNBLGFBQU8sYUFBUDtBQUNIO0FBQ0osR0FySFU7QUFzSFgsaURBQStDLFlBQVU7QUFDckQ7QUFDQTtBQUNBLFFBQUksQ0FBQzJhLHNCQUFMLEVBQTRCO0FBQ3hCQSw0QkFBc0IsR0FBRyxJQUF6QjtBQUNBMWEsYUFBTyxDQUFDQyxHQUFSLENBQVksOEJBQVo7QUFDQSxXQUFLRyxPQUFMO0FBQ0EsVUFBSThELFVBQVUsR0FBRzFFLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0JFLEtBQXBCLEVBQWpCO0FBQ0EsVUFBSXVTLFlBQVksR0FBR3ZZLE1BQU0sQ0FBQ3FJLElBQVAsQ0FBWSx5QkFBWixDQUFuQjtBQUNBLFVBQUlzUixjQUFjLEdBQUcxQixNQUFNLENBQUM1VixPQUFQLENBQWU7QUFBQ3lKLGVBQU8sRUFBRTlMLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNkU7QUFBakMsT0FBZixDQUFyQjtBQUNBLFVBQUk3RCxXQUFXLEdBQUkwUixjQUFjLElBQUVBLGNBQWMsQ0FBQzZCLHFCQUFoQyxHQUF1RDdCLGNBQWMsQ0FBQzZCLHFCQUF0RSxHQUE0RnhiLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QkQsV0FBckksQ0FQd0IsQ0FReEI7QUFDQTs7QUFDQSxZQUFNNlIsZUFBZSxHQUFHNUIsaUJBQWlCLENBQUN2UixhQUFsQixHQUFrQ29DLHlCQUFsQyxFQUF4Qjs7QUFDQSxXQUFLckYsQ0FBTCxJQUFVcUIsVUFBVixFQUFxQjtBQUNqQjtBQUNBLFlBQUlpVSxZQUFZLEdBQUdqVSxVQUFVLENBQUNyQixDQUFELENBQVYsQ0FBYzFDLE9BQWpDO0FBQ0EsWUFBSXlhLGFBQWEsR0FBR3JYLGdCQUFnQixDQUFDMEIsSUFBakIsQ0FBc0I7QUFDdEM5RSxpQkFBTyxFQUFDZ1ksWUFEOEI7QUFFdEM3TixnQkFBTSxFQUFDLEtBRitCO0FBR3RDdU4sY0FBSSxFQUFFLENBQUU7QUFBRXRTLGtCQUFNLEVBQUU7QUFBRXVTLGlCQUFHLEVBQUUxUTtBQUFQO0FBQVYsV0FBRixFQUFvQztBQUFFN0Isa0JBQU0sRUFBRTtBQUFFd1Msa0JBQUksRUFBRUw7QUFBUjtBQUFWLFdBQXBDO0FBSGdDLFNBQXRCLEVBSWpCdlMsS0FKaUIsRUFBcEI7QUFNQSxZQUFJMFYsTUFBTSxHQUFHLEVBQWIsQ0FUaUIsQ0FXakI7O0FBQ0EsYUFBS2xWLENBQUwsSUFBVWlWLGFBQVYsRUFBd0I7QUFDcEIsY0FBSXRWLEtBQUssR0FBR2xDLFNBQVMsQ0FBQzVCLE9BQVYsQ0FBa0I7QUFBQytELGtCQUFNLEVBQUNxVixhQUFhLENBQUNqVixDQUFELENBQWIsQ0FBaUJKO0FBQXpCLFdBQWxCLENBQVo7QUFDQSxjQUFJdVYsY0FBYyxHQUFHekQsaUJBQWlCLENBQUM3VixPQUFsQixDQUEwQjtBQUFDNlcsaUJBQUssRUFBQ0YsWUFBUDtBQUFxQnJJLG9CQUFRLEVBQUN4SyxLQUFLLENBQUNKO0FBQXBDLFdBQTFCLENBQXJCOztBQUVBLGNBQUksT0FBTzJWLE1BQU0sQ0FBQ3ZWLEtBQUssQ0FBQ0osZUFBUCxDQUFiLEtBQXlDLFdBQTdDLEVBQXlEO0FBQ3JELGdCQUFJNFYsY0FBSixFQUFtQjtBQUNmRCxvQkFBTSxDQUFDdlYsS0FBSyxDQUFDSixlQUFQLENBQU4sR0FBZ0M0VixjQUFjLENBQUM1WCxLQUFmLEdBQXFCLENBQXJEO0FBQ0gsYUFGRCxNQUdJO0FBQ0EyWCxvQkFBTSxDQUFDdlYsS0FBSyxDQUFDSixlQUFQLENBQU4sR0FBZ0MsQ0FBaEM7QUFDSDtBQUNKLFdBUEQsTUFRSTtBQUNBMlYsa0JBQU0sQ0FBQ3ZWLEtBQUssQ0FBQ0osZUFBUCxDQUFOO0FBQ0g7QUFDSjs7QUFFRCxhQUFLL0UsT0FBTCxJQUFnQjBhLE1BQWhCLEVBQXVCO0FBQ25CLGNBQUkvWSxJQUFJLEdBQUc7QUFDUHVXLGlCQUFLLEVBQUVGLFlBREE7QUFFUHJJLG9CQUFRLEVBQUMzUCxPQUZGO0FBR1ArQyxpQkFBSyxFQUFFMlgsTUFBTSxDQUFDMWEsT0FBRDtBQUhOLFdBQVg7QUFNQThZLHlCQUFlLENBQUNoVSxJQUFoQixDQUFxQjtBQUFDb1QsaUJBQUssRUFBQ0YsWUFBUDtBQUFxQnJJLG9CQUFRLEVBQUMzUDtBQUE5QixXQUFyQixFQUE2RHlLLE1BQTdELEdBQXNFQyxTQUF0RSxDQUFnRjtBQUFDQyxnQkFBSSxFQUFDaEo7QUFBTixXQUFoRjtBQUNILFNBckNnQixDQXNDakI7O0FBRUg7O0FBRUQsVUFBSW1YLGVBQWUsQ0FBQy9YLE1BQWhCLEdBQXlCLENBQTdCLEVBQStCO0FBQzNCK1gsdUJBQWUsQ0FBQzdLLE9BQWhCLENBQXdCalAsTUFBTSxDQUFDa2IsZUFBUCxDQUF1QixDQUFDN1EsR0FBRCxFQUFNOUksTUFBTixLQUFpQjtBQUM1RCxjQUFJOEksR0FBSixFQUFRO0FBQ0prUixrQ0FBc0IsR0FBRyxLQUF6QjtBQUNBMWEsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZdUosR0FBWjtBQUNIOztBQUNELGNBQUk5SSxNQUFKLEVBQVc7QUFDUDBXLGtCQUFNLENBQUN4TSxNQUFQLENBQWM7QUFBQ0sscUJBQU8sRUFBRTlMLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNkU7QUFBakMsYUFBZCxFQUF5RDtBQUFDSCxrQkFBSSxFQUFDO0FBQUM2UCxxQ0FBcUIsRUFBQ2pELFlBQXZCO0FBQXFDcUQsbUNBQW1CLEVBQUUsSUFBSXhZLElBQUo7QUFBMUQ7QUFBTixhQUF6RDtBQUNBbVksa0NBQXNCLEdBQUcsS0FBekI7QUFDQTFhLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0g7QUFDSixTQVZ1QixDQUF4QjtBQVdILE9BWkQsTUFhSTtBQUNBeWEsOEJBQXNCLEdBQUcsS0FBekI7QUFDSDs7QUFFRCxhQUFPLElBQVA7QUFDSCxLQXZFRCxNQXdFSTtBQUNBLGFBQU8sYUFBUDtBQUNIO0FBQ0osR0FwTVU7QUFxTVgsZ0RBQThDLFVBQVNwWSxJQUFULEVBQWM7QUFDeEQsU0FBS2xDLE9BQUw7QUFDQSxRQUFJOFUsR0FBRyxHQUFHLElBQUkzUyxJQUFKLEVBQVY7O0FBRUEsUUFBSUQsSUFBSSxJQUFJLEdBQVosRUFBZ0I7QUFDWixVQUFJdUosZ0JBQWdCLEdBQUcsQ0FBdkI7QUFDQSxVQUFJbVAsa0JBQWtCLEdBQUcsQ0FBekI7QUFFQSxVQUFJQyxTQUFTLEdBQUd6WCxTQUFTLENBQUN5QixJQUFWLENBQWU7QUFBRSxnQkFBUTtBQUFFNlMsYUFBRyxFQUFFLElBQUl2VixJQUFKLENBQVNBLElBQUksQ0FBQzJTLEdBQUwsS0FBYSxLQUFLLElBQTNCO0FBQVA7QUFBVixPQUFmLEVBQXNFL1AsS0FBdEUsRUFBaEI7O0FBQ0EsVUFBSThWLFNBQVMsQ0FBQy9aLE1BQVYsR0FBbUIsQ0FBdkIsRUFBeUI7QUFDckIsYUFBSzJCLENBQUwsSUFBVW9ZLFNBQVYsRUFBb0I7QUFDaEJwUCwwQkFBZ0IsSUFBSW9QLFNBQVMsQ0FBQ3BZLENBQUQsQ0FBVCxDQUFhK0MsUUFBakM7QUFDQW9WLDRCQUFrQixJQUFJQyxTQUFTLENBQUNwWSxDQUFELENBQVQsQ0FBYTBILFlBQW5DO0FBQ0g7O0FBQ0RzQix3QkFBZ0IsR0FBR0EsZ0JBQWdCLEdBQUdvUCxTQUFTLENBQUMvWixNQUFoRDtBQUNBOFosMEJBQWtCLEdBQUdBLGtCQUFrQixHQUFHQyxTQUFTLENBQUMvWixNQUFwRDtBQUVBbUMsYUFBSyxDQUFDdUksTUFBTixDQUFhO0FBQUNYLGlCQUFPLEVBQUM5TCxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjZFO0FBQWhDLFNBQWIsRUFBc0Q7QUFBQ0gsY0FBSSxFQUFDO0FBQUNvUSxpQ0FBcUIsRUFBQ0Ysa0JBQXZCO0FBQTJDRywrQkFBbUIsRUFBQ3RQO0FBQS9EO0FBQU4sU0FBdEQ7QUFDQXFMLG1CQUFXLENBQUN4TixNQUFaLENBQW1CO0FBQ2ZtQywwQkFBZ0IsRUFBRUEsZ0JBREg7QUFFZm1QLDRCQUFrQixFQUFFQSxrQkFGTDtBQUdmcGEsY0FBSSxFQUFFMEIsSUFIUztBQUlmZ1QsbUJBQVMsRUFBRUo7QUFKSSxTQUFuQjtBQU1IO0FBQ0o7O0FBQ0QsUUFBSTVTLElBQUksSUFBSSxHQUFaLEVBQWdCO0FBQ1osVUFBSXVKLGdCQUFnQixHQUFHLENBQXZCO0FBQ0EsVUFBSW1QLGtCQUFrQixHQUFHLENBQXpCO0FBQ0EsVUFBSUMsU0FBUyxHQUFHelgsU0FBUyxDQUFDeUIsSUFBVixDQUFlO0FBQUUsZ0JBQVE7QUFBRTZTLGFBQUcsRUFBRSxJQUFJdlYsSUFBSixDQUFTQSxJQUFJLENBQUMyUyxHQUFMLEtBQWEsS0FBRyxFQUFILEdBQVEsSUFBOUI7QUFBUDtBQUFWLE9BQWYsRUFBeUUvUCxLQUF6RSxFQUFoQjs7QUFDQSxVQUFJOFYsU0FBUyxDQUFDL1osTUFBVixHQUFtQixDQUF2QixFQUF5QjtBQUNyQixhQUFLMkIsQ0FBTCxJQUFVb1ksU0FBVixFQUFvQjtBQUNoQnBQLDBCQUFnQixJQUFJb1AsU0FBUyxDQUFDcFksQ0FBRCxDQUFULENBQWErQyxRQUFqQztBQUNBb1YsNEJBQWtCLElBQUlDLFNBQVMsQ0FBQ3BZLENBQUQsQ0FBVCxDQUFhMEgsWUFBbkM7QUFDSDs7QUFDRHNCLHdCQUFnQixHQUFHQSxnQkFBZ0IsR0FBR29QLFNBQVMsQ0FBQy9aLE1BQWhEO0FBQ0E4WiwwQkFBa0IsR0FBR0Esa0JBQWtCLEdBQUdDLFNBQVMsQ0FBQy9aLE1BQXBEO0FBRUFtQyxhQUFLLENBQUN1SSxNQUFOLENBQWE7QUFBQ1gsaUJBQU8sRUFBQzlMLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNkU7QUFBaEMsU0FBYixFQUFzRDtBQUFDSCxjQUFJLEVBQUM7QUFBQ3NRLCtCQUFtQixFQUFDSixrQkFBckI7QUFBeUNLLDZCQUFpQixFQUFDeFA7QUFBM0Q7QUFBTixTQUF0RDtBQUNBcUwsbUJBQVcsQ0FBQ3hOLE1BQVosQ0FBbUI7QUFDZm1DLDBCQUFnQixFQUFFQSxnQkFESDtBQUVmbVAsNEJBQWtCLEVBQUVBLGtCQUZMO0FBR2ZwYSxjQUFJLEVBQUUwQixJQUhTO0FBSWZnVCxtQkFBUyxFQUFFSjtBQUpJLFNBQW5CO0FBTUg7QUFDSjs7QUFFRCxRQUFJNVMsSUFBSSxJQUFJLEdBQVosRUFBZ0I7QUFDWixVQUFJdUosZ0JBQWdCLEdBQUcsQ0FBdkI7QUFDQSxVQUFJbVAsa0JBQWtCLEdBQUcsQ0FBekI7QUFDQSxVQUFJQyxTQUFTLEdBQUd6WCxTQUFTLENBQUN5QixJQUFWLENBQWU7QUFBRSxnQkFBUTtBQUFFNlMsYUFBRyxFQUFFLElBQUl2VixJQUFKLENBQVNBLElBQUksQ0FBQzJTLEdBQUwsS0FBYSxLQUFHLEVBQUgsR0FBTSxFQUFOLEdBQVcsSUFBakM7QUFBUDtBQUFWLE9BQWYsRUFBNEUvUCxLQUE1RSxFQUFoQjs7QUFDQSxVQUFJOFYsU0FBUyxDQUFDL1osTUFBVixHQUFtQixDQUF2QixFQUF5QjtBQUNyQixhQUFLMkIsQ0FBTCxJQUFVb1ksU0FBVixFQUFvQjtBQUNoQnBQLDBCQUFnQixJQUFJb1AsU0FBUyxDQUFDcFksQ0FBRCxDQUFULENBQWErQyxRQUFqQztBQUNBb1YsNEJBQWtCLElBQUlDLFNBQVMsQ0FBQ3BZLENBQUQsQ0FBVCxDQUFhMEgsWUFBbkM7QUFDSDs7QUFDRHNCLHdCQUFnQixHQUFHQSxnQkFBZ0IsR0FBR29QLFNBQVMsQ0FBQy9aLE1BQWhEO0FBQ0E4WiwwQkFBa0IsR0FBR0Esa0JBQWtCLEdBQUdDLFNBQVMsQ0FBQy9aLE1BQXBEO0FBRUFtQyxhQUFLLENBQUN1SSxNQUFOLENBQWE7QUFBQ1gsaUJBQU8sRUFBQzlMLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNkU7QUFBaEMsU0FBYixFQUFzRDtBQUFDSCxjQUFJLEVBQUM7QUFBQ3dRLDhCQUFrQixFQUFDTixrQkFBcEI7QUFBd0NPLDRCQUFnQixFQUFDMVA7QUFBekQ7QUFBTixTQUF0RDtBQUNBcUwsbUJBQVcsQ0FBQ3hOLE1BQVosQ0FBbUI7QUFDZm1DLDBCQUFnQixFQUFFQSxnQkFESDtBQUVmbVAsNEJBQWtCLEVBQUVBLGtCQUZMO0FBR2ZwYSxjQUFJLEVBQUUwQixJQUhTO0FBSWZnVCxtQkFBUyxFQUFFSjtBQUpJLFNBQW5CO0FBTUg7QUFDSixLQXBFdUQsQ0FzRXhEOztBQUNILEdBNVFVO0FBNlFYLGdEQUE4QyxZQUFVO0FBQ3BELFNBQUs5VSxPQUFMO0FBQ0EsUUFBSThELFVBQVUsR0FBRzFFLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0JFLEtBQXBCLEVBQWpCO0FBQ0EsUUFBSStQLEdBQUcsR0FBRyxJQUFJM1MsSUFBSixFQUFWOztBQUNBLFNBQUtNLENBQUwsSUFBVXFCLFVBQVYsRUFBcUI7QUFDakIsVUFBSTJILGdCQUFnQixHQUFHLENBQXZCO0FBRUEsVUFBSTdHLE1BQU0sR0FBRzVCLFNBQVMsQ0FBQzZCLElBQVYsQ0FBZTtBQUFDQyx1QkFBZSxFQUFDaEIsVUFBVSxDQUFDckIsQ0FBRCxDQUFWLENBQWMxQyxPQUEvQjtBQUF3QyxnQkFBUTtBQUFFMlgsYUFBRyxFQUFFLElBQUl2VixJQUFKLENBQVNBLElBQUksQ0FBQzJTLEdBQUwsS0FBYSxLQUFHLEVBQUgsR0FBTSxFQUFOLEdBQVcsSUFBakM7QUFBUDtBQUFoRCxPQUFmLEVBQWlIO0FBQUN0SCxjQUFNLEVBQUM7QUFBQ3JJLGdCQUFNLEVBQUM7QUFBUjtBQUFSLE9BQWpILEVBQXNJSixLQUF0SSxFQUFiOztBQUVBLFVBQUlILE1BQU0sQ0FBQzlELE1BQVAsR0FBZ0IsQ0FBcEIsRUFBc0I7QUFDbEIsWUFBSXNhLFlBQVksR0FBRyxFQUFuQjs7QUFDQSxhQUFLN1YsQ0FBTCxJQUFVWCxNQUFWLEVBQWlCO0FBQ2J3VyxzQkFBWSxDQUFDclMsSUFBYixDQUFrQm5FLE1BQU0sQ0FBQ1csQ0FBRCxDQUFOLENBQVVKLE1BQTVCO0FBQ0g7O0FBRUQsWUFBSTBWLFNBQVMsR0FBR3pYLFNBQVMsQ0FBQ3lCLElBQVYsQ0FBZTtBQUFDTSxnQkFBTSxFQUFFO0FBQUNFLGVBQUcsRUFBQytWO0FBQUw7QUFBVCxTQUFmLEVBQTZDO0FBQUM1TixnQkFBTSxFQUFDO0FBQUNySSxrQkFBTSxFQUFDLENBQVI7QUFBVUssb0JBQVEsRUFBQztBQUFuQjtBQUFSLFNBQTdDLEVBQTZFVCxLQUE3RSxFQUFoQjs7QUFHQSxhQUFLc1csQ0FBTCxJQUFVUixTQUFWLEVBQW9CO0FBQ2hCcFAsMEJBQWdCLElBQUlvUCxTQUFTLENBQUNRLENBQUQsQ0FBVCxDQUFhN1YsUUFBakM7QUFDSDs7QUFFRGlHLHdCQUFnQixHQUFHQSxnQkFBZ0IsR0FBR29QLFNBQVMsQ0FBQy9aLE1BQWhEO0FBQ0g7O0FBRURpVywwQkFBb0IsQ0FBQ3pOLE1BQXJCLENBQTRCO0FBQ3hCeEUsdUJBQWUsRUFBRWhCLFVBQVUsQ0FBQ3JCLENBQUQsQ0FBVixDQUFjMUMsT0FEUDtBQUV4QjBMLHdCQUFnQixFQUFFQSxnQkFGTTtBQUd4QmpMLFlBQUksRUFBRSxnQ0FIa0I7QUFJeEIwVSxpQkFBUyxFQUFFSjtBQUphLE9BQTVCO0FBTUg7O0FBRUQsV0FBTyxJQUFQO0FBQ0g7QUEvU1UsQ0FBZixFOzs7Ozs7Ozs7OztBQzdEQSxJQUFJL1YsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJaUUsZ0JBQUosRUFBcUJDLFNBQXJCLEVBQStCOFQsWUFBL0IsRUFBNENELGlCQUE1QyxFQUE4RDVULGVBQTlEO0FBQThFckUsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDa0Usa0JBQWdCLENBQUNqRSxDQUFELEVBQUc7QUFBQ2lFLG9CQUFnQixHQUFDakUsQ0FBakI7QUFBbUIsR0FBeEM7O0FBQXlDa0UsV0FBUyxDQUFDbEUsQ0FBRCxFQUFHO0FBQUNrRSxhQUFTLEdBQUNsRSxDQUFWO0FBQVksR0FBbEU7O0FBQW1FZ1ksY0FBWSxDQUFDaFksQ0FBRCxFQUFHO0FBQUNnWSxnQkFBWSxHQUFDaFksQ0FBYjtBQUFlLEdBQWxHOztBQUFtRytYLG1CQUFpQixDQUFDL1gsQ0FBRCxFQUFHO0FBQUMrWCxxQkFBaUIsR0FBQy9YLENBQWxCO0FBQW9CLEdBQTVJOztBQUE2SW1FLGlCQUFlLENBQUNuRSxDQUFELEVBQUc7QUFBQ21FLG1CQUFlLEdBQUNuRSxDQUFoQjtBQUFrQjs7QUFBbEwsQ0FBNUIsRUFBZ04sQ0FBaE47QUFBbU4sSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBN0MsRUFBMkUsQ0FBM0U7QUFJaFhILE1BQU0sQ0FBQzJWLE9BQVAsQ0FBZSx1QkFBZixFQUF3QyxZQUFZO0FBQ2hELFNBQU92UixnQkFBZ0IsQ0FBQzBCLElBQWpCLEVBQVA7QUFDSCxDQUZEO0FBSUE5RixNQUFNLENBQUMyVixPQUFQLENBQWUsMEJBQWYsRUFBMkMsVUFBUzNVLE9BQVQsRUFBa0J1YixHQUFsQixFQUFzQjtBQUM3RCxTQUFPblksZ0JBQWdCLENBQUMwQixJQUFqQixDQUFzQjtBQUFDOUUsV0FBTyxFQUFDQTtBQUFULEdBQXRCLEVBQXdDO0FBQUNnSCxTQUFLLEVBQUN1VSxHQUFQO0FBQVl4VSxRQUFJLEVBQUM7QUFBQzNCLFlBQU0sRUFBQyxDQUFDO0FBQVQ7QUFBakIsR0FBeEMsQ0FBUDtBQUNILENBRkQ7QUFJQXBHLE1BQU0sQ0FBQzJWLE9BQVAsQ0FBZSxtQkFBZixFQUFvQyxZQUFVO0FBQzFDLFNBQU90UixTQUFTLENBQUN5QixJQUFWLENBQWUsRUFBZixFQUFrQjtBQUFDaUMsUUFBSSxFQUFDO0FBQUMzQixZQUFNLEVBQUMsQ0FBQztBQUFULEtBQU47QUFBa0I0QixTQUFLLEVBQUM7QUFBeEIsR0FBbEIsQ0FBUDtBQUNILENBRkQ7QUFJQWhJLE1BQU0sQ0FBQzJWLE9BQVAsQ0FBZSx1QkFBZixFQUF3QyxZQUFVO0FBQzlDLFNBQU9yUixlQUFlLENBQUN3QixJQUFoQixDQUFxQixFQUFyQixFQUF3QjtBQUFDaUMsUUFBSSxFQUFDO0FBQUMzQixZQUFNLEVBQUMsQ0FBQztBQUFULEtBQU47QUFBbUI0QixTQUFLLEVBQUM7QUFBekIsR0FBeEIsQ0FBUDtBQUNILENBRkQ7QUFJQXFJLGdCQUFnQixDQUFDLHdCQUFELEVBQTJCLFVBQVNyUCxPQUFULEVBQWtCUyxJQUFsQixFQUF1QjtBQUM5RCxNQUFJK2EsVUFBVSxHQUFHLEVBQWpCOztBQUNBLE1BQUkvYSxJQUFJLElBQUksT0FBWixFQUFvQjtBQUNoQithLGNBQVUsR0FBRztBQUNUdEQsV0FBSyxFQUFFbFk7QUFERSxLQUFiO0FBR0gsR0FKRCxNQUtJO0FBQ0F3YixjQUFVLEdBQUc7QUFDVDdMLGNBQVEsRUFBRTNQO0FBREQsS0FBYjtBQUdIOztBQUNELFNBQU87QUFDSDhFLFFBQUksR0FBRTtBQUNGLGFBQU9vUyxpQkFBaUIsQ0FBQ3BTLElBQWxCLENBQXVCMFcsVUFBdkIsQ0FBUDtBQUNILEtBSEU7O0FBSUhsTSxZQUFRLEVBQUUsQ0FDTjtBQUNJeEssVUFBSSxDQUFDOFUsS0FBRCxFQUFPO0FBQ1AsZUFBT3ZhLFVBQVUsQ0FBQ3lGLElBQVgsQ0FDSCxFQURHLEVBRUg7QUFBQzJJLGdCQUFNLEVBQUM7QUFBQ3pOLG1CQUFPLEVBQUMsQ0FBVDtBQUFZcU0sdUJBQVcsRUFBQyxDQUF4QjtBQUEyQkMsdUJBQVcsRUFBQztBQUF2QztBQUFSLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE07QUFKUCxHQUFQO0FBZUgsQ0EzQmUsQ0FBaEI7QUE2QkErQyxnQkFBZ0IsQ0FBQyx5QkFBRCxFQUE0QixVQUFTclAsT0FBVCxFQUFrQlMsSUFBbEIsRUFBdUI7QUFDL0QsU0FBTztBQUNIcUUsUUFBSSxHQUFFO0FBQ0YsYUFBT3FTLFlBQVksQ0FBQ3JTLElBQWIsQ0FDSDtBQUFDLFNBQUNyRSxJQUFELEdBQVFUO0FBQVQsT0FERyxFQUVIO0FBQUMrRyxZQUFJLEVBQUU7QUFBQzJTLG1CQUFTLEVBQUUsQ0FBQztBQUFiO0FBQVAsT0FGRyxDQUFQO0FBSUgsS0FORTs7QUFPSHBLLFlBQVEsRUFBRSxDQUNOO0FBQ0l4SyxVQUFJLEdBQUU7QUFDRixlQUFPekYsVUFBVSxDQUFDeUYsSUFBWCxDQUNILEVBREcsRUFFSDtBQUFDMkksZ0JBQU0sRUFBQztBQUFDek4sbUJBQU8sRUFBQyxDQUFUO0FBQVlxTSx1QkFBVyxFQUFDLENBQXhCO0FBQTJCOUssNEJBQWdCLEVBQUM7QUFBNUM7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNO0FBUFAsR0FBUDtBQWtCSCxDQW5CZSxDQUFoQixDOzs7Ozs7Ozs7OztBQ2pEQXRDLE1BQU0sQ0FBQ3NRLE1BQVAsQ0FBYztBQUFDbk0sa0JBQWdCLEVBQUMsTUFBSUEsZ0JBQXRCO0FBQXVDQyxXQUFTLEVBQUMsTUFBSUEsU0FBckQ7QUFBK0Q2VCxtQkFBaUIsRUFBQyxNQUFJQSxpQkFBckY7QUFBdUdDLGNBQVksRUFBQyxNQUFJQSxZQUF4SDtBQUFxSTdULGlCQUFlLEVBQUMsTUFBSUEsZUFBeko7QUFBeUt5VCxhQUFXLEVBQUMsTUFBSUEsV0FBekw7QUFBcU1DLHNCQUFvQixFQUFDLE1BQUlBO0FBQTlOLENBQWQ7QUFBbVEsSUFBSXhILEtBQUo7QUFBVXZRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3NRLE9BQUssQ0FBQ3JRLENBQUQsRUFBRztBQUFDcVEsU0FBSyxHQUFDclEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUF2QyxFQUFxRSxDQUFyRTtBQUd2VSxNQUFNaUUsZ0JBQWdCLEdBQUcsSUFBSW9NLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixtQkFBckIsQ0FBekI7QUFDQSxNQUFNcE0sU0FBUyxHQUFHLElBQUltTSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsV0FBckIsQ0FBbEI7QUFDQSxNQUFNeUgsaUJBQWlCLEdBQUcsSUFBSTFILEtBQUssQ0FBQ0MsVUFBVixDQUFxQixxQkFBckIsQ0FBMUI7QUFDQSxNQUFNMEgsWUFBWSxHQUFHLElBQUszSCxLQUFLLENBQUNDLFVBQVgsQ0FBc0IsZUFBdEIsQ0FBckI7QUFDQSxNQUFNbk0sZUFBZSxHQUFHLElBQUlrTSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsNEJBQXJCLENBQXhCO0FBQ0EsTUFBTXNILFdBQVcsR0FBRyxJQUFJdkgsS0FBSyxDQUFDQyxVQUFWLENBQXFCLGNBQXJCLENBQXBCO0FBQ0EsTUFBTXVILG9CQUFvQixHQUFHLElBQUl4SCxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsd0JBQXJCLENBQTdCO0FBRVB5SCxpQkFBaUIsQ0FBQ3hILE9BQWxCLENBQTBCO0FBQ3RCK0wsaUJBQWUsR0FBRTtBQUNiLFFBQUlyYSxTQUFTLEdBQUcvQixVQUFVLENBQUNnQyxPQUFYLENBQW1CO0FBQUNyQixhQUFPLEVBQUMsS0FBSzJQO0FBQWQsS0FBbkIsQ0FBaEI7QUFDQSxXQUFRdk8sU0FBUyxDQUFDaUwsV0FBWCxHQUF3QmpMLFNBQVMsQ0FBQ2lMLFdBQVYsQ0FBc0JxUCxPQUE5QyxHQUFzRCxLQUFLL0wsUUFBbEU7QUFDSCxHQUpxQjs7QUFLdEJnTSxjQUFZLEdBQUU7QUFDVixRQUFJdmEsU0FBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDckIsYUFBTyxFQUFDLEtBQUtrWTtBQUFkLEtBQW5CLENBQWhCO0FBQ0EsV0FBUTlXLFNBQVMsQ0FBQ2lMLFdBQVgsR0FBd0JqTCxTQUFTLENBQUNpTCxXQUFWLENBQXNCcVAsT0FBOUMsR0FBc0QsS0FBS3hELEtBQWxFO0FBQ0g7O0FBUnFCLENBQTFCLEU7Ozs7Ozs7Ozs7O0FDWEEsSUFBSWxaLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSThYLE1BQUo7QUFBV2hZLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQytYLFFBQU0sQ0FBQzlYLENBQUQsRUFBRztBQUFDOFgsVUFBTSxHQUFDOVgsQ0FBUDtBQUFTOztBQUFwQixDQUEzQixFQUFpRCxDQUFqRDtBQUFvRCxJQUFJMlcsS0FBSjtBQUFVN1csTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDNFcsT0FBSyxDQUFDM1csQ0FBRCxFQUFHO0FBQUMyVyxTQUFLLEdBQUMzVyxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBSXpJSCxNQUFNLENBQUMyVixPQUFQLENBQWUsZUFBZixFQUFnQyxZQUFZO0FBQ3hDLFNBQU9zQyxNQUFNLENBQUNuUyxJQUFQLENBQVk7QUFBQ2dHLFdBQU8sRUFBQzlMLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCNkU7QUFBaEMsR0FBWixDQUFQO0FBQ0gsQ0FGRCxFOzs7Ozs7Ozs7OztBQ0pBN0wsTUFBTSxDQUFDc1EsTUFBUCxDQUFjO0FBQUMwSCxRQUFNLEVBQUMsTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUl6SCxLQUFKO0FBQVV2USxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNzUSxPQUFLLENBQUNyUSxDQUFELEVBQUc7QUFBQ3FRLFNBQUssR0FBQ3JRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFdEMsTUFBTThYLE1BQU0sR0FBRyxJQUFJekgsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFFBQXJCLENBQWYsQzs7Ozs7Ozs7Ozs7QUNGUCxJQUFJelEsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUlxRSxZQUFKO0FBQWlCdkUsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ3NFLGNBQVksQ0FBQ3JFLENBQUQsRUFBRztBQUFDcUUsZ0JBQVksR0FBQ3JFLENBQWI7QUFBZTs7QUFBaEMsQ0FBakQsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBN0MsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSW9FLGtCQUFKO0FBQXVCdEUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0JBQVosRUFBNEM7QUFBQ3FFLG9CQUFrQixDQUFDcEUsQ0FBRCxFQUFHO0FBQUNvRSxzQkFBa0IsR0FBQ3BFLENBQW5CO0FBQXFCOztBQUE1QyxDQUE1QyxFQUEwRixDQUExRjtBQU1uVixNQUFNeWMsYUFBYSxHQUFHLEVBQXRCO0FBRUE1YyxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLHdCQUFzQixVQUFTc0ksSUFBVCxFQUFlNEMsU0FBZixFQUF5QjtBQUMzQyxTQUFLaEwsT0FBTDtBQUNBb0ksUUFBSSxHQUFHQSxJQUFJLENBQUN3VCxXQUFMLEVBQVA7QUFDQSxRQUFJdGMsR0FBRyxHQUFHRyxHQUFHLEdBQUUsT0FBTCxHQUFhMkksSUFBdkI7QUFDQSxRQUFJbEksUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsUUFBSXVjLEVBQUUsR0FBRzFiLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQVQ7QUFFQVQsV0FBTyxDQUFDQyxHQUFSLENBQVl1SSxJQUFaO0FBRUF5VCxNQUFFLENBQUMxVyxNQUFILEdBQVl3RSxRQUFRLENBQUNrUyxFQUFFLENBQUMxVyxNQUFKLENBQXBCLENBVDJDLENBVzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBR0EsUUFBSTJXLElBQUksR0FBR3ZZLFlBQVksQ0FBQytGLE1BQWIsQ0FBb0J1UyxFQUFwQixDQUFYOztBQUNBLFFBQUlDLElBQUosRUFBUztBQUNMLGFBQU9BLElBQVA7QUFDSCxLQUZELE1BR0ssT0FBTyxLQUFQO0FBQ1IsR0E5RFU7QUErRFgsaUNBQStCLFVBQVMvYixPQUFULEVBQWtCb0YsTUFBbEIsRUFBeUI7QUFDcEQ7QUFDQSxXQUFPNUIsWUFBWSxDQUFDc0IsSUFBYixDQUFrQjtBQUNyQnhELFNBQUcsRUFBRSxDQUFDO0FBQUNvVyxZQUFJLEVBQUUsQ0FDVDtBQUFDLHlCQUFlO0FBQWhCLFNBRFMsRUFFVDtBQUFDLG1DQUF5QjtBQUExQixTQUZTLEVBR1Q7QUFBQyxxQ0FBMkIxWDtBQUE1QixTQUhTO0FBQVAsT0FBRCxFQUlEO0FBQUMwWCxZQUFJLEVBQUMsQ0FDTjtBQUFDLG1DQUF5QjtBQUExQixTQURNLEVBRU47QUFBQyxxQ0FBMkI7QUFBNUIsU0FGTSxFQUdOO0FBQUMsbUNBQXlCO0FBQTFCLFNBSE0sRUFJTjtBQUFDLHFDQUEyQjFYO0FBQTVCLFNBSk07QUFBTixPQUpDLEVBU0Q7QUFBQzBYLFlBQUksRUFBQyxDQUNOO0FBQUMseUJBQWU7QUFBaEIsU0FETSxFQUVOO0FBQUMsbUNBQXlCO0FBQTFCLFNBRk0sRUFHTjtBQUFDLHFDQUEyQjFYO0FBQTVCLFNBSE07QUFBTixPQVRDLEVBYUQ7QUFBQzBYLFlBQUksRUFBQyxDQUNOO0FBQUMseUJBQWU7QUFBaEIsU0FETSxFQUVOO0FBQUMsbUNBQXlCO0FBQTFCLFNBRk0sRUFHTjtBQUFDLHFDQUEyQjFYO0FBQTVCLFNBSE07QUFBTixPQWJDLEVBaUJEO0FBQUMwWCxZQUFJLEVBQUMsQ0FDTjtBQUFDLHlCQUFlO0FBQWhCLFNBRE0sRUFFTjtBQUFDLG1DQUF5QjtBQUExQixTQUZNLEVBR047QUFBQyxxQ0FBMkIxWDtBQUE1QixTQUhNO0FBQU4sT0FqQkMsQ0FEZ0I7QUF1QnJCLGNBQVE7QUFBQ2lLLGVBQU8sRUFBRTtBQUFWLE9BdkJhO0FBd0JyQjdFLFlBQU0sRUFBQztBQUFDNFcsV0FBRyxFQUFDNVc7QUFBTDtBQXhCYyxLQUFsQixFQXlCUDtBQUFDMkIsVUFBSSxFQUFDO0FBQUMzQixjQUFNLEVBQUMsQ0FBQztBQUFULE9BQU47QUFDSTRCLFdBQUssRUFBRTtBQURYLEtBekJPLEVBMkJMaEMsS0EzQkssRUFBUDtBQTRCSCxHQTdGVTtBQThGWCwyQkFBeUIsVUFBU2hGLE9BQVQsRUFBOEI7QUFBQSxRQUFaeU4sTUFBWSx1RUFBTCxJQUFLO0FBQ25EO0FBQ0EsUUFBSXJNLFNBQUo7QUFDQSxRQUFJLENBQUNxTSxNQUFMLEVBQ0lBLE1BQU0sR0FBRztBQUFDek4sYUFBTyxFQUFDLENBQVQ7QUFBWXFNLGlCQUFXLEVBQUMsQ0FBeEI7QUFBMkI5SyxzQkFBZ0IsRUFBQyxDQUE1QztBQUErQ0MsdUJBQWlCLEVBQUM7QUFBakUsS0FBVDs7QUFDSixRQUFJeEIsT0FBTyxDQUFDaWMsUUFBUixDQUFpQmpkLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCaVcsbUJBQXhDLENBQUosRUFBaUU7QUFDN0Q7QUFDQTlhLGVBQVMsR0FBRy9CLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQ0Usd0JBQWdCLEVBQUN2QjtBQUFsQixPQUFuQixFQUErQztBQUFDeU47QUFBRCxPQUEvQyxDQUFaO0FBQ0gsS0FIRCxNQUlLLElBQUl6TixPQUFPLENBQUNpYyxRQUFSLENBQWlCamQsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJrVyxtQkFBeEMsQ0FBSixFQUFpRTtBQUNsRTtBQUNBL2EsZUFBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDRyx5QkFBaUIsRUFBQ3hCO0FBQW5CLE9BQW5CLEVBQWdEO0FBQUN5TjtBQUFELE9BQWhELENBQVo7QUFDSCxLQUhJLE1BSUEsSUFBSXpOLE9BQU8sQ0FBQ2UsTUFBUixLQUFtQjZhLGFBQXZCLEVBQXNDO0FBQ3ZDeGEsZUFBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDckIsZUFBTyxFQUFDQTtBQUFULE9BQW5CLEVBQXNDO0FBQUN5TjtBQUFELE9BQXRDLENBQVo7QUFDSDs7QUFDRCxRQUFJck0sU0FBSixFQUFjO0FBQ1YsYUFBT0EsU0FBUDtBQUNIOztBQUNELFdBQU8sS0FBUDtBQUVIO0FBbkhVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNSQSxJQUFJcEMsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJcUUsWUFBSjtBQUFpQnZFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9CQUFaLEVBQWlDO0FBQUNzRSxjQUFZLENBQUNyRSxDQUFELEVBQUc7QUFBQ3FFLGdCQUFZLEdBQUNyRSxDQUFiO0FBQWU7O0FBQWhDLENBQWpDLEVBQW1FLENBQW5FO0FBQXNFLElBQUk4RCxTQUFKO0FBQWNoRSxNQUFNLENBQUNDLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDK0QsV0FBUyxDQUFDOUQsQ0FBRCxFQUFHO0FBQUM4RCxhQUFTLEdBQUM5RCxDQUFWO0FBQVk7O0FBQTFCLENBQXJDLEVBQWlFLENBQWpFO0FBS3JLa1EsZ0JBQWdCLENBQUMsbUJBQUQsRUFBc0IsWUFBb0I7QUFBQSxNQUFYckksS0FBVyx1RUFBSCxFQUFHO0FBQ3RELFNBQU87QUFDSGxDLFFBQUksR0FBRTtBQUNGLGFBQU90QixZQUFZLENBQUNzQixJQUFiLENBQWtCLEVBQWxCLEVBQXFCO0FBQUNpQyxZQUFJLEVBQUM7QUFBQzNCLGdCQUFNLEVBQUMsQ0FBQztBQUFULFNBQU47QUFBbUI0QixhQUFLLEVBQUNBO0FBQXpCLE9BQXJCLENBQVA7QUFDSCxLQUhFOztBQUlIc0ksWUFBUSxFQUFFLENBQ047QUFDSXhLLFVBQUksQ0FBQ2dYLEVBQUQsRUFBSTtBQUNKLGVBQU83WSxTQUFTLENBQUM2QixJQUFWLENBQ0g7QUFBQ00sZ0JBQU0sRUFBQzBXLEVBQUUsQ0FBQzFXO0FBQVgsU0FERyxFQUVIO0FBQUNxSSxnQkFBTSxFQUFDO0FBQUN0TCxnQkFBSSxFQUFDLENBQU47QUFBU2lELGtCQUFNLEVBQUM7QUFBaEI7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNO0FBSlAsR0FBUDtBQWVILENBaEJlLENBQWhCO0FBa0JBaUssZ0JBQWdCLENBQUMsd0JBQUQsRUFBMkIsVUFBUytNLGdCQUFULEVBQTJCQyxnQkFBM0IsRUFBdUQ7QUFBQSxNQUFWclYsS0FBVSx1RUFBSixHQUFJO0FBQzlGLE1BQUlzVixLQUFLLEdBQUcsRUFBWjs7QUFDQSxNQUFJRixnQkFBZ0IsSUFBSUMsZ0JBQXhCLEVBQXlDO0FBQ3JDQyxTQUFLLEdBQUc7QUFBQ2hiLFNBQUcsRUFBQyxDQUFDO0FBQUMsbUNBQTBCOGE7QUFBM0IsT0FBRCxFQUErQztBQUFDLG1DQUEwQkM7QUFBM0IsT0FBL0M7QUFBTCxLQUFSO0FBQ0g7O0FBRUQsTUFBSSxDQUFDRCxnQkFBRCxJQUFxQkMsZ0JBQXpCLEVBQTBDO0FBQ3RDQyxTQUFLLEdBQUc7QUFBQyxpQ0FBMEJEO0FBQTNCLEtBQVI7QUFDSDs7QUFFRCxTQUFPO0FBQ0h2WCxRQUFJLEdBQUU7QUFDRixhQUFPdEIsWUFBWSxDQUFDc0IsSUFBYixDQUFrQndYLEtBQWxCLEVBQXlCO0FBQUN2VixZQUFJLEVBQUM7QUFBQzNCLGdCQUFNLEVBQUMsQ0FBQztBQUFULFNBQU47QUFBbUI0QixhQUFLLEVBQUNBO0FBQXpCLE9BQXpCLENBQVA7QUFDSCxLQUhFOztBQUlIc0ksWUFBUSxFQUFDLENBQ0w7QUFDSXhLLFVBQUksQ0FBQ2dYLEVBQUQsRUFBSTtBQUNKLGVBQU83WSxTQUFTLENBQUM2QixJQUFWLENBQ0g7QUFBQ00sZ0JBQU0sRUFBQzBXLEVBQUUsQ0FBQzFXO0FBQVgsU0FERyxFQUVIO0FBQUNxSSxnQkFBTSxFQUFDO0FBQUN0TCxnQkFBSSxFQUFDLENBQU47QUFBU2lELGtCQUFNLEVBQUM7QUFBaEI7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURLO0FBSk4sR0FBUDtBQWVILENBekJlLENBQWhCO0FBMkJBaUssZ0JBQWdCLENBQUMsc0JBQUQsRUFBeUIsVUFBU2hILElBQVQsRUFBYztBQUNuRCxTQUFPO0FBQ0h2RCxRQUFJLEdBQUU7QUFDRixhQUFPdEIsWUFBWSxDQUFDc0IsSUFBYixDQUFrQjtBQUFDMlIsY0FBTSxFQUFDcE87QUFBUixPQUFsQixDQUFQO0FBQ0gsS0FIRTs7QUFJSGlILFlBQVEsRUFBRSxDQUNOO0FBQ0l4SyxVQUFJLENBQUNnWCxFQUFELEVBQUk7QUFDSixlQUFPN1ksU0FBUyxDQUFDNkIsSUFBVixDQUNIO0FBQUNNLGdCQUFNLEVBQUMwVyxFQUFFLENBQUMxVztBQUFYLFNBREcsRUFFSDtBQUFDcUksZ0JBQU0sRUFBQztBQUFDdEwsZ0JBQUksRUFBQyxDQUFOO0FBQVNpRCxrQkFBTSxFQUFDO0FBQWhCO0FBQVIsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FETTtBQUpQLEdBQVA7QUFlSCxDQWhCZSxDQUFoQjtBQWtCQWlLLGdCQUFnQixDQUFDLHFCQUFELEVBQXdCLFVBQVNqSyxNQUFULEVBQWdCO0FBQ3BELFNBQU87QUFDSE4sUUFBSSxHQUFFO0FBQ0YsYUFBT3RCLFlBQVksQ0FBQ3NCLElBQWIsQ0FBa0I7QUFBQ00sY0FBTSxFQUFDQTtBQUFSLE9BQWxCLENBQVA7QUFDSCxLQUhFOztBQUlIa0ssWUFBUSxFQUFFLENBQ047QUFDSXhLLFVBQUksQ0FBQ2dYLEVBQUQsRUFBSTtBQUNKLGVBQU83WSxTQUFTLENBQUM2QixJQUFWLENBQ0g7QUFBQ00sZ0JBQU0sRUFBQzBXLEVBQUUsQ0FBQzFXO0FBQVgsU0FERyxFQUVIO0FBQUNxSSxnQkFBTSxFQUFDO0FBQUN0TCxnQkFBSSxFQUFDLENBQU47QUFBU2lELGtCQUFNLEVBQUM7QUFBaEI7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNO0FBSlAsR0FBUDtBQWVILENBaEJlLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDcEVBbkcsTUFBTSxDQUFDc1EsTUFBUCxDQUFjO0FBQUMvTCxjQUFZLEVBQUMsTUFBSUE7QUFBbEIsQ0FBZDtBQUErQyxJQUFJZ00sS0FBSjtBQUFVdlEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDc1EsT0FBSyxDQUFDclEsQ0FBRCxFQUFHO0FBQUNxUSxTQUFLLEdBQUNyUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUk4RCxTQUFKO0FBQWNoRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDK0QsV0FBUyxDQUFDOUQsQ0FBRCxFQUFHO0FBQUM4RCxhQUFTLEdBQUM5RCxDQUFWO0FBQVk7O0FBQTFCLENBQWxDLEVBQThELENBQTlEO0FBQWlFLElBQUlvZCxNQUFKO0FBQVd0ZCxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQkFBWixFQUE0QztBQUFDcWQsUUFBTSxDQUFDcGQsQ0FBRCxFQUFHO0FBQUNvZCxVQUFNLEdBQUNwZCxDQUFQO0FBQVM7O0FBQXBCLENBQTVDLEVBQWtFLENBQWxFO0FBSTlMLE1BQU1xRSxZQUFZLEdBQUcsSUFBSWdNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixjQUFyQixDQUFyQjtBQUVQak0sWUFBWSxDQUFDa00sT0FBYixDQUFxQjtBQUNqQnZLLE9BQUssR0FBRTtBQUNILFdBQU9sQyxTQUFTLENBQUM1QixPQUFWLENBQWtCO0FBQUMrRCxZQUFNLEVBQUMsS0FBS0E7QUFBYixLQUFsQixDQUFQO0FBQ0g7O0FBSGdCLENBQXJCLEU7Ozs7Ozs7Ozs7O0FDTkEsSUFBSXBHLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXFFLFlBQUo7QUFBaUJ2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDc0UsY0FBWSxDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxnQkFBWSxHQUFDckUsQ0FBYjtBQUFlOztBQUFoQyxDQUFqRCxFQUFtRixDQUFuRjtBQUFzRixJQUFJOEQsU0FBSjtBQUFjaEUsTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQytELFdBQVMsQ0FBQzlELENBQUQsRUFBRztBQUFDOEQsYUFBUyxHQUFDOUQsQ0FBVjtBQUFZOztBQUExQixDQUFyQyxFQUFpRSxDQUFqRTtBQUFvRSxJQUFJOFYsV0FBSjtBQUFnQmhXLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtDQUFaLEVBQStDO0FBQUMrVixhQUFXLENBQUM5VixDQUFELEVBQUc7QUFBQzhWLGVBQVcsR0FBQzlWLENBQVo7QUFBYzs7QUFBOUIsQ0FBL0MsRUFBK0UsQ0FBL0U7QUFLelFILE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsd0NBQXNDLFVBQVNDLE9BQVQsRUFBaUI7QUFDbkQ7QUFDQSxRQUFJOGIsRUFBRSxHQUFHdFksWUFBWSxDQUFDbkMsT0FBYixDQUFxQjtBQUFDcVcsVUFBSSxFQUFDLENBQ2hDO0FBQUMsZ0RBQXVDMVg7QUFBeEMsT0FEZ0MsRUFFaEM7QUFBQyw2QkFBb0I7QUFBckIsT0FGZ0MsRUFHaEM7QUFBQ3FXLFlBQUksRUFBQztBQUFDcE0saUJBQU8sRUFBQztBQUFUO0FBQU4sT0FIZ0M7QUFBTixLQUFyQixDQUFUOztBQU1BLFFBQUk2UixFQUFKLEVBQU87QUFDSCxVQUFJM1csS0FBSyxHQUFHbEMsU0FBUyxDQUFDNUIsT0FBVixDQUFrQjtBQUFDK0QsY0FBTSxFQUFDMFcsRUFBRSxDQUFDMVc7QUFBWCxPQUFsQixDQUFaOztBQUNBLFVBQUlELEtBQUosRUFBVTtBQUNOLGVBQU9BLEtBQUssQ0FBQ2hELElBQWI7QUFDSDtBQUNKLEtBTEQsTUFNSTtBQUNBO0FBQ0EsYUFBTyxLQUFQO0FBQ0g7QUFDSixHQW5CVTs7QUFvQlg7QUFDQSxpQ0FBK0JuQyxPQUEvQixFQUF1QztBQUNuQyxRQUFJVCxHQUFHLEdBQUdHLEdBQUcsR0FBRyxzQkFBTixHQUE2Qk0sT0FBN0IsR0FBcUMsY0FBL0M7O0FBRUEsUUFBRztBQUNDLFVBQUlnQixXQUFXLEdBQUc1QixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFsQjs7QUFDQSxVQUFJeUIsV0FBVyxDQUFDckIsVUFBWixJQUEwQixHQUE5QixFQUFrQztBQUM5QnFCLG1CQUFXLEdBQUdaLElBQUksQ0FBQ0MsS0FBTCxDQUFXVyxXQUFXLENBQUNWLE9BQXZCLEVBQWdDQyxNQUE5QztBQUNBUyxtQkFBVyxDQUFDZ0IsT0FBWixDQUFvQixDQUFDUyxVQUFELEVBQWFDLENBQWIsS0FBbUI7QUFDbkMsY0FBSTFCLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxJQUFrQjFCLFdBQVcsQ0FBQzBCLENBQUQsQ0FBWCxDQUFlZCxNQUFyQyxFQUNJWixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBZixHQUF3QkMsVUFBVSxDQUFDYixXQUFXLENBQUMwQixDQUFELENBQVgsQ0FBZWQsTUFBaEIsQ0FBbEM7QUFDUCxTQUhEO0FBS0EsZUFBT1osV0FBUDtBQUNIOztBQUFBO0FBQ0osS0FYRCxDQVlBLE9BQU9wQixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKOztBQXZDVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTEEsSUFBSVosTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUEvQixFQUE2RCxDQUE3RDtBQUFnRSxJQUFJaUUsZ0JBQUo7QUFBcUJuRSxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDa0Usa0JBQWdCLENBQUNqRSxDQUFELEVBQUc7QUFBQ2lFLG9CQUFnQixHQUFDakUsQ0FBakI7QUFBbUI7O0FBQXhDLENBQXZDLEVBQWlGLENBQWpGO0FBQW9GLElBQUlvRSxrQkFBSjtBQUF1QnRFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtCQUFaLEVBQTRDO0FBQUNxRSxvQkFBa0IsQ0FBQ3BFLENBQUQsRUFBRztBQUFDb0Usc0JBQWtCLEdBQUNwRSxDQUFuQjtBQUFxQjs7QUFBNUMsQ0FBNUMsRUFBMEYsQ0FBMUY7QUFLL1FILE1BQU0sQ0FBQzJWLE9BQVAsQ0FBZSxnQkFBZixFQUFpQyxZQUFtRTtBQUFBLE1BQXpENU4sSUFBeUQsdUVBQWxELHFCQUFrRDtBQUFBLE1BQTNCeVYsU0FBMkIsdUVBQWYsQ0FBQyxDQUFjO0FBQUEsTUFBWC9PLE1BQVcsdUVBQUosRUFBSTtBQUNoRyxTQUFPcE8sVUFBVSxDQUFDeUYsSUFBWCxDQUFnQixFQUFoQixFQUFvQjtBQUFDaUMsUUFBSSxFQUFFO0FBQUMsT0FBQ0EsSUFBRCxHQUFReVY7QUFBVCxLQUFQO0FBQTRCL08sVUFBTSxFQUFFQTtBQUFwQyxHQUFwQixDQUFQO0FBQ0gsQ0FGRDtBQUlBNEIsZ0JBQWdCLENBQUMsc0JBQUQsRUFBd0I7QUFDcEN2SyxNQUFJLEdBQUc7QUFDSCxXQUFPekYsVUFBVSxDQUFDeUYsSUFBWCxDQUFnQixFQUFoQixDQUFQO0FBQ0gsR0FIbUM7O0FBSXBDd0ssVUFBUSxFQUFFLENBQ047QUFDSXhLLFFBQUksQ0FBQzJYLEdBQUQsRUFBTTtBQUNOLGFBQU9yWixnQkFBZ0IsQ0FBQzBCLElBQWpCLENBQ0g7QUFBRTlFLGVBQU8sRUFBRXljLEdBQUcsQ0FBQ3pjO0FBQWYsT0FERyxFQUVIO0FBQUUrRyxZQUFJLEVBQUU7QUFBQzNCLGdCQUFNLEVBQUU7QUFBVCxTQUFSO0FBQXFCNEIsYUFBSyxFQUFFO0FBQTVCLE9BRkcsQ0FBUDtBQUlIOztBQU5MLEdBRE07QUFKMEIsQ0FBeEIsQ0FBaEI7QUFnQkFoSSxNQUFNLENBQUMyVixPQUFQLENBQWUseUJBQWYsRUFBMEMsWUFBVTtBQUNoRCxTQUFPdFYsVUFBVSxDQUFDeUYsSUFBWCxDQUFnQjtBQUNuQjZCLFVBQU0sRUFBRSxDQURXO0FBRW5CNEYsVUFBTSxFQUFDO0FBRlksR0FBaEIsRUFHTDtBQUNFeEYsUUFBSSxFQUFDO0FBQ0RxRCxrQkFBWSxFQUFDLENBQUM7QUFEYixLQURQO0FBSUVxRCxVQUFNLEVBQUM7QUFDSHpOLGFBQU8sRUFBRSxDQUROO0FBRUhxTSxpQkFBVyxFQUFDLENBRlQ7QUFHSGpDLGtCQUFZLEVBQUMsQ0FIVjtBQUlIa0MsaUJBQVcsRUFBQztBQUpUO0FBSlQsR0FISyxDQUFQO0FBZUgsQ0FoQkQ7QUFrQkErQyxnQkFBZ0IsQ0FBQyxtQkFBRCxFQUFzQixVQUFTclAsT0FBVCxFQUFpQjtBQUNuRCxNQUFJNlgsT0FBTyxHQUFHO0FBQUM3WCxXQUFPLEVBQUNBO0FBQVQsR0FBZDs7QUFDQSxNQUFJQSxPQUFPLENBQUN3RSxPQUFSLENBQWdCeEYsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJpVyxtQkFBdkMsS0FBK0QsQ0FBQyxDQUFwRSxFQUFzRTtBQUNsRXJFLFdBQU8sR0FBRztBQUFDdFcsc0JBQWdCLEVBQUN2QjtBQUFsQixLQUFWO0FBQ0g7O0FBQ0QsU0FBTztBQUNIOEUsUUFBSSxHQUFFO0FBQ0YsYUFBT3pGLFVBQVUsQ0FBQ3lGLElBQVgsQ0FBZ0IrUyxPQUFoQixDQUFQO0FBQ0gsS0FIRTs7QUFJSHZJLFlBQVEsRUFBRSxDQUNOO0FBQ0l4SyxVQUFJLENBQUMyWCxHQUFELEVBQUs7QUFDTCxlQUFPbFosa0JBQWtCLENBQUN1QixJQUFuQixDQUNIO0FBQUM5RSxpQkFBTyxFQUFDeWMsR0FBRyxDQUFDemM7QUFBYixTQURHLEVBRUg7QUFBQytHLGNBQUksRUFBQztBQUFDM0Isa0JBQU0sRUFBQyxDQUFDO0FBQVQsV0FBTjtBQUFtQjRCLGVBQUssRUFBQztBQUF6QixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNLEVBU047QUFDSWxDLFVBQUksQ0FBQzJYLEdBQUQsRUFBTTtBQUNOLGVBQU9yWixnQkFBZ0IsQ0FBQzBCLElBQWpCLENBQ0g7QUFBRTlFLGlCQUFPLEVBQUV5YyxHQUFHLENBQUN6YztBQUFmLFNBREcsRUFFSDtBQUFFK0csY0FBSSxFQUFFO0FBQUMzQixrQkFBTSxFQUFFLENBQUM7QUFBVixXQUFSO0FBQXNCNEIsZUFBSyxFQUFFaEksTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJDO0FBQXBELFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBVE07QUFKUCxHQUFQO0FBdUJILENBNUJlLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDM0NBakgsTUFBTSxDQUFDc1EsTUFBUCxDQUFjO0FBQUNsUSxZQUFVLEVBQUMsTUFBSUE7QUFBaEIsQ0FBZDtBQUEyQyxJQUFJbVEsS0FBSjtBQUFVdlEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDc1EsT0FBSyxDQUFDclEsQ0FBRCxFQUFHO0FBQUNxUSxTQUFLLEdBQUNyUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlpRSxnQkFBSjtBQUFxQm5FLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVCQUFaLEVBQW9DO0FBQUNrRSxrQkFBZ0IsQ0FBQ2pFLENBQUQsRUFBRztBQUFDaUUsb0JBQWdCLEdBQUNqRSxDQUFqQjtBQUFtQjs7QUFBeEMsQ0FBcEMsRUFBOEUsQ0FBOUU7QUFBaUYsSUFBSW9FLGtCQUFKO0FBQXVCdEUsTUFBTSxDQUFDQyxJQUFQLENBQVksNEJBQVosRUFBeUM7QUFBQ3FFLG9CQUFrQixDQUFDcEUsQ0FBRCxFQUFHO0FBQUNvRSxzQkFBa0IsR0FBQ3BFLENBQW5CO0FBQXFCOztBQUE1QyxDQUF6QyxFQUF1RixDQUF2RjtBQUk3TixNQUFNRSxVQUFVLEdBQUcsSUFBSW1RLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixZQUFyQixDQUFuQjtBQUVQcFEsVUFBVSxDQUFDcVEsT0FBWCxDQUFtQjtBQUNmZ04sV0FBUyxHQUFFO0FBQ1AsV0FBT3RaLGdCQUFnQixDQUFDL0IsT0FBakIsQ0FBeUI7QUFBQ3JCLGFBQU8sRUFBQyxLQUFLQTtBQUFkLEtBQXpCLENBQVA7QUFDSCxHQUhjOztBQUlmMmMsU0FBTyxHQUFFO0FBQ0wsV0FBT3BaLGtCQUFrQixDQUFDdUIsSUFBbkIsQ0FBd0I7QUFBQzlFLGFBQU8sRUFBQyxLQUFLQTtBQUFkLEtBQXhCLEVBQWdEO0FBQUMrRyxVQUFJLEVBQUM7QUFBQzNCLGNBQU0sRUFBQyxDQUFDO0FBQVQsT0FBTjtBQUFtQjRCLFdBQUssRUFBQztBQUF6QixLQUFoRCxFQUE4RWhDLEtBQTlFLEVBQVA7QUFDSDs7QUFOYyxDQUFuQixFLENBUUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzQkEvRixNQUFNLENBQUNzUSxNQUFQLENBQWM7QUFBQ2hNLG9CQUFrQixFQUFDLE1BQUlBO0FBQXhCLENBQWQ7QUFBMkQsSUFBSWlNLEtBQUo7QUFBVXZRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3NRLE9BQUssQ0FBQ3JRLENBQUQsRUFBRztBQUFDcVEsU0FBSyxHQUFDclEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUU5RCxNQUFNb0Usa0JBQWtCLEdBQUcsSUFBSWlNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixzQkFBckIsQ0FBM0IsQzs7Ozs7Ozs7Ozs7QUNGUHhRLE1BQU0sQ0FBQ3NRLE1BQVAsQ0FBYztBQUFDOUwsV0FBUyxFQUFDLE1BQUlBO0FBQWYsQ0FBZDtBQUF5QyxJQUFJK0wsS0FBSjtBQUFVdlEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDc1EsT0FBSyxDQUFDclEsQ0FBRCxFQUFHO0FBQUNxUSxTQUFLLEdBQUNyUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRTVDLE1BQU1zRSxTQUFTLEdBQUcsSUFBSStMLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixXQUFyQixDQUFsQixDOzs7Ozs7Ozs7OztBQ0ZQeFEsTUFBTSxDQUFDc1EsTUFBUCxDQUFjO0FBQUNwTSxlQUFhLEVBQUMsTUFBSUE7QUFBbkIsQ0FBZDtBQUFpRCxJQUFJcU0sS0FBSjtBQUFVdlEsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDc1EsT0FBSyxDQUFDclEsQ0FBRCxFQUFHO0FBQUNxUSxTQUFLLEdBQUNyUSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRXBELE1BQU1nRSxhQUFhLEdBQUcsSUFBSXFNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixnQkFBckIsQ0FBdEIsQzs7Ozs7Ozs7Ozs7QUNGUDtBQUNBLHdDOzs7Ozs7Ozs7OztBQ0RBLElBQUl4TSxTQUFKO0FBQWNoRSxNQUFNLENBQUNDLElBQVAsQ0FBWSw0QkFBWixFQUF5QztBQUFDK0QsV0FBUyxDQUFDOUQsQ0FBRCxFQUFHO0FBQUM4RCxhQUFTLEdBQUM5RCxDQUFWO0FBQVk7O0FBQTFCLENBQXpDLEVBQXFFLENBQXJFO0FBQXdFLElBQUlpRSxnQkFBSixFQUFxQkMsU0FBckIsRUFBK0I2VCxpQkFBL0IsRUFBaURDLFlBQWpELEVBQThESixXQUE5RCxFQUEwRUMsb0JBQTFFO0FBQStGL1gsTUFBTSxDQUFDQyxJQUFQLENBQVksOEJBQVosRUFBMkM7QUFBQ2tFLGtCQUFnQixDQUFDakUsQ0FBRCxFQUFHO0FBQUNpRSxvQkFBZ0IsR0FBQ2pFLENBQWpCO0FBQW1CLEdBQXhDOztBQUF5Q2tFLFdBQVMsQ0FBQ2xFLENBQUQsRUFBRztBQUFDa0UsYUFBUyxHQUFDbEUsQ0FBVjtBQUFZLEdBQWxFOztBQUFtRStYLG1CQUFpQixDQUFDL1gsQ0FBRCxFQUFHO0FBQUMrWCxxQkFBaUIsR0FBQy9YLENBQWxCO0FBQW9CLEdBQTVHOztBQUE2R2dZLGNBQVksQ0FBQ2hZLENBQUQsRUFBRztBQUFDZ1ksZ0JBQVksR0FBQ2hZLENBQWI7QUFBZSxHQUE1STs7QUFBNkk0WCxhQUFXLENBQUM1WCxDQUFELEVBQUc7QUFBQzRYLGVBQVcsR0FBQzVYLENBQVo7QUFBYyxHQUExSzs7QUFBMks2WCxzQkFBb0IsQ0FBQzdYLENBQUQsRUFBRztBQUFDNlgsd0JBQW9CLEdBQUM3WCxDQUFyQjtBQUF1Qjs7QUFBMU4sQ0FBM0MsRUFBdVEsQ0FBdlE7QUFBMFEsSUFBSXFFLFlBQUo7QUFBaUJ2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSx3Q0FBWixFQUFxRDtBQUFDc0UsY0FBWSxDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxnQkFBWSxHQUFDckUsQ0FBYjtBQUFlOztBQUFoQyxDQUFyRCxFQUF1RixDQUF2RjtBQUEwRixJQUFJZ0UsYUFBSjtBQUFrQmxFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDRDQUFaLEVBQXlEO0FBQUNpRSxlQUFhLENBQUNoRSxDQUFELEVBQUc7QUFBQ2dFLGlCQUFhLEdBQUNoRSxDQUFkO0FBQWdCOztBQUFsQyxDQUF6RCxFQUE2RixDQUE3RjtBQUFnRyxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUFqRCxFQUErRSxDQUEvRTtBQUFrRixJQUFJb0Usa0JBQUo7QUFBdUJ0RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQ0FBWixFQUFnRDtBQUFDcUUsb0JBQWtCLENBQUNwRSxDQUFELEVBQUc7QUFBQ29FLHNCQUFrQixHQUFDcEUsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQWhELEVBQThGLENBQTlGO0FBQWlHLElBQUlzRSxTQUFKO0FBQWN4RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxrQ0FBWixFQUErQztBQUFDdUUsV0FBUyxDQUFDdEUsQ0FBRCxFQUFHO0FBQUNzRSxhQUFTLEdBQUN0RSxDQUFWO0FBQVk7O0FBQTFCLENBQS9DLEVBQTJFLENBQTNFO0FBQThFLElBQUl1VixTQUFKO0FBQWN6VixNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDd1YsV0FBUyxDQUFDdlYsQ0FBRCxFQUFHO0FBQUN1VixhQUFTLEdBQUN2VixDQUFWO0FBQVk7O0FBQTFCLENBQWpELEVBQTZFLENBQTdFO0FBQWdGLElBQUl5USxXQUFKO0FBQWdCM1EsTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQzBRLGFBQVcsQ0FBQ3pRLENBQUQsRUFBRztBQUFDeVEsZUFBVyxHQUFDelEsQ0FBWjtBQUFjOztBQUE5QixDQUF2QyxFQUF1RSxDQUF2RTtBQVkvakN5USxXQUFXLENBQUNqSyxhQUFaLEdBQTRCaVgsV0FBNUIsQ0FBd0M7QUFBQ3hYLFFBQU0sRUFBRSxDQUFDO0FBQVYsQ0FBeEMsRUFBcUQ7QUFBQ3lYLFFBQU0sRUFBQztBQUFSLENBQXJEO0FBRUE1WixTQUFTLENBQUMwQyxhQUFWLEdBQTBCaVgsV0FBMUIsQ0FBc0M7QUFBQ3hYLFFBQU0sRUFBRSxDQUFDO0FBQVYsQ0FBdEMsRUFBbUQ7QUFBQ3lYLFFBQU0sRUFBQztBQUFSLENBQW5EO0FBQ0E1WixTQUFTLENBQUMwQyxhQUFWLEdBQTBCaVgsV0FBMUIsQ0FBc0M7QUFBQzdYLGlCQUFlLEVBQUM7QUFBakIsQ0FBdEM7QUFFQXRCLFNBQVMsQ0FBQ2tDLGFBQVYsR0FBMEJpWCxXQUExQixDQUFzQztBQUFDeFgsUUFBTSxFQUFFLENBQUM7QUFBVixDQUF0QyxFLENBRUE7O0FBRUFoQyxnQkFBZ0IsQ0FBQ3VDLGFBQWpCLEdBQWlDaVgsV0FBakMsQ0FBNkM7QUFBQzVjLFNBQU8sRUFBQyxDQUFUO0FBQVdvRixRQUFNLEVBQUUsQ0FBQztBQUFwQixDQUE3QyxFQUFxRTtBQUFDeVgsUUFBTSxFQUFDO0FBQVIsQ0FBckU7QUFDQXpaLGdCQUFnQixDQUFDdUMsYUFBakIsR0FBaUNpWCxXQUFqQyxDQUE2QztBQUFDNWMsU0FBTyxFQUFDLENBQVQ7QUFBV21LLFFBQU0sRUFBQyxDQUFsQjtBQUFxQi9FLFFBQU0sRUFBRSxDQUFDO0FBQTlCLENBQTdDO0FBRUEvQixTQUFTLENBQUNzQyxhQUFWLEdBQTBCaVgsV0FBMUIsQ0FBc0M7QUFBQ3hYLFFBQU0sRUFBRSxDQUFDO0FBQVYsQ0FBdEMsRUFBb0Q7QUFBQ3lYLFFBQU0sRUFBQztBQUFSLENBQXBEO0FBRUExRixZQUFZLENBQUN4UixhQUFiLEdBQTZCaVgsV0FBN0IsQ0FBeUM7QUFBQ2pOLFVBQVEsRUFBQyxDQUFWO0FBQWF1SSxPQUFLLEVBQUMsQ0FBbkI7QUFBc0J3QixXQUFTLEVBQUUsQ0FBQztBQUFsQyxDQUF6QztBQUNBdkMsWUFBWSxDQUFDeFIsYUFBYixHQUE2QmlYLFdBQTdCLENBQXlDO0FBQUNqTixVQUFRLEVBQUMsQ0FBVjtBQUFhd0ksYUFBVyxFQUFDLENBQUM7QUFBMUIsQ0FBekM7QUFDQWhCLFlBQVksQ0FBQ3hSLGFBQWIsR0FBNkJpWCxXQUE3QixDQUF5QztBQUFDMUUsT0FBSyxFQUFDLENBQVA7QUFBVUMsYUFBVyxFQUFDLENBQUM7QUFBdkIsQ0FBekM7QUFDQWhCLFlBQVksQ0FBQ3hSLGFBQWIsR0FBNkJpWCxXQUE3QixDQUF5QztBQUFDMUUsT0FBSyxFQUFDLENBQVA7QUFBVXZJLFVBQVEsRUFBQyxDQUFuQjtBQUFzQndJLGFBQVcsRUFBQyxDQUFDO0FBQW5DLENBQXpDLEVBQWdGO0FBQUMwRSxRQUFNLEVBQUM7QUFBUixDQUFoRjtBQUVBM0YsaUJBQWlCLENBQUN2UixhQUFsQixHQUFrQ2lYLFdBQWxDLENBQThDO0FBQUNqTixVQUFRLEVBQUM7QUFBVixDQUE5QztBQUNBdUgsaUJBQWlCLENBQUN2UixhQUFsQixHQUFrQ2lYLFdBQWxDLENBQThDO0FBQUMxRSxPQUFLLEVBQUM7QUFBUCxDQUE5QztBQUNBaEIsaUJBQWlCLENBQUN2UixhQUFsQixHQUFrQ2lYLFdBQWxDLENBQThDO0FBQUNqTixVQUFRLEVBQUMsQ0FBVjtBQUFhdUksT0FBSyxFQUFDO0FBQW5CLENBQTlDLEVBQW9FO0FBQUMyRSxRQUFNLEVBQUM7QUFBUixDQUFwRTtBQUVBOUYsV0FBVyxDQUFDcFIsYUFBWixHQUE0QmlYLFdBQTVCLENBQXdDO0FBQUNuYyxNQUFJLEVBQUMsQ0FBTjtBQUFTMFUsV0FBUyxFQUFDLENBQUM7QUFBcEIsQ0FBeEMsRUFBK0Q7QUFBQzBILFFBQU0sRUFBQztBQUFSLENBQS9EO0FBQ0E3RixvQkFBb0IsQ0FBQ3JSLGFBQXJCLEdBQXFDaVgsV0FBckMsQ0FBaUQ7QUFBQzdYLGlCQUFlLEVBQUMsQ0FBakI7QUFBbUJvUSxXQUFTLEVBQUMsQ0FBQztBQUE5QixDQUFqRCxFQUFrRjtBQUFDMEgsUUFBTSxFQUFDO0FBQVIsQ0FBbEYsRSxDQUNBOztBQUVBclosWUFBWSxDQUFDbUMsYUFBYixHQUE2QmlYLFdBQTdCLENBQXlDO0FBQUNuRyxRQUFNLEVBQUM7QUFBUixDQUF6QyxFQUFvRDtBQUFDb0csUUFBTSxFQUFDO0FBQVIsQ0FBcEQ7QUFDQXJaLFlBQVksQ0FBQ21DLGFBQWIsR0FBNkJpWCxXQUE3QixDQUF5QztBQUFDeFgsUUFBTSxFQUFDLENBQUM7QUFBVCxDQUF6QyxFLENBQ0E7O0FBQ0E1QixZQUFZLENBQUNtQyxhQUFiLEdBQTZCaVgsV0FBN0IsQ0FBeUM7QUFBQywyQkFBd0I7QUFBekIsQ0FBekM7QUFDQXBaLFlBQVksQ0FBQ21DLGFBQWIsR0FBNkJpWCxXQUE3QixDQUF5QztBQUFDLDZCQUEwQjtBQUEzQixDQUF6QztBQUVBelosYUFBYSxDQUFDd0MsYUFBZCxHQUE4QmlYLFdBQTlCLENBQTBDO0FBQUNqVCxjQUFZLEVBQUMsQ0FBQztBQUFmLENBQTFDO0FBRUF0SyxVQUFVLENBQUNzRyxhQUFYLEdBQTJCaVgsV0FBM0IsQ0FBdUM7QUFBQzVjLFNBQU8sRUFBQztBQUFULENBQXZDLEVBQW1EO0FBQUM2YyxRQUFNLEVBQUMsSUFBUjtBQUFjQyx5QkFBdUIsRUFBRTtBQUFFOWMsV0FBTyxFQUFFO0FBQUVpSyxhQUFPLEVBQUU7QUFBWDtBQUFYO0FBQXZDLENBQW5EO0FBQ0E1SyxVQUFVLENBQUNzRyxhQUFYLEdBQTJCaVgsV0FBM0IsQ0FBdUM7QUFBQ3BWLGtCQUFnQixFQUFDO0FBQWxCLENBQXZDLEVBQTREO0FBQUNxVixRQUFNLEVBQUM7QUFBUixDQUE1RDtBQUNBeGQsVUFBVSxDQUFDc0csYUFBWCxHQUEyQmlYLFdBQTNCLENBQXVDO0FBQUMsbUJBQWdCO0FBQWpCLENBQXZDLEVBQTJEO0FBQUNDLFFBQU0sRUFBQyxJQUFSO0FBQWNDLHlCQUF1QixFQUFFO0FBQUUscUJBQWlCO0FBQUU3UyxhQUFPLEVBQUU7QUFBWDtBQUFuQjtBQUF2QyxDQUEzRDtBQUVBMUcsa0JBQWtCLENBQUNvQyxhQUFuQixHQUFtQ2lYLFdBQW5DLENBQStDO0FBQUM1YyxTQUFPLEVBQUMsQ0FBVDtBQUFXb0YsUUFBTSxFQUFDLENBQUM7QUFBbkIsQ0FBL0M7QUFDQTdCLGtCQUFrQixDQUFDb0MsYUFBbkIsR0FBbUNpWCxXQUFuQyxDQUErQztBQUFDbmMsTUFBSSxFQUFDO0FBQU4sQ0FBL0M7QUFFQWlVLFNBQVMsQ0FBQy9PLGFBQVYsR0FBMEJpWCxXQUExQixDQUFzQztBQUFDaEksaUJBQWUsRUFBQyxDQUFDO0FBQWxCLENBQXRDLEVBQTJEO0FBQUNpSSxRQUFNLEVBQUM7QUFBUixDQUEzRCxFOzs7Ozs7Ozs7OztBQ3REQTVkLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVo7QUFBeUJELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG1CQUFaO0FBQWlDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQkFBWjtBQUFtQyxJQUFJNmQsVUFBSjtBQUFlOWQsTUFBTSxDQUFDQyxJQUFQLENBQVksc0JBQVosRUFBbUM7QUFBQzZkLFlBQVUsQ0FBQzVkLENBQUQsRUFBRztBQUFDNGQsY0FBVSxHQUFDNWQsQ0FBWDtBQUFhOztBQUE1QixDQUFuQyxFQUFpRSxDQUFqRTtBQUFvRSxJQUFJNmQsTUFBSjtBQUFXL2QsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDOGQsUUFBTSxDQUFDN2QsQ0FBRCxFQUFHO0FBQUM2ZCxVQUFNLEdBQUM3ZCxDQUFQO0FBQVM7O0FBQXBCLENBQTNCLEVBQWlELENBQWpEO0FBYzNMO0FBRUE0ZCxVQUFVLENBQUNFLElBQUksSUFBSTtBQUNmO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQSxRQUFNQyxNQUFNLEdBQUdGLE1BQU0sQ0FBQ0csWUFBUCxFQUFmO0FBQ0FGLE1BQUksQ0FBQ0csWUFBTCxDQUFrQkYsTUFBTSxDQUFDRyxJQUFQLENBQVlDLFFBQVosRUFBbEI7QUFDQUwsTUFBSSxDQUFDRyxZQUFMLENBQWtCRixNQUFNLENBQUNLLEtBQVAsQ0FBYUQsUUFBYixFQUFsQixFQWRlLENBZ0JmO0FBQ0gsQ0FqQlMsQ0FBVixDOzs7Ozs7Ozs7OztBQ2hCQXJlLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaO0FBQWtERCxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQ0FBWjtBQUFpREQsTUFBTSxDQUFDQyxJQUFQLENBQVksd0NBQVo7QUFBc0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaO0FBQWtERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx5Q0FBWjtBQUF1REQsTUFBTSxDQUFDQyxJQUFQLENBQVksd0NBQVo7QUFBc0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZDQUFaO0FBQTJERCxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQ0FBWjtBQUFtREQsTUFBTSxDQUFDQyxJQUFQLENBQVksMENBQVo7QUFBd0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdDQUFaO0FBQXNERCxNQUFNLENBQUNDLElBQVAsQ0FBWSw2Q0FBWjtBQUEyREQsTUFBTSxDQUFDQyxJQUFQLENBQVksK0NBQVo7QUFBNkRELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBDQUFaO0FBQXdERCxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQ0FBWjtBQUE2REQsTUFBTSxDQUFDQyxJQUFQLENBQVkseUNBQVo7QUFBdURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDhDQUFaO0FBQTRERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx5Q0FBWjtBQUF1REQsTUFBTSxDQUFDQyxJQUFQLENBQVksc0NBQVo7QUFBb0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdDQUFaLEU7Ozs7Ozs7Ozs7O0FDQS85QixJQUFJc2UsTUFBSjtBQUFXdmUsTUFBTSxDQUFDQyxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDK1csU0FBTyxDQUFDOVcsQ0FBRCxFQUFHO0FBQUNxZSxVQUFNLEdBQUNyZSxDQUFQO0FBQVM7O0FBQXJCLENBQXJCLEVBQTRDLENBQTVDO0FBQStDLElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSXlFLE9BQUo7QUFBWTNFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFNBQVosRUFBc0I7QUFBQyxNQUFJQyxDQUFKLEVBQU07QUFBQ3lFLFdBQU8sR0FBQ3pFLENBQVI7QUFBVTs7QUFBbEIsQ0FBdEIsRUFBMEMsQ0FBMUM7O0FBSTlIO0FBQ0EsSUFBSXNlLE1BQU0sR0FBR0MsR0FBRyxDQUFDQyxPQUFKLENBQVksZUFBWixDQUFiLEMsQ0FDQTs7O0FBQ0EsSUFBSUMsSUFBSSxHQUFHRixHQUFHLENBQUNDLE9BQUosQ0FBWSxlQUFaLEVBQTZCQyxJQUF4Qzs7QUFFQSxTQUFTQyxXQUFULENBQXFCQyxTQUFyQixFQUFnQztBQUM1QixTQUFPQSxTQUFTLENBQUM1WSxHQUFWLENBQWMsVUFBUzZZLElBQVQsRUFBZTtBQUNoQyxXQUFPLENBQUMsTUFBTSxDQUFDQSxJQUFJLEdBQUcsSUFBUixFQUFjVCxRQUFkLENBQXVCLEVBQXZCLENBQVAsRUFBbUNVLEtBQW5DLENBQXlDLENBQUMsQ0FBMUMsQ0FBUDtBQUNILEdBRk0sRUFFSkMsSUFGSSxDQUVDLEVBRkQsQ0FBUDtBQUdIOztBQUVEamYsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWG1lLGdCQUFjLEVBQUUsVUFBUzdKLE1BQVQsRUFBaUI4SixNQUFqQixFQUF5QjtBQUNyQztBQUNBLFFBQUlDLGlCQUFpQixHQUFHalYsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUEwQixLQUExQixDQUF4QjtBQUNBLFFBQUlpVixNQUFNLEdBQUdsVixNQUFNLENBQUNtVixLQUFQLENBQWEsRUFBYixDQUFiO0FBQ0FGLHFCQUFpQixDQUFDRyxJQUFsQixDQUF1QkYsTUFBdkIsRUFBK0IsQ0FBL0I7QUFDQWxWLFVBQU0sQ0FBQ0MsSUFBUCxDQUFZaUwsTUFBTSxDQUFDM1QsS0FBbkIsRUFBMEIsUUFBMUIsRUFBb0M2ZCxJQUFwQyxDQUF5Q0YsTUFBekMsRUFBaURELGlCQUFpQixDQUFDcmQsTUFBbkU7QUFDQSxXQUFPeWMsTUFBTSxDQUFDZ0IsTUFBUCxDQUFjTCxNQUFkLEVBQXNCWCxNQUFNLENBQUNpQixPQUFQLENBQWVKLE1BQWYsQ0FBdEIsQ0FBUDtBQUNILEdBUlU7QUFTWEssZ0JBQWMsRUFBRSxVQUFTckssTUFBVCxFQUFpQjtBQUM3QjtBQUNBLFFBQUkrSixpQkFBaUIsR0FBR2pWLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBMEIsS0FBMUIsQ0FBeEI7QUFDQSxRQUFJaVYsTUFBTSxHQUFHbFYsTUFBTSxDQUFDQyxJQUFQLENBQVlvVSxNQUFNLENBQUNtQixTQUFQLENBQWlCbkIsTUFBTSxDQUFDb0IsTUFBUCxDQUFjdkssTUFBZCxFQUFzQndLLEtBQXZDLENBQVosQ0FBYjtBQUNBLFdBQU9SLE1BQU0sQ0FBQ0wsS0FBUCxDQUFhSSxpQkFBaUIsQ0FBQ3JkLE1BQS9CLEVBQXVDdWMsUUFBdkMsQ0FBZ0QsUUFBaEQsQ0FBUDtBQUNILEdBZFU7QUFlWHdCLGNBQVksRUFBRSxVQUFTQyxZQUFULEVBQXNCO0FBQ2hDLFFBQUkvZSxPQUFPLEdBQUd3ZCxNQUFNLENBQUNvQixNQUFQLENBQWNHLFlBQWQsQ0FBZDtBQUNBLFdBQU92QixNQUFNLENBQUNnQixNQUFQLENBQWN4ZixNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmtXLG1CQUFyQyxFQUEwRG5jLE9BQU8sQ0FBQzZlLEtBQWxFLENBQVA7QUFDSCxHQWxCVTtBQW1CWEcsbUJBQWlCLEVBQUUsVUFBU0MsVUFBVCxFQUFvQjtBQUNuQyxRQUFJeGEsUUFBUSxHQUFHckYsSUFBSSxDQUFDSyxHQUFMLENBQVN3ZixVQUFULENBQWY7O0FBQ0EsUUFBSXhhLFFBQVEsQ0FBQzlFLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0IsVUFBSStFLElBQUksR0FBR2QsT0FBTyxDQUFDZSxJQUFSLENBQWFGLFFBQVEsQ0FBQ25FLE9BQXRCLENBQVg7QUFDQSxhQUFPb0UsSUFBSSxDQUFDLG1CQUFELENBQUosQ0FBMEJFLElBQTFCLENBQStCLEtBQS9CLENBQVA7QUFDSDtBQUNKO0FBekJVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNmQTNGLE1BQU0sQ0FBQ3NRLE1BQVAsQ0FBYztBQUFDMlAsYUFBVyxFQUFDLE1BQUlBLFdBQWpCO0FBQTZCQyxvQkFBa0IsRUFBQyxNQUFJQSxrQkFBcEQ7QUFBdUVDLFVBQVEsRUFBQyxNQUFJQSxRQUFwRjtBQUE2RjdDLFFBQU0sRUFBQyxNQUFJQSxNQUF4RztBQUErRzhDLFVBQVEsRUFBQyxNQUFJQTtBQUE1SCxDQUFkO0FBQXFKLElBQUlDLEtBQUo7QUFBVXJnQixNQUFNLENBQUNDLElBQVAsQ0FBWSxPQUFaLEVBQW9CO0FBQUMrVyxTQUFPLENBQUM5VyxDQUFELEVBQUc7QUFBQ21nQixTQUFLLEdBQUNuZ0IsQ0FBTjtBQUFROztBQUFwQixDQUFwQixFQUEwQyxDQUExQztBQUE2QyxJQUFJb2dCLG1CQUFKO0FBQXdCdGdCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ3FnQixxQkFBbUIsQ0FBQ3BnQixDQUFELEVBQUc7QUFBQ29nQix1QkFBbUIsR0FBQ3BnQixDQUFwQjtBQUFzQjs7QUFBOUMsQ0FBekIsRUFBeUUsQ0FBekU7O0FBRzdOLE1BQU0rZixXQUFXLEdBQUlNLEtBQUQsSUFBVztBQUNsQyxVQUFRQSxLQUFLLENBQUN2TixLQUFkO0FBQ0EsU0FBSyxPQUFMO0FBQ0ksYUFBTyxJQUFQOztBQUNKO0FBQ0ksYUFBTyxJQUFQO0FBSko7QUFNSCxDQVBNOztBQVVBLE1BQU1rTixrQkFBa0IsR0FBSUssS0FBRCxJQUFXO0FBQ3pDLFVBQVFBLEtBQUssQ0FBQzdZLE1BQWQ7QUFDQSxTQUFLLFFBQUw7QUFDSSxhQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxVQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssU0FBTDtBQUNJLGFBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSixTQUFLLGVBQUw7QUFDSSxhQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxjQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKO0FBQ0ksYUFBTyw4QkFBUDtBQVpKO0FBY0gsQ0FmTTs7QUFpQkEsTUFBTXlZLFFBQVEsR0FBSUksS0FBRCxJQUFXO0FBQy9CLFVBQVFBLEtBQUssQ0FBQ0MsSUFBZDtBQUNBLFNBQUssS0FBTDtBQUNJLGFBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSixTQUFLLElBQUw7QUFDSSxhQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxTQUFMO0FBQ0ksYUFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssY0FBTDtBQUNJLGFBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSjtBQUNJLGFBQU8sOEJBQVA7QUFWSjtBQVlILENBYk07O0FBZUEsTUFBTWxELE1BQU0sR0FBSWlELEtBQUQsSUFBVztBQUM3QixNQUFJQSxLQUFLLENBQUNFLEtBQVYsRUFBZ0I7QUFDWixXQUFPO0FBQU0sZUFBUyxFQUFDO0FBQWhCLE9BQTJDO0FBQUcsZUFBUyxFQUFDO0FBQWIsTUFBM0MsQ0FBUDtBQUNILEdBRkQsTUFHSTtBQUNBLFdBQU87QUFBTSxlQUFTLEVBQUM7QUFBaEIsT0FBMEM7QUFBRyxlQUFTLEVBQUM7QUFBYixNQUExQyxDQUFQO0FBQ0g7QUFDSixDQVBNOztBQVNBLE1BQU1MLFFBQU4sU0FBdUJDLEtBQUssQ0FBQ0ssU0FBN0IsQ0FBdUM7QUFDMUNDLGFBQVcsQ0FBQ0osS0FBRCxFQUFRO0FBQ2YsVUFBTUEsS0FBTjtBQUNBLFNBQUtLLEdBQUwsR0FBV1AsS0FBSyxDQUFDUSxTQUFOLEVBQVg7QUFDSDs7QUFFREMsUUFBTSxHQUFHO0FBQ0wsV0FBTyxDQUNIO0FBQUcsU0FBRyxFQUFDLE1BQVA7QUFBYyxlQUFTLEVBQUMsMEJBQXhCO0FBQW1ELFNBQUcsRUFBRSxLQUFLRjtBQUE3RCxjQURHLEVBRUgsb0JBQUMsbUJBQUQ7QUFBcUIsU0FBRyxFQUFDLFNBQXpCO0FBQW1DLGVBQVMsRUFBQyxPQUE3QztBQUFxRCxZQUFNLEVBQUUsS0FBS0E7QUFBbEUsT0FDSyxLQUFLTCxLQUFMLENBQVdsUSxRQUFYLEdBQW9CLEtBQUtrUSxLQUFMLENBQVdsUSxRQUEvQixHQUF3QyxLQUFLa1EsS0FBTCxDQUFXUSxXQUR4RCxDQUZHLENBQVA7QUFNSDs7QUFieUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0RDlDL2dCLE1BQU0sQ0FBQ3NRLE1BQVAsQ0FBYztBQUFDMEcsU0FBTyxFQUFDLE1BQUlnSztBQUFiLENBQWQ7QUFBa0MsSUFBSWpoQixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUkrZ0IsTUFBSjtBQUFXamhCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQytXLFNBQU8sQ0FBQzlXLENBQUQsRUFBRztBQUFDK2dCLFVBQU0sR0FBQy9nQixDQUFQO0FBQVM7O0FBQXJCLENBQXJCLEVBQTRDLENBQTVDOztBQUc3R2doQixVQUFVLEdBQUl6ZixLQUFELElBQVc7QUFDdkIsTUFBSTBmLFNBQVMsR0FBRyxVQUFoQjtBQUNBMWYsT0FBSyxHQUFHMkssSUFBSSxDQUFDNkUsS0FBTCxDQUFXeFAsS0FBSyxHQUFHLElBQW5CLElBQTJCLElBQW5DO0FBQ0EsTUFBSTJLLElBQUksQ0FBQzZFLEtBQUwsQ0FBV3hQLEtBQVgsTUFBc0JBLEtBQTFCLEVBQ0MwZixTQUFTLEdBQUcsS0FBWixDQURELEtBRUssSUFBSS9VLElBQUksQ0FBQzZFLEtBQUwsQ0FBV3hQLEtBQUssR0FBQyxFQUFqQixNQUF5QkEsS0FBSyxHQUFDLEVBQW5DLEVBQ0owZixTQUFTLEdBQUcsT0FBWixDQURJLEtBRUEsSUFBSS9VLElBQUksQ0FBQzZFLEtBQUwsQ0FBV3hQLEtBQUssR0FBQyxHQUFqQixNQUEwQkEsS0FBSyxHQUFDLEdBQXBDLEVBQ0owZixTQUFTLEdBQUcsUUFBWixDQURJLEtBRUEsSUFBSS9VLElBQUksQ0FBQzZFLEtBQUwsQ0FBV3hQLEtBQUssR0FBQyxJQUFqQixNQUEyQkEsS0FBSyxHQUFDLElBQXJDLEVBQ0owZixTQUFTLEdBQUcsU0FBWjtBQUNELFNBQU9GLE1BQU0sQ0FBQ3hmLEtBQUQsQ0FBTixDQUFjMmYsTUFBZCxDQUFxQkQsU0FBckIsQ0FBUDtBQUNBLENBWkQ7O0FBY2UsTUFBTUgsSUFBTixDQUFXO0FBT3pCTCxhQUFXLENBQUM1TixNQUFELEVBQXFCO0FBQUEsUUFBWkMsS0FBWSx1RUFBTixJQUFNO0FBQy9CLFFBQUksT0FBT0QsTUFBUCxLQUFrQixRQUF0QixFQUNDLENBQUM7QUFBQ0EsWUFBRDtBQUFTQztBQUFULFFBQWtCRCxNQUFuQjs7QUFDRCxRQUFJLENBQUNDLEtBQUQsSUFBVUEsS0FBSyxDQUFDcU8sV0FBTixPQUF3QkwsSUFBSSxDQUFDTSxZQUFMLENBQWtCRCxXQUFsQixFQUF0QyxFQUF1RTtBQUN0RSxXQUFLRSxPQUFMLEdBQWV6SyxNQUFNLENBQUMvRCxNQUFELENBQXJCO0FBQ0EsS0FGRCxNQUVPLElBQUlDLEtBQUssQ0FBQ3FPLFdBQU4sT0FBd0JMLElBQUksQ0FBQ1EsWUFBTCxDQUFrQkgsV0FBbEIsRUFBNUIsRUFBNkQ7QUFDbkUsV0FBS0UsT0FBTCxHQUFlekssTUFBTSxDQUFDL0QsTUFBRCxDQUFOLEdBQWlCaU8sSUFBSSxDQUFDUyxlQUFyQztBQUNBLEtBRk0sTUFHRjtBQUNKLFlBQU1wSyxLQUFLLDZCQUFzQnJFLEtBQXRCLEVBQVg7QUFDQTtBQUNEOztBQUVELE1BQUlELE1BQUosR0FBYztBQUNiLFdBQU8sS0FBS3dPLE9BQVo7QUFDQTs7QUFFRCxNQUFJRyxhQUFKLEdBQXFCO0FBQ3BCLFdBQU8sS0FBS0gsT0FBTCxHQUFlUCxJQUFJLENBQUNTLGVBQTNCO0FBQ0E7O0FBRURwRCxVQUFRLENBQUVzRCxTQUFGLEVBQWE7QUFDcEI7QUFDQSxRQUFJQyxRQUFRLEdBQUdaLElBQUksQ0FBQ1MsZUFBTCxJQUFzQkUsU0FBUyxHQUFDdlYsSUFBSSxDQUFDeVYsR0FBTCxDQUFTLEVBQVQsRUFBYUYsU0FBYixDQUFELEdBQXlCLEtBQXhELENBQWY7O0FBQ0EsUUFBSSxLQUFLNU8sTUFBTCxHQUFjNk8sUUFBbEIsRUFBNEI7QUFDM0IsdUJBQVVYLE1BQU0sQ0FBQyxLQUFLbE8sTUFBTixDQUFOLENBQW9CcU8sTUFBcEIsQ0FBMkIsS0FBM0IsQ0FBVixjQUErQ0osSUFBSSxDQUFDTSxZQUFwRDtBQUNBLEtBRkQsTUFFTztBQUNOLHVCQUFVSyxTQUFTLEdBQUNWLE1BQU0sQ0FBQyxLQUFLUyxhQUFOLENBQU4sQ0FBMkJOLE1BQTNCLENBQWtDLFNBQVMsSUFBSVUsTUFBSixDQUFXSCxTQUFYLENBQTNDLENBQUQsR0FBbUVULFVBQVUsQ0FBQyxLQUFLUSxhQUFOLENBQWhHLGNBQXdIVixJQUFJLENBQUNRLFlBQTdIO0FBQ0E7QUFDRDs7QUFFRE8sWUFBVSxDQUFFWixTQUFGLEVBQWE7QUFDdEIsUUFBSXBPLE1BQU0sR0FBRyxLQUFLQSxNQUFsQjs7QUFDQSxRQUFJb08sU0FBSixFQUFlO0FBQ2RwTyxZQUFNLEdBQUdrTyxNQUFNLENBQUNsTyxNQUFELENBQU4sQ0FBZXFPLE1BQWYsQ0FBc0JELFNBQXRCLENBQVQ7QUFDQTs7QUFDRCxxQkFBVXBPLE1BQVYsY0FBb0JpTyxJQUFJLENBQUNNLFlBQXpCO0FBQ0E7O0FBRURVLGFBQVcsQ0FBRWIsU0FBRixFQUFhO0FBQ3ZCLFFBQUlwTyxNQUFNLEdBQUcsS0FBSzJPLGFBQWxCOztBQUNBLFFBQUlQLFNBQUosRUFBZTtBQUNkcE8sWUFBTSxHQUFHa08sTUFBTSxDQUFDbE8sTUFBRCxDQUFOLENBQWVxTyxNQUFmLENBQXNCRCxTQUF0QixDQUFUO0FBQ0E7O0FBQ0QscUJBQVVwTyxNQUFWLGNBQW9CaU8sSUFBSSxDQUFDUSxZQUF6QjtBQUNBOztBQXBEd0I7O0FBQUxSLEksQ0FDYlEsWSxHQUFlemhCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCaWIsWTtBQUR6QmpCLEksQ0FFYmtCLGtCLEdBQXFCbmlCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCbWIsa0JBQXZCLElBQThDbkIsSUFBSSxDQUFDUSxZQUFMLEdBQW9CLEc7QUFGMUVSLEksQ0FHYk0sWSxHQUFldmhCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCMEwsWTtBQUh6QnNPLEksQ0FJYlMsZSxHQUFrQjNLLE1BQU0sQ0FBQy9XLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCc08sZUFBeEIsQztBQUpYMEwsSSxDQUtib0IsUSxHQUFXLElBQUl0TCxNQUFNLENBQUMvVyxNQUFNLENBQUNnSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QnNPLGVBQXhCLEM7Ozs7Ozs7Ozs7O0FDdEI3QnRWLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHlCQUFaO0FBQXVDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSx1QkFBWjtBQUl2QztBQUNBO0FBRUFpSSxPQUFPLEdBQUcsS0FBVjtBQUNBc1IsaUJBQWlCLEdBQUcsS0FBcEI7QUFDQThCLHNCQUFzQixHQUFHLEtBQXpCO0FBQ0E3VCxHQUFHLEdBQUcxSCxNQUFNLENBQUNnSCxRQUFQLENBQWdCc2IsTUFBaEIsQ0FBdUJDLEdBQTdCO0FBQ0E3aEIsR0FBRyxHQUFHVixNQUFNLENBQUNnSCxRQUFQLENBQWdCc2IsTUFBaEIsQ0FBdUJFLEdBQTdCO0FBQ0FDLFdBQVcsR0FBRyxDQUFkO0FBQ0FDLFVBQVUsR0FBRyxDQUFiO0FBQ0FDLGNBQWMsR0FBRyxDQUFqQjtBQUNBQyxhQUFhLEdBQUcsQ0FBaEI7QUFDQUMscUJBQXFCLEdBQUcsQ0FBeEI7QUFDQUMsZ0JBQWdCLEdBQUcsQ0FBbkI7QUFDQUMsZUFBZSxHQUFHLENBQWxCO0FBQ0FDLGNBQWMsR0FBRyxDQUFqQjtBQUVBLE1BQU1DLGVBQWUsR0FBRyx3QkFBeEI7O0FBRUFDLGlCQUFpQixHQUFHLE1BQU07QUFDdEJsakIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLG9CQUFaLEVBQWtDLENBQUM4YSxLQUFELEVBQVE1aEIsTUFBUixLQUFtQjtBQUNqRCxRQUFJNGhCLEtBQUosRUFBVTtBQUNOdGlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFpQnFpQixLQUE3QjtBQUNILEtBRkQsTUFHSTtBQUNBdGlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFpQlMsTUFBN0I7QUFDSDtBQUNKLEdBUEQ7QUFRSCxDQVREOztBQVdBNmhCLFdBQVcsR0FBRyxNQUFNO0FBQ2hCcGpCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSxxQkFBWixFQUFtQyxDQUFDOGEsS0FBRCxFQUFRNWhCLE1BQVIsS0FBbUI7QUFDbEQsUUFBSTRoQixLQUFKLEVBQVU7QUFDTnRpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxtQkFBaUJxaUIsS0FBN0I7QUFDSCxLQUZELE1BR0k7QUFDQXRpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxtQkFBaUJTLE1BQTdCO0FBQ0g7QUFDSixHQVBEO0FBUUgsQ0FURDs7QUFXQThoQixpQkFBaUIsR0FBRyxNQUFNO0FBQ3RCcmpCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSx5QkFBWixFQUF1QyxDQUFDOGEsS0FBRCxFQUFRNWhCLE1BQVIsS0FBbUI7QUFDdEQsUUFBSTRoQixLQUFKLEVBQVU7QUFDTnRpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxvQkFBa0JxaUIsS0FBOUI7QUFDSDtBQUNKLEdBSkQ7QUFLSCxDQU5EOztBQVFBRyxpQkFBaUIsR0FBRyxNQUFNO0FBQ3ZCdGpCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSw4QkFBWixFQUE0QyxDQUFDOGEsS0FBRCxFQUFRNWhCLE1BQVIsS0FBbUI7QUFDM0QsUUFBSTRoQixLQUFKLEVBQVU7QUFDTnRpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxhQUFZcWlCLEtBQXhCO0FBQ0g7O0FBQ0QsUUFBSTVoQixNQUFKLEVBQVc7QUFDUFYsYUFBTyxDQUFDQyxHQUFSLENBQVksYUFBV1MsTUFBdkI7QUFDSDtBQUNKLEdBUEQ7QUFRRixDQVRELEMsQ0FXQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUVBZ2lCLGtCQUFrQixHQUFHLE1BQU07QUFDdkJ2akIsUUFBTSxDQUFDcUksSUFBUCxDQUFZLHdDQUFaLEVBQXNELENBQUM4YSxLQUFELEVBQVE1aEIsTUFBUixLQUFrQjtBQUNwRSxRQUFJNGhCLEtBQUosRUFBVTtBQUNOdGlCLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDBCQUF5QnFpQixLQUFyQztBQUNIOztBQUNELFFBQUk1aEIsTUFBSixFQUFXO0FBQ1BWLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFzQlMsTUFBbEM7QUFDSDtBQUNKLEdBUEQ7QUFRSjs7Ozs7Ozs7OztBQVVDLENBbkJEOztBQXFCQWlpQixjQUFjLEdBQUcsTUFBTTtBQUNuQnhqQixRQUFNLENBQUNxSSxJQUFQLENBQVksNEJBQVosRUFBMEMsQ0FBQzhhLEtBQUQsRUFBUTVoQixNQUFSLEtBQW1CO0FBQ3pELFFBQUk0aEIsS0FBSixFQUFVO0FBQ050aUIsYUFBTyxDQUFDQyxHQUFSLENBQVksNEJBQTJCcWlCLEtBQXZDO0FBQ0gsS0FGRCxNQUdJO0FBQ0F0aUIsYUFBTyxDQUFDQyxHQUFSLENBQVkseUJBQXdCUyxNQUFwQztBQUNIO0FBQ0osR0FQRDtBQVFILENBVEQ7O0FBV0FraUIsaUJBQWlCLEdBQUcsTUFBSztBQUNyQjtBQUNBempCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSw0Q0FBWixFQUEwRCxHQUExRCxFQUErRCxDQUFDOGEsS0FBRCxFQUFRNWhCLE1BQVIsS0FBbUI7QUFDOUUsUUFBSTRoQixLQUFKLEVBQVU7QUFDTnRpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSwwQ0FBd0NxaUIsS0FBcEQ7QUFDSCxLQUZELE1BR0k7QUFDQXRpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx1Q0FBcUNTLE1BQWpEO0FBQ0g7QUFDSixHQVBEO0FBU0F2QixRQUFNLENBQUNxSSxJQUFQLENBQVksd0JBQVosRUFBc0MsQ0FBQzhhLEtBQUQsRUFBUTVoQixNQUFSLEtBQW1CO0FBQ3JELFFBQUk0aEIsS0FBSixFQUFVO0FBQ050aUIsYUFBTyxDQUFDQyxHQUFSLENBQVksMkJBQXlCcWlCLEtBQXJDO0FBQ0gsS0FGRCxNQUdJO0FBQ0F0aUIsYUFBTyxDQUFDQyxHQUFSLENBQVksd0JBQXNCUyxNQUFsQztBQUNIO0FBQ0osR0FQRDtBQVFILENBbkJEOztBQXFCQW1pQixlQUFlLEdBQUcsTUFBSztBQUNuQjtBQUNBMWpCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSw0Q0FBWixFQUEwRCxHQUExRCxFQUErRCxDQUFDOGEsS0FBRCxFQUFRNWhCLE1BQVIsS0FBbUI7QUFDOUUsUUFBSTRoQixLQUFKLEVBQVU7QUFDTnRpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx3Q0FBc0NxaUIsS0FBbEQ7QUFDSCxLQUZELE1BR0k7QUFDQXRpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxxQ0FBbUNTLE1BQS9DO0FBQ0g7QUFDSixHQVBEO0FBUUgsQ0FWRDs7QUFZQW9pQixjQUFjLEdBQUcsTUFBSztBQUNsQjtBQUNBM2pCLFFBQU0sQ0FBQ3FJLElBQVAsQ0FBWSw0Q0FBWixFQUEwRCxHQUExRCxFQUErRCxDQUFDOGEsS0FBRCxFQUFRNWhCLE1BQVIsS0FBbUI7QUFDOUUsUUFBSTRoQixLQUFKLEVBQVU7QUFDTnRpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSx1Q0FBcUNxaUIsS0FBakQ7QUFDSCxLQUZELE1BR0k7QUFDQXRpQixhQUFPLENBQUNDLEdBQVIsQ0FBWSxvQ0FBa0NTLE1BQTlDO0FBQ0g7QUFDSixHQVBEO0FBU0F2QixRQUFNLENBQUNxSSxJQUFQLENBQVksNENBQVosRUFBMEQsQ0FBQzhhLEtBQUQsRUFBUTVoQixNQUFSLEtBQW1CO0FBQ3pFLFFBQUk0aEIsS0FBSixFQUFVO0FBQ050aUIsYUFBTyxDQUFDQyxHQUFSLENBQVksMkNBQTBDcWlCLEtBQXREO0FBQ0gsS0FGRCxNQUdLO0FBQ0R0aUIsYUFBTyxDQUFDQyxHQUFSLENBQVksd0NBQXVDUyxNQUFuRDtBQUNIO0FBQ0osR0FQRDtBQVFILENBbkJEOztBQXVCQXZCLE1BQU0sQ0FBQzRqQixPQUFQLENBQWUsWUFBVTtBQUNyQixNQUFJNWpCLE1BQU0sQ0FBQzZqQixhQUFYLEVBQXlCO0FBL0s3QixRQUFJQyxtQkFBSjtBQUF3QjdqQixVQUFNLENBQUNDLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDK1csYUFBTyxDQUFDOVcsQ0FBRCxFQUFHO0FBQUMyakIsMkJBQW1CLEdBQUMzakIsQ0FBcEI7QUFBc0I7O0FBQWxDLEtBQXZDLEVBQTJFLENBQTNFO0FBZ0xoQjRqQixXQUFPLENBQUNDLEdBQVIsQ0FBWUMsNEJBQVosR0FBMkMsQ0FBM0M7QUFFQXZiLFVBQU0sQ0FBQ0MsSUFBUCxDQUFZbWIsbUJBQVosRUFBaUM5Z0IsT0FBakMsQ0FBMENraEIsR0FBRCxJQUFTO0FBQzlDLFVBQUlsa0IsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtkLEdBQWhCLEtBQXdCdlYsU0FBNUIsRUFBdUM7QUFDbkM5TixlQUFPLENBQUNzakIsSUFBUixnQ0FBcUNELEdBQXJDO0FBQ0Fsa0IsY0FBTSxDQUFDZ0gsUUFBUCxDQUFnQmtkLEdBQWhCLElBQXVCLEVBQXZCO0FBQ0g7O0FBQ0R4YixZQUFNLENBQUNDLElBQVAsQ0FBWW1iLG1CQUFtQixDQUFDSSxHQUFELENBQS9CLEVBQXNDbGhCLE9BQXRDLENBQStDb2hCLEtBQUQsSUFBVztBQUNyRCxZQUFJcGtCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrZCxHQUFoQixFQUFxQkUsS0FBckIsS0FBK0J6VixTQUFuQyxFQUE2QztBQUN6QzlOLGlCQUFPLENBQUNzakIsSUFBUixnQ0FBcUNELEdBQXJDLGNBQTRDRSxLQUE1QztBQUNBcGtCLGdCQUFNLENBQUNnSCxRQUFQLENBQWdCa2QsR0FBaEIsRUFBcUJFLEtBQXJCLElBQThCTixtQkFBbUIsQ0FBQ0ksR0FBRCxDQUFuQixDQUF5QkUsS0FBekIsQ0FBOUI7QUFDSDtBQUNKLE9BTEQ7QUFNSCxLQVhEO0FBWUg7O0FBRURwa0IsUUFBTSxDQUFDcUksSUFBUCxDQUFZLGVBQVosRUFBNkIsQ0FBQ2dDLEdBQUQsRUFBTTlJLE1BQU4sS0FBaUI7QUFDMUMsUUFBSThJLEdBQUosRUFBUTtBQUNKeEosYUFBTyxDQUFDQyxHQUFSLENBQVl1SixHQUFaO0FBQ0g7O0FBQ0QsUUFBSTlJLE1BQUosRUFBVztBQUNQLFVBQUl2QixNQUFNLENBQUNnSCxRQUFQLENBQWdCdU0sS0FBaEIsQ0FBc0I4USxVQUExQixFQUFxQztBQUNqQzFCLHNCQUFjLEdBQUczaUIsTUFBTSxDQUFDc2tCLFdBQVAsQ0FBbUIsWUFBVTtBQUMxQ2pCLDJCQUFpQjtBQUNwQixTQUZnQixFQUVkcmpCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QnFjLGlCQUZULENBQWpCO0FBSUE5QixtQkFBVyxHQUFHemlCLE1BQU0sQ0FBQ3NrQixXQUFQLENBQW1CLFlBQVU7QUFDdkNsQixxQkFBVztBQUNkLFNBRmEsRUFFWHBqQixNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUJzYyxhQUZaLENBQWQ7QUFJQTlCLGtCQUFVLEdBQUcxaUIsTUFBTSxDQUFDc2tCLFdBQVAsQ0FBbUIsWUFBVTtBQUN0Q3BCLDJCQUFpQjtBQUNwQixTQUZZLEVBRVZsakIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCdWMsY0FGYixDQUFiO0FBSUFDLDBCQUFrQixHQUFHMWtCLE1BQU0sQ0FBQ3NrQixXQUFQLENBQW9CLFlBQVc7QUFDaERoQiwyQkFBaUI7QUFDcEIsU0FGb0IsRUFFbEJ0akIsTUFBTSxDQUFDZ0gsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCeWMsZ0JBRkwsQ0FBckIsQ0FiaUMsQ0FpQmpEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVnQjdCLHdCQUFnQixHQUFHOWlCLE1BQU0sQ0FBQ3NrQixXQUFQLENBQW1CLFlBQVU7QUFDNUNmLDRCQUFrQjtBQUNyQixTQUZrQixFQUVoQnZqQixNQUFNLENBQUNnSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUIwYyxvQkFGUCxDQUFuQjtBQUlBN0IsdUJBQWUsR0FBRy9pQixNQUFNLENBQUNza0IsV0FBUCxDQUFtQixZQUFVO0FBQzNDZCx3QkFBYztBQUNqQixTQUZpQixFQUVmeGpCLE1BQU0sQ0FBQ2dILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QjJjLGtCQUZSLENBQWxCO0FBSUE3QixzQkFBYyxHQUFHaGpCLE1BQU0sQ0FBQ3NrQixXQUFQLENBQW1CLFlBQVU7QUFDMUMsY0FBSXZPLEdBQUcsR0FBRyxJQUFJM1MsSUFBSixFQUFWOztBQUNBLGNBQUsyUyxHQUFHLENBQUMrTyxhQUFKLE1BQXVCLENBQTVCLEVBQStCO0FBQzNCckIsNkJBQWlCO0FBQ3BCOztBQUVELGNBQUsxTixHQUFHLENBQUNnUCxhQUFKLE1BQXVCLENBQXhCLElBQStCaFAsR0FBRyxDQUFDK08sYUFBSixNQUF1QixDQUExRCxFQUE2RDtBQUN6RHBCLDJCQUFlO0FBQ2xCOztBQUVELGNBQUszTixHQUFHLENBQUNpUCxXQUFKLE1BQXFCLENBQXRCLElBQTZCalAsR0FBRyxDQUFDZ1AsYUFBSixNQUF1QixDQUFwRCxJQUEyRGhQLEdBQUcsQ0FBQytPLGFBQUosTUFBdUIsQ0FBdEYsRUFBeUY7QUFDckZuQiwwQkFBYztBQUNqQjtBQUNKLFNBYmdCLEVBYWQsSUFiYyxDQUFqQjtBQWNIO0FBQ0o7QUFDSixHQXRERDtBQXdESCxDQTFFRCxFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5jb25zdCBmZXRjaEZyb21VcmwgPSAodXJsKSA9PiB7XG4gICAgdHJ5e1xuICAgICAgICBsZXQgcmVzID0gSFRUUC5nZXQoTENEICsgdXJsKTtcbiAgICAgICAgaWYgKHJlcy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICByZXR1cm4gcmVzXG4gICAgICAgIH07XG4gICAgfVxuICAgIGNhdGNoIChlKXtcbiAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgfVxufVxuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ2FjY291bnRzLmdldEFjY291bnREZXRhaWwnOiBmdW5jdGlvbihhZGRyZXNzKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL2F1dGgvYWNjb3VudHMvJysgYWRkcmVzcztcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IGF2YWlsYWJsZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBpZiAoYXZhaWxhYmxlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBKU09OLnBhcnNlKGF2YWlsYWJsZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgbGV0IGFjY291bnQ7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnR5cGUgPT09ICdjb3Ntb3Mtc2RrL0FjY291bnQnKVxuICAgICAgICAgICAgICAgICAgICBhY2NvdW50ID0gcmVzcG9uc2UudmFsdWU7XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAocmVzcG9uc2UudHlwZSA9PT0gJ2Nvc21vcy1zZGsvRGVsYXllZFZlc3RpbmdBY2NvdW50JyB8fCByZXNwb25zZS50eXBlID09PSAnY29zbW9zLXNkay9Db250aW51b3VzVmVzdGluZ0FjY291bnQnKVxuICAgICAgICAgICAgICAgICAgICBhY2NvdW50ID0gcmVzcG9uc2UudmFsdWUuQmFzZVZlc3RpbmdBY2NvdW50LkJhc2VBY2NvdW50XG4gICAgICAgICAgICAgICAgaWYgKGFjY291bnQgJiYgYWNjb3VudC5hY2NvdW50X251bWJlciAhPSBudWxsKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYWNjb3VudFxuICAgICAgICAgICAgICAgIHJldHVybiBudWxsXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ2FjY291bnRzLmdldEJhbGFuY2UnOiBmdW5jdGlvbihhZGRyZXNzKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCBiYWxhbmNlID0ge31cblxuICAgICAgICAvLyBnZXQgYXZhaWxhYmxlIGF0b21zXG4gICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL2JhbmsvYmFsYW5jZXMvJysgYWRkcmVzcztcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IGF2YWlsYWJsZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBpZiAoYXZhaWxhYmxlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhKU09OLnBhcnNlKGF2YWlsYWJsZS5jb250ZW50KSlcbiAgICAgICAgICAgICAgICBiYWxhbmNlLmF2YWlsYWJsZSA9IEpTT04ucGFyc2UoYXZhaWxhYmxlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICBpZiAoYmFsYW5jZS5hdmFpbGFibGUgJiYgYmFsYW5jZS5hdmFpbGFibGUubGVuZ3RoID4gMClcbiAgICAgICAgICAgICAgICAgICAgYmFsYW5jZS5hdmFpbGFibGUgPSBiYWxhbmNlLmF2YWlsYWJsZVswXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gZ2V0IGRlbGVnYXRlZCBhbW5vdW50c1xuICAgICAgICB1cmwgPSBMQ0QgKyAnL3N0YWtpbmcvZGVsZWdhdG9ycy8nK2FkZHJlc3MrJy9kZWxlZ2F0aW9ucyc7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCBkZWxlZ2F0aW9ucyA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBpZiAoZGVsZWdhdGlvbnMuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIGJhbGFuY2UuZGVsZWdhdGlvbnMgPSBKU09OLnBhcnNlKGRlbGVnYXRpb25zLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBnZXQgdW5ib25kaW5nXG4gICAgICAgIHVybCA9IExDRCArICcvc3Rha2luZy9kZWxlZ2F0b3JzLycrYWRkcmVzcysnL3VuYm9uZGluZ19kZWxlZ2F0aW9ucyc7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCB1bmJvbmRpbmcgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKHVuYm9uZGluZy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgYmFsYW5jZS51bmJvbmRpbmcgPSBKU09OLnBhcnNlKHVuYm9uZGluZy5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBnZXQgcmV3YXJkc1xuICAgICAgICB1cmwgPSBMQ0QgKyAnL2Rpc3RyaWJ1dGlvbi9kZWxlZ2F0b3JzLycrYWRkcmVzcysnL3Jld2FyZHMnO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgcmV3YXJkcyA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBpZiAocmV3YXJkcy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgYmFsYW5jZS5yZXdhcmRzID0gSlNPTi5wYXJzZShyZXdhcmRzLmNvbnRlbnQpLnJlc3VsdC50b3RhbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGdldCBjb21taXNzaW9uXG4gICAgICAgIGxldCB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUoXG4gICAgICAgICAgICB7JG9yOiBbe29wZXJhdG9yX2FkZHJlc3M6YWRkcmVzc30sIHtkZWxlZ2F0b3JfYWRkcmVzczphZGRyZXNzfSwge2FkZHJlc3M6YWRkcmVzc31dfSlcbiAgICAgICAgaWYgKHZhbGlkYXRvcikge1xuICAgICAgICAgICAgbGV0IHVybCA9IExDRCArICcvZGlzdHJpYnV0aW9uL3ZhbGlkYXRvcnMvJyArIHZhbGlkYXRvci5vcGVyYXRvcl9hZGRyZXNzO1xuICAgICAgICAgICAgYmFsYW5jZS5vcGVyYXRvcl9hZGRyZXNzID0gdmFsaWRhdG9yLm9wZXJhdG9yX2FkZHJlc3M7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGxldCByZXdhcmRzID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICBpZiAocmV3YXJkcy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgICAgIGxldCBjb250ZW50ID0gSlNPTi5wYXJzZShyZXdhcmRzLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvbnRlbnQudmFsX2NvbW1pc3Npb24gJiYgY29udGVudC52YWxfY29tbWlzc2lvbi5sZW5ndGggPiAwKVxuICAgICAgICAgICAgICAgICAgICAgICAgYmFsYW5jZS5jb21taXNzaW9uID0gY29udGVudC52YWxfY29tbWlzc2lvblswXTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGJhbGFuY2U7XG4gICAgfSxcbiAgICAnYWNjb3VudHMuZ2V0RGVsZWdhdGlvbicoYWRkcmVzcywgdmFsaWRhdG9yKXtcbiAgICAgICAgbGV0IHVybCA9IGAvc3Rha2luZy9kZWxlZ2F0b3JzLyR7YWRkcmVzc30vZGVsZWdhdGlvbnMvJHt2YWxpZGF0b3J9YDtcbiAgICAgICAgbGV0IGRlbGVnYXRpb25zID0gZmV0Y2hGcm9tVXJsKHVybCk7XG4gICAgICAgIGRlbGVnYXRpb25zID0gZGVsZWdhdGlvbnMgJiYgZGVsZWdhdGlvbnMuZGF0YS5yZXN1bHQ7XG4gICAgICAgIGlmIChkZWxlZ2F0aW9ucyAmJiBkZWxlZ2F0aW9ucy5zaGFyZXMpXG4gICAgICAgICAgICBkZWxlZ2F0aW9ucy5zaGFyZXMgPSBwYXJzZUZsb2F0KGRlbGVnYXRpb25zLnNoYXJlcyk7XG5cbiAgICAgICAgdXJsID0gYC9zdGFraW5nL3JlZGVsZWdhdGlvbnM/ZGVsZWdhdG9yPSR7YWRkcmVzc30mdmFsaWRhdG9yX3RvPSR7dmFsaWRhdG9yfWA7XG4gICAgICAgIGxldCByZWxlZ2F0aW9ucyA9IGZldGNoRnJvbVVybCh1cmwpO1xuICAgICAgICByZWxlZ2F0aW9ucyA9IHJlbGVnYXRpb25zICYmIHJlbGVnYXRpb25zLmRhdGEucmVzdWx0O1xuICAgICAgICBsZXQgY29tcGxldGlvblRpbWU7XG4gICAgICAgIGlmIChyZWxlZ2F0aW9ucykge1xuICAgICAgICAgICAgcmVsZWdhdGlvbnMuZm9yRWFjaCgocmVsZWdhdGlvbikgPT4ge1xuICAgICAgICAgICAgICAgIGxldCBlbnRyaWVzID0gcmVsZWdhdGlvbi5lbnRyaWVzXG4gICAgICAgICAgICAgICAgbGV0IHRpbWUgPSBuZXcgRGF0ZShlbnRyaWVzW2VudHJpZXMubGVuZ3RoLTFdLmNvbXBsZXRpb25fdGltZSlcbiAgICAgICAgICAgICAgICBpZiAoIWNvbXBsZXRpb25UaW1lIHx8IHRpbWUgPiBjb21wbGV0aW9uVGltZSlcbiAgICAgICAgICAgICAgICAgICAgY29tcGxldGlvblRpbWUgPSB0aW1lXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgZGVsZWdhdGlvbnMucmVkZWxlZ2F0aW9uQ29tcGxldGlvblRpbWUgPSBjb21wbGV0aW9uVGltZTtcbiAgICAgICAgfVxuXG4gICAgICAgIHVybCA9IGAvc3Rha2luZy9kZWxlZ2F0b3JzLyR7YWRkcmVzc30vdW5ib25kaW5nX2RlbGVnYXRpb25zLyR7dmFsaWRhdG9yfWA7XG4gICAgICAgIGxldCB1bmRlbGVnYXRpb25zID0gZmV0Y2hGcm9tVXJsKHVybCk7XG4gICAgICAgIHVuZGVsZWdhdGlvbnMgPSB1bmRlbGVnYXRpb25zICYmIHVuZGVsZWdhdGlvbnMuZGF0YS5yZXN1bHQ7XG4gICAgICAgIGlmICh1bmRlbGVnYXRpb25zKSB7XG4gICAgICAgICAgICBkZWxlZ2F0aW9ucy51bmJvbmRpbmcgPSB1bmRlbGVnYXRpb25zLmVudHJpZXMubGVuZ3RoO1xuICAgICAgICAgICAgZGVsZWdhdGlvbnMudW5ib25kaW5nQ29tcGxldGlvblRpbWUgPSB1bmRlbGVnYXRpb25zLmVudHJpZXNbMF0uY29tcGxldGlvbl90aW1lO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBkZWxlZ2F0aW9ucztcbiAgICB9LFxuICAgICdhY2NvdW50cy5nZXRBbGxEZWxlZ2F0aW9ucycoYWRkcmVzcyl7XG4gICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL3N0YWtpbmcvZGVsZWdhdG9ycy8nK2FkZHJlc3MrJy9kZWxlZ2F0aW9ucyc7XG5cbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IGRlbGVnYXRpb25zID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmIChkZWxlZ2F0aW9ucy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgZGVsZWdhdGlvbnMgPSBKU09OLnBhcnNlKGRlbGVnYXRpb25zLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICBpZiAoZGVsZWdhdGlvbnMgJiYgZGVsZWdhdGlvbnMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zLmZvckVhY2goKGRlbGVnYXRpb24sIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkZWxlZ2F0aW9uc1tpXSAmJiBkZWxlZ2F0aW9uc1tpXS5zaGFyZXMpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZWdhdGlvbnNbaV0uc2hhcmVzID0gcGFyc2VGbG9hdChkZWxlZ2F0aW9uc1tpXS5zaGFyZXMpO1xuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHJldHVybiBkZWxlZ2F0aW9ucztcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdhY2NvdW50cy5nZXRBbGxVbmJvbmRpbmdzJyhhZGRyZXNzKXtcbiAgICAgICAgbGV0IHVybCA9IExDRCArICcvc3Rha2luZy9kZWxlZ2F0b3JzLycrYWRkcmVzcysnL3VuYm9uZGluZ19kZWxlZ2F0aW9ucyc7XG5cbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IHVuYm9uZGluZ3MgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKHVuYm9uZGluZ3Muc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIHVuYm9uZGluZ3MgPSBKU09OLnBhcnNlKHVuYm9uZGluZ3MuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgIHJldHVybiB1bmJvbmRpbmdzO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ2FjY291bnRzLmdldEFsbFJlZGVsZWdhdGlvbnMnKGFkZHJlc3MsIHZhbGlkYXRvcil7XG4gICAgICAgIGxldCB1cmwgPSBgL3N0YWtpbmcvcmVkZWxlZ2F0aW9ucz9kZWxlZ2F0b3I9JHthZGRyZXNzfSZ2YWxpZGF0b3JfZnJvbT0ke3ZhbGlkYXRvcn1gO1xuICAgICAgICBsZXQgcmVzdWx0ID0gZmV0Y2hGcm9tVXJsKHVybCk7XG4gICAgICAgIGlmIChyZXN1bHQgJiYgcmVzdWx0LmRhdGEpIHtcbiAgICAgICAgICAgIGxldCByZWRlbGVnYXRpb25zID0ge31cbiAgICAgICAgICAgIHJlc3VsdC5kYXRhLmZvckVhY2goKHJlZGVsZWdhdGlvbikgPT4ge1xuICAgICAgICAgICAgICAgIGxldCBlbnRyaWVzID0gcmVkZWxlZ2F0aW9uLmVudHJpZXM7XG4gICAgICAgICAgICAgICAgcmVkZWxlZ2F0aW9uc1tyZWRlbGVnYXRpb24udmFsaWRhdG9yX2RzdF9hZGRyZXNzXSA9IHtcbiAgICAgICAgICAgICAgICAgICAgY291bnQ6IGVudHJpZXMubGVuZ3RoLFxuICAgICAgICAgICAgICAgICAgICBjb21wbGV0aW9uVGltZTogZW50cmllc1swXS5jb21wbGV0aW9uX3RpbWVcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgcmV0dXJuIHJlZGVsZWdhdGlvbnNcbiAgICAgICAgfVxuICAgIH1cbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuaW1wb3J0IHsgUHJvbWlzZSB9IGZyb20gXCJtZXRlb3IvcHJvbWlzZVwiO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2Jsb2Nrcy9ibG9ja3MuanMnO1xuaW1wb3J0IHsgQ2hhaW4gfSBmcm9tICcvaW1wb3J0cy9hcGkvY2hhaW4vY2hhaW4uanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9yU2V0cyB9IGZyb20gJy9pbXBvcnRzL2FwaS92YWxpZGF0b3Itc2V0cy92YWxpZGF0b3Itc2V0cy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JSZWNvcmRzLCBBbmFseXRpY3MsIFZQRGlzdHJpYnV0aW9uc30gZnJvbSAnL2ltcG9ydHMvYXBpL3JlY29yZHMvcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBWb3RpbmdQb3dlckhpc3RvcnkgfSBmcm9tICcvaW1wb3J0cy9hcGkvdm90aW5nLXBvd2VyL2hpc3RvcnkuanMnO1xuaW1wb3J0IHsgVHJhbnNhY3Rpb25zIH0gZnJvbSAnLi4vLi4vdHJhbnNhY3Rpb25zL3RyYW5zYWN0aW9ucy5qcyc7XG5pbXBvcnQgeyBFdmlkZW5jZXMgfSBmcm9tICcuLi8uLi9ldmlkZW5jZXMvZXZpZGVuY2VzLmpzJztcbmltcG9ydCB7IHNoYTI1NiB9IGZyb20gJ2pzLXNoYTI1Nic7XG5pbXBvcnQgeyBnZXRBZGRyZXNzIH0gZnJvbSAndGVuZGVybWludC9saWIvcHVia2V5JztcbmltcG9ydCAqIGFzIGNoZWVyaW8gZnJvbSAnY2hlZXJpbyc7XG5cbi8vIGltcG9ydCBCbG9jayBmcm9tICcuLi8uLi8uLi91aS9jb21wb25lbnRzL0Jsb2NrJztcblxuLy8gZ2V0VmFsaWRhdG9yVm90aW5nUG93ZXIgPSAodmFsaWRhdG9ycywgYWRkcmVzcykgPT4ge1xuLy8gICAgIGZvciAodiBpbiB2YWxpZGF0b3JzKXtcbi8vICAgICAgICAgaWYgKHZhbGlkYXRvcnNbdl0uYWRkcmVzcyA9PSBhZGRyZXNzKXtcbi8vICAgICAgICAgICAgIHJldHVybiBwYXJzZUludCh2YWxpZGF0b3JzW3ZdLnZvdGluZ19wb3dlcik7XG4vLyAgICAgICAgIH1cbi8vICAgICB9XG4vLyB9XG5cbmdldFJlbW92ZWRWYWxpZGF0b3JzID0gKHByZXZWYWxpZGF0b3JzLCB2YWxpZGF0b3JzKSA9PiB7XG4gICAgLy8gbGV0IHJlbW92ZVZhbGlkYXRvcnMgPSBbXTtcbiAgICBmb3IgKHAgaW4gcHJldlZhbGlkYXRvcnMpe1xuICAgICAgICBmb3IgKHYgaW4gdmFsaWRhdG9ycyl7XG4gICAgICAgICAgICBpZiAocHJldlZhbGlkYXRvcnNbcF0uYWRkcmVzcyA9PSB2YWxpZGF0b3JzW3ZdLmFkZHJlc3Mpe1xuICAgICAgICAgICAgICAgIHByZXZWYWxpZGF0b3JzLnNwbGljZShwLDEpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHByZXZWYWxpZGF0b3JzO1xufVxuXG5nZXRWYWxpZGF0b3JQcm9maWxlVXJsID0gKGlkZW50aXR5KSA9PiB7XG4gICAgaWYgKGlkZW50aXR5Lmxlbmd0aCA9PSAxNil7XG4gICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KGBodHRwczovL2tleWJhc2UuaW8vXy9hcGkvMS4wL3VzZXIvbG9va3VwLmpzb24/a2V5X3N1ZmZpeD0ke2lkZW50aXR5fSZmaWVsZHM9cGljdHVyZXNgKVxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApIHtcbiAgICAgICAgICAgIGxldCB0aGVtID0gcmVzcG9uc2UuZGF0YS50aGVtXG4gICAgICAgICAgICByZXR1cm4gdGhlbSAmJiB0aGVtLmxlbmd0aCAmJiB0aGVtWzBdLnBpY3R1cmVzICYmIHRoZW1bMF0ucGljdHVyZXMucHJpbWFyeSAmJiB0aGVtWzBdLnBpY3R1cmVzLnByaW1hcnkudXJsO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkocmVzcG9uc2UpKVxuICAgICAgICB9XG4gICAgfSBlbHNlIGlmIChpZGVudGl0eS5pbmRleE9mKFwia2V5YmFzZS5pby90ZWFtL1wiKT4wKXtcbiAgICAgICAgbGV0IHRlYW1QYWdlID0gSFRUUC5nZXQoaWRlbnRpdHkpO1xuICAgICAgICBpZiAodGVhbVBhZ2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgbGV0IHBhZ2UgPSBjaGVlcmlvLmxvYWQodGVhbVBhZ2UuY29udGVudCk7XG4gICAgICAgICAgICByZXR1cm4gcGFnZShcIi5rYi1tYWluLWNhcmQgaW1nXCIpLmF0dHIoJ3NyYycpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkodGVhbVBhZ2UpKVxuICAgICAgICB9XG4gICAgfVxufVxuXG4vLyB2YXIgZmlsdGVyZWQgPSBbMSwgMiwgMywgNCwgNV0uZmlsdGVyKG5vdENvbnRhaW5lZEluKFsxLCAyLCAzLCA1XSkpO1xuLy8gY29uc29sZS5sb2coZmlsdGVyZWQpOyAvLyBbNF1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdibG9ja3MuYXZlcmFnZUJsb2NrVGltZScoYWRkcmVzcyl7XG4gICAgICAgIGxldCBibG9ja3MgPSBCbG9ja3Njb24uZmluZCh7cHJvcG9zZXJBZGRyZXNzOmFkZHJlc3N9KS5mZXRjaCgpO1xuICAgICAgICBsZXQgaGVpZ2h0cyA9IGJsb2Nrcy5tYXAoKGJsb2NrLCBpKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gYmxvY2suaGVpZ2h0O1xuICAgICAgICB9KTtcbiAgICAgICAgbGV0IGJsb2Nrc1N0YXRzID0gQW5hbHl0aWNzLmZpbmQoe2hlaWdodDp7JGluOmhlaWdodHN9fSkuZmV0Y2goKTtcbiAgICAgICAgLy8gY29uc29sZS5sb2coYmxvY2tzU3RhdHMpO1xuXG4gICAgICAgIGxldCB0b3RhbEJsb2NrRGlmZiA9IDA7XG4gICAgICAgIGZvciAoYiBpbiBibG9ja3NTdGF0cyl7XG4gICAgICAgICAgICB0b3RhbEJsb2NrRGlmZiArPSBibG9ja3NTdGF0c1tiXS50aW1lRGlmZjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdG90YWxCbG9ja0RpZmYvaGVpZ2h0cy5sZW5ndGg7XG4gICAgfSxcbiAgICAnYmxvY2tzLmZpbmRVcFRpbWUnKGFkZHJlc3Mpe1xuICAgICAgICBsZXQgY29sbGVjdGlvbiA9IFZhbGlkYXRvclJlY29yZHMucmF3Q29sbGVjdGlvbigpO1xuICAgICAgICAvLyBsZXQgYWdncmVnYXRlUXVlcnkgPSBNZXRlb3Iud3JhcEFzeW5jKGNvbGxlY3Rpb24uYWdncmVnYXRlLCBjb2xsZWN0aW9uKTtcbiAgICAgICAgdmFyIHBpcGVsaW5lID0gW1xuICAgICAgICAgICAgeyRtYXRjaDp7XCJhZGRyZXNzXCI6YWRkcmVzc319LFxuICAgICAgICAgICAgLy8geyRwcm9qZWN0OnthZGRyZXNzOjEsaGVpZ2h0OjEsZXhpc3RzOjF9fSxcbiAgICAgICAgICAgIHskc29ydDp7XCJoZWlnaHRcIjotMX19LFxuICAgICAgICAgICAgeyRsaW1pdDooTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy51cHRpbWVXaW5kb3ctMSl9LFxuICAgICAgICAgICAgeyR1bndpbmQ6IFwiJF9pZFwifSxcbiAgICAgICAgICAgIHskZ3JvdXA6e1xuICAgICAgICAgICAgICAgIFwiX2lkXCI6IFwiJGFkZHJlc3NcIixcbiAgICAgICAgICAgICAgICBcInVwdGltZVwiOiB7XG4gICAgICAgICAgICAgICAgICAgIFwiJHN1bVwiOntcbiAgICAgICAgICAgICAgICAgICAgICAgICRjb25kOiBbeyRlcTogWyckZXhpc3RzJywgdHJ1ZV19LCAxLCAwXVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgfV07XG4gICAgICAgIC8vIGxldCByZXN1bHQgPSBhZ2dyZWdhdGVRdWVyeShwaXBlbGluZSwgeyBjdXJzb3I6IHt9IH0pO1xuXG4gICAgICAgIHJldHVybiBQcm9taXNlLmF3YWl0KGNvbGxlY3Rpb24uYWdncmVnYXRlKHBpcGVsaW5lKS50b0FycmF5KCkpO1xuICAgICAgICAvLyByZXR1cm4gLmFnZ3JlZ2F0ZSgpXG4gICAgfSxcbiAgICAnYmxvY2tzLmdldExhdGVzdEhlaWdodCc6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHVybCA9IFJQQysnL3N0YXR1cyc7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBsZXQgc3RhdHVzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgIHJldHVybiAoc3RhdHVzLnJlc3VsdC5zeW5jX2luZm8ubGF0ZXN0X2Jsb2NrX2hlaWdodCk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdibG9ja3MuZ2V0Q3VycmVudEhlaWdodCc6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IGN1cnJIZWlnaHQgPSBCbG9ja3Njb24uZmluZCh7fSx7c29ydDp7aGVpZ2h0Oi0xfSxsaW1pdDoxfSkuZmV0Y2goKTtcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCJjdXJyZW50SGVpZ2h0OlwiK2N1cnJIZWlnaHQpO1xuICAgICAgICBsZXQgc3RhcnRIZWlnaHQgPSBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLnN0YXJ0SGVpZ2h0O1xuICAgICAgICBpZiAoY3VyckhlaWdodCAmJiBjdXJySGVpZ2h0Lmxlbmd0aCA9PSAxKSB7XG4gICAgICAgICAgICBsZXQgaGVpZ2h0ID0gY3VyckhlaWdodFswXS5oZWlnaHQ7XG4gICAgICAgICAgICBpZiAoaGVpZ2h0ID4gc3RhcnRIZWlnaHQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGhlaWdodFxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzdGFydEhlaWdodFxuICAgIH0sXG4gICAgJ2Jsb2Nrcy5ibG9ja3NVcGRhdGUnOiBmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKFNZTkNJTkcpXG4gICAgICAgICAgICByZXR1cm4gXCJTeW5jaW5nLi4uXCI7XG4gICAgICAgIGVsc2UgY29uc29sZS5sb2coXCJzdGFydCB0byBzeW5jXCIpO1xuICAgICAgICAvLyBNZXRlb3IuY2xlYXJJbnRlcnZhbChNZXRlb3IudGltZXJIYW5kbGUpO1xuICAgICAgICAvLyBnZXQgdGhlIGxhdGVzdCBoZWlnaHRcbiAgICAgICAgbGV0IHVudGlsID0gTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5nZXRMYXRlc3RIZWlnaHQnKTtcbiAgICAgICAgLy8gY29uc29sZS5sb2codW50aWwpO1xuICAgICAgICAvLyBnZXQgdGhlIGN1cnJlbnQgaGVpZ2h0IGluIGRiXG4gICAgICAgIGxldCBjdXJyID0gTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5nZXRDdXJyZW50SGVpZ2h0Jyk7XG4gICAgICAgIGNvbnNvbGUubG9nKGN1cnIpO1xuICAgICAgICAvLyBsb29wIGlmIHRoZXJlJ3MgdXBkYXRlIGluIGRiXG4gICAgICAgIGlmICh1bnRpbCA+IGN1cnIpIHtcbiAgICAgICAgICAgIFNZTkNJTkcgPSB0cnVlO1xuXG4gICAgICAgICAgICBsZXQgdmFsaWRhdG9yU2V0ID0ge31cbiAgICAgICAgICAgIC8vIGdldCBsYXRlc3QgdmFsaWRhdG9yIGNhbmRpZGF0ZSBpbmZvcm1hdGlvblxuICAgICAgICAgICAgdXJsID0gTENEKycvc3Rha2luZy92YWxpZGF0b3JzJztcblxuICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdC5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHZhbGlkYXRvclNldFt2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleV0gPSB2YWxpZGF0b3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHVybCA9IExDRCsnL3N0YWtpbmcvdmFsaWRhdG9ycz9zdGF0dXM9dW5ib25kaW5nJztcblxuICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdC5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHZhbGlkYXRvclNldFt2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleV0gPSB2YWxpZGF0b3IpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdXJsID0gTENEKycvc3Rha2luZy92YWxpZGF0b3JzP3N0YXR1cz11bmJvbmRlZCc7XG5cbiAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQuZm9yRWFjaCgodmFsaWRhdG9yKSA9PiB2YWxpZGF0b3JTZXRbdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXldID0gdmFsaWRhdG9yKVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZXQgdG90YWxWYWxpZGF0b3JzID0gT2JqZWN0LmtleXModmFsaWRhdG9yU2V0KS5sZW5ndGg7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFsbCB2YWxpZGF0b3JzOiBcIisgdG90YWxWYWxpZGF0b3JzKTtcbiAgICAgICAgICAgIGZvciAobGV0IGhlaWdodCA9IGN1cnIrMSA7IGhlaWdodCA8PSB1bnRpbCA7IGhlaWdodCsrKSB7XG4gICAgICAgICAgICAgICAgbGV0IHN0YXJ0QmxvY2tUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAvLyBhZGQgdGltZW91dCBoZXJlPyBhbmQgb3V0c2lkZSB0aGlzIGxvb3AgKGZvciBjYXRjaGVkIHVwIGFuZCBrZWVwIGZldGNoaW5nKT9cbiAgICAgICAgICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgICAgICAgICBsZXQgdXJsID0gUlBDKycvYmxvY2s/aGVpZ2h0PScgKyBoZWlnaHQ7XG4gICAgICAgICAgICAgICAgbGV0IGFuYWx5dGljc0RhdGEgPSB7fTtcblxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHVybCk7XG4gICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBidWxrVmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AoKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYnVsa1ZhbGlkYXRvclJlY29yZHMgPSBWYWxpZGF0b3JSZWNvcmRzLnJhd0NvbGxlY3Rpb24oKS5pbml0aWFsaXplVW5vcmRlcmVkQnVsa09wKCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtWUEhpc3RvcnkgPSBWb3RpbmdQb3dlckhpc3RvcnkucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AoKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYnVsa1RyYW5zYXRpb25zID0gVHJhbnNhY3Rpb25zLnJhd0NvbGxlY3Rpb24oKS5pbml0aWFsaXplVW5vcmRlcmVkQnVsa09wKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0R2V0SGVpZ2h0VGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgYmxvY2sgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2sgPSBibG9jay5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzdG9yZSBoZWlnaHQsIGhhc2gsIG51bXRyYW5zYWN0aW9uIGFuZCB0aW1lIGluIGRiXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgYmxvY2tEYXRhID0ge307XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLmhhc2ggPSBibG9jay5ibG9ja19pZC5oYXNoO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLnRyYW5zTnVtID0gKGJsb2NrLmJsb2NrLmRhdGEudHhzID09PSBudWxsKSA/IDAgOiBibG9jay5ibG9jay5kYXRhLnR4cy5sZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEudGltZSA9IG5ldyBEYXRlKGJsb2NrLmJsb2NrLmhlYWRlci50aW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS5sYXN0QmxvY2tIYXNoID0gYmxvY2suYmxvY2suaGVhZGVyLmxhc3RfYmxvY2tfaWQuaGFzaDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS5wcm9wb3NlckFkZHJlc3MgPSBibG9jay5ibG9jay5oZWFkZXIucHJvcG9zZXJfYWRkcmVzcztcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS52YWxpZGF0b3JzID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJlY29tbWl0cyA9IGJsb2NrLmJsb2NrLmxhc3RfY29tbWl0LnNpZ25hdHVyZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJlY29tbWl0cyAhPSBudWxsKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhwcmVjb21taXRzLmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaT0wOyBpPHByZWNvbW1pdHMubGVuZ3RoOyBpKyspe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJlY29tbWl0c1tpXSAhPSBudWxsKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS52YWxpZGF0b3JzLnB1c2gocHJlY29tbWl0c1tpXS52YWxpZGF0b3JfYWRkcmVzcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLnByZWNvbW1pdHMgPSBwcmVjb21taXRzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyByZWNvcmQgZm9yIGFuYWx5dGljc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFByZWNvbW1pdFJlY29yZHMuaW5zZXJ0KHtoZWlnaHQ6aGVpZ2h0LCBwcmVjb21taXRzOnByZWNvbW1pdHMubGVuZ3RofSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHNhdmUgdHhzIGluIGRhdGFiYXNlXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYmxvY2suYmxvY2suZGF0YS50eHMgJiYgYmxvY2suYmxvY2suZGF0YS50eHMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh0IGluIGJsb2NrLmJsb2NrLmRhdGEudHhzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTWV0ZW9yLmNhbGwoJ1RyYW5zYWN0aW9ucy5pbmRleCcsIHNoYTI1NihCdWZmZXIuZnJvbShibG9jay5ibG9jay5kYXRhLnR4c1t0XSwgJ2Jhc2U2NCcpKSwgYmxvY2tEYXRhLnRpbWUsIChlcnIsIHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzYXZlIGRvdWJsZSBzaWduIGV2aWRlbmNlc1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGJsb2NrLmJsb2NrLmV2aWRlbmNlLmV2aWRlbmNlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBFdmlkZW5jZXMuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBoZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV2aWRlbmNlOiBibG9jay5ibG9jay5ldmlkZW5jZS5ldmlkZW5jZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEucHJlY29tbWl0c0NvdW50ID0gYmxvY2tEYXRhLnZhbGlkYXRvcnMubGVuZ3RoO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLmhlaWdodCA9IGhlaWdodDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGVuZEdldEhlaWdodFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJHZXQgaGVpZ2h0IHRpbWU6IFwiKygoZW5kR2V0SGVpZ2h0VGltZS1zdGFydEdldEhlaWdodFRpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0R2V0VmFsaWRhdG9yc1RpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gdXBkYXRlIGNoYWluIHN0YXR1c1xuICAgICAgICAgICAgICAgICAgICAgICAgdXJsID0gUlBDKycvdmFsaWRhdG9ycz9oZWlnaHQ9JytoZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvcnMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9ycy5yZXN1bHQuYmxvY2tfaGVpZ2h0ID0gcGFyc2VJbnQodmFsaWRhdG9ycy5yZXN1bHQuYmxvY2tfaGVpZ2h0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIFZhbGlkYXRvclNldHMuaW5zZXJ0KHZhbGlkYXRvcnMucmVzdWx0KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLnZhbGlkYXRvcnNDb3VudCA9IHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnMubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0QmxvY2tJbnNlcnRUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIEJsb2Nrc2Nvbi5pbnNlcnQoYmxvY2tEYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlbmRCbG9ja0luc2VydFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJCbG9jayBpbnNlcnQgdGltZTogXCIrKChlbmRCbG9ja0luc2VydFRpbWUtc3RhcnRCbG9ja0luc2VydFRpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHN0b3JlIHZhbGRpYXRvcnMgZXhpc3QgcmVjb3Jkc1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGV4aXN0aW5nVmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7YWRkcmVzczp7JGV4aXN0czp0cnVlfX0pLmZldGNoKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChoZWlnaHQgPiAxKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyByZWNvcmQgcHJlY29tbWl0cyBhbmQgY2FsY3VsYXRlIHVwdGltZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIG9ubHkgcmVjb3JkIGZyb20gYmxvY2sgMlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoaSBpbiB2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGFkZHJlc3MgPSB2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzW2ldLmFkZHJlc3M7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZWNvcmQgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IGFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleGlzdHM6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiBwYXJzZUludCh2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzW2ldLnZvdGluZ19wb3dlcikvL2dldFZhbGlkYXRvclZvdGluZ1Bvd2VyKGV4aXN0aW5nVmFsaWRhdG9ycywgYWRkcmVzcylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoaiBpbiBwcmVjb21taXRzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmVjb21taXRzW2pdICE9IG51bGwpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhZGRyZXNzID09IHByZWNvbW1pdHNbal0udmFsaWRhdG9yX2FkZHJlc3Mpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWNvcmQuZXhpc3RzID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJlY29tbWl0cy5zcGxpY2UoaiwxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2FsY3VsYXRlIHRoZSB1cHRpbWUgYmFzZWQgb24gdGhlIHJlY29yZHMgc3RvcmVkIGluIHByZXZpb3VzIGJsb2Nrc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBvbmx5IGRvIHRoaXMgZXZlcnkgMTUgYmxvY2tzIH5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoKGhlaWdodCAlIDE1KSA9PSAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGxldCBzdGFydEFnZ1RpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG51bUJsb2NrcyA9IE1ldGVvci5jYWxsKCdibG9ja3MuZmluZFVwVGltZScsIGFkZHJlc3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHVwdGltZSA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBsZXQgZW5kQWdnVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcIkdldCBhZ2dyZWdhdGVkIHVwdGltZSBmb3IgXCIrZXhpc3RpbmdWYWxpZGF0b3JzW2ldLmFkZHJlc3MrXCI6IFwiKygoZW5kQWdnVGltZS1zdGFydEFnZ1RpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoKG51bUJsb2Nrc1swXSAhPSBudWxsKSAmJiAobnVtQmxvY2tzWzBdLnVwdGltZSAhPSBudWxsKSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXB0aW1lID0gbnVtQmxvY2tzWzBdLnVwdGltZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJhc2UgPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLnVwdGltZVdpbmRvdztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChoZWlnaHQgPCBiYXNlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYXNlID0gaGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVjb3JkLmV4aXN0cyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHVwdGltZSA8IGJhc2Upe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cHRpbWUrKztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXB0aW1lID0gKHVwdGltZSAvIGJhc2UpKjEwMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHthZGRyZXNzOmFkZHJlc3N9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6e3VwdGltZTp1cHRpbWUsIGxhc3RTZWVuOmJsb2NrRGF0YS50aW1lfX0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cHRpbWUgPSAodXB0aW1lIC8gYmFzZSkqMTAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JzLmZpbmQoe2FkZHJlc3M6YWRkcmVzc30pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDp7dXB0aW1lOnVwdGltZX19KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JSZWNvcmRzLmluc2VydChyZWNvcmQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBWYWxpZGF0b3JSZWNvcmRzLnVwZGF0ZSh7aGVpZ2h0OmhlaWdodCxhZGRyZXNzOnJlY29yZC5hZGRyZXNzfSxyZWNvcmQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNoYWluU3RhdHVzID0gQ2hhaW4uZmluZE9uZSh7Y2hhaW5JZDpibG9jay5ibG9jay5oZWFkZXIuY2hhaW5faWR9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBsYXN0U3luY2VkVGltZSA9IGNoYWluU3RhdHVzP2NoYWluU3RhdHVzLmxhc3RTeW5jZWRUaW1lOjA7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgdGltZURpZmY7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgYmxvY2tUaW1lID0gTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5kZWZhdWx0QmxvY2tUaW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGxhc3RTeW5jZWRUaW1lKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgZGF0ZUxhdGVzdCA9IGJsb2NrRGF0YS50aW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBkYXRlTGFzdCA9IG5ldyBEYXRlKGxhc3RTeW5jZWRUaW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lRGlmZiA9IE1hdGguYWJzKGRhdGVMYXRlc3QuZ2V0VGltZSgpIC0gZGF0ZUxhc3QuZ2V0VGltZSgpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkaXNyZWdhcmQgZmlyc3QgY291cGxlIG9mIGJsb2NrcyB0byBhdm9pZCBoaWdoIGF2ZyB0aW1lIGR1ZSB0byBnZW5lc2lzIGRhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZihibG9ja0RhdGEuaGVpZ2h0ID4gMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja1RpbWUgPSAoY2hhaW5TdGF0dXMuYmxvY2tUaW1lICogKGJsb2NrRGF0YS5oZWlnaHQgLSAxKSArIHRpbWVEaWZmKSAvIGJsb2NrRGF0YS5oZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZW5kR2V0VmFsaWRhdG9yc1RpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJHZXQgaGVpZ2h0IHZhbGlkYXRvcnMgdGltZTogXCIrKChlbmRHZXRWYWxpZGF0b3JzVGltZS1zdGFydEdldFZhbGlkYXRvcnNUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6YmxvY2suYmxvY2suaGVhZGVyLmNoYWluX2lkfSwgeyRzZXQ6e2xhc3RTeW5jZWRUaW1lOmJsb2NrRGF0YS50aW1lLCBibG9ja1RpbWU6YmxvY2tUaW1lfX0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLmF2ZXJhZ2VCbG9ja1RpbWUgPSBibG9ja1RpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLnRpbWVEaWZmID0gdGltZURpZmY7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGFuYWx5dGljc0RhdGEudGltZSA9IGJsb2NrRGF0YS50aW1lO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBpbml0aWFsaXplIHZhbGlkYXRvciBkYXRhIGF0IGZpcnN0IGJsb2NrXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBpZiAoaGVpZ2h0ID09IDEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgIFZhbGlkYXRvcnMucmVtb3ZlKHt9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS52b3RpbmdfcG93ZXIgPSAwO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRGaW5kVmFsaWRhdG9yc05hbWVUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JzLnJlc3VsdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9ycyBhcmUgYWxsIHRoZSB2YWxpZGF0b3JzIGluIHRoZSBjdXJyZW50IGhlaWdodFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwidmFsaWRhdG9yU2V0IHNpemU6IFwiK3ZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnMubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHYgaW4gdmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFZhbGlkYXRvcnMuaW5zZXJ0KHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnNbdl0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yID0gdmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9yc1t2XTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnZvdGluZ19wb3dlciA9IHBhcnNlSW50KHZhbGlkYXRvci52b3RpbmdfcG93ZXIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHJvcG9zZXJfcHJpb3JpdHkgPSBwYXJzZUludCh2YWxpZGF0b3IucHJvcG9zZXJfcHJpb3JpdHkpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxFeGlzdCA9IFZhbGlkYXRvcnMuZmluZE9uZSh7XCJwdWJfa2V5LnZhbHVlXCI6dmFsaWRhdG9yLnB1Yl9rZXkudmFsdWV9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCF2YWxFeGlzdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgdmFsaWRhdG9yIHB1Yl9rZXkgJHt2YWxpZGF0b3IuYWRkcmVzc30gJHt2YWxpZGF0b3IucHViX2tleS52YWx1ZX0gbm90IGluIGRiYCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBsZXQgY29tbWFuZCA9IE1ldGVvci5zZXR0aW5ncy5iaW4uZ2FpYWRlYnVnK1wiIHB1YmtleSBcIit2YWxpZGF0b3IucHViX2tleS52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGNvbW1hbmQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGV0IHRlbXBWYWwgPSB2YWxpZGF0b3I7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5hZGRyZXNzID0gZ2V0QWRkcmVzcyh2YWxpZGF0b3IucHViX2tleSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYWNjcHViID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4QWNjUHViKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXkgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3IucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhWYWxQdWIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXkgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3IucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhDb25zUHViKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvckRhdGEgPSB2YWxpZGF0b3JTZXRbdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yRGF0YSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvckRhdGEuZGVzY3JpcHRpb24uaWRlbnRpdHkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5wcm9maWxlX3VybCA9ICBnZXRWYWxpZGF0b3JQcm9maWxlVXJsKHZhbGlkYXRvckRhdGEuZGVzY3JpcHRpb24uaWRlbnRpdHkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLm9wZXJhdG9yX2FkZHJlc3MgPSB2YWxpZGF0b3JEYXRhLm9wZXJhdG9yX2FkZHJlc3M7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmRlbGVnYXRvcl9hZGRyZXNzID0gTWV0ZW9yLmNhbGwoJ2dldERlbGVnYXRvcicsIHZhbGlkYXRvckRhdGEub3BlcmF0b3JfYWRkcmVzcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmphaWxlZCA9IHZhbGlkYXRvckRhdGEuamFpbGVkO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5zdGF0dXMgPSB2YWxpZGF0b3JEYXRhLnN0YXR1cztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IubWluX3NlbGZfZGVsZWdhdGlvbiA9IHZhbGlkYXRvckRhdGEubWluX3NlbGZfZGVsZWdhdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IudG9rZW5zID0gdmFsaWRhdG9yRGF0YS50b2tlbnM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmRlbGVnYXRvcl9zaGFyZXMgPSB2YWxpZGF0b3JEYXRhLmRlbGVnYXRvcl9zaGFyZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmRlc2NyaXB0aW9uID0gdmFsaWRhdG9yRGF0YS5kZXNjcmlwdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYm9uZF9oZWlnaHQgPSB2YWxpZGF0b3JEYXRhLmJvbmRfaGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5ib25kX2ludHJhX3R4X2NvdW50ZXIgPSB2YWxpZGF0b3JEYXRhLmJvbmRfaW50cmFfdHhfY291bnRlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IudW5ib25kaW5nX2hlaWdodCA9IHZhbGlkYXRvckRhdGEudW5ib25kaW5nX2hlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IudW5ib25kaW5nX3RpbWUgPSB2YWxpZGF0b3JEYXRhLnVuYm9uZGluZ190aW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5jb21taXNzaW9uID0gdmFsaWRhdG9yRGF0YS5jb21taXNzaW9uO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5zZWxmX2RlbGVnYXRpb24gPSB2YWxpZGF0b3IuZGVsZWdhdG9yX3NoYXJlcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IucmVtb3ZlZCA9IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5yZW1vdmVkQXQgPSAwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yU2V0LnNwbGljZSh2YWwsIDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnbm8gY29uIHB1YiBrZXk/JylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gYnVsa1ZhbGlkYXRvcnMuaW5zZXJ0KHZhbGlkYXRvcik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHtjb25zZW5zdXNfcHVia2V5OiB2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleX0pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDp2YWxpZGF0b3J9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwidmFsaWRhdG9yIGZpcnN0IGFwcGVhcnM6IFwiK2J1bGtWYWxpZGF0b3JzLmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVlBIaXN0b3J5Lmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogdmFsaWRhdG9yLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdhZGQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogYmxvY2tEYXRhLmhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja190aW1lOiBibG9ja0RhdGEudGltZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE1ldGVvci5jYWxsKCdydW5Db2RlJywgY29tbWFuZCwgZnVuY3Rpb24oZXJyb3IsIHJlc3VsdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuYWRkcmVzcyA9IHJlc3VsdC5tYXRjaCgvXFxzWzAtOUEtRl17NDB9JC9pZ20pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmFkZHJlc3MgPSB2YWxpZGF0b3IuYWRkcmVzc1swXS50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuaGV4ID0gcmVzdWx0Lm1hdGNoKC9cXHNbMC05QS1GXXs2NH0kL2lnbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuaGV4ID0gdmFsaWRhdG9yLmhleFswXS50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuY29zbW9zYWNjcHViID0gcmVzdWx0Lm1hdGNoKC9jb3Ntb3NwdWIuKiQvaWdtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5jb3Ntb3NhY2NwdWIgPSB2YWxpZGF0b3IuY29zbW9zYWNjcHViWzBdLnRyaW0oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXkgPSByZXN1bHQubWF0Y2goL2Nvc21vc3ZhbG9wZXJwdWIuKiQvaWdtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5vcGVyYXRvcl9wdWJrZXkgPSB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5WzBdLnRyaW0oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5ID0gcmVzdWx0Lm1hdGNoKC9jb3Ntb3N2YWxjb25zcHViLiokL2lnbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleSA9IHZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5WzBdLnRyaW0oKTtcblxuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yRGF0YSA9IHZhbGlkYXRvclNldFt2YWxFeGlzdC5jb25zZW5zdXNfcHVia2V5XVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvckRhdGEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JEYXRhLmRlc2NyaXB0aW9uICYmICghdmFsRXhpc3QuZGVzY3JpcHRpb24gfHwgdmFsaWRhdG9yRGF0YS5kZXNjcmlwdGlvbi5pZGVudGl0eSAhPT0gdmFsRXhpc3QuZGVzY3JpcHRpb24uaWRlbnRpdHkpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHJvZmlsZV91cmwgPSAgZ2V0VmFsaWRhdG9yUHJvZmlsZVVybCh2YWxpZGF0b3JEYXRhLmRlc2NyaXB0aW9uLmlkZW50aXR5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5qYWlsZWQgPSB2YWxpZGF0b3JEYXRhLmphaWxlZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iuc3RhdHVzID0gdmFsaWRhdG9yRGF0YS5zdGF0dXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnRva2VucyA9IHZhbGlkYXRvckRhdGEudG9rZW5zO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzID0gdmFsaWRhdG9yRGF0YS5kZWxlZ2F0b3Jfc2hhcmVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZXNjcmlwdGlvbiA9IHZhbGlkYXRvckRhdGEuZGVzY3JpcHRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmJvbmRfaGVpZ2h0ID0gdmFsaWRhdG9yRGF0YS5ib25kX2hlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYm9uZF9pbnRyYV90eF9jb3VudGVyID0gdmFsaWRhdG9yRGF0YS5ib25kX2ludHJhX3R4X2NvdW50ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnVuYm9uZGluZ19oZWlnaHQgPSB2YWxpZGF0b3JEYXRhLnVuYm9uZGluZ19oZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnVuYm9uZGluZ190aW1lID0gdmFsaWRhdG9yRGF0YS51bmJvbmRpbmdfdGltZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuY29tbWlzc2lvbiA9IHZhbGlkYXRvckRhdGEuY29tbWlzc2lvbjtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNhbGN1bGF0ZSBzZWxmIGRlbGVnYXRpb24gcGVyY2VudGFnZSBldmVyeSAzMCBibG9ja3NcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChoZWlnaHQgJSAzMCA9PSAxKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQoTENEICsgJy9zdGFraW5nL2RlbGVnYXRvcnMvJyt2YWxFeGlzdC5kZWxlZ2F0b3JfYWRkcmVzcysnL2RlbGVnYXRpb25zLycrdmFsRXhpc3Qub3BlcmF0b3JfYWRkcmVzcyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHNlbGZEZWxlZ2F0aW9uID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNlbGZEZWxlZ2F0aW9uLnNoYXJlcyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5zZWxmX2RlbGVnYXRpb24gPSBwYXJzZUZsb2F0KHNlbGZEZWxlZ2F0aW9uLnNoYXJlcykvcGFyc2VGbG9hdCh2YWxpZGF0b3IuZGVsZWdhdG9yX3NoYXJlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHtjb25zZW5zdXNfcHVia2V5OiB2YWxFeGlzdC5jb25zZW5zdXNfcHVia2V5fSkudXBkYXRlT25lKHskc2V0OnZhbGlkYXRvcn0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwidmFsaWRhdG9yIGV4aXNpdHM6IFwiK2J1bGtWYWxpZGF0b3JzLmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yU2V0LnNwbGljZSh2YWwsIDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ25vIGNvbiBwdWIga2V5PycpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJldlZvdGluZ1Bvd2VyID0gVm90aW5nUG93ZXJIaXN0b3J5LmZpbmRPbmUoe2FkZHJlc3M6dmFsaWRhdG9yLmFkZHJlc3N9LCB7aGVpZ2h0Oi0xLCBsaW1pdDoxfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmV2Vm90aW5nUG93ZXIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmV2Vm90aW5nUG93ZXIudm90aW5nX3Bvd2VyICE9IHZhbGlkYXRvci52b3RpbmdfcG93ZXIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgY2hhbmdlVHlwZSA9IChwcmV2Vm90aW5nUG93ZXIudm90aW5nX3Bvd2VyID4gdmFsaWRhdG9yLnZvdGluZ19wb3dlcik/J2Rvd24nOid1cCc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjaGFuZ2VEYXRhID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogdmFsaWRhdG9yLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmV2X3ZvdGluZ19wb3dlcjogcHJldlZvdGluZ1Bvd2VyLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogdmFsaWRhdG9yLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IGNoYW5nZVR5cGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGJsb2NrRGF0YS5oZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja190aW1lOiBibG9ja0RhdGEudGltZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygndm90aW5nIHBvd2VyIGNoYW5nZWQuJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGNoYW5nZURhdGEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVlBIaXN0b3J5Lmluc2VydChjaGFuZ2VEYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2codmFsaWRhdG9yKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLnZvdGluZ19wb3dlciArPSB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGlmIHRoZXJlIGlzIHZhbGlkYXRvciByZW1vdmVkXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJldlZhbGlkYXRvcnMgPSBWYWxpZGF0b3JTZXRzLmZpbmRPbmUoe2Jsb2NrX2hlaWdodDpoZWlnaHQtMX0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByZXZWYWxpZGF0b3JzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlbW92ZWRWYWxpZGF0b3JzID0gZ2V0UmVtb3ZlZFZhbGlkYXRvcnMocHJldlZhbGlkYXRvcnMudmFsaWRhdG9ycywgdmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9ycyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChyIGluIHJlbW92ZWRWYWxpZGF0b3JzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWUEhpc3RvcnkuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOiByZW1vdmVkVmFsaWRhdG9yc1tyXS5hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZXZfdm90aW5nX3Bvd2VyOiByZW1vdmVkVmFsaWRhdG9yc1tyXS52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdyZW1vdmUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogYmxvY2tEYXRhLmhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja190aW1lOiBibG9ja0RhdGEudGltZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjaGVjayBpZiB0aGVyZSdzIGFueSB2YWxpZGF0b3Igbm90IGluIGRiIDE0NDAwIGJsb2Nrcyh+MSBkYXkpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVpZ2h0ICUgMTQ0MDAgPT0gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0NoZWNraW5nIGFsbCB2YWxpZGF0b3JzIGFnYWluc3QgZGIuLi4nKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgZGJWYWxpZGF0b3JzID0ge31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVmFsaWRhdG9ycy5maW5kKHt9LCB7ZmllbGRzOiB7Y29uc2Vuc3VzX3B1YmtleTogMSwgc3RhdHVzOiAxfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkuZm9yRWFjaCgodikgPT4gZGJWYWxpZGF0b3JzW3YuY29uc2Vuc3VzX3B1YmtleV0gPSB2LnN0YXR1cylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT2JqZWN0LmtleXModmFsaWRhdG9yU2V0KS5mb3JFYWNoKChjb25QdWJLZXkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3JEYXRhID0gdmFsaWRhdG9yU2V0W2NvblB1YktleV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBBY3RpdmUgdmFsaWRhdG9ycyBzaG91bGQgaGF2ZSBiZWVuIHVwZGF0ZWQgaW4gcHJldmlvdXMgc3RlcHNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JEYXRhLnN0YXR1cyA9PT0gMilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGRiVmFsaWRhdG9yc1tjb25QdWJLZXldID09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGB2YWxpZGF0b3Igd2l0aCBjb25zZW5zdXNfcHVia2V5ICR7Y29uUHViS2V5fSBub3QgaW4gZGJgKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvckRhdGEucHViX2tleSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCIgOiBcInRlbmRlcm1pbnQvUHViS2V5RWQyNTUxOVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInZhbHVlXCI6IE1ldGVvci5jYWxsKCdiZWNoMzJUb1B1YmtleScsIGNvblB1YktleSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yRGF0YS5hZGRyZXNzID0gZ2V0QWRkcmVzcyh2YWxpZGF0b3JEYXRhLnB1Yl9rZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvckRhdGEuZGVsZWdhdG9yX2FkZHJlc3MgPSBNZXRlb3IuY2FsbCgnZ2V0RGVsZWdhdG9yJywgdmFsaWRhdG9yRGF0YS5vcGVyYXRvcl9hZGRyZXNzKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvckRhdGEuYWNjcHViID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yRGF0YS5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY1B1Yik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yRGF0YS5vcGVyYXRvcl9wdWJrZXkgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3JEYXRhLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsUHViKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeSh2YWxpZGF0b3JEYXRhKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHtjb25zZW5zdXNfcHVia2V5OiBjb25QdWJLZXl9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6dmFsaWRhdG9yRGF0YX0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChkYlZhbGlkYXRvcnNbY29uUHViS2V5XSA9PSAyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7Y29uc2Vuc3VzX3B1YmtleTogY29uUHViS2V5fSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OnZhbGlkYXRvckRhdGF9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGZldGNoaW5nIGtleWJhc2UgZXZlcnkgMTQ0MDAgYmxvY2tzKH4xIGRheSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChoZWlnaHQgJSAxNDQwMCA9PSAxKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnRmV0Y2hpbmcga2V5YmFzZS4uLicpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVmFsaWRhdG9ycy5maW5kKHt9KS5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwcm9maWxlVXJsID0gIGdldFZhbGlkYXRvclByb2ZpbGVVcmwodmFsaWRhdG9yLmRlc2NyaXB0aW9uLmlkZW50aXR5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByb2ZpbGVVcmwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHthZGRyZXNzOiB2YWxpZGF0b3IuYWRkcmVzc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6eydwcm9maWxlX3VybCc6cHJvZmlsZVVybH19KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlbmRGaW5kVmFsaWRhdG9yc05hbWVUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiR2V0IHZhbGlkYXRvcnMgbmFtZSB0aW1lOiBcIisoKGVuZEZpbmRWYWxpZGF0b3JzTmFtZVRpbWUtc3RhcnRGaW5kVmFsaWRhdG9yc05hbWVUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyByZWNvcmQgZm9yIGFuYWx5dGljc1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0QW5heXRpY3NJbnNlcnRUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIEFuYWx5dGljcy5pbnNlcnQoYW5hbHl0aWNzRGF0YSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZW5kQW5hbHl0aWNzSW5zZXJ0VGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkFuYWx5dGljcyBpbnNlcnQgdGltZTogXCIrKChlbmRBbmFseXRpY3NJbnNlcnRUaW1lLXN0YXJ0QW5heXRpY3NJbnNlcnRUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRWVXBUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChidWxrVmFsaWRhdG9ycy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhidWxrVmFsaWRhdG9ycy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JzLmV4ZWN1dGUoKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGVuZFZVcFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJWYWxpZGF0b3IgdXBkYXRlIHRpbWU6IFwiKygoZW5kVlVwVGltZS1zdGFydFZVcFRpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzdGFydFZSVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYnVsa1ZhbGlkYXRvclJlY29yZHMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvclJlY29yZHMuZXhlY3V0ZSgoZXJyLCByZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlbmRWUlRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJWYWxpZGF0b3IgcmVjb3JkcyB1cGRhdGUgdGltZTogXCIrKChlbmRWUlRpbWUtc3RhcnRWUlRpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChidWxrVlBIaXN0b3J5Lmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWUEhpc3RvcnkuZXhlY3V0ZSgoZXJyLCByZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChidWxrVHJhbnNhdGlvbnMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1RyYW5zYXRpb25zLmV4ZWN1dGUoKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjYWxjdWxhdGUgdm90aW5nIHBvd2VyIGRpc3RyaWJ1dGlvbiBldmVyeSA2MCBibG9ja3MgfiA1bWluc1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVpZ2h0ICUgNjAgPT0gMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCI9PT09PSBjYWxjdWxhdGUgdm90aW5nIHBvd2VyIGRpc3RyaWJ1dGlvbiA9PT09PVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgYWN0aXZlVmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7c3RhdHVzOjIsamFpbGVkOmZhbHNlfSx7c29ydDp7dm90aW5nX3Bvd2VyOi0xfX0pLmZldGNoKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG51bVRvcFR3ZW50eSA9IE1hdGguY2VpbChhY3RpdmVWYWxpZGF0b3JzLmxlbmd0aCowLjIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBudW1Cb3R0b21FaWdodHkgPSBhY3RpdmVWYWxpZGF0b3JzLmxlbmd0aCAtIG51bVRvcFR3ZW50eTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB0b3BUd2VudHlQb3dlciA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJvdHRvbUVpZ2h0eVBvd2VyID0gMDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBudW1Ub3BUaGlydHlGb3VyID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgbnVtQm90dG9tU2l4dHlTaXggPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB0b3BUaGlydHlGb3VyUGVyY2VudCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJvdHRvbVNpeHR5U2l4UGVyY2VudCA9IDA7XG5cblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2IGluIGFjdGl2ZVZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodiA8IG51bVRvcFR3ZW50eSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3BUd2VudHlQb3dlciArPSBhY3RpdmVWYWxpZGF0b3JzW3ZdLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNle1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm90dG9tRWlnaHR5UG93ZXIgKz0gYWN0aXZlVmFsaWRhdG9yc1t2XS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0b3BUaGlydHlGb3VyUGVyY2VudCA8IDAuMzQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wVGhpcnR5Rm91clBlcmNlbnQgKz0gYWN0aXZlVmFsaWRhdG9yc1t2XS52b3RpbmdfcG93ZXIgLyBhbmFseXRpY3NEYXRhLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bVRvcFRoaXJ0eUZvdXIrKztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvdHRvbVNpeHR5U2l4UGVyY2VudCA9IDEgLSB0b3BUaGlydHlGb3VyUGVyY2VudDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Cb3R0b21TaXh0eVNpeCA9IGFjdGl2ZVZhbGlkYXRvcnMubGVuZ3RoIC0gbnVtVG9wVGhpcnR5Rm91cjtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2cERpc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Ub3BUd2VudHk6IG51bVRvcFR3ZW50eSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wVHdlbnR5UG93ZXI6IHRvcFR3ZW50eVBvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Cb3R0b21FaWdodHk6IG51bUJvdHRvbUVpZ2h0eSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm90dG9tRWlnaHR5UG93ZXI6IGJvdHRvbUVpZ2h0eVBvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Ub3BUaGlydHlGb3VyOiBudW1Ub3BUaGlydHlGb3VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3BUaGlydHlGb3VyUGVyY2VudDogdG9wVGhpcnR5Rm91clBlcmNlbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bUJvdHRvbVNpeHR5U2l4OiBudW1Cb3R0b21TaXh0eVNpeCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm90dG9tU2l4dHlTaXhQZXJjZW50OiBib3R0b21TaXh0eVNpeFBlcmNlbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bVZhbGlkYXRvcnM6IGFjdGl2ZVZhbGlkYXRvcnMubGVuZ3RoLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbFZvdGluZ1Bvd2VyOiBhbmFseXRpY3NEYXRhLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tUaW1lOiBibG9ja0RhdGEudGltZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3JlYXRlQXQ6IG5ldyBEYXRlKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh2cERpc3QpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVlBEaXN0cmlidXRpb25zLmluc2VydCh2cERpc3QpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgICAgIFNZTkNJTkcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiU3RvcHBlZFwiO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBsZXQgZW5kQmxvY2tUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlRoaXMgYmxvY2sgdXNlZDogXCIrKChlbmRCbG9ja1RpbWUtc3RhcnRCbG9ja1RpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBTWU5DSU5HID0gZmFsc2U7XG4gICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSwgeyRzZXQ6e2xhc3RCbG9ja3NTeW5jZWRUaW1lOm5ldyBEYXRlKCksIHRvdGFsVmFsaWRhdG9yczp0b3RhbFZhbGlkYXRvcnN9fSk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdW50aWw7XG4gICAgfSxcbiAgICAnYWRkTGltaXQnOiBmdW5jdGlvbihsaW1pdCkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhsaW1pdCsxMClcbiAgICAgICAgcmV0dXJuIChsaW1pdCsxMCk7XG4gICAgfSxcbiAgICAnaGFzTW9yZSc6IGZ1bmN0aW9uKGxpbWl0KSB7XG4gICAgICAgIGlmIChsaW1pdCA+IE1ldGVvci5jYWxsKCdnZXRDdXJyZW50SGVpZ2h0JykpIHtcbiAgICAgICAgICAgIHJldHVybiAoZmFsc2UpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuICh0cnVlKTtcbiAgICAgICAgfVxuICAgIH1cbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBCbG9ja3Njb24gfSBmcm9tICcuLi9ibG9ja3MuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi8uLi90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzJztcblxucHVibGlzaENvbXBvc2l0ZSgnYmxvY2tzLmhlaWdodCcsIGZ1bmN0aW9uKGxpbWl0KXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmQoe30sIHtsaW1pdDogbGltaXQsIHNvcnQ6IHtoZWlnaHQ6IC0xfX0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZChibG9jayl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWRkcmVzczpibG9jay5wcm9wb3NlckFkZHJlc3N9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2xpbWl0OjF9XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgnYmxvY2tzLmZpbmRPbmUnLCBmdW5jdGlvbihoZWlnaHQpe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZCh7aGVpZ2h0OmhlaWdodH0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZChibG9jayl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBUcmFuc2FjdGlvbnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHtoZWlnaHQ6YmxvY2suaGVpZ2h0fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKGJsb2NrKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHthZGRyZXNzOmJsb2NrLnByb3Bvc2VyQWRkcmVzc30sXG4gICAgICAgICAgICAgICAgICAgICAgICB7bGltaXQ6MX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5cbmV4cG9ydCBjb25zdCBCbG9ja3Njb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignYmxvY2tzJyk7XG5cbkJsb2Nrc2Nvbi5oZWxwZXJzKHtcbiAgICBwcm9wb3Nlcigpe1xuICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kT25lKHthZGRyZXNzOnRoaXMucHJvcG9zZXJBZGRyZXNzfSk7XG4gICAgfVxufSk7XG5cbi8vIEJsb2Nrc2Nvbi5oZWxwZXJzKHtcbi8vICAgICBzb3J0ZWQobGltaXQpIHtcbi8vICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKHt9LCB7c29ydDoge2hlaWdodDotMX0sIGxpbWl0OiBsaW1pdH0pO1xuLy8gICAgIH1cbi8vIH0pO1xuXG5cbi8vIE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpIHtcbi8vICAgICBNZXRlb3IuY2FsbCgnYmxvY2tzVXBkYXRlJywgKGVycm9yLCByZXN1bHQpID0+IHtcbi8vICAgICAgICAgY29uc29sZS5sb2cocmVzdWx0KTtcbi8vICAgICB9KVxuLy8gfSwgMzAwMDAwMDApOyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IGdldEFkZHJlc3MgfSBmcm9tICd0ZW5kZXJtaW50L2xpYi9wdWJrZXkuanMnO1xuaW1wb3J0IHsgQ2hhaW4sIENoYWluU3RhdGVzIH0gZnJvbSAnLi4vY2hhaW4uanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBWb3RpbmdQb3dlckhpc3RvcnkgfSBmcm9tICcuLi8uLi92b3RpbmctcG93ZXIvaGlzdG9yeS5qcyc7XG5cbmZpbmRWb3RpbmdQb3dlciA9ICh2YWxpZGF0b3IsIGdlblZhbGlkYXRvcnMpID0+IHtcbiAgICBmb3IgKGxldCB2IGluIGdlblZhbGlkYXRvcnMpe1xuICAgICAgICBpZiAodmFsaWRhdG9yLnB1Yl9rZXkudmFsdWUgPT0gZ2VuVmFsaWRhdG9yc1t2XS5wdWJfa2V5LnZhbHVlKXtcbiAgICAgICAgICAgIHJldHVybiBwYXJzZUludChnZW5WYWxpZGF0b3JzW3ZdLnBvd2VyKTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdjaGFpbi5nZXRDb25zZW5zdXNTdGF0ZSc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgdXJsID0gUlBDKycvZHVtcF9jb25zZW5zdXNfc3RhdGUnO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgbGV0IGNvbnNlbnN1cyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICBjb25zZW5zdXMgPSBjb25zZW5zdXMucmVzdWx0O1xuICAgICAgICAgICAgbGV0IGhlaWdodCA9IGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS5oZWlnaHQ7XG4gICAgICAgICAgICBsZXQgcm91bmQgPSBjb25zZW5zdXMucm91bmRfc3RhdGUucm91bmQ7XG4gICAgICAgICAgICBsZXQgc3RlcCA9IGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS5zdGVwO1xuICAgICAgICAgICAgbGV0IHZvdGVkUG93ZXIgPSBNYXRoLnJvdW5kKHBhcnNlRmxvYXQoY29uc2Vuc3VzLnJvdW5kX3N0YXRlLnZvdGVzW3JvdW5kXS5wcmV2b3Rlc19iaXRfYXJyYXkuc3BsaXQoXCIgXCIpWzNdKSoxMDApO1xuXG4gICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSwgeyRzZXQ6e1xuICAgICAgICAgICAgICAgIHZvdGluZ0hlaWdodDogaGVpZ2h0LFxuICAgICAgICAgICAgICAgIHZvdGluZ1JvdW5kOiByb3VuZCxcbiAgICAgICAgICAgICAgICB2b3RpbmdTdGVwOiBzdGVwLFxuICAgICAgICAgICAgICAgIHZvdGVkUG93ZXI6IHZvdGVkUG93ZXIsXG4gICAgICAgICAgICAgICAgcHJvcG9zZXJBZGRyZXNzOiBjb25zZW5zdXMucm91bmRfc3RhdGUudmFsaWRhdG9ycy5wcm9wb3Nlci5hZGRyZXNzLFxuICAgICAgICAgICAgICAgIHByZXZvdGVzOiBjb25zZW5zdXMucm91bmRfc3RhdGUudm90ZXNbcm91bmRdLnByZXZvdGVzLFxuICAgICAgICAgICAgICAgIHByZWNvbW1pdHM6IGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS52b3Rlc1tyb3VuZF0ucHJlY29tbWl0c1xuICAgICAgICAgICAgfX0pO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdjaGFpbi51cGRhdGVTdGF0dXMnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHVybCA9IFJQQysnL3N0YXR1cyc7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBsZXQgc3RhdHVzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgIHN0YXR1cyA9IHN0YXR1cy5yZXN1bHQ7XG4gICAgICAgICAgICBsZXQgY2hhaW4gPSB7fTtcbiAgICAgICAgICAgIGNoYWluLmNoYWluSWQgPSBzdGF0dXMubm9kZV9pbmZvLm5ldHdvcms7XG4gICAgICAgICAgICBjaGFpbi5sYXRlc3RCbG9ja0hlaWdodCA9IHN0YXR1cy5zeW5jX2luZm8ubGF0ZXN0X2Jsb2NrX2hlaWdodDtcbiAgICAgICAgICAgIGNoYWluLmxhdGVzdEJsb2NrVGltZSA9IHN0YXR1cy5zeW5jX2luZm8ubGF0ZXN0X2Jsb2NrX3RpbWU7XG5cbiAgICAgICAgICAgIGxldCBsYXRlc3RTdGF0ZSA9IENoYWluU3RhdGVzLmZpbmRPbmUoe30sIHtzb3J0OiB7aGVpZ2h0OiAtMX19KVxuICAgICAgICAgICAgaWYgKGxhdGVzdFN0YXRlICYmIGxhdGVzdFN0YXRlLmhlaWdodCA+PSBjaGFpbi5sYXRlc3RCbG9ja0hlaWdodCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBgbm8gdXBkYXRlcyAoZ2V0dGluZyBibG9jayAke2NoYWluLmxhdGVzdEJsb2NrSGVpZ2h0fSBhdCBibG9jayAke2xhdGVzdFN0YXRlLmhlaWdodH0pYFxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB1cmwgPSBSUEMrJy92YWxpZGF0b3JzJztcbiAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGxldCB2YWxpZGF0b3JzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgIHZhbGlkYXRvcnMgPSB2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzO1xuICAgICAgICAgICAgY2hhaW4udmFsaWRhdG9ycyA9IHZhbGlkYXRvcnMubGVuZ3RoO1xuICAgICAgICAgICAgbGV0IGFjdGl2ZVZQID0gMDtcbiAgICAgICAgICAgIGZvciAodiBpbiB2YWxpZGF0b3JzKXtcbiAgICAgICAgICAgICAgICBhY3RpdmVWUCArPSBwYXJzZUludCh2YWxpZGF0b3JzW3ZdLnZvdGluZ19wb3dlcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjaGFpbi5hY3RpdmVWb3RpbmdQb3dlciA9IGFjdGl2ZVZQO1xuXG5cbiAgICAgICAgICAgIENoYWluLnVwZGF0ZSh7Y2hhaW5JZDpjaGFpbi5jaGFpbklkfSwgeyRzZXQ6Y2hhaW59LCB7dXBzZXJ0OiB0cnVlfSk7XG4gICAgICAgICAgICAvLyBHZXQgY2hhaW4gc3RhdGVzXG4gICAgICAgICAgICBpZiAocGFyc2VJbnQoY2hhaW4ubGF0ZXN0QmxvY2tIZWlnaHQpID4gMCl7XG4gICAgICAgICAgICAgICAgbGV0IGNoYWluU3RhdGVzID0ge307XG4gICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMuaGVpZ2h0ID0gcGFyc2VJbnQoc3RhdHVzLnN5bmNfaW5mby5sYXRlc3RfYmxvY2tfaGVpZ2h0KTtcbiAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy50aW1lID0gbmV3IERhdGUoc3RhdHVzLnN5bmNfaW5mby5sYXRlc3RfYmxvY2tfdGltZSk7XG5cbiAgICAgICAgICAgICAgICB1cmwgPSBMQ0QgKyAnL3N0YWtpbmcvcG9vbCc7XG4gICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBib25kaW5nID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNoYWluLmJvbmRlZFRva2VucyA9IGJvbmRpbmcuYm9uZGVkX3Rva2VucztcbiAgICAgICAgICAgICAgICAgICAgLy8gY2hhaW4ubm90Qm9uZGVkVG9rZW5zID0gYm9uZGluZy5ub3RfYm9uZGVkX3Rva2VucztcbiAgICAgICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMuYm9uZGVkVG9rZW5zID0gcGFyc2VJbnQoYm9uZGluZy5ib25kZWRfdG9rZW5zKTtcbiAgICAgICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMubm90Qm9uZGVkVG9rZW5zID0gcGFyc2VJbnQoYm9uZGluZy5ub3RfYm9uZGVkX3Rva2Vucyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB1cmwgPSBMQ0QgKyAnL3N1cHBseS90b3RhbC8nK01ldGVvci5zZXR0aW5ncy5wdWJsaWMubWludGluZ0Rlbm9tO1xuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgc3VwcGx5ID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLnRvdGFsU3VwcGx5ID0gcGFyc2VJbnQoc3VwcGx5KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHVybCA9IExDRCArICcvZGlzdHJpYnV0aW9uL2NvbW11bml0eV9wb29sJztcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBwb29sID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwb29sICYmIHBvb2wubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5jb21tdW5pdHlQb29sID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICBwb29sLmZvckVhY2goKGFtb3VudCwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLmNvbW11bml0eVBvb2wucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbm9tOiBhbW91bnQuZGVub20sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFtb3VudDogcGFyc2VGbG9hdChhbW91bnQuYW1vdW50KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB1cmwgPSBMQ0QgKyAnL21pbnRpbmcvaW5mbGF0aW9uJztcbiAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGluZmxhdGlvbiA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICBpZiAoaW5mbGF0aW9uKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLmluZmxhdGlvbiA9IHBhcnNlRmxvYXQoaW5mbGF0aW9uKVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB1cmwgPSBMQ0QgKyAnL21pbnRpbmcvYW5udWFsLXByb3Zpc2lvbnMnO1xuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgcHJvdmlzaW9ucyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm92aXNpb25zKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLmFubnVhbFByb3Zpc2lvbnMgPSBwYXJzZUZsb2F0KHByb3Zpc2lvbnMucmVzdWx0KVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBDaGFpblN0YXRlcy5pbnNlcnQoY2hhaW5TdGF0ZXMpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBjaGFpbi50b3RhbFZvdGluZ1Bvd2VyID0gdG90YWxWUDtcblxuICAgICAgICAgICAgLy8gdmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7fSkuZmV0Y2goKTtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHZhbGlkYXRvcnMpO1xuICAgICAgICAgICAgcmV0dXJuIGNoYWluLmxhdGVzdEJsb2NrSGVpZ2h0O1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgcmV0dXJuIFwiRXJyb3IgZ2V0dGluZyBjaGFpbiBzdGF0dXMuXCI7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdjaGFpbi5nZXRMYXRlc3RTdGF0dXMnOiBmdW5jdGlvbigpe1xuICAgICAgICBDaGFpbi5maW5kKCkuc29ydCh7Y3JlYXRlZDotMX0pLmxpbWl0KDEpO1xuICAgIH0sXG4gICAgJ2NoYWluLmdlbmVzaXMnOiBmdW5jdGlvbigpe1xuICAgICAgICBsZXQgY2hhaW4gPSBDaGFpbi5maW5kT25lKHtjaGFpbklkOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9KTtcblxuICAgICAgICBpZiAoY2hhaW4gJiYgY2hhaW4ucmVhZEdlbmVzaXMpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ0dlbmVzaXMgZmlsZSBoYXMgYmVlbiBwcm9jZXNzZWQnKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChNZXRlb3Iuc2V0dGluZ3MuZGVidWcucmVhZEdlbmVzaXMpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCc9PT0gU3RhcnQgcHJvY2Vzc2luZyBnZW5lc2lzIGZpbGUgPT09Jyk7XG4gICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldChNZXRlb3Iuc2V0dGluZ3MuZ2VuZXNpc0ZpbGUpO1xuICAgICAgICAgICAgbGV0IGdlbmVzaXMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgbGV0IGRpc3RyID0gZ2VuZXNpcy5hcHBfc3RhdGUuZGlzdHIgfHwgZ2VuZXNpcy5hcHBfc3RhdGUuZGlzdHJpYnV0aW9uXG4gICAgICAgICAgICBsZXQgY2hhaW5QYXJhbXMgPSB7XG4gICAgICAgICAgICAgICAgY2hhaW5JZDogZ2VuZXNpcy5jaGFpbl9pZCxcbiAgICAgICAgICAgICAgICBnZW5lc2lzVGltZTogZ2VuZXNpcy5nZW5lc2lzX3RpbWUsXG4gICAgICAgICAgICAgICAgY29uc2Vuc3VzUGFyYW1zOiBnZW5lc2lzLmNvbnNlbnN1c19wYXJhbXMsXG4gICAgICAgICAgICAgICAgYXV0aDogZ2VuZXNpcy5hcHBfc3RhdGUuYXV0aCxcbiAgICAgICAgICAgICAgICBiYW5rOiBnZW5lc2lzLmFwcF9zdGF0ZS5iYW5rLFxuICAgICAgICAgICAgICAgIHN0YWtpbmc6IHtcbiAgICAgICAgICAgICAgICAgICAgcG9vbDogZ2VuZXNpcy5hcHBfc3RhdGUuc3Rha2luZy5wb29sLFxuICAgICAgICAgICAgICAgICAgICBwYXJhbXM6IGdlbmVzaXMuYXBwX3N0YXRlLnN0YWtpbmcucGFyYW1zXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBtaW50OiBnZW5lc2lzLmFwcF9zdGF0ZS5taW50LFxuICAgICAgICAgICAgICAgIGRpc3RyOiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbW11bml0eVRheDogZGlzdHIuY29tbXVuaXR5X3RheCxcbiAgICAgICAgICAgICAgICAgICAgYmFzZVByb3Bvc2VyUmV3YXJkOiBkaXN0ci5iYXNlX3Byb3Bvc2VyX3Jld2FyZCxcbiAgICAgICAgICAgICAgICAgICAgYm9udXNQcm9wb3NlclJld2FyZDogZGlzdHIuYm9udXNfcHJvcG9zZXJfcmV3YXJkLFxuICAgICAgICAgICAgICAgICAgICB3aXRoZHJhd0FkZHJFbmFibGVkOiBkaXN0ci53aXRoZHJhd19hZGRyX2VuYWJsZWRcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGdvdjogbnVsbCxcbiAgICAgICAgICAgICAgICBzbGFzaGluZzp7XG4gICAgICAgICAgICAgICAgICAgIHBhcmFtczogZ2VuZXNpcy5hcHBfc3RhdGUuc2xhc2hpbmcucGFyYW1zXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBzdXBwbHk6IGdlbmVzaXMuYXBwX3N0YXRlLnN1cHBseSxcbiAgICAgICAgICAgICAgICBjcmlzaXM6IGdlbmVzaXMuYXBwX3N0YXRlLmNyaXNpc1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBsZXQgdG90YWxWb3RpbmdQb3dlciA9IDA7XG5cbiAgICAgICAgICAgIC8vIHJlYWQgZ2VudHhcbiAgICAgICAgICAgIGlmIChnZW5lc2lzLmFwcF9zdGF0ZS5nZW51dGlsICYmIGdlbmVzaXMuYXBwX3N0YXRlLmdlbnV0aWwuZ2VudHhzICYmIChnZW5lc2lzLmFwcF9zdGF0ZS5nZW51dGlsLmdlbnR4cy5sZW5ndGggPiAwKSl7XG4gICAgICAgICAgICAgICAgZm9yIChpIGluIGdlbmVzaXMuYXBwX3N0YXRlLmdlbnV0aWwuZ2VudHhzKXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IG1zZyA9IGdlbmVzaXMuYXBwX3N0YXRlLmdlbnV0aWwuZ2VudHhzW2ldLnZhbHVlLm1zZztcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2cobXNnLnR5cGUpO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKG0gaW4gbXNnKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChtc2dbbV0udHlwZSA9PSBcImNvc21vcy1zZGsvTXNnQ3JlYXRlVmFsaWRhdG9yXCIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKG1zZ1ttXS52YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGV0IGNvbW1hbmQgPSBNZXRlb3Iuc2V0dGluZ3MuYmluLmdhaWFkZWJ1ZytcIiBwdWJrZXkgXCIrbXNnW21dLnZhbHVlLnB1YmtleTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zZW5zdXNfcHVia2V5OiBtc2dbbV0udmFsdWUucHVia2V5LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogbXNnW21dLnZhbHVlLmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb21taXNzaW9uOiBtc2dbbV0udmFsdWUuY29tbWlzc2lvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluX3NlbGZfZGVsZWdhdGlvbjogbXNnW21dLnZhbHVlLm1pbl9zZWxmX2RlbGVnYXRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wZXJhdG9yX2FkZHJlc3M6IG1zZ1ttXS52YWx1ZS52YWxpZGF0b3JfYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZWdhdG9yX2FkZHJlc3M6IG1zZ1ttXS52YWx1ZS5kZWxlZ2F0b3JfYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiBNYXRoLmZsb29yKHBhcnNlSW50KG1zZ1ttXS52YWx1ZS52YWx1ZS5hbW91bnQpIC8gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5zdGFraW5nRnJhY3Rpb24pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqYWlsZWQ6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IDJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbFZvdGluZ1Bvd2VyICs9IHZhbGlkYXRvci52b3RpbmdfcG93ZXI7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHVia2V5VmFsdWUgPSBNZXRlb3IuY2FsbCgnYmVjaDMyVG9QdWJrZXknLCBtc2dbbV0udmFsdWUucHVia2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBWYWxpZGF0b3JzLnVwc2VydCh7Y29uc2Vuc3VzX3B1YmtleTptc2dbbV0udmFsdWUucHVia2V5fSx2YWxpZGF0b3IpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnB1Yl9rZXkgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwidHlwZVwiOlwidGVuZGVybWludC9QdWJLZXlFZDI1NTE5XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwidmFsdWVcIjpwdWJrZXlWYWx1ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5hZGRyZXNzID0gZ2V0QWRkcmVzcyh2YWxpZGF0b3IucHViX2tleSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFjY3B1YiA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbGlkYXRvci5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY1B1Yik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLm9wZXJhdG9yX3B1YmtleSA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbGlkYXRvci5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeFZhbFB1Yik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVm90aW5nUG93ZXJIaXN0b3J5Lmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IHZhbGlkYXRvci5hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmV2X3ZvdGluZ19wb3dlcjogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnYWRkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja190aW1lOiBnZW5lc2lzLmdlbmVzaXNfdGltZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVmFsaWRhdG9ycy5pbnNlcnQodmFsaWRhdG9yKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gcmVhZCB2YWxpZGF0b3JzIGZyb20gcHJldmlvdXMgY2hhaW5cbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdyZWFkIHZhbGlkYXRvcnMgZnJvbSBwcmV2aW91cyBjaGFpbicpO1xuICAgICAgICAgICAgaWYgKGdlbmVzaXMuYXBwX3N0YXRlLnN0YWtpbmcudmFsaWRhdG9ycyAmJiBnZW5lc2lzLmFwcF9zdGF0ZS5zdGFraW5nLnZhbGlkYXRvcnMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZ2VuZXNpcy5hcHBfc3RhdGUuc3Rha2luZy52YWxpZGF0b3JzLmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgbGV0IGdlblZhbGlkYXRvcnNTZXQgPSBnZW5lc2lzLmFwcF9zdGF0ZS5zdGFraW5nLnZhbGlkYXRvcnM7XG4gICAgICAgICAgICAgICAgbGV0IGdlblZhbGlkYXRvcnMgPSBnZW5lc2lzLnZhbGlkYXRvcnM7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgdiBpbiBnZW5WYWxpZGF0b3JzU2V0KXtcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coZ2VuVmFsaWRhdG9yc1t2XSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3IgPSBnZW5WYWxpZGF0b3JzU2V0W3ZdO1xuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuZGVsZWdhdG9yX2FkZHJlc3MgPSBNZXRlb3IuY2FsbCgnZ2V0RGVsZWdhdG9yJywgZ2VuVmFsaWRhdG9yc1NldFt2XS5vcGVyYXRvcl9hZGRyZXNzKTtcblxuICAgICAgICAgICAgICAgICAgICBsZXQgcHVia2V5VmFsdWUgPSBNZXRlb3IuY2FsbCgnYmVjaDMyVG9QdWJrZXknLCB2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleSk7XG5cbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnB1Yl9rZXkgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBcInR5cGVcIjpcInRlbmRlcm1pbnQvUHViS2V5RWQyNTUxOVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJ2YWx1ZVwiOnB1YmtleVZhbHVlXG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYWRkcmVzcyA9IGdldEFkZHJlc3ModmFsaWRhdG9yLnB1Yl9rZXkpO1xuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHViX2tleSA9IHZhbGlkYXRvci5wdWJfa2V5O1xuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYWNjcHViID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4QWNjUHViKTtcbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLm9wZXJhdG9yX3B1YmtleSA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbGlkYXRvci5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeFZhbFB1Yik7XG5cbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnZvdGluZ19wb3dlciA9IGZpbmRWb3RpbmdQb3dlcih2YWxpZGF0b3IsIGdlblZhbGlkYXRvcnMpO1xuICAgICAgICAgICAgICAgICAgICB0b3RhbFZvdGluZ1Bvd2VyICs9IHZhbGlkYXRvci52b3RpbmdfcG93ZXI7XG5cbiAgICAgICAgICAgICAgICAgICAgVmFsaWRhdG9ycy51cHNlcnQoe2NvbnNlbnN1c19wdWJrZXk6dmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXl9LHZhbGlkYXRvcik7XG4gICAgICAgICAgICAgICAgICAgIFZvdGluZ1Bvd2VySGlzdG9yeS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogdmFsaWRhdG9yLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICBwcmV2X3ZvdGluZ19wb3dlcjogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogdmFsaWRhdG9yLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdhZGQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogZ2VuZXNpcy5nZW5lc2lzX3RpbWVcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBjaGFpblBhcmFtcy5yZWFkR2VuZXNpcyA9IHRydWU7XG4gICAgICAgICAgICBjaGFpblBhcmFtcy5hY3RpdmVWb3RpbmdQb3dlciA9IHRvdGFsVm90aW5nUG93ZXI7XG4gICAgICAgICAgICBsZXQgcmVzdWx0ID0gQ2hhaW4udXBzZXJ0KHtjaGFpbklkOmNoYWluUGFyYW1zLmNoYWluSWR9LCB7JHNldDpjaGFpblBhcmFtc30pO1xuXG5cbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCc9PT0gRmluaXNoZWQgcHJvY2Vzc2luZyBnZW5lc2lzIGZpbGUgPT09Jyk7XG5cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IENoYWluLCBDaGFpblN0YXRlcyB9IGZyb20gJy4uL2NoYWluLmpzJztcbmltcG9ydCB7IENvaW5TdGF0cyB9IGZyb20gJy4uLy4uL2NvaW4tc3RhdHMvY29pbi1zdGF0cy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcblxuTWV0ZW9yLnB1Ymxpc2goJ2NoYWluU3RhdGVzLmxhdGVzdCcsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gW1xuICAgICAgICBDaGFpblN0YXRlcy5maW5kKHt9LHtzb3J0OntoZWlnaHQ6LTF9LGxpbWl0OjF9KSxcbiAgICAgICAgQ29pblN0YXRzLmZpbmQoe30se3NvcnQ6e2xhc3RfdXBkYXRlZF9hdDotMX0sbGltaXQ6MX0pXG4gICAgXTtcbn0pO1xuXG5wdWJsaXNoQ29tcG9zaXRlKCdjaGFpbi5zdGF0dXMnLCBmdW5jdGlvbigpe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBDaGFpbi5maW5kKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0pO1xuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQoY2hhaW4pe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge30sXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmllbGRzOntcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOjEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246MSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcGVyYXRvcl9hZGRyZXNzOjEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOi0xLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGphaWxlZDoxLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb2ZpbGVfdXJsOjFcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTsiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcblxuZXhwb3J0IGNvbnN0IENoYWluID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NoYWluJyk7XG5leHBvcnQgY29uc3QgQ2hhaW5TdGF0ZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY2hhaW5fc3RhdGVzJylcblxuQ2hhaW4uaGVscGVycyh7XG4gICAgcHJvcG9zZXIoKXtcbiAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZE9uZSh7YWRkcmVzczp0aGlzLnByb3Bvc2VyQWRkcmVzc30pO1xuICAgIH1cbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBDb2luU3RhdHMgfSBmcm9tICcuLi9jb2luLXN0YXRzLmpzJztcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnY29pblN0YXRzLmdldENvaW5TdGF0cyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgY29pbklkID0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jb2luZ2Vja29JZDtcbiAgICAgICAgaWYgKGNvaW5JZCl7XG4gICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgbGV0IG5vdyA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgbm93LnNldE1pbnV0ZXMoMCk7XG4gICAgICAgICAgICAgICAgbGV0IHVybCA9IFwiaHR0cHM6Ly9hcGkuY29pbmdlY2tvLmNvbS9hcGkvdjMvc2ltcGxlL3ByaWNlP2lkcz1cIitjb2luSWQrXCImdnNfY3VycmVuY2llcz11c2QmaW5jbHVkZV9tYXJrZXRfY2FwPXRydWUmaW5jbHVkZV8yNGhyX3ZvbD10cnVlJmluY2x1ZGVfMjRocl9jaGFuZ2U9dHJ1ZSZpbmNsdWRlX2xhc3RfdXBkYXRlZF9hdD10cnVlXCI7XG4gICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGEgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgICAgICBkYXRhID0gZGF0YVtjb2luSWRdO1xuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhjb2luU3RhdHMpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQ29pblN0YXRzLnVwc2VydCh7bGFzdF91cGRhdGVkX2F0OmRhdGEubGFzdF91cGRhdGVkX2F0fSwgeyRzZXQ6ZGF0YX0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICByZXR1cm4gXCJObyBjb2luZ2Vja28gSWQgcHJvdmlkZWQuXCJcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ2NvaW5TdGF0cy5nZXRTdGF0cyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgY29pbklkID0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jb2luZ2Vja29JZDtcbiAgICAgICAgaWYgKGNvaW5JZCl7XG4gICAgICAgICAgICByZXR1cm4gKENvaW5TdGF0cy5maW5kT25lKHt9LHtzb3J0OntsYXN0X3VwZGF0ZWRfYXQ6LTF9fSkpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICByZXR1cm4gXCJObyBjb2luZ2Vja28gSWQgcHJvdmlkZWQuXCI7XG4gICAgICAgIH1cblxuICAgIH1cbn0pIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgQ29pblN0YXRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NvaW5fc3RhdHMnKTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgRGVsZWdhdGlvbnMgfSBmcm9tICcuLi9kZWxlZ2F0aW9ucy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdkZWxlZ2F0aW9ucy5nZXREZWxlZ2F0aW9ucyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgdmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7fSkuZmV0Y2goKTtcbiAgICAgICAgbGV0IGRlbGVnYXRpb25zID0gW107XG4gICAgICAgIGNvbnNvbGUubG9nKFwiPT09IEdldHRpbmcgZGVsZWdhdGlvbnMgPT09XCIpO1xuICAgICAgICBmb3IgKHYgaW4gdmFsaWRhdG9ycyl7XG4gICAgICAgICAgICBpZiAodmFsaWRhdG9yc1t2XS5vcGVyYXRvcl9hZGRyZXNzKXtcbiAgICAgICAgICAgICAgICBsZXQgdXJsID0gTENEICsgJy9zdGFraW5nL3ZhbGlkYXRvcnMvJyt2YWxpZGF0b3JzW3ZdLm9wZXJhdG9yX2FkZHJlc3MrXCIvZGVsZWdhdGlvbnNcIjtcbiAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZGVsZWdhdGlvbiA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coZGVsZWdhdGlvbik7XG4gICAgICAgICAgICAgICAgICAgICAgICBkZWxlZ2F0aW9ucyA9IGRlbGVnYXRpb25zLmNvbmNhdChkZWxlZ2F0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNle1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2Uuc3RhdHVzQ29kZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgICAgICB9ICAgIFxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgZm9yIChpIGluIGRlbGVnYXRpb25zKXtcbiAgICAgICAgICAgIGlmIChkZWxlZ2F0aW9uc1tpXSAmJiBkZWxlZ2F0aW9uc1tpXS5zaGFyZXMpXG4gICAgICAgICAgICAgICAgZGVsZWdhdGlvbnNbaV0uc2hhcmVzID0gcGFyc2VGbG9hdChkZWxlZ2F0aW9uc1tpXS5zaGFyZXMpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gY29uc29sZS5sb2coZGVsZWdhdGlvbnMpO1xuICAgICAgICBsZXQgZGF0YSA9IHtcbiAgICAgICAgICAgIGRlbGVnYXRpb25zOiBkZWxlZ2F0aW9ucyxcbiAgICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBEZWxlZ2F0aW9ucy5pbnNlcnQoZGF0YSk7XG4gICAgfVxuICAgIC8vICdibG9ja3MuYXZlcmFnZUJsb2NrVGltZScoYWRkcmVzcyl7XG4gICAgLy8gICAgIGxldCBibG9ja3MgPSBCbG9ja3Njb24uZmluZCh7cHJvcG9zZXJBZGRyZXNzOmFkZHJlc3N9KS5mZXRjaCgpO1xuICAgIC8vICAgICBsZXQgaGVpZ2h0cyA9IGJsb2Nrcy5tYXAoKGJsb2NrLCBpKSA9PiB7XG4gICAgLy8gICAgICAgICByZXR1cm4gYmxvY2suaGVpZ2h0O1xuICAgIC8vICAgICB9KTtcbiAgICAvLyAgICAgbGV0IGJsb2Nrc1N0YXRzID0gQW5hbHl0aWNzLmZpbmQoe2hlaWdodDp7JGluOmhlaWdodHN9fSkuZmV0Y2goKTtcbiAgICAvLyAgICAgLy8gY29uc29sZS5sb2coYmxvY2tzU3RhdHMpO1xuXG4gICAgLy8gICAgIGxldCB0b3RhbEJsb2NrRGlmZiA9IDA7XG4gICAgLy8gICAgIGZvciAoYiBpbiBibG9ja3NTdGF0cyl7XG4gICAgLy8gICAgICAgICB0b3RhbEJsb2NrRGlmZiArPSBibG9ja3NTdGF0c1tiXS50aW1lRGlmZjtcbiAgICAvLyAgICAgfVxuICAgIC8vICAgICByZXR1cm4gdG90YWxCbG9ja0RpZmYvaGVpZ2h0cy5sZW5ndGg7XG4gICAgLy8gfVxufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBEZWxlZ2F0aW9ucyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdkZWxlZ2F0aW9ucycpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuaW1wb3J0IHsgRW50ZXJwcmlzZSB9IGZyb20gJy4uL2VudGVycHJpc2UuanMnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ2VudGVycHJpc2UuZ2V0UHVyY2hhc2VPcmRlcnMnOiBmdW5jdGlvbigpe1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IHVybCA9IExDRCArICcvZW50ZXJwcmlzZS9wb3MnO1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGxldCBwdXJjaGFzZU9yZGVycyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuXG4gICAgICAgICAgICBsZXQgZmluaXNoZWRQdXJjaGFzZU9yZGVycyA9IG5ldyBTZXQoRW50ZXJwcmlzZS5maW5kKFxuICAgICAgICAgICAgICAgIHtcInN0YXR1c1wiOnskaW46W1wicmVqZWN0XCIsIFwiY29tcGxldGVcIl19fVxuICAgICAgICAgICAgKS5mZXRjaCgpLm1hcCgocCk9PiBwLnBvSWQpKTtcblxuICAgICAgICAgICAgbGV0IHBvSWRzID0gW107XG5cbiAgICAgICAgICAgIGlmIChwdXJjaGFzZU9yZGVycy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgYnVsa1BvcyA9IEVudGVycHJpc2UucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AoKTtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpIGluIHB1cmNoYXNlT3JkZXJzKSB7XG4gICAgICAgICAgICAgICAgICAgIGxldCBwbyA9IHB1cmNoYXNlT3JkZXJzW2ldXG4gICAgICAgICAgICAgICAgICAgIHBvLnBvSWQgPSBwYXJzZUludChwby5pZCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwby5wb0lkID4gMCAmJiAhZmluaXNoZWRQdXJjaGFzZU9yZGVycy5oYXMocG8ucG9JZCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1Bvcy5maW5kKHtwb0lkOiBwby5wb0lkfSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OiBwb30pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvSWRzLnB1c2gocG8ucG9JZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrUG9zLmZpbmQoe3BvSWQ6IHBvLnBvSWR9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6IHBvfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9JZHMucHVzaChwby5wb0lkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlLnJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmKHBvSWRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgYnVsa1Bvcy5leGVjdXRlKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgfVxuICAgIH1cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEVudGVycHJpc2UgfSBmcm9tICcuLi9lbnRlcnByaXNlLmpzJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJ1xuXG5NZXRlb3IucHVibGlzaCgnZW50ZXJwcmlzZS5saXN0X3BvcycsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gRW50ZXJwcmlzZS5maW5kKHt9LCB7c29ydDp7cG9JZDotMX19KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaCgnZW50ZXJwcmlzZS5vbmVfcG8nLCBmdW5jdGlvbiAoaWQpe1xuICAgIGNoZWNrKGlkLCBOdW1iZXIpO1xuICAgIHJldHVybiBFbnRlcnByaXNlLmZpbmQoe3BvSWQ6aWR9KTtcbn0pIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgRW50ZXJwcmlzZSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdlbnRlcnByaXNlJyk7XG4iLCJpbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ3RyYW5zYWN0aW9uLnN1Ym1pdCc6IGZ1bmN0aW9uKHR4SW5mbykge1xuICAgICAgICBjb25zdCB1cmwgPSBgJHtMQ0R9L3R4c2A7XG4gICAgICAgIGRhdGEgPSB7XG4gICAgICAgICAgICBcInR4XCI6IHR4SW5mby52YWx1ZSxcbiAgICAgICAgICAgIFwibW9kZVwiOiBcInN5bmNcIlxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHRpbWVzdGFtcCA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xuICAgICAgICBjb25zb2xlLmxvZyhgc3VibWl0dGluZyB0cmFuc2FjdGlvbiR7dGltZXN0YW1wfSAke3VybH0gd2l0aCBkYXRhICR7SlNPTi5zdHJpbmdpZnkoZGF0YSl9YClcblxuICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLnBvc3QodXJsLCB7ZGF0YX0pO1xuICAgICAgICBjb25zb2xlLmxvZyhgcmVzcG9uc2UgZm9yIHRyYW5zYWN0aW9uJHt0aW1lc3RhbXB9ICR7dXJsfTogJHtKU09OLnN0cmluZ2lmeShyZXNwb25zZSl9YClcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKSB7XG4gICAgICAgICAgICBsZXQgZGF0YSA9IHJlc3BvbnNlLmRhdGFcbiAgICAgICAgICAgIGlmIChkYXRhLmNvZGUpXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihkYXRhLmNvZGUsIEpTT04ucGFyc2UoZGF0YS5yYXdfbG9nKS5tZXNzYWdlKVxuICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGEudHhoYXNoO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAndHJhbnNhY3Rpb24uZXhlY3V0ZSc6IGZ1bmN0aW9uKGJvZHksIHBhdGgpIHtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7TENEfS8ke3BhdGh9YDtcbiAgICAgICAgZGF0YSA9IHtcbiAgICAgICAgICAgIFwiYmFzZV9yZXFcIjoge1xuICAgICAgICAgICAgICAgIC4uLmJvZHksXG4gICAgICAgICAgICAgICAgXCJjaGFpbl9pZFwiOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWQsXG4gICAgICAgICAgICAgICAgXCJzaW11bGF0ZVwiOiBmYWxzZVxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLnBvc3QodXJsLCB7ZGF0YX0pO1xuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApIHtcbiAgICAgICAgICAgIHJldHVybiBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAndHJhbnNhY3Rpb24uc2ltdWxhdGUnOiBmdW5jdGlvbih0eE1zZywgZnJvbSwgcGF0aCwgYWRqdXN0bWVudD0nMS4yJykge1xuICAgICAgICBjb25zdCB1cmwgPSBgJHtMQ0R9LyR7cGF0aH1gO1xuICAgICAgICBkYXRhID0gey4uLnR4TXNnLFxuICAgICAgICAgICAgXCJiYXNlX3JlcVwiOiB7XG4gICAgICAgICAgICAgICAgXCJmcm9tXCI6IGZyb20sXG4gICAgICAgICAgICAgICAgXCJjaGFpbl9pZFwiOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWQsXG4gICAgICAgICAgICAgICAgXCJnYXNfYWRqdXN0bWVudFwiOiBhZGp1c3RtZW50LFxuICAgICAgICAgICAgICAgIFwic2ltdWxhdGVcIjogdHJ1ZVxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLnBvc3QodXJsLCB7ZGF0YX0pO1xuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApIHtcbiAgICAgICAgICAgIHJldHVybiBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLmdhc19lc3RpbWF0ZTtcbiAgICAgICAgfVxuICAgIH0sXG59KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgVmFsaWRhdG9yUmVjb3JkcywgQW5hbHl0aWNzLCBBdmVyYWdlRGF0YSwgQXZlcmFnZVZhbGlkYXRvckRhdGEgfSBmcm9tICcuLi9yZWNvcmRzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9yU2V0cyB9IGZyb20gJy9pbXBvcnRzL2FwaS92YWxpZGF0b3Itc2V0cy92YWxpZGF0b3Itc2V0cy5qcyc7XG5pbXBvcnQgeyBTdGF0dXMgfSBmcm9tICcuLi8uLi9zdGF0dXMvc3RhdHVzLmpzJztcbmltcG9ydCB7IE1pc3NlZEJsb2Nrc1N0YXRzIH0gZnJvbSAnLi4vcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBNaXNzZWRCbG9ja3MgfSBmcm9tICcuLi9yZWNvcmRzLmpzJztcbmltcG9ydCB7IEJsb2Nrc2NvbiB9IGZyb20gJy4uLy4uL2Jsb2Nrcy9ibG9ja3MuanMnO1xuaW1wb3J0IHsgQ2hhaW4gfSBmcm9tICcuLi8uLi9jaGFpbi9jaGFpbi5qcyc7XG5pbXBvcnQgXyBmcm9tICdsb2Rhc2gnO1xuY29uc3QgQlVMS1VQREFURU1BWFNJWkUgPSAxMDAwO1xuXG5jb25zdCBnZXRCbG9ja1N0YXRzID0gKHN0YXJ0SGVpZ2h0LCBsYXRlc3RIZWlnaHQpID0+IHtcbiAgICBsZXQgYmxvY2tTdGF0cyA9IHt9O1xuICAgIGNvbnN0IGNvbmQgPSB7JGFuZDogW1xuICAgICAgICB7IGhlaWdodDogeyAkZ3Q6IHN0YXJ0SGVpZ2h0IH0gfSxcbiAgICAgICAgeyBoZWlnaHQ6IHsgJGx0ZTogbGF0ZXN0SGVpZ2h0IH0gfSBdfTtcbiAgICBjb25zdCBvcHRpb25zID0ge3NvcnQ6e2hlaWdodDogMX19O1xuICAgIEJsb2Nrc2Nvbi5maW5kKGNvbmQsIG9wdGlvbnMpLmZvckVhY2goKGJsb2NrKSA9PiB7XG4gICAgICAgIGJsb2NrU3RhdHNbYmxvY2suaGVpZ2h0XSA9IHtcbiAgICAgICAgICAgIGhlaWdodDogYmxvY2suaGVpZ2h0LFxuICAgICAgICAgICAgcHJvcG9zZXJBZGRyZXNzOiBibG9jay5wcm9wb3NlckFkZHJlc3MsXG4gICAgICAgICAgICBwcmVjb21taXRzQ291bnQ6IGJsb2NrLnByZWNvbW1pdHNDb3VudCxcbiAgICAgICAgICAgIHZhbGlkYXRvcnNDb3VudDogYmxvY2sudmFsaWRhdG9yc0NvdW50LFxuICAgICAgICAgICAgdmFsaWRhdG9yczogYmxvY2sudmFsaWRhdG9ycyxcbiAgICAgICAgICAgIHRpbWU6IGJsb2NrLnRpbWVcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgQW5hbHl0aWNzLmZpbmQoY29uZCwgb3B0aW9ucykuZm9yRWFjaCgoYmxvY2spID0+IHtcbiAgICAgICAgaWYgKCFibG9ja1N0YXRzW2Jsb2NrLmhlaWdodF0pIHtcbiAgICAgICAgICAgIGJsb2NrU3RhdHNbYmxvY2suaGVpZ2h0XSA9IHsgaGVpZ2h0OiBibG9jay5oZWlnaHQgfTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBibG9jayAke2Jsb2NrLmhlaWdodH0gZG9lcyBub3QgaGF2ZSBhbiBlbnRyeWApO1xuICAgICAgICB9XG4gICAgICAgIF8uYXNzaWduKGJsb2NrU3RhdHNbYmxvY2suaGVpZ2h0XSwge1xuICAgICAgICAgICAgcHJlY29tbWl0czogYmxvY2sucHJlY29tbWl0cyxcbiAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGJsb2NrLmF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICB0aW1lRGlmZjogYmxvY2sudGltZURpZmYsXG4gICAgICAgICAgICB2b3RpbmdfcG93ZXI6IGJsb2NrLnZvdGluZ19wb3dlclxuICAgICAgICB9KTtcbiAgICB9KTtcbiAgICByZXR1cm4gYmxvY2tTdGF0cztcbn1cblxuY29uc3QgZ2V0UHJldmlvdXNSZWNvcmQgPSAodm90ZXJBZGRyZXNzLCBwcm9wb3NlckFkZHJlc3MpID0+IHtcbiAgICBsZXQgcHJldmlvdXNSZWNvcmQgPSBNaXNzZWRCbG9ja3MuZmluZE9uZShcbiAgICAgICAge3ZvdGVyOnZvdGVyQWRkcmVzcywgcHJvcG9zZXI6cHJvcG9zZXJBZGRyZXNzLCBibG9ja0hlaWdodDogLTF9KTtcbiAgICBsZXQgbGFzdFVwZGF0ZWRIZWlnaHQgPSBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLnN0YXJ0SGVpZ2h0O1xuICAgIGxldCBwcmV2U3RhdHMgPSB7fTtcbiAgICBpZiAocHJldmlvdXNSZWNvcmQpIHtcbiAgICAgICAgcHJldlN0YXRzID0gXy5waWNrKHByZXZpb3VzUmVjb3JkLCBbJ21pc3NDb3VudCcsICd0b3RhbENvdW50J10pO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIHByZXZTdGF0cyA9IHtcbiAgICAgICAgICAgIG1pc3NDb3VudDogMCxcbiAgICAgICAgICAgIHRvdGFsQ291bnQ6IDBcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcHJldlN0YXRzO1xufVxuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ1ZhbGlkYXRvclJlY29yZHMuY2FsY3VsYXRlTWlzc2VkQmxvY2tzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgaWYgKCFDT1VOVE1JU1NFREJMT0NLUyl7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGxldCBzdGFydFRpbWUgPSBEYXRlLm5vdygpO1xuICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnY2FsdWxhdGUgbWlzc2VkIGJsb2NrcyBjb3VudCcpO1xuICAgICAgICAgICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3JzID0gVmFsaWRhdG9ycy5maW5kKHt9KS5mZXRjaCgpO1xuICAgICAgICAgICAgICAgIGxldCBsYXRlc3RIZWlnaHQgPSBNZXRlb3IuY2FsbCgnYmxvY2tzLmdldEN1cnJlbnRIZWlnaHQnKTtcbiAgICAgICAgICAgICAgICBsZXQgZXhwbG9yZXJTdGF0dXMgPSBTdGF0dXMuZmluZE9uZSh7Y2hhaW5JZDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSk7XG4gICAgICAgICAgICAgICAgbGV0IHN0YXJ0SGVpZ2h0ID0gKGV4cGxvcmVyU3RhdHVzJiZleHBsb3JlclN0YXR1cy5sYXN0UHJvY2Vzc2VkTWlzc2VkQmxvY2tIZWlnaHQpP2V4cGxvcmVyU3RhdHVzLmxhc3RQcm9jZXNzZWRNaXNzZWRCbG9ja0hlaWdodDpNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLnN0YXJ0SGVpZ2h0O1xuICAgICAgICAgICAgICAgIGxhdGVzdEhlaWdodCA9IE1hdGgubWluKHN0YXJ0SGVpZ2h0ICsgQlVMS1VQREFURU1BWFNJWkUsIGxhdGVzdEhlaWdodCk7XG4gICAgICAgICAgICAgICAgY29uc3QgYnVsa01pc3NlZFN0YXRzID0gTWlzc2VkQmxvY2tzLnJhd0NvbGxlY3Rpb24oKS5pbml0aWFsaXplT3JkZXJlZEJ1bGtPcCgpO1xuXG4gICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvcnNNYXAgPSB7fTtcbiAgICAgICAgICAgICAgICB2YWxpZGF0b3JzLmZvckVhY2goKHZhbGlkYXRvcikgPT4gdmFsaWRhdG9yc01hcFt2YWxpZGF0b3IuYWRkcmVzc10gPSB2YWxpZGF0b3IpO1xuXG4gICAgICAgICAgICAgICAgLy8gYSBtYXAgb2YgYmxvY2sgaGVpZ2h0IHRvIGJsb2NrIHN0YXRzXG4gICAgICAgICAgICAgICAgbGV0IGJsb2NrU3RhdHMgPSBnZXRCbG9ja1N0YXRzKHN0YXJ0SGVpZ2h0LCBsYXRlc3RIZWlnaHQpO1xuXG4gICAgICAgICAgICAgICAgLy8gcHJvcG9zZXJWb3RlclN0YXRzIGlzIGEgcHJvcG9zZXItdm90ZXIgbWFwIGNvdW50aW5nIG51bWJlcnMgb2YgcHJvcG9zZWQgYmxvY2tzIG9mIHdoaWNoIHZvdGVyIGlzIGFuIGFjdGl2ZSB2YWxpZGF0b3JcbiAgICAgICAgICAgICAgICBsZXQgcHJvcG9zZXJWb3RlclN0YXRzID0ge31cblxuICAgICAgICAgICAgICAgIF8uZm9yRWFjaChibG9ja1N0YXRzLCAoYmxvY2ssIGJsb2NrSGVpZ2h0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGxldCBwcm9wb3NlckFkZHJlc3MgPSBibG9jay5wcm9wb3NlckFkZHJlc3M7XG4gICAgICAgICAgICAgICAgICAgIGxldCB2b3RlZFZhbGlkYXRvcnMgPSBuZXcgU2V0KGJsb2NrLnZhbGlkYXRvcnMpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yU2V0cyA9IFZhbGlkYXRvclNldHMuZmluZE9uZSh7YmxvY2tfaGVpZ2h0OmJsb2NrLmhlaWdodH0pO1xuICAgICAgICAgICAgICAgICAgICBsZXQgdm90ZWRWb3RpbmdQb3dlciA9IDA7XG5cbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yU2V0cy52YWxpZGF0b3JzLmZvckVhY2goKGFjdGl2ZVZhbGlkYXRvcikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZvdGVkVmFsaWRhdG9ycy5oYXMoYWN0aXZlVmFsaWRhdG9yLmFkZHJlc3MpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGVkVm90aW5nUG93ZXIgKz0gcGFyc2VGbG9hdChhY3RpdmVWYWxpZGF0b3Iudm90aW5nX3Bvd2VyKVxuICAgICAgICAgICAgICAgICAgICB9KVxuXG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvclNldHMudmFsaWRhdG9ycy5mb3JFYWNoKChhY3RpdmVWYWxpZGF0b3IpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjdXJyZW50VmFsaWRhdG9yID0gYWN0aXZlVmFsaWRhdG9yLmFkZHJlc3NcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghXy5oYXMocHJvcG9zZXJWb3RlclN0YXRzLCBbcHJvcG9zZXJBZGRyZXNzLCBjdXJyZW50VmFsaWRhdG9yXSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJldlN0YXRzID0gZ2V0UHJldmlvdXNSZWNvcmQoY3VycmVudFZhbGlkYXRvciwgcHJvcG9zZXJBZGRyZXNzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfLnNldChwcm9wb3NlclZvdGVyU3RhdHMsIFtwcm9wb3NlckFkZHJlc3MsIGN1cnJlbnRWYWxpZGF0b3JdLCBwcmV2U3RhdHMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBfLnVwZGF0ZShwcm9wb3NlclZvdGVyU3RhdHMsIFtwcm9wb3NlckFkZHJlc3MsIGN1cnJlbnRWYWxpZGF0b3IsICd0b3RhbENvdW50J10sIChuKSA9PiBuKzEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCF2b3RlZFZhbGlkYXRvcnMuaGFzKGN1cnJlbnRWYWxpZGF0b3IpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXy51cGRhdGUocHJvcG9zZXJWb3RlclN0YXRzLCBbcHJvcG9zZXJBZGRyZXNzLCBjdXJyZW50VmFsaWRhdG9yLCAnbWlzc0NvdW50J10sIChuKSA9PiBuKzEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtNaXNzZWRTdGF0cy5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RlcjogY3VycmVudFZhbGlkYXRvcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tIZWlnaHQ6IGJsb2NrLmhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zZXI6IHByb3Bvc2VyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJlY29tbWl0c0NvdW50OiBibG9jay5wcmVjb21taXRzQ291bnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvcnNDb3VudDogYmxvY2sudmFsaWRhdG9yc0NvdW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lOiBibG9jay50aW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmVjb21taXRzOiBibG9jay5wcmVjb21taXRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lOiBibG9jay5hdmVyYWdlQmxvY2tUaW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lRGlmZjogYmxvY2sudGltZURpZmYsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ1Bvd2VyOiBibG9jay52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGVkVm90aW5nUG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRBdDogbGF0ZXN0SGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaXNzQ291bnQ6IF8uZ2V0KHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvciwgJ21pc3NDb3VudCddKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWxDb3VudDogXy5nZXQocHJvcG9zZXJWb3RlclN0YXRzLCBbcHJvcG9zZXJBZGRyZXNzLCBjdXJyZW50VmFsaWRhdG9yLCAndG90YWxDb3VudCddKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgXy5mb3JFYWNoKHByb3Bvc2VyVm90ZXJTdGF0cywgKHZvdGVycywgcHJvcG9zZXJBZGRyZXNzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIF8uZm9yRWFjaCh2b3RlcnMsIChzdGF0cywgdm90ZXJBZGRyZXNzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBidWxrTWlzc2VkU3RhdHMuZmluZCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90ZXI6IHZvdGVyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wb3NlcjogcHJvcG9zZXJBZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrSGVpZ2h0OiAtMVxuICAgICAgICAgICAgICAgICAgICAgICAgfSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90ZXI6IHZvdGVyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wb3NlcjogcHJvcG9zZXJBZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrSGVpZ2h0OiAtMSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkQXQ6IGxhdGVzdEhlaWdodCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaXNzQ291bnQ6IF8uZ2V0KHN0YXRzLCAnbWlzc0NvdW50JyksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWxDb3VudDogXy5nZXQoc3RhdHMsICd0b3RhbENvdW50JylcbiAgICAgICAgICAgICAgICAgICAgICAgIH19KTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICBsZXQgbWVzc2FnZSA9ICcnO1xuICAgICAgICAgICAgICAgIGlmIChidWxrTWlzc2VkU3RhdHMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNsaWVudCA9IE1pc3NlZEJsb2Nrcy5fZHJpdmVyLm1vbmdvLmNsaWVudDtcbiAgICAgICAgICAgICAgICAgICAgLy8gVE9ETzogYWRkIHRyYW5zYWN0aW9uIGJhY2sgYWZ0ZXIgcmVwbGljYSBzZXQoIzE0NikgaXMgc2V0IHVwXG4gICAgICAgICAgICAgICAgICAgIC8vIGxldCBzZXNzaW9uID0gY2xpZW50LnN0YXJ0U2Vzc2lvbigpO1xuICAgICAgICAgICAgICAgICAgICAvLyBzZXNzaW9uLnN0YXJ0VHJhbnNhY3Rpb24oKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGJ1bGtQcm9taXNlID0gYnVsa01pc3NlZFN0YXRzLmV4ZWN1dGUobnVsbC8qLCB7c2Vzc2lvbn0qLykudGhlbihcbiAgICAgICAgICAgICAgICAgICAgICAgIE1ldGVvci5iaW5kRW52aXJvbm1lbnQoKHJlc3VsdCwgZXJyKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFByb21pc2UuYXdhaXQoc2Vzc2lvbi5hYm9ydFRyYW5zYWN0aW9uKCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBQcm9taXNlLmF3YWl0KHNlc3Npb24uY29tbWl0VHJhbnNhY3Rpb24oKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UgPSBgKCR7cmVzdWx0LnJlc3VsdC5uSW5zZXJ0ZWR9IGluc2VydGVkLCBgICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgJHtyZXN1bHQucmVzdWx0Lm5VcHNlcnRlZH0gdXBzZXJ0ZWQsIGAgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAke3Jlc3VsdC5yZXN1bHQubk1vZGlmaWVkfSBtb2RpZmllZClgO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcblxuICAgICAgICAgICAgICAgICAgICBQcm9taXNlLmF3YWl0KGJ1bGtQcm9taXNlKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLUyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIFN0YXR1cy51cHNlcnQoe2NoYWluSWQ6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0sIHskc2V0OntsYXN0UHJvY2Vzc2VkTWlzc2VkQmxvY2tIZWlnaHQ6bGF0ZXN0SGVpZ2h0LCBsYXN0UHJvY2Vzc2VkTWlzc2VkQmxvY2tUaW1lOiBuZXcgRGF0ZSgpfX0pO1xuICAgICAgICAgICAgICAgIHJldHVybiBgZG9uZSBpbiAke0RhdGUubm93KCkgLSBzdGFydFRpbWV9bXMgJHttZXNzYWdlfWA7XG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1MgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aHJvdyBlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICByZXR1cm4gXCJ1cGRhdGluZy4uLlwiO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAnVmFsaWRhdG9yUmVjb3Jkcy5jYWxjdWxhdGVNaXNzZWRCbG9ja3NTdGF0cyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIC8vIFRPRE86IGRlcHJlY2F0ZSB0aGlzIG1ldGhvZCBhbmQgTWlzc2VkQmxvY2tzU3RhdHMgY29sbGVjdGlvblxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIlZhbGlkYXRvclJlY29yZHMuY2FsY3VsYXRlTWlzc2VkQmxvY2tzOiBcIitDT1VOVE1JU1NFREJMT0NLUyk7XG4gICAgICAgIGlmICghQ09VTlRNSVNTRURCTE9DS1NTVEFUUyl7XG4gICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLU1NUQVRTID0gdHJ1ZTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdjYWx1bGF0ZSBtaXNzZWQgYmxvY2tzIHN0YXRzJyk7XG4gICAgICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgICAgIGxldCB2YWxpZGF0b3JzID0gVmFsaWRhdG9ycy5maW5kKHt9KS5mZXRjaCgpO1xuICAgICAgICAgICAgbGV0IGxhdGVzdEhlaWdodCA9IE1ldGVvci5jYWxsKCdibG9ja3MuZ2V0Q3VycmVudEhlaWdodCcpO1xuICAgICAgICAgICAgbGV0IGV4cGxvcmVyU3RhdHVzID0gU3RhdHVzLmZpbmRPbmUoe2NoYWluSWQ6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0pO1xuICAgICAgICAgICAgbGV0IHN0YXJ0SGVpZ2h0ID0gKGV4cGxvcmVyU3RhdHVzJiZleHBsb3JlclN0YXR1cy5sYXN0TWlzc2VkQmxvY2tIZWlnaHQpP2V4cGxvcmVyU3RhdHVzLmxhc3RNaXNzZWRCbG9ja0hlaWdodDpNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLnN0YXJ0SGVpZ2h0O1xuICAgICAgICAgICAgLy8gY29uc29sZS5sb2cobGF0ZXN0SGVpZ2h0KTtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHN0YXJ0SGVpZ2h0KTtcbiAgICAgICAgICAgIGNvbnN0IGJ1bGtNaXNzZWRTdGF0cyA9IE1pc3NlZEJsb2Nrc1N0YXRzLnJhd0NvbGxlY3Rpb24oKS5pbml0aWFsaXplVW5vcmRlcmVkQnVsa09wKCk7XG4gICAgICAgICAgICBmb3IgKGkgaW4gdmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgLy8gaWYgKCh2YWxpZGF0b3JzW2ldLmFkZHJlc3MgPT0gXCJCODU1MkVBQzBEMTIzQTZCRjYwOTEyMzA0N0E1MTgxRDQ1RUU5MEI1XCIpIHx8ICh2YWxpZGF0b3JzW2ldLmFkZHJlc3MgPT0gXCI2OUQ5OUIyQzY2MDQzQUNCRUFBODQ0NzUyNUMzNTZBRkM2NDA4RTBDXCIpIHx8ICh2YWxpZGF0b3JzW2ldLmFkZHJlc3MgPT0gXCIzNUFEN0EyQ0QyRkM3MTcxMUE2NzU4MzBFQzExNTgwODIyNzNENDU3XCIpKXtcbiAgICAgICAgICAgICAgICBsZXQgdm90ZXJBZGRyZXNzID0gdmFsaWRhdG9yc1tpXS5hZGRyZXNzO1xuICAgICAgICAgICAgICAgIGxldCBtaXNzZWRSZWNvcmRzID0gVmFsaWRhdG9yUmVjb3Jkcy5maW5kKHtcbiAgICAgICAgICAgICAgICAgICAgYWRkcmVzczp2b3RlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgIGV4aXN0czpmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgJGFuZDogWyB7IGhlaWdodDogeyAkZ3Q6IHN0YXJ0SGVpZ2h0IH0gfSwgeyBoZWlnaHQ6IHsgJGx0ZTogbGF0ZXN0SGVpZ2h0IH0gfSBdXG4gICAgICAgICAgICAgICAgfSkuZmV0Y2goKTtcblxuICAgICAgICAgICAgICAgIGxldCBjb3VudHMgPSB7fTtcblxuICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwibWlzc2VkUmVjb3JkcyB0byBwcm9jZXNzOiBcIittaXNzZWRSZWNvcmRzLmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgZm9yIChiIGluIG1pc3NlZFJlY29yZHMpe1xuICAgICAgICAgICAgICAgICAgICBsZXQgYmxvY2sgPSBCbG9ja3Njb24uZmluZE9uZSh7aGVpZ2h0Om1pc3NlZFJlY29yZHNbYl0uaGVpZ2h0fSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBleGlzdGluZ1JlY29yZCA9IE1pc3NlZEJsb2Nrc1N0YXRzLmZpbmRPbmUoe3ZvdGVyOnZvdGVyQWRkcmVzcywgcHJvcG9zZXI6YmxvY2sucHJvcG9zZXJBZGRyZXNzfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBjb3VudHNbYmxvY2sucHJvcG9zZXJBZGRyZXNzXSA9PT0gJ3VuZGVmaW5lZCcpe1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGV4aXN0aW5nUmVjb3JkKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb3VudHNbYmxvY2sucHJvcG9zZXJBZGRyZXNzXSA9IGV4aXN0aW5nUmVjb3JkLmNvdW50KzE7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNle1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50c1tibG9jay5wcm9wb3NlckFkZHJlc3NdID0gMTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNle1xuICAgICAgICAgICAgICAgICAgICAgICAgY291bnRzW2Jsb2NrLnByb3Bvc2VyQWRkcmVzc10rKztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGZvciAoYWRkcmVzcyBpbiBjb3VudHMpe1xuICAgICAgICAgICAgICAgICAgICBsZXQgZGF0YSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZvdGVyOiB2b3RlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9wb3NlcjphZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgY291bnQ6IGNvdW50c1thZGRyZXNzXVxuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgYnVsa01pc3NlZFN0YXRzLmZpbmQoe3ZvdGVyOnZvdGVyQWRkcmVzcywgcHJvcG9zZXI6YWRkcmVzc30pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDpkYXRhfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vIH1cblxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoYnVsa01pc3NlZFN0YXRzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgIGJ1bGtNaXNzZWRTdGF0cy5leGVjdXRlKE1ldGVvci5iaW5kRW52aXJvbm1lbnQoKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1NTVEFUUyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgIFN0YXR1cy51cHNlcnQoe2NoYWluSWQ6IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0sIHskc2V0OntsYXN0TWlzc2VkQmxvY2tIZWlnaHQ6bGF0ZXN0SGVpZ2h0LCBsYXN0TWlzc2VkQmxvY2tUaW1lOiBuZXcgRGF0ZSgpfX0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1NTVEFUUyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJkb25lXCIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLU1NUQVRTID0gZmFsc2U7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICByZXR1cm4gXCJ1cGRhdGluZy4uLlwiO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAnQW5hbHl0aWNzLmFnZ3JlZ2F0ZUJsb2NrVGltZUFuZFZvdGluZ1Bvd2VyJzogZnVuY3Rpb24odGltZSl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgbm93ID0gbmV3IERhdGUoKTtcblxuICAgICAgICBpZiAodGltZSA9PSAnbScpe1xuICAgICAgICAgICAgbGV0IGF2ZXJhZ2VCbG9ja1RpbWUgPSAwO1xuICAgICAgICAgICAgbGV0IGF2ZXJhZ2VWb3RpbmdQb3dlciA9IDA7XG5cbiAgICAgICAgICAgIGxldCBhbmFseXRpY3MgPSBBbmFseXRpY3MuZmluZCh7IFwidGltZVwiOiB7ICRndDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDYwICogMTAwMCkgfSB9KS5mZXRjaCgpO1xuICAgICAgICAgICAgaWYgKGFuYWx5dGljcy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICBmb3IgKGkgaW4gYW5hbHl0aWNzKXtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSArPSBhbmFseXRpY3NbaV0udGltZURpZmY7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlciArPSBhbmFseXRpY3NbaV0udm90aW5nX3Bvd2VyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lID0gYXZlcmFnZUJsb2NrVGltZSAvIGFuYWx5dGljcy5sZW5ndGg7XG4gICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyID0gYXZlcmFnZVZvdGluZ1Bvd2VyIC8gYW5hbHl0aWNzLmxlbmd0aDtcblxuICAgICAgICAgICAgICAgIENoYWluLnVwZGF0ZSh7Y2hhaW5JZDpNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LHskc2V0OntsYXN0TWludXRlVm90aW5nUG93ZXI6YXZlcmFnZVZvdGluZ1Bvd2VyLCBsYXN0TWludXRlQmxvY2tUaW1lOmF2ZXJhZ2VCbG9ja1RpbWV9fSk7XG4gICAgICAgICAgICAgICAgQXZlcmFnZURhdGEuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZTogYXZlcmFnZUJsb2NrVGltZSxcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyOiBhdmVyYWdlVm90aW5nUG93ZXIsXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IHRpbWUsXG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZWRBdDogbm93XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAodGltZSA9PSAnaCcpe1xuICAgICAgICAgICAgbGV0IGF2ZXJhZ2VCbG9ja1RpbWUgPSAwO1xuICAgICAgICAgICAgbGV0IGF2ZXJhZ2VWb3RpbmdQb3dlciA9IDA7XG4gICAgICAgICAgICBsZXQgYW5hbHl0aWNzID0gQW5hbHl0aWNzLmZpbmQoeyBcInRpbWVcIjogeyAkZ3Q6IG5ldyBEYXRlKERhdGUubm93KCkgLSA2MCo2MCAqIDEwMDApIH0gfSkuZmV0Y2goKTtcbiAgICAgICAgICAgIGlmIChhbmFseXRpY3MubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgZm9yIChpIGluIGFuYWx5dGljcyl7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgKz0gYW5hbHl0aWNzW2ldLnRpbWVEaWZmO1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgKz0gYW5hbHl0aWNzW2ldLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSA9IGF2ZXJhZ2VCbG9ja1RpbWUgLyBhbmFseXRpY3MubGVuZ3RoO1xuICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlciA9IGF2ZXJhZ2VWb3RpbmdQb3dlciAvIGFuYWx5dGljcy5sZW5ndGg7XG5cbiAgICAgICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSx7JHNldDp7bGFzdEhvdXJWb3RpbmdQb3dlcjphdmVyYWdlVm90aW5nUG93ZXIsIGxhc3RIb3VyQmxvY2tUaW1lOmF2ZXJhZ2VCbG9ja1RpbWV9fSk7XG4gICAgICAgICAgICAgICAgQXZlcmFnZURhdGEuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZTogYXZlcmFnZUJsb2NrVGltZSxcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyOiBhdmVyYWdlVm90aW5nUG93ZXIsXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IHRpbWUsXG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZWRBdDogbm93XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0aW1lID09ICdkJyl7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZUJsb2NrVGltZSA9IDA7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZVZvdGluZ1Bvd2VyID0gMDtcbiAgICAgICAgICAgIGxldCBhbmFseXRpY3MgPSBBbmFseXRpY3MuZmluZCh7IFwidGltZVwiOiB7ICRndDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDI0KjYwKjYwICogMTAwMCkgfSB9KS5mZXRjaCgpO1xuICAgICAgICAgICAgaWYgKGFuYWx5dGljcy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICBmb3IgKGkgaW4gYW5hbHl0aWNzKXtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSArPSBhbmFseXRpY3NbaV0udGltZURpZmY7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlciArPSBhbmFseXRpY3NbaV0udm90aW5nX3Bvd2VyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lID0gYXZlcmFnZUJsb2NrVGltZSAvIGFuYWx5dGljcy5sZW5ndGg7XG4gICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyID0gYXZlcmFnZVZvdGluZ1Bvd2VyIC8gYW5hbHl0aWNzLmxlbmd0aDtcblxuICAgICAgICAgICAgICAgIENoYWluLnVwZGF0ZSh7Y2hhaW5JZDpNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LHskc2V0OntsYXN0RGF5Vm90aW5nUG93ZXI6YXZlcmFnZVZvdGluZ1Bvd2VyLCBsYXN0RGF5QmxvY2tUaW1lOmF2ZXJhZ2VCbG9ja1RpbWV9fSk7XG4gICAgICAgICAgICAgICAgQXZlcmFnZURhdGEuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZTogYXZlcmFnZUJsb2NrVGltZSxcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyOiBhdmVyYWdlVm90aW5nUG93ZXIsXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IHRpbWUsXG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZWRBdDogbm93XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHJldHVybiBhbmFseXRpY3MubGVuZ3RoO1xuICAgIH0sXG4gICAgJ0FuYWx5dGljcy5hZ2dyZWdhdGVWYWxpZGF0b3JEYWlseUJsb2NrVGltZSc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgdmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7fSkuZmV0Y2goKTtcbiAgICAgICAgbGV0IG5vdyA9IG5ldyBEYXRlKCk7XG4gICAgICAgIGZvciAoaSBpbiB2YWxpZGF0b3JzKXtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlQmxvY2tUaW1lID0gMDtcblxuICAgICAgICAgICAgbGV0IGJsb2NrcyA9IEJsb2Nrc2Nvbi5maW5kKHtwcm9wb3NlckFkZHJlc3M6dmFsaWRhdG9yc1tpXS5hZGRyZXNzLCBcInRpbWVcIjogeyAkZ3Q6IG5ldyBEYXRlKERhdGUubm93KCkgLSAyNCo2MCo2MCAqIDEwMDApIH19LCB7ZmllbGRzOntoZWlnaHQ6MX19KS5mZXRjaCgpO1xuXG4gICAgICAgICAgICBpZiAoYmxvY2tzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgIGxldCBibG9ja0hlaWdodHMgPSBbXTtcbiAgICAgICAgICAgICAgICBmb3IgKGIgaW4gYmxvY2tzKXtcbiAgICAgICAgICAgICAgICAgICAgYmxvY2tIZWlnaHRzLnB1c2goYmxvY2tzW2JdLmhlaWdodCk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgbGV0IGFuYWx5dGljcyA9IEFuYWx5dGljcy5maW5kKHtoZWlnaHQ6IHskaW46YmxvY2tIZWlnaHRzfX0sIHtmaWVsZHM6e2hlaWdodDoxLHRpbWVEaWZmOjF9fSkuZmV0Y2goKTtcblxuXG4gICAgICAgICAgICAgICAgZm9yIChhIGluIGFuYWx5dGljcyl7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgKz0gYW5hbHl0aWNzW2FdLnRpbWVEaWZmO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgPSBhdmVyYWdlQmxvY2tUaW1lIC8gYW5hbHl0aWNzLmxlbmd0aDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgQXZlcmFnZVZhbGlkYXRvckRhdGEuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICBwcm9wb3NlckFkZHJlc3M6IHZhbGlkYXRvcnNbaV0uYWRkcmVzcyxcbiAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lOiBhdmVyYWdlQmxvY2tUaW1lLFxuICAgICAgICAgICAgICAgIHR5cGU6ICdWYWxpZGF0b3JEYWlseUF2ZXJhZ2VCbG9ja1RpbWUnLFxuICAgICAgICAgICAgICAgIGNyZWF0ZWRBdDogbm93XG4gICAgICAgICAgICB9KVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgVmFsaWRhdG9yUmVjb3JkcywgQW5hbHl0aWNzLCBNaXNzZWRCbG9ja3MsIE1pc3NlZEJsb2Nrc1N0YXRzLCBWUERpc3RyaWJ1dGlvbnMgfSBmcm9tICcuLi9yZWNvcmRzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuXG5NZXRlb3IucHVibGlzaCgndmFsaWRhdG9yX3JlY29yZHMuYWxsJywgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBWYWxpZGF0b3JSZWNvcmRzLmZpbmQoKTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaCgndmFsaWRhdG9yX3JlY29yZHMudXB0aW1lJywgZnVuY3Rpb24oYWRkcmVzcywgbnVtKXtcbiAgICByZXR1cm4gVmFsaWRhdG9yUmVjb3Jkcy5maW5kKHthZGRyZXNzOmFkZHJlc3N9LHtsaW1pdDpudW0sIHNvcnQ6e2hlaWdodDotMX19KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaCgnYW5hbHl0aWNzLmhpc3RvcnknLCBmdW5jdGlvbigpe1xuICAgIHJldHVybiBBbmFseXRpY3MuZmluZCh7fSx7c29ydDp7aGVpZ2h0Oi0xfSxsaW1pdDo1MH0pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKCd2cERpc3RyaWJ1dGlvbi5sYXRlc3QnLCBmdW5jdGlvbigpe1xuICAgIHJldHVybiBWUERpc3RyaWJ1dGlvbnMuZmluZCh7fSx7c29ydDp7aGVpZ2h0Oi0xfSwgbGltaXQ6MX0pO1xufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ21pc3NlZGJsb2Nrcy52YWxpZGF0b3InLCBmdW5jdGlvbihhZGRyZXNzLCB0eXBlKXtcbiAgICBsZXQgY29uZGl0aW9ucyA9IHt9O1xuICAgIGlmICh0eXBlID09ICd2b3Rlcicpe1xuICAgICAgICBjb25kaXRpb25zID0ge1xuICAgICAgICAgICAgdm90ZXI6IGFkZHJlc3NcbiAgICAgICAgfVxuICAgIH1cbiAgICBlbHNle1xuICAgICAgICBjb25kaXRpb25zID0ge1xuICAgICAgICAgICAgcHJvcG9zZXI6IGFkZHJlc3NcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gTWlzc2VkQmxvY2tzU3RhdHMuZmluZChjb25kaXRpb25zKVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQoc3RhdHMpe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge30sXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmllbGRzOnthZGRyZXNzOjEsIGRlc2NyaXB0aW9uOjEsIHByb2ZpbGVfdXJsOjF9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ21pc3NlZHJlY29yZHMudmFsaWRhdG9yJywgZnVuY3Rpb24oYWRkcmVzcywgdHlwZSl7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIE1pc3NlZEJsb2Nrcy5maW5kKFxuICAgICAgICAgICAgICAgIHtbdHlwZV06IGFkZHJlc3N9LFxuICAgICAgICAgICAgICAgIHtzb3J0OiB7dXBkYXRlZEF0OiAtMX19XG4gICAgICAgICAgICApXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge30sXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmllbGRzOnthZGRyZXNzOjEsIGRlc2NyaXB0aW9uOjEsIG9wZXJhdG9yX2FkZHJlc3M6MX19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMnO1xuXG5leHBvcnQgY29uc3QgVmFsaWRhdG9yUmVjb3JkcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd2YWxpZGF0b3JfcmVjb3JkcycpO1xuZXhwb3J0IGNvbnN0IEFuYWx5dGljcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdhbmFseXRpY3MnKTtcbmV4cG9ydCBjb25zdCBNaXNzZWRCbG9ja3NTdGF0cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdtaXNzZWRfYmxvY2tzX3N0YXRzJyk7XG5leHBvcnQgY29uc3QgTWlzc2VkQmxvY2tzID0gbmV3ICBNb25nby5Db2xsZWN0aW9uKCdtaXNzZWRfYmxvY2tzJyk7XG5leHBvcnQgY29uc3QgVlBEaXN0cmlidXRpb25zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3ZvdGluZ19wb3dlcl9kaXN0cmlidXRpb25zJyk7XG5leHBvcnQgY29uc3QgQXZlcmFnZURhdGEgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignYXZlcmFnZV9kYXRhJyk7XG5leHBvcnQgY29uc3QgQXZlcmFnZVZhbGlkYXRvckRhdGEgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignYXZlcmFnZV92YWxpZGF0b3JfZGF0YScpO1xuXG5NaXNzZWRCbG9ja3NTdGF0cy5oZWxwZXJzKHtcbiAgICBwcm9wb3Nlck1vbmlrZXIoKXtcbiAgICAgICAgbGV0IHZhbGlkYXRvciA9IFZhbGlkYXRvcnMuZmluZE9uZSh7YWRkcmVzczp0aGlzLnByb3Bvc2VyfSk7XG4gICAgICAgIHJldHVybiAodmFsaWRhdG9yLmRlc2NyaXB0aW9uKT92YWxpZGF0b3IuZGVzY3JpcHRpb24ubW9uaWtlcjp0aGlzLnByb3Bvc2VyO1xuICAgIH0sXG4gICAgdm90ZXJNb25pa2VyKCl7XG4gICAgICAgIGxldCB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe2FkZHJlc3M6dGhpcy52b3Rlcn0pO1xuICAgICAgICByZXR1cm4gKHZhbGlkYXRvci5kZXNjcmlwdGlvbik/dmFsaWRhdG9yLmRlc2NyaXB0aW9uLm1vbmlrZXI6dGhpcy52b3RlcjtcbiAgICB9XG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBTdGF0dXMgfSBmcm9tICcuLi9zdGF0dXMuanMnO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snXG5cbk1ldGVvci5wdWJsaXNoKCdzdGF0dXMuc3RhdHVzJywgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBTdGF0dXMuZmluZCh7Y2hhaW5JZDpNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9KTtcbn0pO1xuXG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBTdGF0dXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignc3RhdHVzJyk7IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuaW1wb3J0IHsgVHJhbnNhY3Rpb25zIH0gZnJvbSAnLi4vLi4vdHJhbnNhY3Rpb25zL3RyYW5zYWN0aW9ucy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcbmltcG9ydCB7IFZvdGluZ1Bvd2VySGlzdG9yeSB9IGZyb20gJy4uLy4uL3ZvdGluZy1wb3dlci9oaXN0b3J5LmpzJztcblxuY29uc3QgQWRkcmVzc0xlbmd0aCA9IDQwO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ1RyYW5zYWN0aW9ucy5pbmRleCc6IGZ1bmN0aW9uKGhhc2gsIGJsb2NrVGltZSl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBoYXNoID0gaGFzaC50b1VwcGVyQ2FzZSgpO1xuICAgICAgICBsZXQgdXJsID0gTENEKyAnL3R4cy8nK2hhc2g7XG4gICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgIGxldCB0eCA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG5cbiAgICAgICAgY29uc29sZS5sb2coaGFzaCk7XG5cbiAgICAgICAgdHguaGVpZ2h0ID0gcGFyc2VJbnQodHguaGVpZ2h0KTtcblxuICAgICAgICAvLyBpZiAoIXR4LmNvZGUpe1xuICAgICAgICAvLyAgICAgbGV0IG1zZyA9IHR4LnR4LnZhbHVlLm1zZztcbiAgICAgICAgLy8gICAgIGZvciAobGV0IG0gaW4gbXNnKXtcbiAgICAgICAgLy8gICAgICAgICBpZiAobXNnW21dLnR5cGUgPT0gXCJjb3Ntb3Mtc2RrL01zZ0NyZWF0ZVZhbGlkYXRvclwiKXtcbiAgICAgICAgLy8gICAgICAgICAgICAgY29uc29sZS5sb2cobXNnW21dLnZhbHVlKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgbGV0IGNvbW1hbmQgPSBNZXRlb3Iuc2V0dGluZ3MuYmluLmdhaWFkZWJ1ZytcIiBwdWJrZXkgXCIrbXNnW21dLnZhbHVlLnB1YmtleTtcbiAgICAgICAgLy8gICAgICAgICAgICAgbGV0IHZhbGlkYXRvciA9IHtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIGNvbnNlbnN1c19wdWJrZXk6IG1zZ1ttXS52YWx1ZS5wdWJrZXksXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogbXNnW21dLnZhbHVlLmRlc2NyaXB0aW9uLFxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgY29tbWlzc2lvbjogbXNnW21dLnZhbHVlLmNvbW1pc3Npb24sXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBtaW5fc2VsZl9kZWxlZ2F0aW9uOiBtc2dbbV0udmFsdWUubWluX3NlbGZfZGVsZWdhdGlvbixcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIG9wZXJhdG9yX2FkZHJlc3M6IG1zZ1ttXS52YWx1ZS52YWxpZGF0b3JfYWRkcmVzcyxcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIGRlbGVnYXRvcl9hZGRyZXNzOiBtc2dbbV0udmFsdWUuZGVsZWdhdG9yX2FkZHJlc3MsXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IE1hdGguZmxvb3IocGFyc2VJbnQobXNnW21dLnZhbHVlLnZhbHVlLmFtb3VudCkgLyAxMDAwMDAwKVxuICAgICAgICAvLyAgICAgICAgICAgICB9XG5cbiAgICAgICAgLy8gICAgICAgICAgICAgTWV0ZW9yLmNhbGwoJ3J1bkNvZGUnLCBjb21tYW5kLCBmdW5jdGlvbihlcnJvciwgcmVzdWx0KXtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHZhbGlkYXRvci5hZGRyZXNzID0gcmVzdWx0Lm1hdGNoKC9cXHNbMC05QS1GXXs0MH0kL2lnbSk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYWRkcmVzcyA9IHZhbGlkYXRvci5hZGRyZXNzWzBdLnRyaW0oKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHZhbGlkYXRvci5oZXggPSByZXN1bHQubWF0Y2goL1xcc1swLTlBLUZdezY0fSQvaWdtKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHZhbGlkYXRvci5oZXggPSB2YWxpZGF0b3IuaGV4WzBdLnRyaW0oKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHZhbGlkYXRvci5wdWJfa2V5ID0gcmVzdWx0Lm1hdGNoKC97XCIuKlwifS9pZ20pO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnB1Yl9rZXkgPSBKU09OLnBhcnNlKHZhbGlkYXRvci5wdWJfa2V5WzBdLnRyaW0oKSk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBsZXQgcmUgPSBuZXcgUmVnRXhwKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4QWNjUHViK1wiLiokXCIsXCJpZ21cIik7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuY29zbW9zYWNjcHViID0gcmVzdWx0Lm1hdGNoKHJlKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHZhbGlkYXRvci5jb3Ntb3NhY2NwdWIgPSB2YWxpZGF0b3IuY29zbW9zYWNjcHViWzBdLnRyaW0oKTtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIHJlID0gbmV3IFJlZ0V4cChNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeFZhbFB1YitcIi4qJFwiLFwiaWdtXCIpO1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLm9wZXJhdG9yX3B1YmtleSA9IHJlc3VsdC5tYXRjaChyZSk7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gdmFsaWRhdG9yLm9wZXJhdG9yX3B1YmtleVswXS50cmltKCk7XG5cbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIFZhbGlkYXRvcnMudXBzZXJ0KHtjb25zZW5zdXNfcHVia2V5Om1zZ1ttXS52YWx1ZS5wdWJrZXl9LHZhbGlkYXRvcik7XG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBWb3RpbmdQb3dlckhpc3RvcnkuaW5zZXJ0KHtcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOiB2YWxpZGF0b3IuYWRkcmVzcyxcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICBwcmV2X3ZvdGluZ19wb3dlcjogMCxcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IHZhbGlkYXRvci52b3RpbmdfcG93ZXIsXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2FkZCcsXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiB0eC5oZWlnaHQrMixcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICBibG9ja190aW1lOiBibG9ja1RpbWVcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAvLyAgICAgICAgICAgICB9KVxuICAgICAgICAvLyAgICAgICAgIH1cbiAgICAgICAgLy8gICAgIH1cbiAgICAgICAgLy8gfVxuXG5cbiAgICAgICAgbGV0IHR4SWQgPSBUcmFuc2FjdGlvbnMuaW5zZXJ0KHR4KTtcbiAgICAgICAgaWYgKHR4SWQpe1xuICAgICAgICAgICAgcmV0dXJuIHR4SWQ7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSByZXR1cm4gZmFsc2U7XG4gICAgfSxcbiAgICAnVHJhbnNhY3Rpb25zLmZpbmREZWxlZ2F0aW9uJzogZnVuY3Rpb24oYWRkcmVzcywgaGVpZ2h0KXtcbiAgICAgICAgLy8gZm9sbG93aW5nIGNvc21vcy1zZGsveC9zbGFzaGluZy9zcGVjLzA2X2V2ZW50cy5tZCBhbmQgY29zbW9zLXNkay94L3N0YWtpbmcvc3BlYy8wNl9ldmVudHMubWRcbiAgICAgICAgcmV0dXJuIFRyYW5zYWN0aW9ucy5maW5kKHtcbiAgICAgICAgICAgICRvcjogW3skYW5kOiBbXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLnR5cGVcIjogXCJkZWxlZ2F0ZVwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy5rZXlcIjogXCJ2YWxpZGF0b3JcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjogYWRkcmVzc31cbiAgICAgICAgICAgIF19LCB7JGFuZDpbXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCI6IFwiYWN0aW9uXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6IFwidW5qYWlsXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOiBcInNlbmRlclwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOiBhZGRyZXNzfVxuICAgICAgICAgICAgXX0sIHskYW5kOltcbiAgICAgICAgICAgICAgICB7XCJldmVudHMudHlwZVwiOiBcImNyZWF0ZV92YWxpZGF0b3JcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCI6IFwidmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6IGFkZHJlc3N9XG4gICAgICAgICAgICBdfSwgeyRhbmQ6W1xuICAgICAgICAgICAgICAgIHtcImV2ZW50cy50eXBlXCI6IFwidW5ib25kXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOiBcInZhbGlkYXRvclwifSxcbiAgICAgICAgICAgICAgICB7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOiBhZGRyZXNzfVxuICAgICAgICAgICAgXX0sIHskYW5kOltcbiAgICAgICAgICAgICAgICB7XCJldmVudHMudHlwZVwiOiBcInJlZGVsZWdhdGVcIn0sXG4gICAgICAgICAgICAgICAge1wiZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCI6IFwiZGVzdGluYXRpb25fdmFsaWRhdG9yXCJ9LFxuICAgICAgICAgICAgICAgIHtcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6IGFkZHJlc3N9XG4gICAgICAgICAgICBdfV0sXG4gICAgICAgICAgICBcImNvZGVcIjogeyRleGlzdHM6IGZhbHNlfSxcbiAgICAgICAgICAgIGhlaWdodDp7JGx0OmhlaWdodH19LFxuICAgICAgICB7c29ydDp7aGVpZ2h0Oi0xfSxcbiAgICAgICAgICAgIGxpbWl0OiAxfVxuICAgICAgICApLmZldGNoKCk7XG4gICAgfSxcbiAgICAnVHJhbnNhY3Rpb25zLmZpbmRVc2VyJzogZnVuY3Rpb24oYWRkcmVzcywgZmllbGRzPW51bGwpe1xuICAgICAgICAvLyBhZGRyZXNzIGlzIGVpdGhlciBkZWxlZ2F0b3IgYWRkcmVzcyBvciB2YWxpZGF0b3Igb3BlcmF0b3IgYWRkcmVzc1xuICAgICAgICBsZXQgdmFsaWRhdG9yO1xuICAgICAgICBpZiAoIWZpZWxkcylcbiAgICAgICAgICAgIGZpZWxkcyA9IHthZGRyZXNzOjEsIGRlc2NyaXB0aW9uOjEsIG9wZXJhdG9yX2FkZHJlc3M6MSwgZGVsZWdhdG9yX2FkZHJlc3M6MX07XG4gICAgICAgIGlmIChhZGRyZXNzLmluY2x1ZGVzKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsQWRkcikpe1xuICAgICAgICAgICAgLy8gdmFsaWRhdG9yIG9wZXJhdG9yIGFkZHJlc3NcbiAgICAgICAgICAgIHZhbGlkYXRvciA9IFZhbGlkYXRvcnMuZmluZE9uZSh7b3BlcmF0b3JfYWRkcmVzczphZGRyZXNzfSwge2ZpZWxkc30pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGFkZHJlc3MuaW5jbHVkZXMoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhBY2NBZGRyKSl7XG4gICAgICAgICAgICAvLyBkZWxlZ2F0b3IgYWRkcmVzc1xuICAgICAgICAgICAgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKHtkZWxlZ2F0b3JfYWRkcmVzczphZGRyZXNzfSwge2ZpZWxkc30pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGFkZHJlc3MubGVuZ3RoID09PSBBZGRyZXNzTGVuZ3RoKSB7XG4gICAgICAgICAgICB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe2FkZHJlc3M6YWRkcmVzc30sIHtmaWVsZHN9KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodmFsaWRhdG9yKXtcbiAgICAgICAgICAgIHJldHVybiB2YWxpZGF0b3I7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuXG4gICAgfVxufSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFRyYW5zYWN0aW9ucyB9IGZyb20gJy4uL3RyYW5zYWN0aW9ucy5qcyc7XG5pbXBvcnQgeyBCbG9ja3Njb24gfSBmcm9tICcuLi8uLi9ibG9ja3MvYmxvY2tzLmpzJztcblxuXG5wdWJsaXNoQ29tcG9zaXRlKCd0cmFuc2FjdGlvbnMubGlzdCcsIGZ1bmN0aW9uKGxpbWl0ID0gMzApe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBUcmFuc2FjdGlvbnMuZmluZCh7fSx7c29ydDp7aGVpZ2h0Oi0xfSwgbGltaXQ6bGltaXR9KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQodHgpe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7aGVpZ2h0OnR4LmhlaWdodH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmllbGRzOnt0aW1lOjEsIGhlaWdodDoxfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pO1xuXG5wdWJsaXNoQ29tcG9zaXRlKCd0cmFuc2FjdGlvbnMudmFsaWRhdG9yJywgZnVuY3Rpb24odmFsaWRhdG9yQWRkcmVzcywgZGVsZWdhdG9yQWRkcmVzcywgbGltaXQ9MTAwKXtcbiAgICBsZXQgcXVlcnkgPSB7fTtcbiAgICBpZiAodmFsaWRhdG9yQWRkcmVzcyAmJiBkZWxlZ2F0b3JBZGRyZXNzKXtcbiAgICAgICAgcXVlcnkgPSB7JG9yOlt7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOnZhbGlkYXRvckFkZHJlc3N9LCB7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOmRlbGVnYXRvckFkZHJlc3N9XX1cbiAgICB9XG5cbiAgICBpZiAoIXZhbGlkYXRvckFkZHJlc3MgJiYgZGVsZWdhdG9yQWRkcmVzcyl7XG4gICAgICAgIHF1ZXJ5ID0ge1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjpkZWxlZ2F0b3JBZGRyZXNzfVxuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBUcmFuc2FjdGlvbnMuZmluZChxdWVyeSwge3NvcnQ6e2hlaWdodDotMX0sIGxpbWl0OmxpbWl0fSlcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46W1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQodHgpe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7aGVpZ2h0OnR4LmhlaWdodH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmllbGRzOnt0aW1lOjEsIGhlaWdodDoxfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pXG5cbnB1Ymxpc2hDb21wb3NpdGUoJ3RyYW5zYWN0aW9ucy5maW5kT25lJywgZnVuY3Rpb24oaGFzaCl7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIFRyYW5zYWN0aW9ucy5maW5kKHt0eGhhc2g6aGFzaH0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZCh0eCl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHtoZWlnaHQ6dHguaGVpZ2h0fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e3RpbWU6MSwgaGVpZ2h0OjF9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSlcblxucHVibGlzaENvbXBvc2l0ZSgndHJhbnNhY3Rpb25zLmhlaWdodCcsIGZ1bmN0aW9uKGhlaWdodCl7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIFRyYW5zYWN0aW9ucy5maW5kKHtoZWlnaHQ6aGVpZ2h0fSlcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHR4KXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2hlaWdodDp0eC5oZWlnaHR9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7dGltZToxLCBoZWlnaHQ6MX19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IEJsb2Nrc2NvbiB9IGZyb20gJy4uL2Jsb2Nrcy9ibG9ja3MuanMnO1xuaW1wb3J0IHsgVHhJY29uIH0gZnJvbSAnLi4vLi4vdWkvY29tcG9uZW50cy9JY29ucy5qc3gnO1xuXG5leHBvcnQgY29uc3QgVHJhbnNhY3Rpb25zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3RyYW5zYWN0aW9ucycpO1xuXG5UcmFuc2FjdGlvbnMuaGVscGVycyh7XG4gICAgYmxvY2soKXtcbiAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kT25lKHtoZWlnaHQ6dGhpcy5oZWlnaHR9KTtcbiAgICB9XG59KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgVHJhbnNhY3Rpb25zIH0gZnJvbSAnLi4vLi4vdHJhbnNhY3Rpb25zL3RyYW5zYWN0aW9ucy5qcyc7XG5pbXBvcnQgeyBCbG9ja3Njb24gfSBmcm9tICcuLi8uLi9ibG9ja3MvYmxvY2tzLmpzJztcbmltcG9ydCB7IERlbGVnYXRpb25zIH0gZnJvbSAnLi4vLi4vZGVsZWdhdGlvbnMvZGVsZWdhdGlvbnMuanMnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ1ZhbGlkYXRvcnMuZmluZENyZWF0ZVZhbGlkYXRvclRpbWUnOiBmdW5jdGlvbihhZGRyZXNzKXtcbiAgICAgICAgLy8gbG9vayB1cCB0aGUgY3JlYXRlIHZhbGlkYXRvciB0aW1lIHRvIGNvbnNpZGVyIGlmIHRoZSB2YWxpZGF0b3IgaGFzIG5ldmVyIHVwZGF0ZWQgdGhlIGNvbW1pc3Npb25cbiAgICAgICAgbGV0IHR4ID0gVHJhbnNhY3Rpb25zLmZpbmRPbmUoeyRhbmQ6W1xuICAgICAgICAgICAge1widHgudmFsdWUubXNnLnZhbHVlLmRlbGVnYXRvcl9hZGRyZXNzXCI6YWRkcmVzc30sXG4gICAgICAgICAgICB7XCJ0eC52YWx1ZS5tc2cudHlwZVwiOlwiY29zbW9zLXNkay9Nc2dDcmVhdGVWYWxpZGF0b3JcIn0sXG4gICAgICAgICAgICB7Y29kZTp7JGV4aXN0czpmYWxzZX19XG4gICAgICAgIF19KTtcblxuICAgICAgICBpZiAodHgpe1xuICAgICAgICAgICAgbGV0IGJsb2NrID0gQmxvY2tzY29uLmZpbmRPbmUoe2hlaWdodDp0eC5oZWlnaHR9KTtcbiAgICAgICAgICAgIGlmIChibG9jayl7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGJsb2NrLnRpbWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIC8vIG5vIHN1Y2ggY3JlYXRlIHZhbGlkYXRvciB0eFxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAvLyBhc3luYyAnVmFsaWRhdG9ycy5nZXRBbGxEZWxlZ2F0aW9ucycoYWRkcmVzcyl7XG4gICAgJ1ZhbGlkYXRvcnMuZ2V0QWxsRGVsZWdhdGlvbnMnKGFkZHJlc3Mpe1xuICAgICAgICBsZXQgdXJsID0gTENEICsgJy9zdGFraW5nL3ZhbGlkYXRvcnMvJythZGRyZXNzKycvZGVsZWdhdGlvbnMnO1xuXG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCBkZWxlZ2F0aW9ucyA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBpZiAoZGVsZWdhdGlvbnMuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zID0gSlNPTi5wYXJzZShkZWxlZ2F0aW9ucy5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgZGVsZWdhdGlvbnMuZm9yRWFjaCgoZGVsZWdhdGlvbiwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZGVsZWdhdGlvbnNbaV0gJiYgZGVsZWdhdGlvbnNbaV0uc2hhcmVzKVxuICAgICAgICAgICAgICAgICAgICAgICAgZGVsZWdhdGlvbnNbaV0uc2hhcmVzID0gcGFyc2VGbG9hdChkZWxlZ2F0aW9uc1tpXS5zaGFyZXMpO1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgcmV0dXJuIGRlbGVnYXRpb25zO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgfVxuICAgIH1cbn0pOyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9yUmVjb3JkcyB9IGZyb20gJy4uLy4uL3JlY29yZHMvcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBWb3RpbmdQb3dlckhpc3RvcnkgfSBmcm9tICcuLi8uLi92b3RpbmctcG93ZXIvaGlzdG9yeS5qcyc7XG5cbk1ldGVvci5wdWJsaXNoKCd2YWxpZGF0b3JzLmFsbCcsIGZ1bmN0aW9uIChzb3J0ID0gXCJkZXNjcmlwdGlvbi5tb25pa2VyXCIsIGRpcmVjdGlvbiA9IC0xLCBmaWVsZHM9e30pIHtcbiAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKHt9LCB7c29ydDoge1tzb3J0XTogZGlyZWN0aW9ufSwgZmllbGRzOiBmaWVsZHN9KTtcbn0pO1xuXG5wdWJsaXNoQ29tcG9zaXRlKCd2YWxpZGF0b3JzLmZpcnN0U2Vlbicse1xuICAgIGZpbmQoKSB7XG4gICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoe30pO1xuICAgIH0sXG4gICAgY2hpbGRyZW46IFtcbiAgICAgICAge1xuICAgICAgICAgICAgZmluZCh2YWwpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gVmFsaWRhdG9yUmVjb3Jkcy5maW5kKFxuICAgICAgICAgICAgICAgICAgICB7IGFkZHJlc3M6IHZhbC5hZGRyZXNzIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgc29ydDoge2hlaWdodDogMX0sIGxpbWl0OiAxfVxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICBdXG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ3ZhbGlkYXRvcnMudm90aW5nX3Bvd2VyJywgZnVuY3Rpb24oKXtcbiAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kKHtcbiAgICAgICAgc3RhdHVzOiAyLFxuICAgICAgICBqYWlsZWQ6ZmFsc2VcbiAgICB9LHtcbiAgICAgICAgc29ydDp7XG4gICAgICAgICAgICB2b3RpbmdfcG93ZXI6LTFcbiAgICAgICAgfSxcbiAgICAgICAgZmllbGRzOntcbiAgICAgICAgICAgIGFkZHJlc3M6IDEsXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjoxLFxuICAgICAgICAgICAgdm90aW5nX3Bvd2VyOjEsXG4gICAgICAgICAgICBwcm9maWxlX3VybDoxXG4gICAgICAgIH1cbiAgICB9XG4gICAgKTtcbn0pO1xuXG5wdWJsaXNoQ29tcG9zaXRlKCd2YWxpZGF0b3IuZGV0YWlscycsIGZ1bmN0aW9uKGFkZHJlc3Mpe1xuICAgIGxldCBvcHRpb25zID0ge2FkZHJlc3M6YWRkcmVzc307XG4gICAgaWYgKGFkZHJlc3MuaW5kZXhPZihNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeFZhbEFkZHIpICE9IC0xKXtcbiAgICAgICAgb3B0aW9ucyA9IHtvcGVyYXRvcl9hZGRyZXNzOmFkZHJlc3N9XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQob3B0aW9ucylcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHZhbCl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWb3RpbmdQb3dlckhpc3RvcnkuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHthZGRyZXNzOnZhbC5hZGRyZXNzfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzb3J0OntoZWlnaHQ6LTF9LCBsaW1pdDo1MH1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZCh2YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvclJlY29yZHMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgYWRkcmVzczogdmFsLmFkZHJlc3MgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgc29ydDoge2hlaWdodDogLTF9LCBsaW1pdDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy51cHRpbWVXaW5kb3d9XG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JSZWNvcmRzIH0gZnJvbSAnLi4vcmVjb3Jkcy9yZWNvcmRzLmpzJztcbmltcG9ydCB7IFZvdGluZ1Bvd2VySGlzdG9yeSB9IGZyb20gJy4uL3ZvdGluZy1wb3dlci9oaXN0b3J5LmpzJztcblxuZXhwb3J0IGNvbnN0IFZhbGlkYXRvcnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndmFsaWRhdG9ycycpO1xuXG5WYWxpZGF0b3JzLmhlbHBlcnMoe1xuICAgIGZpcnN0U2Vlbigpe1xuICAgICAgICByZXR1cm4gVmFsaWRhdG9yUmVjb3Jkcy5maW5kT25lKHthZGRyZXNzOnRoaXMuYWRkcmVzc30pO1xuICAgIH0sXG4gICAgaGlzdG9yeSgpe1xuICAgICAgICByZXR1cm4gVm90aW5nUG93ZXJIaXN0b3J5LmZpbmQoe2FkZHJlc3M6dGhpcy5hZGRyZXNzfSwge3NvcnQ6e2hlaWdodDotMX0sIGxpbWl0OjUwfSkuZmV0Y2goKTtcbiAgICB9XG59KVxuLy8gVmFsaWRhdG9ycy5oZWxwZXJzKHtcbi8vICAgICB1cHRpbWUoKXtcbi8vICAgICAgICAgLy8gY29uc29sZS5sb2codGhpcy5hZGRyZXNzKTtcbi8vICAgICAgICAgbGV0IGxhc3RIdW5kcmVkID0gVmFsaWRhdG9yUmVjb3Jkcy5maW5kKHthZGRyZXNzOnRoaXMuYWRkcmVzc30sIHtzb3J0OntoZWlnaHQ6LTF9LCBsaW1pdDoxMDB9KS5mZXRjaCgpO1xuLy8gICAgICAgICBjb25zb2xlLmxvZyhsYXN0SHVuZHJlZCk7XG4vLyAgICAgICAgIGxldCB1cHRpbWUgPSAwO1xuLy8gICAgICAgICBmb3IgKGkgaW4gbGFzdEh1bmRyZWQpe1xuLy8gICAgICAgICAgICAgaWYgKGxhc3RIdW5kcmVkW2ldLmV4aXN0cyl7XG4vLyAgICAgICAgICAgICAgICAgdXB0aW1lKz0xO1xuLy8gICAgICAgICAgICAgfVxuLy8gICAgICAgICB9XG4vLyAgICAgICAgIHJldHVybiB1cHRpbWU7XG4vLyAgICAgfVxuLy8gfSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBWb3RpbmdQb3dlckhpc3RvcnkgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndm90aW5nX3Bvd2VyX2hpc3RvcnknKTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IEV2aWRlbmNlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdldmlkZW5jZXMnKTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IFZhbGlkYXRvclNldHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndmFsaWRhdG9yX3NldHMnKTtcbiIsIi8vIEltcG9ydCBtb2R1bGVzIHVzZWQgYnkgYm90aCBjbGllbnQgYW5kIHNlcnZlciB0aHJvdWdoIGEgc2luZ2xlIGluZGV4IGVudHJ5IHBvaW50XG4vLyBlLmcuIHVzZXJhY2NvdW50cyBjb25maWd1cmF0aW9uIGZpbGUuXG4iLCJpbXBvcnQgeyBCbG9ja3Njb24gfSBmcm9tICcuLi8uLi9hcGkvYmxvY2tzL2Jsb2Nrcy5qcyc7XG4vL2ltcG9ydCB7IFByb3Bvc2FscyB9IGZyb20gJy4uLy4uL2FwaS9wcm9wb3NhbHMvcHJvcG9zYWxzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMsIEFuYWx5dGljcywgTWlzc2VkQmxvY2tzU3RhdHMsIE1pc3NlZEJsb2NrcywgQXZlcmFnZURhdGEsIEF2ZXJhZ2VWYWxpZGF0b3JEYXRhIH0gZnJvbSAnLi4vLi4vYXBpL3JlY29yZHMvcmVjb3Jkcy5qcyc7XG4vLyBpbXBvcnQgeyBTdGF0dXMgfSBmcm9tICcuLi8uLi9hcGkvc3RhdHVzL3N0YXR1cy5qcyc7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi8uLi9hcGkvdHJhbnNhY3Rpb25zL3RyYW5zYWN0aW9ucy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JTZXRzIH0gZnJvbSAnLi4vLi4vYXBpL3ZhbGlkYXRvci1zZXRzL3ZhbGlkYXRvci1zZXRzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi9hcGkvdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcbmltcG9ydCB7IFZvdGluZ1Bvd2VySGlzdG9yeSB9IGZyb20gJy4uLy4uL2FwaS92b3RpbmctcG93ZXIvaGlzdG9yeS5qcyc7XG5pbXBvcnQgeyBFdmlkZW5jZXMgfSBmcm9tICcuLi8uLi9hcGkvZXZpZGVuY2VzL2V2aWRlbmNlcy5qcyc7XG5pbXBvcnQgeyBDb2luU3RhdHMgfSBmcm9tICcuLi8uLi9hcGkvY29pbi1zdGF0cy9jb2luLXN0YXRzLmpzJztcbmltcG9ydCB7IENoYWluU3RhdGVzIH0gZnJvbSAnLi4vLi4vYXBpL2NoYWluL2NoYWluLmpzJztcblxuQ2hhaW5TdGF0ZXMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtoZWlnaHQ6IC0xfSx7dW5pcXVlOnRydWV9KTtcblxuQmxvY2tzY29uLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7aGVpZ2h0OiAtMX0se3VuaXF1ZTp0cnVlfSk7XG5CbG9ja3Njb24ucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NlckFkZHJlc3M6MX0pO1xuXG5FdmlkZW5jZXMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtoZWlnaHQ6IC0xfSk7XG5cbi8vUHJvcG9zYWxzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7cHJvcG9zYWxJZDogMX0sIHt1bmlxdWU6dHJ1ZX0pO1xuXG5WYWxpZGF0b3JSZWNvcmRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7YWRkcmVzczoxLGhlaWdodDogLTF9LCB7dW5pcXVlOjF9KTtcblZhbGlkYXRvclJlY29yZHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHthZGRyZXNzOjEsZXhpc3RzOjEsIGhlaWdodDogLTF9KTtcblxuQW5hbHl0aWNzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7aGVpZ2h0OiAtMX0sIHt1bmlxdWU6dHJ1ZX0pXG5cbk1pc3NlZEJsb2Nrcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2VyOjEsIHZvdGVyOjEsIHVwZGF0ZWRBdDogLTF9KTtcbk1pc3NlZEJsb2Nrcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2VyOjEsIGJsb2NrSGVpZ2h0Oi0xfSk7XG5NaXNzZWRCbG9ja3MucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHt2b3RlcjoxLCBibG9ja0hlaWdodDotMX0pO1xuTWlzc2VkQmxvY2tzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7dm90ZXI6MSwgcHJvcG9zZXI6MSwgYmxvY2tIZWlnaHQ6LTF9LCB7dW5pcXVlOnRydWV9KTtcblxuTWlzc2VkQmxvY2tzU3RhdHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NlcjoxfSk7XG5NaXNzZWRCbG9ja3NTdGF0cy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3ZvdGVyOjF9KTtcbk1pc3NlZEJsb2Nrc1N0YXRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7cHJvcG9zZXI6MSwgdm90ZXI6MX0se3VuaXF1ZTp0cnVlfSk7XG5cbkF2ZXJhZ2VEYXRhLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7dHlwZToxLCBjcmVhdGVkQXQ6LTF9LHt1bmlxdWU6dHJ1ZX0pO1xuQXZlcmFnZVZhbGlkYXRvckRhdGEucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NlckFkZHJlc3M6MSxjcmVhdGVkQXQ6LTF9LHt1bmlxdWU6dHJ1ZX0pO1xuLy8gU3RhdHVzLnJhd0NvbGxlY3Rpb24uY3JlYXRlSW5kZXgoe30pXG5cblRyYW5zYWN0aW9ucy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3R4aGFzaDoxfSx7dW5pcXVlOnRydWV9KTtcblRyYW5zYWN0aW9ucy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2hlaWdodDotMX0pO1xuLy8gVHJhbnNhY3Rpb25zLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7YWN0aW9uOjF9KTtcblRyYW5zYWN0aW9ucy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe1wiZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCI6MX0pO1xuVHJhbnNhY3Rpb25zLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOjF9KTtcblxuVmFsaWRhdG9yU2V0cy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2Jsb2NrX2hlaWdodDotMX0pO1xuXG5WYWxpZGF0b3JzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7YWRkcmVzczoxfSx7dW5pcXVlOnRydWUsIHBhcnRpYWxGaWx0ZXJFeHByZXNzaW9uOiB7IGFkZHJlc3M6IHsgJGV4aXN0czogdHJ1ZSB9IH0gfSk7XG5WYWxpZGF0b3JzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7Y29uc2Vuc3VzX3B1YmtleToxfSx7dW5pcXVlOnRydWV9KTtcblZhbGlkYXRvcnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtcInB1Yl9rZXkudmFsdWVcIjoxfSx7dW5pcXVlOnRydWUsIHBhcnRpYWxGaWx0ZXJFeHByZXNzaW9uOiB7IFwicHViX2tleS52YWx1ZVwiOiB7ICRleGlzdHM6IHRydWUgfSB9fSk7XG5cblZvdGluZ1Bvd2VySGlzdG9yeS5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2FkZHJlc3M6MSxoZWlnaHQ6LTF9KTtcblZvdGluZ1Bvd2VySGlzdG9yeS5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3R5cGU6MX0pO1xuXG5Db2luU3RhdHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtsYXN0X3VwZGF0ZWRfYXQ6LTF9LHt1bmlxdWU6dHJ1ZX0pO1xuIiwiLy8gSW1wb3J0IHNlcnZlciBzdGFydHVwIHRocm91Z2ggYSBzaW5nbGUgaW5kZXggZW50cnkgcG9pbnRcblxuaW1wb3J0ICcuL3V0aWwuanMnO1xuaW1wb3J0ICcuL3JlZ2lzdGVyLWFwaS5qcyc7XG5pbXBvcnQgJy4vY3JlYXRlLWluZGV4ZXMuanMnO1xuXG4vLyBpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuLy8gaW1wb3J0IHsgcmVuZGVyVG9Ob2RlU3RyZWFtIH0gZnJvbSAncmVhY3QtZG9tL3NlcnZlcic7XG4vLyBpbXBvcnQgeyByZW5kZXJUb1N0cmluZyB9IGZyb20gXCJyZWFjdC1kb20vc2VydmVyXCI7XG5pbXBvcnQgeyBvblBhZ2VMb2FkIH0gZnJvbSAnbWV0ZW9yL3NlcnZlci1yZW5kZXInO1xuLy8gaW1wb3J0IHsgU3RhdGljUm91dGVyIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG4vLyBpbXBvcnQgeyBTZXJ2ZXJTdHlsZVNoZWV0IH0gZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCJcbmltcG9ydCB7IEhlbG1ldCB9IGZyb20gJ3JlYWN0LWhlbG1ldCc7XG5cbi8vIGltcG9ydCBBcHAgZnJvbSAnLi4vLi4vdWkvQXBwLmpzeCc7XG5cbm9uUGFnZUxvYWQoc2luayA9PiB7XG4gICAgLy8gY29uc3QgY29udGV4dCA9IHt9O1xuICAgIC8vIGNvbnN0IHNoZWV0ID0gbmV3IFNlcnZlclN0eWxlU2hlZXQoKVxuXG4gICAgLy8gY29uc3QgaHRtbCA9IHJlbmRlclRvU3RyaW5nKHNoZWV0LmNvbGxlY3RTdHlsZXMoXG4gICAgLy8gICAgIDxTdGF0aWNSb3V0ZXIgbG9jYXRpb249e3NpbmsucmVxdWVzdC51cmx9IGNvbnRleHQ9e2NvbnRleHR9PlxuICAgIC8vICAgICAgICAgPEFwcCAvPlxuICAgIC8vICAgICA8L1N0YXRpY1JvdXRlcj5cbiAgICAvLyAgICkpO1xuXG4gICAgLy8gc2luay5yZW5kZXJJbnRvRWxlbWVudEJ5SWQoJ2FwcCcsIGh0bWwpO1xuXG4gICAgY29uc3QgaGVsbWV0ID0gSGVsbWV0LnJlbmRlclN0YXRpYygpO1xuICAgIHNpbmsuYXBwZW5kVG9IZWFkKGhlbG1ldC5tZXRhLnRvU3RyaW5nKCkpO1xuICAgIHNpbmsuYXBwZW5kVG9IZWFkKGhlbG1ldC50aXRsZS50b1N0cmluZygpKTtcblxuICAgIC8vIHNpbmsuYXBwZW5kVG9IZWFkKHNoZWV0LmdldFN0eWxlVGFncygpKTtcbn0pOyIsIi8vIFJlZ2lzdGVyIHlvdXIgYXBpcyBoZXJlXG5cbmltcG9ydCAnLi4vLi4vYXBpL2xlZGdlci9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL2NoYWluL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL2NoYWluL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9ibG9ja3Mvc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvYmxvY2tzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS92YWxpZGF0b3JzL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL3ZhbGlkYXRvcnMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL3JlY29yZHMvc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvcmVjb3Jkcy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuLy9pbXBvcnQgJy4uLy4uL2FwaS9wcm9wb3NhbHMvc2VydmVyL21ldGhvZHMuanMnO1xuLy9pbXBvcnQgJy4uLy4uL2FwaS9wcm9wb3NhbHMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9lbnRlcnByaXNlL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL2VudGVycHJpc2Uvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL3ZvdGluZy1wb3dlci9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvdHJhbnNhY3Rpb25zL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL3RyYW5zYWN0aW9ucy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvZGVsZWdhdGlvbnMvc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvZGVsZWdhdGlvbnMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL3N0YXR1cy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvYWNjb3VudHMvc2VydmVyL21ldGhvZHMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9jb2luLXN0YXRzL3NlcnZlci9tZXRob2RzLmpzJztcbiIsImltcG9ydCBiZWNoMzIgZnJvbSAnYmVjaDMyJ1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCAqIGFzIGNoZWVyaW8gZnJvbSAnY2hlZXJpbyc7XG5cbi8vIExvYWQgZnV0dXJlIGZyb20gZmliZXJzXG52YXIgRnV0dXJlID0gTnBtLnJlcXVpcmUoXCJmaWJlcnMvZnV0dXJlXCIpO1xuLy8gTG9hZCBleGVjXG52YXIgZXhlYyA9IE5wbS5yZXF1aXJlKFwiY2hpbGRfcHJvY2Vzc1wiKS5leGVjO1xuXG5mdW5jdGlvbiB0b0hleFN0cmluZyhieXRlQXJyYXkpIHtcbiAgICByZXR1cm4gYnl0ZUFycmF5Lm1hcChmdW5jdGlvbihieXRlKSB7XG4gICAgICAgIHJldHVybiAoJzAnICsgKGJ5dGUgJiAweEZGKS50b1N0cmluZygxNikpLnNsaWNlKC0yKTtcbiAgICB9KS5qb2luKCcnKVxufVxuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgcHVia2V5VG9CZWNoMzI6IGZ1bmN0aW9uKHB1YmtleSwgcHJlZml4KSB7XG4gICAgICAgIC8vICcxNjI0REU2NDIwJyBpcyBlZDI1NTE5IHB1YmtleSBwcmVmaXhcbiAgICAgICAgbGV0IHB1YmtleUFtaW5vUHJlZml4ID0gQnVmZmVyLmZyb20oJzE2MjRERTY0MjAnLCAnaGV4JylcbiAgICAgICAgbGV0IGJ1ZmZlciA9IEJ1ZmZlci5hbGxvYygzNylcbiAgICAgICAgcHVia2V5QW1pbm9QcmVmaXguY29weShidWZmZXIsIDApXG4gICAgICAgIEJ1ZmZlci5mcm9tKHB1YmtleS52YWx1ZSwgJ2Jhc2U2NCcpLmNvcHkoYnVmZmVyLCBwdWJrZXlBbWlub1ByZWZpeC5sZW5ndGgpXG4gICAgICAgIHJldHVybiBiZWNoMzIuZW5jb2RlKHByZWZpeCwgYmVjaDMyLnRvV29yZHMoYnVmZmVyKSlcbiAgICB9LFxuICAgIGJlY2gzMlRvUHVia2V5OiBmdW5jdGlvbihwdWJrZXkpIHtcbiAgICAgICAgLy8gJzE2MjRERTY0MjAnIGlzIGVkMjU1MTkgcHVia2V5IHByZWZpeFxuICAgICAgICBsZXQgcHVia2V5QW1pbm9QcmVmaXggPSBCdWZmZXIuZnJvbSgnMTYyNERFNjQyMCcsICdoZXgnKVxuICAgICAgICBsZXQgYnVmZmVyID0gQnVmZmVyLmZyb20oYmVjaDMyLmZyb21Xb3JkcyhiZWNoMzIuZGVjb2RlKHB1YmtleSkud29yZHMpKTtcbiAgICAgICAgcmV0dXJuIGJ1ZmZlci5zbGljZShwdWJrZXlBbWlub1ByZWZpeC5sZW5ndGgpLnRvU3RyaW5nKCdiYXNlNjQnKTtcbiAgICB9LFxuICAgIGdldERlbGVnYXRvcjogZnVuY3Rpb24ob3BlcmF0b3JBZGRyKXtcbiAgICAgICAgbGV0IGFkZHJlc3MgPSBiZWNoMzIuZGVjb2RlKG9wZXJhdG9yQWRkcik7XG4gICAgICAgIHJldHVybiBiZWNoMzIuZW5jb2RlKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4QWNjQWRkciwgYWRkcmVzcy53b3Jkcyk7XG4gICAgfSxcbiAgICBnZXRLZXliYXNlVGVhbVBpYzogZnVuY3Rpb24oa2V5YmFzZVVybCl7XG4gICAgICAgIGxldCB0ZWFtUGFnZSA9IEhUVFAuZ2V0KGtleWJhc2VVcmwpO1xuICAgICAgICBpZiAodGVhbVBhZ2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgbGV0IHBhZ2UgPSBjaGVlcmlvLmxvYWQodGVhbVBhZ2UuY29udGVudCk7XG4gICAgICAgICAgICByZXR1cm4gcGFnZShcIi5rYi1tYWluLWNhcmQgaW1nXCIpLmF0dHIoJ3NyYycpO1xuICAgICAgICB9XG4gICAgfVxufSlcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBVbmNvbnRyb2xsZWRUb29sdGlwIH0gZnJvbSAncmVhY3RzdHJhcCc7XG5cbmV4cG9ydCBjb25zdCBEZW5vbVN5bWJvbCA9IChwcm9wcykgPT4ge1xuICAgIHN3aXRjaCAocHJvcHMuZGVub20pe1xuICAgIGNhc2UgXCJzdGVha1wiOlxuICAgICAgICByZXR1cm4gJ/CfpaknO1xuICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiAn8J+NhSc7XG4gICAgfVxufVxuXG5cbmV4cG9ydCBjb25zdCBQcm9wb3NhbFN0YXR1c0ljb24gPSAocHJvcHMpID0+IHtcbiAgICBzd2l0Y2ggKHByb3BzLnN0YXR1cyl7XG4gICAgY2FzZSAnUGFzc2VkJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1jaGVjay1jaXJjbGUgdGV4dC1zdWNjZXNzXCI+PC9pPjtcbiAgICBjYXNlICdSZWplY3RlZCc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtdGltZXMtY2lyY2xlIHRleHQtZGFuZ2VyXCI+PC9pPjtcbiAgICBjYXNlICdSZW1vdmVkJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS10cmFzaC1hbHQgdGV4dC1kYXJrXCI+PC9pPlxuICAgIGNhc2UgJ0RlcG9zaXRQZXJpb2QnOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLWJhdHRlcnktaGFsZiB0ZXh0LXdhcm5pbmdcIj48L2k+O1xuICAgIGNhc2UgJ1ZvdGluZ1BlcmlvZCc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtaGFuZC1wYXBlciB0ZXh0LWluZm9cIj48L2k+O1xuICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiA8aT48L2k+O1xuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IFZvdGVJY29uID0gKHByb3BzKSA9PiB7XG4gICAgc3dpdGNoIChwcm9wcy52b3RlKXtcbiAgICBjYXNlICd5ZXMnOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLWNoZWNrIHRleHQtc3VjY2Vzc1wiPjwvaT47XG4gICAgY2FzZSAnbm8nOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLXRpbWVzIHRleHQtZGFuZ2VyXCI+PC9pPjtcbiAgICBjYXNlICdhYnN0YWluJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS11c2VyLXNsYXNoIHRleHQtd2FybmluZ1wiPjwvaT47XG4gICAgY2FzZSAnbm9fd2l0aF92ZXRvJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1leGNsYW1hdGlvbi10cmlhbmdsZSB0ZXh0LWluZm9cIj48L2k+O1xuICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiA8aT48L2k+O1xuICAgIH1cbn1cblxuZXhwb3J0IGNvbnN0IFR4SWNvbiA9IChwcm9wcykgPT4ge1xuICAgIGlmIChwcm9wcy52YWxpZCl7XG4gICAgICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXN1Y2Nlc3MgdGV4dC1ub3dyYXBcIj48aSBjbGFzc05hbWU9XCJmYXMgZmEtY2hlY2stY2lyY2xlXCI+PC9pPjwvc3Bhbj47XG4gICAgfVxuICAgIGVsc2V7XG4gICAgICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWRhbmdlciB0ZXh0LW5vd3JhcFwiPjxpIGNsYXNzTmFtZT1cImZhcyBmYS10aW1lcy1jaXJjbGVcIj48L2k+PC9zcGFuPjtcbiAgICB9XG59XG5cbmV4cG9ydCBjbGFzcyBJbmZvSWNvbiBleHRlbmRzIFJlYWN0LkNvbXBvbmVudCB7XG4gICAgY29uc3RydWN0b3IocHJvcHMpIHtcbiAgICAgICAgc3VwZXIocHJvcHMpO1xuICAgICAgICB0aGlzLnJlZiA9IFJlYWN0LmNyZWF0ZVJlZigpO1xuICAgIH1cblxuICAgIHJlbmRlcigpIHtcbiAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgIDxpIGtleT0naWNvbicgY2xhc3NOYW1lPSdtYXRlcmlhbC1pY29ucyBpbmZvLWljb24nIHJlZj17dGhpcy5yZWZ9PmluZm88L2k+LFxuICAgICAgICAgICAgPFVuY29udHJvbGxlZFRvb2x0aXAga2V5PSd0b29sdGlwJyBwbGFjZW1lbnQ9J3JpZ2h0JyB0YXJnZXQ9e3RoaXMucmVmfT5cbiAgICAgICAgICAgICAgICB7dGhpcy5wcm9wcy5jaGlsZHJlbj90aGlzLnByb3BzLmNoaWxkcmVuOnRoaXMucHJvcHMudG9vbHRpcFRleHR9XG4gICAgICAgICAgICA8L1VuY29udHJvbGxlZFRvb2x0aXA+XG4gICAgICAgIF1cbiAgICB9XG59IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgbnVtYnJvIGZyb20gJ251bWJybyc7XG5cbmF1dG9mb3JtYXQgPSAodmFsdWUpID0+IHtcblx0bGV0IGZvcm1hdHRlciA9ICcwLDAuMDAwMCc7XG5cdHZhbHVlID0gTWF0aC5yb3VuZCh2YWx1ZSAqIDEwMDApIC8gMTAwMFxuXHRpZiAoTWF0aC5yb3VuZCh2YWx1ZSkgPT09IHZhbHVlKVxuXHRcdGZvcm1hdHRlciA9ICcwLDAnXG5cdGVsc2UgaWYgKE1hdGgucm91bmQodmFsdWUqMTApID09PSB2YWx1ZSoxMClcblx0XHRmb3JtYXR0ZXIgPSAnMCwwLjAnXG5cdGVsc2UgaWYgKE1hdGgucm91bmQodmFsdWUqMTAwKSA9PT0gdmFsdWUqMTAwKVxuXHRcdGZvcm1hdHRlciA9ICcwLDAuMDAnXG5cdGVsc2UgaWYgKE1hdGgucm91bmQodmFsdWUqMTAwMCkgPT09IHZhbHVlKjEwMDApXG5cdFx0Zm9ybWF0dGVyID0gJzAsMC4wMDAnXG5cdHJldHVybiBudW1icm8odmFsdWUpLmZvcm1hdChmb3JtYXR0ZXIpXG59XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIENvaW4ge1xuXHRzdGF0aWMgU3Rha2luZ0Rlbm9tID0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5zdGFraW5nRGVub207XG5cdHN0YXRpYyBTdGFraW5nRGVub21QbHVyYWwgPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLnN0YWtpbmdEZW5vbVBsdXJhbCB8fCAoQ29pbi5TdGFraW5nRGVub20gKyAncycpO1xuXHRzdGF0aWMgTWludGluZ0Rlbm9tID0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5taW50aW5nRGVub207XG5cdHN0YXRpYyBTdGFraW5nRnJhY3Rpb24gPSBOdW1iZXIoTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5zdGFraW5nRnJhY3Rpb24pO1xuXHRzdGF0aWMgTWluU3Rha2UgPSAxIC8gTnVtYmVyKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuc3Rha2luZ0ZyYWN0aW9uKTtcblxuXHRjb25zdHJ1Y3RvcihhbW91bnQsIGRlbm9tPW51bGwpIHtcblx0XHRpZiAodHlwZW9mIGFtb3VudCA9PT0gJ29iamVjdCcpXG5cdFx0XHQoe2Ftb3VudCwgZGVub219ID0gYW1vdW50KVxuXHRcdGlmICghZGVub20gfHwgZGVub20udG9Mb3dlckNhc2UoKSA9PT0gQ29pbi5NaW50aW5nRGVub20udG9Mb3dlckNhc2UoKSkge1xuXHRcdFx0dGhpcy5fYW1vdW50ID0gTnVtYmVyKGFtb3VudCk7XG5cdFx0fSBlbHNlIGlmIChkZW5vbS50b0xvd2VyQ2FzZSgpID09PSBDb2luLlN0YWtpbmdEZW5vbS50b0xvd2VyQ2FzZSgpKSB7XG5cdFx0XHR0aGlzLl9hbW91bnQgPSBOdW1iZXIoYW1vdW50KSAqIENvaW4uU3Rha2luZ0ZyYWN0aW9uO1xuXHRcdH1cblx0XHRlbHNlIHtcblx0XHRcdHRocm93IEVycm9yKGB1bnN1cHBvcnRlZCBkZW5vbSAke2Rlbm9tfWApO1xuXHRcdH1cblx0fVxuXG5cdGdldCBhbW91bnQgKCkge1xuXHRcdHJldHVybiB0aGlzLl9hbW91bnQ7XG5cdH1cblxuXHRnZXQgc3Rha2luZ0Ftb3VudCAoKSB7XG5cdFx0cmV0dXJuIHRoaXMuX2Ftb3VudCAvIENvaW4uU3Rha2luZ0ZyYWN0aW9uO1xuXHR9XG5cblx0dG9TdHJpbmcgKHByZWNpc2lvbikge1xuXHRcdC8vIGRlZmF1bHQgdG8gZGlzcGxheSBpbiBtaW50IGRlbm9tIGlmIGl0IGhhcyBtb3JlIHRoYW4gNCBkZWNpbWFsIHBsYWNlc1xuXHRcdGxldCBtaW5TdGFrZSA9IENvaW4uU3Rha2luZ0ZyYWN0aW9uLyhwcmVjaXNpb24/TWF0aC5wb3coMTAsIHByZWNpc2lvbik6MTAwMDApXG5cdFx0aWYgKHRoaXMuYW1vdW50IDwgbWluU3Rha2UpIHtcblx0XHRcdHJldHVybiBgJHtudW1icm8odGhpcy5hbW91bnQpLmZvcm1hdCgnMCwwJyl9ICR7Q29pbi5NaW50aW5nRGVub219YDtcblx0XHR9IGVsc2Uge1xuXHRcdFx0cmV0dXJuIGAke3ByZWNpc2lvbj9udW1icm8odGhpcy5zdGFraW5nQW1vdW50KS5mb3JtYXQoJzAsMC4nICsgJzAnLnJlcGVhdChwcmVjaXNpb24pKTphdXRvZm9ybWF0KHRoaXMuc3Rha2luZ0Ftb3VudCl9ICR7Q29pbi5TdGFraW5nRGVub219YFxuXHRcdH1cblx0fVxuXG5cdG1pbnRTdHJpbmcgKGZvcm1hdHRlcikge1xuXHRcdGxldCBhbW91bnQgPSB0aGlzLmFtb3VudFxuXHRcdGlmIChmb3JtYXR0ZXIpIHtcblx0XHRcdGFtb3VudCA9IG51bWJybyhhbW91bnQpLmZvcm1hdChmb3JtYXR0ZXIpXG5cdFx0fVxuXHRcdHJldHVybiBgJHthbW91bnR9ICR7Q29pbi5NaW50aW5nRGVub219YDtcblx0fVxuXG5cdHN0YWtlU3RyaW5nIChmb3JtYXR0ZXIpIHtcblx0XHRsZXQgYW1vdW50ID0gdGhpcy5zdGFraW5nQW1vdW50XG5cdFx0aWYgKGZvcm1hdHRlcikge1xuXHRcdFx0YW1vdW50ID0gbnVtYnJvKGFtb3VudCkuZm9ybWF0KGZvcm1hdHRlcilcblx0XHR9XG5cdFx0cmV0dXJuIGAke2Ftb3VudH0gJHtDb2luLlN0YWtpbmdEZW5vbX1gO1xuXHR9XG59IiwiLy8gU2VydmVyIGVudHJ5IHBvaW50LCBpbXBvcnRzIGFsbCBzZXJ2ZXIgY29kZVxuXG5pbXBvcnQgJy9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyJztcbmltcG9ydCAnL2ltcG9ydHMvc3RhcnR1cC9ib3RoJztcbi8vIGltcG9ydCBtb21lbnQgZnJvbSAnbW9tZW50Jztcbi8vIGltcG9ydCAnL2ltcG9ydHMvYXBpL2Jsb2Nrcy9ibG9ja3MuanMnO1xuXG5TWU5DSU5HID0gZmFsc2U7XG5DT1VOVE1JU1NFREJMT0NLUyA9IGZhbHNlO1xuQ09VTlRNSVNTRURCTE9DS1NTVEFUUyA9IGZhbHNlO1xuUlBDID0gTWV0ZW9yLnNldHRpbmdzLnJlbW90ZS5ycGM7XG5MQ0QgPSBNZXRlb3Iuc2V0dGluZ3MucmVtb3RlLmxjZDtcbnRpbWVyQmxvY2tzID0gMDtcbnRpbWVyQ2hhaW4gPSAwO1xudGltZXJDb25zZW5zdXMgPSAwO1xudGltZXJQcm9wb3NhbCA9IDA7XG50aW1lclByb3Bvc2Fsc1Jlc3VsdHMgPSAwO1xudGltZXJNaXNzZWRCbG9jayA9IDA7XG50aW1lckRlbGVnYXRpb24gPSAwO1xudGltZXJBZ2dyZWdhdGUgPSAwO1xuXG5jb25zdCBERUZBVUxUU0VUVElOR1MgPSAnL2RlZmF1bHRfc2V0dGluZ3MuanNvbic7XG5cbnVwZGF0ZUNoYWluU3RhdHVzID0gKCkgPT4ge1xuICAgIE1ldGVvci5jYWxsKCdjaGFpbi51cGRhdGVTdGF0dXMnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ1cGRhdGVTdGF0dXM6IFwiK2Vycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJ1cGRhdGVTdGF0dXM6IFwiK3Jlc3VsdCk7XG4gICAgICAgIH1cbiAgICB9KVxufVxuXG51cGRhdGVCbG9jayA9ICgpID0+IHtcbiAgICBNZXRlb3IuY2FsbCgnYmxvY2tzLmJsb2Nrc1VwZGF0ZScsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInVwZGF0ZUJsb2NrczogXCIrZXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInVwZGF0ZUJsb2NrczogXCIrcmVzdWx0KTtcbiAgICAgICAgfVxuICAgIH0pXG59XG5cbmdldENvbnNlbnN1c1N0YXRlID0gKCkgPT4ge1xuICAgIE1ldGVvci5jYWxsKCdjaGFpbi5nZXRDb25zZW5zdXNTdGF0ZScsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBjb25zZW5zdXM6IFwiK2Vycm9yKVxuICAgICAgICB9XG4gICAgfSlcbn1cblxuZ2V0UHVyY2hhc2VPcmRlcnMgPSAoKSA9PiB7XG4gICBNZXRlb3IuY2FsbCgnZW50ZXJwcmlzZS5nZXRQdXJjaGFzZU9yZGVycycsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgcG86IFwiKyBlcnJvcik7XG4gICAgICAgfVxuICAgICAgIGlmIChyZXN1bHQpe1xuICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBwbzogXCIrcmVzdWx0KTtcbiAgICAgICB9XG4gICB9KTtcbn1cblxuLy9nZXRQcm9wb3NhbHMgPSAoKSA9PiB7XG4vLyAgICBNZXRlb3IuY2FsbCgncHJvcG9zYWxzLmdldFByb3Bvc2FscycsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4vLyAgICAgICAgaWYgKGVycm9yKXtcbi8vICAgICAgICAgICAgY29uc29sZS5sb2coXCJnZXQgcHJvcG9zYWw6IFwiKyBlcnJvcik7XG4vLyAgICAgICAgfVxuLy8gICAgICAgIGlmIChyZXN1bHQpe1xuLy8gICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBwcm9wb3NhbDogXCIrcmVzdWx0KTtcbi8vICAgICAgICB9XG4vLyAgICB9KTtcbi8vfVxuLy9cbi8vZ2V0UHJvcG9zYWxzUmVzdWx0cyA9ICgpID0+IHtcbi8vICAgIE1ldGVvci5jYWxsKCdwcm9wb3NhbHMuZ2V0UHJvcG9zYWxSZXN1bHRzJywgKGVycm9yLCByZXN1bHQpID0+IHtcbi8vICAgICAgICBpZiAoZXJyb3Ipe1xuLy8gICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBwcm9wb3NhbHMgcmVzdWx0OiBcIitlcnJvcik7XG4vLyAgICAgICAgfVxuLy8gICAgICAgIGlmIChyZXN1bHQpe1xuLy8gICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBwcm9wb3NhbHMgcmVzdWx0OiBcIityZXN1bHQpO1xuLy8gICAgICAgIH1cbi8vICAgIH0pO1xuLy99XG5cbnVwZGF0ZU1pc3NlZEJsb2NrcyA9ICgpID0+IHtcbiAgICBNZXRlb3IuY2FsbCgnVmFsaWRhdG9yUmVjb3Jkcy5jYWxjdWxhdGVNaXNzZWRCbG9ja3MnLCAoZXJyb3IsIHJlc3VsdCkgPT57XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIm1pc3NlZCBibG9ja3MgZXJyb3I6IFwiKyBlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwibWlzc2VkIGJsb2NrcyBvazpcIiArIHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICB9KTtcbi8qXG4gICAgTWV0ZW9yLmNhbGwoJ1ZhbGlkYXRvclJlY29yZHMuY2FsY3VsYXRlTWlzc2VkQmxvY2tzU3RhdHMnLCAoZXJyb3IsIHJlc3VsdCkgPT57XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIm1pc3NlZCBibG9ja3Mgc3RhdHMgZXJyb3I6IFwiKyBlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwibWlzc2VkIGJsb2NrcyBzdGF0cyBvazpcIiArIHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICB9KTtcbiovXG59XG5cbmdldERlbGVnYXRpb25zID0gKCkgPT4ge1xuICAgIE1ldGVvci5jYWxsKCdkZWxlZ2F0aW9ucy5nZXREZWxlZ2F0aW9ucycsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBkZWxlZ2F0aW9ucyBlcnJvcjogXCIrIGVycm9yKVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBkZWxlZ2F0aW9ucyBvazogXCIrIHJlc3VsdClcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG5hZ2dyZWdhdGVNaW51dGVseSA9ICgpID0+e1xuICAgIC8vIGRvaW5nIHNvbWV0aGluZyBldmVyeSBtaW5cbiAgICBNZXRlb3IuY2FsbCgnQW5hbHl0aWNzLmFnZ3JlZ2F0ZUJsb2NrVGltZUFuZFZvdGluZ1Bvd2VyJywgXCJtXCIsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSBtaW51dGVseSBibG9jayB0aW1lIGVycm9yOiBcIitlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgbWludXRlbHkgYmxvY2sgdGltZSBvazogXCIrcmVzdWx0KVxuICAgICAgICB9XG4gICAgfSk7XG5cbiAgICBNZXRlb3IuY2FsbCgnY29pblN0YXRzLmdldENvaW5TdGF0cycsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImdldCBjb2luIHN0YXRzIGVycm9yOiBcIitlcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZ2V0IGNvaW4gc3RhdHMgb2s6IFwiK3Jlc3VsdClcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG5hZ2dyZWdhdGVIb3VybHkgPSAoKSA9PntcbiAgICAvLyBkb2luZyBzb21ldGhpbmcgZXZlcnkgaG91clxuICAgIE1ldGVvci5jYWxsKCdBbmFseXRpY3MuYWdncmVnYXRlQmxvY2tUaW1lQW5kVm90aW5nUG93ZXInLCBcImhcIiwgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRlIGhvdXJseSBibG9jayB0aW1lIGVycm9yOiBcIitlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgaG91cmx5IGJsb2NrIHRpbWUgb2s6IFwiK3Jlc3VsdClcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG5hZ2dyZWdhdGVEYWlseSA9ICgpID0+e1xuICAgIC8vIGRvaW5nIHNvbXRoaW5nIGV2ZXJ5IGRheVxuICAgIE1ldGVvci5jYWxsKCdBbmFseXRpY3MuYWdncmVnYXRlQmxvY2tUaW1lQW5kVm90aW5nUG93ZXInLCBcImRcIiwgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRlIGRhaWx5IGJsb2NrIHRpbWUgZXJyb3I6IFwiK2Vycm9yKVxuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFnZ3JlZ2F0ZSBkYWlseSBibG9jayB0aW1lIG9rOiBcIityZXN1bHQpXG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIE1ldGVvci5jYWxsKCdBbmFseXRpY3MuYWdncmVnYXRlVmFsaWRhdG9yRGFpbHlCbG9ja1RpbWUnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3Ipe1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJhZ2dyZWdhdGUgdmFsaWRhdG9ycyBibG9jayB0aW1lIGVycm9yOlwiKyBlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYWdncmVnYXRlIHZhbGlkYXRvcnMgYmxvY2sgdGltZSBvazpcIisgcmVzdWx0KTtcbiAgICAgICAgfVxuICAgIH0pXG59XG5cblxuXG5NZXRlb3Iuc3RhcnR1cChmdW5jdGlvbigpe1xuICAgIGlmIChNZXRlb3IuaXNEZXZlbG9wbWVudCl7XG4gICAgICAgIHByb2Nlc3MuZW52Lk5PREVfVExTX1JFSkVDVF9VTkFVVEhPUklaRUQgPSAwO1xuICAgICAgICBpbXBvcnQgREVGQVVMVFNFVFRJTkdTSlNPTiBmcm9tICcuLi9kZWZhdWx0X3NldHRpbmdzLmpzb24nXG4gICAgICAgIE9iamVjdC5rZXlzKERFRkFVTFRTRVRUSU5HU0pTT04pLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgICAgICAgaWYgKE1ldGVvci5zZXR0aW5nc1trZXldID09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgQ0hFQ0sgU0VUVElOR1MgSlNPTjogJHtrZXl9IGlzIG1pc3NpbmcgZnJvbSBzZXR0aW5nc2ApXG4gICAgICAgICAgICAgICAgTWV0ZW9yLnNldHRpbmdzW2tleV0gPSB7fTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIE9iamVjdC5rZXlzKERFRkFVTFRTRVRUSU5HU0pTT05ba2V5XSkuZm9yRWFjaCgocGFyYW0pID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoTWV0ZW9yLnNldHRpbmdzW2tleV1bcGFyYW1dID09IHVuZGVmaW5lZCl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgQ0hFQ0sgU0VUVElOR1MgSlNPTjogJHtrZXl9LiR7cGFyYW19IGlzIG1pc3NpbmcgZnJvbSBzZXR0aW5nc2ApXG4gICAgICAgICAgICAgICAgICAgIE1ldGVvci5zZXR0aW5nc1trZXldW3BhcmFtXSA9IERFRkFVTFRTRVRUSU5HU0pTT05ba2V5XVtwYXJhbV1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuICAgICAgICB9KVxuICAgIH1cblxuICAgIE1ldGVvci5jYWxsKCdjaGFpbi5nZW5lc2lzJywgKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgIGlmIChNZXRlb3Iuc2V0dGluZ3MuZGVidWcuc3RhcnRUaW1lcil7XG4gICAgICAgICAgICAgICAgdGltZXJDb25zZW5zdXMgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAgICAgZ2V0Q29uc2Vuc3VzU3RhdGUoKTtcbiAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLmNvbnNlbnN1c0ludGVydmFsKTtcblxuICAgICAgICAgICAgICAgIHRpbWVyQmxvY2tzID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZUJsb2NrKCk7XG4gICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5ibG9ja0ludGVydmFsKTtcblxuICAgICAgICAgICAgICAgIHRpbWVyQ2hhaW4gPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlQ2hhaW5TdGF0dXMoKTtcbiAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLnN0YXR1c0ludGVydmFsKTtcblxuICAgICAgICAgICAgICAgIHRpbWVyUHVyY2hhc2VPcmRlciA9IE1ldGVvci5zZXRJbnRlcnZhbCggZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgIGdldFB1cmNoYXNlT3JkZXJzKCk7XG4gICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5wcm9wb3NhbEludGVydmFsKTtcblxuLy8gICAgICAgICAgICAgICAgdGltZXJQcm9wb3NhbCA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuLy8gICAgICAgICAgICAgICAgICAgIGdldFByb3Bvc2FscygpO1xuLy8gICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5wcm9wb3NhbEludGVydmFsKTtcbi8vXG4vLyAgICAgICAgICAgICAgICB0aW1lclByb3Bvc2Fsc1Jlc3VsdHMgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwoZnVuY3Rpb24oKXtcbi8vICAgICAgICAgICAgICAgICAgICBnZXRQcm9wb3NhbHNSZXN1bHRzKCk7XG4vLyAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLnByb3Bvc2FsSW50ZXJ2YWwpO1xuXG4gICAgICAgICAgICAgICAgdGltZXJNaXNzZWRCbG9jayA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVNaXNzZWRCbG9ja3MoKTtcbiAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLm1pc3NlZEJsb2Nrc0ludGVydmFsKTtcblxuICAgICAgICAgICAgICAgIHRpbWVyRGVsZWdhdGlvbiA9IE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgICAgICBnZXREZWxlZ2F0aW9ucygpO1xuICAgICAgICAgICAgICAgIH0sIE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuZGVsZWdhdGlvbkludGVydmFsKTtcblxuICAgICAgICAgICAgICAgIHRpbWVyQWdncmVnYXRlID0gTWV0ZW9yLnNldEludGVydmFsKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgIGxldCBub3cgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoKG5vdy5nZXRVVENTZWNvbmRzKCkgPT0gMCkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgYWdncmVnYXRlTWludXRlbHkoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGlmICgobm93LmdldFVUQ01pbnV0ZXMoKSA9PSAwKSAmJiAobm93LmdldFVUQ1NlY29uZHMoKSA9PSAwKSl7XG4gICAgICAgICAgICAgICAgICAgICAgICBhZ2dyZWdhdGVIb3VybHkoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGlmICgobm93LmdldFVUQ0hvdXJzKCkgPT0gMCkgJiYgKG5vdy5nZXRVVENNaW51dGVzKCkgPT0gMCkgJiYgKG5vdy5nZXRVVENTZWNvbmRzKCkgPT0gMCkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgYWdncmVnYXRlRGFpbHkoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0sIDEwMDApXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9KVxuXG59KTtcbiJdfQ==
